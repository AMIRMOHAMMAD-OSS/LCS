# NeurALPSv2 — Phase 0 Record

Date: 2026-08-11

## Jean Zay
Project root:
`/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2`

Full Phase 0 results:
`/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/results/round0_20260811_072933`

Important files there:
- `round0_data_audit.json`
- `bode_324_model_table.tsv`
- `part_activity_rates.tsv`
- `pair_activity_rates.tsv`
- `shortcut_baseline_results.json`

## Dataset
- 324 Bode constructs
- 173 positive / expected product detected
- 151 negative / expected product not detected
- Positive prevalence: 53.4%

## What Phase 0 models were
Simple logistic-regression diagnostic classifiers on categorical Bode metadata only.
No ESM, VAE, GNN, Transformer, NeurALPSv2, or antiSMASH model training was used.

`part_identity` = categorical identities of initiation, elongation and termination engineered parts (for example pIN24, pIN200, pIN204), not sequence embeddings.

## Random 5-fold CV — easy/leaky reference

| Feature set | ROC-AUC | AP | BA |
|---|---:|---:|---:|
| part_identity | 0.736 | 0.775 | 0.665 |
| donor_nrps | 0.738 | 0.774 | 0.668 |
| species | 0.747 | 0.786 | 0.684 |
| architecture_substrate | 0.738 | 0.778 | 0.668 |
| part_identity_plus_adjacent_pairs | 0.830 | 0.848 | 0.759 |
| all_metadata | 0.824 | 0.842 | 0.756 |

## Leave-one-part-out

| Test | ROC-AUC | AP | BA |
|---|---:|---:|---:|
| initiation | 0.706 | 0.723 | 0.652 |
| elongation | 0.711 | 0.752 | 0.644 |
| termination | 0.658 | 0.714 | 0.616 |

## Leave-source-out

| Test | ROC-AUC | AP | BA |
|---|---:|---:|---:|
| donor NRPS | 0.689 | 0.706 | 0.624 |
| species | 0.694 | 0.711 | 0.629 |

## Individual part activity rates

### Initiation
- pIN24: 45/54 = 0.8333
- pIN241: 32/54 = 0.5926
- pIN244: 28/54 = 0.5185
- pIN243: 26/54 = 0.4815
- pIN264: 23/54 = 0.4259
- pIN263: 19/54 = 0.3519

### Elongation
- pIN285: 29/36 = 0.8056
- pIN200: 25/36 = 0.6944
- pIN237: 21/36 = 0.5833
- pIN238: 19/36 = 0.5278
- pIN246: 18/36 = 0.5000
- pIN247: 17/36 = 0.4722
- pIN269: 17/36 = 0.4722
- pIN240: 14/36 = 0.3889
- pIN239: 13/36 = 0.3611

### Termination
- pIN204: 37/54 = 0.6852
- pIN111: 36/54 = 0.6667
- pIN286: 36/54 = 0.6667
- pIN45: 25/54 = 0.4630
- pIN235: 24/54 = 0.4444
- pIN275: 15/54 = 0.2778

## Notable pair observations

Initiation–elongation, 0/6:
- pIN243 + pIN246
- pIN244 + pIN240
- pIN263 + pIN239

Initiation–elongation, 6/6:
- pIN24 + pIN200
- pIN24 + pIN237
- pIN24 + pIN240
- pIN24 + pIN285

Elongation–termination, 0/6:
- pIN238 + pIN275
- pIN238 + pIN45
- pIN239 + pIN275
- pIN246 + pIN235
- pIN247 + pIN235
- pIN269 + pIN275

Elongation–termination, 6/6:
- pIN200 + pIN286
- pIN237 + pIN45
- pIN238 + pIN204
- pIN238 + pIN286
- pIN247 + pIN204
- pIN269 + pIN235
- pIN285 + pIN204
- pIN285 + pIN286

Initiation–termination:
- pIN241 + pIN275: 0/9
- pIN24 + pIN111: 9/9
- pIN24 + pIN204: 9/9

## Phase 0 interpretation
1. Strong intrinsic part effects exist.
2. Adjacent pair identity adds substantial predictive signal in random CV (ROC 0.736 → 0.830), consistent with pairwise interaction/epistasis, but recurrent-pair memorization has not yet been ruled out.
3. Species/donor metadata is predictive inside Bode, but this is not the feared antiSMASH shortcut. It may reflect real cross-source coupling signal or simply identify the finite 21 parts.
4. The dangerous shortcut is specifically: training natural/same-origin antiSMASH assemblies as positive and arbitrary cross-origin shuffled assemblies as negative.
5. Do not label shuffled antiSMASH constructs as experimentally incompatible. Use antiSMASH mainly for self-supervised representation learning.
6. Current architecture hypothesis:
   `logit P(productive) = b + Σ f(module_i) + Σ g(module_i, junction_i, module_i+1) + h(whole assembly)`
7. Bode scars LNRSAV and SGYSSS should stay as engineered junction/linker features, but they are constant within the 324 library and therefore cannot identify linker-sequence effects by themselves.

## Recommended Phase 0.5
Before large PLM/H100 runs:
1. Verify exact donor/source combinations across all 324 constructs.
2. Compute source-distance diagnostics separately for initiation↔elongation and elongation↔termination.
3. Compare multiple distances: donor NRPS, taxonomic distance, sequence identity/similarity, and later PLM distance.
4. Compare main-effects vs adjacent-interaction vs optional 3-way/global models.
5. Evaluate leave-one-part-out, leave-one-adjacent-pair-out, leave-one-donor-NRPS-out, and leave-one-species-out.
6. Bootstrap confidence intervals.
7. Decide about DANN/IRM only after these diagnostics.

## DANN / IRM position
DANN and IRM are relevant tools for shortcut/domain-invariance problems, but they cannot manufacture experimental cross-origin compatibility labels missing from natural data. Do not adversarially remove origin by default because evolutionary origin can carry real biochemical compatibility signal. First measure whether origin-distance predicts engineered activity and whether origin-decodability actually harms held-out generalization.

References:
- Ganin et al., Domain-Adversarial Training of Neural Networks, JMLR 2016 / arXiv:1505.07818.
- Arjovsky et al., Invariant Risk Minimization, arXiv:1907.02893.
- Geirhos et al., Shortcut Learning in Deep Neural Networks, Nature Machine Intelligence 2020.
