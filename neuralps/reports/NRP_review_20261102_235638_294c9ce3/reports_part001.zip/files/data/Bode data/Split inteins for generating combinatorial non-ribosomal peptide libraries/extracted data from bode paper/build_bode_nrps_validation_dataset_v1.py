#!/usr/bin/env python3
from __future__ import annotations
import csv,gzip,hashlib,json,re,shutil,zipfile
from collections import Counter,defaultdict
from pathlib import Path
from typing import Any

STAGE=Path('/mnt/data/bode_stage1_unz')
ACTIVITY=Path('/mnt/data/bode_main_panel_activity_labels/bode_activity_matrix_324.tsv')
OUT=Path('/mnt/data/bode_nrps_validation_dataset_v1')
ZIP=Path('/mnt/data/bode_nrps_validation_dataset_v1.zip')
SCAR1='LNRSAV'; SCAR2='SGYSSS'

def sha(text:str)->str:return hashlib.sha256(text.encode()).hexdigest()
def sid(s:str)->str:return re.sub(r'[^A-Za-z0-9_.|:=+-]+','_',s)
def b(v:Any)->bool:return str(v).lower()=='true'
def i(v:Any)->int:return int(v)
def monomer_from_specificity(s:str)->str:
    m=re.search(r'substrate consensus:\s*([^;]+)',s or '',re.I)
    return m.group(1).strip() if m else ''
def is_loader(hit:str)->bool:return hit=='AMP-binding' or 'AMP-binding' in hit or hit in {'A-OX','CAL_domain','CoA-ligase'}
def is_carrier(hit:str)->bool:return hit in {'PCP','PP-binding','ACP','ACP_beta','ACP-like'}
def read_gz(name):
    with gzip.open(STAGE/name,'rt',encoding='utf-8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def read_fasta_gz(path):
    out={}; h=None; seq=[]
    with gzip.open(path,'rt',encoding='utf-8') as f:
        for line in f:
            line=line.strip()
            if not line:continue
            if line.startswith('>'):
                if h is not None:out[h]=''.join(seq)
                h=line[1:].split()[0];seq=[]
            else:seq.append(line)
    if h is not None:out[h]=''.join(seq)
    return out
class TSV:
    def __init__(self,path,fields):
        self.path=path;self.fields=fields;self.h=gzip.open(path,'wt',encoding='utf-8',newline='');self.w=csv.DictWriter(self.h,fieldnames=fields,delimiter='\t',extrasaction='ignore');self.w.writeheader();self.n=0
    def write(self,row):self.w.writerow(row);self.n+=1
    def close(self):self.h.close()
class FASTA:
    def __init__(self,path):self.h=gzip.open(path,'wt',encoding='utf-8');self.n=0
    def write(self,h,s):
        self.h.write('>'+h+'\n');
        for x in range(0,len(s),80):self.h.write(s[x:x+80]+'\n')
        self.n+=1
    def close(self):self.h.close()

def main():
    if OUT.exists():shutil.rmtree(OUT)
    OUT.mkdir()
    source_seqs=read_fasta_gz(STAGE/'unique_proteins.fasta.gz')
    records={r['part_id']:r for r in read_gz('unique_records.tsv.gz') if r['role']!='native_reference'}
    chains=defaultdict(list)
    for r in read_gz('part_chains.tsv.gz'):
        if r['role']!='native_reference':chains[r['part_id']].append({**r,'chain_index':i(r['chain_index']),'start':i(r['start_in_raw_sequence_0based']),'end':i(r['end_in_raw_sequence_0based_exclusive'])})
    for p in chains:chains[p].sort(key=lambda x:x['chain_index'])
    src_domains=defaultdict(list)
    for r in read_gz('domains.tsv.gz'):
        if r['role']!='native_reference':
            r={**r,'start':i(r['start_0based']),'end':i(r['end_0based_exclusive']),'domain_index':i(r['domain_index'])}
            r['monomer']=monomer_from_specificity(r['specificity'])
            src_domains[r['part_id']].append(r)
    for p in src_domains:src_domains[p].sort(key=lambda x:(x['start'],x['end']))
    src_modules=defaultdict(list)
    for r in read_gz('modules.tsv.gz'):
        if r['role']!='native_reference':
            r={**r,'start':i(r['start_0based']),'end':i(r['end_0based_exclusive']),'module_index':i(r['module_index'])}
            ds=[d for d in src_domains[r['part_id']] if d['start']>=r['start'] and d['end']<=r['end']]
            r['domains']=ds;r['has_loader']=any(is_loader(d['domain_type']) for d in ds);r['has_carrier']=any(is_carrier(d['domain_type']) for d in ds)
            r['monomers']=[d['monomer'] or 'X' for d in ds if is_loader(d['domain_type'])]
            if r['has_loader']:src_modules[r['part_id']].append(r)
    for p in src_modules:src_modules[p].sort(key=lambda x:(x['start'],x['end']))
    prefix_domains={}
    for pid in records:
        mods=src_modules[pid]
        if records[pid]['role'] in {'elongation','termination'}:
            first_start=mods[0]['start'] if mods else 10**9
            assigned={id(d) for m in mods for d in m['domains']}
            prefix=[d for d in src_domains[pid] if d['start']<first_start and id(d) not in assigned]
            prefix_domains[pid]=prefix
        else:prefix_domains[pid]=[]
    # sanity
    for pid in records:
        role=records[pid]['role']; mods=src_modules[pid]
        if role in {'initiation','elongation'} and (not mods or mods[-1]['has_carrier']):raise RuntimeError(f'{pid} expected final incomplete module')
        if role in {'elongation','termination'} and not prefix_domains[pid]:raise RuntimeError(f'{pid} missing leading prefix domains')

    activity={r['construct_id']:r for r in csv.DictReader(ACTIVITY.open(),delimiter='\t')}
    panel_letter={}
    for r in csv.DictReader((Path('/mnt/data/bode_main_panel_activity_labels/panel_letter_to_part.tsv')).open(),delimiter='\t'):panel_letter[r['part_id']]=r['panel_letter']
    part_meta={
'pIN24':('GxpS','Photorhabdus laumondii'),'pIN241':('BicA','Xenorhabdus budapestensis'),'pIN263':('FitAB','Xenorhabdus innexi'),'pIN264':('XabABC','Xenorhabdus szentirmaii'),'pIN244':('XabABC','Xenorhabdus stockiae'),'pIN243':('IszAB/XldS','Xenorhabdus indica'),
'pIN200':('XtpS','Xenorhabdus nematophila'),'pIN237':('IszAB/XldS','Xenorhabdus indica'),'pIN239':('FitAB','Xenorhabdus innexi'),'pIN240':('MbpA','Mortierella alpina'),'pIN285':('GxpS','Photorhabdus laumondii'),'pIN246':('AmbS','Xenorhabdus miraniensis'),'pIN247':('AmbS','Xenorhabdus indica'),'pIN238':('XabA','Xenorhabdus mauleonii'),'pIN269':('FitAB','Xenorhabdus innexi'),
'pIN204':('XtpS','Xenorhabdus nematophila'),'pIN286':('GxpS','Photorhabdus laumondii'),'pIN275':('AmbS-XtpS','Xenorhabdus miraniensis;Xenorhabdus nematophila'),'pIN111':('XtpS','Xenorhabdus nematophila'),'pIN235':('PrtAB','Xenorhabdus doucetiae'),'pIN45':('GxpS','Photorhabdus luminescens')}
    # output writers exact core schema
    T={
'genomes':TSV(OUT/'genomes.tsv.gz',['accession','antismash_version','schema','record_count','nrps_area_count','modular_protein_count','assembly_line_count']),
'areas':TSV(OUT/'areas.tsv.gz',['accession','record_id','area_index','prediction_key','start_nt_0based','end_nt_0based_exclusive','products','tax_id','organism','species','genus','family','order','class','phylum','kingdom','superkingdom']),
'proteins':TSV(OUT/'proteins.tsv.gz',['protein_uid','accession','record_id','area_index','cds_name','locus_tag','gene','protein_id','product','start_nt_0based','end_nt_0based_exclusive','strand','length_aa','reported_module_count','component_only','contains_nrps_module','module_families']),
'modules':TSV(OUT/'modules.tsv.gz',['module_uid','accession','record_id','area_index','owner_cds','reported_module_index','first_in_cds','module_family','multi_cds','component_loci','segment_count','component_count','component_architecture','has_loader','has_carrier','operational_complete','contiguous_sequence_available','contiguous_locus','start_aa_0based','end_aa_0based_exclusive','length_aa','predicted_monomers']),
'module_segments':TSV(OUT/'module_segments.tsv.gz',['module_uid','segment_index','locus','protein_uid','start_aa_0based','end_aa_0based_exclusive','length_aa','component_count','component_architecture']),
'domains':TSV(OUT/'domains.tsv.gz',['domain_uid','accession','record_id','area_index','locus','protein_uid','hit_id','start_aa_0based','end_aa_0based_exclusive','length_aa','evalue','bitscore','antismash_domain_key','predicted_monomer_consensus']),
'module_domains':TSV(OUT/'module_domains.tsv.gz',['module_uid','component_order','domain_uid','locus','hit_id','start_aa_0based','end_aa_0based_exclusive']),
'consensus':TSV(OUT/'substrate_consensus.tsv.gz',['accession','record_id','domain_key','locus','predicted_monomer']),
'region':TSV(OUT/'region_predictions.tsv.gz',['assembly_line_id','accession','record_id','area_index','prediction_index','sc_number','polymer','smiles','docking_used','ordering_source','protein_ordering']),
'lines':TSV(OUT/'assembly_lines.tsv.gz',['assembly_line_id','accession','record_id','area_index','prediction_index','polymer','smiles','docking_used','ordering_source','protein_count','module_count','chain_break_count']),
'line_proteins':TSV(OUT/'assembly_line_proteins.tsv.gz',['assembly_line_id','protein_order','protein_uid','cds_name','length_aa','reported_module_count','chain_break_after']),
'line_modules':TSV(OUT/'assembly_line_modules.tsv.gz',['assembly_line_id','global_module_index','protein_order','owner_cds','reported_module_index','module_uid','module_family','multi_cds','predicted_monomers']),
'transitions':TSV(OUT/'assembly_line_transitions.tsv.gz',['transition_uid','assembly_line_id','left_global_module_index','right_global_module_index','left_module_uid','right_module_uid','left_owner_cds','right_owner_cds','transition_type','sequence_available','start_aa_0based','end_aa_0based_exclusive','length_aa','left_terminal_component','right_initial_component']),
'linkers':TSV(OUT/'inter_module_linkers.tsv.gz',['transition_uid','assembly_line_id','accession','record_id','area_index','cds_name','left_global_module_index','right_global_module_index','left_module_uid','right_module_uid','start_aa_0based','end_aa_0based_exclusive','length_aa','left_terminal_component','right_initial_component','interpretation']),
'gaps':TSV(OUT/'inter_component_gaps.tsv.gz',['module_uid','locus','left_domain_uid','right_domain_uid','left_component','right_component','start_aa_0based','end_aa_0based_exclusive','length_aa','interpretation']),
'flanks':TSV(OUT/'terminal_flanks.tsv.gz',['protein_uid','accession','record_id','area_index','cds_name','flank_type','start_aa_0based','end_aa_0based_exclusive','length_aa']),
# validation-specific
'parts':TSV(OUT/'engineered_parts.tsv.gz',['part_id','panel_letter','role','source_nrps','source_species','length_aa','chain_count','source_architecture','source_substrate_consensus','exact_native_source_mapping','source_filenames']),
'constructs':TSV(OUT/'engineered_constructs.tsv.gz',['construct_id','panel_code','initiation_part','elongation_part','termination_part','fusion_site','splice_strategy','splice_1_intein','splice_1_scar','splice_2_intein','splice_2_scar','mature_chain_count','total_mature_aa','experimental_product_detected','product_topology','linear_product_detected','cyclic_product_detected','validation_status','label_source']),
'membership':TSV(OUT/'construct_part_membership.tsv.gz',['construct_id','part_order','role','part_id','panel_letter','source_chain_count','source_length_aa']),
'splices':TSV(OUT/'engineered_splice_junctions.tsv.gz',['splice_uid','construct_id','junction_index','junction_name','fusion_site','splice_strategy','intein','left_js_triplet','right_js_triplet','mature_scar_sequence','mature_chain_index','scar_start_aa_0based','scar_end_aa_0based_exclusive','left_part','right_part','crossing_module_uid','upstream_50aa','downstream_50aa','mature_context_50aa_each_side']),
'scars':TSV(OUT/'engineered_splice_scars.tsv.gz',['splice_uid','construct_id','mature_chain_index','start_aa_0based','end_aa_0based_exclusive','length_aa','sequence','interpretation']),
'eng_segments':TSV(OUT/'engineered_module_segments.tsv.gz',['module_uid','construct_id','segment_index','segment_type','source_part','source_chain_index','source_start_aa_0based','source_end_aa_0based_exclusive','mature_chain_index','mature_start_aa_0based','mature_end_aa_0based_exclusive','length_aa','sequence']),
'activity':TSV(OUT/'experimental_construct_activity.tsv.gz',['construct_id','panel_code','expected_product_detected','product_topology','linear_product_detected','cyclic_product_detected','activity_definition','negative_label_interpretation','source']),
'products':TSV(OUT/'experimental_products.tsv.gz',['product_number','construct_code','construct_id','reported_titer_mg_L','titer_status','structure_confirmed_by_synthetic_standard','product_topology','coverage_note','source']),
'donors':TSV(OUT/'native_donor_mapping.tsv.gz',['part_id','role','panel_letter','source_nrps','source_species','exact_native_source_mapping','source_note']),
'source_modules':TSV(OUT/'source_part_modules.tsv.gz',list(next(iter(read_gz('modules.tsv.gz'))).keys())),
'source_domains':TSV(OUT/'source_part_domains.tsv.gz',list(next(iter(read_gz('domains.tsv.gz'))).keys())),
}
    F={k:FASTA(OUT/fn) for k,fn in {'proteins':'proteins.fasta.gz','modules':'contiguous_modules.fasta.gz','segments':'module_segments.fasta.gz','domains':'domains.fasta.gz','assembly':'assembly_line_proteins.fasta.gz','linkers':'inter_module_linkers.fasta.gz','gaps':'inter_component_gaps.fasta.gz','flanks':'terminal_flanks.fasta.gz','scars':'engineered_splice_scars.fasta.gz','unique':'unique_mature_chains.fasta.gz','source':'source_engineered_parts.fasta.gz'}.items()}
    # source tables and part metadata
    for r in read_gz('modules.tsv.gz'):
        if r['role']!='native_reference':T['source_modules'].write(r)
    for r in read_gz('domains.tsv.gz'):
        if r['role']!='native_reference':T['source_domains'].write(r)
    for pid,r in sorted(records.items(),key=lambda x:(x[1]['role'],x[0])):
        source_nrps,species=part_meta[pid]
        T['parts'].write({'part_id':pid,'panel_letter':panel_letter[pid],'role':r['role'],'source_nrps':source_nrps,'source_species':species,'length_aa':r['amino_acid_count'],'chain_count':r['chain_count'],'source_architecture':r['nrpspks_architecture'],'source_substrate_consensus':r['substrate_consensus_ordered'],'exact_native_source_mapping':r['exact_native_source_mapping_by_chain'],'source_filenames':r['source_filenames']})
        T['donors'].write({'part_id':pid,'role':r['role'],'panel_letter':panel_letter[pid],'source_nrps':source_nrps,'source_species':species,'exact_native_source_mapping':r['exact_native_source_mapping_by_chain'],'source_note':'Figure 3a donor label plus exact sequence mapping from supplied SnapGene records'})
        F['source'].write(f'{pid}|role={r["role"]}|panel={panel_letter[pid]}',source_seqs[pid].replace('*',''))
    # helper placements/mapping
    def source_chain_for(pid,start,end):
        for c in chains[pid]:
            if start>=c['start'] and end<=c['end']:return c
        raise RuntimeError(f'interval outside chains {pid} {start}:{end}')
    def mapped(pid,start,end,placements):
        c=source_chain_for(pid,start,end); pl=placements[(pid,c['chain_index'])]
        return pl['mature_chain'],pl['offset']+(start-c['start']),pl['offset']+(end-c['start'])
    def map_domain(pid,d,placements):
        ch,s,e=mapped(pid,d['start'],d['end'],placements)
        return {**d,'source_part':pid,'mature_chain':ch,'mstart':s,'mend':e}
    # representative products
    products=[('1','AIS','6.0','quantified'),('2','ALQ','','not_reliably_determined_poor_solubility'),('3','AKV','','not_reliably_determined_poor_solubility'),('4','APQ','0.6','quantified'),('5','BKQ','2.9','quantified'),('6','BNR','11.8','quantified'),('7','BIV','0.2','quantified'),('8','BPU','6.3','quantified'),('9','CHR','0.6','quantified'),('10','CIV','0.6','quantified'),('11','DHU','0.9','quantified'),('12','DMV','0.2','quantified'),('13','EJT','0.3','quantified'),('14','FOT','0.6','quantified')]
    unique_mature={}
    counts=Counter(); family=Counter(); activity_counts=Counter(); module_count_dist=Counter()
    domain_pred=gzip.open(OUT/'domain_predictions.jsonl.gz','wt',encoding='utf-8')
    # order construct ids by panel letters A-F/H-P/Q-V
    inits=sorted([p for p,r in records.items() if r['role']=='initiation'],key=lambda p:panel_letter[p])
    elongs=sorted([p for p,r in records.items() if r['role']=='elongation'],key=lambda p:panel_letter[p])
    terms=sorted([p for p,r in records.items() if r['role']=='termination'],key=lambda p:panel_letter[p])
    for iid in inits:
      for eid in elongs:
       for tid in terms:
        cid=f'BODE_{iid}_{eid}_{tid}'; alid=f'{cid}|assembly_line=1'; acc=cid; recid=cid; area=1
        act=activity[cid]; code=f'{panel_letter[iid]}{panel_letter[eid]}{panel_letter[tid]}'
        iseq=source_seqs[iid]; eseq=source_seqs[eid]; tseq=source_seqs[tid]
        ich=chains[iid][0]; tch=chains[tid][0]; ech=chains[eid]
        placements={}
        mature_chains=[]
        scar_intervals=[]
        if eid!='pIN269':
            eseq1=eseq[ech[0]['start']:ech[0]['end']]
            seq=iseq+SCAR1+eseq1+SCAR2+tseq
            mature_chains=[seq]
            placements[(iid,1)]={'mature_chain':1,'offset':0}
            placements[(eid,1)]={'mature_chain':1,'offset':len(iseq)+6}
            placements[(tid,1)]={'mature_chain':1,'offset':len(iseq)+6+len(eseq1)+6}
            scar_intervals=[(1,len(iseq),len(iseq)+6,SCAR1),(1,len(iseq)+6+len(eseq1),len(iseq)+12+len(eseq1),SCAR2)]
        else:
            e1=eseq[ech[0]['start']:ech[0]['end']]; e2=eseq[ech[1]['start']:ech[1]['end']]
            mature_chains=[iseq+SCAR1+e1,e2+SCAR2+tseq]
            placements[(iid,1)]={'mature_chain':1,'offset':0}
            placements[(eid,1)]={'mature_chain':1,'offset':len(iseq)+6}
            placements[(eid,2)]={'mature_chain':2,'offset':0}
            placements[(tid,1)]={'mature_chain':2,'offset':len(e2)+6}
            scar_intervals=[(1,len(iseq),len(iseq)+6,SCAR1),(2,len(e2),len(e2)+6,SCAR2)]
        protein_uids={}; cds_names={}
        for ci,seq in enumerate(mature_chains,1):
            puid=f'{cid}|mature_chain={ci}'; cds=f'mature_chain_{ci}'
            protein_uids[ci]=puid;cds_names[ci]=cds
            unique_mature.setdefault(sha(seq),seq)
        # build module objects
        modules=[]
        def source_module_obj(pid,m):
            ch,s,e=mapped(pid,m['start'],m['end'],placements)
            ds=[map_domain(pid,d,placements) for d in m['domains']]
            return {'chain':ch,'start':s,'end':e,'domains':ds,'monomers':m['monomers'],'source_type':'source_module','source_part':pid,'source_segments':[(pid,source_chain_for(pid,m['start'],m['end'])['chain_index'],m['start'],m['end'],ch,s,e,'source_module')]}
        imods=src_modules[iid]; emods=src_modules[eid]; tmods=src_modules[tid]
        for m in imods[:-1]:modules.append(source_module_obj(iid,m))
        # merge splice 1
        up=imods[-1]; pre=prefix_domains[eid]
        upch,ups,upe=mapped(iid,up['start'],up['end'],placements)
        pch,ps,pe=mapped(eid,min(d['start'] for d in pre),max(d['end'] for d in pre),placements)
        assert upch==pch==scar_intervals[0][0]
        ds=[map_domain(iid,d,placements) for d in up['domains']]+[map_domain(eid,d,placements) for d in pre]
        ds.sort(key=lambda d:d['mstart'])
        up_chain=source_chain_for(iid,up['start'],up['end']); pre_chain=source_chain_for(eid,min(d['start'] for d in pre),max(d['end'] for d in pre))
        pl_up=placements[(iid,up_chain['chain_index'])]; pl_pre=placements[(eid,pre_chain['chain_index'])]
        modules.append({'chain':upch,'start':ups,'end':pe,'domains':ds,'monomers':up['monomers'],'source_type':'engineered_cross_splice_1','source_part':f'{iid};{eid}','source_segments':[(iid,up_chain['chain_index'],up['start'],up_chain['end'],upch,ups,pl_up['offset']+(up_chain['end']-up_chain['start']),'upstream_extein'),('',0,0,0,upch,scar_intervals[0][1],scar_intervals[0][2],'engineered_scar'),(eid,pre_chain['chain_index'],pre_chain['start'],max(d['end'] for d in pre),pch,pl_pre['offset'],pe,'downstream_extein')]})
        # elong complete except pending last
        for m in emods[:-1]:modules.append(source_module_obj(eid,m))
        # merge splice2
        up=emods[-1]; pre=prefix_domains[tid]
        upch,ups,upe=mapped(eid,up['start'],up['end'],placements)
        pch,ps,pe=mapped(tid,min(d['start'] for d in pre),max(d['end'] for d in pre),placements)
        assert upch==pch==scar_intervals[1][0]
        ds=[map_domain(eid,d,placements) for d in up['domains']]+[map_domain(tid,d,placements) for d in pre];ds.sort(key=lambda d:d['mstart'])
        up_chain=source_chain_for(eid,up['start'],up['end']); pre_chain=source_chain_for(tid,min(d['start'] for d in pre),max(d['end'] for d in pre))
        pl_up=placements[(eid,up_chain['chain_index'])];pl_pre=placements[(tid,pre_chain['chain_index'])]
        modules.append({'chain':upch,'start':ups,'end':pe,'domains':ds,'monomers':up['monomers'],'source_type':'engineered_cross_splice_2','source_part':f'{eid};{tid}','source_segments':[(eid,up_chain['chain_index'],up['start'],up_chain['end'],upch,ups,pl_up['offset']+(up_chain['end']-up_chain['start']),'upstream_extein'),('',0,0,0,upch,scar_intervals[1][1],scar_intervals[1][2],'engineered_scar'),(tid,pre_chain['chain_index'],pre_chain['start'],max(d['end'] for d in pre),pch,pl_pre['offset'],pe,'downstream_extein')]})
        for m in tmods:modules.append(source_module_obj(tid,m))
        # sort by chain then coordinate
        modules.sort(key=lambda m:(m['chain'],m['start'],m['end']))
        module_count_dist[len(modules)]+=1
        # enrich uids and write proteins after module counts known
        bychain=Counter(m['chain'] for m in modules)
        T['genomes'].write({'accession':acc,'antismash_version':'supplied antiSMASH protein annotations; Bode validation converter v1','schema':'BODE_VALIDATION_1','record_count':1,'nrps_area_count':1,'modular_protein_count':len(mature_chains),'assembly_line_count':1})
        T['areas'].write({'accession':acc,'record_id':recid,'area_index':area,'prediction_key':'experimentally_defined_construct','products':'engineered_NRPS_validation','organism':'synthetic chimeric NRPS expressed in Escherichia coli DH10B::mtaA','species':'synthetic construct','genus':'','family':'','order':'','class':'','phylum':'','kingdom':'','superkingdom':''})
        for ci,seq in enumerate(mature_chains,1):
            puid=protein_uids[ci];cds=cds_names[ci]
            T['proteins'].write({'protein_uid':puid,'accession':acc,'record_id':recid,'area_index':area,'cds_name':cds,'locus_tag':cds,'gene':'engineered_NRPS','protein_id':puid,'product':'mature split-intein-spliced NRPS chain','length_aa':len(seq),'reported_module_count':bychain[ci],'component_only':False,'contains_nrps_module':True,'module_families':'NRPS'})
            F['proteins'].write(f'{puid}|length={len(seq)}|engineered_mature_chain',seq);F['assembly'].write(f'{alid}|protein_order={ci}|{cds}|CHAIN_BREAK_AFTER={ci<len(mature_chains)}',seq)
        # write modules/domains
        domain_uid_by_obj={}; module_rows=[]
        for gi,m in enumerate(modules,1):
            muid=f'{cid}|module={gi}';m['uid']=muid;m['global']=gi
            cds=cds_names[m['chain']];puid=protein_uids[m['chain']];seq=mature_chains[m['chain']-1]
            arch='->'.join(d['domain_type'] for d in m['domains']); hasl=any(is_loader(d['domain_type']) for d in m['domains']);hasc=any(is_carrier(d['domain_type']) for d in m['domains']); mons=';'.join(m['monomers'])
            T['modules'].write({'module_uid':muid,'accession':acc,'record_id':recid,'area_index':area,'owner_cds':cds,'reported_module_index':sum(1 for x in modules[:gi] if x['chain']==m['chain']),'first_in_cds':sum(1 for x in modules[:gi] if x['chain']==m['chain'])==1,'module_family':'NRPS','multi_cds':False,'component_loci':cds,'segment_count':1,'component_count':len(m['domains']),'component_architecture':arch,'has_loader':hasl,'has_carrier':hasc,'operational_complete':hasl and hasc,'contiguous_sequence_available':True,'contiguous_locus':cds,'start_aa_0based':m['start'],'end_aa_0based_exclusive':m['end'],'length_aa':m['end']-m['start'],'predicted_monomers':mons})
            T['module_segments'].write({'module_uid':muid,'segment_index':1,'locus':cds,'protein_uid':puid,'start_aa_0based':m['start'],'end_aa_0based_exclusive':m['end'],'length_aa':m['end']-m['start'],'component_count':len(m['domains']),'component_architecture':arch})
            F['modules'].write(f'{muid}|family=NRPS|locus={cds}|coords={m["start"]}:{m["end"]}|monomers={mons or "-"}',seq[m['start']:m['end']]);F['segments'].write(f'{muid}|segment=1|locus={cds}|coords={m["start"]}:{m["end"]}',seq[m['start']:m['end']])
            for si,(sp,sci,ss,se,mch,ms,me,stype) in enumerate(m['source_segments'],1):
                segseq=seq[ms:me]
                T['eng_segments'].write({'module_uid':muid,'construct_id':cid,'segment_index':si,'segment_type':stype,'source_part':sp,'source_chain_index':sci or '','source_start_aa_0based':ss if sp else '','source_end_aa_0based_exclusive':se if sp else '','mature_chain_index':mch,'mature_start_aa_0based':ms,'mature_end_aa_0based_exclusive':me,'length_aa':me-ms,'sequence':segseq})
            for oi,d in enumerate(m['domains'],1):
                duid=f'{cid}|chain={m["chain"]}|{d["source_part"]}|{d["domain_type"]}|{d["mstart"]}:{d["mend"]}'
                domain_uid_by_obj[(muid,oi)]=duid
                mon=d['monomer'] if is_loader(d['domain_type']) else ''
                T['domains'].write({'domain_uid':duid,'accession':acc,'record_id':recid,'area_index':area,'locus':cds,'protein_uid':puid,'hit_id':d['domain_type'],'start_aa_0based':d['mstart'],'end_aa_0based_exclusive':d['mend'],'length_aa':d['mend']-d['mstart'],'evalue':d['evalue'],'bitscore':d['score'],'antismash_domain_key':d['domain_id'] or d['feature_name'],'predicted_monomer_consensus':mon})
                T['module_domains'].write({'module_uid':muid,'component_order':oi,'domain_uid':duid,'locus':cds,'hit_id':d['domain_type'],'start_aa_0based':d['mstart'],'end_aa_0based_exclusive':d['mend']})
                F['domains'].write(f'{duid}|monomer={mon or "-"}',seq[d['mstart']:d['mend']])
                if mon:
                    T['consensus'].write({'accession':acc,'record_id':recid,'domain_key':d['domain_id'] or duid,'locus':cds,'predicted_monomer':mon})
                    domain_pred.write(json.dumps({'construct_id':cid,'domain_uid':duid,'source_part':d['source_part'],'source_domain_id':d['domain_id'],'predicted_monomer':mon,'raw_specificity':d['specificity']},separators=(',',':'))+'\n')
            # component gaps
            for oi,(ld,rd) in enumerate(zip(m['domains'],m['domains'][1:]),1):
                gs,ge=ld['mend'],rd['mstart']
                if ge<gs:counts['overlapping_components']+=1;continue
                luid=domain_uid_by_obj[(muid,oi)];ruid=domain_uid_by_obj[(muid,oi+1)]
                interp='inter_component_gap_not_validated_linker'
                if m['source_type'].startswith('engineered_cross') and ((scar_intervals[0][1]>=gs and scar_intervals[0][2]<=ge) or (scar_intervals[1][1]>=gs and scar_intervals[1][2]<=ge)):
                    interp='engineered_xuti_splice_scar_within_A_to_T_inter_component_gap'
                T['gaps'].write({'module_uid':muid,'locus':cds,'left_domain_uid':luid,'right_domain_uid':ruid,'left_component':ld['domain_type'],'right_component':rd['domain_type'],'start_aa_0based':gs,'end_aa_0based_exclusive':ge,'length_aa':ge-gs,'interpretation':interp})
                F['gaps'].write(f'{muid}|locus={cds}|gap={ld["domain_type"]}__{rd["domain_type"]}|coords={gs}:{ge}|{interp}',seq[gs:ge])
            module_rows.append(m)
        # splices now crossing module uids known
        crossing=[m for m in modules if m['source_type'].startswith('engineered_cross')]
        assert len(crossing)==2
        for ji,(ch,ss,se,scar) in enumerate(scar_intervals,1):
            intein='gp41-8' if ji==1 else 'NrdJ-1'; leftjs='LNR' if ji==1 else 'SGY';rightjs='SAV' if ji==1 else 'SSS';left=iid if ji==1 else eid;right=eid if ji==1 else tid
            seq=mature_chains[ch-1];suid=f'{cid}|splice={ji}'
            T['splices'].write({'splice_uid':suid,'construct_id':cid,'junction_index':ji,'junction_name':'initiation_to_elongation' if ji==1 else 'elongation_to_termination','fusion_site':'XUTI','splice_strategy':'js_insertion','intein':intein,'left_js_triplet':leftjs,'right_js_triplet':rightjs,'mature_scar_sequence':scar,'mature_chain_index':ch,'scar_start_aa_0based':ss,'scar_end_aa_0based_exclusive':se,'left_part':left,'right_part':right,'crossing_module_uid':crossing[ji-1]['uid'],'upstream_50aa':seq[max(0,ss-50):ss],'downstream_50aa':seq[se:se+50],'mature_context_50aa_each_side':seq[max(0,ss-50):min(len(seq),se+50)]})
            T['scars'].write({'splice_uid':suid,'construct_id':cid,'mature_chain_index':ch,'start_aa_0based':ss,'end_aa_0based_exclusive':se,'length_aa':6,'sequence':scar,'interpretation':'six_residue_intein_junction_sequence_scar_retained_after_trans_splicing'})
            F['scars'].write(f'{suid}|chain={ch}|coords={ss}:{se}|intein={intein}|XUTI|js_insertion',scar)
        # transitions
        link_count=0;break_count=0
        for ti,(lm,rm) in enumerate(zip(modules,modules[1:]),1):
            tuid=f'{cid}|transition={ti}';lt=lm['domains'][-1]['domain_type'];ri=rm['domains'][0]['domain_type']
            if lm['chain']!=rm['chain']:
                typ='inter_protein_chain_break';seqavail=False;st=en=ln='';break_count+=1
            else:
                st=lm['end'];en=rm['start'];ln=en-st
                typ='overlapping_module_spans' if ln<0 else 'inter_module_linker_candidate';seqavail=ln>=0
                if ln>=0:
                    link_count+=1;cds=cds_names[lm['chain']];seq=mature_chains[lm['chain']-1][st:en]
                    T['linkers'].write({'transition_uid':tuid,'assembly_line_id':alid,'accession':acc,'record_id':recid,'area_index':area,'cds_name':cds,'left_global_module_index':ti,'right_global_module_index':ti+1,'left_module_uid':lm['uid'],'right_module_uid':rm['uid'],'start_aa_0based':st,'end_aa_0based_exclusive':en,'length_aa':ln,'left_terminal_component':lt,'right_initial_component':ri,'interpretation':'inter_module_linker_candidate_from_engineered_mature_NRPS_not_experimentally_validated_as_linker'})
                    F['linkers'].write(f'{tuid}|{cds}|coords={st}:{en}|candidate_linker',seq)
            T['transitions'].write({'transition_uid':tuid,'assembly_line_id':alid,'left_global_module_index':ti,'right_global_module_index':ti+1,'left_module_uid':lm['uid'],'right_module_uid':rm['uid'],'left_owner_cds':cds_names[lm['chain']],'right_owner_cds':cds_names[rm['chain']],'transition_type':typ,'sequence_available':seqavail,'start_aa_0based':st,'end_aa_0based_exclusive':en,'length_aa':ln,'left_terminal_component':lt,'right_initial_component':ri})
        # flanks
        for ci,seq in enumerate(mature_chains,1):
            cms=[m for m in modules if m['chain']==ci];firsts=min(m['start'] for m in cms);laste=max(m['end'] for m in cms);cds=cds_names[ci];puid=protein_uids[ci]
            for typ,s,e in [('n_terminal_flank',0,firsts),('c_terminal_flank',laste,len(seq))]:
                T['flanks'].write({'protein_uid':puid,'accession':acc,'record_id':recid,'area_index':area,'cds_name':cds,'flank_type':typ,'start_aa_0based':s,'end_aa_0based_exclusive':e,'length_aa':e-s});F['flanks'].write(f'{puid}|{typ}|coords={s}:{e}',seq[s:e])
        monomers=[m for m in modules for m in m['monomers']];polymer=' - '.join(monomers)
        T['region'].write({'assembly_line_id':alid,'accession':acc,'record_id':recid,'area_index':area,'prediction_index':1,'sc_number':'experimental_construct','polymer':polymer,'smiles':'','docking_used':'','ordering_source':'experimentally_defined_Bode_324_library','protein_ordering':';'.join(cds_names[x] for x in sorted(cds_names))})
        T['lines'].write({'assembly_line_id':alid,'accession':acc,'record_id':recid,'area_index':area,'prediction_index':1,'polymer':polymer,'smiles':'','docking_used':'','ordering_source':'experimentally_defined_Bode_324_library','protein_count':len(mature_chains),'module_count':len(modules),'chain_break_count':len(mature_chains)-1})
        for ci,seq in enumerate(mature_chains,1):T['line_proteins'].write({'assembly_line_id':alid,'protein_order':ci,'protein_uid':protein_uids[ci],'cds_name':cds_names[ci],'length_aa':len(seq),'reported_module_count':bychain[ci],'chain_break_after':ci<len(mature_chains)})
        for gi,m in enumerate(modules,1):T['line_modules'].write({'assembly_line_id':alid,'global_module_index':gi,'protein_order':m['chain'],'owner_cds':cds_names[m['chain']],'reported_module_index':sum(1 for x in modules[:gi] if x['chain']==m['chain']),'module_uid':m['uid'],'module_family':'NRPS','multi_cds':False,'predicted_monomers':';'.join(m['monomers'])})
        detected=act['experimental_product_detected']=='True';status='experimentally_expected_product_detected' if detected else 'expected_product_not_detected'
        T['constructs'].write({'construct_id':cid,'panel_code':code,'initiation_part':iid,'elongation_part':eid,'termination_part':tid,'fusion_site':'XUTI','splice_strategy':'js_insertion','splice_1_intein':'gp41-8','splice_1_scar':SCAR1,'splice_2_intein':'NrdJ-1','splice_2_scar':SCAR2,'mature_chain_count':len(mature_chains),'total_mature_aa':sum(map(len,mature_chains)),'experimental_product_detected':detected,'product_topology':act['product_topology'],'linear_product_detected':act['linear_product_detected'],'cyclic_product_detected':act['cyclic_product_detected'],'validation_status':status,'label_source':'Figure_3b_HR_LC_MS_expected_product_matrix'})
        for po,pid in enumerate([iid,eid,tid],1):T['membership'].write({'construct_id':cid,'part_order':po,'role':records[pid]['role'],'part_id':pid,'panel_letter':panel_letter[pid],'source_chain_count':records[pid]['chain_count'],'source_length_aa':records[pid]['amino_acid_count']})
        T['activity'].write({'construct_id':cid,'panel_code':code,'expected_product_detected':detected,'product_topology':act['product_topology'],'linear_product_detected':act['linear_product_detected'],'cyclic_product_detected':act['cyclic_product_detected'],'activity_definition':'at least one expected linear or cyclic NRP detected by HR-LC-MS/MS','negative_label_interpretation':'expected product not detected; not proof of failed expression, splicing, or biochemical incompatibility','source':'Figure 3b and Results text'})
        counts['constructs']+=1;counts['proteins']+=len(mature_chains);counts['modules']+=len(modules);counts['domains']+=sum(len(m['domains']) for m in modules);counts['linkers']+=link_count;counts['chain_breaks']+=break_count;counts['splices']+=2
        activity_counts[act['product_topology']]+=1
    domain_pred.close()
    # representative products
    letter_to_part={v:k for k,v in panel_letter.items()}
    for num,code,titer,tstat in products:
        cid=f'BODE_{letter_to_part[code[0]]}_{letter_to_part[code[1]]}_{letter_to_part[code[2]]}'
        T['products'].write({'product_number':num,'construct_code':code,'construct_id':cid,'reported_titer_mg_L':titer,'titer_status':tstat,'structure_confirmed_by_synthetic_standard':True,'product_topology':activity[cid]['product_topology'],'coverage_note':'one of 14 representative confirmed products; full 258-product table requires Supplementary Table S7','source':'Figure 3c and Results text'})
    for digest,seq in sorted(unique_mature.items()):F['unique'].write(f'BODEUNIQ_{digest[:20]}|length={len(seq)}',seq)
    for x in T.values():x.close()
    for x in F.values():x.close()
    # qc
    expected_trans=counts['modules']-324
    qc={'dataset_version':'1.0','source_paper_doi':'10.1101/2025.10.02.680031','constructs':counts['constructs'],'assembly_lines':counts['constructs'],'mature_protein_occurrences':counts['proteins'],'unique_mature_protein_sequences':len(unique_mature),'modules':counts['modules'],'domains':counts['domains'],'engineered_xuti_splice_scars':counts['splices'],'inter_module_linker_candidates':counts['linkers'],'natural_interprotein_chain_breaks':counts['chain_breaks'],'expected_module_transitions':expected_trans,'accounted_module_transitions':counts['linkers']+counts['chain_breaks'],'constructs_one_chain':288,'constructs_two_chain_pIN269':36,'activity_topology_counts':dict(activity_counts),'active_constructs':173,'inactive_expected_product_not_detected':151,'module_count_distribution':dict(sorted(module_count_dist.items())),'mature_reconstruction_rule':'initiation + LNRSAV + elongation + SGYSSS + termination; pIN269 remains two chains','coordinate_convention':'0-based end-exclusive','product_level_coverage':'14 representative confirmed products only; Supplementary Table S7 needed for all 258 products'}
    assert expected_trans==qc['accounted_module_transitions'],qc
    assert activity_counts==Counter({'not_detected':151,'linear':127,'cyclic':25,'cyclic_and_linear':21}),activity_counts
    (OUT/'QC_SUMMARY.json').write_text(json.dumps(qc,indent=2),encoding='utf-8')
    readme=f'''# Bode split-intein NRPS validation dataset v1\n\nThis package converts the supplied Bode-lab SnapGene protein annotations and Figure 3 activity matrix into an antiSMASH-v3-compatible validation dataset.\n\n## Critical mature-sequence rule\n\nAll 324 library constructs use the XUTI `js insertion` strategy with two scars retained after trans-splicing:\n\n```text\ninitiation + LNRSAV + elongation + SGYSSS + termination\n```\n\n`LNRSAV` derives from gp41-8 (`LNR` + `SAV`) and `SGYSSS` from NrdJ-1 (`SGY` + `SSS`). The scars are intra-module A-to-T junctions, not natural inter-module linkers.\n\nThe 36 pIN269 constructs remain two-chain assembly lines and retain one natural FitA/FitB inter-protein chain break. No fake peptide bond was introduced.\n\n## Experimental labels\n\n- 324 constructs\n- 173 expected-product-positive\n- 151 expected product not detected\n- 127 linear only\n- 25 cyclic only\n- 21 both linear and cyclic\n\nA white cell means only that the expected product was not detected under the reported assay.\n\n## Core schema\n\nThe core TSV and FASTA filenames/columns match antiSMASH DB5 extractor v3. Validation-specific tables preserve parts, splice scars, source segments, donor provenance, and experimental labels.\n\n## Current limitation\n\nThe package contains the 14 representative chemically confirmed products from Figure 3c. Supplementary Table S7 is still required for all 258 product-level assignments; Supplementary Table S2 is desirable for authoritative donor metadata.\n\nCoordinates are 0-based, end-exclusive.\n'''
    (OUT/'README.md').write_text(readme,encoding='utf-8')
    # copy source spec and scripts
    shutil.copy2('/mnt/data/bode_validation_extraction_spec_v2/BODE_VALIDATION_EXTRACTION_SPEC.md',OUT/'BODE_VALIDATION_EXTRACTION_SPEC.md')
    shutil.copy2(__file__,OUT/'build_bode_nrps_validation_dataset_v1.py')
    # hashes
    lines=[]
    for p in sorted(OUT.iterdir()):
        if p.is_file() and p.name!='SHA256SUMS.txt':lines.append(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}')
    (OUT/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n')
    if ZIP.exists():ZIP.unlink()
    with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(OUT.iterdir()):z.write(p,p.name)
    print(json.dumps(qc,indent=2));print(ZIP)
if __name__=='__main__':main()
