# Bode split-intein NRPS validation dataset v1

This package converts the supplied Bode-lab SnapGene protein annotations and Figure 3 activity matrix into an antiSMASH-v3-compatible validation dataset.

## Critical mature-sequence rule

All 324 library constructs use the XUTI `js insertion` strategy with two scars retained after trans-splicing:

```text
initiation + LNRSAV + elongation + SGYSSS + termination
```

`LNRSAV` derives from gp41-8 (`LNR` + `SAV`) and `SGYSSS` from NrdJ-1 (`SGY` + `SSS`). The scars are intra-module A-to-T junctions, not natural inter-module linkers.

The 36 pIN269 constructs remain two-chain assembly lines and retain one natural FitA/FitB inter-protein chain break. No fake peptide bond was introduced.

## Experimental labels

- 324 constructs
- 173 expected-product-positive
- 151 expected product not detected
- 127 linear only
- 25 cyclic only
- 21 both linear and cyclic

A white cell means only that the expected product was not detected under the reported assay.

## Core schema

The core TSV and FASTA filenames/columns match antiSMASH DB5 extractor v3. Validation-specific tables preserve parts, splice scars, source segments, donor provenance, and experimental labels.

## Current limitation

The package contains the 14 representative chemically confirmed products from Figure 3c. Supplementary Table S7 is still required for all 258 product-level assignments; Supplementary Table S2 is desirable for authoritative donor metadata.

Coordinates are 0-based, end-exclusive.

## v1.1 source-provenance correction

`source_engineered_parts.fasta.gz` contains one record per real source protein
chain. In particular, pIN269 is represented by two separate source chains;
the internal FitA/FitB boundary is never collapsed into a fake peptide.

The complete 42-record source annotation layer is retained under files prefixed
with `source_all_` or `source_`.
