# Bode split-intein NRPS validation dataset: extraction specification v2

## Scope

This specification defines how to convert the Bode-lab split-intein NRPS files
and the 324-construct activity matrix into a validation dataset aligned with the
antiSMASH NRPS assembly-line schema.

The decisive correction relative to the preliminary Stage-1 reconstruction is
that the mature spliced proteins contain **two six-residue intein-derived
junction-sequence scars**. The raw `.prot` part sequences map to native NRPS
segments and do not themselves contain those mature scar residues.

## Paper-grounded junction chemistry

A split intein precursor has:

- upstream native extein
- three-residue N-extein junction sequence
- intein N fragment
- intein C fragment
- three-residue C-extein junction sequence
- downstream native extein

After trans-splicing, both intein fragments are excised and the mature protein is:

`native_left + left_js_triplet + right_js_triplet + native_right`

The six junction-sequence residues remain covalently incorporated into the
mature NRPS.

### Intein junction sequences

| Intein | Left js | Right js | Mature six-residue scar |
|---|---|---|---|
| gp41-1 | NPC | SEI | NPCSEI |
| gp41-8 | LNR | SAV | LNRSAV |
| NrdJ-1 | SGY | SSS | SGYSSS |
| IMPDH-1 | GGG | SIC | GGGSIC |
| SspGyrB | AGG | SAK | AGGSAK |

## Two construction strategies in the paper

### js insertion

- Delete zero native NRPS residues.
- Insert the six-residue scar.
- Mature protein is six residues longer per splice.
- The 324-member library uses this strategy exclusively.

### js replacement

- Delete six native NRPS residues at the splice site.
- Replace them with the six-residue scar.
- Mature protein length is unchanged.
- This strategy occurs in the initial XtpS benchmarking experiments, not in the
  324-member combinatorial library.

Exact replacement sequences for all benchmark constructs require the
supplementary construct maps or plasmid sequences; they must not be guessed from
the main article alone.

## 324-library reconstruction rule

All 324 constructs use:

- fusion site: `XUTI`
- splice strategy: `js_insertion`
- first split-intein pair: `gp41-8`
- second split-intein pair: `NrdJ-1`

Therefore the ordinary one-chain mature sequence is:

`initiation + LNRSAV + elongation + SGYSSS + termination`

Length rule:

`mature_length = initiation_length + elongation_length + termination_length + 12`

The previous direct-concatenation Stage-1 mature sequences must be superseded.

## pIN269 exception

pIN269 contains two natural protein chains separated by a native FitA/FitB
inter-protein boundary.

For each construct containing pIN269:

- Mature chain 1:
  `initiation + LNRSAV + pIN269_chain_1`
- Mature chain 2:
  `pIN269_chain_2 + SGYSSS + termination`

No peptide sequence may be invented across the FitA/FitB break.

These 36 constructs retain:

- two engineered covalent trans-splice scars
- one natural inter-protein chain break
- two mature protein chains

## Relationship to NRPS modules

The library is split at the XUTI site, which lies in an A-to-T linker.

Consequences:

1. Each engineered scar is an **intra-module A-to-T junction**, not an ordinary
   inter-module T-to-C linker.
2. The terminal partial module on the left part must be merged with the initial
   T-domain segment on the right part.
3. Each reconstructed module crossing a splice should contain:
   - upstream module segment
   - six-residue engineered scar
   - downstream module segment
4. The scar must not be placed in `inter_module_linkers.tsv.gz`.
5. It belongs in a separate engineered-junction table and FASTA.
6. Natural T-to-C inter-module linker candidates elsewhere in the mature chain
   should still be extracted normally.
7. Domain HMM sequences are unchanged; downstream mature-protein coordinates
   shift by six residues at each preceding splice.

## Coordinate rules

All amino-acid coordinates are zero-based, end-exclusive.

### Ordinary one-chain construct

Let:

- `Li` = initiation length
- `Le` = elongation length
- `Lt` = termination length

Mature layout:

- initiation: `[0, Li)`
- scar 1 `LNRSAV`: `[Li, Li+6)`
- elongation: `[Li+6, Li+6+Le)`
- scar 2 `SGYSSS`: `[Li+6+Le, Li+12+Le)`
- termination: `[Li+12+Le, Li+12+Le+Lt)`

### pIN269 two-chain construct

Let `Le1` and `Le2` be the two pIN269 chain lengths.

Chain 1:

- initiation: `[0, Li)`
- scar 1: `[Li, Li+6)`
- pIN269 chain 1: `[Li+6, Li+6+Le1)`

Chain 2:

- pIN269 chain 2: `[0, Le2)`
- scar 2: `[Le2, Le2+6)`
- termination: `[Le2+6, Le2+6+Lt)`

## Transition vocabulary

Use distinct labels:

- `natural_same_protein_inter_module_linker`
- `natural_inter_protein_chain_break`
- `engineered_covalent_trans_splice_xuti`
- `engineered_js_scar`
- `engineered_module_crossing_splice`
- `source_part_boundary_pre_splicing`

Do not label an XUTI scar as:

- a natural linker
- a docking interface
- an inter-module transition

## Required validation-specific tables

- `engineered_parts.tsv.gz`
- `engineered_constructs.tsv.gz`
- `construct_part_membership.tsv.gz`
- `mature_construct_chains.tsv.gz`
- `engineered_splice_junctions.tsv.gz`
- `engineered_splice_scars.tsv.gz`
- `engineered_module_segments.tsv.gz`
- `experimental_construct_activity.tsv.gz`
- `experimental_products.tsv.gz`
- `native_donor_mapping.tsv.gz`

## Core antiSMASH-compatible tables

- `assembly_lines.tsv.gz`
- `assembly_line_proteins.tsv.gz`
- `assembly_line_modules.tsv.gz`
- `assembly_line_transitions.tsv.gz`
- `proteins.tsv.gz`
- `modules.tsv.gz`
- `module_segments.tsv.gz`
- `domains.tsv.gz`
- `module_domains.tsv.gz`
- `inter_module_linkers.tsv.gz`
- `terminal_flanks.tsv.gz`
- `substrate_consensus.tsv.gz`

The engineered validation fields should supplement, not overwrite, the
antiSMASH-compatible fields.

## Experimental labels from the main article

Construct-level:

- total constructs: 324
- expected-product-positive constructs: 173
- expected-product-negative constructs: 151
- constructs producing at least one linear peptide: 148
- constructs producing at least one cyclic peptide: 46
- constructs producing both: 21
- linear-only: 127
- cyclic-only: 25

Product-level, according to the Results text:

- total identified NRPs: 258
- linear NRPs: 201
- cyclic NRPs: 57

The rendered Figure 3 panel appears to display `257 NRP found`, whereas the
Results and Discussion text report `258`. Preserve this discrepancy in
provenance and use Supplementary Table S7 as the final product-level authority.

The white matrix cells mean:

`expected_product_not_detected`

They do not prove:

- failed expression
- failed trans-splicing
- biochemical incompatibility
- complete enzymatic inactivity

## Validation and machine-learning cautions

1. The 324 constructs are combinatorial reuse of only 21 parts. They are not
   324 independent sequence families.
2. Keep the complete Bode library out of natural-data training; use it as an
   external engineered validation set.
3. A construct outcome depends on two engineered XUTI splice junctions and the
   full assembly-line context.
4. Do not assign a negative construct label independently to both splice
   junctions as hard pair-level negatives. That is only weak supervision.
5. The 36 pIN269 constructs form a separate subgroup because they also contain
   a natural inter-protein interface.
6. Modules E, M, N, and U can yield multiple substrate/product variants, so
   one active construct can correspond to more than one NRP.
7. Product identities and intensities for the full library require
   Supplementary Table S7.
8. The two-system LC-MS agreement data require Supplementary Figure S6 or its
   source table.
9. Exact native module/donor metadata should be checked against Supplementary
   Table S2.

## Readiness status

Ready from current files:

- all 21 part sequences
- 324 construct combinations
- part-local antiSMASH modules/domains
- corrected mature sequence reconstruction rules
- exact two scar sequences used by the library
- construct-level product-detection matrix
- representative 14-product mapping from Figure 3
- pIN269 two-chain handling

Still required for a complete product-level validation release:

- Supplementary Table S7
- Supplementary Table S2
- source data for Figure S6, if replicate/system agreement is needed
- exact antiSMASH-v3 production table headers or extractor snapshot for strict
  byte-compatible schema reproduction
