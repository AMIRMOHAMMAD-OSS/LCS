#!/usr/bin/env python3
import argparse
import gzip
import json
from pathlib import Path

def load_json(path: Path):
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        return json.load(handle)

def main():
    parser = argparse.ArgumentParser(
        description="Print antiSMASH NRPS/PKS module components and coordinates."
    )
    parser.add_argument("json_file", type=Path)
    args = parser.parse_args()

    data = load_json(args.json_file)

    print(f"antiSMASH version: {data.get('version')}")
    print(f"schema: {data.get('schema')}")

    for record in data.get("records", []):
        print("\n" + "=" * 90)
        print(f"RECORD {record.get('id')}")

        software = record.get("modules", {})
        detection = software.get("antismash.detection.nrps_pks_domains", {})
        cds_results = detection.get("cds_results", {}) if isinstance(detection, dict) else {}

        prediction_block = software.get("antismash.modules.nrps_pks", {})
        consensus = prediction_block.get("consensus", {}) if isinstance(prediction_block, dict) else {}

        for cds_name, result in sorted(cds_results.items()):
            if not isinstance(result, dict):
                continue

            modules = result.get("modules", [])
            if not modules:
                continue

            print("\n" + "-" * 90)
            print(f"CDS: {cds_name}")
            print(f"Module count: {len(modules)}")

            for module_index, module in enumerate(modules, start=1):
                print(f"\n  MODULE {module_index}")
                print(f"    first_in_cds: {module.get('first_in_cds')}")
                components = module.get("components", [])
                print(f"    component_count: {len(components)}")

                for component_index, component in enumerate(components, start=1):
                    if not isinstance(component, dict):
                        print(f"      {component_index}. {component!r}")
                        continue

                    label = (
                        component.get("name")
                        or component.get("type")
                        or component.get("domain")
                        or component.get("label")
                        or "?"
                    )
                    start = component.get("start", component.get("protein_start", "?"))
                    end = component.get("end", component.get("protein_end", "?"))
                    locus = component.get("locus", cds_name)
                    subtype = component.get("subtype")
                    active = component.get("active")
                    domain_id = component.get("domain_id", component.get("id", ""))

                    extras = []
                    if subtype not in ("", None):
                        extras.append(f"subtype={subtype}")
                    if active not in ("", None):
                        extras.append(f"active={active}")
                    if domain_id:
                        extras.append(f"id={domain_id}")
                    extra_text = "; " + ", ".join(extras) if extras else ""

                    print(
                        f"      {component_index}. {label} "
                        f"[{start}:{end}] locus={locus}{extra_text}"
                    )

                    # Print unrecognized fields to expose the schema cleanly.
                    known = {
                        "name", "type", "domain", "label",
                        "start", "end", "protein_start", "protein_end",
                        "locus", "subtype", "active", "domain_id", "id"
                    }
                    extra_keys = [k for k in component.keys() if k not in known]
                    if extra_keys:
                        print(f"         other_fields: {extra_keys}")

            matching = {
                key: value
                for key, value in consensus.items()
                if cds_name in str(key) or cds_name in str(value)
            }
            if matching:
                print("\n  CONSENSUS")
                for key, value in matching.items():
                    print(f"    {key}: {value}")

if __name__ == "__main__":
    main()
