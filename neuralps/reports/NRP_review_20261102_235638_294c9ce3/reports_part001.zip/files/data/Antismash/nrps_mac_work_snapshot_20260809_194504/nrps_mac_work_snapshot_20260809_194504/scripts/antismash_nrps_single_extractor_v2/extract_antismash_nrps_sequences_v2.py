#!/usr/bin/env python3
"""
Extract protein, module, domain, and linker-candidate sequences from one
antiSMASH JSON/JSON.GZ result.

Compatible with antiSMASH schema 4 records where module components may be stored
as wrapper objects such as:

    {"domain": {"hit_id": "...", "query_start": 10, "query_end": 100},
     "locus": "CDS_NAME"}

Coordinates are treated as 0-based, end-exclusive amino-acid coordinates.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import re
from pathlib import Path
from typing import Any


def load_json(path: Path) -> dict[str, Any]:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        return json.load(handle)


def first(value: Any, default: str = "") -> str:
    return str(value[0]) if isinstance(value, list) and value else default


def clean_sequence(value: str) -> str:
    return re.sub(r"[^A-Za-z*]", "", value).upper().rstrip("*")


def wrap_fasta(sequence: str, width: int = 80) -> str:
    return "\n".join(sequence[i:i + width] for i in range(0, len(sequence), width))


def write_tsv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def parse_feature_location(text: Any) -> tuple[int | None, int | None, int]:
    raw = str(text)
    match = re.search(r"\[(\d+):(\d+)\]", raw)
    if not match:
        return None, None, 0
    strand = -1 if raw.endswith("(-)") else 1 if raw.endswith("(+)") else 0
    return int(match.group(1)), int(match.group(2)), strand


def nrps_consensus_for_cds(consensus: dict[str, Any], cds_name: str) -> dict[int, str]:
    pattern = re.compile(
        rf"^nrpspksdomains_{re.escape(cds_name)}_AMP-binding\.(\d+)$"
    )
    result: dict[int, str] = {}
    for key, value in consensus.items():
        match = pattern.match(str(key))
        if match:
            result[int(match.group(1))] = str(value)
    return result


def normalize_component(raw: Any, cds_name: str) -> dict[str, Any] | None:
    """
    Return a flat domain component.

    antiSMASH schema 4 can store a component as:
        {"domain": {...domain hit...}, "locus": "..."}
    Older/other outputs can store the hit directly.
    """
    if not isinstance(raw, dict):
        return None

    if isinstance(raw.get("domain"), dict):
        component = dict(raw["domain"])
        component.setdefault("locus", raw.get("locus", cds_name))
        for key in ("active", "subtype", "type"):
            if key in raw and key not in component:
                component[key] = raw[key]
    else:
        component = dict(raw)
        component.setdefault("locus", cds_name)

    if "query_start" not in component or "query_end" not in component:
        return None

    try:
        component["query_start"] = int(component["query_start"])
        component["query_end"] = int(component["query_end"])
    except (TypeError, ValueError):
        return None

    return component


def normalized_components(module: dict[str, Any], cds_name: str) -> list[dict[str, Any]]:
    components: list[dict[str, Any]] = []
    for raw in module.get("components", []):
        component = normalize_component(raw, cds_name)
        if component is not None:
            components.append(component)
    components.sort(key=lambda c: (c["query_start"], c["query_end"]))
    return components


def is_loader(hit_id: str) -> bool:
    return (
        "AMP-binding" in hit_id
        or hit_id in {
            "A-OX", "CAL_domain", "PKS_AT", "PKS_AT2",
            "AT", "CoA-ligase"
        }
    )


def is_carrier(hit_id: str) -> bool:
    return hit_id in {"PCP", "PP-binding", "ACP", "ACP_beta", "ACP-like"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_json", type=Path)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    data = load_json(args.input_json)

    protein_rows: list[dict[str, Any]] = []
    module_rows: list[dict[str, Any]] = []
    domain_rows: list[dict[str, Any]] = []
    internal_gap_rows: list[dict[str, Any]] = []
    linker_rows: list[dict[str, Any]] = []
    flank_rows: list[dict[str, Any]] = []

    proteins_fa: list[str] = []
    modules_fa: list[str] = []
    domains_fa: list[str] = []
    linkers_fa: list[str] = []
    gaps_fa: list[str] = []
    flanks_fa: list[str] = []

    qc: dict[str, Any] = {
        "input_file": str(args.input_json),
        "antismash_version": data.get("version"),
        "schema": data.get("schema"),
        "records_seen": 0,
        "proteins_with_modules": 0,
        "modules": 0,
        "domains": 0,
        "inter_module_linker_candidates": 0,
        "inter_component_gaps": 0,
        "terminal_flanks": 0,
        "wrapped_domain_components_unwrapped": 0,
        "non_domain_components_skipped": 0,
        "missing_cds_translation": [],
        "coordinate_warnings": [],
    }

    for record in data.get("records", []):
        qc["records_seen"] += 1
        record_id = str(record.get("id", ""))

        cds_by_alias: dict[str, dict[str, Any]] = {}
        for feature in record.get("features", []):
            if feature.get("type") != "CDS":
                continue
            qualifiers = feature.get("qualifiers", {})
            locus_tag = first(qualifiers.get("locus_tag"))
            gene = first(qualifiers.get("gene"))
            protein_id = first(qualifiers.get("protein_id"))
            translation = clean_sequence(first(qualifiers.get("translation")))
            start_nt, end_nt, strand = parse_feature_location(feature.get("location"))
            entry = {
                "locus_tag": locus_tag,
                "gene": gene,
                "protein_id": protein_id,
                "translation": translation,
                "start_nt": start_nt,
                "end_nt": end_nt,
                "strand": strand,
                "product": first(qualifiers.get("product")),
            }
            for alias in {locus_tag, gene, protein_id}:
                if alias:
                    cds_by_alias.setdefault(alias, entry)

        software = record.get("modules", {})
        detection = software.get("antismash.detection.nrps_pks_domains", {})
        cds_results = detection.get("cds_results", {}) if isinstance(detection, dict) else {}

        predictions = software.get("antismash.modules.nrps_pks", {})
        consensus = predictions.get("consensus", {}) if isinstance(predictions, dict) else {}

        for cds_name, result in sorted(cds_results.items()):
            if not isinstance(result, dict):
                continue
            raw_modules = result.get("modules", [])
            if not raw_modules:
                continue

            cds = cds_by_alias.get(cds_name)
            if not cds or not cds.get("translation"):
                qc["missing_cds_translation"].append({
                    "record_id": record_id,
                    "cds_name": cds_name,
                })
                continue

            sequence = str(cds["translation"])
            protein_len = len(sequence)
            amp_consensus = nrps_consensus_for_cds(consensus, cds_name)
            amp_counter = 0
            valid_modules: list[dict[str, Any]] = []

            for raw_module in raw_modules:
                if not isinstance(raw_module, dict):
                    continue
                for raw_component in raw_module.get("components", []):
                    if isinstance(raw_component, dict) and isinstance(raw_component.get("domain"), dict):
                        qc["wrapped_domain_components_unwrapped"] += 1

                components = normalized_components(raw_module, cds_name)
                skipped = len(raw_module.get("components", [])) - len(components)
                if skipped > 0:
                    qc["non_domain_components_skipped"] += skipped
                if components:
                    valid_modules.append({
                        "raw_module": raw_module,
                        "components": components,
                    })

            if not valid_modules:
                continue

            qc["proteins_with_modules"] += 1
            protein_rows.append({
                "record_id": record_id,
                "cds_name": cds_name,
                "locus_tag": cds.get("locus_tag", ""),
                "gene": cds.get("gene", ""),
                "protein_id": cds.get("protein_id", ""),
                "product": cds.get("product", ""),
                "start_nt_0based": cds.get("start_nt", ""),
                "end_nt_0based_exclusive": cds.get("end_nt", ""),
                "strand": cds.get("strand", ""),
                "length_aa": protein_len,
                "module_count": len(valid_modules),
            })
            proteins_fa.append(
                f">{record_id}|{cds_name}|full_protein|length={protein_len}\n"
                f"{wrap_fasta(sequence)}"
            )

            normalized_module_spans: list[dict[str, Any]] = []

            for module_index, item in enumerate(valid_modules, start=1):
                raw_module = item["raw_module"]
                components = item["components"]
                start = min(c["query_start"] for c in components)
                end = max(c["query_end"] for c in components)

                if start < 0 or end > protein_len or end <= start:
                    qc["coordinate_warnings"].append({
                        "record_id": record_id,
                        "cds_name": cds_name,
                        "module_index": module_index,
                        "start": start,
                        "end": end,
                        "protein_len": protein_len,
                    })
                    continue

                architecture = "->".join(
                    str(c.get("hit_id", "?")) for c in components
                )
                has_loader = any(is_loader(str(c.get("hit_id", ""))) for c in components)
                has_carrier = any(is_carrier(str(c.get("hit_id", ""))) for c in components)
                operational_complete = has_loader and has_carrier
                module_sequence = sequence[start:end]

                module_rows.append({
                    "record_id": record_id,
                    "cds_name": cds_name,
                    "module_index": module_index,
                    "first_in_cds": raw_module.get("first_in_cds", ""),
                    "start_aa_0based": start,
                    "end_aa_0based_exclusive": end,
                    "length_aa": end - start,
                    "component_count": len(components),
                    "component_architecture": architecture,
                    "has_loader": has_loader,
                    "has_carrier": has_carrier,
                    "operational_complete": operational_complete,
                    "sequence": module_sequence,
                })
                modules_fa.append(
                    f">{record_id}|{cds_name}|module={module_index}|"
                    f"coords={start}:{end}|complete={operational_complete}\n"
                    f"{wrap_fasta(module_sequence)}"
                )
                qc["modules"] += 1

                for component_index, component in enumerate(components, start=1):
                    hit_id = str(component.get("hit_id", "?"))
                    dstart = int(component["query_start"])
                    dend = int(component["query_end"])

                    if dstart < 0 or dend > protein_len or dend <= dstart:
                        qc["coordinate_warnings"].append({
                            "record_id": record_id,
                            "cds_name": cds_name,
                            "module_index": module_index,
                            "component_index": component_index,
                            "hit_id": hit_id,
                            "start": dstart,
                            "end": dend,
                            "protein_len": protein_len,
                        })
                        continue

                    predicted_monomer = ""
                    if "AMP-binding" in hit_id:
                        amp_counter += 1
                        predicted_monomer = amp_consensus.get(amp_counter, "")

                    domain_sequence = sequence[dstart:dend]
                    domain_rows.append({
                        "record_id": record_id,
                        "cds_name": cds_name,
                        "module_index": module_index,
                        "component_index": component_index,
                        "hit_id": hit_id,
                        "start_aa_0based": dstart,
                        "end_aa_0based_exclusive": dend,
                        "length_aa": dend - dstart,
                        "evalue": component.get("evalue", ""),
                        "bitscore": component.get("bitscore", ""),
                        "predicted_monomer_consensus": predicted_monomer,
                        "sequence": domain_sequence,
                    })
                    domains_fa.append(
                        f">{record_id}|{cds_name}|module={module_index}|"
                        f"component={component_index}|{hit_id}|"
                        f"coords={dstart}:{dend}|monomer={predicted_monomer or '-'}\n"
                        f"{wrap_fasta(domain_sequence)}"
                    )
                    qc["domains"] += 1

                for left, right in zip(components, components[1:]):
                    gap_start = int(left["query_end"])
                    gap_end = int(right["query_start"])
                    if gap_end < gap_start:
                        continue
                    gap_sequence = sequence[gap_start:gap_end]
                    internal_gap_rows.append({
                        "record_id": record_id,
                        "cds_name": cds_name,
                        "module_index": module_index,
                        "left_component": left.get("hit_id", ""),
                        "right_component": right.get("hit_id", ""),
                        "start_aa_0based": gap_start,
                        "end_aa_0based_exclusive": gap_end,
                        "length_aa": gap_end - gap_start,
                        "interpretation": "inter_component_gap_not_validated_linker",
                        "sequence": gap_sequence,
                    })
                    gaps_fa.append(
                        f">{record_id}|{cds_name}|module={module_index}|"
                        f"gap={left.get('hit_id','?')}__{right.get('hit_id','?')}|"
                        f"coords={gap_start}:{gap_end}|NOT_VALIDATED_LINKER\n"
                        f"{wrap_fasta(gap_sequence)}"
                    )
                    qc["inter_component_gaps"] += 1

                normalized_module_spans.append({
                    "index": module_index,
                    "start": start,
                    "end": end,
                    "components": components,
                })

            normalized_module_spans.sort(key=lambda x: (x["start"], x["end"]))

            for left, right in zip(normalized_module_spans, normalized_module_spans[1:]):
                linker_start = left["end"]
                linker_end = right["start"]
                if linker_end < linker_start:
                    qc["coordinate_warnings"].append({
                        "record_id": record_id,
                        "cds_name": cds_name,
                        "left_module": left["index"],
                        "right_module": right["index"],
                        "warning": "overlapping_module_spans",
                        "left_end": linker_start,
                        "right_start": linker_end,
                    })
                    continue

                linker_sequence = sequence[linker_start:linker_end]
                linker_rows.append({
                    "record_id": record_id,
                    "cds_name": cds_name,
                    "left_module_index": left["index"],
                    "right_module_index": right["index"],
                    "start_aa_0based": linker_start,
                    "end_aa_0based_exclusive": linker_end,
                    "length_aa": linker_end - linker_start,
                    "left_terminal_component": left["components"][-1].get("hit_id", ""),
                    "right_initial_component": right["components"][0].get("hit_id", ""),
                    "interpretation": "inter_module_linker_candidate",
                    "sequence": linker_sequence,
                })
                linkers_fa.append(
                    f">{record_id}|{cds_name}|modules={left['index']}__{right['index']}|"
                    f"coords={linker_start}:{linker_end}|inter_module_linker_candidate\n"
                    f"{wrap_fasta(linker_sequence)}"
                )
                qc["inter_module_linker_candidates"] += 1

            if normalized_module_spans:
                first_start = normalized_module_spans[0]["start"]
                last_end = normalized_module_spans[-1]["end"]
                for flank_type, flank_start, flank_end in (
                    ("n_terminal_flank", 0, first_start),
                    ("c_terminal_flank", last_end, protein_len),
                ):
                    flank_sequence = sequence[flank_start:flank_end]
                    flank_rows.append({
                        "record_id": record_id,
                        "cds_name": cds_name,
                        "flank_type": flank_type,
                        "start_aa_0based": flank_start,
                        "end_aa_0based_exclusive": flank_end,
                        "length_aa": flank_end - flank_start,
                        "sequence": flank_sequence,
                    })
                    flanks_fa.append(
                        f">{record_id}|{cds_name}|{flank_type}|"
                        f"coords={flank_start}:{flank_end}\n"
                        f"{wrap_fasta(flank_sequence)}"
                    )
                    qc["terminal_flanks"] += 1

    write_tsv(
        args.out_dir / "proteins.tsv", protein_rows,
        [
            "record_id", "cds_name", "locus_tag", "gene", "protein_id",
            "product", "start_nt_0based", "end_nt_0based_exclusive",
            "strand", "length_aa", "module_count",
        ],
    )
    write_tsv(
        args.out_dir / "modules.tsv", module_rows,
        [
            "record_id", "cds_name", "module_index", "first_in_cds",
            "start_aa_0based", "end_aa_0based_exclusive", "length_aa",
            "component_count", "component_architecture", "has_loader",
            "has_carrier", "operational_complete", "sequence",
        ],
    )
    write_tsv(
        args.out_dir / "domains.tsv", domain_rows,
        [
            "record_id", "cds_name", "module_index", "component_index",
            "hit_id", "start_aa_0based", "end_aa_0based_exclusive",
            "length_aa", "evalue", "bitscore",
            "predicted_monomer_consensus", "sequence",
        ],
    )
    write_tsv(
        args.out_dir / "inter_component_gaps.tsv", internal_gap_rows,
        [
            "record_id", "cds_name", "module_index", "left_component",
            "right_component", "start_aa_0based",
            "end_aa_0based_exclusive", "length_aa",
            "interpretation", "sequence",
        ],
    )
    write_tsv(
        args.out_dir / "inter_module_linkers.tsv", linker_rows,
        [
            "record_id", "cds_name", "left_module_index",
            "right_module_index", "start_aa_0based",
            "end_aa_0based_exclusive", "length_aa",
            "left_terminal_component", "right_initial_component",
            "interpretation", "sequence",
        ],
    )
    write_tsv(
        args.out_dir / "terminal_flanks.tsv", flank_rows,
        [
            "record_id", "cds_name", "flank_type",
            "start_aa_0based", "end_aa_0based_exclusive",
            "length_aa", "sequence",
        ],
    )

    fasta_outputs = {
        "proteins.fasta": proteins_fa,
        "modules.fasta": modules_fa,
        "domains.fasta": domains_fa,
        "inter_module_linkers.fasta": linkers_fa,
        "inter_component_gaps.fasta": gaps_fa,
        "terminal_flanks.fasta": flanks_fa,
    }
    for filename, entries in fasta_outputs.items():
        (args.out_dir / filename).write_text(
            ("\n".join(entries) + "\n") if entries else "",
            encoding="utf-8",
        )

    (args.out_dir / "qc_summary.json").write_text(
        json.dumps(qc, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print(json.dumps(qc, indent=2, ensure_ascii=False))
    print(f"\nOutputs: {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
