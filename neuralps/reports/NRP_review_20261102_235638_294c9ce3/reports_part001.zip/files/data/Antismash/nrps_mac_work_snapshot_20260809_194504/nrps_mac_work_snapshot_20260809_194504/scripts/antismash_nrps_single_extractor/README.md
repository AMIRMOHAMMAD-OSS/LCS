# antiSMASH single-record NRPS sequence extractor

Run:

```bash
python3 extract_antismash_nrps_sequences.py \
  test_extract/asdb5_jsons/GCF_000024185.1.json.gz \
  --out-dir /tmp/GCF_000024185_nrps
```

Inspect:

```bash
cat /tmp/GCF_000024185_nrps/qc_summary.json
column -t -s $'\t' /tmp/GCF_000024185_nrps/inter_module_linkers.tsv
```

Important interpretation:

- `inter_module_linkers.tsv` contains candidate same-chain inter-module linker
  intervals.
- `inter_component_gaps.tsv` must not automatically be called linker data;
  domain HMM hits often cover only conserved cores.
- Proteins are kept separate. No artificial sequence is inserted between genes.
