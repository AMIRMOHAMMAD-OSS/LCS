#!/usr/bin/env python3
"""
Extract NRPS/PKS protein, domain, module, and linker-candidate sequences
from one antiSMASH JSON or JSON.GZ result.

Coordinate convention used:
  query_start/query_end are treated as Python-style 0-based, end-exclusive
  amino-acid coordinates. This is consistent with the inspected antiSMASH
  record where (query_end - query_start) equals the translated genomic span.

Important:
  - "inter_module_linker_candidate" is the sequence between the last detected
    component of one module and the first detected component of the next module
    on the SAME protein.
  - "inter_component_gap" is not automatically a biological linker. HMM hits
    often cover only conserved cores, so these gaps can include undetected
    portions of structured domains.
  - Separate proteins are never concatenated into an artificial sequence.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import re
from pathlib import Path
from typing import Any, Iterable


def load_json(path: Path) -> dict[str, Any]:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        return json.load(handle)


def first(value: Any, default: str = "") -> str:
    return str(value[0]) if isinstance(value, list) and value else default


def clean_sequence(value: str) -> str:
    return re.sub(r"[^A-Za-z*]", "", value).upper().rstrip("*")


def wrap_fasta(sequence: str, width: int = 80) -> str:
    return "\n".join(sequence[i:i+width] for i in range(0, len(sequence), width))


def write_tsv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def parse_feature_location(text: Any) -> tuple[int | None, int | None, int]:
    raw = str(text)
    match = re.search(r"\[(\d+):(\d+)\]", raw)
    if not match:
        return None, None, 0
    strand = -1 if raw.endswith("(-)") else 1 if raw.endswith("(+)") else 0
    return int(match.group(1)), int(match.group(2)), strand


def nrps_consensus_for_cds(
    consensus: dict[str, Any], cds_name: str
) -> dict[int, str]:
    """Map sequential AMP-binding index -> consensus monomer."""
    pattern = re.compile(
        rf"^nrpspksdomains_{re.escape(cds_name)}_AMP-binding\.(\d+)$"
    )
    result: dict[int, str] = {}
    for key, value in consensus.items():
        match = pattern.match(str(key))
        if match:
            result[int(match.group(1))] = str(value)
    return result


def module_span(module: dict[str, Any]) -> tuple[int, int]:
    components = module.get("components", [])
    starts = [int(c["query_start"]) for c in components if "query_start" in c]
    ends = [int(c["query_end"]) for c in components if "query_end" in c]
    if not starts or not ends:
        raise ValueError("Module has no component coordinates")
    return min(starts), max(ends)


def is_loader(hit_id: str) -> bool:
    return hit_id in {
        "AMP-binding", "A-OX", "CAL_domain", "PKS_AT",
        "PKS_AT2", "AT", "CoA-ligase"
    } or "AMP-binding" in hit_id


def is_carrier(hit_id: str) -> bool:
    return hit_id in {"PCP", "PP-binding", "ACP", "ACP_beta", "ACP-like"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_json", type=Path)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    data = load_json(args.input_json)

    protein_rows: list[dict[str, Any]] = []
    module_rows: list[dict[str, Any]] = []
    domain_rows: list[dict[str, Any]] = []
    internal_gap_rows: list[dict[str, Any]] = []
    linker_rows: list[dict[str, Any]] = []
    flank_rows: list[dict[str, Any]] = []

    proteins_fa: list[str] = []
    modules_fa: list[str] = []
    domains_fa: list[str] = []
    linkers_fa: list[str] = []
    gaps_fa: list[str] = []
    flanks_fa: list[str] = []

    qc = {
        "input_file": str(args.input_json),
        "antismash_version": data.get("version"),
        "schema": data.get("schema"),
        "records_seen": 0,
        "proteins_with_modules": 0,
        "modules": 0,
        "domains": 0,
        "inter_module_linker_candidates": 0,
        "inter_component_gaps": 0,
        "terminal_flanks": 0,
        "missing_cds_translation": [],
        "coordinate_warnings": [],
    }

    for record in data.get("records", []):
        qc["records_seen"] += 1
        record_id = str(record.get("id", ""))

        # Map locus tags and other aliases to CDS translations.
        cds_by_alias: dict[str, dict[str, Any]] = {}
        for feature in record.get("features", []):
            if feature.get("type") != "CDS":
                continue
            q = feature.get("qualifiers", {})
            locus_tag = first(q.get("locus_tag"))
            gene = first(q.get("gene"))
            protein_id = first(q.get("protein_id"))
            translation = clean_sequence(first(q.get("translation")))
            start_nt, end_nt, strand = parse_feature_location(feature.get("location"))
            entry = {
                "locus_tag": locus_tag,
                "gene": gene,
                "protein_id": protein_id,
                "translation": translation,
                "start_nt": start_nt,
                "end_nt": end_nt,
                "strand": strand,
                "product": first(q.get("product")),
            }
            for alias in {locus_tag, gene, protein_id}:
                if alias:
                    cds_by_alias.setdefault(alias, entry)

        software = record.get("modules", {})
        detection = software.get("antismash.detection.nrps_pks_domains", {})
        cds_results = detection.get("cds_results", {}) if isinstance(detection, dict) else {}

        predictions = software.get("antismash.modules.nrps_pks", {})
        consensus = predictions.get("consensus", {}) if isinstance(predictions, dict) else {}

        for cds_name, result in sorted(cds_results.items()):
            if not isinstance(result, dict):
                continue
            modules = result.get("modules", [])
            if not modules:
                continue

            cds = cds_by_alias.get(cds_name)
            if not cds or not cds.get("translation"):
                qc["missing_cds_translation"].append(
                    {"record_id": record_id, "cds_name": cds_name}
                )
                continue

            sequence = str(cds["translation"])
            protein_len = len(sequence)
            qc["proteins_with_modules"] += 1
            amp_consensus = nrps_consensus_for_cds(consensus, cds_name)
            amp_counter = 0

            protein_rows.append({
                "record_id": record_id,
                "cds_name": cds_name,
                "locus_tag": cds.get("locus_tag", ""),
                "gene": cds.get("gene", ""),
                "protein_id": cds.get("protein_id", ""),
                "product": cds.get("product", ""),
                "start_nt_0based": cds.get("start_nt", ""),
                "end_nt_0based_exclusive": cds.get("end_nt", ""),
                "strand": cds.get("strand", ""),
                "length_aa": protein_len,
                "module_count": len(modules),
            })
            proteins_fa.append(
                f">{record_id}|{cds_name}|full_protein|length={protein_len}\n"
                f"{wrap_fasta(sequence)}"
            )

            normalized_modules: list[dict[str, Any]] = []
            for module_index, module in enumerate(modules, start=1):
                components = [
                    c for c in module.get("components", [])
                    if isinstance(c, dict)
                    and "query_start" in c
                    and "query_end" in c
                ]
                components.sort(
                    key=lambda c: (int(c["query_start"]), int(c["query_end"]))
                )
                if not components:
                    continue

                start, end = module_span(module)
                if start < 0 or end > protein_len or end <= start:
                    qc["coordinate_warnings"].append({
                        "record_id": record_id,
                        "cds_name": cds_name,
                        "module_index": module_index,
                        "start": start,
                        "end": end,
                        "protein_len": protein_len,
                    })
                    continue

                has_loader = any(is_loader(str(c.get("hit_id", ""))) for c in components)
                has_carrier = any(is_carrier(str(c.get("hit_id", ""))) for c in components)
                operational_complete = has_loader and has_carrier
                module_sequence = sequence[start:end]

                module_rows.append({
                    "record_id": record_id,
                    "cds_name": cds_name,
                    "module_index": module_index,
                    "first_in_cds": module.get("first_in_cds", ""),
                    "start_aa_0based": start,
                    "end_aa_0based_exclusive": end,
                    "length_aa": end - start,
                    "component_count": len(components),
                    "component_architecture": "->".join(
                        str(c.get("hit_id", "?")) for c in components
                    ),
                    "has_loader": has_loader,
                    "has_carrier": has_carrier,
                    "operational_complete": operational_complete,
                    "sequence": module_sequence,
                })
                modules_fa.append(
                    f">{record_id}|{cds_name}|module={module_index}|"
                    f"coords={start}:{end}|complete={operational_complete}\n"
                    f"{wrap_fasta(module_sequence)}"
                )
                qc["modules"] += 1

                for component_index, component in enumerate(components, start=1):
                    hit_id = str(component.get("hit_id", "?"))
                    dstart = int(component["query_start"])
                    dend = int(component["query_end"])
                    if dstart < 0 or dend > protein_len or dend <= dstart:
                        qc["coordinate_warnings"].append({
                            "record_id": record_id,
                            "cds_name": cds_name,
                            "module_index": module_index,
                            "component_index": component_index,
                            "hit_id": hit_id,
                            "start": dstart,
                            "end": dend,
                            "protein_len": protein_len,
                        })
                        continue

                    predicted_monomer = ""
                    if "AMP-binding" in hit_id:
                        amp_counter += 1
                        predicted_monomer = amp_consensus.get(amp_counter, "")

                    domain_sequence = sequence[dstart:dend]
                    domain_rows.append({
                        "record_id": record_id,
                        "cds_name": cds_name,
                        "module_index": module_index,
                        "component_index": component_index,
                        "hit_id": hit_id,
                        "start_aa_0based": dstart,
                        "end_aa_0based_exclusive": dend,
                        "length_aa": dend - dstart,
                        "evalue": component.get("evalue", ""),
                        "bitscore": component.get("bitscore", ""),
                        "predicted_monomer_consensus": predicted_monomer,
                        "sequence": domain_sequence,
                    })
                    domains_fa.append(
                        f">{record_id}|{cds_name}|module={module_index}|"
                        f"component={component_index}|{hit_id}|"
                        f"coords={dstart}:{dend}|monomer={predicted_monomer or '-'}\n"
                        f"{wrap_fasta(domain_sequence)}"
                    )
                    qc["domains"] += 1

                # Gaps inside a module: report conservatively, not as true linkers.
                for left, right in zip(components, components[1:]):
                    gstart = int(left["query_end"])
                    gend = int(right["query_start"])
                    if gend < gstart:
                        continue
                    gap_sequence = sequence[gstart:gend]
                    internal_gap_rows.append({
                        "record_id": record_id,
                        "cds_name": cds_name,
                        "module_index": module_index,
                        "left_component": left.get("hit_id", ""),
                        "right_component": right.get("hit_id", ""),
                        "start_aa_0based": gstart,
                        "end_aa_0based_exclusive": gend,
                        "length_aa": gend - gstart,
                        "interpretation": "inter_component_gap_not_validated_linker",
                        "sequence": gap_sequence,
                    })
                    gaps_fa.append(
                        f">{record_id}|{cds_name}|module={module_index}|"
                        f"gap={left.get('hit_id','?')}__{right.get('hit_id','?')}|"
                        f"coords={gstart}:{gend}|NOT_VALIDATED_LINKER\n"
                        f"{wrap_fasta(gap_sequence)}"
                    )
                    qc["inter_component_gaps"] += 1

                normalized_modules.append({
                    "index": module_index,
                    "start": start,
                    "end": end,
                    "components": components,
                })

            # True candidate inter-module gaps on the same translated protein.
            normalized_modules.sort(key=lambda m: (m["start"], m["end"]))
            for left, right in zip(normalized_modules, normalized_modules[1:]):
                lstart = left["end"]
                lend = right["start"]
                if lend < lstart:
                    qc["coordinate_warnings"].append({
                        "record_id": record_id,
                        "cds_name": cds_name,
                        "left_module": left["index"],
                        "right_module": right["index"],
                        "warning": "overlapping_module_spans",
                        "left_end": lstart,
                        "right_start": lend,
                    })
                    continue
                linker_sequence = sequence[lstart:lend]
                linker_rows.append({
                    "record_id": record_id,
                    "cds_name": cds_name,
                    "left_module_index": left["index"],
                    "right_module_index": right["index"],
                    "start_aa_0based": lstart,
                    "end_aa_0based_exclusive": lend,
                    "length_aa": lend - lstart,
                    "left_terminal_component": left["components"][-1].get("hit_id", ""),
                    "right_initial_component": right["components"][0].get("hit_id", ""),
                    "interpretation": "inter_module_linker_candidate",
                    "sequence": linker_sequence,
                })
                linkers_fa.append(
                    f">{record_id}|{cds_name}|modules={left['index']}__{right['index']}|"
                    f"coords={lstart}:{lend}|inter_module_linker_candidate\n"
                    f"{wrap_fasta(linker_sequence)}"
                )
                qc["inter_module_linker_candidates"] += 1

            if normalized_modules:
                first_start = normalized_modules[0]["start"]
                last_end = normalized_modules[-1]["end"]

                for flank_type, fstart, fend in [
                    ("n_terminal_flank", 0, first_start),
                    ("c_terminal_flank", last_end, protein_len),
                ]:
                    flank_seq = sequence[fstart:fend]
                    flank_rows.append({
                        "record_id": record_id,
                        "cds_name": cds_name,
                        "flank_type": flank_type,
                        "start_aa_0based": fstart,
                        "end_aa_0based_exclusive": fend,
                        "length_aa": fend - fstart,
                        "sequence": flank_seq,
                    })
                    flanks_fa.append(
                        f">{record_id}|{cds_name}|{flank_type}|coords={fstart}:{fend}\n"
                        f"{wrap_fasta(flank_seq)}"
                    )
                    qc["terminal_flanks"] += 1

    write_tsv(
        args.out_dir / "proteins.tsv",
        protein_rows,
        [
            "record_id", "cds_name", "locus_tag", "gene", "protein_id",
            "product", "start_nt_0based", "end_nt_0based_exclusive",
            "strand", "length_aa", "module_count",
        ],
    )
    write_tsv(
        args.out_dir / "modules.tsv",
        module_rows,
        [
            "record_id", "cds_name", "module_index", "first_in_cds",
            "start_aa_0based", "end_aa_0based_exclusive", "length_aa",
            "component_count", "component_architecture", "has_loader",
            "has_carrier", "operational_complete", "sequence",
        ],
    )
    write_tsv(
        args.out_dir / "domains.tsv",
        domain_rows,
        [
            "record_id", "cds_name", "module_index", "component_index",
            "hit_id", "start_aa_0based", "end_aa_0based_exclusive",
            "length_aa", "evalue", "bitscore",
            "predicted_monomer_consensus", "sequence",
        ],
    )
    write_tsv(
        args.out_dir / "inter_component_gaps.tsv",
        internal_gap_rows,
        [
            "record_id", "cds_name", "module_index", "left_component",
            "right_component", "start_aa_0based",
            "end_aa_0based_exclusive", "length_aa",
            "interpretation", "sequence",
        ],
    )
    write_tsv(
        args.out_dir / "inter_module_linkers.tsv",
        linker_rows,
        [
            "record_id", "cds_name", "left_module_index",
            "right_module_index", "start_aa_0based",
            "end_aa_0based_exclusive", "length_aa",
            "left_terminal_component", "right_initial_component",
            "interpretation", "sequence",
        ],
    )
    write_tsv(
        args.out_dir / "terminal_flanks.tsv",
        flank_rows,
        [
            "record_id", "cds_name", "flank_type",
            "start_aa_0based", "end_aa_0based_exclusive",
            "length_aa", "sequence",
        ],
    )

    for filename, entries in [
        ("proteins.fasta", proteins_fa),
        ("modules.fasta", modules_fa),
        ("domains.fasta", domains_fa),
        ("inter_module_linkers.fasta", linkers_fa),
        ("inter_component_gaps.fasta", gaps_fa),
        ("terminal_flanks.fasta", flanks_fa),
    ]:
        (args.out_dir / filename).write_text(
            ("\n".join(entries) + "\n") if entries else "",
            encoding="utf-8",
        )

    (args.out_dir / "qc_summary.json").write_text(
        json.dumps(qc, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print(json.dumps(qc, indent=2, ensure_ascii=False))
    print(f"\nOutputs: {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
