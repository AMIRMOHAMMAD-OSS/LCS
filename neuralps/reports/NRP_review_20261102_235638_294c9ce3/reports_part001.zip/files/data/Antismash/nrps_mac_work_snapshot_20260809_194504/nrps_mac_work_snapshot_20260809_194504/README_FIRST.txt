NRPS / antiSMASH MAC WORK SNAPSHOT
Created: Sun Aug  9 19:45:27 CEST 2026

This snapshot is a compact reproducibility and lookup bundle.

INCLUDED
- Extractor and inspection Python scripts still present on the Mac
- Production and test logs
- Final and test QC summaries
- Final dataset file inventory, table headers, counts, and directory tree
- Key Mac directory paths and disk sizes
- Small validation outputs and test antiSMASH JSON
- antiSMASH taxonomy JSON.GZ
- Filtered relevant zsh command history

NOT INCLUDED
- /Volumes/neurALPS/asdb5/asdb5_jsons.tar
  Reason: approximately 181 GB; its path and verification metadata are recorded.
- /Volumes/neurALPS/asdb5/nrps_assembly_dataset_v3
  Reason: the full result dataset was already transferred to Windows.
  Its inventory, schemas, counts, logs, and QC summary are included.

FINAL DATASET PATH ON MAC
/Volumes/neurALPS/asdb5/nrps_assembly_dataset_v3

MAIN PRODUCTION SCRIPT
/tmp/asdb5_nrps_assembly_extractor_v3/extract_asdb5_nrps_assembly_v3.py

FINAL PRODUCTION LOG
/Volumes/neurALPS/asdb5/nrps_assembly_v3_run.log

START HERE FOR LATER LOOKUPS
1. reports/KEY_PATHS.txt
2. reports/FINAL_DATASET_COUNTS.tsv
3. reports/FINAL_DATASET_TSV_HEADERS.txt
4. metadata/final_qc_summary.json
5. scripts/asdb5_nrps_assembly_extractor_v3/

SECURITY NOTE
reports/RELEVANT_ZSH_HISTORY.txt contains filtered terminal commands and paths.
Review it before sharing this snapshot with other people.
