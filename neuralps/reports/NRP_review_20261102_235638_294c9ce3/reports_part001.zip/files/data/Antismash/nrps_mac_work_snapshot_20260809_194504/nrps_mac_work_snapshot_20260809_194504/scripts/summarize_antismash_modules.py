#!/usr/bin/env python3
import argparse
import gzip
import json
from pathlib import Path
from typing import Any

def load_json(path: Path) -> dict[str, Any]:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        return json.load(handle)

def short(value: Any) -> str:
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "yes" if value else "no"
    return str(value)

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Print a compact summary of antiSMASH NRPS/PKS modules."
    )
    parser.add_argument("json_file", type=Path)
    args = parser.parse_args()

    data = load_json(args.json_file)

    print(f"antiSMASH version: {data.get('version')}")
    print(f"schema: {data.get('schema')}")

    for record in data.get("records", []):
        record_id = record.get("id", "?")
        print("\n" + "=" * 90)
        print(f"RECORD {record_id}")

        software = record.get("modules", {})
        detection = software.get("antismash.detection.nrps_pks_domains", {})
        cds_results = detection.get("cds_results", {}) if isinstance(detection, dict) else {}

        prediction_block = software.get("antismash.modules.nrps_pks", {})
        consensus = prediction_block.get("consensus", {}) if isinstance(prediction_block, dict) else {}
        region_predictions = (
            prediction_block.get("region_predictions", {})
            if isinstance(prediction_block, dict)
            else {}
        )

        found = False
        for cds_name, result in sorted(cds_results.items()):
            if not isinstance(result, dict):
                continue
            modules = result.get("modules", [])
            if not modules:
                continue

            found = True
            print("\n" + "-" * 90)
            print(f"CDS: {cds_name}")
            print(f"Module count: {len(modules)}")

            for module_index, module in enumerate(modules, start=1):
                if not isinstance(module, dict):
                    print(f"\n  MODULE {module_index}: {module!r}")
                    continue

                domains = module.get("domains", [])
                print(f"\n  MODULE {module_index}")
                for field in [
                    "complete",
                    "starter_module",
                    "final_module",
                    "iterative",
                    "monomer",
                    "module_type",
                    "multi_cds",
                ]:
                    if field in module:
                        print(f"    {field}: {short(module.get(field))}")

                print(f"    domain_count: {len(domains)}")
                for domain_index, domain in enumerate(domains, start=1):
                    if not isinstance(domain, dict):
                        print(f"      {domain_index}. {domain!r}")
                        continue

                    name = (
                        domain.get("name")
                        or domain.get("type")
                        or domain.get("domain")
                        or "?"
                    )
                    start = domain.get("start", domain.get("protein_start", "?"))
                    end = domain.get("end", domain.get("protein_end", "?"))
                    locus = domain.get("locus", cds_name)
                    subtype = domain.get("subtype", "")
                    active = domain.get("active", "")
                    extras = []
                    if subtype not in ("", None):
                        extras.append(f"subtype={subtype}")
                    if active not in ("", None):
                        extras.append(f"active={active}")
                    extra_text = ("; " + ", ".join(extras)) if extras else ""
                    print(
                        f"      {domain_index}. {name} "
                        f"[{start}:{end}] locus={locus}{extra_text}"
                    )

                # Keep any unrecognized fields visible for schema discovery.
                known = {
                    "domains", "complete", "starter_module", "final_module",
                    "iterative", "monomer", "module_type", "multi_cds"
                }
                extra_keys = [key for key in module.keys() if key not in known]
                if extra_keys:
                    print(f"    other_fields: {extra_keys}")

            if isinstance(consensus, dict):
                matching = {
                    key: value
                    for key, value in consensus.items()
                    if cds_name in str(key) or cds_name in str(value)
                }
                if matching:
                    print("\n  CONSENSUS ENTRIES")
                    print(json.dumps(matching, indent=2, ensure_ascii=False))

        if not found:
            print("No CDS with non-empty NRPS/PKS module lists.")

        print("\nREGION PREDICTIONS")
        print(json.dumps(region_predictions, indent=2, ensure_ascii=False))

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
