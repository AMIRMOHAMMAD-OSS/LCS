#!/usr/bin/env python3
"""
Stream antiSMASH Database 5 JSON members directly from asdb5_jsons.tar and
extract NRPS-related assembly-line proteins, modules, domains, and sequence gaps.

The TAR is read sequentially; its 181-GB contents are NOT extracted to disk.

Important terminology
---------------------
- inter_module_linker_candidate:
    sequence between the last HMM component of one antiSMASH module and the
    first HMM component of the next module on the SAME protein.
- inter_component_gap_not_validated_linker:
    sequence between two HMM hits inside a module. This is not automatically a
    true linker because HMM hits often cover conserved cores, not full domains.
- Separate proteins are never concatenated.

Outputs are gzip-compressed TSV/FASTA files.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import io
import json
import re
import shutil
import sys
import tarfile
import time
from collections import Counter
from pathlib import Path
from typing import Any, Iterable, TextIO


NRPS_EXACT_PRODUCTS = {
    "nrps",
    "nrps-like",
    "nrp-metallophore",
    "isocyanide-nrp",
    "thioamide-nrp",
    "t3nrps-iterative",
}


def is_nrps_product(product: str) -> bool:
    p = product.strip().lower()
    return (
        p in NRPS_EXACT_PRODUCTS
        or p.startswith("nrps-")
        or p.endswith("-nrps")
        or p.startswith("nrp-")
        or p.endswith("-nrp")
        or "nonribosomal" in p
    )


def load_taxa(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {}
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        data = json.load(handle)
    return data.get("mappings", data) if isinstance(data, dict) else {}


def first(value: Any, default: str = "") -> str:
    return str(value[0]) if isinstance(value, list) and value else default


def clean_sequence(value: str) -> str:
    return re.sub(r"[^A-Za-z*]", "", value).upper().rstrip("*")


def parse_location(text: Any) -> tuple[int | None, int | None, int]:
    raw = str(text)
    match = re.search(r"\[(\d+):(\d+)\]", raw)
    if not match:
        return None, None, 0
    strand = -1 if raw.endswith("(-)") else 1 if raw.endswith("(+)") else 0
    return int(match.group(1)), int(match.group(2)), strand


def overlaps(start1: int, end1: int, start2: int, end2: int) -> bool:
    return end1 > start2 and end2 > start1


def normalize_component(raw: Any, cds_name: str) -> dict[str, Any] | None:
    if not isinstance(raw, dict):
        return None

    if isinstance(raw.get("domain"), dict):
        component = dict(raw["domain"])
        component.setdefault("locus", raw.get("locus", cds_name))
        for key in ("active", "subtype", "type"):
            if key in raw and key not in component:
                component[key] = raw[key]
    else:
        component = dict(raw)
        component.setdefault("locus", cds_name)

    if "query_start" not in component or "query_end" not in component:
        return None

    try:
        component["query_start"] = int(component["query_start"])
        component["query_end"] = int(component["query_end"])
    except (TypeError, ValueError):
        return None

    return component


def normalized_components(module: dict[str, Any], cds_name: str) -> list[dict[str, Any]]:
    result = []
    for raw in module.get("components", []):
        comp = normalize_component(raw, cds_name)
        if comp is not None:
            result.append(comp)
    result.sort(key=lambda c: (c["query_start"], c["query_end"]))
    return result


def is_a_loader(hit_id: str) -> bool:
    return "AMP-binding" in hit_id or hit_id in {"A-OX", "CAL_domain", "CoA-ligase"}


def is_pks_loader(hit_id: str) -> bool:
    return hit_id in {"PKS_AT", "PKS_AT2", "AT"}


def is_carrier(hit_id: str) -> bool:
    return hit_id in {"PCP", "PP-binding", "ACP", "ACP_beta", "ACP-like"}


def module_family(components: list[dict[str, Any]]) -> str:
    hits = [str(c.get("hit_id", "")) for c in components]
    nrps = any(is_a_loader(h) for h in hits)
    pks = any(is_pks_loader(h) or "PKS_KS" in h or h == "Ketosynthase" for h in hits)
    if nrps and pks:
        return "HYBRID"
    if nrps:
        return "NRPS"
    if pks:
        return "PKS"
    return "OTHER"


def nrps_consensus_for_cds(consensus: dict[str, Any], cds_name: str) -> dict[int, str]:
    pattern = re.compile(
        rf"^nrpspksdomains_{re.escape(cds_name)}_AMP-binding\.(\d+)$"
    )
    out: dict[int, str] = {}
    for key, value in consensus.items():
        match = pattern.match(str(key))
        if match:
            out[int(match.group(1))] = str(value)
    return out


def wrap_fasta(sequence: str, width: int = 80) -> str:
    return "\n".join(sequence[i:i + width] for i in range(0, len(sequence), width))


class GzipTSV:
    def __init__(self, path: Path, fields: list[str]):
        self.handle = gzip.open(path, "wt", encoding="utf-8", newline="")
        self.writer = csv.DictWriter(
            self.handle,
            fieldnames=fields,
            delimiter="\t",
            extrasaction="ignore",
        )
        self.writer.writeheader()

    def write(self, row: dict[str, Any]) -> None:
        self.writer.writerow(row)

    def close(self) -> None:
        self.handle.close()


class GzipFASTA:
    def __init__(self, path: Path):
        self.handle = gzip.open(path, "wt", encoding="utf-8")

    def write(self, header: str, sequence: str) -> None:
        self.handle.write(f">{header}\n")
        self.handle.write(wrap_fasta(sequence))
        self.handle.write("\n")

    def close(self) -> None:
        self.handle.close()


def taxonomy_for_record(record: dict[str, Any], taxa: dict[str, Any]) -> dict[str, Any]:
    tax_id = ""
    for feature in record.get("features", []):
        if feature.get("type") != "source":
            continue
        q = feature.get("qualifiers", {})
        for item in q.get("db_xref", []):
            match = re.match(r"taxon:(\d+)", str(item))
            if match:
                tax_id = match.group(1)
                break
        if tax_id:
            break

    metadata = taxa.get(tax_id, {}) if tax_id else {}
    return {
        "tax_id": tax_id,
        "organism": metadata.get("name", ""),
        "species": metadata.get("species", ""),
        "genus": metadata.get("genus", ""),
        "family": metadata.get("family", ""),
        "order": metadata.get("order", ""),
        "class": metadata.get("class", ""),
        "phylum": metadata.get("phylum", ""),
        "kingdom": metadata.get("kingdom", ""),
        "superkingdom": metadata.get("superkingdom", ""),
    }


def safe_remove_output(out_dir: Path, overwrite: bool) -> None:
    if out_dir.exists():
        if not overwrite:
            raise SystemExit(
                f"Output directory already exists: {out_dir}\n"
                "Use --overwrite to replace it."
            )
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tar", required=True, type=Path)
    parser.add_argument("--taxa-json", type=Path, default=None)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument(
        "--max-members",
        type=int,
        default=0,
        help="Stop after this many JSON members; 0 means all members.",
    )
    parser.add_argument(
        "--log-every",
        type=int,
        default=100,
        help="Print progress every N JSON members.",
    )
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    safe_remove_output(args.out_dir, args.overwrite)
    taxa = load_taxa(args.taxa_json)

    tsv = {
        "genomes": GzipTSV(args.out_dir / "genomes.tsv.gz", [
            "accession", "antismash_version", "schema", "record_count",
            "nrps_area_count", "nrps_protein_count",
        ]),
        "areas": GzipTSV(args.out_dir / "areas.tsv.gz", [
            "accession", "record_id", "area_index",
            "start_nt_0based", "end_nt_0based_exclusive",
            "products", "tax_id", "organism", "species", "genus",
            "family", "order", "class", "phylum", "kingdom", "superkingdom",
        ]),
        "proteins": GzipTSV(args.out_dir / "proteins.tsv.gz", [
            "accession", "record_id", "area_index", "cds_name",
            "locus_tag", "gene", "protein_id", "product",
            "start_nt_0based", "end_nt_0based_exclusive", "strand",
            "length_aa", "module_count", "contains_nrps_module",
            "module_families",
        ]),
        "modules": GzipTSV(args.out_dir / "modules.tsv.gz", [
            "accession", "record_id", "area_index", "cds_name",
            "module_index", "first_in_cds", "module_family",
            "start_aa_0based", "end_aa_0based_exclusive", "length_aa",
            "component_count", "component_architecture",
            "has_loader", "has_carrier", "operational_complete",
        ]),
        "domains": GzipTSV(args.out_dir / "domains.tsv.gz", [
            "accession", "record_id", "area_index", "cds_name",
            "module_index", "component_index", "hit_id",
            "start_aa_0based", "end_aa_0based_exclusive", "length_aa",
            "evalue", "bitscore", "predicted_monomer_consensus",
        ]),
        "linkers": GzipTSV(args.out_dir / "inter_module_linkers.tsv.gz", [
            "accession", "record_id", "area_index", "cds_name",
            "left_module_index", "right_module_index",
            "left_module_family", "right_module_family",
            "start_aa_0based", "end_aa_0based_exclusive", "length_aa",
            "left_terminal_component", "right_initial_component",
            "interpretation",
        ]),
        "gaps": GzipTSV(args.out_dir / "inter_component_gaps.tsv.gz", [
            "accession", "record_id", "area_index", "cds_name",
            "module_index", "left_component", "right_component",
            "start_aa_0based", "end_aa_0based_exclusive", "length_aa",
            "interpretation",
        ]),
        "flanks": GzipTSV(args.out_dir / "terminal_flanks.tsv.gz", [
            "accession", "record_id", "area_index", "cds_name",
            "flank_type", "start_aa_0based",
            "end_aa_0based_exclusive", "length_aa",
        ]),
    }

    fasta = {
        "proteins": GzipFASTA(args.out_dir / "proteins.fasta.gz"),
        "modules": GzipFASTA(args.out_dir / "modules.fasta.gz"),
        "domains": GzipFASTA(args.out_dir / "domains.fasta.gz"),
        "linkers": GzipFASTA(args.out_dir / "inter_module_linkers.fasta.gz"),
        "gaps": GzipFASTA(args.out_dir / "inter_component_gaps.fasta.gz"),
        "flanks": GzipFASTA(args.out_dir / "terminal_flanks.fasta.gz"),
    }

    counts = Counter()
    module_family_counts = Counter()
    start_time = time.time()

    try:
        with tarfile.open(args.tar, mode="r|") as tar:
            for member in tar:
                if not member.isfile() or not member.name.endswith(".json.gz"):
                    continue

                counts["json_members_seen"] += 1
                if args.max_members and counts["json_members_seen"] > args.max_members:
                    break

                extracted = tar.extractfile(member)
                if extracted is None:
                    counts["tar_member_read_errors"] += 1
                    continue

                accession = Path(member.name).name.removesuffix(".json.gz")

                try:
                    with gzip.GzipFile(fileobj=extracted, mode="rb") as gz:
                        data = json.load(io.TextIOWrapper(gz, encoding="utf-8"))
                except Exception as exc:
                    counts["json_parse_errors"] += 1
                    print(f"[WARN] {accession}: {exc}", file=sys.stderr)
                    continue

                accession_nrps_areas = 0
                accession_nrps_proteins = 0

                for record in data.get("records", []):
                    record_id = str(record.get("id", ""))
                    tax = taxonomy_for_record(record, taxa)

                    nrps_areas = []
                    for area_index, area in enumerate(record.get("areas", []), start=1):
                        products = [str(x) for x in area.get("products", [])]
                        if any(is_nrps_product(p) for p in products):
                            nrps_areas.append({
                                "index": area_index,
                                "start": int(area["start"]),
                                "end": int(area["end"]),
                                "products": products,
                            })
                            accession_nrps_areas += 1
                            counts["nrps_areas"] += 1
                            tsv["areas"].write({
                                "accession": accession,
                                "record_id": record_id,
                                "area_index": area_index,
                                "start_nt_0based": area["start"],
                                "end_nt_0based_exclusive": area["end"],
                                "products": ";".join(products),
                                **tax,
                            })

                    if not nrps_areas:
                        continue

                    cds_by_alias: dict[str, dict[str, Any]] = {}
                    for feature in record.get("features", []):
                        if feature.get("type") != "CDS":
                            continue
                        q = feature.get("qualifiers", {})
                        locus_tag = first(q.get("locus_tag"))
                        gene = first(q.get("gene"))
                        protein_id = first(q.get("protein_id"))
                        start_nt, end_nt, strand = parse_location(feature.get("location"))
                        translation = clean_sequence(first(q.get("translation")))
                        entry = {
                            "locus_tag": locus_tag,
                            "gene": gene,
                            "protein_id": protein_id,
                            "product": first(q.get("product")),
                            "start_nt": start_nt,
                            "end_nt": end_nt,
                            "strand": strand,
                            "translation": translation,
                        }
                        for alias in {locus_tag, gene, protein_id}:
                            if alias:
                                cds_by_alias.setdefault(alias, entry)

                    software = record.get("modules", {})
                    detection = software.get(
                        "antismash.detection.nrps_pks_domains", {}
                    )
                    cds_results = (
                        detection.get("cds_results", {})
                        if isinstance(detection, dict)
                        else {}
                    )
                    prediction_block = software.get("antismash.modules.nrps_pks", {})
                    consensus = (
                        prediction_block.get("consensus", {})
                        if isinstance(prediction_block, dict)
                        else {}
                    )

                    for cds_name, result in sorted(cds_results.items()):
                        if not isinstance(result, dict):
                            continue
                        raw_modules = result.get("modules", [])
                        if not raw_modules:
                            continue

                        cds = cds_by_alias.get(cds_name)
                        if not cds or not cds.get("translation"):
                            counts["missing_cds_translation"] += 1
                            continue
                        if cds["start_nt"] is None or cds["end_nt"] is None:
                            counts["missing_cds_location"] += 1
                            continue

                        overlapping_areas = [
                            a for a in nrps_areas
                            if overlaps(
                                int(cds["start_nt"]), int(cds["end_nt"]),
                                a["start"], a["end"]
                            )
                        ]
                        if not overlapping_areas:
                            continue

                        area = overlapping_areas[0]
                        sequence = str(cds["translation"])
                        protein_len = len(sequence)
                        amp_consensus = nrps_consensus_for_cds(consensus, cds_name)
                        amp_counter = 0

                        modules = []
                        for raw_module in raw_modules:
                            if not isinstance(raw_module, dict):
                                continue
                            components = normalized_components(raw_module, cds_name)
                            if not components:
                                continue
                            start = min(c["query_start"] for c in components)
                            end = max(c["query_end"] for c in components)
                            if start < 0 or end > protein_len or end <= start:
                                counts["coordinate_warnings"] += 1
                                continue
                            family = module_family(components)
                            modules.append({
                                "raw": raw_module,
                                "components": components,
                                "start": start,
                                "end": end,
                                "family": family,
                            })

                        if not modules:
                            continue

                        contains_nrps = any(
                            m["family"] in {"NRPS", "HYBRID"} for m in modules
                        )
                        # Keep all modular proteins in an NRPS-related area, but
                        # clearly mark whether the protein itself has NRPS modules.
                        accession_nrps_proteins += 1
                        counts["proteins"] += 1
                        if contains_nrps:
                            counts["proteins_with_nrps_module"] += 1

                        module_families = [m["family"] for m in modules]
                        tsv["proteins"].write({
                            "accession": accession,
                            "record_id": record_id,
                            "area_index": area["index"],
                            "cds_name": cds_name,
                            "locus_tag": cds["locus_tag"],
                            "gene": cds["gene"],
                            "protein_id": cds["protein_id"],
                            "product": cds["product"],
                            "start_nt_0based": cds["start_nt"],
                            "end_nt_0based_exclusive": cds["end_nt"],
                            "strand": cds["strand"],
                            "length_aa": protein_len,
                            "module_count": len(modules),
                            "contains_nrps_module": contains_nrps,
                            "module_families": ";".join(module_families),
                        })
                        fasta["proteins"].write(
                            f"{accession}|{record_id}|area={area['index']}|"
                            f"{cds_name}|full_protein|length={protein_len}|"
                            f"contains_nrps={contains_nrps}",
                            sequence,
                        )

                        normalized_for_linkers = []
                        for module_index, module in enumerate(modules, start=1):
                            components = module["components"]
                            family = module["family"]
                            start = module["start"]
                            end = module["end"]
                            architecture = "->".join(
                                str(c.get("hit_id", "?")) for c in components
                            )
                            has_loader = any(
                                is_a_loader(str(c.get("hit_id", "")))
                                or is_pks_loader(str(c.get("hit_id", "")))
                                for c in components
                            )
                            has_carrier = any(
                                is_carrier(str(c.get("hit_id", "")))
                                for c in components
                            )
                            complete = has_loader and has_carrier
                            module_family_counts[family] += 1
                            counts["modules"] += 1

                            tsv["modules"].write({
                                "accession": accession,
                                "record_id": record_id,
                                "area_index": area["index"],
                                "cds_name": cds_name,
                                "module_index": module_index,
                                "first_in_cds": module["raw"].get("first_in_cds", ""),
                                "module_family": family,
                                "start_aa_0based": start,
                                "end_aa_0based_exclusive": end,
                                "length_aa": end - start,
                                "component_count": len(components),
                                "component_architecture": architecture,
                                "has_loader": has_loader,
                                "has_carrier": has_carrier,
                                "operational_complete": complete,
                            })
                            fasta["modules"].write(
                                f"{accession}|{record_id}|area={area['index']}|"
                                f"{cds_name}|module={module_index}|family={family}|"
                                f"coords={start}:{end}|complete={complete}",
                                sequence[start:end],
                            )

                            for component_index, component in enumerate(
                                components, start=1
                            ):
                                hit_id = str(component.get("hit_id", "?"))
                                dstart = int(component["query_start"])
                                dend = int(component["query_end"])
                                predicted = ""
                                if "AMP-binding" in hit_id:
                                    amp_counter += 1
                                    predicted = amp_consensus.get(amp_counter, "")

                                counts["domains"] += 1
                                tsv["domains"].write({
                                    "accession": accession,
                                    "record_id": record_id,
                                    "area_index": area["index"],
                                    "cds_name": cds_name,
                                    "module_index": module_index,
                                    "component_index": component_index,
                                    "hit_id": hit_id,
                                    "start_aa_0based": dstart,
                                    "end_aa_0based_exclusive": dend,
                                    "length_aa": dend - dstart,
                                    "evalue": component.get("evalue", ""),
                                    "bitscore": component.get("bitscore", ""),
                                    "predicted_monomer_consensus": predicted,
                                })
                                fasta["domains"].write(
                                    f"{accession}|{record_id}|area={area['index']}|"
                                    f"{cds_name}|module={module_index}|"
                                    f"component={component_index}|{hit_id}|"
                                    f"coords={dstart}:{dend}|monomer={predicted or '-'}",
                                    sequence[dstart:dend],
                                )

                            for left, right in zip(components, components[1:]):
                                gap_start = int(left["query_end"])
                                gap_end = int(right["query_start"])
                                if gap_end < gap_start:
                                    counts["overlapping_components"] += 1
                                    continue
                                counts["inter_component_gaps"] += 1
                                tsv["gaps"].write({
                                    "accession": accession,
                                    "record_id": record_id,
                                    "area_index": area["index"],
                                    "cds_name": cds_name,
                                    "module_index": module_index,
                                    "left_component": left.get("hit_id", ""),
                                    "right_component": right.get("hit_id", ""),
                                    "start_aa_0based": gap_start,
                                    "end_aa_0based_exclusive": gap_end,
                                    "length_aa": gap_end - gap_start,
                                    "interpretation":
                                        "inter_component_gap_not_validated_linker",
                                })
                                fasta["gaps"].write(
                                    f"{accession}|{record_id}|area={area['index']}|"
                                    f"{cds_name}|module={module_index}|"
                                    f"gap={left.get('hit_id','?')}__"
                                    f"{right.get('hit_id','?')}|"
                                    f"coords={gap_start}:{gap_end}|"
                                    f"NOT_VALIDATED_LINKER",
                                    sequence[gap_start:gap_end],
                                )

                            normalized_for_linkers.append({
                                "index": module_index,
                                "family": family,
                                "start": start,
                                "end": end,
                                "components": components,
                            })

                        normalized_for_linkers.sort(
                            key=lambda m: (m["start"], m["end"])
                        )
                        for left, right in zip(
                            normalized_for_linkers,
                            normalized_for_linkers[1:]
                        ):
                            linker_start = left["end"]
                            linker_end = right["start"]
                            if linker_end < linker_start:
                                counts["overlapping_modules"] += 1
                                continue
                            counts["inter_module_linker_candidates"] += 1
                            tsv["linkers"].write({
                                "accession": accession,
                                "record_id": record_id,
                                "area_index": area["index"],
                                "cds_name": cds_name,
                                "left_module_index": left["index"],
                                "right_module_index": right["index"],
                                "left_module_family": left["family"],
                                "right_module_family": right["family"],
                                "start_aa_0based": linker_start,
                                "end_aa_0based_exclusive": linker_end,
                                "length_aa": linker_end - linker_start,
                                "left_terminal_component":
                                    left["components"][-1].get("hit_id", ""),
                                "right_initial_component":
                                    right["components"][0].get("hit_id", ""),
                                "interpretation":
                                    "inter_module_linker_candidate",
                            })
                            fasta["linkers"].write(
                                f"{accession}|{record_id}|area={area['index']}|"
                                f"{cds_name}|modules={left['index']}__"
                                f"{right['index']}|"
                                f"families={left['family']}__{right['family']}|"
                                f"coords={linker_start}:{linker_end}|"
                                f"inter_module_linker_candidate",
                                sequence[linker_start:linker_end],
                            )

                        first_start = normalized_for_linkers[0]["start"]
                        last_end = normalized_for_linkers[-1]["end"]
                        for flank_type, fstart, fend in (
                            ("n_terminal_flank", 0, first_start),
                            ("c_terminal_flank", last_end, protein_len),
                        ):
                            counts["terminal_flanks"] += 1
                            tsv["flanks"].write({
                                "accession": accession,
                                "record_id": record_id,
                                "area_index": area["index"],
                                "cds_name": cds_name,
                                "flank_type": flank_type,
                                "start_aa_0based": fstart,
                                "end_aa_0based_exclusive": fend,
                                "length_aa": fend - fstart,
                            })
                            fasta["flanks"].write(
                                f"{accession}|{record_id}|area={area['index']}|"
                                f"{cds_name}|{flank_type}|coords={fstart}:{fend}",
                                sequence[fstart:fend],
                            )

                if accession_nrps_areas:
                    counts["genomes_with_nrps_area"] += 1
                    tsv["genomes"].write({
                        "accession": accession,
                        "antismash_version": data.get("version", ""),
                        "schema": data.get("schema", ""),
                        "record_count": len(data.get("records", [])),
                        "nrps_area_count": accession_nrps_areas,
                        "nrps_protein_count": accession_nrps_proteins,
                    })

                if (
                    args.log_every
                    and counts["json_members_seen"] % args.log_every == 0
                ):
                    elapsed = time.time() - start_time
                    rate = counts["json_members_seen"] / elapsed if elapsed else 0
                    print(
                        f"[{counts['json_members_seen']:,} members] "
                        f"NRPS genomes={counts['genomes_with_nrps_area']:,}, "
                        f"areas={counts['nrps_areas']:,}, "
                        f"proteins={counts['proteins']:,}, "
                        f"modules={counts['modules']:,}, "
                        f"rate={rate:.2f} members/s",
                        flush=True,
                    )

    finally:
        for writer in tsv.values():
            writer.close()
        for writer in fasta.values():
            writer.close()

    summary = {
        **dict(counts),
        "module_family_counts": dict(module_family_counts),
        "elapsed_seconds": round(time.time() - start_time, 2),
        "tar_path": str(args.tar),
        "taxa_json": str(args.taxa_json) if args.taxa_json else None,
    }
    (args.out_dir / "qc_summary.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2))
    print(f"Outputs: {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
