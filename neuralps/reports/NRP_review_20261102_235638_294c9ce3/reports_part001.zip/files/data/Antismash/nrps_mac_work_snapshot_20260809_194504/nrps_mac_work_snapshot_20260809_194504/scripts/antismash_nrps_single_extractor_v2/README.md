# antiSMASH NRPS single-record extractor v2

This version unwraps antiSMASH schema-4 module components stored under
`component["domain"]`.

Run:

```bash
python3 extract_antismash_nrps_sequences_v2.py \
  test_extract/asdb5_jsons/GCF_000024185.1.json.gz \
  --out-dir test_extract/GCF_000024185_nrps_v2
```

Expected for the test record:

- proteins_with_modules: 2
- modules: 6
- domains: 19
- inter_module_linker_candidates: 4
- inter_component_gaps: 13
- terminal_flanks: 4
