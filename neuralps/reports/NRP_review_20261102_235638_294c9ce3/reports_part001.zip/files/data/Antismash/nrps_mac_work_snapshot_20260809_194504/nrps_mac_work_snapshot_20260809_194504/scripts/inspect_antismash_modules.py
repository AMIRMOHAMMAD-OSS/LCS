#!/usr/bin/env python3
import gzip
import json
from pathlib import Path

INPUT = Path("test_extract/asdb5_jsons/GCF_000024185.1.json.gz")
OUTPUT = Path("/tmp/nrps_module_schema_summary.json")

with gzip.open(INPUT, "rt", encoding="utf-8") as handle:
    data = json.load(handle)

summary = {
    "antismash_version": data.get("version"),
    "schema": data.get("schema"),
    "records": [],
}

for record in data.get("records", []):
    software = record.get("modules", {})
    detection = software.get("antismash.detection.nrps_pks_domains", {})
    predictions = software.get("antismash.modules.nrps_pks", {})

    record_summary = {
        "record_id": record.get("id"),
        "cds_results_with_modules": {},
        "nrps_pks_prediction_keys": list(predictions.keys()) if isinstance(predictions, dict) else [],
        "domain_predictions": predictions.get("domain_predictions") if isinstance(predictions, dict) else None,
        "consensus": predictions.get("consensus") if isinstance(predictions, dict) else None,
        "consensus_transat": predictions.get("consensus_transat") if isinstance(predictions, dict) else None,
        "region_predictions": predictions.get("region_predictions") if isinstance(predictions, dict) else None,
    }

    cds_results = detection.get("cds_results", {}) if isinstance(detection, dict) else {}
    for cds_name, result in cds_results.items():
        modules = result.get("modules", []) if isinstance(result, dict) else []
        if modules:
            record_summary["cds_results_with_modules"][cds_name] = {
                "result_keys": list(result.keys()),
                "modules": modules,
                "domain_hmms": result.get("domain_hmms"),
                "motif_hmms": result.get("motif_hmms"),
            }

    summary["records"].append(record_summary)

OUTPUT.write_text(
    json.dumps(summary, indent=2, ensure_ascii=False),
    encoding="utf-8",
)

print(f"Wrote: {OUTPUT}")
for record in summary["records"]:
    print(f"\nRecord: {record['record_id']}")
    print("CDSs with non-empty module lists:")
    for cds_name, result in record["cds_results_with_modules"].items():
        print(f"  {cds_name}: {len(result['modules'])} modules")
    print("NRPS/PKS prediction keys:", record["nrps_pks_prediction_keys"])
