# antiSMASH DB5 streaming NRPS extractor

This script scans `asdb5_jsons.tar` directly. It does not unpack the 181-GB
archive.

## Small validation run

```bash
python3 extract_asdb5_nrps_stream.py \
  --tar /Volumes/neurALPS/asdb5/asdb5_jsons.tar \
  --taxa-json /Volumes/neurALPS/asdb5/asdb5_taxa.json.gz \
  --out-dir /Volumes/neurALPS/asdb5/nrps_stream_test \
  --max-members 100 \
  --overwrite
```

## Full run

Use `caffeinate` and `nohup` so the Mac stays awake and the SSH session may close:

```bash
cd /Volumes/neurALPS/asdb5

nohup caffeinate -dimsu \
  python3 /tmp/asdb5_nrps_stream_extractor/extract_asdb5_nrps_stream.py \
    --tar /Volumes/neurALPS/asdb5/asdb5_jsons.tar \
    --taxa-json /Volumes/neurALPS/asdb5/asdb5_taxa.json.gz \
    --out-dir /Volumes/neurALPS/asdb5/nrps_dataset \
    --overwrite \
  > /Volumes/neurALPS/asdb5/nrps_dataset_run.log 2>&1 &

echo $!
```

Monitor:

```bash
tail -f /Volumes/neurALPS/asdb5/nrps_dataset_run.log
```

## Output interpretation

- `inter_module_linkers.*` are candidate same-protein inter-module gaps.
- `inter_component_gaps.*` are not validated linkers.
- PKS modules inside NRPS-related hybrid areas are retained and labeled by
  `module_family`.
- Proteins are never concatenated across gene boundaries.
