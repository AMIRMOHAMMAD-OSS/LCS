#!/usr/bin/env python3
import gzip
import json
import re
from collections import defaultdict
from pathlib import Path

path = Path("test_extract/asdb5_jsons/GCF_000024185.1.json.gz")

def first(value, default=""):
    return value[0] if isinstance(value, list) and value else default

def parse_location(text):
    match = re.search(r"\[(\d+):(\d+)\]", str(text))
    return (int(match.group(1)), int(match.group(2))) if match else (None, None)

with gzip.open(path, "rt", encoding="utf-8") as handle:
    data = json.load(handle)

print("antiSMASH version:", data.get("version"))
print("schema:", data.get("schema"))
print("records:", len(data.get("records", [])))

for record in data.get("records", []):
    print("\n" + "=" * 80)
    print("RECORD:", record.get("id"))

    for area_index, area in enumerate(record.get("areas", []), start=1):
        products = [str(x) for x in area.get("products", [])]
        is_nrps = any(
            "nrps" in p.lower() or "nrp-" in p.lower() or "-nrp" in p.lower()
            for p in products
        )
        if not is_nrps:
            continue

        area_start = int(area["start"])
        area_end = int(area["end"])
        print("\n" + "-" * 80)
        print(
            f"AREA {area_index}: {area_start}-{area_end} "
            f"products={products}"
        )

        by_gene = defaultdict(list)

        for feature in record.get("features", []):
            if feature.get("type") != "aSDomain":
                continue

            genomic_start, genomic_end = parse_location(feature.get("location"))
            if genomic_start is None:
                continue
            if genomic_end <= area_start or genomic_start >= area_end:
                continue

            qualifiers = feature.get("qualifiers", {})
            locus_tag = first(
                qualifiers.get("locus_tag"),
                first(qualifiers.get("gene"), "UNKNOWN_GENE"),
            )
            domain_type = first(
                qualifiers.get("aSDomain"),
                first(qualifiers.get("label"), "UNKNOWN_DOMAIN"),
            )
            protein_start = int(first(qualifiers.get("protein_start"), "-1"))
            protein_end = int(first(qualifiers.get("protein_end"), "-1"))

            by_gene[locus_tag].append(
                (protein_start, protein_end, domain_type, genomic_start, genomic_end)
            )

        print("Genes with antiSMASH domains:", len(by_gene))

        for locus_tag, domains in sorted(by_gene.items()):
            domains.sort()
            architecture = " -> ".join(d[2] for d in domains)
            print(f"\n  Gene: {locus_tag}")
            print(f"  Architecture: {architecture}")
            for protein_start, protein_end, domain_type, genomic_start, genomic_end in domains:
                print(
                    f"    {domain_type:25s} "
                    f"protein={protein_start:5d}-{protein_end:<5d} "
                    f"genome={genomic_start}-{genomic_end}"
                )

    print("\n" + "=" * 80)
    print("RELEVANT SOFTWARE-MODULE RESULT KEYS")

    relevant = []
    for key, value in record.get("modules", {}).items():
        low = key.lower()
        if "nrps" in low or "pks" in low:
            relevant.append((key, value))

    if not relevant:
        print("No result key containing NRPS or PKS was found.")
    else:
        for key, value in relevant:
            print("\n" + "-" * 80)
            print("Key:", key)
            print("Value type:", type(value).__name__)
            if isinstance(value, dict):
                print("Top-level fields:", list(value.keys()))
            rendered = json.dumps(value, indent=2, ensure_ascii=False)
            print(rendered[:5000])
            if len(rendered) > 5000:
                print("\n... OUTPUT TRUNCATED ...")
