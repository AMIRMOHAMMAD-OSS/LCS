# antiSMASH DB5 NRPS assembly-line extractor v3

This is the production version for the requested dataset.

## Why v3 replaces the earlier stream extractor

The earlier version correctly extracted ordinary same-protein modules, domains,
and linker candidates, but it did not yet provide the explicit assembly-line
layer and could misinterpret multi-CDS modules. v3 adds:

- explicit assembly-line alternatives from `region_predictions`
- protein ordering, polymer, SMILES, and docking-use status
- global module numbering within each assembly line
- explicit `inter_protein_chain_break` transitions
- safe representation of multi-CDS modules as separate segments
- raw domain-prediction JSONL plus consensus monomer labels
- no artificial concatenation of proteins or multi-CDS module segments
- exact `--max-members` behavior

## Stop the old full run

```bash
pkill -TERM -P 60568 2>/dev/null
kill -TERM 60568 2>/dev/null
pgrep -fl extract_asdb5_nrps_stream.py
```

If the last command still shows the old extractor:

```bash
pkill -TERM -f extract_asdb5_nrps_stream.py
```

## 100-member validation

```bash
python3 /tmp/asdb5_nrps_assembly_extractor_v3/extract_asdb5_nrps_assembly_v3.py \
  --tar /Volumes/neurALPS/asdb5/asdb5_jsons.tar \
  --taxa-json /Volumes/neurALPS/asdb5/asdb5_taxa.json.gz \
  --out-dir /Volumes/neurALPS/asdb5/nrps_assembly_test_v3 \
  --max-members 100 \
  --overwrite
```

## Full run

```bash
cd /Volumes/neurALPS/asdb5

nohup caffeinate -dimsu \
  python3 /tmp/asdb5_nrps_assembly_extractor_v3/extract_asdb5_nrps_assembly_v3.py \
    --tar /Volumes/neurALPS/asdb5/asdb5_jsons.tar \
    --taxa-json /Volumes/neurALPS/asdb5/asdb5_taxa.json.gz \
    --out-dir /Volumes/neurALPS/asdb5/nrps_assembly_dataset_v3 \
    --overwrite \
  > /Volumes/neurALPS/asdb5/nrps_assembly_v3_run.log 2>&1 &

echo $!
```

Monitor:

```bash
tail -f /Volumes/neurALPS/asdb5/nrps_assembly_v3_run.log
```

## Core assembly-line files

- `assembly_lines.tsv.gz`
- `assembly_line_proteins.tsv.gz`
- `assembly_line_modules.tsv.gz`
- `assembly_line_transitions.tsv.gz`
- `assembly_line_proteins.fasta.gz`
- `region_predictions.tsv.gz`

## Sequence annotation files

- `proteins.fasta.gz`
- `contiguous_modules.fasta.gz`
- `module_segments.fasta.gz`
- `domains.fasta.gz`
- `inter_module_linkers.fasta.gz`
- `inter_component_gaps.fasta.gz`
- `terminal_flanks.fasta.gz`

## Prediction files

- `substrate_consensus.tsv.gz`
- `domain_predictions.jsonl.gz`
