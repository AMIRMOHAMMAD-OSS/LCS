#!/usr/bin/env python3
"""
antiSMASH DB5 NRPS assembly-line extractor (v3)

Streams asdb5_jsons.tar without extracting it and writes a normalized dataset
for NRPS-related areas.

Key design choices
------------------
1. Whole assembly lines are represented as ordered lists of full protein
   sequences. Separate proteins are NEVER concatenated into a fake peptide.
2. Same-protein gaps between adjacent antiSMASH modules are labelled
   inter_module_linker_candidate.
3. Cross-protein boundaries are labelled inter_protein_chain_break and have no
   amino-acid sequence.
4. Gaps between HMM components inside one module are retained as
   inter_component_gap_not_validated_linker.
5. Multi-CDS modules are represented by separate module segments. They are
   never converted into a fake contiguous sequence.
6. antiSMASH region predictions, polymer, SMILES, ordering, docking flag,
   consensus monomers, and raw domain-prediction objects are preserved.

Coordinates
-----------
Protein coordinates are 0-based, end-exclusive, matching Python slicing.
Genomic coordinates are retained as antiSMASH reports them.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import io
import json
import re
import shutil
import sys
import tarfile
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable


NRPS_EXACT_PRODUCTS = {
    "nrps",
    "nrps-like",
    "nrp-metallophore",
    "isocyanide-nrp",
    "thioamide-nrp",
    "t3nrps-iterative",
}


def is_nrps_product(product: str) -> bool:
    p = product.strip().lower()
    return (
        p in NRPS_EXACT_PRODUCTS
        or p.startswith("nrps-")
        or p.endswith("-nrps")
        or p.startswith("nrp-")
        or p.endswith("-nrp")
        or "nonribosomal" in p
    )


def load_taxa(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {}
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        data = json.load(handle)
    if isinstance(data, dict):
        mappings = data.get("mappings", data)
        return mappings if isinstance(mappings, dict) else {}
    return {}


def first(value: Any, default: str = "") -> str:
    return str(value[0]) if isinstance(value, list) and value else default


def clean_sequence(value: str) -> str:
    return re.sub(r"[^A-Za-z*]", "", value).upper().rstrip("*")


def parse_location(text: Any) -> tuple[int | None, int | None, int]:
    raw = str(text)
    match = re.search(r"\[(\d+):(\d+)\]", raw)
    if not match:
        return None, None, 0
    strand = -1 if raw.endswith("(-)") else 1 if raw.endswith("(+)") else 0
    return int(match.group(1)), int(match.group(2)), strand


def overlaps(start1: int, end1: int, start2: int, end2: int) -> bool:
    return end1 > start2 and end2 > start1


def wrap_fasta(sequence: str, width: int = 80) -> str:
    return "\n".join(sequence[i:i + width] for i in range(0, len(sequence), width))


def safe_id(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.|:=+-]+", "_", text)


def short_hash(parts: Iterable[Any]) -> str:
    payload = "\x1f".join(str(x) for x in parts)
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()[:12]


def normalize_component(raw: Any, owner_cds: str) -> dict[str, Any] | None:
    """
    antiSMASH schema 4 commonly stores:
      {"domain": {...hit...}, "locus": "CDS"}
    while some outputs store the hit directly.
    """
    if not isinstance(raw, dict):
        return None

    if isinstance(raw.get("domain"), dict):
        component = dict(raw["domain"])
        component.setdefault("locus", raw.get("locus", owner_cds))
        for key in ("active", "subtype", "type"):
            if key in raw and key not in component:
                component[key] = raw[key]
    else:
        component = dict(raw)
        component.setdefault("locus", owner_cds)

    if "query_start" not in component or "query_end" not in component:
        return None

    try:
        component["query_start"] = int(component["query_start"])
        component["query_end"] = int(component["query_end"])
    except (TypeError, ValueError):
        return None

    component["locus"] = str(component.get("locus") or owner_cds)
    component["hit_id"] = str(component.get("hit_id") or "?")
    return component


def is_a_loader(hit_id: str) -> bool:
    return "AMP-binding" in hit_id or hit_id in {
        "A-OX", "CAL_domain", "CoA-ligase"
    }


def is_pks_loader(hit_id: str) -> bool:
    return hit_id in {"PKS_AT", "PKS_AT2", "AT"}


def is_carrier(hit_id: str) -> bool:
    return hit_id in {"PCP", "PP-binding", "ACP", "ACP_beta", "ACP-like"}


def module_family(components: list[dict[str, Any]]) -> str:
    hits = [str(c.get("hit_id", "")) for c in components]
    has_nrps = any(is_a_loader(hit) for hit in hits)
    has_pks = any(
        is_pks_loader(hit)
        or "PKS_KS" in hit
        or hit in {"Ketosynthase", "KS"}
        for hit in hits
    )
    if has_nrps and has_pks:
        return "HYBRID"
    if has_nrps:
        return "NRPS"
    if has_pks:
        return "PKS"
    return "OTHER"


def unique_in_order(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result


def tax_id_from_record(record: dict[str, Any]) -> str:
    for feature in record.get("features", []):
        if feature.get("type") != "source":
            continue
        qualifiers = feature.get("qualifiers", {})
        for item in qualifiers.get("db_xref", []):
            match = re.match(r"taxon:(\d+)", str(item))
            if match:
                return match.group(1)
    return ""


def taxonomy_fields(record: dict[str, Any], taxa: dict[str, Any]) -> dict[str, Any]:
    tax_id = tax_id_from_record(record)
    metadata = taxa.get(tax_id, {}) if tax_id else {}
    if not isinstance(metadata, dict):
        metadata = {}
    return {
        "tax_id": tax_id,
        "organism": metadata.get("name", ""),
        "species": metadata.get("species", ""),
        "genus": metadata.get("genus", ""),
        "family": metadata.get("family", ""),
        "order": metadata.get("order", ""),
        "class": metadata.get("class", ""),
        "phylum": metadata.get("phylum", ""),
        "kingdom": metadata.get("kingdom", ""),
        "superkingdom": metadata.get("superkingdom", ""),
    }


class GzipTSV:
    def __init__(self, path: Path, fields: list[str]):
        self.handle = gzip.open(path, "wt", encoding="utf-8", newline="")
        self.writer = csv.DictWriter(
            self.handle,
            fieldnames=fields,
            delimiter="\t",
            extrasaction="ignore",
        )
        self.writer.writeheader()

    def write(self, row: dict[str, Any]) -> None:
        self.writer.writerow(row)

    def close(self) -> None:
        self.handle.close()


class GzipFASTA:
    def __init__(self, path: Path):
        self.handle = gzip.open(path, "wt", encoding="utf-8")

    def write(self, header: str, sequence: str) -> None:
        self.handle.write(f">{header}\n")
        self.handle.write(wrap_fasta(sequence))
        self.handle.write("\n")

    def close(self) -> None:
        self.handle.close()


class GzipJSONL:
    def __init__(self, path: Path):
        self.handle = gzip.open(path, "wt", encoding="utf-8")

    def write(self, obj: dict[str, Any]) -> None:
        self.handle.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
        self.handle.write("\n")

    def close(self) -> None:
        self.handle.close()


def prepare_output(out_dir: Path, overwrite: bool) -> None:
    if out_dir.exists():
        if not overwrite:
            raise SystemExit(
                f"Output directory already exists: {out_dir}\n"
                "Use --overwrite to replace it."
            )
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True)


def find_area_for_cds(
    cds: dict[str, Any], areas: list[dict[str, Any]]
) -> dict[str, Any] | None:
    start = cds.get("start_nt")
    end = cds.get("end_nt")
    if start is None or end is None:
        return None
    for area in areas:
        if overlaps(int(start), int(end), int(area["start"]), int(area["end"])):
            return area
    return None


def build_cds_maps(record: dict[str, Any]) -> tuple[
    dict[str, dict[str, Any]], dict[str, str], dict[str, dict[str, Any]]
]:
    """
    Returns:
      alias_to_cds
      alias_to_canonical
      canonical_to_cds
    """
    alias_to_cds: dict[str, dict[str, Any]] = {}
    alias_to_canonical: dict[str, str] = {}
    canonical_to_cds: dict[str, dict[str, Any]] = {}

    for feature in record.get("features", []):
        if feature.get("type") != "CDS":
            continue
        q = feature.get("qualifiers", {})
        locus_tag = first(q.get("locus_tag"))
        gene = first(q.get("gene"))
        protein_id = first(q.get("protein_id"))
        canonical = locus_tag or protein_id or gene
        if not canonical:
            continue

        start_nt, end_nt, strand = parse_location(feature.get("location"))
        entry = {
            "canonical": canonical,
            "locus_tag": locus_tag,
            "gene": gene,
            "protein_id": protein_id,
            "product": first(q.get("product")),
            "translation": clean_sequence(first(q.get("translation"))),
            "start_nt": start_nt,
            "end_nt": end_nt,
            "strand": strand,
        }
        canonical_to_cds.setdefault(canonical, entry)
        for alias in {canonical, locus_tag, gene, protein_id}:
            if alias:
                alias_to_cds.setdefault(alias, entry)
                alias_to_canonical.setdefault(alias, canonical)

    return alias_to_cds, alias_to_canonical, canonical_to_cds


def resolve_locus(alias: str, alias_to_canonical: dict[str, str], fallback: str) -> str:
    return alias_to_canonical.get(alias, alias or fallback)


def area_prediction_key(area: dict[str, Any]) -> str:
    return str(area.get("prediction_key", area["index"]))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tar", required=True, type=Path)
    parser.add_argument("--taxa-json", type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument(
        "--max-members",
        type=int,
        default=0,
        help="Process at most this many JSON members; 0 means all.",
    )
    parser.add_argument("--log-every", type=int, default=100)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    prepare_output(args.out_dir, args.overwrite)
    taxa = load_taxa(args.taxa_json)

    tsv = {
        "genomes": GzipTSV(args.out_dir / "genomes.tsv.gz", [
            "accession", "antismash_version", "schema", "record_count",
            "nrps_area_count", "modular_protein_count", "assembly_line_count",
        ]),
        "areas": GzipTSV(args.out_dir / "areas.tsv.gz", [
            "accession", "record_id", "area_index", "prediction_key",
            "start_nt_0based", "end_nt_0based_exclusive", "products",
            "tax_id", "organism", "species", "genus", "family", "order",
            "class", "phylum", "kingdom", "superkingdom",
        ]),
        "proteins": GzipTSV(args.out_dir / "proteins.tsv.gz", [
            "protein_uid", "accession", "record_id", "area_index",
            "cds_name", "locus_tag", "gene", "protein_id", "product",
            "start_nt_0based", "end_nt_0based_exclusive", "strand",
            "length_aa", "reported_module_count", "component_only",
            "contains_nrps_module", "module_families",
        ]),
        "modules": GzipTSV(args.out_dir / "modules.tsv.gz", [
            "module_uid", "accession", "record_id", "area_index",
            "owner_cds", "reported_module_index", "first_in_cds",
            "module_family", "multi_cds", "component_loci",
            "segment_count", "component_count", "component_architecture",
            "has_loader", "has_carrier", "operational_complete",
            "contiguous_sequence_available", "contiguous_locus",
            "start_aa_0based", "end_aa_0based_exclusive", "length_aa",
            "predicted_monomers",
        ]),
        "module_segments": GzipTSV(args.out_dir / "module_segments.tsv.gz", [
            "module_uid", "segment_index", "locus", "protein_uid",
            "start_aa_0based", "end_aa_0based_exclusive", "length_aa",
            "component_count", "component_architecture",
        ]),
        "domains": GzipTSV(args.out_dir / "domains.tsv.gz", [
            "domain_uid", "accession", "record_id", "area_index",
            "locus", "protein_uid", "hit_id",
            "start_aa_0based", "end_aa_0based_exclusive", "length_aa",
            "evalue", "bitscore", "antismash_domain_key",
            "predicted_monomer_consensus",
        ]),
        "module_domains": GzipTSV(args.out_dir / "module_domains.tsv.gz", [
            "module_uid", "component_order", "domain_uid", "locus",
            "hit_id", "start_aa_0based", "end_aa_0based_exclusive",
        ]),
        "consensus": GzipTSV(args.out_dir / "substrate_consensus.tsv.gz", [
            "accession", "record_id", "domain_key", "locus",
            "predicted_monomer",
        ]),
        "region_predictions": GzipTSV(args.out_dir / "region_predictions.tsv.gz", [
            "assembly_line_id", "accession", "record_id", "area_index",
            "prediction_index", "sc_number", "polymer", "smiles",
            "docking_used", "ordering_source", "protein_ordering",
        ]),
        "assembly_lines": GzipTSV(args.out_dir / "assembly_lines.tsv.gz", [
            "assembly_line_id", "accession", "record_id", "area_index",
            "prediction_index", "polymer", "smiles", "docking_used",
            "ordering_source", "protein_count", "module_count",
            "chain_break_count",
        ]),
        "assembly_line_proteins": GzipTSV(
            args.out_dir / "assembly_line_proteins.tsv.gz",
            [
                "assembly_line_id", "protein_order", "protein_uid",
                "cds_name", "length_aa", "reported_module_count",
                "chain_break_after",
            ],
        ),
        "assembly_line_modules": GzipTSV(
            args.out_dir / "assembly_line_modules.tsv.gz",
            [
                "assembly_line_id", "global_module_index",
                "protein_order", "owner_cds", "reported_module_index",
                "module_uid", "module_family", "multi_cds",
                "predicted_monomers",
            ],
        ),
        "transitions": GzipTSV(args.out_dir / "assembly_line_transitions.tsv.gz", [
            "transition_uid", "assembly_line_id",
            "left_global_module_index", "right_global_module_index",
            "left_module_uid", "right_module_uid",
            "left_owner_cds", "right_owner_cds",
            "transition_type", "sequence_available",
            "start_aa_0based", "end_aa_0based_exclusive", "length_aa",
            "left_terminal_component", "right_initial_component",
        ]),
        "linkers": GzipTSV(args.out_dir / "inter_module_linkers.tsv.gz", [
            "transition_uid", "assembly_line_id",
            "accession", "record_id", "area_index", "cds_name",
            "left_global_module_index", "right_global_module_index",
            "left_module_uid", "right_module_uid",
            "start_aa_0based", "end_aa_0based_exclusive", "length_aa",
            "left_terminal_component", "right_initial_component",
            "interpretation",
        ]),
        "gaps": GzipTSV(args.out_dir / "inter_component_gaps.tsv.gz", [
            "module_uid", "locus", "left_domain_uid", "right_domain_uid",
            "left_component", "right_component",
            "start_aa_0based", "end_aa_0based_exclusive", "length_aa",
            "interpretation",
        ]),
        "flanks": GzipTSV(args.out_dir / "terminal_flanks.tsv.gz", [
            "protein_uid", "accession", "record_id", "area_index",
            "cds_name", "flank_type", "start_aa_0based",
            "end_aa_0based_exclusive", "length_aa",
        ]),
    }

    fasta = {
        "proteins": GzipFASTA(args.out_dir / "proteins.fasta.gz"),
        "modules": GzipFASTA(args.out_dir / "contiguous_modules.fasta.gz"),
        "segments": GzipFASTA(args.out_dir / "module_segments.fasta.gz"),
        "domains": GzipFASTA(args.out_dir / "domains.fasta.gz"),
        "assembly_proteins": GzipFASTA(
            args.out_dir / "assembly_line_proteins.fasta.gz"
        ),
        "linkers": GzipFASTA(args.out_dir / "inter_module_linkers.fasta.gz"),
        "gaps": GzipFASTA(args.out_dir / "inter_component_gaps.fasta.gz"),
        "flanks": GzipFASTA(args.out_dir / "terminal_flanks.fasta.gz"),
    }

    raw_predictions = GzipJSONL(args.out_dir / "domain_predictions.jsonl.gz")
    counts = Counter()
    family_counts = Counter()
    started = time.time()

    try:
        with tarfile.open(args.tar, mode="r|") as tar:
            for member in tar:
                if not member.isfile() or not member.name.endswith(".json.gz"):
                    continue

                if args.max_members and counts["json_members_seen"] >= args.max_members:
                    break
                counts["json_members_seen"] += 1

                extracted = tar.extractfile(member)
                if extracted is None:
                    counts["tar_member_read_errors"] += 1
                    continue

                accession = Path(member.name).name.removesuffix(".json.gz")
                try:
                    with gzip.GzipFile(fileobj=extracted, mode="rb") as gz:
                        data = json.load(io.TextIOWrapper(gz, encoding="utf-8"))
                except Exception as exc:
                    counts["json_parse_errors"] += 1
                    print(f"[WARN] {accession}: {exc}", file=sys.stderr)
                    continue

                accession_area_count = 0
                accession_protein_count = 0
                accession_line_count = 0

                for record in data.get("records", []):
                    record_id = str(record.get("id", ""))
                    tax = taxonomy_fields(record, taxa)
                    alias_to_cds, alias_to_canonical, canonical_to_cds = build_cds_maps(record)

                    software = record.get("modules", {})
                    detection = software.get(
                        "antismash.detection.nrps_pks_domains", {}
                    )
                    cds_results = (
                        detection.get("cds_results", {})
                        if isinstance(detection, dict)
                        else {}
                    )
                    prediction_block = software.get("antismash.modules.nrps_pks", {})
                    if not isinstance(prediction_block, dict):
                        prediction_block = {}
                    consensus = prediction_block.get("consensus", {})
                    if not isinstance(consensus, dict):
                        consensus = {}
                    region_predictions = prediction_block.get("region_predictions", {})
                    if not isinstance(region_predictions, dict):
                        region_predictions = {}
                    domain_predictions = prediction_block.get("domain_predictions", {})
                    if not isinstance(domain_predictions, dict):
                        domain_predictions = {}

                    nrps_areas: list[dict[str, Any]] = []
                    for area_index, area in enumerate(record.get("areas", []), start=1):
                        products = [str(p) for p in area.get("products", [])]
                        if not any(is_nrps_product(p) for p in products):
                            continue
                        prediction_key = str(area.get("number", area_index))
                        area_obj = {
                            "index": area_index,
                            "prediction_key": prediction_key,
                            "start": int(area["start"]),
                            "end": int(area["end"]),
                            "products": products,
                        }
                        nrps_areas.append(area_obj)
                        accession_area_count += 1
                        counts["nrps_areas"] += 1
                        tsv["areas"].write({
                            "accession": accession,
                            "record_id": record_id,
                            "area_index": area_index,
                            "prediction_key": prediction_key,
                            "start_nt_0based": area["start"],
                            "end_nt_0based_exclusive": area["end"],
                            "products": ";".join(products),
                            **tax,
                        })

                    if not nrps_areas:
                        continue

                    # Parse modules reported by antiSMASH, preserving owner CDS and
                    # component loci. This is critical for multi-CDS modules.
                    modules_by_owner: dict[str, list[dict[str, Any]]] = defaultdict(list)
                    all_modules: list[dict[str, Any]] = []
                    involved_loci: set[str] = set()

                    for owner_alias, result in sorted(cds_results.items()):
                        if not isinstance(result, dict):
                            continue
                        owner = resolve_locus(
                            str(owner_alias), alias_to_canonical, str(owner_alias)
                        )
                        owner_cds = canonical_to_cds.get(owner)
                        if not owner_cds:
                            counts["module_owner_cds_missing"] += 1
                            continue
                        area = find_area_for_cds(owner_cds, nrps_areas)
                        if area is None:
                            continue

                        for reported_index, raw_module in enumerate(
                            result.get("modules", []), start=1
                        ):
                            if not isinstance(raw_module, dict):
                                continue

                            components: list[dict[str, Any]] = []
                            for raw_component in raw_module.get("components", []):
                                component = normalize_component(raw_component, owner)
                                if component is None:
                                    counts["non_domain_components_skipped"] += 1
                                    continue
                                component["locus"] = resolve_locus(
                                    str(component.get("locus", owner)),
                                    alias_to_canonical,
                                    owner,
                                )
                                components.append(component)

                            if not components:
                                continue

                            component_signature = [
                                (
                                    c["locus"], c["hit_id"],
                                    c["query_start"], c["query_end"]
                                )
                                for c in components
                            ]
                            module_uid = (
                                f"{safe_id(accession)}|{safe_id(record_id)}|"
                                f"{safe_id(owner)}|m{reported_index}|"
                                f"{short_hash(component_signature)}"
                            )
                            family = module_family(components)
                            loci = unique_in_order(
                                str(c["locus"]) for c in components
                            )
                            module_obj = {
                                "uid": module_uid,
                                "owner": owner,
                                "reported_index": reported_index,
                                "first_in_cds": raw_module.get("first_in_cds", ""),
                                "components": components,
                                "family": family,
                                "loci": loci,
                                "area": area,
                            }
                            modules_by_owner[owner].append(module_obj)
                            all_modules.append(module_obj)
                            involved_loci.add(owner)
                            involved_loci.update(loci)

                    if not all_modules:
                        continue

                    # Precompute A-domain numbering and consensus per protein.
                    a_components_by_locus: dict[str, dict[tuple[int, int], dict[str, Any]]] = defaultdict(dict)
                    for module in all_modules:
                        for component in module["components"]:
                            if "AMP-binding" in str(component["hit_id"]):
                                key = (
                                    int(component["query_start"]),
                                    int(component["query_end"]),
                                )
                                a_components_by_locus[component["locus"]][key] = component

                    a_domain_lookup: dict[tuple[str, int, int], tuple[str, str]] = {}
                    for locus, coord_map in a_components_by_locus.items():
                        ordered = sorted(coord_map)
                        for ordinal, (start, end) in enumerate(ordered, start=1):
                            domain_key = (
                                f"nrpspksdomains_{locus}_AMP-binding.{ordinal}"
                            )
                            monomer = str(consensus.get(domain_key, ""))
                            a_domain_lookup[(locus, start, end)] = (
                                domain_key, monomer
                            )
                            tsv["consensus"].write({
                                "accession": accession,
                                "record_id": record_id,
                                "domain_key": domain_key,
                                "locus": locus,
                                "predicted_monomer": monomer,
                            })

                    # Preserve all raw prediction objects for involved NRPS/PKS
                    # proteins. No method-specific information is discarded.
                    for domain_key, prediction_value in domain_predictions.items():
                        key_text = str(domain_key)
                        matched_locus = ""
                        for locus in sorted(involved_loci, key=len, reverse=True):
                            if locus in key_text:
                                matched_locus = locus
                                break
                        if not matched_locus:
                            continue
                        raw_predictions.write({
                            "accession": accession,
                            "record_id": record_id,
                            "domain_key": key_text,
                            "locus": matched_locus,
                            "prediction": prediction_value,
                        })
                        counts["raw_domain_prediction_records"] += 1

                    # Write involved protein records once.
                    protein_written: set[str] = set()
                    protein_uid_by_locus: dict[str, str] = {}
                    module_families_by_locus: dict[str, list[str]] = defaultdict(list)
                    owner_loci = set(modules_by_owner)
                    for module in all_modules:
                        for locus in module["loci"]:
                            module_families_by_locus[locus].append(module["family"])

                    for locus in sorted(involved_loci):
                        cds = canonical_to_cds.get(locus)
                        if not cds or not cds.get("translation"):
                            counts["missing_cds_translation"] += 1
                            continue
                        area = find_area_for_cds(cds, nrps_areas)
                        if area is None:
                            # Component-only locus can be adjacent to the owner and
                            # still belong to the same module. Assign owner's area.
                            candidate = next(
                                (
                                    m["area"] for m in all_modules
                                    if locus in m["loci"]
                                ),
                                None,
                            )
                            area = candidate
                        if area is None:
                            counts["component_locus_without_area"] += 1
                            continue

                        protein_uid = (
                            f"{safe_id(accession)}|{safe_id(record_id)}|"
                            f"{safe_id(locus)}"
                        )
                        protein_uid_by_locus[locus] = protein_uid
                        if protein_uid in protein_written:
                            continue
                        protein_written.add(protein_uid)

                        families = unique_in_order(
                            module_families_by_locus.get(locus, [])
                        )
                        contains_nrps = any(
                            family in {"NRPS", "HYBRID"} for family in families
                        )
                        reported_count = len(modules_by_owner.get(locus, []))
                        tsv["proteins"].write({
                            "protein_uid": protein_uid,
                            "accession": accession,
                            "record_id": record_id,
                            "area_index": area["index"],
                            "cds_name": locus,
                            "locus_tag": cds.get("locus_tag", ""),
                            "gene": cds.get("gene", ""),
                            "protein_id": cds.get("protein_id", ""),
                            "product": cds.get("product", ""),
                            "start_nt_0based": cds.get("start_nt", ""),
                            "end_nt_0based_exclusive": cds.get("end_nt", ""),
                            "strand": cds.get("strand", ""),
                            "length_aa": len(cds["translation"]),
                            "reported_module_count": reported_count,
                            "component_only": locus not in owner_loci,
                            "contains_nrps_module": contains_nrps,
                            "module_families": ";".join(families),
                        })
                        fasta["proteins"].write(
                            f"{protein_uid}|area={area['index']}|"
                            f"full_protein|length={len(cds['translation'])}|"
                            f"component_only={locus not in owner_loci}",
                            cds["translation"],
                        )
                        counts["proteins"] += 1
                        accession_protein_count += 1

                    # Write normalized modules/domains/segments.
                    domain_written: set[str] = set()
                    module_by_uid: dict[str, dict[str, Any]] = {}
                    module_monomers: dict[str, list[str]] = {}
                    module_contiguous_span: dict[str, tuple[str, int, int] | None] = {}
                    module_terminal_hits: dict[str, tuple[str, str]] = {}

                    for module in all_modules:
                        components = module["components"]
                        family = module["family"]
                        family_counts[family] += 1
                        counts["modules"] += 1

                        predicted_monomers: list[str] = []
                        for component in components:
                            lookup = a_domain_lookup.get((
                                component["locus"],
                                int(component["query_start"]),
                                int(component["query_end"]),
                            ))
                            if lookup:
                                predicted_monomers.append(lookup[1] or "X")
                        module_monomers[module["uid"]] = predicted_monomers

                        loci = module["loci"]
                        multi_cds = len(loci) > 1
                        has_loader = any(
                            is_a_loader(c["hit_id"]) or is_pks_loader(c["hit_id"])
                            for c in components
                        )
                        has_carrier = any(
                            is_carrier(c["hit_id"]) for c in components
                        )
                        complete = has_loader and has_carrier
                        architecture = "->".join(c["hit_id"] for c in components)
                        module_terminal_hits[module["uid"]] = (
                            components[0]["hit_id"],
                            components[-1]["hit_id"],
                        )

                        segments: list[dict[str, Any]] = []
                        for locus in loci:
                            locus_components = [
                                c for c in components if c["locus"] == locus
                            ]
                            cds = canonical_to_cds.get(locus)
                            if not cds or not cds.get("translation"):
                                counts["missing_segment_translation"] += 1
                                continue
                            start = min(int(c["query_start"]) for c in locus_components)
                            end = max(int(c["query_end"]) for c in locus_components)
                            if start < 0 or end > len(cds["translation"]) or end <= start:
                                counts["coordinate_warnings"] += 1
                                continue
                            segments.append({
                                "locus": locus,
                                "start": start,
                                "end": end,
                                "components": locus_components,
                                "sequence": cds["translation"][start:end],
                            })

                        contiguous = len(segments) == 1 and not multi_cds
                        contiguous_locus = segments[0]["locus"] if contiguous else ""
                        start = segments[0]["start"] if contiguous else ""
                        end = segments[0]["end"] if contiguous else ""
                        length = (
                            segments[0]["end"] - segments[0]["start"]
                            if contiguous else ""
                        )
                        module_contiguous_span[module["uid"]] = (
                            (contiguous_locus, int(start), int(end))
                            if contiguous else None
                        )

                        tsv["modules"].write({
                            "module_uid": module["uid"],
                            "accession": accession,
                            "record_id": record_id,
                            "area_index": module["area"]["index"],
                            "owner_cds": module["owner"],
                            "reported_module_index": module["reported_index"],
                            "first_in_cds": module["first_in_cds"],
                            "module_family": family,
                            "multi_cds": multi_cds,
                            "component_loci": ";".join(loci),
                            "segment_count": len(segments),
                            "component_count": len(components),
                            "component_architecture": architecture,
                            "has_loader": has_loader,
                            "has_carrier": has_carrier,
                            "operational_complete": complete,
                            "contiguous_sequence_available": contiguous,
                            "contiguous_locus": contiguous_locus,
                            "start_aa_0based": start,
                            "end_aa_0based_exclusive": end,
                            "length_aa": length,
                            "predicted_monomers": ";".join(predicted_monomers),
                        })

                        if contiguous:
                            fasta["modules"].write(
                                f"{module['uid']}|family={family}|"
                                f"locus={contiguous_locus}|coords={start}:{end}|"
                                f"monomers={';'.join(predicted_monomers) or '-'}",
                                segments[0]["sequence"],
                            )
                            counts["contiguous_module_sequences"] += 1
                        else:
                            counts["multi_cds_modules"] += 1

                        for segment_index, segment in enumerate(segments, start=1):
                            segment_architecture = "->".join(
                                c["hit_id"] for c in segment["components"]
                            )
                            protein_uid = protein_uid_by_locus.get(
                                segment["locus"], ""
                            )
                            tsv["module_segments"].write({
                                "module_uid": module["uid"],
                                "segment_index": segment_index,
                                "locus": segment["locus"],
                                "protein_uid": protein_uid,
                                "start_aa_0based": segment["start"],
                                "end_aa_0based_exclusive": segment["end"],
                                "length_aa": segment["end"] - segment["start"],
                                "component_count": len(segment["components"]),
                                "component_architecture": segment_architecture,
                            })
                            fasta["segments"].write(
                                f"{module['uid']}|segment={segment_index}|"
                                f"locus={segment['locus']}|"
                                f"coords={segment['start']}:{segment['end']}",
                                segment["sequence"],
                            )
                            counts["module_segments"] += 1

                        # Domains and module-domain relations.
                        domain_ids_in_order: list[str] = []
                        for component_order, component in enumerate(
                            components, start=1
                        ):
                            locus = component["locus"]
                            cds = canonical_to_cds.get(locus)
                            if not cds or not cds.get("translation"):
                                counts["missing_domain_translation"] += 1
                                continue
                            dstart = int(component["query_start"])
                            dend = int(component["query_end"])
                            if dstart < 0 or dend > len(cds["translation"]) or dend <= dstart:
                                counts["coordinate_warnings"] += 1
                                continue

                            domain_uid = (
                                f"{safe_id(accession)}|{safe_id(record_id)}|"
                                f"{safe_id(locus)}|{safe_id(component['hit_id'])}|"
                                f"{dstart}:{dend}"
                            )
                            domain_ids_in_order.append(domain_uid)
                            lookup = a_domain_lookup.get((locus, dstart, dend))
                            antismash_domain_key = lookup[0] if lookup else ""
                            monomer = lookup[1] if lookup else ""

                            if domain_uid not in domain_written:
                                domain_written.add(domain_uid)
                                tsv["domains"].write({
                                    "domain_uid": domain_uid,
                                    "accession": accession,
                                    "record_id": record_id,
                                    "area_index": module["area"]["index"],
                                    "locus": locus,
                                    "protein_uid": protein_uid_by_locus.get(locus, ""),
                                    "hit_id": component["hit_id"],
                                    "start_aa_0based": dstart,
                                    "end_aa_0based_exclusive": dend,
                                    "length_aa": dend - dstart,
                                    "evalue": component.get("evalue", ""),
                                    "bitscore": component.get("bitscore", ""),
                                    "antismash_domain_key": antismash_domain_key,
                                    "predicted_monomer_consensus": monomer,
                                })
                                fasta["domains"].write(
                                    f"{domain_uid}|monomer={monomer or '-'}",
                                    cds["translation"][dstart:dend],
                                )
                                counts["unique_domains"] += 1

                            tsv["module_domains"].write({
                                "module_uid": module["uid"],
                                "component_order": component_order,
                                "domain_uid": domain_uid,
                                "locus": locus,
                                "hit_id": component["hit_id"],
                                "start_aa_0based": dstart,
                                "end_aa_0based_exclusive": dend,
                            })
                            counts["module_domain_links"] += 1

                        # Internal gaps only when adjacent components are on the
                        # same protein. Cross-protein adjacency is a chain break.
                        for left, right in zip(components, components[1:]):
                            if left["locus"] != right["locus"]:
                                counts["within_module_chain_breaks"] += 1
                                continue
                            gap_start = int(left["query_end"])
                            gap_end = int(right["query_start"])
                            if gap_end < gap_start:
                                counts["overlapping_components"] += 1
                                continue
                            locus = left["locus"]
                            cds = canonical_to_cds.get(locus)
                            if not cds or not cds.get("translation"):
                                continue
                            left_uid = (
                                f"{safe_id(accession)}|{safe_id(record_id)}|"
                                f"{safe_id(locus)}|{safe_id(left['hit_id'])}|"
                                f"{left['query_start']}:{left['query_end']}"
                            )
                            right_uid = (
                                f"{safe_id(accession)}|{safe_id(record_id)}|"
                                f"{safe_id(locus)}|{safe_id(right['hit_id'])}|"
                                f"{right['query_start']}:{right['query_end']}"
                            )
                            tsv["gaps"].write({
                                "module_uid": module["uid"],
                                "locus": locus,
                                "left_domain_uid": left_uid,
                                "right_domain_uid": right_uid,
                                "left_component": left["hit_id"],
                                "right_component": right["hit_id"],
                                "start_aa_0based": gap_start,
                                "end_aa_0based_exclusive": gap_end,
                                "length_aa": gap_end - gap_start,
                                "interpretation":
                                    "inter_component_gap_not_validated_linker",
                            })
                            fasta["gaps"].write(
                                f"{module['uid']}|locus={locus}|"
                                f"gap={left['hit_id']}__{right['hit_id']}|"
                                f"coords={gap_start}:{gap_end}|"
                                f"NOT_VALIDATED_LINKER",
                                cds["translation"][gap_start:gap_end],
                            )
                            counts["inter_component_gaps"] += 1

                        module_by_uid[module["uid"]] = module

                    # Terminal flanks are based on all module segments present on
                    # each protein, not on owner modules only.
                    segments_by_locus: dict[str, list[tuple[int, int]]] = defaultdict(list)
                    for module in all_modules:
                        span = module_contiguous_span.get(module["uid"])
                        if span:
                            locus, start, end = span
                            segments_by_locus[locus].append((start, end))
                        else:
                            for locus in module["loci"]:
                                comps = [
                                    c for c in module["components"]
                                    if c["locus"] == locus
                                ]
                                if comps:
                                    segments_by_locus[locus].append((
                                        min(int(c["query_start"]) for c in comps),
                                        max(int(c["query_end"]) for c in comps),
                                    ))

                    for locus, spans in segments_by_locus.items():
                        cds = canonical_to_cds.get(locus)
                        protein_uid = protein_uid_by_locus.get(locus, "")
                        if not cds or not cds.get("translation") or not protein_uid:
                            continue
                        first_start = min(s for s, _ in spans)
                        last_end = max(e for _, e in spans)
                        for flank_type, fstart, fend in (
                            ("n_terminal_flank", 0, first_start),
                            ("c_terminal_flank", last_end, len(cds["translation"])),
                        ):
                            tsv["flanks"].write({
                                "protein_uid": protein_uid,
                                "accession": accession,
                                "record_id": record_id,
                                "area_index": (
                                    find_area_for_cds(cds, nrps_areas) or
                                    all_modules[0]["area"]
                                )["index"],
                                "cds_name": locus,
                                "flank_type": flank_type,
                                "start_aa_0based": fstart,
                                "end_aa_0based_exclusive": fend,
                                "length_aa": fend - fstart,
                            })
                            fasta["flanks"].write(
                                f"{protein_uid}|{flank_type}|"
                                f"coords={fstart}:{fend}",
                                cds["translation"][fstart:fend],
                            )
                            counts["terminal_flanks"] += 1

                    # Build explicit assembly-line alternatives from antiSMASH
                    # region_predictions. If absent, preserve a clearly marked
                    # genomic fallback rather than pretending the order is known.
                    for area in nrps_areas:
                        area_modules = [
                            m for m in all_modules
                            if m["area"]["index"] == area["index"]
                        ]
                        if not area_modules:
                            continue
                        area_owners = unique_in_order(m["owner"] for m in area_modules)

                        predictions = region_predictions.get(
                            area_prediction_key(area), []
                        )
                        if not isinstance(predictions, list):
                            predictions = []

                        prediction_entries: list[dict[str, Any]] = []
                        if predictions:
                            for prediction_index, prediction in enumerate(
                                predictions, start=1
                            ):
                                if not isinstance(prediction, dict):
                                    continue
                                ordering = [
                                    resolve_locus(str(x), alias_to_canonical, str(x))
                                    for x in prediction.get("ordering", [])
                                ]
                                prediction_entries.append({
                                    "prediction_index": prediction_index,
                                    "prediction": prediction,
                                    "ordering": ordering,
                                    "ordering_source": "antiSMASH_region_prediction",
                                })
                        else:
                            fallback = sorted(
                                area_owners,
                                key=lambda locus: (
                                    canonical_to_cds.get(locus, {}).get("start_nt")
                                    if canonical_to_cds.get(locus, {}).get("start_nt")
                                    is not None else 10**18
                                ),
                            )
                            prediction_entries.append({
                                "prediction_index": 1,
                                "prediction": {},
                                "ordering": fallback,
                                "ordering_source":
                                    "genomic_fallback_unvalidated",
                            })
                            counts["assembly_lines_without_region_prediction"] += 1

                        for entry in prediction_entries:
                            prediction = entry["prediction"]
                            ordering = unique_in_order(entry["ordering"])

                            # Preserve modular proteins omitted from a prediction,
                            # but mark the order as augmented.
                            omitted = [owner for owner in area_owners if owner not in ordering]
                            if omitted:
                                ordering.extend(omitted)
                                ordering_source = (
                                    entry["ordering_source"] +
                                    "+omitted_modular_proteins_appended"
                                )
                                counts["assembly_line_orderings_augmented"] += 1
                            else:
                                ordering_source = entry["ordering_source"]

                            assembly_line_id = (
                                f"{safe_id(accession)}|{safe_id(record_id)}|"
                                f"area={area['index']}|"
                                f"prediction={entry['prediction_index']}"
                            )

                            ordered_modules: list[tuple[int, dict[str, Any]]] = []
                            protein_rows_for_line: list[tuple[int, str]] = []
                            for protein_order, owner in enumerate(ordering, start=1):
                                if owner not in canonical_to_cds:
                                    counts["ordering_protein_missing"] += 1
                                    continue
                                protein_rows_for_line.append((protein_order, owner))
                                for module in modules_by_owner.get(owner, []):
                                    if module["area"]["index"] == area["index"]:
                                        ordered_modules.append((protein_order, module))

                            chain_break_count = max(0, len(protein_rows_for_line) - 1)
                            accession_line_count += 1
                            counts["assembly_lines"] += 1

                            tsv["region_predictions"].write({
                                "assembly_line_id": assembly_line_id,
                                "accession": accession,
                                "record_id": record_id,
                                "area_index": area["index"],
                                "prediction_index": entry["prediction_index"],
                                "sc_number": prediction.get("sc_number", ""),
                                "polymer": prediction.get("polymer", ""),
                                "smiles": prediction.get("smiles", ""),
                                "docking_used": prediction.get("docking_used", ""),
                                "ordering_source": ordering_source,
                                "protein_ordering": ";".join(ordering),
                            })
                            tsv["assembly_lines"].write({
                                "assembly_line_id": assembly_line_id,
                                "accession": accession,
                                "record_id": record_id,
                                "area_index": area["index"],
                                "prediction_index": entry["prediction_index"],
                                "polymer": prediction.get("polymer", ""),
                                "smiles": prediction.get("smiles", ""),
                                "docking_used": prediction.get("docking_used", ""),
                                "ordering_source": ordering_source,
                                "protein_count": len(protein_rows_for_line),
                                "module_count": len(ordered_modules),
                                "chain_break_count": chain_break_count,
                            })

                            for idx, (protein_order, owner) in enumerate(
                                protein_rows_for_line, start=1
                            ):
                                cds = canonical_to_cds[owner]
                                protein_uid = protein_uid_by_locus.get(owner, "")
                                tsv["assembly_line_proteins"].write({
                                    "assembly_line_id": assembly_line_id,
                                    "protein_order": protein_order,
                                    "protein_uid": protein_uid,
                                    "cds_name": owner,
                                    "length_aa": len(cds.get("translation", "")),
                                    "reported_module_count":
                                        len(modules_by_owner.get(owner, [])),
                                    "chain_break_after":
                                        idx < len(protein_rows_for_line),
                                })
                                if cds.get("translation"):
                                    fasta["assembly_proteins"].write(
                                        f"{assembly_line_id}|protein_order="
                                        f"{protein_order}|{owner}|"
                                        f"CHAIN_BREAK_AFTER="
                                        f"{idx < len(protein_rows_for_line)}",
                                        cds["translation"],
                                    )

                            for global_index, (protein_order, module) in enumerate(
                                ordered_modules, start=1
                            ):
                                tsv["assembly_line_modules"].write({
                                    "assembly_line_id": assembly_line_id,
                                    "global_module_index": global_index,
                                    "protein_order": protein_order,
                                    "owner_cds": module["owner"],
                                    "reported_module_index":
                                        module["reported_index"],
                                    "module_uid": module["uid"],
                                    "module_family": module["family"],
                                    "multi_cds": len(module["loci"]) > 1,
                                    "predicted_monomers":
                                        ";".join(module_monomers[module["uid"]]),
                                })

                            for transition_index, (
                                left_pair, right_pair
                            ) in enumerate(
                                zip(ordered_modules, ordered_modules[1:]),
                                start=1,
                            ):
                                left_global = transition_index
                                right_global = transition_index + 1
                                _, left = left_pair
                                _, right = right_pair
                                left_span = module_contiguous_span.get(left["uid"])
                                right_span = module_contiguous_span.get(right["uid"])
                                left_first, left_last = module_terminal_hits[left["uid"]]
                                right_first, right_last = module_terminal_hits[right["uid"]]

                                transition_type = ""
                                sequence_available = False
                                start_aa: int | str = ""
                                end_aa: int | str = ""
                                length_aa: int | str = ""
                                sequence = ""

                                if left["owner"] != right["owner"]:
                                    transition_type = "inter_protein_chain_break"
                                    counts["inter_protein_chain_breaks"] += 1
                                elif (
                                    left_span is None
                                    or right_span is None
                                    or left_span[0] != right_span[0]
                                ):
                                    transition_type = (
                                        "multi_cds_or_noncontiguous_module_boundary"
                                    )
                                    counts["unresolved_module_boundaries"] += 1
                                else:
                                    locus = left_span[0]
                                    start_aa = left_span[2]
                                    end_aa = right_span[1]
                                    if int(end_aa) < int(start_aa):
                                        transition_type = "overlapping_module_spans"
                                        counts["overlapping_modules"] += 1
                                    else:
                                        transition_type = (
                                            "inter_module_linker_candidate"
                                        )
                                        sequence_available = True
                                        length_aa = int(end_aa) - int(start_aa)
                                        cds = canonical_to_cds[locus]
                                        sequence = cds["translation"][
                                            int(start_aa):int(end_aa)
                                        ]
                                        counts[
                                            "inter_module_linker_candidates"
                                        ] += 1

                                transition_uid = (
                                    f"{assembly_line_id}|transition="
                                    f"{left_global}__{right_global}"
                                )
                                tsv["transitions"].write({
                                    "transition_uid": transition_uid,
                                    "assembly_line_id": assembly_line_id,
                                    "left_global_module_index": left_global,
                                    "right_global_module_index": right_global,
                                    "left_module_uid": left["uid"],
                                    "right_module_uid": right["uid"],
                                    "left_owner_cds": left["owner"],
                                    "right_owner_cds": right["owner"],
                                    "transition_type": transition_type,
                                    "sequence_available": sequence_available,
                                    "start_aa_0based": start_aa,
                                    "end_aa_0based_exclusive": end_aa,
                                    "length_aa": length_aa,
                                    "left_terminal_component": left_last,
                                    "right_initial_component": right_first,
                                })

                                if sequence_available:
                                    tsv["linkers"].write({
                                        "transition_uid": transition_uid,
                                        "assembly_line_id": assembly_line_id,
                                        "accession": accession,
                                        "record_id": record_id,
                                        "area_index": area["index"],
                                        "cds_name": left["owner"],
                                        "left_global_module_index": left_global,
                                        "right_global_module_index": right_global,
                                        "left_module_uid": left["uid"],
                                        "right_module_uid": right["uid"],
                                        "start_aa_0based": start_aa,
                                        "end_aa_0based_exclusive": end_aa,
                                        "length_aa": length_aa,
                                        "left_terminal_component": left_last,
                                        "right_initial_component": right_first,
                                        "interpretation":
                                            "inter_module_linker_candidate",
                                    })
                                    fasta["linkers"].write(
                                        f"{transition_uid}|locus={left['owner']}|"
                                        f"coords={start_aa}:{end_aa}",
                                        sequence,
                                    )

                if accession_area_count:
                    counts["genomes_with_nrps_area"] += 1
                    tsv["genomes"].write({
                        "accession": accession,
                        "antismash_version": data.get("version", ""),
                        "schema": data.get("schema", ""),
                        "record_count": len(data.get("records", [])),
                        "nrps_area_count": accession_area_count,
                        "modular_protein_count": accession_protein_count,
                        "assembly_line_count": accession_line_count,
                    })

                if (
                    args.log_every
                    and counts["json_members_seen"] % args.log_every == 0
                ):
                    elapsed = time.time() - started
                    rate = counts["json_members_seen"] / elapsed if elapsed else 0
                    print(
                        f"[{counts['json_members_seen']:,} members] "
                        f"NRPS genomes={counts['genomes_with_nrps_area']:,}, "
                        f"areas={counts['nrps_areas']:,}, "
                        f"assembly_lines={counts['assembly_lines']:,}, "
                        f"proteins={counts['proteins']:,}, "
                        f"modules={counts['modules']:,}, "
                        f"rate={rate:.2f} members/s",
                        flush=True,
                    )
    finally:
        for writer in tsv.values():
            writer.close()
        for writer in fasta.values():
            writer.close()
        raw_predictions.close()

    summary = {
        **dict(counts),
        "module_family_counts": dict(family_counts),
        "elapsed_seconds": round(time.time() - started, 2),
        "tar_path": str(args.tar),
        "taxa_json": str(args.taxa_json) if args.taxa_json else None,
        "coordinate_convention": "0-based, end-exclusive",
        "linker_policy": (
            "same-protein gaps between adjacent contiguous antiSMASH modules "
            "are candidates; cross-protein boundaries are chain breaks"
        ),
    }
    (args.out_dir / "qc_summary.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2))
    print(f"Outputs: {args.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
