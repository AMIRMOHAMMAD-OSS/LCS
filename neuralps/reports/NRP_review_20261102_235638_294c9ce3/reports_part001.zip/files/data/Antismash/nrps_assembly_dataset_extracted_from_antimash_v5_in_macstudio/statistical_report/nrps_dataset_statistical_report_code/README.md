# NRPS dataset statistical report

This script generates a supervisor-ready statistical report for the complete
antiSMASH assembly-line dataset and clearly defined training subsets.

## Install plotting dependency

```powershell
python -m pip install matplotlib
```

## Run on Windows

```powershell
python "$HOME\Downloads\nrps_dataset_statistical_report.py" `
  "C:\Users\ASUS\OneDrive\Desktop\NRP\Antismash\nrps_assembly_dataset_extracted_from_antimash_v5_in_macstudio"
```

The report will be created inside:

```text
...\nrps_assembly_dataset_extracted_from_antimash_v5_in_macstudio\statistical_report
```

Open:

```text
statistical_report\report.html
```

## Main subsets

- `clean_pure_nrps_general`: clean high-confidence pure-NRPS multi-module lines
- `covalent_linker_training`: all transitions are same-protein linker sequences
- `noncovalent_docking_training`: at least one inter-protein chain break

The report keeps prediction-record counts separate from deduplicated physical
junction counts.
