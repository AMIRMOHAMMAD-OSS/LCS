#!/usr/bin/env python3
"""
Create a comprehensive statistical report for the antiSMASH NRPS assembly-line
dataset v3.

The script streams the .tsv.gz files directly, so it does not require pandas
and does not decompress the dataset to disk.

Outputs:
- report.html
- summary.txt
- summary.json
- tables/*.csv
- plots/*.png

Recommended training subsets
----------------------------
1. clean_pure_nrps_general
   - at least two modules
   - every module is NRPS
   - every transition is either a same-protein linker candidate or an
     inter-protein chain break
   - no unresolved/noncontiguous or overlapping module boundary
   - ordering_source is exactly antiSMASH_region_prediction

2. covalent_linker_training
   - clean_pure_nrps_general
   - every transition is a same-protein linker candidate with a sequence

3. noncovalent_docking_training
   - clean_pure_nrps_general
   - contains at least one inter-protein chain break
   - terminal sequences remain separate; no fake linker is created

Usage on Windows:
    python nrps_dataset_statistical_report.py "C:\\path\\to\\dataset"

Optional:
    --out-dir "C:\\path\\to\\report"
    --top-n 20
"""

from __future__ import annotations

import argparse
import csv
import gzip
import html
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable


def open_tsv_gz(path: Path):
    with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
        yield from csv.DictReader(handle, delimiter="\t")


def as_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def as_bool(value: Any) -> bool:
    return str(value).strip().lower() == "true"


def percentage(numerator: int, denominator: int) -> float:
    return 100.0 * numerator / denominator if denominator else 0.0


def percentile(sorted_values: list[int], fraction: float) -> int | None:
    if not sorted_values:
        return None
    position = round((len(sorted_values) - 1) * fraction)
    return sorted_values[position]


def compact_bins(values: Iterable[int], maximum: int) -> Counter[str]:
    counter: Counter[str] = Counter()
    for value in values:
        if value <= maximum:
            counter[str(value)] += 1
        else:
            counter[f"{maximum + 1}+"] += 1
    return counter


def write_csv(path: Path, headers: list[str], rows: Iterable[Iterable[Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        writer.writerows(rows)


def write_counter_csv(path: Path, counter: Counter[str], label: str) -> None:
    write_csv(
        path,
        [label, "count"],
        counter.most_common(),
    )


def require_files(root: Path, filenames: list[str]) -> None:
    missing = [name for name in filenames if not (root / name).is_file()]
    if missing:
        raise SystemExit(
            "Missing required dataset files:\n  " + "\n  ".join(missing)
        )


def load_matplotlib():
    try:
        import matplotlib.pyplot as plt
        return plt
    except ImportError as exc:
        raise SystemExit(
            "matplotlib is required for plots.\n"
            "Install it with:\n"
            "  python -m pip install matplotlib"
        ) from exc


def save_horizontal_bar(
    plt,
    counter: Counter[str],
    title: str,
    xlabel: str,
    output: Path,
    top_n: int,
) -> None:
    items = counter.most_common(top_n)
    labels = [label for label, _ in reversed(items)]
    values = [value for _, value in reversed(items)]

    plt.figure(figsize=(12, max(6, 0.36 * max(1, len(items)))))
    plt.barh(labels, values)
    plt.xlabel(xlabel)
    plt.ylabel("")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(output, dpi=220)
    plt.close()


def save_grouped_bar(
    plt,
    labels: list[str],
    first: list[int],
    second: list[int],
    first_label: str,
    second_label: str,
    title: str,
    ylabel: str,
    output: Path,
) -> None:
    positions = list(range(len(labels)))
    width = 0.4

    plt.figure(figsize=(13, 7))
    plt.bar(
        [x - width / 2 for x in positions],
        first,
        width=width,
        label=first_label,
    )
    plt.bar(
        [x + width / 2 for x in positions],
        second,
        width=width,
        label=second_label,
    )
    plt.xticks(positions, labels, rotation=45, ha="right")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(output, dpi=220)
    plt.close()


def save_histogram(
    plt,
    values: list[int],
    title: str,
    xlabel: str,
    output: Path,
    bins: int = 60,
    percentile_cap: float | None = 0.99,
) -> None:
    if not values:
        return

    display_values = values
    footer = ""
    if percentile_cap is not None:
        ordered = sorted(values)
        cap = percentile(ordered, percentile_cap)
        if cap is not None:
            display_values = [value for value in values if value <= cap]
            footer = f" (display capped at {int(percentile_cap * 100)}th percentile: {cap})"

    plt.figure(figsize=(11, 7))
    plt.hist(display_values, bins=bins)
    plt.xlabel(xlabel)
    plt.ylabel("Count")
    plt.title(title + footer)
    plt.tight_layout()
    plt.savefig(output, dpi=220)
    plt.close()


def save_funnel(
    plt,
    labels: list[str],
    values: list[int],
    title: str,
    output: Path,
) -> None:
    plt.figure(figsize=(12, 7))
    plt.barh(list(reversed(labels)), list(reversed(values)))
    plt.xlabel("Assembly-line prediction records")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(output, dpi=220)
    plt.close()


def top_unique_counts(mapping: dict[str, set[str]]) -> Counter[str]:
    return Counter({key: len(value) for key, value in mapping.items()})


def safe_taxon(value: str, fallback: str = "Unclassified") -> str:
    cleaned = str(value or "").strip()
    return cleaned if cleaned else fallback


def format_number(value: Any) -> str:
    if isinstance(value, int):
        return f"{value:,}"
    if isinstance(value, float):
        return f"{value:,.2f}"
    return str(value)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset_dir", type=Path)
    parser.add_argument("--out-dir", type=Path, default=None)
    parser.add_argument("--top-n", type=int, default=20)
    args = parser.parse_args()

    root = args.dataset_dir.resolve()
    out = (
        args.out_dir.resolve()
        if args.out_dir
        else root / "statistical_report"
    )
    plots_dir = out / "plots"
    tables_dir = out / "tables"
    plots_dir.mkdir(parents=True, exist_ok=True)
    tables_dir.mkdir(parents=True, exist_ok=True)

    required = [
        "assembly_lines.tsv.gz",
        "assembly_line_modules.tsv.gz",
        "assembly_line_transitions.tsv.gz",
        "assembly_line_proteins.tsv.gz",
        "areas.tsv.gz",
        "modules.tsv.gz",
        "module_domains.tsv.gz",
        "domains.tsv.gz",
        "substrate_consensus.tsv.gz",
    ]
    require_files(root, required)

    plt = load_matplotlib()

    # ------------------------------------------------------------------
    # Pass 1: assembly-line metadata
    # ------------------------------------------------------------------
    line_meta: dict[str, dict[str, Any]] = {}
    ordering_source_counts: Counter[str] = Counter()
    docking_use_counts: Counter[str] = Counter()
    modules_per_line_all: list[int] = []
    proteins_per_line_all: list[int] = []

    for row in open_tsv_gz(root / "assembly_lines.tsv.gz"):
        line_id = row["assembly_line_id"]
        module_count = as_int(row["module_count"])
        protein_count = as_int(row["protein_count"])
        area_key = (
            row["accession"],
            row["record_id"],
            row["area_index"],
        )
        meta = {
            "accession": row["accession"],
            "record_id": row["record_id"],
            "area_index": row["area_index"],
            "area_key": area_key,
            "module_count": module_count,
            "protein_count": protein_count,
            "ordering_source": row["ordering_source"],
            "docking_used": row["docking_used"],
        }
        line_meta[line_id] = meta
        ordering_source_counts[row["ordering_source"]] += 1
        docking_use_counts[str(row["docking_used"] or "blank")] += 1
        modules_per_line_all.append(module_count)
        proteins_per_line_all.append(protein_count)

    all_line_ids = set(line_meta)

    # ------------------------------------------------------------------
    # Pass 2: module-family composition per line
    # ------------------------------------------------------------------
    line_module_families: dict[str, Counter[str]] = defaultdict(Counter)
    module_occurrence_families_all: Counter[str] = Counter()

    for row in open_tsv_gz(root / "assembly_line_modules.tsv.gz"):
        line_id = row["assembly_line_id"]
        family = row["module_family"]
        line_module_families[line_id][family] += 1
        module_occurrence_families_all[family] += 1

    # ------------------------------------------------------------------
    # Pass 3: transition composition per line
    # ------------------------------------------------------------------
    line_transition_types: dict[str, Counter[str]] = defaultdict(Counter)
    transition_occurrences_all: Counter[str] = Counter()

    for row in open_tsv_gz(root / "assembly_line_transitions.tsv.gz"):
        line_id = row["assembly_line_id"]
        transition_type = row["transition_type"]
        line_transition_types[line_id][transition_type] += 1
        transition_occurrences_all[transition_type] += 1

    # ------------------------------------------------------------------
    # Define transparent training subsets
    # ------------------------------------------------------------------
    multi_module_lines: set[str] = set()
    pure_nrps_lines: set[str] = set()
    pure_nrps_multimodule_lines: set[str] = set()
    clean_transition_lines: set[str] = set()
    high_confidence_order_lines: set[str] = set()
    clean_pure_nrps_general: set[str] = set()
    covalent_linker_training: set[str] = set()
    noncovalent_docking_training: set[str] = set()
    all_chain_break_training: set[str] = set()
    mixed_linker_chain_training: set[str] = set()

    allowed_clean_types = {
        "inter_module_linker_candidate",
        "inter_protein_chain_break",
    }

    for line_id, meta in line_meta.items():
        module_count = meta["module_count"]
        families = line_module_families[line_id]
        transitions = line_transition_types[line_id]
        expected = max(0, module_count - 1)
        observed = sum(transitions.values())

        is_multi = module_count >= 2
        is_pure_nrps = (
            module_count > 0
            and families.get("NRPS", 0) == module_count
            and sum(families.values()) == module_count
        )
        clean_types_only = set(transitions).issubset(allowed_clean_types)
        is_clean = (
            is_multi
            and observed == expected
            and clean_types_only
        )
        is_high_confidence = (
            meta["ordering_source"] == "antiSMASH_region_prediction"
        )

        if is_multi:
            multi_module_lines.add(line_id)
        if is_pure_nrps:
            pure_nrps_lines.add(line_id)
        if is_multi and is_pure_nrps:
            pure_nrps_multimodule_lines.add(line_id)
        if is_clean:
            clean_transition_lines.add(line_id)
        if is_high_confidence:
            high_confidence_order_lines.add(line_id)

        is_general = (
            is_multi
            and is_pure_nrps
            and is_clean
            and is_high_confidence
        )
        if is_general:
            clean_pure_nrps_general.add(line_id)

            linker_count = transitions.get(
                "inter_module_linker_candidate", 0
            )
            chain_count = transitions.get(
                "inter_protein_chain_break", 0
            )

            if linker_count == expected:
                covalent_linker_training.add(line_id)
            if chain_count > 0:
                noncovalent_docking_training.add(line_id)
            if chain_count == expected:
                all_chain_break_training.add(line_id)
            if linker_count > 0 and chain_count > 0:
                mixed_linker_chain_training.add(line_id)

    training_area_keys = {
        line_meta[line_id]["area_key"]
        for line_id in clean_pure_nrps_general
    }
    covalent_area_keys = {
        line_meta[line_id]["area_key"]
        for line_id in covalent_linker_training
    }
    docking_area_keys = {
        line_meta[line_id]["area_key"]
        for line_id in noncovalent_docking_training
    }

    # ------------------------------------------------------------------
    # Pass 4: collect module IDs used by the clean and branch subsets
    # ------------------------------------------------------------------
    valid_module_uids: set[str] = set()
    covalent_module_uids: set[str] = set()
    docking_module_uids: set[str] = set()

    for row in open_tsv_gz(root / "assembly_line_modules.tsv.gz"):
        line_id = row["assembly_line_id"]
        module_uid = row["module_uid"]
        if line_id in clean_pure_nrps_general:
            valid_module_uids.add(module_uid)
        if line_id in covalent_linker_training:
            covalent_module_uids.add(module_uid)
        if line_id in noncovalent_docking_training:
            docking_module_uids.add(module_uid)

    # ------------------------------------------------------------------
    # Pass 5: protein occurrences and total AA length per line
    # ------------------------------------------------------------------
    line_total_aa: Counter[str] = Counter()
    valid_protein_uids: set[str] = set()
    valid_locus_keys: set[tuple[str, str, str]] = set()

    for row in open_tsv_gz(root / "assembly_line_proteins.tsv.gz"):
        line_id = row["assembly_line_id"]
        line_total_aa[line_id] += as_int(row["length_aa"])
        if line_id in clean_pure_nrps_general:
            valid_protein_uids.add(row["protein_uid"])
            meta = line_meta[line_id]
            valid_locus_keys.add(
                (meta["accession"], meta["record_id"], row["cds_name"])
            )

    line_lengths_all = [
        line_total_aa[line_id]
        for line_id in all_line_ids
        if line_total_aa[line_id] > 0
    ]
    line_lengths_valid = [
        line_total_aa[line_id]
        for line_id in clean_pure_nrps_general
        if line_total_aa[line_id] > 0
    ]

    modules_per_line_valid = [
        line_meta[line_id]["module_count"]
        for line_id in clean_pure_nrps_general
    ]
    proteins_per_line_valid = [
        line_meta[line_id]["protein_count"]
        for line_id in clean_pure_nrps_general
    ]

    # ------------------------------------------------------------------
    # Pass 6: taxonomy and products at distinct area/genome level
    # ------------------------------------------------------------------
    species_genomes_all: dict[str, set[str]] = defaultdict(set)
    species_genomes_valid: dict[str, set[str]] = defaultdict(set)
    species_areas_all: Counter[str] = Counter()
    species_areas_valid: Counter[str] = Counter()

    phylum_genomes_all: dict[str, set[str]] = defaultdict(set)
    phylum_genomes_valid: dict[str, set[str]] = defaultdict(set)

    genus_genomes_all: dict[str, set[str]] = defaultdict(set)
    genus_genomes_valid: dict[str, set[str]] = defaultdict(set)

    product_labels_all: Counter[str] = Counter()
    product_labels_valid: Counter[str] = Counter()

    seen_area_rows: set[tuple[str, str, str]] = set()

    for row in open_tsv_gz(root / "areas.tsv.gz"):
        area_key = (
            row["accession"],
            row["record_id"],
            row["area_index"],
        )
        if area_key in seen_area_rows:
            continue
        seen_area_rows.add(area_key)

        species = safe_taxon(
            row.get("species") or row.get("organism")
        )
        genus = safe_taxon(row.get("genus"))
        phylum = safe_taxon(row.get("phylum"))
        accession = row["accession"]

        species_genomes_all[species].add(accession)
        species_areas_all[species] += 1
        genus_genomes_all[genus].add(accession)
        phylum_genomes_all[phylum].add(accession)

        products = [
            product.strip()
            for product in str(row.get("products", "")).split(";")
            if product.strip()
        ]
        product_labels_all.update(products)

        if area_key in training_area_keys:
            species_genomes_valid[species].add(accession)
            species_areas_valid[species] += 1
            genus_genomes_valid[genus].add(accession)
            phylum_genomes_valid[phylum].add(accession)
            product_labels_valid.update(products)

    species_unique_all = top_unique_counts(species_genomes_all)
    species_unique_valid = top_unique_counts(species_genomes_valid)
    genus_unique_all = top_unique_counts(genus_genomes_all)
    genus_unique_valid = top_unique_counts(genus_genomes_valid)
    phylum_unique_all = top_unique_counts(phylum_genomes_all)
    phylum_unique_valid = top_unique_counts(phylum_genomes_valid)

    # ------------------------------------------------------------------
    # Pass 7: unique module statistics
    # ------------------------------------------------------------------
    module_family_unique_all: Counter[str] = Counter()
    module_family_unique_valid: Counter[str] = Counter()
    module_arch_all: Counter[str] = Counter()
    module_arch_valid: Counter[str] = Counter()
    module_complete_all: Counter[str] = Counter()
    module_complete_valid: Counter[str] = Counter()
    module_multi_cds_all: Counter[str] = Counter()
    module_multi_cds_valid: Counter[str] = Counter()

    for row in open_tsv_gz(root / "modules.tsv.gz"):
        module_uid = row["module_uid"]
        family = row["module_family"]
        architecture = row["component_architecture"] or "Unannotated"
        completeness = (
            "Operationally complete"
            if as_bool(row["operational_complete"])
            else "Incomplete/partial"
        )
        multi_cds = (
            "Multi-CDS"
            if as_bool(row["multi_cds"])
            else "Single-CDS"
        )

        module_family_unique_all[family] += 1
        module_arch_all[architecture] += 1
        module_complete_all[completeness] += 1
        module_multi_cds_all[multi_cds] += 1

        if module_uid in valid_module_uids:
            module_family_unique_valid[family] += 1
            module_arch_valid[architecture] += 1
            module_complete_valid[completeness] += 1
            module_multi_cds_valid[multi_cds] += 1

    # ------------------------------------------------------------------
    # Pass 8: domain types for unique domains
    # ------------------------------------------------------------------
    valid_domain_uids: set[str] = set()
    for row in open_tsv_gz(root / "module_domains.tsv.gz"):
        if row["module_uid"] in valid_module_uids:
            valid_domain_uids.add(row["domain_uid"])

    domain_types_all: Counter[str] = Counter()
    domain_types_valid: Counter[str] = Counter()

    for row in open_tsv_gz(root / "domains.tsv.gz"):
        hit_id = row["hit_id"] or "Unannotated"
        domain_types_all[hit_id] += 1
        if row["domain_uid"] in valid_domain_uids:
            domain_types_valid[hit_id] += 1

    # ------------------------------------------------------------------
    # Pass 9: substrate consensus
    # ------------------------------------------------------------------
    substrate_all: Counter[str] = Counter()
    substrate_valid: Counter[str] = Counter()

    for row in open_tsv_gz(root / "substrate_consensus.tsv.gz"):
        monomer = row["predicted_monomer"] or "Blank"
        substrate_all[monomer] += 1
        locus_key = (
            row["accession"],
            row["record_id"],
            row["locus"],
        )
        if locus_key in valid_locus_keys:
            substrate_valid[monomer] += 1

    # ------------------------------------------------------------------
    # Pass 10: transition details and physical-boundary deduplication
    # ------------------------------------------------------------------
    linker_pairs_occ_all: Counter[str] = Counter()
    linker_pairs_occ_valid: Counter[str] = Counter()
    chain_pairs_occ_all: Counter[str] = Counter()
    chain_pairs_occ_valid: Counter[str] = Counter()

    unique_linkers_all: dict[tuple[str, ...], tuple[str, int]] = {}
    unique_linkers_valid: dict[tuple[str, ...], tuple[str, int]] = {}
    unique_chain_all: dict[tuple[str, ...], str] = {}
    unique_chain_valid: dict[tuple[str, ...], str] = {}

    transition_occurrences_valid: Counter[str] = Counter()

    for row in open_tsv_gz(root / "assembly_line_transitions.tsv.gz"):
        line_id = row["assembly_line_id"]
        transition_type = row["transition_type"]
        pair = (
            f"{row['left_terminal_component']}->"
            f"{row['right_initial_component']}"
        )
        is_valid = line_id in clean_pure_nrps_general

        if is_valid:
            transition_occurrences_valid[transition_type] += 1

        if transition_type == "inter_module_linker_candidate":
            linker_pairs_occ_all[pair] += 1
            key = (
                row["left_module_uid"],
                row["right_module_uid"],
                row["left_owner_cds"],
                row["right_owner_cds"],
                row["start_aa_0based"],
                row["end_aa_0based_exclusive"],
            )
            unique_linkers_all.setdefault(
                key,
                (pair, as_int(row["length_aa"])),
            )
            if is_valid:
                linker_pairs_occ_valid[pair] += 1
                unique_linkers_valid.setdefault(
                    key,
                    (pair, as_int(row["length_aa"])),
                )

        elif transition_type == "inter_protein_chain_break":
            chain_pairs_occ_all[pair] += 1
            key = (
                row["left_module_uid"],
                row["right_module_uid"],
                row["left_owner_cds"],
                row["right_owner_cds"],
            )
            unique_chain_all.setdefault(key, pair)
            if is_valid:
                chain_pairs_occ_valid[pair] += 1
                unique_chain_valid.setdefault(key, pair)

    linker_pairs_unique_all = Counter(
        pair for pair, _ in unique_linkers_all.values()
    )
    linker_pairs_unique_valid = Counter(
        pair for pair, _ in unique_linkers_valid.values()
    )
    chain_pairs_unique_all = Counter(unique_chain_all.values())
    chain_pairs_unique_valid = Counter(unique_chain_valid.values())

    linker_lengths_all = [
        length for _, length in unique_linkers_all.values()
    ]
    linker_lengths_valid = [
        length for _, length in unique_linkers_valid.values()
    ]

    # ------------------------------------------------------------------
    # Metrics and tables
    # ------------------------------------------------------------------
    total_lines = len(all_line_ids)
    metrics: dict[str, Any] = {
        "assembly_line_prediction_records": total_lines,
        "distinct_nrps_related_areas": len(seen_area_rows),
        "multi_module_lines": len(multi_module_lines),
        "pure_nrps_lines": len(pure_nrps_lines),
        "pure_nrps_multimodule_lines": len(pure_nrps_multimodule_lines),
        "clean_transition_lines": len(clean_transition_lines),
        "high_confidence_order_lines": len(high_confidence_order_lines),
        "clean_pure_nrps_general_lines": len(clean_pure_nrps_general),
        "covalent_linker_training_lines": len(covalent_linker_training),
        "noncovalent_docking_training_lines": len(
            noncovalent_docking_training
        ),
        "all_chain_break_training_lines": len(all_chain_break_training),
        "mixed_linker_chain_training_lines": len(
            mixed_linker_chain_training
        ),
        "clean_pure_nrps_distinct_areas": len(training_area_keys),
        "covalent_distinct_areas": len(covalent_area_keys),
        "docking_distinct_areas": len(docking_area_keys),
        "unique_modules_all": sum(module_family_unique_all.values()),
        "unique_modules_clean_pure_nrps": len(valid_module_uids),
        "unique_domains_all": sum(domain_types_all.values()),
        "unique_domains_clean_pure_nrps": len(valid_domain_uids),
        "same_protein_linker_occurrences_all": transition_occurrences_all.get(
            "inter_module_linker_candidate", 0
        ),
        "same_protein_linker_occurrences_clean_pure_nrps":
            transition_occurrences_valid.get(
                "inter_module_linker_candidate", 0
            ),
        "unique_same_protein_linkers_all": len(unique_linkers_all),
        "unique_same_protein_linkers_clean_pure_nrps":
            len(unique_linkers_valid),
        "inter_protein_chain_break_occurrences_all":
            transition_occurrences_all.get(
                "inter_protein_chain_break", 0
            ),
        "inter_protein_chain_break_occurrences_clean_pure_nrps":
            transition_occurrences_valid.get(
                "inter_protein_chain_break", 0
            ),
        "unique_inter_protein_chain_breaks_all": len(unique_chain_all),
        "unique_inter_protein_chain_breaks_clean_pure_nrps":
            len(unique_chain_valid),
        "unique_species_all": len(species_unique_all),
        "unique_species_clean_pure_nrps": len(species_unique_valid),
        "unique_genera_all": len(genus_unique_all),
        "unique_genera_clean_pure_nrps": len(genus_unique_valid),
        "unique_phyla_all": len(phylum_unique_all),
        "unique_phyla_clean_pure_nrps": len(phylum_unique_valid),
    }

    ordered_all_lengths = sorted(linker_lengths_all)
    ordered_valid_lengths = sorted(linker_lengths_valid)
    for prefix, values in [
        ("linker_length_all", ordered_all_lengths),
        ("linker_length_clean_pure_nrps", ordered_valid_lengths),
    ]:
        if values:
            metrics[f"{prefix}_minimum"] = min(values)
            metrics[f"{prefix}_median"] = percentile(values, 0.50)
            metrics[f"{prefix}_p90"] = percentile(values, 0.90)
            metrics[f"{prefix}_p95"] = percentile(values, 0.95)
            metrics[f"{prefix}_p99"] = percentile(values, 0.99)
            metrics[f"{prefix}_maximum"] = max(values)

    with (out / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(metrics, handle, indent=2)

    write_csv(
        tables_dir / "summary_metrics.csv",
        ["metric", "value"],
        metrics.items(),
    )

    write_counter_csv(
        tables_dir / "module_family_unique_all.csv",
        module_family_unique_all,
        "module_family",
    )
    write_counter_csv(
        tables_dir / "module_architecture_all.csv",
        module_arch_all,
        "module_architecture",
    )
    write_counter_csv(
        tables_dir / "module_architecture_clean_pure_nrps.csv",
        module_arch_valid,
        "module_architecture",
    )
    write_counter_csv(
        tables_dir / "domain_types_all.csv",
        domain_types_all,
        "domain_type",
    )
    write_counter_csv(
        tables_dir / "domain_types_clean_pure_nrps.csv",
        domain_types_valid,
        "domain_type",
    )
    write_counter_csv(
        tables_dir / "transition_types_all.csv",
        transition_occurrences_all,
        "transition_type",
    )
    write_counter_csv(
        tables_dir / "transition_types_clean_pure_nrps.csv",
        transition_occurrences_valid,
        "transition_type",
    )
    write_counter_csv(
        tables_dir / "species_unique_genomes_all.csv",
        species_unique_all,
        "species",
    )
    write_counter_csv(
        tables_dir / "species_unique_genomes_clean_pure_nrps.csv",
        species_unique_valid,
        "species",
    )
    write_counter_csv(
        tables_dir / "genus_unique_genomes_all.csv",
        genus_unique_all,
        "genus",
    )
    write_counter_csv(
        tables_dir / "genus_unique_genomes_clean_pure_nrps.csv",
        genus_unique_valid,
        "genus",
    )
    write_counter_csv(
        tables_dir / "phylum_unique_genomes_all.csv",
        phylum_unique_all,
        "phylum",
    )
    write_counter_csv(
        tables_dir / "phylum_unique_genomes_clean_pure_nrps.csv",
        phylum_unique_valid,
        "phylum",
    )
    write_counter_csv(
        tables_dir / "product_labels_all.csv",
        product_labels_all,
        "product_label",
    )
    write_counter_csv(
        tables_dir / "product_labels_clean_pure_nrps.csv",
        product_labels_valid,
        "product_label",
    )
    write_counter_csv(
        tables_dir / "substrate_consensus_all.csv",
        substrate_all,
        "predicted_monomer",
    )
    write_counter_csv(
        tables_dir / "substrate_consensus_clean_pure_nrps.csv",
        substrate_valid,
        "predicted_monomer",
    )
    write_counter_csv(
        tables_dir / "linker_pairs_unique_all.csv",
        linker_pairs_unique_all,
        "domain_pair",
    )
    write_counter_csv(
        tables_dir / "linker_pairs_unique_clean_pure_nrps.csv",
        linker_pairs_unique_valid,
        "domain_pair",
    )
    write_counter_csv(
        tables_dir / "chain_break_pairs_unique_all.csv",
        chain_pairs_unique_all,
        "domain_pair",
    )
    write_counter_csv(
        tables_dir / "chain_break_pairs_unique_clean_pure_nrps.csv",
        chain_pairs_unique_valid,
        "domain_pair",
    )

    # ------------------------------------------------------------------
    # Plots: one figure per file, no subplots
    # ------------------------------------------------------------------
    funnel_labels = [
        "All prediction records",
        "Multi-module",
        "Pure-NRPS multi-module",
        "Clean pure-NRPS general",
        "Covalent linker training",
        "Contains noncovalent chain break",
    ]
    funnel_values = [
        total_lines,
        len(multi_module_lines),
        len(pure_nrps_multimodule_lines),
        len(clean_pure_nrps_general),
        len(covalent_linker_training),
        len(noncovalent_docking_training),
    ]
    save_funnel(
        plt,
        funnel_labels,
        funnel_values,
        "Assembly-line filtering and training subsets",
        plots_dir / "01_training_subset_funnel.png",
    )

    module_bins_all = compact_bins(modules_per_line_all, 20)
    module_bins_valid = compact_bins(modules_per_line_valid, 20)
    module_labels = [str(i) for i in range(1, 21)] + ["21+"]
    save_grouped_bar(
        plt,
        module_labels,
        [module_bins_all[label] for label in module_labels],
        [module_bins_valid[label] for label in module_labels],
        "Whole dataset",
        "Clean pure-NRPS",
        "Modules per assembly-line prediction",
        "Assembly-line records",
        plots_dir / "02_modules_per_line.png",
    )

    protein_bins_all = compact_bins(proteins_per_line_all, 10)
    protein_bins_valid = compact_bins(proteins_per_line_valid, 10)
    protein_labels = [str(i) for i in range(1, 11)] + ["11+"]
    save_grouped_bar(
        plt,
        protein_labels,
        [protein_bins_all[label] for label in protein_labels],
        [protein_bins_valid[label] for label in protein_labels],
        "Whole dataset",
        "Clean pure-NRPS",
        "Proteins per assembly-line prediction",
        "Assembly-line records",
        plots_dir / "03_proteins_per_line.png",
    )

    save_horizontal_bar(
        plt,
        module_family_unique_all,
        "Unique module-family composition",
        "Unique modules",
        plots_dir / "04_module_family_composition.png",
        args.top_n,
    )

    save_horizontal_bar(
        plt,
        transition_occurrences_all,
        "Transition types across all assembly-line predictions",
        "Transition occurrences",
        plots_dir / "05_transition_types_all.png",
        args.top_n,
    )

    save_horizontal_bar(
        plt,
        module_arch_all,
        "Most common unique module architectures: whole dataset",
        "Unique modules",
        plots_dir / "06_module_architectures_all.png",
        args.top_n,
    )

    save_horizontal_bar(
        plt,
        module_arch_valid,
        "Most common unique module architectures: clean pure-NRPS subset",
        "Unique modules",
        plots_dir / "07_module_architectures_clean_pure_nrps.png",
        args.top_n,
    )

    save_horizontal_bar(
        plt,
        domain_types_all,
        "Most common domain types: whole dataset",
        "Unique domains",
        plots_dir / "08_domain_types_all.png",
        args.top_n,
    )

    save_horizontal_bar(
        plt,
        domain_types_valid,
        "Most common domain types: clean pure-NRPS subset",
        "Unique domains",
        plots_dir / "09_domain_types_clean_pure_nrps.png",
        args.top_n,
    )

    save_horizontal_bar(
        plt,
        species_unique_all,
        "Top species by unique genome accessions: whole dataset",
        "Unique genome accessions",
        plots_dir / "10_species_all.png",
        args.top_n,
    )

    save_horizontal_bar(
        plt,
        species_unique_valid,
        "Top species by unique genome accessions: clean pure-NRPS subset",
        "Unique genome accessions",
        plots_dir / "11_species_clean_pure_nrps.png",
        args.top_n,
    )

    # Compare top phyla chosen from combined rank.
    combined_phyla = phylum_unique_all + phylum_unique_valid
    phylum_labels = [
        label for label, _ in combined_phyla.most_common(args.top_n)
    ]
    save_grouped_bar(
        plt,
        phylum_labels,
        [phylum_unique_all[label] for label in phylum_labels],
        [phylum_unique_valid[label] for label in phylum_labels],
        "Whole dataset",
        "Clean pure-NRPS",
        "Top phyla by unique genome accessions",
        "Unique genome accessions",
        plots_dir / "12_phyla_comparison.png",
    )

    save_histogram(
        plt,
        linker_lengths_all,
        "Deduplicated same-protein linker lengths: whole dataset",
        "Linker length (amino acids)",
        plots_dir / "13_linker_lengths_all.png",
    )

    save_histogram(
        plt,
        linker_lengths_valid,
        "Deduplicated same-protein linker lengths: clean pure-NRPS subset",
        "Linker length (amino acids)",
        plots_dir / "14_linker_lengths_clean_pure_nrps.png",
    )

    save_horizontal_bar(
        plt,
        linker_pairs_unique_valid,
        "Natural same-protein linker positions: clean pure-NRPS subset",
        "Deduplicated physical boundaries",
        plots_dir / "15_linker_terminal_pairs_clean_pure_nrps.png",
        args.top_n,
    )

    save_horizontal_bar(
        plt,
        chain_pairs_unique_valid,
        "Natural inter-protein chain-break positions: clean pure-NRPS subset",
        "Deduplicated physical boundaries",
        plots_dir / "16_chain_break_terminal_pairs_clean_pure_nrps.png",
        args.top_n,
    )

    save_horizontal_bar(
        plt,
        substrate_valid,
        "A-domain substrate consensus: clean pure-NRPS subset",
        "Predicted A domains",
        plots_dir / "17_substrate_consensus_clean_pure_nrps.png",
        args.top_n,
    )

    save_histogram(
        plt,
        line_lengths_all,
        "Total amino-acid length per assembly-line prediction: whole dataset",
        "Total length across ordered proteins (aa)",
        plots_dir / "18_assembly_line_aa_length_all.png",
    )

    save_histogram(
        plt,
        line_lengths_valid,
        "Total amino-acid length per assembly-line prediction: clean pure-NRPS subset",
        "Total length across ordered proteins (aa)",
        plots_dir / "19_assembly_line_aa_length_clean_pure_nrps.png",
    )

    save_horizontal_bar(
        plt,
        ordering_source_counts,
        "Assembly-line ordering provenance",
        "Assembly-line prediction records",
        plots_dir / "20_ordering_source.png",
        args.top_n,
    )

    save_grouped_bar(
        plt,
        ["Operationally complete", "Incomplete/partial"],
        [
            module_complete_all["Operationally complete"],
            module_complete_all["Incomplete/partial"],
        ],
        [
            module_complete_valid["Operationally complete"],
            module_complete_valid["Incomplete/partial"],
        ],
        "Whole dataset",
        "Clean pure-NRPS",
        "Module completeness",
        "Unique modules",
        plots_dir / "21_module_completeness.png",
    )

    # ------------------------------------------------------------------
    # Human-readable summary
    # ------------------------------------------------------------------
    summary_lines = [
        "ANTI-SMASH NRPS ASSEMBLY-LINE DATASET REPORT",
        "=" * 64,
        "",
        "WHOLE DATASET",
        f"Assembly-line prediction records: {total_lines:,}",
        f"Distinct NRPS-related areas: {len(seen_area_rows):,}",
        f"Unique modules: {sum(module_family_unique_all.values()):,}",
        f"Unique domains: {sum(domain_types_all.values()):,}",
        "",
        "TRAINING SUBSETS",
        f"Multi-module lines: {len(multi_module_lines):,} "
        f"({percentage(len(multi_module_lines), total_lines):.2f}%)",
        f"Pure-NRPS multi-module lines: {len(pure_nrps_multimodule_lines):,} "
        f"({percentage(len(pure_nrps_multimodule_lines), total_lines):.2f}%)",
        f"Clean pure-NRPS general lines: {len(clean_pure_nrps_general):,} "
        f"({percentage(len(clean_pure_nrps_general), total_lines):.2f}%)",
        f"Covalent linker-training lines: {len(covalent_linker_training):,}",
        f"Noncovalent docking-training lines: "
        f"{len(noncovalent_docking_training):,}",
        f"All-chain-break lines: {len(all_chain_break_training):,}",
        f"Mixed linker/chain-break lines: "
        f"{len(mixed_linker_chain_training):,}",
        "",
        "PHYSICAL JUNCTIONS",
        f"Unique same-protein linkers, whole dataset: "
        f"{len(unique_linkers_all):,}",
        f"Unique same-protein linkers, clean pure-NRPS: "
        f"{len(unique_linkers_valid):,}",
        f"Unique inter-protein chain breaks, whole dataset: "
        f"{len(unique_chain_all):,}",
        f"Unique inter-protein chain breaks, clean pure-NRPS: "
        f"{len(unique_chain_valid):,}",
        "",
        "IMPORTANT INTERPRETATION",
        "- Assembly-line rows are prediction records; one biological area can "
        "have multiple alternative antiSMASH orderings.",
        "- The clean pure-NRPS subset excludes augmented/fallback ordering and "
        "ambiguous module boundaries.",
        "- Covalent linkers have continuous amino-acid sequences.",
        "- Inter-protein chain breaks represent noncovalent interfaces and have "
        "two separate terminal sequences, not a peptide linker.",
        "- Deduplicated physical-boundary counts are preferable to raw "
        "transition-occurrence counts for biological conclusions.",
        "",
        f"Report directory: {out}",
    ]
    summary_text = "\n".join(summary_lines) + "\n"
    (out / "summary.txt").write_text(summary_text, encoding="utf-8")

    # ------------------------------------------------------------------
    # Standalone HTML report
    # ------------------------------------------------------------------
    metric_rows = "\n".join(
        f"<tr><td>{html.escape(key.replace('_', ' ').title())}</td>"
        f"<td>{html.escape(format_number(value))}</td></tr>"
        for key, value in metrics.items()
    )

    plot_files = sorted(plots_dir.glob("*.png"))
    plot_blocks = "\n".join(
        (
            "<section>"
            f"<h2>{html.escape(plot.stem.replace('_', ' ').title())}</h2>"
            f"<img src='plots/{html.escape(plot.name)}' "
            "style='max-width:100%;height:auto'>"
            "</section>"
        )
        for plot in plot_files
    )

    report_html = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>antiSMASH NRPS assembly-line dataset report</title>
<style>
body {{
  font-family: Arial, sans-serif;
  max-width: 1200px;
  margin: 40px auto;
  padding: 0 24px;
  line-height: 1.5;
}}
table {{
  border-collapse: collapse;
  width: 100%;
  margin-bottom: 32px;
}}
th, td {{
  border: 1px solid #ccc;
  padding: 8px 10px;
  text-align: left;
}}
section {{
  margin: 48px 0;
  page-break-inside: avoid;
}}
code {{
  background: #f2f2f2;
  padding: 2px 4px;
}}
.note {{
  border-left: 4px solid #777;
  padding-left: 16px;
}}
</style>
</head>
<body>
<h1>antiSMASH NRPS assembly-line dataset report</h1>
<p>Dataset directory: <code>{html.escape(str(root))}</code></p>

<div class="note">
<h2>Subset definitions</h2>
<p><strong>Clean pure-NRPS general:</strong> at least two NRPS modules, exact
antiSMASH region ordering, and every transition classified as either a
same-protein linker or an inter-protein chain break.</p>
<p><strong>Covalent linker training:</strong> clean pure-NRPS lines whose every
transition has a same-protein linker sequence.</p>
<p><strong>Noncovalent docking training:</strong> clean pure-NRPS lines with at
least one inter-protein chain break. The two terminal sequences remain separate.</p>
</div>

<h2>Summary metrics</h2>
<table>
<tr><th>Metric</th><th>Value</th></tr>
{metric_rows}
</table>

{plot_blocks}

<h2>Generated tables</h2>
<p>Machine-readable CSV tables are available in the <code>tables</code>
directory. The plots are available as publication-ready PNG files in
<code>plots</code>.</p>
</body>
</html>
"""
    (out / "report.html").write_text(report_html, encoding="utf-8")

    print(summary_text)
    print("Created:")
    print(f"  {out / 'report.html'}")
    print(f"  {out / 'summary.txt'}")
    print(f"  {plots_dir}")
    print(f"  {tables_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
