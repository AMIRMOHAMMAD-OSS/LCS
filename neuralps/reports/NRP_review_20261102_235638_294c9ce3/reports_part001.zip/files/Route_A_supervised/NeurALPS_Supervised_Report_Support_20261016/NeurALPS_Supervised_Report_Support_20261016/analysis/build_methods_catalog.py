from pathlib import Path
import json, csv, hashlib, collections, re

import argparse
parser=argparse.ArgumentParser(description='Recompute report records from the extracted original input archive; no model training.')
parser.add_argument('--input',type=Path,required=True,help='Directory containing REPORT_INPUT_INDEX.json and source/')
parser.add_argument('--output',type=Path,required=True,help='Directory for newly computed tables and records')
args=parser.parse_args()
args.output.mkdir(parents=True,exist_ok=True)
ROOT=args.input/'source'
OUT=args.output;OUT.mkdir(parents=True,exist_ok=True)
REMOTE='/lustre/fswork/projects/rech/nef/unh87ms/'
P=ROOT/'NeurALPSv2'
def j(p):return json.loads(p.read_text())
def remote(p):return REMOTE+str(p.relative_to(ROOT))
def writecsv(name,rows):
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with (OUT/name).open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def flat(o,path=''):
    if isinstance(o,dict):
        for k,v in o.items():yield from flat(v,path+'/'+str(k))
    elif isinstance(o,list):
        for i,v in enumerate(o):yield from flat(v,path+'/'+str(i))
    else:yield path,o

index=j(ROOT.parent/'REPORT_INPUT_INDEX.json')
paths=[]
for x in index['source_paths']:
    s=x['source_path'];local=ROOT/s.removeprefix(REMOTE)
    paths.append(dict(source_path=s,original_collection_status=x['status'],bytes=x.get('bytes_before',''),recorded_sha256=x.get('sha256',''),included_in_compact_archive=local.is_file(),kind='code' if s.endswith(('.py','.sh')) else 'weight' if s.endswith(('.pt','.pth')) or '/model.npz' in s else 'record'))
writecsv('source_path_catalog.csv',paths)
writecsv('code_paths.csv',[r for r in paths if r['kind']=='code'])
checkpoint_hashes={}
for d in P.glob('e*'):
    for f in d.rglob('complete.json'):
        z=j(f)
        for suffix,key in [('best.pt','checkpoint_sha256'),('model.pt','model_sha256')]:
            if z.get(key):checkpoint_hashes[remote(f.parent/suffix)]=z[key]
        for name,h in z.get('files_sha256',{}).items():
            if name in ('model.npz','best.pt'):checkpoint_hashes[remote(f.parent/name)]=h
checks=[]
for r in paths:
    if r['kind']=='weight':
        r=dict(r);r['completion_record_sha256']=checkpoint_hashes.get(r['source_path'],'');checks.append(r)
writecsv('checkpoint_catalog.csv',checks)

settings=[];runs=[];splitrows=[];members=[];all_splits=[]
for d in sorted(P.glob('e*')):
    if not d.is_dir():continue
    cfg=j(d/'config.json') if (d/'config.json').exists() else {}
    summ=j(d/'summary.json') if (d/'summary.json').exists() else {}
    run={'run':d.name,'remote_run_path':remote(d),'status':summ.get('status',''),'profile':cfg.get('profile',summ.get('profile','')),'tasks_in_config':len(cfg.get('tasks',[])),'complete_records':len(list(d.rglob('complete.json'))),'ssl_run':cfg.get('ssl_run',''),'config_path':remote(d/'config.json') if cfg else ''}
    runtime=j(d/'runtime.json') if (d/'runtime.json').exists() else {}
    run.update({f'runtime_{k}':v for k,v in runtime.items() if isinstance(v,(str,int,float,bool))});runs.append(run)
    for section in ['recipe','settings','ensemble']:
        for key,value in flat(cfg.get(section,{})):
            settings.append(dict(run=d.name,section=section,parameter=key,value=json.dumps(value),source_path=remote(d/'config.json')))
    seen={}
    for task in cfg.get('tasks',[]):
        if not isinstance(task,dict):continue
        key=(task['part'],task['seed'],task['budget'])
        sp={'run':d.name,'split_id':task['part']+'_s'+str(task['seed'])+'_b'+str(task['budget']),'dataset':'bode1','benchmark':'bode1_edits' if 'query_ids' in task else 'bode1_donor','seed':task['seed'],'budget':task['budget'],'arms':[],'fit_ids':task['inner']['fit_ids'],'validation_ids':task['inner']['validation_ids'],'test_ids':task['test_ids'],'query_ids':task.get('query_ids',[]),'inner_held_out':task['inner'].get('inner_held_out_part',''),'source_path':remote(d/'config.json')}
        if key not in seen:seen[key]=sp
        else:
            for role in ['fit_ids','validation_ids','test_ids']:assert seen[key][role]==sp[role],(d,role)
        seen[key]['arms'].append(task['arm'])
    all_splits.extend(seen.values())
    if (d/'splits.json').exists():
        for sp in j(d/'splits.json'):
            all_splits.append(dict(run=d.name,split_id=sp['task_id'],dataset=sp['dataset'],benchmark=sp['benchmark'],seed='',budget='',arms=['global_context','typed_context','typed_context_scores'],fit_ids=sp['fit_ids'],validation_ids=sp['validation_ids'],test_ids=sp['test_ids'],query_ids=sp.get('query_ids',[]),refit_ids=sp['refit_ids'],inner_held_out=sp.get('inner_held_out_donor',sp.get('inner_held_out_donors','')),source_path=remote(d/'splits.json')))

for sp in all_splits:
    roles=['fit_ids','validation_ids','test_ids','query_ids','refit_ids']
    a,b,c=[set(sp[k]) for k in roles[:3]]
    assert not(a&b or a&c or b&c),(sp['run'],sp['split_id'])
    if 'refit_ids' in sp:assert set(sp['refit_ids'])==a|b
    rec={k:v for k,v in sp.items() if k not in roles}
    rec['arms']=';'.join(sorted(set(rec['arms'])))
    rec['inner_held_out']=json.dumps(rec['inner_held_out'])
    for role in roles:rec[role.replace('_ids','_n')]=len(sp.get(role,[]))
    rec['fit_val_test_disjoint']=True;splitrows.append(rec)
    for role in roles:
        for n,assembly in enumerate(sp.get(role,[])):
            members.append(dict(run=sp['run'],split_id=sp['split_id'],dataset=sp['dataset'],role=role.removesuffix('_ids'),order=n,assembly_id=assembly))

e6=P/'e6_compatibility_bode2_588750'
for f in sorted(e6.glob('fits/*/complete.json')):
    z=j(f);c=z['contract'];tid=f.parent.name
    for role in ['fit_ids','external_ids']:
        for n,assembly in enumerate(c[role]):members.append(dict(run=e6.name,split_id=tid,dataset='bode1' if role=='fit_ids' else 'bode2',role=role.removesuffix('_ids'),order=n,assembly_id=assembly))
    for key,value in flat({k:v for k,v in c.items() if k not in ['fit_ids','external_ids','identity']}):
        settings.append(dict(run=e6.name,section=tid,parameter=key,value=json.dumps(value),source_path=remote(f)))
expl=ROOT/'NeurALPS_Explorer_20261010'
for n,row in enumerate(j(expl/'data/training_rows.json')):
    members.append(dict(run='Explorer_all494',split_id='all494_full_fit',dataset=row['dataset'],role='fit',order=n,assembly_id=row['assembly_id']))
writecsv('experiment_runs.csv',runs);writecsv('training_settings.csv',settings)
writecsv('split_summary.csv',splitrows);writecsv('split_membership.csv',members)
writecsv('deployment_training_rows.csv',j(expl/'data/training_rows.json'))

# Keep exact protocol details and key metadata without thousands of duplicate contracts.
protocols={}
for f in sorted(ROOT.glob('NeurALPSv2/*/*')):
    if f.is_file() and f.name in ['PROTOCOL.json','protocol.json','architectures.json','VALIDATION.json']:
        protocols[remote(f)]=j(f)
protocols[remote(expl/'models/all494/manifest.json')]=j(expl/'models/all494/manifest.json')
protocols[remote(expl/'data/training_manifest.json')]=j(expl/'data/training_manifest.json')
(OUT/'protocols_and_architectures.json').write_text(json.dumps(protocols,indent=2)+'\n')

observed_paths={}
for d in ROOT.iterdir():
    for f in d.glob('*/*.json'):
        if f.name in ['config.json','request.json','source_provenance.json','summary.json','CONTRACT.json','INPUTS.json']:
            for ptr,value in flat(j(f)):
                if isinstance(value,str) and value.startswith('/lustre/'):
                    observed_paths.setdefault(value,(remote(f),ptr))
writecsv('referenced_remote_paths.csv',[dict(remote_path=k,evidence_file=v[0],json_pointer=v[1]) for k,v in sorted(observed_paths.items())])
validation=[]
for d in sorted(P.glob('e*')):
    if not d.is_dir():continue
    fs=list(d.rglob('complete.json'));z=[j(f) for f in fs]
    validation.append(dict(run=d.name,complete_records=len(z),checkpoint_reload_exact_true=sum(x.get('checkpoint_reload_exact') is True for x in z),checkpoint_reload_exact_false=sum(x.get('checkpoint_reload_exact') is False for x in z),reload_status_absent=sum('checkpoint_reload_exact' not in x for x in z)))
writecsv('execution_checks.csv',validation)
summary={'source_path_entries':len(paths),'code_path_entries':sum(x['kind']=='code' for x in paths),'checkpoint_path_entries':len(checks),'checkpoint_hashes_from_completion_records':sum(bool(x['completion_record_sha256']) for x in checks),'split_summary_rows':len(splitrows),'split_membership_rows':len(members),'all_recorded_split_triplets_disjoint':True,'all_recorded_refit_ids_equal_fit_plus_validation':True}
(OUT/'CATALOG_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
