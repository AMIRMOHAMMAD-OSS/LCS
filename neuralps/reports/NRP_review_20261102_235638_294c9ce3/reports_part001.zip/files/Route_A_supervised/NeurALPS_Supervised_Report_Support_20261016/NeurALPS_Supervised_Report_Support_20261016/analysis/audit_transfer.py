from pathlib import Path
import csv,json,hashlib,collections,math
import numpy as np
from sklearn.metrics import roc_auc_score,average_precision_score,balanced_accuracy_score,matthews_corrcoef,log_loss,brier_score_loss,confusion_matrix
from scipy.stats import spearmanr
import argparse
parser=argparse.ArgumentParser(description='Recompute report records from the extracted original input archive; no model training.')
parser.add_argument('--input',type=Path,required=True,help='Directory containing REPORT_INPUT_INDEX.json and source/')
parser.add_argument('--output',type=Path,required=True,help='Directory for newly computed tables and records')
args=parser.parse_args()
args.output.mkdir(parents=True,exist_ok=True)
root=args.input/'source'; base=root/'NeurALPSv2'; out=args.output
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r6=base/'e6_compatibility_bode2_588750'; r7=base/'e7_compat_readout_benchmark_646197'; r11=base/'e11_tdomain_transfer_699466'; exp=root/'NeurALPS_Explorer_20261010'
result={'scope':'Audited archived summaries plus explicitly new T-domain retrospective label join; no models trained or inferred','e6':{'source':str(r6/'summary.json'),'protocol_source':str(base/'NeurALPS_Compatibility_20261004/PROTOCOL.json'),'summary':load(r6/'summary.json'),'protocol':load(base/'NeurALPS_Compatibility_20261004/PROTOCOL.json'),'recipe':load(r6/'config.json')['recipe'],'overlap':load(r6/'overlap_audit.json')},'e7':{'source':str(r7/'summary.json'),'summary':load(r7/'summary.json'),'protocol':load(r7/'PROTOCOL.json')},'e11_historical':{'source':str(r11/'summary.json'),'summary':load(r11/'summary.json'),'protocol':load(r11/'PROTOCOL.json')},'all494':{'source':str(exp/'models/all494/manifest.json'),'manifest':load(exp/'models/all494/manifest.json'),'fit_diagnostics':load(exp/'models/all494/fit_diagnostics.json'),'head_selection':{k:v for k,v in load(exp/'data/head_selection.json').items() if k!='archived_trials'}}}
splits=load(r7/'splits.json'); summ={}
for benchmark in sorted(set(s['benchmark'] for s in splits)):
 ss=[s for s in splits if s['benchmark']==benchmark]
 summ[benchmark]={'tasks':len(ss),'counts':{k:dict(collections.Counter(len(s[k]) for s in ss)) for k in ('fit_ids','validation_ids','refit_ids','test_ids','query_ids')}}
 for s in ss:
  assert not(set(s['fit_ids'])&set(s['validation_ids']))
  assert set(s['refit_ids'])==set(s['fit_ids'])|set(s['validation_ids'])
  assert not(set(s['refit_ids'])&set(s['test_ids']))
result['e7']['split_counts']=summ
fitcount=collections.Counter(); trials=collections.Counter(); allsolvers=[]; l2s=collections.defaultdict(collections.Counter)
for p in sorted((r7/'fits').glob('*/*/complete.json')):
 c=load(p); t=load(p.parent/'trials.json'); task=p.parent.parent.name; arm=p.parent.name; fam='bode1_donor' if task.startswith('b1_donor') else ('bode2_donor' if task.startswith('b2_donor') else 'bode1_edits')
 fitcount[fam]+=1;trials[fam]+=len(t['trials']); l2s[f'{fam}/{arm}'][str(c['selected_l2'])]+=1
 assert c['checkpoint_reload_exact'];assert c['status']=='MODEL_COMPLETE'
 allsolvers.append(c['solver']['attempts'][-1])
result['e7']['fit_audit']={'final_models':dict(fitcount),'inner_trials':dict(trials),'selected_l2_counts':{k:dict(v) for k,v in l2s.items()},'all_final_reload_exact':True,'all_final_solver_success':all(s['success'] for s in allsolvers),'max_final_gradient_inf':max(s['gradient_inf'] for s in allsolvers)}
labels=list(csv.DictReader((r11/'assay_packet/evaluation/minimal_frozen_evaluation.csv').open()))
preds=load(r11/'classifier_predictions.json'); pm={x['assembly_id']:x for x in preds['assemblies']}; inputs={x['assembly_id']:x for x in load(r11/'input_metadata/input_manifest.json')}; qc={x['assembly_id']:x for x in load(r11/'input_metadata/construct_annotation_qc.json')}; reviewed={x['assembly_id']:x for x in load(exp/'data/expected_labels.json')['rows'] if x['dataset']=='tdomain'}
assert len(labels)==65 and len(reviewed)==65
seal=load(r11/'prediction_seal.json');assert sha(r11/'classifier_predictions.json')==seal['files']['classifier_predictions.json']
rows=[]
for x in labels:
 a=x['full_construct_id'];assert a in reviewed and a in pm and a in inputs and a in qc
 assert x['full_construct_sha256']==inputs[a]['amino_acid_sha256']
 assert int(x['reported_nonzero_production'])==reviewed[a]['observed_activity']
 assert inputs[a]['role']=='engineered';assert inputs[a]['context']=='GxpS_minimal_SU2_T3';assert qc[a]['status']=='CANDIDATE_ROUTE_ANNOTATED'
 y=int(x['reported_nonzero_production']); q=float(x['published_processed_percent_WT']);assert y==int(q>0)
 row={'assembly_id':a,'variant_id':x['variant_id'],'label':y,'published_processed_percent_WT':q,'minimum_ancestry_group':x['minimum_ancestry_group'],'source_agreement':x['source_agreement_sensitivity_eligible_after_annotation']=='True','protein_sha256':x['full_construct_sha256']}
 for ds in ['bode1','bode2']:
  for arm in ['global_context','typed_context']:
   v=pm[a]['predictions'][ds][arm]; assert v['folds']==(21 if ds=='bode1' else 35)
   assert abs(v['probability_mean']-np.mean([f['probability'] for f in v['fold_predictions']]))<1e-12
   row[ds+'_'+arm]=v['probability_mean']
 rows.append(row)
with (out/'tdomain_joined_sealed_predictions.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
keys=['bode1_global_context','bode1_typed_context','bode2_global_context','bode2_typed_context']
def metrics(y,p,q):
 z=(p>=.5).astype(int);tn,fp,fn,tp=confusion_matrix(y,z,labels=[0,1]).ravel()
 return {'n':len(y),'positive':int(sum(y)),'negative':int(len(y)-sum(y)),'auroc':float(roc_auc_score(y,p)),'average_precision':float(average_precision_score(y,p)),'balanced_accuracy':float(balanced_accuracy_score(y,z)),'mcc':float(matthews_corrcoef(y,z)),'bce':float(log_loss(y,p,labels=[0,1])),'brier':float(brier_score_loss(y,p)),'spearman_published_percent_WT':(float(spearmanr(p,q).statistic) if len(set(p)) > 1 and len(set(q)) > 1 else None),'threshold':.5,'tp':int(tp),'tn':int(tn),'fp':int(fp),'fn':int(fn)}
new={'status':'NEW_RETROSPECTIVE_ANALYSIS_20261016_NOT_A_HISTORICAL_E11_RUN_METRIC','protocol':str(r11/'PROTOCOL.json'),'label_source':str(r11/'assay_packet/evaluation/minimal_frozen_evaluation.csv'),'reviewed_label_confirmation':str(exp/'data/expected_labels.json'),'predictions_source':str(r11/'classifier_predictions.json'),'predictions_sha256':sha(r11/'classifier_predictions.json'),'sequence_join':'65/65 assembly IDs and full-protein SHA256 match original pre-inference input manifest; all65 reviewed labels exactly agree with published endpoint table','no_training_or_inference':True,'bootstrap':'2000 cluster bootstrap replicates, seed20261016, sampling documented minimum ancestry groups with replacement; 2.5th/97.5th percentile interval, valid both-class replicates only; conditional on archived scores, not refit bootstrap; minimum groups do not establish homology independence','cohorts':{}}
for cohort,rr in [('minimal_65',rows),('source_agreement_63',[x for x in rows if x['source_agreement']])]:
 y=np.array([x['label'] for x in rr]);q=np.array([x['published_processed_percent_WT'] for x in rr]); groups=sorted(set(x['minimum_ancestry_group'] for x in rr)); gidx=[np.array([i for i,x in enumerate(rr) if x['minimum_ancestry_group']==g],int) for g in groups];rng=np.random.default_rng(20261016)
 boot=[]
 for _ in range(2000):
  ix=np.concatenate([gidx[i] for i in rng.integers(0,len(groups),len(groups))]);
  if len(set(y[ix]))==2:boot.append(ix)
 cm={'n':len(rr),'positive':int(sum(y)),'minimum_groups':len(groups),'valid_bootstrap_replicates':len(boot),'arms':{},'paired_typed_minus_global':{}}
 samples={}
 for key in keys:
  p=np.array([x[key] for x in rr]);m=metrics(y,p,q);samples[key]={}
  for metric,fn in [('auroc',lambda a:roc_auc_score(y[a],p[a])),('average_precision',lambda a:average_precision_score(y[a],p[a])),('spearman_published_percent_WT',lambda a:spearmanr(p[a],q[a]).statistic)]:
   vals=np.array([fn(ix) for ix in boot]);vals=vals[np.isfinite(vals)];samples[key][metric]=vals;m[metric+'_bootstrap95']=np.quantile(vals,[.025,.975]).tolist()
  cm['arms'][key]=m
 for ds in ['bode1','bode2']:
  cm['paired_typed_minus_global'][ds]={metric:{'delta':cm['arms'][ds+'_typed_context'][metric]-cm['arms'][ds+'_global_context'][metric],'bootstrap95':np.quantile(samples[ds+'_typed_context'][metric]-samples[ds+'_global_context'][metric],[.025,.975]).tolist()} for metric in ['auroc','average_precision','spearman_published_percent_WT']}
 new['cohorts'][cohort]=cm
result['e11_new_analysis']=new
result['all494']['class_counts']={ds:dict(collections.Counter(x['observed_activity'] for x in load(exp/'data/training_rows.json') if x['dataset']==ds)) for ds in ['bode1','bode2','tdomain']}
# In-sample metrics are labelled as descriptive only, never external validation.
pr=load(exp/'models/all494/training_predictions.json');insample={}
for ds in ['all494','bode1','bode2','tdomain']:
 rr=[x for x in pr if ds=='all494' or x['dataset']==ds]; y=np.array([x['observed_activity'] for x in rr]);p=np.array([x['activity_score'] for x in rr]);m=metrics(y,p,y);m.pop('spearman_published_percent_WT');insample[ds]=m
result['all494']['newly_computed_in_sample_metrics_not_validation']=insample
(out/'transfer_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(new,indent=2));print('E7 fit audit',result['e7']['fit_audit']);print('IN SAMPLE',insample)
# Independently reproduce archived E6/E7 aggregate classification metrics.
checks=[]
y6={x['assembly_id']:int(x['expected_product_detected']) for x in csv.DictReader((r6/'bode2_assay_outcomes.csv').open())}; p6=load(r6/'bode2_predictions.json'); old6=load(r6/'summary.json')['external_evaluation']['metrics']
for arm,old in old6.items():
 y=np.array([y6[x['assembly_id']] for x in p6]);p=np.array([x[arm] for x in p6]);newm=metrics(y,p,y)
 for k,newk in [('auroc','auroc'),('auprc_average_precision','average_precision'),('bce','bce'),('brier','brier'),('mcc','mcc'),('balanced_accuracy','balanced_accuracy')]:
  assert abs(old[k]-newm[newk])<1e-12,(arm,k,old[k],newm[newk]);checks.append({'run':'e6','arm':arm,'metric':k,'absolute_error':abs(old[k]-newm[newk])})
p7=list(csv.DictReader((r7/'held_out_predictions.csv').open()));old7=load(r7/'summary.json')
for arm,old in old7['bode2_oof'].items():
 rr=[x for x in p7 if x['benchmark']=='bode2_donor' and x['arm']==arm];assert len(rr)==len(set(x['assembly_id'] for x in rr))==105
 y=np.array([int(x['label']) for x in rr]);p=np.array([float(x['probability']) for x in rr]);newm=metrics(y,p,y)
 for k,newk in [('auroc','auroc'),('auprc_average_precision','average_precision'),('bce','bce'),('brier','brier'),('mcc','mcc'),('balanced_accuracy','balanced_accuracy')]:
  assert abs(old[k]-newm[newk])<1e-12,(arm,k);checks.append({'run':'e7_bode2','arm':arm,'metric':k,'absolute_error':abs(old[k]-newm[newk])})
for arm,old in old7['bode1_donor'].items():
 rr=[x for x in p7 if x['benchmark']=='bode1_donor' and x['arm']==arm];tasks=sorted(set(x['task_id'] for x in rr)); assert len(tasks)==21
 ms=[]
 for t in tasks:
  tr=[x for x in rr if x['task_id']==t];y=np.array([int(x['label']) for x in tr]);p=np.array([float(x['probability']) for x in tr]);ms.append(metrics(y,p,y))
 for k,newk in [('auroc','auroc'),('auprc_average_precision','average_precision'),('bce','bce'),('brier','brier'),('mcc','mcc'),('balanced_accuracy','balanced_accuracy')]:
  val=float(np.mean([m[newk] for m in ms]));assert abs(old[k]['mean']-val)<1e-12,(arm,k);checks.append({'run':'e7_bode1','arm':arm,'metric':k,'absolute_error':abs(old[k]['mean']-val)})
result['archived_metric_reproduction']={'checks':len(checks),'max_absolute_error':max(x['absolute_error'] for x in checks),'checks_detail':checks}
(out/'transfer_results.json').write_text(json.dumps(result,indent=2)+'\n')
print('Verified archived metric checks',len(checks))
