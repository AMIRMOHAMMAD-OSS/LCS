from pathlib import Path
import json,csv,statistics,math,collections
import argparse
parser=argparse.ArgumentParser(description='Recompute report records from the extracted original input archive; no model training.')
parser.add_argument('--input',type=Path,required=True,help='Directory containing REPORT_INPUT_INDEX.json and source/')
parser.add_argument('--output',type=Path,required=True,help='Directory for newly computed tables and records')
args=parser.parse_args()
args.output.mkdir(parents=True,exist_ok=True)
R=args.input/'source/NeurALPSv2'; O=args.output
J=lambda p:json.loads(p.read_text())
def writecsv(name,rows):
 keys=list(dict.fromkeys(k for r in rows for k in r))
 with (O/name).open('w',newline='') as f:
  w=csv.DictWriter(f,keys);w.writeheader();w.writerows(rows)
def auc(rows):
 pos=[float(v['probability']) for v in rows if int(v['label'])==1];neg=[float(v['probability']) for v in rows if int(v['label'])==0]
 return sum((p>n)+0.5*(p==n) for p in pos for n in neg)/len(pos)/len(neg) if pos and neg else None
def ap(rows):
 grouped=collections.defaultdict(list)
 for v in rows:grouped[float(v['probability'])].append(int(v['label']))
 total=sum(sum(v) for v in grouped.values());tp=n=0;area=0
 for prob,ys in sorted(grouped.items(),reverse=True):
  tp+=sum(ys);n+=len(ys);area+=sum(ys)*tp/n
 return area/total if total else None
runs=[];metrics=[];fits=[];splits=[];contrasts=[];verify=[];diagnostics=[];epochs=[]
for d in sorted(R.iterdir()):
 if not d.is_dir() or not d.name.startswith(('e2_','e3_','e4_','e5_')):continue
 c=J(d/'config.json');s=J(d/'summary.json');x=J(d/'classification.json');tasks=c['tasks'];source=f'{d.name}/classification.json'
 counts={k:x[k] for k in ['completed_tasks','planned_tasks','completed_base_reports','planned_base_reports','new_fits','reused_controls','ensemble_evaluations'] if k in x}
 runs.append(dict(run=d.name,profile=c['profile'],settings=c['settings'],recipe=c['recipe'],ssl_run=c.get('ssl_run'),source_ssl_selected_step=s.get('source_ssl_selected_step'),source_ssl_updates=s.get('source_ssl_updates'),status=s['status'],counts=counts,arms=sorted(set(t['arm'] for t in tasks)),folds=len(set(t['part'] for t in tasks)),source_config=f'{d.name}/config.json',source_summary=f'{d.name}/summary.json',seconds=s['seconds_this_attempt'],limits=s.get('limits'),ensemble=c.get('ensemble')))
 for key in ['macro_by_donor_fold','macro_by_arm_seed','seed_summary','construct_aggregated_metrics']:
  for i,row in enumerate(x.get(key,[])):
   for metric,val in row['metrics'].items():
    entry=dict(run=d.name,profile=c['profile'],aggregation=key,arm=row['arm'],seed=row.get('seed',''),seeds=';'.join(map(str,row.get('seeds',[]))),budget=row.get('budget',1),folds=row.get('folds',';'.join(map(str,row.get('folds_per_seed',[])))),metric=metric,source=f'{source}#/{key}/{i}/metrics/{metric}')
    if isinstance(val,dict):entry.update(val)
    else:entry['value']=val
    metrics.append(entry)
 for i,t in enumerate(tasks):
  inn=t['inner']; fit=set(inn['fit_ids']); val=set(inn['validation_ids']); test=set(t['test_ids']);assert not (fit&val or fit&test or val&test)
  splits.append(dict(run=d.name,task_id=t['task_id'],arm=t['arm'],seed=t['seed'],outer_part=t['part'],inner_part=inn.get('inner_held_out_part'),fit_n=len(fit),validation_n=len(val),test_n=len(test),fit_positive=inn['fit_classes'].get('1'),validation_positive=inn['validation_classes'].get('1'),budget=t['budget'],label_budget=t['label_budget'],source=f'{d.name}/config.json#/tasks/{i}'))
 for i,v in enumerate(x.get('paired_comparisons',[])):
  base=dict(run=d.name,comparison=v.get('comparison',str(v.get('candidate'))+' minus '+str(v.get('reference'))),source=f'{source}#/paired_comparisons/{i}')
  if 'by_seed' in v:
   for q in v['by_seed']:
    contrasts.append(dict(base,seed=q['seed'],paired_folds=q.get('folds',q.get('paired_folds')),**q['mean_delta'],donor_wins=v.get('donor_wins'),donor_ties=v.get('donor_ties'),donor_losses=v.get('donor_losses')))
  else:contrasts.append(dict(base,seed=v['seed'],paired_folds=v['paired_folds'],auroc=v['mean_auroc_difference']))
 paths=list((d/'fits').glob('*/complete.json'))+list((d/'controls').glob('*/complete.json'))+list((d/'ensembles').glob('*.json'))
 checks=collections.Counter();maxerr=collections.defaultdict(float)
 for p in paths:
  v=J(p);rows=v['predictions'];saved=v['test'];computed={'auroc':auc(rows),'auprc_average_precision':ap(rows),'brier':statistics.mean((float(q['probability'])-int(q['label']))**2 for q in rows)}
  for k,got in computed.items():
   if got is not None and saved.get(k) is not None:
    err=abs(got-saved[k]);maxerr[k]=max(maxerr[k],err);checks[k]+=1
  rec={k:v.get(k) for k in ['arm','seed','part','task_id','epochs_completed','selected_epoch','selected_has_updates','selected_encoder_updated','encoder_updates','encoder_optimizer_steps','checkpoint_reload_exact','reused','reused_test_prediction_parity','seconds','trainable_parameters','checkpoint_sha256','outer_test_used_for_selection','raw_weight']}
  rec.update(run=d.name,kind=p.relative_to(d).parts[0],source=str(p.relative_to(R)),test_n=len(rows),test_auroc=saved['auroc'],test_ap=saved['auprc_average_precision'],validation_bce=v['validation'].get('bce'))
  fits.append(rec)
 verify.append(dict(run=d.name,records_checked=len(paths),checks=dict(checks),maximum_absolute_error=dict(maxerr)))
 assert all(e<1e-12 for e in maxerr.values()),(d.name,maxerr)
 for arm in sorted(set(v['arm'] for v in fits if v['run']==d.name)):
  ff=[v for v in fits if v['run']==d.name and v['arm']==arm and v['kind']!='ensembles'];ep=[v['epochs_completed'] for v in ff if v['epochs_completed'] is not None];se=[v['selected_epoch'] for v in ff if v['selected_epoch'] is not None]
  if ep:epochs.append(dict(run=d.name,arm=arm,records=len(ff),epochs_completed_min=min(ep),epochs_completed_max=max(ep),epochs_completed_median=statistics.median(ep),selected_epoch_min=min(se),selected_epoch_max=max(se),selected_epoch_median=statistics.median(se),epoch_zero_selected=sum(v==0 for v in se),selected_encoder_updated=(sum(v.get('selected_encoder_updated') is True for v in ff) if any(v.get('selected_encoder_updated') is not None for v in ff) else None),source=f'{d.name}/fits/*/complete.json'))
 if (d/'diagnostics_summary.json').exists():
  dd=J(d/'diagnostics_summary.json')
  for i,v in enumerate(dd['methods']):diagnostics.append(dict(run=d.name,**{k:v for k,v in v.items() if k!='per_pair'},source=f'{d.name}/diagnostics_summary.json#/methods/{i}'))
out=dict(runs=runs,validation=verify,diagnostics=diagnostics,epoch_summaries=epochs)
(O/'mlp_results.json').write_text(json.dumps(out,indent=2)+'\n')
for name,rows in [('mlp_metrics.csv',metrics),('mlp_fit_records.csv',fits),('mlp_split_counts.csv',splits),('mlp_contrasts.csv',contrasts),('mlp_diagnostics.csv',diagnostics),('mlp_epoch_summaries.csv',epochs)]:writecsv(name,rows)
print('runs',len(runs),'fit and ensemble records',len(fits),'metrics',len(metrics),'split records',len(splits),'contrasts',len(contrasts));print('Max error',max(e for v in verify for e in v['maximum_absolute_error'].values()))
