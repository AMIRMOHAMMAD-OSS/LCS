NeurALPS recorded pretraining metrics
====================================

Start with evaluations.csv. For the saved model comparison, filter
record_type=selected_dev. Use mode=model for the full path and
mode=local_only_at_eval for the global-bypass control.

Files
  evaluations.csv: initial, final and selected states for all recorded modes,
    all periodic full-model development evaluations, and parent-parity checks.
  training_progress.csv: every recorded training-progress point, including
    cumulative training diagnostics, LR, ranking coefficient and gradient norm.
  run_summary.csv: completed/selected updates, counts, checks and endpoint
    cumulative training statistics.
  configurations.csv: every nested field from the five effective run configs.
  diagnostics.csv: saved runtime, attempt, parent-validation, target-preparation
    and RAM diagnostic values; nested arrays are retained as indexed paths.
  all_recorded_values.csv: lossless JSON scalar/empty-container values from all
    selected source records, with file, line and JSON Pointer. This includes
    metrics, flags, provenance and log fields not given a dedicated wide column.
  metric_dictionary.csv: metric and mode definitions.
  source_files.csv: relative source filenames, byte counts and SHA-256 checksums.
  EXPORT_MANIFEST.json: source root, export checks and CSV counts/hashes.
  export_pretraining_metrics.py: repeat this read-only export on Jean Zay with
    Python 3.9+; no imports beyond the standard library and no GPU allocation.

Scope and interpretation
Only the five documented SSL runs and their recorded diagnostics are exported.
No classifier, engineered-set AUROC, fresh inference or training is performed.
These are aggregate evaluation metrics. Per-assembly/per-piece predictions were
not saved in these training summaries; exporting them requires a different
inference task. Missing results are not synthesized.

The same checkpoint can appear as periodic_dev, final_dev and selected_dev.
These are provenance-distinct records, not independent replicates. The pilot
uses 256 dev views; the other four runs use the same 3,498 eligible fixed views.
Continuation initial_dev is the original update-0 reference, not phase entry.
There is no periodic local-only/type/length curve in the saved logs; those modes
are available at initial/final/selected states. Training values are cumulative
over changing sampled masks and should not be treated as fixed-dev evaluations.
Summary seconds inherit checkpoint counters; do not sum them across phases or
call their differences exact phase wall times. Wrapper times are in diagnostics.

CSV uses UTF-8 with BOM and comma delimiters for Windows/Excel. Numeric values
retain Python's round-trip representation of the source JSON number. No scores
are rounded for display. Missing wide-table values are blank, never zero; the
long table preserves explicit null with value_type=null and value_json=null.
Rows/objects are not weighted equally by all metrics: retain the implemented
object/kind/assembly balancing when interpreting recall and losses.

Direct repeat on Jean Zay
python3 export_pretraining_metrics.py --root /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2 --output /lustre/fswork/projects/rech/nef/unh87ms/NeurALPS_release_exports/NeurALPS_Pretraining_Metrics_20261015

The script refuses to overwrite existing exports. Choose a new output name for
a repeat, and transfer the newly printed ZIP path.
