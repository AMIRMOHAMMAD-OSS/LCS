#!/usr/bin/env python3
"""Export recorded NeurALPS SSL metrics. Python 3.9+; no Torch/GPU required."""
import argparse
import csv
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
import shutil
import tempfile
import zipfile

ROOT = Path('/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2')
RUNS = [
    'e1_ssl_pilot_497190',
    'e1_ssl_ram_development_511325',
    'e1_ssl_ram_development_no_rank_526745',
    'e1_ssl_continue_development_527237',
    'e1_ssl_continue30_v1_530757',
]
KIND_NAMES = {'0': 'domain', '1': 'covalent_boundary', '2': 'interprotein_boundary'}


def flatten(value, prefix=''):
    if isinstance(value, dict) and value:
        for key, item in value.items():
            yield from flatten(item, prefix + '/' + str(key).replace('~', '~0').replace('/', '~1'))
    elif isinstance(value, list) and value:
        for i, item in enumerate(value):
            yield from flatten(item, prefix + '/' + str(i))
    else:
        yield prefix or '/', value


def wide(value, prefix=''):
    result = {}
    for key, item in value.items():
        name = prefix + key
        if isinstance(item, dict):
            result.update(wide(item, name + '.'))
        elif isinstance(item, list):
            result[name] = json.dumps(item, ensure_ascii=False, allow_nan=False)
        else:
            result[name] = item
    return result


def metric_columns(metrics):
    row = wide(metrics)
    for kind, name in KIND_NAMES.items():
        key = 'relations_by_kind.' + kind
        if key in row:
            row['relations_' + name] = row.pop(key)
    return row


def csv_write(path, rows, first=()):
    fields = list(first)
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return {'file': path.name, 'rows': len(rows), 'columns': len(fields),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path, required=True,
                        help='New output directory; a sibling .zip is also created.')
    args = parser.parse_args()
    root, out = args.root.resolve(), args.output.expanduser().resolve()
    archive = out.with_suffix('.zip')
    if out.exists() or archive.exists():
        raise SystemExit('Output already exists. Choose a new --output name; nothing was overwritten.')
    records, sources = [], {}

    def read(path):
        before = path.stat()
        data = path.read_bytes()
        after = path.stat()
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise ValueError('Source changed while reading: ' + str(path))
        rel = path.relative_to(root).as_posix()
        sources[rel] = {'source_file': rel, 'bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()}
        return rel, data.decode('utf-8')

    def read_json(path, run, record_type):
        rel, text = read(path)
        value = json.loads(text)
        records.append((run, rel, '', record_type, value))
        return rel, value

    evaluation, training, summaries, configs, diagnostics, checks = [], [], [], [], [], []
    summary_data = {}
    for run in RUNS:
        folder = root / run
        source, summary = read_json(folder / 'summary.json', run, 'summary')
        _, config = read_json(folder / 'config.json', run, 'configuration')
        summary_data[run] = summary
        phase_start = summary.get('parent_step', 0)
        base = {'run': run, 'phase_start_step': phase_start,
                'selected_step': summary['selected_step'], 'completed_updates': summary['updates']}
        for block, step in [('initial_dev', 0), ('final_dev', summary['updates']),
                            ('selected_dev', summary['selected_step'])]:
            for mode, metrics in summary[block].items():
                evaluation.append({**base, 'record_type': block, 'mode': mode,
                                   'checkpoint_step': step, 'source_file': source, 'source_line': '',
                                   'baseline_inherited': block == 'initial_dev' and phase_start > 0,
                                   **metric_columns(metrics)})
        scalar_summary = {key: value for key, value in summary.items()
                          if not isinstance(value, (dict, list))}
        summaries.append({**base, 'source_file': source, **scalar_summary,
                          **{'cumulative_train.' + key: value
                             for key, value in metric_columns(summary['train']).items()}})
        for pointer, value in flatten(config):
            configs.append({'run': run, 'source_file': run + '/config.json',
                            'json_pointer': pointer, 'value_json': json.dumps(value, ensure_ascii=False, allow_nan=False)})

        progress_source, progress_text = read(folder / 'progress.jsonl')
        progress = []
        for line_no, line in enumerate(progress_text.splitlines(), 1):
            if not line.strip():
                continue
            event = json.loads(line)
            progress.append(event)
            records.append((run, progress_source, line_no, 'training_progress', event))
            row = {key: value for key, value in event.items() if key != 'train'}
            training.append({**base, 'source_file': progress_source, 'source_line': line_no,
                             **wide(row), **{'cumulative_train.' + key: value
                                            for key, value in metric_columns(event['train']).items()}})

        log_source, log_text = read(root / (run + '.log'))
        logged_progress, dev_events, parent_events = [], [], []
        for line_no, line in enumerate(log_text.splitlines(), 1):
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue  # Module messages and pretty-printed terminal summary are not JSONL events.
            if not isinstance(event, dict):
                continue
            if 'step' in event and 'train' in event and 'stage' not in event:
                logged_progress.append(event)
                continue  # Identical progress values are exported from progress.jsonl once.
            stage = event.get('stage')
            if not stage:
                continue
            records.append((run, log_source, line_no, 'log.' + str(stage), event))
            if stage not in ('DEV', 'PARENT_DEV_PARITY_PASS'):
                continue  # INITIAL_DEV duplicates summary.initial_dev; raw event is retained in long CSV.
            step = event.get('step', event.get('parent_step'))
            evaluation.append({**base, 'record_type': 'periodic_dev' if stage == 'DEV' else 'parent_parity',
                               'mode': 'model', 'checkpoint_step': step,
                               'source_file': log_source, 'source_line': line_no,
                               'baseline_inherited': False, 'best_so_far': event.get('best'),
                               **metric_columns(event['metrics'])})
            (dev_events if stage == 'DEV' else parent_events).append(event)

        if not progress or progress != logged_progress:
            raise ValueError('Progress file and stdout records differ: ' + run)
        if any(a['step'] >= b['step'] for a, b in zip(progress, progress[1:])):
            raise ValueError('Nonmonotone or duplicated logged updates: ' + run)
        if progress[-1]['step'] != summary['updates']:
            raise ValueError('Summary/progress endpoint differs: ' + run)
        interval = config['settings']['eval_every']
        expected = list(range(phase_start + interval, summary['updates'] + 1, interval))
        if summary['updates'] not in expected:
            expected.append(summary['updates'])
        if [event['step'] for event in dev_events] != expected:
            raise ValueError('Incomplete or duplicated periodic evaluation history: ' + run)
        if dev_events[-1]['metrics'] != summary['final_dev']['model']:
            raise ValueError('Final evaluation differs between log and summary: ' + run)
        selected = next((e for e in dev_events if e['step'] == summary['selected_step']), None)
        if selected is None or selected['metrics'] != summary['selected_dev']['model']:
            raise ValueError('Selected evaluation differs between log and summary: ' + run)
        checks.append({'run': run, 'progress_rows': len(progress), 'periodic_evaluations': len(dev_events),
                       'parent_parity_evaluations': len(parent_events), 'status': 'verified'})

        extra_files = set(folder.glob('*runtime*.json')) | set(folder.glob('attempt_*.json'))
        if (folder / 'parent_validation.json').is_file():
            extra_files.add(folder / 'parent_validation.json')
        for path in sorted(extra_files):
            rel, value = read_json(path, run, 'diagnostic')
            for pointer, leaf in flatten(value):
                diagnostics.append({'run': run, 'source_file': rel, 'json_pointer': pointer,
                                    'value_json': json.dumps(leaf, ensure_ascii=False, allow_nan=False)})

    for name in ['e1_runtime_507658', 'e1_ssl_targets_497189']:
        rel, value = read_json(root / name / 'summary.json', name, 'diagnostic_summary')
        for pointer, leaf in flatten(value):
            diagnostics.append({'run': name, 'source_file': rel, 'json_pointer': pointer,
                                'value_json': json.dumps(leaf, ensure_ascii=False, allow_nan=False)})

    long_rows = []
    for run, source, line_no, record_type, value in records:
        for pointer, leaf in flatten(value):
            if isinstance(leaf, float) and not math.isfinite(leaf):
                raise ValueError('Nonfinite recorded value at ' + source + ':' + str(line_no) + pointer)
            value_type = ('null' if leaf is None else 'boolean' if isinstance(leaf, bool)
                          else 'integer' if isinstance(leaf, int) else 'number' if isinstance(leaf, float)
                          else 'string' if isinstance(leaf, str) else 'empty_container')
            long_rows.append({'run': run, 'source_file': source, 'source_line': line_no,
                              'record_type': record_type, 'json_pointer': pointer,
                              'value_type': value_type,
                              'value_json': json.dumps(leaf, ensure_ascii=False, allow_nan=False)})

    dictionary = [
        ('object', 'Balanced centered reconstruction objective; lower is better; not an activity probability.'),
        ('raw', 'Raw cosine reconstruction error; lower is better.'),
        ('rank', 'Matched-candidate ranking loss; lower is better. Recorded even when its training coefficient is zero.'),
        ('recall1', 'Native candidate recall@1, tie-aware and balanced by object/kind/assembly; higher is better.'),
        ('recall5', 'Native candidate recall@5 with the same reduction; higher is better.'),
        ('mrr', 'Mean reciprocal native-candidate rank with expected metric over exact ties; higher is better.'),
        ('pred_residual_norm', 'Reported mean norm of prediction minus training-group mean.'),
        ('target_residual_norm', 'Reported mean norm of target minus training-group mean.'),
        ('assemblies', 'Eligible evaluation assemblies, or cumulative accepted training presentations for cumulative_train fields.'),
        ('relations', 'Number of primary physical target objects.'),
        ('ranked_relations', 'Primary objects with a candidate panel containing alternatives.'),
        ('ranked_assemblies', 'Assemblies containing at least one ranked target.'),
        ('relations_domain', 'Domain primary-object count (original kind 0).'),
        ('relations_covalent_boundary', 'Covalent-boundary primary-object count (original kind 1).'),
        ('relations_interprotein_boundary', 'Between-protein boundary primary-object count (original kind 2).'),
        ('mean_candidates', 'Candidate total divided by ranked relations, including the native positive.'),
        ('mean_closure_fraction', 'Average hidden-role fraction after physical/alias closure; not the nominal primary-mask fraction.'),
        ('grad_norm', 'Training gradient norm before clipping.'),
        ('lr', 'Assigned learning rate for the logged optimizer update.'),
        ('rank_weight', 'Ranking coefficient for the logged optimizer update.'),
        ('epoch', 'Zero-based sampler epoch index, not a completed-epoch count.'),
        ('seconds', 'Trainer elapsed counter; continuations inherit parent latest-checkpoint seconds. Not phase wall time.'),
        ('wall_seconds', 'Wrapper process time in diagnostics; scope differs by wrapper and excludes some shell setup.'),
        ('peak_gpu_gib', 'Reported PyTorch peak GPU memory in GiB.'),
        ('model', 'Full local-plus-global model path.'),
        ('local_only_at_eval', 'Same trained checkpoint with global blocks bypassed; not independently trained local-only weights.'),
        ('type', 'Frozen training group-mean predictor.'),
        ('length', 'Frozen type/orientation-and-length-mean predictor with fallback.'),
        ('initial_dev', 'Original random-initialization reference at update 0; inherited in continuation summaries.'),
        ('final_dev', 'Evaluation of the completed endpoint weights.'),
        ('selected_dev', 'Evaluation of the checkpoint chosen by lowest full-model development object loss.'),
        ('periodic_dev', 'Periodic full-model evaluation recorded in stdout; controls were not logged at every checkpoint.'),
        ('parent_parity', 'Full-model evaluation after loading a continuation parent; not a new training update.'),
        ('best_so_far', 'Best object loss field exactly as emitted by the periodic log event; do not substitute another metric.'),
        ('cumulative_train.*', 'Cumulative average/counter across sampled training views since independent lineage initialization; not minibatch or validation metrics.'),
    ]
    readme = '''NeurALPS recorded pretraining metrics
====================================

Start with evaluations.csv. For the saved model comparison, filter
record_type=selected_dev. Use mode=model for the full path and
mode=local_only_at_eval for the global-bypass control.

Files
  evaluations.csv: initial, final and selected states for all recorded modes,
    all periodic full-model development evaluations, and parent-parity checks.
  training_progress.csv: every recorded training-progress point, including
    cumulative training diagnostics, LR, ranking coefficient and gradient norm.
  run_summary.csv: completed/selected updates, counts, checks and endpoint
    cumulative training statistics.
  configurations.csv: every nested field from the five effective run configs.
  diagnostics.csv: saved runtime, attempt, parent-validation, target-preparation
    and RAM diagnostic values; nested arrays are retained as indexed paths.
  all_recorded_values.csv: lossless JSON scalar/empty-container values from all
    selected source records, with file, line and JSON Pointer. This includes
    metrics, flags, provenance and log fields not given a dedicated wide column.
  metric_dictionary.csv: metric and mode definitions.
  source_files.csv: relative source filenames, byte counts and SHA-256 checksums.
  EXPORT_MANIFEST.json: source root, export checks and CSV counts/hashes.
  export_pretraining_metrics.py: repeat this read-only export on Jean Zay with
    Python 3.9+; no imports beyond the standard library and no GPU allocation.

Scope and interpretation
Only the five documented SSL runs and their recorded diagnostics are exported.
No classifier, engineered-set AUROC, fresh inference or training is performed.
These are aggregate evaluation metrics. Per-assembly/per-piece predictions were
not saved in these training summaries; exporting them requires a different
inference task. Missing results are not synthesized.

The same checkpoint can appear as periodic_dev, final_dev and selected_dev.
These are provenance-distinct records, not independent replicates. The pilot
uses 256 dev views; the other four runs use the same 3,498 eligible fixed views.
Continuation initial_dev is the original update-0 reference, not phase entry.
There is no periodic local-only/type/length curve in the saved logs; those modes
are available at initial/final/selected states. Training values are cumulative
over changing sampled masks and should not be treated as fixed-dev evaluations.
Summary seconds inherit checkpoint counters; do not sum them across phases or
call their differences exact phase wall times. Wrapper times are in diagnostics.

CSV uses UTF-8 with BOM and comma delimiters for Windows/Excel. Numeric values
retain Python's round-trip representation of the source JSON number. No scores
are rounded for display. Missing wide-table values are blank, never zero; the
long table preserves explicit null with value_type=null and value_json=null.
Rows/objects are not weighted equally by all metrics: retain the implemented
object/kind/assembly balancing when interpreting recall and losses.

Direct repeat on Jean Zay
python3 export_pretraining_metrics.py --root /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2 --output /lustre/fswork/projects/rech/nef/unh87ms/NeurALPS_release_exports/NeurALPS_Pretraining_Metrics_20261015

The script refuses to overwrite existing exports. Choose a new output name for
a repeat, and transfer the newly printed ZIP path.
'''

    # All source reading and cross-checks finish before creating the output.
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.neuralps_csv_', dir=str(out.parent)) as temporary:
        stage = Path(temporary) / out.name
        stage.mkdir()
        csv_info = []
        for name, rows, first in [
            ('evaluations.csv', evaluation, ['run','record_type','mode','checkpoint_step']),
            ('training_progress.csv', training, ['run','step']),
            ('run_summary.csv', summaries, ['run']),
            ('configurations.csv', configs, ['run','source_file','json_pointer','value_json']),
            ('diagnostics.csv', diagnostics, ['run','source_file','json_pointer','value_json']),
            ('all_recorded_values.csv', long_rows, ['run','record_type','source_file','source_line','json_pointer','value_type','value_json']),
            ('source_files.csv', list(sources.values()), ['source_file','bytes','sha256']),
            ('metric_dictionary.csv', [{'field': field, 'meaning': meaning} for field, meaning in dictionary], ['field','meaning']),
        ]:
            csv_info.append(csv_write(stage / name, rows, first))
        (stage / 'README.txt').write_text(readme, encoding='utf-8')
        shutil.copyfile(Path(__file__), stage / 'export_pretraining_metrics.py')
        manifest = {'export_version': '1.0', 'created_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                    'source_root_read': str(root), 'historical_jeanzay_root': str(ROOT),
                    'no_training_or_inference': True, 'runs': RUNS,
                    'csv_files': csv_info, 'checks': checks,
                    'scope': 'Recorded SSL aggregates and diagnostics; no classifiers or per-assembly predictions.'}
        (stage / 'EXPORT_MANIFEST.json').write_text(json.dumps(manifest, indent=2, allow_nan=False)+'\n', encoding='utf-8')
        stage.rename(out)
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(out.iterdir()):
            z.write(path, arcname=out.name + '/' + path.name)
    print('COMPLETE: recorded metrics exported; no training or inference.')
    for info in csv_info:
        print(info['file'] + ': ' + str(info['rows']) + ' rows')
    print('ZIP: ' + str(archive))
    print('SHA256: ' + hashlib.sha256(archive.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
