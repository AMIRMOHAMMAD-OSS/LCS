# V2-A E22 meeting figure captions

## Figure 1 — Engineered activity transfer
A V2-A checkpoint trained without Bode activity labels assigns higher mean
seam compatibility to active than inactive Bode constructs.
ROC–AUC = 0.663; AP = 0.702.
Active mean = 0.760; inactive mean = 0.624.

## Figure 2 — Partner-specific residual compatibility
Experimental and model pair effects after subtraction of individual-part main
effects. Heatmaps are z-scored within each panel only to emphasize spatial
pattern correspondence.

## Figure 3 — Residual compatibility correlation
Initiation–elongation:
Pearson r = 0.368, p = 0.00618.

Elongation–termination:
Pearson r = 0.425, p = 0.001355.

These results indicate that the model captures partner-specific compatibility
beyond general part quality.

## Figure 4 — Seam phenotypes
Three representative engineered lines illustrate a coherent active profile, an
inactive line containing a localized low-scoring candidate bottleneck, and an
inactive line with diffuse low compatibility. Low-scoring seams are predictions,
not experimentally proven causal lesions.

## Figure 5 — Controlled one-part substitution
The strongest matched activity flip holds two engineered parts fixed and changes
only the elongation part. The active and inactive constructs differ by
1.021 in mean compatibility.

## Figure 6 — Compatibility versus heterogeneity
Active constructs tend to combine higher mean compatibility with lower
within-line seam variability. This supports a model in which successful
assembly requires both sufficiently compatible interfaces and a coherent
whole-line compatibility profile.

## Status
All figures use the provisional V2-A E22 checkpoint for time-critical
exploratory meeting analysis. Final external-validation figures must be rerun
after frozen natural-DEV checkpoint selection.
