from __future__ import annotations

from pathlib import Path
import csv
import gzip
import hashlib
import os
import sys

import numpy as np
import pandas as pd
import torch

from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
)


ROOT = (
    Path(os.environ["WORK"])
    / "NeurALPSv2"
)

for p in (
    ROOT,
    ROOT / "src",
):
    if str(p) not in sys.path:
        sys.path.insert(
            0,
            str(p),
        )


# =====================================================================
# Frozen production code
# =====================================================================

from neuralps.evaluation.bode_structured_module_store_v1_1 import (
    StructuredModuleStoreV1_1,
)

from neuralps.evaluation.bode_embedding_store_v2 import (
    BodeEmbeddingStoreV2,
)

from neuralps.evaluation.bode_structured_path_store_v2 import (
    BodeStructuredPathStoreV2,
)

from neuralps.data.embedding_store import (
    EmbeddingStore,
)

from neuralps.data.structured_module_batch_v1_1 import (
    StructuredModuleBatchBuilderV1_1,
)

from neuralps.data.path_routing_batch_v2 import (
    PathRoutingBatchBuilderV2,
)

from neuralps.data.collate_v2b import (
    RouteATrainCollatorV2B,
)

from neuralps.data.assembly_context_store_v2 import (
    AssemblyContextStoreV2,
)

from neuralps.data.junction_store import (
    JunctionStore,
)

from neuralps.models.routea_v2c import (
    RouteAV2C,
)

from neuralps.training.routea_v2c_runtime import (
    move_batch_v2c,
    forward_model_v2c,
)


# =====================================================================
# Paths
# =====================================================================

BODE_INTERFACES = (
    ROOT
    / "data"
    / "bode_inference_v1_0"
    / "interfaces.tsv.gz"
)

BODE_STRUCTURED = (
    ROOT
    / "data"
    / "bode_structured_v1_1_exploratory"
)

BODE_EMBED = (
    ROOT
    / "results"
    / "bode_esmc600m_embeddings"
)

BODE_BOUNDARY = (
    ROOT
    / "results"
    / "bode_esmc600m_embeddings_v1_1"
    / "boundaries"
)

BODE_CONTEXT = (
    ROOT
    / "data"
    / "bode_v2c_context_e22"
)

CHECKPOINT_ROOT = (
    ROOT
    / "results"
    / "training"
    / "routeA_v2bc"
    / "C_A0_seed20260813"
    / "checkpoints"
)

MEETING = (
    ROOT
    / "results"
    / "analysis"
    / "v2a_biology_snapshot_20260820"
    / "meeting_e22"
)

LABEL_ATLAS = (
    MEETING
    / "construct_atlas_e22.tsv"
)

OUT = (
    ROOT
    / "results"
    / "analysis"
    / "v2c_biology_snapshot_20260820"
    / "bode_epochs01_05"
)

OUT.mkdir(
    parents=True,
    exist_ok=True,
)

BATCH_SIZE = 64


# =====================================================================
# Helpers
# =====================================================================

def read_gz(path):

    with gzip.open(
        path,
        "rt",
        encoding="utf-8",
        newline="",
    ) as f:

        yield from csv.DictReader(
            f,
            delimiter="\t",
        )


def sha256(path):

    h = hashlib.sha256()

    with path.open("rb") as f:

        for block in iter(
            lambda:
                f.read(
                    1024 * 1024
                ),
            b"",
        ):
            h.update(block)

    return h.hexdigest()


def bottom2(x):

    x = np.sort(
        np.asarray(
            x,
            dtype=float,
        )
    )

    return float(
        np.mean(
            x[:min(2, len(x))]
        )
    )


# =====================================================================
# Exact Bode interfaces
# =====================================================================

interfaces = list(
    read_gz(
        BODE_INTERFACES
    )
)

assert len(interfaces) == 1368


# =====================================================================
# Deterministic Bode dummy module pool
# =====================================================================

module_pool_map = {}

for row in interfaces:

    module_pool_map[
        row["left_module_uid"]
    ] = row[
        "left_sequence_hash"
    ]

    module_pool_map[
        row["right_module_uid"]
    ] = row[
        "right_sequence_hash"
    ]


module_pool = sorted(
    module_pool_map.items()
)

assert len(module_pool) == 1692


def dummy_for(uid):

    for candidate_uid, h in module_pool:

        if candidate_uid != uid:
            return (
                candidate_uid,
                h,
            )

    raise RuntimeError(
        "No dummy Bode module"
    )


# =====================================================================
# Bode V2-C collator
# =====================================================================

structured_store = (
    StructuredModuleStoreV1_1(
        BODE_STRUCTURED
    )
)

module_store = (
    BodeEmbeddingStoreV2(
        BODE_EMBED,
        "modules",
    )
)

domain_store = (
    BodeEmbeddingStoreV2(
        BODE_EMBED,
        "domains",
    )
)

boundary_store = (
    EmbeddingStore(
        BODE_BOUNDARY,
        "boundaries",
        max_cached_shards=4,
    )
)

structured_builder = (
    StructuredModuleBatchBuilderV1_1(
        structured_store=(
            structured_store
        ),
        module_embedding_store=(
            module_store
        ),
        domain_embedding_store=(
            domain_store
        ),
        boundary_embedding_store=(
            boundary_store
        ),
    )
)

path_store = (
    BodeStructuredPathStoreV2(
        BODE_STRUCTURED,
        structured_store=(
            structured_store
        ),
    )
)

path_builder = (
    PathRoutingBatchBuilderV2(
        path_store=(
            path_store
        )
    )
)

assembly_store = (
    AssemblyContextStoreV2(
        module_occurrences_path=(
            BODE_CONTEXT
            / "module_occurrences.tsv.gz"
        ),
        interfaces_path=(
            BODE_CONTEXT
            / "interfaces.tsv.gz"
        ),
        junctions_path=(
            BODE_CONTEXT
            / "junctions.tsv.gz"
        ),
    )
)

junction_store = (
    JunctionStore(
        BODE_CONTEXT
        / "junctions.tsv.gz"
    )
)

collator = (
    RouteATrainCollatorV2B(
        module_embedding_store=(
            module_store
        ),
        structured_batch_builder=(
            structured_builder
        ),
        path_routing_builder=(
            path_builder
        ),
        assembly_store=(
            assembly_store
        ),
        junction_store=(
            junction_store
        ),
    )
)


print("=" * 100)
print("V2-C BODE EXTERNAL ASSEMBLY CONTEXT")
print("=" * 100)

print(
    "assembly records:",
    len(assembly_store),
)

print(
    "junction records:",
    len(junction_store),
)

assert len(assembly_store) == 324
assert len(junction_store) == 1368


# =====================================================================
# Build one invariant evaluation item panel
# =====================================================================

items_all = []


for row in interfaces:

    left_uid = (
        row["left_module_uid"]
    )

    right_uid = (
        row["right_module_uid"]
    )

    left_hash = (
        row["left_sequence_hash"]
    )

    right_hash = (
        row["right_sequence_hash"]
    )


    (
        dummy_right_uid,
        dummy_right_hash,
    ) = dummy_for(
        right_uid
    )

    (
        dummy_left_uid,
        dummy_left_hash,
    ) = dummy_for(
        left_uid
    )


    transition_type = (
        row["transition_type"]
    )

    is_linker = (
        transition_type
        ==
        "inter_module_linker_candidate"
    )

    is_break = (
        transition_type
        ==
        "inter_protein_chain_break"
    )


    if not (
        is_linker
        or is_break
    ):
        raise RuntimeError(
            transition_type
        )


    seq = (
        row["junction_sequence"]
        if is_linker
        else ""
    )

    length = (
        int(
            row["junction_length_aa"]
        )
        if is_linker
        else 0
    )


    if is_linker and len(seq) != length:
        raise RuntimeError(
            f"Junction length mismatch "
            f"{row['transition_uid']}"
        )


    # Biological 1-based Ji.
    query_transition_index = int(
        row[
            "left_global_module_index"
        ]
    )


    items_all.append({
        "assembly_line_id":
            row[
                "assembly_line_id"
            ],

        "query_transition_index":
            query_transition_index,

        "transition_uid":
            row[
                "transition_uid"
            ],

        "left_module_uid":
            left_uid,

        "left_sequence_hash":
            left_hash,

        "candidate_right_module_uids":
            [
                right_uid,
                dummy_right_uid,
            ],

        "candidate_right_hashes":
            [
                right_hash,
                dummy_right_hash,
            ],

        "right_module_uid":
            right_uid,

        "right_sequence_hash":
            right_hash,

        "candidate_left_module_uids":
            [
                left_uid,
                dummy_left_uid,
            ],

        "candidate_left_hashes":
            [
                left_hash,
                dummy_left_hash,
            ],

        "junction_sequence":
            seq,

        "junction_length":
            length,

        "junction_is_chain_break":
            is_break,

        "junction_is_linker":
            is_linker,

        "interface_id":
            row[
                "transition_uid"
            ],

        "transition_type":
            transition_type,

        "target":
            0,

        "forward_target":
            0,

        "reverse_target":
            0,
    })


assert len(items_all) == 1368


# =====================================================================
# Preflight collator on actual Bode assemblies
# =====================================================================

print()
print("=" * 100)
print("V2-C BODE COLLATOR PREFLIGHT")
print("=" * 100)

preflight = collator(
    items_all[:8]
)

print(
    "batch keys:",
    len(preflight),
)

print(
    "assembly modules:",
    int(
        preflight[
            "assembly_module_offset"
        ][-1]
    ),
)

print(
    "assembly transitions:",
    int(
        preflight[
            "assembly_transition_offset"
        ][-1]
    ),
)

print(
    "V2-C BODE COLLATOR PREFLIGHT: PASS"
)


# =====================================================================
# Labels + part identities
# =====================================================================

labels = pd.read_csv(
    LABEL_ATLAS,
    sep="\t",
)[
    [
        "construct_id",
        "label",
        "initiation_part",
        "elongation_part",
        "termination_part",
        "product_topology",
    ]
].drop_duplicates()


assert len(labels) == 324


# =====================================================================
# GPU
# =====================================================================

device = torch.device(
    "cuda"
)

use_bf16 = (
    torch.cuda.is_bf16_supported()
)

print()
print(
    "GPU:",
    torch.cuda.get_device_name(0),
)

print(
    "BF16:",
    use_bf16,
)


# =====================================================================
# Evaluate E1--E5
# =====================================================================

summary_rows = []


for epoch in (
    30,
):

    checkpoint_path = (
        CHECKPOINT_ROOT
        / f"epoch_{epoch:04d}.pt"
    )

    checkpoint = torch.load(
        checkpoint_path,
        map_location="cpu",
        weights_only=False,
    )


    # ---------------------------------------------------------------
    # Frozen contract
    # ---------------------------------------------------------------

    expected = {
        "version":
            "routeA_v2bc",

        "architecture_stage":
            "V2-BC",

        "mode":
            "A0",

        "seed":
            20260813,

        "epoch":
            epoch,

        "bode_used":
            False,

        "ablation_architecture":
            "C",

        "assembly_score_enabled":
            True,

        "feedback_enabled":
            True,
    }


    for key, value in expected.items():

        if checkpoint.get(key) != value:
            raise RuntimeError(
                f"E{epoch}: "
                f"{key} mismatch: "
                f"{checkpoint.get(key)!r}"
            )


    # ---------------------------------------------------------------
    # Exact architecture
    # ---------------------------------------------------------------

    model = RouteAV2C(
        attention_radius=int(
            checkpoint[
                "attention_radius"
            ]
        ),

        feedback_initial_gate=float(
            checkpoint[
                "feedback_initial_gate"
            ]
        ),

        feedback_enabled=True,

        assembly_score_enabled=True,
    )

    model.set_ablation_mode(
        "C"
    )

    model.load_state_dict(
        checkpoint[
            "model_state"
        ],
        strict=True,
    )

    model.to(device)
    model.eval()


    ckpt_sha = sha256(
        checkpoint_path
    )


    # ---------------------------------------------------------------
    # Allocate
    # ---------------------------------------------------------------

    channel_names = [
        "pre",
        "local",
        "assembly",
        "final",
    ]

    f_scores = {
        name:
            np.empty(
                len(items_all),
                dtype=np.float32,
            )
        for name in channel_names
    }

    r_scores = {
        name:
            np.empty(
                len(items_all),
                dtype=np.float32,
            )
        for name in channel_names
    }


    gate_value = None


    # ---------------------------------------------------------------
    # Score
    # ---------------------------------------------------------------

    with torch.inference_mode():

        for start in range(
            0,
            len(items_all),
            BATCH_SIZE,
        ):

            end = min(
                start + BATCH_SIZE,
                len(items_all),
            )

            batch = collator(
                items_all[
                    start:end
                ]
            )

            batch = move_batch_v2c(
                batch,
                device,
            )


            with torch.autocast(
                device_type="cuda",
                dtype=torch.bfloat16,
                enabled=use_bf16,
            ):

                result = forward_model_v2c(
                    model,
                    batch,
                )


            result.validate()


            current_gate = float(
                result.feedback_gate
                .float()
                .cpu()
                .item()
            )

            if gate_value is None:
                gate_value = (
                    current_gate
                )

            elif abs(
                gate_value
                - current_gate
            ) > 1e-8:

                raise RuntimeError(
                    "Feedback gate drift "
                    "within epoch"
                )


            tensors = {
                "pre": (
                    result
                    .forward_pre_feedback_scores,
                    result
                    .reverse_pre_feedback_scores,
                ),

                "local": (
                    result
                    .forward_local_scores,
                    result
                    .reverse_local_scores,
                ),

                "assembly": (
                    result
                    .forward_assembly_scores,
                    result
                    .reverse_assembly_scores,
                ),

                "final": (
                    result
                    .forward_scores,
                    result
                    .reverse_scores,
                ),
            }


            for name, (
                ft,
                rt,
            ) in tensors.items():

                fv = (
                    ft[:, 0]
                    .float()
                    .cpu()
                    .numpy()
                )

                rv = (
                    rt[:, 0]
                    .float()
                    .cpu()
                    .numpy()
                )

                if (
                    not np.isfinite(fv).all()
                    or
                    not np.isfinite(rv).all()
                ):
                    raise RuntimeError(
                        f"E{epoch}: "
                        f"nonfinite {name}"
                    )


                f_scores[name][
                    start:end
                ] = fv

                r_scores[name][
                    start:end
                ] = rv


            # -------------------------------------------------------
            # Architecture identities
            # -------------------------------------------------------

            fdiff = (
                result.forward_scores[:, 0]
                - (
                    result
                    .forward_local_scores[:, 0]
                    +
                    result
                    .forward_assembly_scores[:, 0]
                )
            ).abs().max()


            rdiff = (
                result.reverse_scores[:, 0]
                - (
                    result
                    .reverse_local_scores[:, 0]
                    +
                    result
                    .reverse_assembly_scores[:, 0]
                )
            ).abs().max()


            if max(
                float(fdiff),
                float(rdiff),
            ) > 1e-5:

                raise RuntimeError(
                    f"E{epoch}: "
                    "final != local + assembly"
                )


    # ---------------------------------------------------------------
    # Seam atlas
    # ---------------------------------------------------------------

    seam_rows = []

    for i, source in enumerate(
        interfaces
    ):

        row = {
            "epoch":
                epoch,

            "checkpoint_sha256":
                ckpt_sha,

            "feedback_gate":
                gate_value,

            "construct_id":
                source[
                    "construct_id"
                ],

            "assembly_line_id":
                source[
                    "assembly_line_id"
                ],

            "transition_uid":
                source[
                    "transition_uid"
                ],

            "interface_index":
                int(
                    source[
                        "left_global_module_index"
                    ]
                ),

            "left_module_uid":
                source[
                    "left_module_uid"
                ],

            "right_module_uid":
                source[
                    "right_module_uid"
                ],

            "transition_type":
                source[
                    "transition_type"
                ],

            "junction_length_aa":
                int(
                    source[
                        "junction_length_aa"
                    ]
                    or 0
                ),
        }


        for name in channel_names:

            f = float(
                f_scores[name][i]
            )

            r = float(
                r_scores[name][i]
            )

            row[
                f"forward_{name}"
            ] = f

            row[
                f"reverse_{name}"
            ] = r

            row[
                f"symmetric_{name}"
            ] = (
                0.5
                * (
                    f + r
                )
            )


        row[
            "symmetric_feedback_delta"
        ] = (
            row[
                "symmetric_local"
            ]
            - row[
                "symmetric_pre"
            ]
        )


        seam_rows.append(
            row
        )


    seams = pd.DataFrame(
        seam_rows
    )

    seams = seams.merge(
        labels,
        on="construct_id",
        how="left",
        validate="many_to_one",
    )


    if seams["label"].isna().any():
        raise RuntimeError(
            "Missing Bode labels"
        )


    seam_path = (
        OUT
        / f"v2c_epoch{epoch:02d}_seams.tsv.gz"
    )

    seams.to_csv(
        seam_path,
        sep="\t",
        index=False,
        compression="gzip",
    )


    # ---------------------------------------------------------------
    # Construct metrics
    # ---------------------------------------------------------------

    records = []


    for construct_id, g in seams.groupby(
        "construct_id",
        sort=False,
    ):

        record = {
            "epoch":
                epoch,

            "construct_id":
                construct_id,

            "label":
                int(
                    g[
                        "label"
                    ].iloc[0]
                ),

            "initiation_part":
                g[
                    "initiation_part"
                ].iloc[0],

            "elongation_part":
                g[
                    "elongation_part"
                ].iloc[0],

            "termination_part":
                g[
                    "termination_part"
                ].iloc[0],

            "product_topology":
                g[
                    "product_topology"
                ].iloc[0],

            "n_seams":
                len(g),

            "feedback_gate":
                gate_value,
        }


        for name in (
            "pre",
            "local",
            "assembly",
            "final",
        ):

            x = (
                g[
                    f"symmetric_{name}"
                ]
                .to_numpy(
                    dtype=float
                )
            )

            record[
                f"{name}_mean"
            ] = float(
                np.mean(x)
            )

            record[
                f"{name}_min"
            ] = float(
                np.min(x)
            )

            record[
                f"{name}_bottom2"
            ] = bottom2(x)

            record[
                f"{name}_std"
            ] = float(
                np.std(x)
            )

            record[
                f"{name}_range"
            ] = float(
                np.max(x)
                - np.min(x)
            )


        fd = (
            g[
                "symmetric_feedback_delta"
            ]
            .to_numpy(
                dtype=float
            )
        )

        record[
            "feedback_delta_mean"
        ] = float(
            np.mean(fd)
        )

        record[
            "feedback_delta_abs_mean"
        ] = float(
            np.mean(
                np.abs(fd)
            )
        )


        records.append(
            record
        )


    constructs = pd.DataFrame(
        records
    )

    assert len(constructs) == 324


    construct_path = (
        OUT
        / f"v2c_epoch{epoch:02d}_constructs.tsv"
    )

    constructs.to_csv(
        construct_path,
        sep="\t",
        index=False,
    )


    # ---------------------------------------------------------------
    # Activity transfer summary
    # ---------------------------------------------------------------

    y = (
        constructs[
            "label"
        ]
        .to_numpy(
            dtype=int
        )
    )


    print()
    print("=" * 100)
    print(
        f"V2-C EPOCH {epoch}"
    )
    print("=" * 100)

    print(
        "checkpoint:",
        ckpt_sha,
    )

    print(
        "feedback gate:",
        f"{gate_value:.8f}",
    )


    metrics = []

    for name in (
        "pre",
        "local",
        "assembly",
        "final",
    ):

        for stat in (
            "mean",
            "min",
            "bottom2",
        ):

            metric = (
                f"{name}_{stat}"
            )

            x = (
                constructs[
                    metric
                ]
                .to_numpy(
                    dtype=float
                )
            )

            auc = float(
                roc_auc_score(
                    y,
                    x,
                )
            )

            ap = float(
                average_precision_score(
                    y,
                    x,
                )
            )

            active = float(
                x[
                    y == 1
                ].mean()
            )

            inactive = float(
                x[
                    y == 0
                ].mean()
            )


            summary_rows.append({
                "epoch":
                    epoch,

                "feedback_gate":
                    gate_value,

                "channel":
                    name,

                "stat":
                    stat,

                "metric":
                    metric,

                "auc":
                    auc,

                "ap":
                    ap,

                "active_mean":
                    active,

                "inactive_mean":
                    inactive,

                "delta":
                    active
                    - inactive,
            })


            if stat in (
                "mean",
                "min",
            ):

                print(
                    f"{metric:22s} "
                    f"AUC={auc:.4f} "
                    f"AP={ap:.4f} "
                    f"active={active:.4f} "
                    f"inactive={inactive:.4f} "
                    f"delta={active-inactive:+.4f}"
                )


    # Explicit feedback-only diagnostic
    for metric in (
        "feedback_delta_mean",
        "feedback_delta_abs_mean",
    ):

        x = (
            constructs[
                metric
            ]
            .to_numpy(
                dtype=float
            )
        )

        auc = float(
            roc_auc_score(
                y,
                x,
            )
        )

        ap = float(
            average_precision_score(
                y,
                x,
            )
        )

        print(
            f"{metric:22s} "
            f"AUC={auc:.4f} "
            f"AP={ap:.4f}"
        )


    del model
    torch.cuda.empty_cache()


# =====================================================================
# Combined summary
# =====================================================================

summary = pd.DataFrame(
    summary_rows
)

summary_path = (
    OUT
    / "v2c_epochs01_05_activity_summary.tsv"
)

summary.to_csv(
    summary_path,
    sep="\t",
    index=False,
)


print()
print("=" * 100)
print("OUTPUT")
print("=" * 100)

print(summary_path)

print()
print(
    "V2-C BODE EPOCHS 1-5: PASS"
)
