#!/usr/bin/env python3
from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
import csv
import gzip
import hashlib
import json
import math
import os
import statistics

import torch

from neuralps.evaluation.bode_structured_module_store_v1_1 import (
    StructuredModuleStoreV1_1,
)
from neuralps.evaluation.bode_embedding_store_v2 import (
    BodeEmbeddingStoreV2,
)
from neuralps.evaluation.bode_structured_path_store_v2 import (
    BodeStructuredPathStoreV2,
)

from neuralps.data.embedding_store import EmbeddingStore
from neuralps.data.structured_module_batch_v1_1 import (
    StructuredModuleBatchBuilderV1_1,
)
from neuralps.data.path_routing_batch_v2 import (
    PathRoutingBatchBuilderV2,
)
from neuralps.data.collate_v2 import (
    RouteATrainCollatorV2,
)

from neuralps.models.routea_v2a import RouteAV2A

from neuralps.training.routea_v2a_runtime import (
    move_batch_v2a,
    forward_model_v2a,
)


ROOT = Path(os.environ["WORK"]) / "NeurALPSv2"

INTERFACES = (
    ROOT
    / "data"
    / "bode_inference_v1_0"
    / "interfaces.tsv.gz"
)

STRUCTURED = (
    ROOT
    / "data"
    / "bode_structured_v1_1_exploratory"
)

BODE_EMBED = (
    ROOT
    / "results"
    / "bode_esmc600m_embeddings"
)

BOUNDARY_EMBED = (
    ROOT
    / "results"
    / "bode_esmc600m_embeddings_v1_1"
    / "boundaries"
)

ACTIVITY = (
    ROOT
    / "data"
    / "bode"
    / "experimental_construct_activity.tsv.gz"
)

CHECKPOINT = (
    ROOT
    / "results"
    / "training"
    / "routeA_v2a"
    / "A0_seed20260813"
    / "checkpoints"
    / "epoch_0030.pt"
)

OUT = (
    ROOT
    / "results"
    / "training"
    / "routeA_v2a"
    / "bode_benchmark_v2"
    / "A0_epoch0030"
)

OUT.mkdir(
    parents=True,
    exist_ok=True,
)

BATCH_SIZE = 64


def sha256(path: Path) -> str:

    h = hashlib.sha256()

    with open(path, "rb") as f:
        while True:
            block = f.read(
                1024 * 1024
            )

            if not block:
                break

            h.update(block)

    return h.hexdigest()


def read_tsv(path: Path):

    with gzip.open(
        path,
        "rt",
        encoding="utf-8",
        newline="",
    ) as f:

        yield from csv.DictReader(
            f,
            delimiter="\t",
        )


def write_tsv_gz(
    path: Path,
    rows,
    fields,
):

    with gzip.open(
        path,
        "wt",
        encoding="utf-8",
        newline="",
    ) as f:

        writer = csv.DictWriter(
            f,
            delimiter="\t",
            fieldnames=fields,
            lineterminator="\n",
        )

        writer.writeheader()
        writer.writerows(rows)


def parse_bool(value: str) -> int:

    v = str(value).strip().lower()

    if v in {
        "true",
        "1",
        "yes",
        "positive",
        "detected",
    }:
        return 1

    if v in {
        "false",
        "0",
        "no",
        "negative",
        "not_detected",
        "not detected",
    }:
        return 0

    raise RuntimeError(
        f"Cannot parse activity label: {value!r}"
    )


def roc_auc(
    labels,
    scores,
):

    positives = sum(labels)
    negatives = (
        len(labels)
        - positives
    )

    if (
        positives == 0
        or negatives == 0
    ):
        return None

    pairs = sorted(
        zip(
            scores,
            labels,
        ),
        key=lambda x: x[0],
    )

    rank_sum_positive = 0.0

    i = 0
    n = len(pairs)

    while i < n:

        j = i + 1

        while (
            j < n
            and pairs[j][0]
            == pairs[i][0]
        ):
            j += 1

        # ranks are 1-based
        mean_rank = (
            (i + 1)
            + j
        ) / 2.0

        positive_in_group = sum(
            label
            for _, label
            in pairs[i:j]
        )

        rank_sum_positive += (
            mean_rank
            * positive_in_group
        )

        i = j

    return (
        rank_sum_positive
        - positives
        * (
            positives + 1
        )
        / 2.0
    ) / (
        positives
        * negatives
    )


def average_precision(
    labels,
    scores,
):

    positives = sum(labels)

    if positives == 0:
        return None

    pairs = sorted(
        zip(
            scores,
            labels,
        ),
        key=lambda x: x[0],
        reverse=True,
    )

    tp = 0
    fp = 0
    previous_recall = 0.0
    ap = 0.0

    i = 0
    n = len(pairs)

    while i < n:

        score = pairs[i][0]

        j = i

        group_pos = 0
        group_neg = 0

        while (
            j < n
            and pairs[j][0] == score
        ):

            if pairs[j][1]:
                group_pos += 1
            else:
                group_neg += 1

            j += 1

        tp += group_pos
        fp += group_neg

        recall = (
            tp
            / positives
        )

        precision = (
            tp
            / (
                tp + fp
            )
        )

        ap += (
            recall
            - previous_recall
        ) * precision

        previous_recall = recall
        i = j

    return ap


def metric_block(
    labels,
    scores,
):

    active = [
        score
        for label, score
        in zip(
            labels,
            scores,
            strict=True,
        )
        if label == 1
    ]

    inactive = [
        score
        for label, score
        in zip(
            labels,
            scores,
            strict=True,
        )
        if label == 0
    ]

    return {
        "n": len(labels),
        "positives": sum(labels),
        "negatives": (
            len(labels)
            - sum(labels)
        ),
        "roc_auc": roc_auc(
            labels,
            scores,
        ),
        "average_precision": (
            average_precision(
                labels,
                scores,
            )
        ),
        "active_mean": (
            statistics.mean(
                active
            )
            if active
            else None
        ),
        "inactive_mean": (
            statistics.mean(
                inactive
            )
            if inactive
            else None
        ),
        "active_minus_inactive_mean": (
            statistics.mean(active)
            - statistics.mean(inactive)
            if (
                active
                and inactive
            )
            else None
        ),
    }


print("=" * 100)
print("BODE V2-A EPOCH-22 EVALUATION")
print("=" * 100)

device = torch.device(
    "cuda"
    if torch.cuda.is_available()
    else "cpu"
)

print("device:", device)

if device.type == "cuda":
    print(
        "GPU:",
        torch.cuda.get_device_name(0),
    )

checkpoint_hash = sha256(
    CHECKPOINT
)

checkpoint = torch.load(
    CHECKPOINT,
    map_location="cpu",
    weights_only=False,
)

for key, expected in {
    "version": "routeA_v2a",
    "architecture_stage": "V2-A",
    "mode": "A0",
    "seed": 20260813,
    "epoch": 30,
}.items():

    if checkpoint.get(key) != expected:
        raise RuntimeError(
            f"Checkpoint contract mismatch: "
            f"{key}={checkpoint.get(key)!r}"
        )

if checkpoint.get(
    "bode_used"
) is not False:
    raise RuntimeError(
        "Checkpoint reports Bode use"
    )


# ======================================================================
# Build the exact V2-A Bode representation.
# ======================================================================

structured_store = (
    StructuredModuleStoreV1_1(
        STRUCTURED
    )
)

module_store = (
    BodeEmbeddingStoreV2(
        BODE_EMBED,
        "modules",
    )
)

domain_store = (
    BodeEmbeddingStoreV2(
        BODE_EMBED,
        "domains",
    )
)

boundary_store = (
    EmbeddingStore(
        BOUNDARY_EMBED,
        "boundaries",
        max_cached_shards=2,
    )
)

structured_builder = (
    StructuredModuleBatchBuilderV1_1(
        structured_store=(
            structured_store
        ),
        module_embedding_store=(
            module_store
        ),
        domain_embedding_store=(
            domain_store
        ),
        boundary_embedding_store=(
            boundary_store
        ),
    )
)

path_store = (
    BodeStructuredPathStoreV2(
        STRUCTURED,
        structured_store=(
            structured_store
        ),
    )
)

path_builder = (
    PathRoutingBatchBuilderV2(
        path_store=(
            path_store
        )
    )
)

collator = (
    RouteATrainCollatorV2(
        module_embedding_store=(
            module_store
        ),
        structured_batch_builder=(
            structured_builder
        ),
        path_routing_builder=(
            path_builder
        ),
    )
)


# ======================================================================
# Load Bode interfaces.
# ======================================================================

interface_rows = list(
    read_tsv(
        INTERFACES
    )
)

if len(
    interface_rows
) != 1368:
    raise RuntimeError(
        "Expected exactly 1368 Bode interfaces"
    )

interface_rows.sort(
    key=lambda row: (
        row[
            "assembly_line_id"
        ],
        int(
            row[
                "left_global_module_index"
            ]
        ),
    )
)


# Candidate_count >= 2 is a frozen V2-A model contract.
#
# Candidate 0 is ALWAYS the real Bode partner.
# Candidate 1 is a deterministic unrelated Bode module used only to
# satisfy the retrieval-shape contract. V2-A has no cross-candidate
# interaction, so candidate-0 score is the desired interface score.

module_pool = {}

for row in interface_rows:

    module_pool[
        row[
            "left_module_uid"
        ]
    ] = row[
        "left_sequence_hash"
    ]

    module_pool[
        row[
            "right_module_uid"
        ]
    ] = row[
        "right_sequence_hash"
    ]

pool = sorted(
    module_pool.items()
)

if len(pool) != 1692:
    raise RuntimeError(
        f"Expected 1692 Bode module UIDs, "
        f"got {len(pool)}"
    )


def dummy_for(
    observed_uid,
):

    for uid, seq_hash in pool:

        if uid != observed_uid:
            return (
                uid,
                seq_hash,
            )

    raise RuntimeError(
        "Could not select dummy candidate"
    )


# ======================================================================
# Model.
# ======================================================================

torch.manual_seed(
    20260813
)

model = RouteAV2A()

model.load_state_dict(
    checkpoint[
        "model_state"
    ],
    strict=True,
)

model.to(
    device
)

model.eval()

use_bf16 = (
    device.type == "cuda"
    and torch.cuda.is_bf16_supported()
)

print(
    "BF16 autocast:",
    use_bf16,
)


# ======================================================================
# Score all 1368 interfaces.
# ======================================================================

scored_interfaces = []

with torch.inference_mode():

    for start in range(
        0,
        len(interface_rows),
        BATCH_SIZE,
    ):

        rows = interface_rows[
            start:
            start + BATCH_SIZE
        ]

        items = []

        for row in rows:

            left_uid = row[
                "left_module_uid"
            ]

            right_uid = row[
                "right_module_uid"
            ]

            left_hash = row[
                "left_sequence_hash"
            ]

            right_hash = row[
                "right_sequence_hash"
            ]

            dummy_right_uid, dummy_right_hash = (
                dummy_for(
                    right_uid
                )
            )

            dummy_left_uid, dummy_left_hash = (
                dummy_for(
                    left_uid
                )
            )

            transition_type = row[
                "transition_type"
            ]

            is_linker = (
                transition_type
                == "inter_module_linker_candidate"
            )

            is_chain_break = (
                transition_type
                == "inter_protein_chain_break"
            )

            if (
                is_linker
                == is_chain_break
            ):
                raise RuntimeError(
                    "Invalid transition type"
                )

            sequence = row[
                "junction_sequence"
            ]

            length = int(
                row[
                    "junction_length_aa"
                ]
            )

            if (
                is_chain_break
                and (
                    sequence
                    or length != 0
                )
            ):
                raise RuntimeError(
                    "Invalid chain-break junction"
                )

            items.append(
                {
                    "left_module_uid": (
                        left_uid
                    ),
                    "left_sequence_hash": (
                        left_hash
                    ),

                    "candidate_right_module_uids": [
                        right_uid,
                        dummy_right_uid,
                    ],
                    "candidate_right_hashes": [
                        right_hash,
                        dummy_right_hash,
                    ],

                    "right_module_uid": (
                        right_uid
                    ),
                    "right_sequence_hash": (
                        right_hash
                    ),

                    "candidate_left_module_uids": [
                        left_uid,
                        dummy_left_uid,
                    ],
                    "candidate_left_hashes": [
                        left_hash,
                        dummy_left_hash,
                    ],

                    "junction_sequence": (
                        sequence
                    ),
                    "junction_length": (
                        length
                    ),
                    "junction_is_chain_break": (
                        is_chain_break
                    ),
                    "junction_is_linker": (
                        is_linker
                    ),

                    "interface_id": row[
                        "transition_uid"
                    ],
                    "transition_type": (
                        transition_type
                    ),

                    "target": 0,
                    "forward_target": 0,
                    "reverse_target": 0,
                }
            )

        batch = collator(
            items
        )

        batch = move_batch_v2a(
            batch,
            device,
        )

        with torch.autocast(
            device_type=(
                device.type
            ),
            dtype=torch.bfloat16,
            enabled=use_bf16,
        ):

            output = (
                forward_model_v2a(
                    model,
                    batch,
                )
            )

        forward = (
            output
            .forward_scores[
                :,
                0,
            ]
            .float()
            .cpu()
        )

        reverse = (
            output
            .reverse_scores[
                :,
                0,
            ]
            .float()
            .cpu()
        )

        if not torch.isfinite(
            forward
        ).all():
            raise RuntimeError(
                "Non-finite forward Bode scores"
            )

        if not torch.isfinite(
            reverse
        ).all():
            raise RuntimeError(
                "Non-finite reverse Bode scores"
            )

        symmetric = (
            0.5
            * (
                forward
                + reverse
            )
        )

        for (
            row,
            f_score,
            r_score,
            s_score,
        ) in zip(
            rows,
            forward.tolist(),
            reverse.tolist(),
            symmetric.tolist(),
            strict=True,
        ):

            scored_interfaces.append(
                {
                    "construct_id": row[
                        "construct_id"
                    ],
                    "assembly_line_id": row[
                        "assembly_line_id"
                    ],
                    "transition_uid": row[
                        "transition_uid"
                    ],
                    "interface_index": row[
                        "left_global_module_index"
                    ],
                    "left_module_uid": row[
                        "left_module_uid"
                    ],
                    "right_module_uid": row[
                        "right_module_uid"
                    ],
                    "transition_type": row[
                        "transition_type"
                    ],
                    "junction_kind": row[
                        "junction_kind"
                    ],
                    "junction_length_aa": row[
                        "junction_length_aa"
                    ],
                    "forward_score": repr(
                        float(
                            f_score
                        )
                    ),
                    "reverse_score": repr(
                        float(
                            r_score
                        )
                    ),
                    "symmetric_score": repr(
                        float(
                            s_score
                        )
                    ),
                    "checkpoint_sha256": (
                        checkpoint_hash
                    ),
                }
            )

        print(
            f"scored "
            f"{min(start + BATCH_SIZE, len(interface_rows))}"
            f"/{len(interface_rows)}",
            flush=True,
        )


if len(
    scored_interfaces
) != 1368:
    raise RuntimeError(
        "Interface score count mismatch"
    )


# ======================================================================
# Label-independent construct aggregation.
# ======================================================================

by_assembly = defaultdict(
    list
)

for row in scored_interfaces:
    by_assembly[
        row[
            "assembly_line_id"
        ]
    ].append(
        row
    )

if len(
    by_assembly
) != 324:
    raise RuntimeError(
        f"Expected 324 constructs, got {len(by_assembly)}"
    )

construct_rows = []

for aid in sorted(
    by_assembly
):

    rows = sorted(
        by_assembly[
            aid
        ],
        key=lambda row: int(
            row[
                "interface_index"
            ]
        ),
    )

    f = [
        float(
            row[
                "forward_score"
            ]
        )
        for row in rows
    ]

    r = [
        float(
            row[
                "reverse_score"
            ]
        )
        for row in rows
    ]

    s = [
        float(
            row[
                "symmetric_score"
            ]
        )
        for row in rows
    ]

    n_interfaces = len(
        rows
    )

    n_modules = (
        n_interfaces + 1
    )

    bottom2 = sorted(
        s
    )[
        :min(
            2,
            len(s),
        )
    ]

    construct_rows.append(
        {
            "construct_id": rows[
                0
            ][
                "construct_id"
            ],
            "assembly_line_id": aid,

            "n_modules": str(
                n_modules
            ),
            "n_interfaces": str(
                n_interfaces
            ),

            "forward_mean": repr(
                statistics.mean(f)
            ),
            "reverse_mean": repr(
                statistics.mean(r)
            ),

            "symmetric_mean": repr(
                statistics.mean(s)
            ),
            "symmetric_median": repr(
                statistics.median(s)
            ),
            "symmetric_min": repr(
                min(s)
            ),
            "symmetric_max": repr(
                max(s)
            ),
            "symmetric_std": repr(
                statistics.pstdev(s)
            ),
            "symmetric_range": repr(
                max(s)
                - min(s)
            ),
            "symmetric_bottom2_mean": repr(
                statistics.mean(
                    bottom2
                )
            ),

            "checkpoint_sha256": (
                checkpoint_hash
            ),
        }
    )


architecture_counts = Counter(
    int(
        row[
            "n_modules"
        ]
    )
    for row
    in construct_rows
)

expected_architecture = {
    4: 72,
    5: 138,
    6: 84,
    7: 30,
}

if dict(
    architecture_counts
) != expected_architecture:
    raise RuntimeError(
        "Architecture-count mismatch: "
        f"{dict(architecture_counts)}"
    )


# ----------------------------------------------------------------------
# WRITE LABEL-INDEPENDENT PREDICTIONS FIRST.
# ----------------------------------------------------------------------

interface_output = (
    OUT
    / "bode_v2a_epoch22_interface_scores.tsv.gz"
)

construct_output = (
    OUT
    / "bode_v2a_epoch22_construct_scores.tsv.gz"
)

write_tsv_gz(
    interface_output,
    scored_interfaces,
    list(
        scored_interfaces[
            0
        ].keys()
    ),
)

write_tsv_gz(
    construct_output,
    construct_rows,
    list(
        construct_rows[
            0
        ].keys()
    ),
)

print()
print(
    "LABEL-INDEPENDENT predictions written."
)


# ======================================================================
# NOW load activity labels.
# ======================================================================

activity_rows = list(
    read_tsv(
        ACTIVITY
    )
)

labels = {}

for row in activity_rows:

    cid = row[
        "construct_id"
    ]

    label = parse_bool(
        row[
            "expected_product_detected"
        ]
    )

    if cid in labels:
        raise RuntimeError(
            f"Duplicate activity label: {cid}"
        )

    labels[
        cid
    ] = label


if len(
    labels
) != 324:
    raise RuntimeError(
        f"Expected 324 activity labels, got {len(labels)}"
    )

label_counts = Counter(
    labels.values()
)

if label_counts != {
    1: 173,
    0: 151,
}:
    raise RuntimeError(
        f"Unexpected Bode label counts: {label_counts}"
    )


construct_by_id = {
    row[
        "construct_id"
    ]: row
    for row in construct_rows
}

if (
    set(
        construct_by_id
    )
    != set(
        labels
    )
):
    raise RuntimeError(
        "Construct/activity identity mismatch"
    )


score_fields = [
    "forward_mean",
    "reverse_mean",
    "symmetric_mean",
    "symmetric_median",
    "symmetric_min",
    "symmetric_max",
    "symmetric_std",
    "symmetric_range",
    "symmetric_bottom2_mean",
]

metrics = {}

ordered_ids = sorted(
    labels
)

y = [
    labels[cid]
    for cid in ordered_ids
]

for field in score_fields:

    scores = [
        float(
            construct_by_id[
                cid
            ][
                field
            ]
        )
        for cid
        in ordered_ids
    ]

    metrics[
        field
    ] = metric_block(
        y,
        scores,
    )


# ======================================================================
# Architecture-stratified symmetric-mean transfer.
# ======================================================================

architecture_metrics = {}

for n_modules in (
    4,
    5,
    6,
    7,
):

    ids = [
        cid
        for cid
        in ordered_ids
        if int(
            construct_by_id[
                cid
            ][
                "n_modules"
            ]
        )
        == n_modules
    ]

    arch_labels = [
        labels[
            cid
        ]
        for cid
        in ids
    ]

    arch_scores = [
        float(
            construct_by_id[
                cid
            ][
                "symmetric_mean"
            ]
        )
        for cid
        in ids
    ]

    architecture_metrics[
        str(
            n_modules
        )
    ] = metric_block(
        arch_labels,
        arch_scores,
    )


summary = {
    "version": (
        "routeA_v2a_bode_benchmark_v2"
    ),
    "architecture_stage": "V2-A",
    "mode": "A0",
    "epoch": 15,
    "seed": 20260813,

    "checkpoint": str(
        CHECKPOINT
    ),
    "checkpoint_sha256": (
        checkpoint_hash
    ),

    "label_blind_predictions_written_before_activity_join": (
        True
    ),

    "activity_labels_used_for_training": (
        False
    ),
    "activity_labels_used_for_checkpoint_selection": (
        False
    ),
    "activity_labels_used_only_for_external_metrics": (
        True
    ),

    "interfaces": len(
        scored_interfaces
    ),
    "constructs": len(
        construct_rows
    ),

    "activity_positive": (
        label_counts[
            1
        ]
    ),
    "activity_negative": (
        label_counts[
            0
        ]
    ),

    "architecture_counts": {
        str(k): v
        for k, v
        in sorted(
            architecture_counts.items()
        )
    },

    "metrics": metrics,

    "architecture_stratified_symmetric_mean": (
        architecture_metrics
    ),

    "score_semantics": (
        "Route-A V2-A learned local compatibility/coherence "
        "score; not a calibrated productivity probability"
    ),

    "interface_output": str(
        interface_output
    ),
    "construct_output": str(
        construct_output
    ),
}

summary_output = (
    OUT
    / "bode_v2a_epoch22_metrics.json"
)

summary_output.write_text(
    json.dumps(
        summary,
        indent=2,
        sort_keys=True,
    )
    + "\n"
)


print()
print("=" * 100)
print("BODE V2-A EPOCH-22 EVALUATION COMPLETE")
print("=" * 100)

print(
    "interfaces:",
    len(scored_interfaces),
)

print(
    "constructs:",
    len(construct_rows),
)

print(
    "labels:",
    dict(label_counts),
)

print()
print("GLOBAL METRICS")

for field in score_fields:

    m = metrics[
        field
    ]

    print(
        f"{field:24s} "
        f"ROC-AUC={m['roc_auc']:.6f}  "
        f"AP={m['average_precision']:.6f}  "
        f"Δmean={m['active_minus_inactive_mean']:.6f}"
    )


print()
print(
    "PRIMARY symmetric_mean:",
    json.dumps(
        metrics[
            "symmetric_mean"
        ],
        sort_keys=True,
    ),
)

print()
print(
    "metrics:",
    summary_output
)

print(
    "interfaces:",
    interface_output
)

print(
    "constructs:",
    construct_output
)
