NeurALPSv2 Phase 1 Bode-324 External Validation

Models:
- V2-A epoch 30
- V2-C epoch 30
- V2-D epoch 30

External dataset:
Bode engineered NRPS validation set

Statistics:
Constructs: 324
Interfaces: 1368
Active: 173
Inactive: 151

Training isolation:
Bode labels were not used during training.
Internal test was not used.

Hardware:
Jean-Zay HPC
GPU: NVIDIA H100 80GB HBM3

Software:
PyTorch 2.8.0+cu128
CUDA 12.8
Python 3.12.11

Architectures:
V2-A:
routeA_v2a

V2-C:
routeA_v2bc

V2-D:
routeA_v2d

Checkpoint:
epoch_0030 for all models
