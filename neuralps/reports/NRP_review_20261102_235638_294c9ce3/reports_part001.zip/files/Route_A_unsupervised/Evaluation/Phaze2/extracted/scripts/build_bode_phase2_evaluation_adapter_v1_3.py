#!/usr/bin/env python3

from pathlib import Path
from collections import Counter
import json
import shutil

import pandas as pd


ROOT = Path.cwd()

STRUCTURED = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "structured_v1_3"
)

CONTEXT = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "assembly_context_v1_3"
)

LABELS = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "labels"
    / "single_exchange_constructs.tsv"
)

OUT = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "evaluation_v1_3"
)

TMP = OUT.parent / ".evaluation_v1_3.tmp"


EXPECTED_CONSTRUCTS = 106
EXPECTED_MODULES = 530
EXPECTED_INTERFACES = 424
EXPECTED_ACTIVE = 64
EXPECTED_INACTIVE = 42


if TMP.exists():
    shutil.rmtree(TMP)

TMP.mkdir(
    parents=True,
    exist_ok=False,
)


# ======================================================================
# LOAD LABEL-BLIND MODEL INPUTS
# ======================================================================

modules = pd.read_csv(
    STRUCTURED / "structured_modules.tsv.gz",
    sep="\t",
    compression="gzip",
    keep_default_na=False,
)

module_occ = pd.read_csv(
    CONTEXT / "module_occurrences.tsv.gz",
    sep="\t",
    compression="gzip",
    keep_default_na=False,
)

interfaces = pd.read_csv(
    CONTEXT / "interfaces.tsv.gz",
    sep="\t",
    compression="gzip",
    keep_default_na=False,
)

junctions = pd.read_csv(
    CONTEXT / "junctions.tsv.gz",
    sep="\t",
    compression="gzip",
    keep_default_na=False,
)


assert len(modules) == EXPECTED_MODULES
assert len(module_occ) == EXPECTED_MODULES
assert len(interfaces) == EXPECTED_INTERFACES
assert len(junctions) == EXPECTED_INTERFACES


# ======================================================================
# MODULE UID -> WHOLE-MODULE ESM-C HASH
# ======================================================================

module_hash = (
    modules[
        [
            "module_uid",
            "module_sequence_hash",
        ]
    ]
    .drop_duplicates()
)


if len(module_hash) != EXPECTED_MODULES:
    raise RuntimeError(
        "Expected 530 unique module UID/hash mappings"
    )


module_hash_map = dict(
    zip(
        module_hash["module_uid"],
        module_hash["module_sequence_hash"],
    )
)


# ======================================================================
# JUNCTION RECORDS
# ======================================================================

junc = junctions[
    [
        "transition_uid",
        "transition_type",
        "sequence_available",
        "sequence",
        "length_aa",
        "interface_index",
        "junction_kind",
        "junction_sequence_hash",
        "junction_sequence_length",
    ]
].copy()


if junc["transition_uid"].duplicated().any():
    raise RuntimeError(
        "Duplicate transition UID in junction table"
    )


# ======================================================================
# BUILD EXACT EVALUATION INTERFACE TABLE
# ======================================================================

eval_interfaces = interfaces.copy()


eval_interfaces["left_sequence_hash"] = (
    eval_interfaces["left_module_uid"]
    .map(module_hash_map)
)

eval_interfaces["right_sequence_hash"] = (
    eval_interfaces["right_module_uid"]
    .map(module_hash_map)
)


if (
    eval_interfaces[
        [
            "left_sequence_hash",
            "right_sequence_hash",
        ]
    ]
    .eq("")
    .any()
    .any()
):

    raise RuntimeError(
        "Missing module hash in evaluation interface table"
    )


if (
    eval_interfaces[
        [
            "left_sequence_hash",
            "right_sequence_hash",
        ]
    ]
    .isna()
    .any()
    .any()
):

    raise RuntimeError(
        "NaN module hash in evaluation interface table"
    )


eval_interfaces = eval_interfaces.merge(
    junc,
    on=[
        "transition_uid",
        "transition_type",
        "interface_index",
    ],
    how="left",
    validate="one_to_one",
)


if len(eval_interfaces) != EXPECTED_INTERFACES:
    raise RuntimeError(
        "Interface/J merge count drift"
    )


if eval_interfaces["junction_kind"].eq("").any():
    raise RuntimeError(
        "Missing junction kind"
    )


# Compatibility aliases used by historical Bode evaluators.
eval_interfaces["junction_sequence"] = (
    eval_interfaces["sequence"]
)

eval_interfaces["junction_length_aa"] = (
    pd.to_numeric(
        eval_interfaces["length_aa"],
        errors="raise",
    ).astype(int)
)


# Historical interface_id is synonymous with transition_uid.
eval_interfaces["interface_id"] = (
    eval_interfaces["transition_uid"]
)


# ======================================================================
# HARD MODEL-INPUT CONTRACT
# ======================================================================

if eval_interfaces["construct_id"].nunique() != 106:
    raise RuntimeError(
        "Expected 106 construct IDs"
    )


counts_per_construct = (
    eval_interfaces
    .groupby("construct_id")
    .size()
)


if not (
    counts_per_construct == 4
).all():

    raise RuntimeError(
        "Every Phase-2 construct must have exactly four J interfaces"
    )


pair_counts = Counter(
    zip(
        eval_interfaces[
            "left_global_module_index"
        ].astype(int),
        eval_interfaces[
            "right_global_module_index"
        ].astype(int),
    )
)


expected_pairs = {
    (1, 2): 106,
    (2, 3): 106,
    (3, 4): 106,
    (4, 5): 106,
}


if dict(pair_counts) != expected_pairs:

    raise RuntimeError(
        f"Unexpected module-pair counts: {pair_counts}"
    )


type_counts = Counter(
    eval_interfaces[
        "transition_type"
    ]
)


if type_counts != {
    "inter_module_linker_candidate": 347,
    "inter_protein_chain_break": 77,
}:

    raise RuntimeError(
        f"Unexpected J type counts: {type_counts}"
    )


breaks = eval_interfaces[
    eval_interfaces[
        "transition_type"
    ]
    ==
    "inter_protein_chain_break"
]


if not (
    breaks["junction_length_aa"] == 0
).all():

    raise RuntimeError(
        "Chain-break length must be zero"
    )


if not (
    breaks["junction_sequence"] == ""
).all():

    raise RuntimeError(
        "Chain-break sequence must be empty"
    )


linkers = eval_interfaces[
    eval_interfaces[
        "transition_type"
    ]
    ==
    "inter_module_linker_candidate"
]


if (
    linkers["junction_sequence"]
    .str.len()
    !=
    linkers["junction_length_aa"]
).any():

    raise RuntimeError(
        "Linker sequence/length mismatch"
    )


# ======================================================================
# WRITE LABEL-BLIND INTERFACE INPUT
# ======================================================================

interface_columns = [
    "construct_id",
    "assembly_line_id",
    "interface_id",
    "transition_uid",
    "interface_index",
    "left_global_module_index",
    "right_global_module_index",
    "left_module_uid",
    "right_module_uid",
    "left_sequence_hash",
    "right_sequence_hash",
    "transition_type",
    "junction_kind",
    "junction_sequence",
    "junction_length_aa",
    "junction_sequence_hash",
    "sequence_available",
    "module_count",
]


eval_interfaces[
    interface_columns
].to_csv(
    TMP / "interfaces.tsv.gz",
    sep="\t",
    index=False,
    compression="gzip",
)


# ======================================================================
# NOW BUILD LABEL VIEWS
#
# These are separate from the model-input table.
# ======================================================================

labels_raw = pd.read_csv(
    LABELS,
    sep="\t",
    keep_default_na=False,
)


required = {
    "nrps_id",
    "plasmid_combo",
    "starter",
    "elongation",
    "termination",
    "n_exchanges",
    "swapped_position",
    "exchanged_donor",
    "peak_score",
    "active",
    "peak_area",
}


missing = (
    required
    -
    set(labels_raw.columns)
)


if missing:

    raise RuntimeError(
        f"Missing Phase-2 label columns: {sorted(missing)}"
    )


if len(labels_raw) != EXPECTED_CONSTRUCTS:

    raise RuntimeError(
        f"Expected 106 label rows, got {len(labels_raw)}"
    )


labels_raw["active"] = pd.to_numeric(
    labels_raw["active"],
    errors="raise",
).astype(int)


if set(labels_raw["active"]) != {0, 1}:

    raise RuntimeError(
        "Activity labels are not binary"
    )


label_counts = Counter(
    labels_raw["active"]
)


if label_counts != {
    0: EXPECTED_INACTIVE,
    1: EXPECTED_ACTIVE,
}:

    raise RuntimeError(
        f"Unexpected Phase-2 labels: {label_counts}"
    )


input_ids = set(
    eval_interfaces["construct_id"]
)

label_ids = set(
    labels_raw["nrps_id"]
)


if input_ids != label_ids:

    raise RuntimeError(
        "Model-input IDs and experimental-label IDs differ"
    )


# ======================================================================
# V2-C / V2-D atlas-compatible label table
# ======================================================================

atlas = pd.DataFrame({
    "construct_id":
        labels_raw["nrps_id"],

    "label":
        labels_raw["active"],

    "initiation_part":
        labels_raw["starter"],

    "elongation_part":
        labels_raw["elongation"],

    "termination_part":
        labels_raw["termination"],

    "product_topology":
        "phase2_single_exchange",

    "plasmid_combo":
        labels_raw["plasmid_combo"],

    "n_exchanges":
        labels_raw["n_exchanges"],

    "swapped_position":
        labels_raw["swapped_position"],

    "exchanged_donor":
        labels_raw["exchanged_donor"],

    "peak_score":
        labels_raw["peak_score"],

    "peak_area":
        labels_raw["peak_area"],
})


atlas.to_csv(
    TMP / "construct_atlas.tsv",
    sep="\t",
    index=False,
)


# ======================================================================
# V2-A historical activity-schema compatibility table
# ======================================================================

activity = pd.DataFrame({
    "construct_id":
        labels_raw["nrps_id"],

    "panel_code":
        labels_raw["plasmid_combo"],

    "expected_product_detected":
        labels_raw["active"].map(
            {
                0: "false",
                1: "true",
            }
        ),

    "product_topology":
        "phase2_single_exchange",

    "linear_product_detected":
        "false",

    "cyclic_product_detected":
        labels_raw["active"].map(
            {
                0: "false",
                1: "true",
            }
        ),

    "activity_definition":
        "Phase-2 iGEM peak_score > 0",

    "negative_label_interpretation":
        "peak_score == 0",

    "source":
        "Chaiyaphumine iGEM data.xlsm",
})


activity.to_csv(
    TMP
    / "experimental_construct_activity.tsv.gz",
    sep="\t",
    index=False,
    compression="gzip",
)


# ======================================================================
# SUMMARY
# ======================================================================

summary = {
    "status":
        "bode_phase2_evaluation_adapter_v1_3",

    "constructs":
        106,

    "modules":
        530,

    "interfaces":
        424,

    "interfaces_per_construct":
        4,

    "same_chain_linkers":
        347,

    "chain_breaks":
        77,

    "activity_positive":
        64,

    "activity_negative":
        42,

    "peak_score_distribution":
        {
            str(k):
                int(v)

            for k, v
            in sorted(
                Counter(
                    pd.to_numeric(
                        labels_raw[
                            "peak_score"
                        ],
                        errors="raise",
                    ).astype(int)
                ).items()
            )
        },

    "model_input_is_label_blind":
        True,

    "labels_joined_only_for_external_metrics":
        True,
}


with (
    TMP / "summary.json"
).open("w") as f:

    json.dump(
        summary,
        f,
        indent=2,
        sort_keys=True,
    )

    f.write("\n")


# ======================================================================
# COMMIT
# ======================================================================

if OUT.exists():

    backup = OUT.with_name(
        OUT.name + "_backup"
    )

    if backup.exists():
        shutil.rmtree(backup)

    OUT.rename(backup)


TMP.rename(OUT)


print("=" * 100)
print("BODE PHASE-2 EVALUATION ADAPTER V1.3")
print("=" * 100)
print("constructs:           106")
print("modules:              530")
print("interfaces:           424")
print("same-chain J:         347")
print("chain-break J:         77")
print("active:                64")
print("inactive:              42")
print("model input labels:  NONE")
print()
print("OUTPUT:")
print(OUT)
print()
print("BODE PHASE-2 EVALUATION ADAPTER: FULL PASS")
