from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
import csv
import gzip

from neuralps.data.structured_path_store_v2 import (
    StructuredPathRecordV2,
    A_DOMAIN_TYPE,
    CARRIER_DOMAIN_TYPES,
)


class BodePhase2StructuredPathStoreV1_3:
    """
    External-Bode implementation of the frozen Route-A V2
    biological path-routing contract.

    Routing semantics are intentionally identical to the production
    antiSMASH StructuredPathStoreV2.

    Only dataset cardinalities/split contracts differ.
    """

    EXPECTED_DOMAIN_ROWS = 1_854
    EXPECTED_RECORDS = 530

    EXPECTED_SPLIT_COUNTS = {
        "external_bode_phase2": 530,
    }

    EXPECTED_A_COUNTS = {
        "external_bode_phase2": 530,
    }

    EXPECTED_CARRIER_COUNTS = {
        "external_bode_phase2": 530,
    }

    EXPECTED_CORE_COUNTS = {
        "external_bode_phase2": 530,
    }

    def __init__(
        self,
        root: str | Path,
        *,
        structured_store,
    ) -> None:

        self.root = Path(
            root
        )

        domains_path = (
            self.root
            / "structured_domains.tsv.gz"
        )

        if not domains_path.is_file():
            raise FileNotFoundError(
                domains_path
            )

        domains = defaultdict(
            list
        )

        splits = {}

        domain_row_count = 0

        with gzip.open(
            domains_path,
            "rt",
            encoding="utf-8",
            newline="",
        ) as f:

            reader = csv.DictReader(
                f,
                delimiter="\t",
            )

            required = {
                "module_uid",
                "split",
                "component_order",
                "domain_type",
            }

            if (
                reader.fieldnames is None
                or not required.issubset(
                    reader.fieldnames
                )
            ):
                raise RuntimeError(
                    "Bode Phase-2 structured_domains.tsv.gz "
                    f"schema mismatch: {reader.fieldnames}"
                )

            for row in reader:

                domain_row_count += 1

                uid = row[
                    "module_uid"
                ]

                v1_record = (
                    structured_store.get(
                        uid
                    )
                )

                split = row[
                    "split"
                ]

                if (
                    split
                    != v1_record.split
                ):
                    raise RuntimeError(
                        f"{uid}: Bode V1.1/V2 "
                        "split mismatch"
                    )

                previous_split = (
                    splits.get(
                        uid
                    )
                )

                if (
                    previous_split is not None
                    and previous_split != split
                ):
                    raise RuntimeError(
                        f"{uid}: mixed split labels"
                    )

                splits[
                    uid
                ] = split

                domains[
                    uid
                ].append(
                    (
                        int(
                            row[
                                "component_order"
                            ]
                        ),
                        row[
                            "domain_type"
                        ],
                    )
                )

        if (
            domain_row_count
            != self.EXPECTED_DOMAIN_ROWS
        ):
            raise RuntimeError(
                "Unexpected Bode Phase-2 structured domain count: "
                f"{domain_row_count}"
            )

        if (
            len(domains)
            != len(structured_store)
        ):
            raise RuntimeError(
                "Bode V1.1/V2 module coverage mismatch: "
                f"{len(domains)} vs "
                f"{len(structured_store)}"
            )

        if (
            len(domains)
            != self.EXPECTED_RECORDS
        ):
            raise RuntimeError(
                "Unexpected Bode V2 routing module count: "
                f"{len(domains)}"
            )

        records = {}

        split_counts = Counter()
        a_counts = Counter()
        carrier_counts = Counter()
        core_counts = Counter()

        for uid in sorted(
            domains
        ):

            rows = sorted(
                domains[
                    uid
                ]
            )

            orders = [
                order
                for order, _ in rows
            ]

            expected_orders = list(
                range(
                    1,
                    len(rows) + 1,
                )
            )

            if (
                orders
                != expected_orders
            ):
                raise RuntimeError(
                    f"{uid}: non-contiguous "
                    f"component order {orders}"
                )

            types = [
                domain_type
                for _, domain_type
                in rows
            ]

            domain_count = len(
                types
            )

            if domain_count < 1:
                raise RuntimeError(
                    f"{uid}: no domains"
                )

            biological_token_count = (
                2 * domain_count - 1
            )

            v1_record = (
                structured_store.get(
                    uid
                )
            )

            if (
                len(
                    v1_record.tokens
                )
                != biological_token_count
            ):
                raise RuntimeError(
                    f"{uid}: V1.1 token-count mismatch"
                )

            # Exact production D-B-D-B-...-D geometry.
            initial_token_index = 0

            terminal_token_index = (
                biological_token_count
                - 1
            )

            if (
                initial_token_index % 2 != 0
                or terminal_token_index % 2 != 0
            ):
                raise RuntimeError(
                    f"{uid}: invalid terminal geometry"
                )

            a_orders = [
                i + 1
                for i, domain_type
                in enumerate(
                    types
                )
                if (
                    domain_type
                    == A_DOMAIN_TYPE
                )
            ]

            carrier_orders = [
                i + 1
                for i, domain_type
                in enumerate(
                    types
                )
                if (
                    domain_type
                    in CARRIER_DOMAIN_TYPES
                )
            ]

            if len(
                a_orders
            ) > 1:
                raise RuntimeError(
                    f"{uid}: multiple AMP-binding domains"
                )

            if len(
                carrier_orders
            ) > 1:
                raise RuntimeError(
                    f"{uid}: multiple carrier domains"
                )

            a_order = (
                a_orders[0]
                if a_orders
                else None
            )

            carrier_order = (
                carrier_orders[0]
                if carrier_orders
                else None
            )

            a_token_index = (
                2 * (
                    a_order - 1
                )
                if (
                    a_order
                    is not None
                )
                else None
            )

            carrier_token_index = (
                2 * (
                    carrier_order - 1
                )
                if (
                    carrier_order
                    is not None
                )
                else None
            )

            entry_span = None
            core_span = None
            exit_span = None

            if (
                a_token_index
                is not None
            ):

                # Module start through A, inclusive.
                entry_span = (
                    0,
                    a_token_index + 1,
                )

            if (
                carrier_token_index
                is not None
            ):

                # Carrier through actual module end.
                exit_span = (
                    carrier_token_index,
                    biological_token_count,
                )

            if (
                a_token_index is not None
                and carrier_token_index
                is not None
            ):

                if (
                    carrier_token_index
                    <= a_token_index
                ):
                    raise RuntimeError(
                        f"{uid}: carrier does not occur "
                        "downstream of AMP-binding"
                    )

                # A through carrier, preserving every intervening
                # D/B token and tailoring domain.
                core_span = (
                    a_token_index,
                    carrier_token_index + 1,
                )

            record = (
                StructuredPathRecordV2(
                    module_uid=uid,
                    split=splits[
                        uid
                    ],
                    domain_count=(
                        domain_count
                    ),
                    biological_token_count=(
                        biological_token_count
                    ),
                    initial_domain_type=(
                        types[
                            0
                        ]
                    ),
                    terminal_domain_type=(
                        types[
                            -1
                        ]
                    ),
                    initial_token_index=(
                        initial_token_index
                    ),
                    terminal_token_index=(
                        terminal_token_index
                    ),
                    a_component_order=(
                        a_order
                    ),
                    carrier_component_order=(
                        carrier_order
                    ),
                    a_token_index=(
                        a_token_index
                    ),
                    carrier_token_index=(
                        carrier_token_index
                    ),
                    entry_span=(
                        entry_span
                    ),
                    core_span=(
                        core_span
                    ),
                    exit_span=(
                        exit_span
                    ),
                )
            )

            records[
                uid
            ] = record

            split = record.split

            split_counts[
                split
            ] += 1

            if record.has_a:
                a_counts[
                    split
                ] += 1

            if record.has_carrier:
                carrier_counts[
                    split
                ] += 1

            if record.has_core:
                core_counts[
                    split
                ] += 1

        if (
            dict(
                split_counts
            )
            != self.EXPECTED_SPLIT_COUNTS
        ):
            raise RuntimeError(
                "Bode V2 split-count contract mismatch: "
                f"{dict(split_counts)}"
            )

        if (
            dict(
                a_counts
            )
            != self.EXPECTED_A_COUNTS
        ):
            raise RuntimeError(
                "Bode V2 A-domain count contract mismatch: "
                f"{dict(a_counts)}"
            )

        if (
            dict(
                carrier_counts
            )
            != self.EXPECTED_CARRIER_COUNTS
        ):
            raise RuntimeError(
                "Bode V2 carrier count contract mismatch: "
                f"{dict(carrier_counts)}"
            )

        if (
            dict(
                core_counts
            )
            != self.EXPECTED_CORE_COUNTS
        ):
            raise RuntimeError(
                "Bode V2 core-path count contract mismatch: "
                f"{dict(core_counts)}"
            )

        self._records = records

        self._split_counts = dict(
            split_counts
        )

        self._a_counts = dict(
            a_counts
        )

        self._carrier_counts = dict(
            carrier_counts
        )

        self._core_counts = dict(
            core_counts
        )

    def __len__(
        self,
    ) -> int:

        return len(
            self._records
        )

    def __contains__(
        self,
        module_uid: str,
    ) -> bool:

        return (
            module_uid
            in self._records
        )

    def get(
        self,
        module_uid: str,
    ) -> StructuredPathRecordV2:

        try:
            return self._records[
                module_uid
            ]

        except KeyError as exc:
            raise KeyError(
                "Unknown Bode V2 path-routing "
                f"module UID: {module_uid}"
            ) from exc

    def iter_records(
        self,
    ):

        yield from (
            self._records.values()
        )

    def routing_counts(
        self,
    ) -> dict[str, dict[str, int]]:

        result = {}

        for split in sorted(
            self._split_counts
        ):

            result[
                split
            ] = {
                "modules": (
                    self._split_counts[
                        split
                    ]
                ),
                "has_A": (
                    self._a_counts.get(
                        split,
                        0,
                    )
                ),
                "has_carrier": (
                    self._carrier_counts.get(
                        split,
                        0,
                    )
                ),
                "has_core": (
                    self._core_counts.get(
                        split,
                        0,
                    )
                ),
            }

        return result
