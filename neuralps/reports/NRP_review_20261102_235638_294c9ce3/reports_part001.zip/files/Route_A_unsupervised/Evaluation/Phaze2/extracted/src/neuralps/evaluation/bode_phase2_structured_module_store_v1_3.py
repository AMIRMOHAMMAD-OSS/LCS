from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal
import csv
import gzip


TokenKind = Literal[
    "domain",
    "boundary",
]


@dataclass(
    frozen=True,
    slots=True,
)
class StructuredTokenV1_1:
    kind: TokenKind
    sequence_hash: str
    position: int


@dataclass(
    frozen=True,
    slots=True,
)
class StructuredModuleRecordV1_1:
    module_uid: str
    split: str
    module_sequence_hash: str
    tokens: tuple[
        StructuredTokenV1_1,
        ...,
    ]

    @property
    def domain_count(
        self,
    ) -> int:
        return sum(
            token.kind == "domain"
            for token in self.tokens
        )

    @property
    def boundary_count(
        self,
    ) -> int:
        return sum(
            token.kind == "boundary"
            for token in self.tokens
        )

    @property
    def transformer_token_count(
        self,
    ) -> int:
        # Learned CLS + alternating
        # domain/boundary sequence.
        return (
            1
            + len(
                self.tokens
            )
        )


class StructuredModuleStoreV1_1:
    """
    Immutable structural index for Route-A v1.1.

    This class contains no learned state and does not load ESMC tensors.
    It maps each Route-A module UID onto:

      whole-module sequence hash
      +
      D1, B1, D2, B2, ... Dn sequence hashes

    Model inputs intentionally exclude taxonomy, domain-type labels,
    substrate labels, and explicit gap-length metadata in V1-A.
    """

    MAX_TOKENS_WITH_CLS = 12

    def __init__(
        self,
        root: str | Path,
    ) -> None:

        self.root = Path(
            root
        )

        modules_path = (
            self.root
            / "structured_modules.tsv.gz"
        )

        domains_path = (
            self.root
            / "structured_domains.tsv.gz"
        )

        boundaries_path = (
            self.root
            / "internal_boundaries.tsv.gz"
        )


        for path in (
            modules_path,
            domains_path,
            boundaries_path,
        ):
            if not path.is_file():
                raise FileNotFoundError(
                    path
                )


        # --------------------------------------------------------------
        # Module-level metadata.
        # --------------------------------------------------------------

        module_meta: dict[
            str,
            dict[str, object],
        ] = {}


        with gzip.open(
            modules_path,
            "rt",
            newline="",
        ) as f:

            reader = csv.DictReader(
                f,
                delimiter="\t",
            )

            for row in reader:

                uid = row[
                    "module_uid"
                ]

                if uid in module_meta:
                    raise RuntimeError(
                        "Duplicate structured "
                        f"module UID: {uid}"
                    )

                module_meta[
                    uid
                ] = {
                    "split": (
                        row[
                            "split"
                        ]
                    ),
                    "module_sequence_hash": (
                        row[
                            "module_sequence_hash"
                        ]
                    ),
                    "component_count": int(
                        row[
                            "component_count"
                        ]
                    ),
                    "boundary_count": int(
                        row[
                            "internal_boundary_count"
                        ]
                    ),
                }


        # --------------------------------------------------------------
        # Ordered domain sequence hashes.
        # --------------------------------------------------------------

        domains: dict[
            str,
            list[
                tuple[
                    int,
                    str,
                ]
            ],
        ] = {}


        with gzip.open(
            domains_path,
            "rt",
            newline="",
        ) as f:

            reader = csv.DictReader(
                f,
                delimiter="\t",
            )

            for row in reader:

                uid = row[
                    "module_uid"
                ]

                if uid not in module_meta:
                    raise RuntimeError(
                        "Domain references unknown "
                        f"module UID: {uid}"
                    )

                domains.setdefault(
                    uid,
                    [],
                ).append(
                    (
                        int(
                            row[
                                "component_order"
                            ]
                        ),
                        row[
                            "domain_sequence_hash"
                        ],
                    )
                )


        # --------------------------------------------------------------
        # Ordered boundary sequence hashes.
        # --------------------------------------------------------------

        boundaries: dict[
            str,
            list[
                tuple[
                    int,
                    str,
                ]
            ],
        ] = {}


        with gzip.open(
            boundaries_path,
            "rt",
            newline="",
        ) as f:

            reader = csv.DictReader(
                f,
                delimiter="\t",
            )

            for row in reader:

                uid = row[
                    "module_uid"
                ]

                if uid not in module_meta:
                    raise RuntimeError(
                        "Boundary references unknown "
                        f"module UID: {uid}"
                    )

                boundaries.setdefault(
                    uid,
                    [],
                ).append(
                    (
                        int(
                            row[
                                "left_component_order"
                            ]
                        ),
                        row[
                            "boundary_sequence_hash"
                        ],
                    )
                )


        # --------------------------------------------------------------
        # Construct immutable records.
        # --------------------------------------------------------------

        records: dict[
            str,
            StructuredModuleRecordV1_1,
        ] = {}


        max_token_count = 0


        for uid in sorted(
            module_meta
        ):

            meta = module_meta[
                uid
            ]

            domain_rows = sorted(
                domains.get(
                    uid,
                    [],
                )
            )

            boundary_rows = sorted(
                boundaries.get(
                    uid,
                    [],
                )
            )


            expected_domains = int(
                meta[
                    "component_count"
                ]
            )

            expected_boundaries = int(
                meta[
                    "boundary_count"
                ]
            )


            if len(
                domain_rows
            ) != expected_domains:
                raise RuntimeError(
                    f"{uid}: expected "
                    f"{expected_domains} domains, "
                    f"found {len(domain_rows)}"
                )


            if len(
                boundary_rows
            ) != expected_boundaries:
                raise RuntimeError(
                    f"{uid}: expected "
                    f"{expected_boundaries} boundaries, "
                    f"found {len(boundary_rows)}"
                )


            if (
                expected_boundaries
                != expected_domains - 1
            ):
                raise RuntimeError(
                    f"{uid}: invalid D/B geometry"
                )


            observed_domain_orders = [
                order
                for order, _ in domain_rows
            ]

            expected_domain_orders = list(
                range(
                    1,
                    expected_domains + 1,
                )
            )


            if (
                observed_domain_orders
                != expected_domain_orders
            ):
                raise RuntimeError(
                    f"{uid}: invalid domain order "
                    f"{observed_domain_orders}"
                )


            observed_boundary_orders = [
                order
                for order, _ in boundary_rows
            ]

            expected_boundary_orders = list(
                range(
                    1,
                    expected_domains,
                )
            )


            if (
                observed_boundary_orders
                != expected_boundary_orders
            ):
                raise RuntimeError(
                    f"{uid}: invalid boundary order "
                    f"{observed_boundary_orders}"
                )


            tokens: list[
                StructuredTokenV1_1
            ] = []


            token_position = 1
            # Position 0 is reserved for CLS.


            for i, (
                _,
                domain_hash,
            ) in enumerate(
                domain_rows
            ):

                tokens.append(
                    StructuredTokenV1_1(
                        kind="domain",
                        sequence_hash=(
                            domain_hash
                        ),
                        position=(
                            token_position
                        ),
                    )
                )

                token_position += 1


                if i < len(
                    boundary_rows
                ):

                    boundary_hash = (
                        boundary_rows[
                            i
                        ][1]
                    )

                    tokens.append(
                        StructuredTokenV1_1(
                            kind=(
                                "boundary"
                            ),
                            sequence_hash=(
                                boundary_hash
                            ),
                            position=(
                                token_position
                            ),
                        )
                    )

                    token_position += 1


            record = (
                StructuredModuleRecordV1_1(
                    module_uid=uid,
                    split=str(
                        meta[
                            "split"
                        ]
                    ),
                    module_sequence_hash=str(
                        meta[
                            "module_sequence_hash"
                        ]
                    ),
                    tokens=tuple(
                        tokens
                    ),
                )
            )


            if (
                record.transformer_token_count
                > self.MAX_TOKENS_WITH_CLS
            ):
                raise RuntimeError(
                    f"{uid}: transformer sequence "
                    f"length "
                    f"{record.transformer_token_count} "
                    f"> frozen maximum "
                    f"{self.MAX_TOKENS_WITH_CLS}"
                )


            max_token_count = max(
                max_token_count,
                record.transformer_token_count,
            )


            records[
                uid
            ] = record


        if len(
            records
        ) != 530:
            raise RuntimeError(
                "Expected 530 Bode Phase-2 structured "
                f"modules, got {len(records)}"
            )


        if max_token_count != 10:
            raise RuntimeError(
                "Expected Bode maximum transformer "
                f"token count 10, got "
                f"{max_token_count}"
            )


        self._records = records

        self._max_token_count = (
            max_token_count
        )


    def __len__(
        self,
    ) -> int:
        return len(
            self._records
        )


    def __contains__(
        self,
        module_uid: str,
    ) -> bool:
        return (
            module_uid
            in self._records
        )


    def get(
        self,
        module_uid: str,
    ) -> StructuredModuleRecordV1_1:

        try:
            return self._records[
                module_uid
            ]

        except KeyError as exc:
            raise KeyError(
                "Unknown structured module UID: "
                f"{module_uid}"
            ) from exc


    @property
    def max_token_count(
        self,
    ) -> int:
        return (
            self._max_token_count
        )


    def split_counts(
        self,
    ) -> dict[str, int]:

        counts: dict[
            str,
            int,
        ] = {}

        for record in (
            self._records.values()
        ):

            counts[
                record.split
            ] = (
                counts.get(
                    record.split,
                    0,
                )
                + 1
            )

        return dict(
            sorted(
                counts.items()
            )
        )
