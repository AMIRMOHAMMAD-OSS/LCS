from __future__ import annotations

from dataclasses import dataclass

import torch

from neuralps.data.assembly_context_store_v2 import (
    AssemblyContextStoreV2,
)


@dataclass(
    frozen=True,
)
class AssemblyIndexBatchV2:
    """
    Compact occurrence-level V2-B assembly coordinates.

    The natural assembly is stored ONCE per query.

    Candidate-conditioned assembly tracks are NOT materialized here.

    module_uids_flat:
        all natural assembly module occurrences flattened over B

    transition_uids_flat:
        all natural assembly transitions flattened over B

    module_offset:
        [B+1], CSR-style boundaries into module_uids_flat

    transition_offset:
        [B+1], CSR-style boundaries into transition_uids_flat

    query_transition_index:
        [B], zero-based Ji

    forward_candidate_module_index:
        [B], zero-based module slot q+1

    reverse_candidate_module_index:
        [B], zero-based module slot q

    forward_far_mask_transition_index:
        [B], zero-based J(q+1), or -1 at terminal boundary

    reverse_far_mask_transition_index:
        [B], zero-based J(q-1), or -1 at initial boundary
    """

    assembly_line_ids: tuple[str, ...]

    module_uids_flat: tuple[str, ...]
    module_hashes_flat: tuple[str, ...]

    transition_uids_flat: tuple[str, ...]
    transition_types_flat: tuple[str, ...]

    module_offset: torch.Tensor
    transition_offset: torch.Tensor

    module_count: torch.Tensor

    query_transition_index: torch.Tensor

    forward_candidate_module_index: torch.Tensor
    reverse_candidate_module_index: torch.Tensor

    forward_far_mask_transition_index: torch.Tensor
    reverse_far_mask_transition_index: torch.Tensor

    def validate(
        self,
    ) -> None:

        if self.module_offset.ndim != 1:
            raise RuntimeError(
                "module_offset must be rank 1"
            )

        if self.transition_offset.ndim != 1:
            raise RuntimeError(
                "transition_offset must be rank 1"
            )

        batch_size = len(
            self.assembly_line_ids
        )

        if self.module_offset.shape != (
            batch_size + 1,
        ):
            raise RuntimeError(
                "module_offset shape mismatch"
            )

        if self.transition_offset.shape != (
            batch_size + 1,
        ):
            raise RuntimeError(
                "transition_offset shape mismatch"
            )

        vector_names = (
            "module_count",
            "query_transition_index",
            "forward_candidate_module_index",
            "reverse_candidate_module_index",
            "forward_far_mask_transition_index",
            "reverse_far_mask_transition_index",
        )

        for name in vector_names:

            value = getattr(
                self,
                name,
            )

            if value.shape != (
                batch_size,
            ):
                raise RuntimeError(
                    f"{name} shape mismatch"
                )

            if value.dtype != torch.long:
                raise RuntimeError(
                    f"{name} must be torch.long"
                )

        if self.module_offset.dtype != torch.long:
            raise RuntimeError(
                "module_offset must be torch.long"
            )

        if (
            self.transition_offset.dtype
            != torch.long
        ):
            raise RuntimeError(
                "transition_offset must be torch.long"
            )

        if int(
            self.module_offset[0]
        ) != 0:
            raise RuntimeError(
                "module_offset must start at zero"
            )

        if int(
            self.transition_offset[0]
        ) != 0:
            raise RuntimeError(
                "transition_offset must start at zero"
            )

        if int(
            self.module_offset[-1]
        ) != len(
            self.module_uids_flat
        ):
            raise RuntimeError(
                "module_offset terminal mismatch"
            )

        if int(
            self.transition_offset[-1]
        ) != len(
            self.transition_uids_flat
        ):
            raise RuntimeError(
                "transition_offset terminal mismatch"
            )

        if len(
            self.module_uids_flat
        ) != len(
            self.module_hashes_flat
        ):
            raise RuntimeError(
                "module UID/hash flatten mismatch"
            )

        if len(
            self.transition_uids_flat
        ) != len(
            self.transition_types_flat
        ):
            raise RuntimeError(
                "transition UID/type flatten mismatch"
            )

        for b in range(
            batch_size
        ):

            M = int(
                self.module_count[b]
            )

            if M < 2:
                raise RuntimeError(
                    "assembly module_count < 2"
                )

            module_begin = int(
                self.module_offset[b]
            )

            module_end = int(
                self.module_offset[
                    b + 1
                ]
            )

            transition_begin = int(
                self.transition_offset[b]
            )

            transition_end = int(
                self.transition_offset[
                    b + 1
                ]
            )

            if (
                module_end
                - module_begin
                != M
            ):
                raise RuntimeError(
                    "per-example module count mismatch"
                )

            if (
                transition_end
                - transition_begin
                != M - 1
            ):
                raise RuntimeError(
                    "per-example transition count mismatch"
                )

            q = int(
                self.query_transition_index[
                    b
                ]
            )

            if not (
                0 <= q < M - 1
            ):
                raise RuntimeError(
                    "query transition outside assembly"
                )

            if int(
                self.forward_candidate_module_index[
                    b
                ]
            ) != q + 1:
                raise RuntimeError(
                    "forward candidate slot mismatch"
                )

            if int(
                self.reverse_candidate_module_index[
                    b
                ]
            ) != q:
                raise RuntimeError(
                    "reverse candidate slot mismatch"
                )

            expected_forward_mask = (
                q + 1
                if q + 1 < M - 1
                else -1
            )

            expected_reverse_mask = (
                q - 1
                if q > 0
                else -1
            )

            if int(
                self.forward_far_mask_transition_index[
                    b
                ]
            ) != expected_forward_mask:
                raise RuntimeError(
                    "forward far-mask slot mismatch"
                )

            if int(
                self.reverse_far_mask_transition_index[
                    b
                ]
            ) != expected_reverse_mask:
                raise RuntimeError(
                    "reverse far-mask slot mismatch"
                )


class AssemblyIndexBatchBuilderV2:
    """
    Build compact V2-B assembly coordinates from dataset items.

    No full candidate-conditioned assembly copies are constructed.
    """

    def __init__(
        self,
        assembly_store: AssemblyContextStoreV2,
    ) -> None:

        self.assembly_store = (
            assembly_store
        )


    def build(
        self,
        items,
    ) -> AssemblyIndexBatchV2:

        if not items:
            raise ValueError(
                "Empty V2-B assembly batch"
            )

        assembly_line_ids = []

        module_uids_flat = []
        module_hashes_flat = []

        transition_uids_flat = []
        transition_types_flat = []

        module_offset = [0]
        transition_offset = [0]

        module_count = []

        query_transition_index = []

        forward_candidate_module_index = []
        reverse_candidate_module_index = []

        forward_far_mask_transition_index = []
        reverse_far_mask_transition_index = []


        for item in items:

            assembly_id = item[
                "assembly_line_id"
            ]

            record = (
                self.assembly_store.get(
                    assembly_id
                )
            )

            # Dataset stores biological 1-based Ji.
            q_one = int(
                item[
                    "query_transition_index"
                ]
            )

            q = q_one - 1

            M = record.module_count

            if not (
                0 <= q < M - 1
            ):
                raise RuntimeError(
                    f"{assembly_id}: "
                    "query transition outside assembly"
                )


            # ------------------------------------------------------
            # Query identity must reproduce the natural assembly.
            # ------------------------------------------------------

            if (
                record.transition_uids[q]
                != item[
                    "transition_uid"
                ]
            ):
                raise RuntimeError(
                    f"{assembly_id}: "
                    "query transition identity drift"
                )

            if (
                record.module_uids[q]
                != item[
                    "left_module_uid"
                ]
            ):
                raise RuntimeError(
                    f"{assembly_id}: "
                    "query left module identity drift"
                )

            if (
                record.module_uids[
                    q + 1
                ]
                != item[
                    "right_module_uid"
                ]
            ):
                raise RuntimeError(
                    f"{assembly_id}: "
                    "query right module identity drift"
                )


            assembly_line_ids.append(
                assembly_id
            )

            module_uids_flat.extend(
                record.module_uids
            )

            module_hashes_flat.extend(
                record.module_sequence_hashes
            )

            transition_uids_flat.extend(
                record.transition_uids
            )

            transition_types_flat.extend(
                record.transition_types
            )

            module_offset.append(
                len(
                    module_uids_flat
                )
            )

            transition_offset.append(
                len(
                    transition_uids_flat
                )
            )

            module_count.append(
                M
            )

            query_transition_index.append(
                q
            )

            forward_candidate_module_index.append(
                q + 1
            )

            reverse_candidate_module_index.append(
                q
            )

            # Forward candidate = M(q+1).
            # Far side = J(q+1), if present.
            forward_far_mask_transition_index.append(
                q + 1
                if q + 1 < M - 1
                else -1
            )

            # Reverse candidate = M(q).
            # Far side = J(q-1), if present.
            reverse_far_mask_transition_index.append(
                q - 1
                if q > 0
                else -1
            )


        result = AssemblyIndexBatchV2(
            assembly_line_ids=tuple(
                assembly_line_ids
            ),

            module_uids_flat=tuple(
                module_uids_flat
            ),

            module_hashes_flat=tuple(
                module_hashes_flat
            ),

            transition_uids_flat=tuple(
                transition_uids_flat
            ),

            transition_types_flat=tuple(
                transition_types_flat
            ),

            module_offset=torch.tensor(
                module_offset,
                dtype=torch.long,
            ),

            transition_offset=torch.tensor(
                transition_offset,
                dtype=torch.long,
            ),

            module_count=torch.tensor(
                module_count,
                dtype=torch.long,
            ),

            query_transition_index=torch.tensor(
                query_transition_index,
                dtype=torch.long,
            ),

            forward_candidate_module_index=torch.tensor(
                forward_candidate_module_index,
                dtype=torch.long,
            ),

            reverse_candidate_module_index=torch.tensor(
                reverse_candidate_module_index,
                dtype=torch.long,
            ),

            forward_far_mask_transition_index=torch.tensor(
                forward_far_mask_transition_index,
                dtype=torch.long,
            ),

            reverse_far_mask_transition_index=torch.tensor(
                reverse_far_mask_transition_index,
                dtype=torch.long,
            ),
        )

        result.validate()

        return result
