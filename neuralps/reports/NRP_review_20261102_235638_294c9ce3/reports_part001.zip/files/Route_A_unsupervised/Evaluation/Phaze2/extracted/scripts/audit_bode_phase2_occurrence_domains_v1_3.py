#!/usr/bin/env python3

from pathlib import Path
from collections import Counter, defaultdict
import re

import pandas as pd
from Bio import SeqIO


# ======================================================================
# PATHS
# ======================================================================

GB = Path(
    "data/bode_engineered_confidential/"
    "processed/genbank_raw/"
    "106 NRPS sequences.gb"
)

V12 = Path(
    "data/bode_engineered_confidential/"
    "processed/structured_v1_2/"
    "structured_domains.tsv"
)


# ======================================================================
# FROZEN DOMAIN-TYPE POLICY
#
# Same biological vocabulary used in corrected V1.2.
# ======================================================================

CORE_TYPES = {
    "Condensation_Starter",
    "Condensation_LCL",
    "Condensation_DCL",
    "Condensation_Dual",
    "AMP-binding",
    "PCP",
    "Epimerization",
    "TIGR01720",
}


# ======================================================================
# HELPERS
# ======================================================================

def one(q, key, default=""):
    x = q.get(
        key,
        [],
    )

    return (
        str(x[0])
        if x
        else default
    )


def clean_aa(seq):
    return "".join(
        str(seq).split()
    ).upper()


def construct_name(rec):

    name = str(
        rec.name
    )

    if "_(" in name:

        return name.split(
            "_(",
            1,
        )[0]

    return name


def domain_type(q):

    if (
        one(
            q,
            "aSTool",
        )
        !=
        "nrps_pks_domains"
    ):
        return None


    raw = one(
        q,
        "aSDomain",
    ).strip()


    subtypes = [
        str(x).strip()

        for x in q.get(
            "domain_subtypes",
            [],
        )

        if str(x).strip()
    ]


    if raw == "Condensation":

        dtype = None


        # ----------------------------------------------------------
        # Primary source.
        # ----------------------------------------------------------

        for subtype in subtypes:

            if subtype.startswith(
                "Condensation_"
            ):

                dtype = subtype

                break


        # ----------------------------------------------------------
        # Fallback from domain_id if needed.
        # ----------------------------------------------------------

        if dtype is None:

            domain_id = one(
                q,
                "domain_id",
            )


            for candidate in (
                "Condensation_Starter",
                "Condensation_LCL",
                "Condensation_DCL",
                "Condensation_Dual",
            ):

                if candidate in domain_id:

                    dtype = candidate

                    break


        if dtype is None:

            return None


    else:

        dtype = raw


    if dtype not in CORE_TYPES:

        return None


    return dtype


def transferred_translation(q):

    for key in (
        "Transferred_Translation",
        "X-Transferred_Translation",
        "translation",
    ):

        value = one(
            q,
            key,
        )

        if value:

            seq = clean_aa(
                value
            )

            if seq:

                return seq


    return ""


# ======================================================================
# RAW FEATURE EXTRACTION
# ======================================================================

records = list(
    SeqIO.parse(
        str(GB),
        "genbank",
    )
)


assert len(records) == 106


v12 = pd.read_csv(
    V12,
    sep="\t",
)


print(
    "=" * 120
)

print(
    "BODE PHASE-2 OCCURRENCE-LEVEL DOMAIN AUDIT V1.3"
)

print(
    "=" * 120
)

print(
    "GenBank constructs:",
    len(records),
)

print(
    "V1.2 domain occurrences:",
    len(v12),
)

print(
    "V1.2 modules inferred from A count:",
    int(
        (
            v12[
                "domain_type"
            ]
            ==
            "AMP-binding"
        ).sum()
    ),
)


# ======================================================================
# IMPORTANT:
#
# Donor-domain identity != engineered occurrence identity.
#
# First group by donor-domain identity:
#
#     locus
#     type
#     protein start/end
#
# Then CLUSTER genomic feature intervals.
#
# Overlapping intervals = duplicate/partial annotations of SAME occurrence.
#
# Distant intervals = repeated occurrence of SAME donor domain and MUST
# remain separate.
# ======================================================================

all_occurrences = []

raw_feature_count = 0

duplicate_annotation_clusters = 0


for rec in records:

    raw_id = str(
        rec.id
    )

    cid = construct_name(
        rec
    )


    by_donor_domain = defaultdict(
        list
    )


    for feature_index, feat in enumerate(
        rec.features
    ):

        if feat.type != "aSDomain":
            continue


        q = feat.qualifiers


        dtype = domain_type(
            q
        )


        if dtype is None:

            continue


        locus = one(
            q,
            "locus_tag",
        )


        try:

            pstart = int(
                one(
                    q,
                    "protein_start",
                )
            )

            pend = int(
                one(
                    q,
                    "protein_end",
                )
            )

        except Exception:

            continue


        raw_feature_count += 1


        start = int(
            feat.location.start
        )

        end = int(
            feat.location.end
        )


        seq = transferred_translation(
            q
        )


        key = (
            locus,
            dtype,
            pstart,
            pend,
        )


        by_donor_domain[
            key
        ].append(
            {
                "feature_index":
                    feature_index,

                "start":
                    start,

                "end":
                    end,

                "sequence":
                    seq,

                "domain_id":
                    one(
                        q,
                        "domain_id",
                    ),
            }
        )


    # ==================================================================
    # OCCURRENCE CLUSTERING
    # ==================================================================

    for (
        locus,
        dtype,
        pstart,
        pend,
    ), features in by_donor_domain.items():


        features = sorted(
            features,
            key=lambda x: (
                x[
                    "start"
                ],
                x[
                    "end"
                ],
            ),
        )


        clusters = []

        current = []


        for feature in features:

            if not current:

                current = [
                    feature
                ]

                continue


            current_max_end = max(
                x[
                    "end"
                ]
                for x in current
            )


            # ----------------------------------------------------------
            # TRUE annotation duplicate:
            #
            # genomic intervals overlap.
            #
            # Do NOT merge separated occurrences merely because donor
            # locus/protein coordinates are identical.
            # ----------------------------------------------------------

            if (
                feature[
                    "start"
                ]
                <
                current_max_end
            ):

                current.append(
                    feature
                )

            else:

                clusters.append(
                    current
                )

                current = [
                    feature
                ]


        if current:

            clusters.append(
                current
            )


        for occurrence_index, cluster in enumerate(
            clusters,
            start=1,
        ):


            cluster_start = min(
                x[
                    "start"
                ]
                for x in cluster
            )

            cluster_end = max(
                x[
                    "end"
                ]
                for x in cluster
            )


            if len(cluster) > 1:

                duplicate_annotation_clusters += 1


            seqs = {
                x[
                    "sequence"
                ]
                for x in cluster
                if x[
                    "sequence"
                ]
            }


            # ----------------------------------------------------------
            # Partial transferred feature annotations of one occurrence
            # should still describe the same mature AA domain.
            # ----------------------------------------------------------

            if len(
                seqs
            ) > 1:

                print()
                print(
                    "CONFLICTING TRANSLATIONS"
                )

                print(
                    cid,
                    locus,
                    dtype,
                    pstart,
                    pend,
                )

                for x in cluster:

                    print(
                        x
                    )


                raise RuntimeError(
                    "One genomic occurrence has "
                    "conflicting transferred domain sequences"
                )


            sequence = (
                next(
                    iter(
                        seqs
                    )
                )
                if seqs
                else ""
            )


            all_occurrences.append(
                {
                    "raw_construct_id":
                        raw_id,

                    "construct_id":
                        cid,

                    "locus_tag":
                        locus,

                    "domain_type":
                        dtype,

                    "protein_start":
                        pstart,

                    "protein_end":
                        pend,

                    "occurrence_index_within_donor_domain":
                        occurrence_index,

                    "cluster_start_nt":
                        cluster_start,

                    "cluster_end_nt":
                        cluster_end,

                    "raw_annotation_count":
                        len(
                            cluster
                        ),

                    "transferred_sequence":
                        sequence,

                    "transferred_sequence_length":
                        len(
                            sequence
                        ),

                    "raw_feature_indices":
                        ",".join(
                            str(
                                x[
                                    "feature_index"
                                ]
                            )
                            for x in cluster
                        ),
                }
            )


occ = pd.DataFrame(
    all_occurrences
)


# ======================================================================
# BASIC COUNTS
# ======================================================================

print()
print(
    "=" * 120
)

print(
    "OCCURRENCE-LEVEL DOMAIN COUNTS"
)

print(
    "=" * 120
)

print(
    "raw retained feature annotations:",
    raw_feature_count,
)

print(
    "occurrence clusters:",
    len(
        occ
    ),
)

print(
    "clusters containing duplicate/partial annotations:",
    duplicate_annotation_clusters,
)


print()
print(
    occ[
        "domain_type"
    ]
    .value_counts()
    .sort_index()
    .to_string()
)


# ======================================================================
# A / PCP CONTRACT PER CONSTRUCT
# ======================================================================

per_construct = (
    occ.groupby(
        "construct_id"
    )
    .agg(
        A=(
            "domain_type",
            lambda s:
                int(
                    (
                        s
                        ==
                        "AMP-binding"
                    ).sum()
                ),
        ),

        PCP=(
            "domain_type",
            lambda s:
                int(
                    (
                        s
                        ==
                        "PCP"
                    ).sum()
                ),
        ),

        domains=(
            "domain_type",
            "size",
        ),
    )
)


bad_a = (
    per_construct[
        per_construct[
            "A"
        ]
        !=
        5
    ]
)


bad_pcp = (
    per_construct[
        per_construct[
            "PCP"
        ]
        !=
        5
    ]
)


print()
print(
    "=" * 120
)

print(
    "FIVE-MODULE ANCHOR CONTRACT"
)

print(
    "=" * 120
)

print(
    "constructs with exactly 5 A:",
    int(
        (
            per_construct[
                "A"
            ]
            ==
            5
        ).sum()
    ),
    "/ 106",
)

print(
    "constructs with exactly 5 PCP:",
    int(
        (
            per_construct[
                "PCP"
            ]
            ==
            5
        ).sum()
    ),
    "/ 106",
)


if len(
    bad_a
):

    print()
    print(
        "BAD A COUNTS:"
    )

    print(
        bad_a.to_string()
    )


if len(
    bad_pcp
):

    print()
    print(
        "BAD PCP COUNTS:"
    )

    print(
        bad_pcp.to_string()
    )


# ======================================================================
# RECONSTRUCT MODULES FROM OCCURRENCE ORDER
# ======================================================================

module_rows = []

assignment_rows = []

module_problems = []


for construct_id, g in occ.groupby(
    "construct_id",
    sort=False,
):


    g = g.sort_values(
        [
            "cluster_start_nt",
            "cluster_end_nt",
            "domain_type",
        ]
    )


    current = []

    modules_here = []


    for domain in g.to_dict(
        "records"
    ):

        dtype = domain[
            "domain_type"
        ]


        begins_module = (
            dtype.startswith(
                "Condensation_"
            )
            or
            dtype
            ==
            "AMP-binding"
        )


        has_pcp = any(
            x[
                "domain_type"
            ]
            ==
            "PCP"

            for x in current
        )


        if (
            current
            and
            has_pcp
            and
            begins_module
        ):

            modules_here.append(
                current
            )

            current = []


        current.append(
            domain
        )


    if current:

        modules_here.append(
            current
        )


    for module_index, module in enumerate(
        modules_here,
        start=1,
    ):


        types = [
            x[
                "domain_type"
            ]
            for x in module
        ]


        n_a = types.count(
            "AMP-binding"
        )

        n_pcp = types.count(
            "PCP"
        )


        if (
            n_a != 1
            or
            n_pcp != 1
        ):

            module_problems.append(
                (
                    construct_id,
                    module_index,
                    types,
                )
            )


        module_uid = (
            f"{construct_id}"
            f"|module={module_index}"
        )


        module_rows.append(
            {
                "construct_id":
                    construct_id,

                "module_uid":
                    module_uid,

                "module_index":
                    module_index,

                "component_count":
                    len(
                        module
                    ),

                "architecture":
                    "->".join(
                        types
                    ),

                "first_nt":
                    min(
                        x[
                            "cluster_start_nt"
                        ]
                        for x in module
                    ),

                "last_nt":
                    max(
                        x[
                            "cluster_end_nt"
                        ]
                        for x in module
                    ),
            }
        )


        for component_order, domain in enumerate(
            module,
            start=1,
        ):

            assignment_rows.append(
                {
                    **domain,

                    "module_uid":
                        module_uid,

                    "module_index":
                        module_index,

                    "component_order":
                        component_order,
                }
            )


modules = pd.DataFrame(
    module_rows
)

assigned = pd.DataFrame(
    assignment_rows
)


module_counts = (
    modules.groupby(
        "construct_id"
    )
    .size()
)


print()
print(
    "=" * 120
)

print(
    "OCCURRENCE-LEVEL MODULE RECONSTRUCTION"
)

print(
    "=" * 120
)

print(
    "constructs:",
    modules[
        "construct_id"
    ].nunique(),
)

print(
    "modules:",
    len(
        modules
    ),
)

print(
    "assigned domain occurrences:",
    len(
        assigned
    ),
)

print(
    "module composition problems:",
    len(
        module_problems
    ),
)

print()
print(
    "module-count distribution:"
)

print(
    module_counts
    .value_counts()
    .sort_index()
    .to_string()
)


if module_problems:

    print()
    print(
        "FIRST MODULE PROBLEMS"
    )

    for x in (
        module_problems[
            :50
        ]
    ):

        print(x)


# ======================================================================
# SCAR LABELS
# ======================================================================

record_by_construct = {
    construct_name(
        rec
    ):
        rec

    for rec in records
}


scar_rows = []

scar_problems = []


for construct_id, group in assigned.groupby(
    "construct_id",
    sort=False,
):

    rec = record_by_construct[
        construct_id
    ]


    labels = {}


    for feat in rec.features:

        label = one(
            feat.qualifiers,
            "label",
        ).strip()


        if label in {
            "LNR",
            "SAV",
            "NPC",
            "SEI",
        }:

            labels[
                label
            ] = (
                int(
                    feat.location.start
                ),
                int(
                    feat.location.end
                ),
            )


    specs = (
        (
            "scar1",
            "LNR",
            "SAV",
            2,
        ),

        (
            "scar2",
            "NPC",
            "SEI",
            3,
        ),
    )


    group = group.sort_values(
        [
            "cluster_start_nt",
            "cluster_end_nt",
        ]
    )


    for (
        scar_name,
        left_label,
        right_label,
        expected_module,
    ) in specs:


        scar_start = labels[
            left_label
        ][0]

        scar_end = labels[
            right_label
        ][1]


        upstream = group[
            group[
                "cluster_end_nt"
            ]
            <=
            scar_start
        ]


        downstream = group[
            group[
                "cluster_start_nt"
            ]
            >=
            scar_end
        ]


        if (
            len(
                upstream
            )
            == 0
            or
            len(
                downstream
            )
            == 0
        ):

            scar_problems.append(
                (
                    construct_id,
                    scar_name,
                    "NO_NEIGHBORS",
                )
            )

            continue


        left = (
            upstream.sort_values(
                [
                    "cluster_end_nt",
                    "cluster_start_nt",
                ]
            )
            .iloc[
                -1
            ]
        )


        right = (
            downstream.sort_values(
                [
                    "cluster_start_nt",
                    "cluster_end_nt",
                ]
            )
            .iloc[
                0
            ]
        )


        same_module = (
            int(
                left[
                    "module_index"
                ]
            )
            ==
            int(
                right[
                    "module_index"
                ]
            )
        )


        correct_types = (
            left[
                "domain_type"
            ]
            ==
            "AMP-binding"
            and
            right[
                "domain_type"
            ]
            ==
            "PCP"
        )


        correct_module = (
            int(
                left[
                    "module_index"
                ]
            )
            ==
            expected_module
        )


        if not (
            same_module
            and
            correct_types
            and
            correct_module
        ):

            scar_problems.append(
                (
                    construct_id,
                    scar_name,
                    left[
                        "domain_type"
                    ],
                    int(
                        left[
                            "module_index"
                        ]
                    ),
                    right[
                        "domain_type"
                    ],
                    int(
                        right[
                            "module_index"
                        ]
                    ),
                    expected_module,
                )
            )


        scar_rows.append(
            {
                "construct_id":
                    construct_id,

                "scar_name":
                    scar_name,

                "scar_start":
                    scar_start,

                "scar_end":
                    scar_end,

                "left_type":
                    left[
                        "domain_type"
                    ],

                "right_type":
                    right[
                        "domain_type"
                    ],

                "module_index":
                    int(
                        left[
                            "module_index"
                        ]
                    ),

                "same_module":
                    same_module,
            }
        )


print()
print(
    "=" * 120
)

print(
    "SCAR TOPOLOGY WITH OCCURRENCE-LEVEL DOMAINS"
)

print(
    "=" * 120
)

print(
    "scar mappings:",
    len(
        scar_rows
    ),
)

print(
    "scar problems:",
    len(
        scar_problems
    ),
)


if scar_problems:

    for x in scar_problems[:50]:

        print(x)


print()
print(
    Counter(
        (
            row[
                "scar_name"
            ],
            row[
                "module_index"
            ],
            row[
                "left_type"
            ],
            row[
                "right_type"
            ],
        )

        for row in scar_rows
    )
)


# ======================================================================
# V1.2 -> OCCURRENCE V1.3 DELTA
# ======================================================================

print()
print(
    "=" * 120
)

print(
    "V1.2 -> OCCURRENCE-LEVEL DELTA"
)

print(
    "=" * 120
)

print(
    "V1.2 domain occurrences:",
    len(
        v12
    ),
)

print(
    "occurrence-level domains:",
    len(
        occ
    ),
)

print(
    "domain occurrence delta:",
    len(
        occ
    )
    -
    len(
        v12
    ),
)


print(
    "V1.2 A:",
    int(
        (
            v12[
                "domain_type"
            ]
            ==
            "AMP-binding"
        ).sum()
    ),
)

print(
    "occurrence-level A:",
    int(
        (
            occ[
                "domain_type"
            ]
            ==
            "AMP-binding"
        ).sum()
    ),
)


print(
    "V1.2 PCP:",
    int(
        (
            v12[
                "domain_type"
            ]
            ==
            "PCP"
        ).sum()
    ),
)

print(
    "occurrence-level PCP:",
    int(
        (
            occ[
                "domain_type"
            ]
            ==
            "PCP"
        ).sum()
    ),
)


# ======================================================================
# HARD EXPECTED CONTRACT
# ======================================================================

checks = {
    "106 constructs":
        modules[
            "construct_id"
        ].nunique()
        ==
        106,

    "5 A per construct":
        len(
            bad_a
        )
        ==
        0,

    "5 PCP per construct":
        len(
            bad_pcp
        )
        ==
        0,

    "530 modules":
        len(
            modules
        )
        ==
        530,

    "5 modules per construct":
        bool(
            (
                module_counts
                ==
                5
            ).all()
        ),

    "all domains assigned":
        len(
            assigned
        )
        ==
        len(
            occ
        ),

    "module composition clean":
        len(
            module_problems
        )
        ==
        0,

    "212 scars":
        len(
            scar_rows
        )
        ==
        212,

    "scar topology clean":
        len(
            scar_problems
        )
        ==
        0,
}


print()
print(
    "=" * 120
)

print(
    "FINAL OCCURRENCE CONTRACT"
)

print(
    "=" * 120
)


for name, ok in checks.items():

    print(
        f"{'PASS' if ok else 'FAIL'}  "
        f"{name}"
    )


if all(
    checks.values()
):

    print()
    print(
        "=" * 120
    )

    print(
        "BODE PHASE-2 OCCURRENCE-LEVEL DOMAIN/MODULE TOPOLOGY: FULL PASS"
    )

    print(
        "=" * 120
    )

else:

    raise RuntimeError(
        "Occurrence-level topology is not yet fully resolved"
    )
