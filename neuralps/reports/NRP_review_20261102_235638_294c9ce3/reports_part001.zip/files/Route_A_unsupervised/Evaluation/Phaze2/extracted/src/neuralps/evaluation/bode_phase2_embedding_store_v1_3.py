from __future__ import annotations

from pathlib import Path
import csv
import gzip

import torch


class BodePhase2EmbeddingStoreV1_3:
    """
    Read-only adapter for the existing label-blind Bode ESMC packages.

    Supported kinds:
      - modules
      - domains

    Exposes a production-compatible get()/get_many() interface while
    preserving the existing Bode embedding files unchanged.
    """

    EXPECTED_COUNTS = {
        "modules": 215,
        "domains": 133,
    }

    ESMC_DIM = 1152

    def __init__(
        self,
        root: str | Path,
        kind: str,
    ) -> None:

        self.root = Path(root)
        self.kind = str(kind)

        if self.kind not in self.EXPECTED_COUNTS:
            raise ValueError(
                f"Unsupported Bode embedding kind: {self.kind}"
            )

        expected_count = self.EXPECTED_COUNTS[
            self.kind
        ]

        tensor_path = (
            self.root
            / f"{self.kind}_embeddings.pt"
        )

        index_path = (
            self.root
            / f"{self.kind}_embedding_index.tsv.gz"
        )

        if not tensor_path.is_file():
            raise FileNotFoundError(
                tensor_path
            )

        if not index_path.is_file():
            raise FileNotFoundError(
                index_path
            )

        obj = torch.load(
            tensor_path,
            map_location="cpu",
            weights_only=False,
        )

        if not isinstance(obj, dict):
            raise RuntimeError(
                f"{self.kind}: unexpected embedding package"
            )

        if (
            obj.get(
                "label_blind_embedding_extraction"
            )
            is not True
        ):
            raise RuntimeError(
                f"{self.kind}: package is not label-blind"
            )

        if (
            obj.get(
                "experimental_activity_labels_used"
            )
            is not False
        ):
            raise RuntimeError(
                f"{self.kind}: activity labels were reported used"
            )

        if (
            obj.get(
                "embedding_dimension"
            )
            != self.ESMC_DIM
        ):
            raise RuntimeError(
                f"{self.kind}: unexpected embedding dimension"
            )

        embeddings = obj.get(
            "embeddings"
        )

        if not torch.is_tensor(
            embeddings
        ):
            raise RuntimeError(
                f"{self.kind}: missing embedding tensor"
            )

        expected_shape = (
            expected_count,
            self.ESMC_DIM,
        )

        if tuple(
            embeddings.shape
        ) != expected_shape:
            raise RuntimeError(
                f"{self.kind}: embedding shape mismatch: "
                f"{tuple(embeddings.shape)} vs "
                f"{expected_shape}"
            )

        if embeddings.dtype != torch.float32:
            raise RuntimeError(
                f"{self.kind}: expected float32 storage, "
                f"got {embeddings.dtype}"
            )

        if not torch.isfinite(
            embeddings
        ).all():
            raise RuntimeError(
                f"{self.kind}: non-finite embeddings"
            )

        self.embeddings = (
            embeddings
            .detach()
            .contiguous()
        )

        package_hashes = obj.get(
            "sequence_hashes"
        )

        if package_hashes is not None:

            package_hashes = list(
                package_hashes
            )

            if len(
                package_hashes
            ) != expected_count:
                raise RuntimeError(
                    f"{self.kind}: bad package sequence-hash count"
                )

        self._rows: dict[str, int] = {}
        self._lengths: dict[str, int] = {}

        with gzip.open(
            index_path,
            "rt",
            encoding="utf-8",
            newline="",
        ) as f:

            reader = csv.DictReader(
                f,
                delimiter="\t",
            )

            required = {
                "sequence_hash",
                "row_index",
            }

            if (
                reader.fieldnames is None
                or not required.issubset(
                    reader.fieldnames
                )
            ):
                raise RuntimeError(
                    f"{self.kind}: embedding index schema mismatch: "
                    f"{reader.fieldnames}"
                )

            for row in reader:

                sequence_hash = row[
                    "sequence_hash"
                ]

                row_index = int(
                    row[
                        "row_index"
                    ]
                )

                if sequence_hash in self._rows:
                    raise RuntimeError(
                        f"{self.kind}: duplicate sequence hash: "
                        f"{sequence_hash}"
                    )

                if not (
                    0
                    <= row_index
                    < expected_count
                ):
                    raise RuntimeError(
                        f"{self.kind}: invalid row index "
                        f"{row_index}"
                    )

                self._rows[
                    sequence_hash
                ] = row_index

                if (
                    "length"
                    in row
                    and row["length"] not in (
                        None,
                        "",
                    )
                ):
                    self._lengths[
                        sequence_hash
                    ] = int(
                        row["length"]
                    )

                if package_hashes is not None:

                    if (
                        package_hashes[
                            row_index
                        ]
                        != sequence_hash
                    ):
                        raise RuntimeError(
                            f"{self.kind}: package/index "
                            "hash-order mismatch"
                        )

        if len(
            self._rows
        ) != expected_count:
            raise RuntimeError(
                f"{self.kind}: expected "
                f"{expected_count} index rows, "
                f"got {len(self._rows)}"
            )

    def __len__(
        self,
    ) -> int:

        return len(
            self._rows
        )

    def embedding_dim(
        self,
    ) -> int:

        return self.ESMC_DIM

    def contains(
        self,
        sequence_hash: str,
    ) -> bool:

        return (
            sequence_hash
            in self._rows
        )

    def __contains__(
        self,
        sequence_hash: str,
    ) -> bool:

        return self.contains(
            sequence_hash
        )

    def length(
        self,
        sequence_hash: str,
    ) -> int:

        try:
            return self._lengths[
                sequence_hash
            ]

        except KeyError as exc:
            raise KeyError(
                f"{self.kind}: no stored length for "
                f"{sequence_hash}"
            ) from exc

    def get(
        self,
        sequence_hash: str,
    ) -> torch.Tensor:

        try:
            row_index = self._rows[
                sequence_hash
            ]

        except KeyError as exc:
            raise KeyError(
                f"Unknown Bode {self.kind} sequence hash: "
                f"{sequence_hash}"
            ) from exc

        result = self.embeddings[
            row_index
        ]

        if tuple(
            result.shape
        ) != (
            self.ESMC_DIM,
        ):
            raise RuntimeError(
                f"{self.kind}: unexpected single-vector shape"
            )

        return result

    def get_many(
        self,
        sequence_hashes,
    ) -> torch.Tensor:

        hashes = list(
            sequence_hashes
        )

        if not hashes:
            return torch.empty(
                (
                    0,
                    self.ESMC_DIM,
                ),
                dtype=torch.float32,
            )

        rows = []

        for sequence_hash in hashes:

            try:
                rows.append(
                    self._rows[
                        sequence_hash
                    ]
                )

            except KeyError as exc:
                raise KeyError(
                    f"Unknown Bode {self.kind} sequence hash: "
                    f"{sequence_hash}"
                ) from exc

        row_tensor = torch.tensor(
            rows,
            dtype=torch.long,
        )

        result = self.embeddings[
            row_tensor
        ]

        expected_shape = (
            len(hashes),
            self.ESMC_DIM,
        )

        if tuple(
            result.shape
        ) != expected_shape:
            raise RuntimeError(
                f"{self.kind}: batched embedding shape mismatch: "
                f"{tuple(result.shape)} vs "
                f"{expected_shape}"
            )

        if not torch.isfinite(
            result
        ).all():
            raise RuntimeError(
                f"{self.kind}: non-finite batched embeddings"
            )

        return result
