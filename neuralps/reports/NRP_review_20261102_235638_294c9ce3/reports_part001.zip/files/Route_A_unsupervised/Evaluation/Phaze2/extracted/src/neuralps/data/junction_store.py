from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import csv
import gzip


@dataclass(
    frozen=True,
    slots=True,
)
class JunctionRecord:
    transition_uid: str
    split: str
    transition_type: str
    sequence_available: bool
    sequence: str
    length_aa: int
    sequence_sha256: str

    @property
    def is_chain_break(self) -> bool:
        return (
            self.transition_type
            == "inter_protein_chain_break"
        )

    @property
    def is_linker(self) -> bool:
        return (
            self.transition_type
            == "inter_module_linker_candidate"
        )


class JunctionStore:
    """
    Read-only Route-A v1.0 junction lookup.

    Same-chain junctions contain the real amino-acid
    linker sequence.

    Inter-protein boundaries contain no fabricated
    sequence and are represented later by a learned
    CHAIN_BREAK token.
    """

    def __init__(
        self,
        path: str | Path,
    ):
        self.path = Path(path)

        if not self.path.exists():
            raise FileNotFoundError(
                self.path
            )

        self._records = {}

        self._load()

    def _load(self):
        with gzip.open(
            self.path,
            "rt",
            encoding="utf-8",
            newline="",
        ) as f:
            reader = csv.DictReader(
                f,
                delimiter="\t",
            )

            for row in reader:
                uid = row[
                    "transition_uid"
                ]

                if uid in self._records:
                    raise RuntimeError(
                        "Duplicate transition UID: "
                        f"{uid}"
                    )

                transition_type = (
                    row["transition_type"]
                )

                if transition_type not in {
                    "inter_module_linker_candidate",
                    "inter_protein_chain_break",
                }:
                    raise RuntimeError(
                        "Invalid transition type: "
                        f"{transition_type}"
                    )

                sequence_available = (
                    row["sequence_available"]
                    == "True"
                )

                sequence = row["sequence"]
                length = int(
                    row["length_aa"]
                )

                if (
                    transition_type
                    == "inter_module_linker_candidate"
                ):
                    if not sequence_available:
                        raise RuntimeError(
                            "Linker missing sequence: "
                            f"{uid}"
                        )

                    if len(sequence) != length:
                        raise RuntimeError(
                            "Linker sequence length "
                            f"mismatch: {uid}"
                        )

                else:
                    if sequence_available:
                        raise RuntimeError(
                            "Chain break has sequence: "
                            f"{uid}"
                        )

                    if sequence:
                        raise RuntimeError(
                            "Chain break contains "
                            f"residues: {uid}"
                        )

                    if length != 0:
                        raise RuntimeError(
                            "Chain break has nonzero "
                            f"length: {uid}"
                        )

                self._records[
                    uid
                ] = JunctionRecord(
                    transition_uid=uid,
                    split=row["split"],
                    transition_type=(
                        transition_type
                    ),
                    sequence_available=(
                        sequence_available
                    ),
                    sequence=sequence,
                    length_aa=length,
                    sequence_sha256=row[
                        "sequence_sha256"
                    ],
                )

    def __len__(self):
        return len(
            self._records
        )

    def contains(
        self,
        transition_uid: str,
    ) -> bool:
        return (
            transition_uid
            in self._records
        )

    def get(
        self,
        transition_uid: str,
    ) -> JunctionRecord:
        try:
            return self._records[
                transition_uid
            ]
        except KeyError:
            raise KeyError(
                "Unknown transition UID: "
                f"{transition_uid}"
            )
