from __future__ import annotations

from dataclasses import dataclass

import torch

from neuralps.data.structured_module_batch_v1_1 import (
    StructuredModuleBatchV1_1,
)

from neuralps.data.path_routing_batch_v2 import (
    PathRoutingBatchV2,
)

from neuralps.models.routea_v2a import (
    RouteAV2A,
    MODEL_DIM,
    JUNCTION_DIM,
)

from neuralps.models.candidate_assembly_track_v2 import (
    CandidateAssemblyTrackBuilderV2,
)

from neuralps.models.assembly_encoder_v2 import (
    AssemblyEncoderV2,
)

from neuralps.models.assembly_readout_feedback_v2 import (
    AssemblyGlobalPoolV2,
    AssemblyCoherenceScorerV2,
    AssemblyToLocalFeedbackV2,
)


@dataclass(
    frozen=True,
    slots=True,
)
class RouteAV2COutput:
    """
    Route-A V2-C bidirectional output.

    final forward/reverse scores:
        local score after optional assembly->local feedback
        +
        optional whole-assembly coherence score

    Shapes:
        all score tensors [B,K]

        forward_assembly_z:
            [B,K,256]

        reverse_assembly_z:
            [B,K,256]

        z_junction:
            [B,64]

        feedback_gate:
            scalar tensor
    """

    forward_scores: torch.Tensor
    reverse_scores: torch.Tensor

    # Exact V2-A-like scores BEFORE assembly->local feedback.
    forward_pre_feedback_scores: torch.Tensor
    reverse_pre_feedback_scores: torch.Tensor

    # Local scores AFTER optional feedback.
    forward_local_scores: torch.Tensor
    reverse_local_scores: torch.Tensor

    forward_assembly_scores: torch.Tensor
    reverse_assembly_scores: torch.Tensor

    forward_assembly_z: torch.Tensor
    reverse_assembly_z: torch.Tensor

    z_junction: torch.Tensor

    feedback_gate: torch.Tensor

    feedback_enabled: bool
    assembly_score_enabled: bool


    def validate(
        self,
    ) -> None:

        if self.forward_scores.ndim != 2:
            raise RuntimeError(
                "forward_scores must be [B,K]"
            )

        if self.reverse_scores.shape != (
            self.forward_scores.shape
        ):
            raise RuntimeError(
                "reverse score shape mismatch"
            )

        expected_scores = (
            self.forward_scores.shape
        )


        for name in (
            "forward_pre_feedback_scores",
            "reverse_pre_feedback_scores",
            "forward_local_scores",
            "reverse_local_scores",
            "forward_assembly_scores",
            "reverse_assembly_scores",
        ):

            value = getattr(
                self,
                name,
            )

            if value.shape != expected_scores:
                raise RuntimeError(
                    f"{name} shape mismatch"
                )

            if not torch.isfinite(
                value
            ).all():
                raise RuntimeError(
                    f"non-finite {name}"
                )


        B, K = expected_scores


        for name in (
            "forward_assembly_z",
            "reverse_assembly_z",
        ):

            value = getattr(
                self,
                name,
            )

            if value.shape != (
                B,
                K,
                MODEL_DIM,
            ):
                raise RuntimeError(
                    f"{name} shape mismatch"
                )

            if not torch.isfinite(
                value
            ).all():
                raise RuntimeError(
                    f"non-finite {name}"
                )


        if self.z_junction.shape != (
            B,
            JUNCTION_DIM,
        ):
            raise RuntimeError(
                "z_junction shape mismatch"
            )


        if self.feedback_gate.ndim != 0:
            raise RuntimeError(
                "feedback_gate must be scalar"
            )


        if not torch.isfinite(
            self.feedback_gate
        ):
            raise RuntimeError(
                "non-finite feedback gate"
            )


        if not torch.isfinite(
            self.forward_scores
        ).all():
            raise RuntimeError(
                "non-finite forward final scores"
            )


        if not torch.isfinite(
            self.reverse_scores
        ).all():
            raise RuntimeError(
                "non-finite reverse final scores"
            )


class RouteAV2C(
    RouteAV2A
):
    """
    Route-A V2-C.

    Shared V2-A local biology:
        StructuredModuleEncoderV2
        PathAttentionPoolV2
        JunctionEncoder
        EdgeEncoderV2
        LocalInterfaceScorerV2

    Added assembly path:
        natural M/J representations
            ↓
        candidate replacement
        far-side J_MASK
            ↓
        4-layer banded AssemblyEncoderV2
            ↓
        learned global [ASM] readout
            ↓
        whole-assembly coherence score

    C additionally performs:

        z_edge_C =
            z_edge_A
            + g * W(z_assembly)

        g ~= 0.01 initially

    Ablations using IDENTICAL implementation:

        A-like:
            assembly_score_enabled=False
            feedback_enabled=False

        B:
            assembly_score_enabled=True
            feedback_enabled=False

        C:
            assembly_score_enabled=True
            feedback_enabled=True

    No recycling exists in this class.
    """

    def __init__(
        self,
        *,
        attention_radius: int = 4,
        feedback_initial_gate: float = 0.01,
        feedback_enabled: bool = True,
        assembly_score_enabled: bool = True,
        assembly_dropout: float = 0.1,
        **local_kwargs,
    ) -> None:

        super().__init__(
            **local_kwargs
        )


        self.feedback_enabled = bool(
            feedback_enabled
        )

        self.assembly_score_enabled = bool(
            assembly_score_enabled
        )


        # ----------------------------------------------------------
        # Candidate-conditioning primitive.
        # No trainable parameters.
        # ----------------------------------------------------------

        self.assembly_track_builder = (
            CandidateAssemblyTrackBuilderV2()
        )


        # ----------------------------------------------------------
        # Candidate-conditioned banded assembly contextualization.
        # ----------------------------------------------------------

        self.assembly_encoder = (
            AssemblyEncoderV2(
                attention_radius=(
                    attention_radius
                ),

                dropout=(
                    assembly_dropout
                ),
            )
        )


        # ----------------------------------------------------------
        # Global [ASM]-style READOUT after banded contextualization.
        # ----------------------------------------------------------

        self.assembly_pool = (
            AssemblyGlobalPoolV2(
                dropout=(
                    assembly_dropout
                ),
            )
        )


        # ----------------------------------------------------------
        # Shared forward/reverse assembly coherence head.
        # ----------------------------------------------------------

        self.assembly_scorer = (
            AssemblyCoherenceScorerV2()
        )


        # ----------------------------------------------------------
        # V2-C-only assembly -> local seam feedback.
        # ----------------------------------------------------------

        self.assembly_feedback = (
            AssemblyToLocalFeedbackV2(
                initial_gate=(
                    feedback_initial_gate
                )
            )
        )


    def set_ablation_mode(
        self,
        mode: str,
    ) -> None:
        """
        Convenience switch.

        mode="A":
            assembly score OFF
            feedback OFF

        mode="B":
            assembly score ON
            feedback OFF

        mode="C":
            assembly score ON
            feedback ON

        This changes information flow only.
        It does not create/destroy parameters.
        """

        mode = str(
            mode
        ).upper()


        if mode == "A":

            self.assembly_score_enabled = False
            self.feedback_enabled = False


        elif mode == "B":

            self.assembly_score_enabled = True
            self.feedback_enabled = False


        elif mode == "C":

            self.assembly_score_enabled = True
            self.feedback_enabled = True


        else:

            raise ValueError(
                "mode must be A, B, or C"
            )


    def forward(
        self,
        *,
        # ==========================================================
        # Exact V2-A local inputs.
        # ==========================================================

        forward_left_structured: (
            StructuredModuleBatchV1_1
        ),

        forward_left_routing: (
            PathRoutingBatchV2
        ),

        forward_right_structured: (
            StructuredModuleBatchV1_1
        ),

        forward_right_routing: (
            PathRoutingBatchV2
        ),

        reverse_left_structured: (
            StructuredModuleBatchV1_1
        ),

        reverse_left_routing: (
            PathRoutingBatchV2
        ),

        reverse_right_structured: (
            StructuredModuleBatchV1_1
        ),

        reverse_right_routing: (
            PathRoutingBatchV2
        ),

        junction_aa: torch.Tensor,
        junction_mask: torch.Tensor,
        junction_kind: torch.Tensor,
        junction_log_length: torch.Tensor,


        # ==========================================================
        # Compact natural assembly inputs from RouteATrainCollatorV2B.
        # ==========================================================

        assembly_structured: (
            StructuredModuleBatchV1_1
        ),

        assembly_junction_aa: torch.Tensor,
        assembly_junction_mask: torch.Tensor,
        assembly_junction_kind: torch.Tensor,
        assembly_junction_log_length: torch.Tensor,

        assembly_module_offset: torch.Tensor,
        assembly_transition_offset: torch.Tensor,
        assembly_module_count: torch.Tensor,

        assembly_query_transition_index: torch.Tensor,

        assembly_forward_candidate_module_index: torch.Tensor,
        assembly_reverse_candidate_module_index: torch.Tensor,

        assembly_forward_far_mask_transition_index: torch.Tensor,
        assembly_reverse_far_mask_transition_index: torch.Tensor,


        batch_size: int,
        candidate_count: int,
    ) -> RouteAV2COutput:

        if batch_size <= 0:
            raise RuntimeError(
                "batch_size must be positive"
            )


        if candidate_count < 2:
            raise RuntimeError(
                "candidate_count must be >=2"
            )


        # ==========================================================
        # EXACT V2-A MODULE ENCODING.
        # ==========================================================

        fwd_left = self.module_encoder(
            forward_left_structured
        )

        fwd_right = self.module_encoder(
            forward_right_structured
        )

        rev_left = self.module_encoder(
            reverse_left_structured
        )

        rev_right = self.module_encoder(
            reverse_right_structured
        )


        # ==========================================================
        # Natural assembly modules use THE SAME module encoder.
        # ==========================================================

        assembly_modules = self.module_encoder(
            assembly_structured
        )


        if (
            assembly_modules.module_z.ndim
            != 2
            or assembly_modules.module_z.shape[-1]
            != MODEL_DIM
        ):
            raise RuntimeError(
                "Unexpected natural assembly module_z"
            )


        # ==========================================================
        # EXACT V2-A PATH POOLING.
        # ==========================================================

        fwd_left_paths = self.path_pool(
            fwd_left,
            forward_left_routing,
        )

        fwd_right_paths = self.path_pool(
            fwd_right,
            forward_right_routing,
        )

        rev_left_paths = self.path_pool(
            rev_left,
            reverse_left_routing,
        )

        rev_right_paths = self.path_pool(
            rev_right,
            reverse_right_routing,
        )


        # ==========================================================
        # EXACT V2-A INTERFACE-FACING DOMAIN STATES.
        # ==========================================================

        fwd_left_terminal = (
            self._gather_domain_state(
                fwd_left.token_z,

                forward_left_routing
                .terminal_token_index,

                name=(
                    "forward left terminal"
                ),
            )
            .unsqueeze(1)
            .expand(
                -1,
                candidate_count,
                -1,
            )
        )


        fwd_right_initial = (
            self._gather_domain_state(
                fwd_right.token_z,

                forward_right_routing
                .initial_token_index,

                name=(
                    "forward right initial"
                ),
            )
            .reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )


        rev_left_terminal = (
            self._gather_domain_state(
                rev_left.token_z,

                reverse_left_routing
                .terminal_token_index,

                name=(
                    "reverse left terminal"
                ),
            )
            .reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )


        rev_right_initial = (
            self._gather_domain_state(
                rev_right.token_z,

                reverse_right_routing
                .initial_token_index,

                name=(
                    "reverse right initial"
                ),
            )
            .unsqueeze(1)
            .expand(
                -1,
                candidate_count,
                -1,
            )
        )


        # ==========================================================
        # EXACT V2-A QUERY JUNCTION.
        # ==========================================================

        z_junction = self.junction_encoder(
            junction_aa,
            junction_mask,
            junction_kind,
            junction_log_length,
        )


        if z_junction.shape != (
            batch_size,
            JUNCTION_DIM,
        ):
            raise RuntimeError(
                "Unexpected local query junction shape"
            )


        # ==========================================================
        # EXACT V2-A LOCAL EDGE STATES.
        # ==========================================================

        forward_edge_A = self.edge_encoder(
            left_terminal_z=(
                fwd_left_terminal
            ),

            z_junction=(
                z_junction
            ),

            right_initial_z=(
                fwd_right_initial
            ),
        )


        reverse_edge_A = self.edge_encoder(
            left_terminal_z=(
                rev_left_terminal
            ),

            z_junction=(
                z_junction
            ),

            right_initial_z=(
                rev_right_initial
            ),
        )


        expected_edge = (
            batch_size,
            candidate_count,
            MODEL_DIM,
        )


        if forward_edge_A.shape != expected_edge:
            raise RuntimeError(
                "Forward local edge shape drift"
            )


        if reverse_edge_A.shape != expected_edge:
            raise RuntimeError(
                "Reverse local edge shape drift"
            )


        # ==========================================================
        # EXACT PRE-FEEDBACK V2-A-LIKE LOCAL SCORES.
        #
        # These scores use forward_edge_A / reverse_edge_A BEFORE
        # assembly context is allowed to modify the local seam.
        #
        # They provide the protected local SSL branch:
        #
        #   L_A = bidirectional InfoNCE(pre-feedback local)
        #
        # while the normal final scores provide:
        #
        #   L_context = bidirectional InfoNCE(contextual final)
        # ==========================================================

        forward_pre_feedback_scores = (
            self.local_scorer(
                left_module_z=(
                    fwd_left.module_z
                ),

                left_core_z=(
                    fwd_left_paths.core_z
                ),

                left_exit_z=(
                    fwd_left_paths.exit_z
                ),

                z_edge=(
                    forward_edge_A
                ),

                right_entry_z=(
                    fwd_right_paths
                    .entry_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                right_core_z=(
                    fwd_right_paths
                    .core_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                right_module_z=(
                    fwd_right
                    .module_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),
            )
        )


        reverse_pre_feedback_scores = (
            self.local_scorer(
                left_module_z=(
                    rev_left
                    .module_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                left_core_z=(
                    rev_left_paths
                    .core_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                left_exit_z=(
                    rev_left_paths
                    .exit_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                z_edge=(
                    reverse_edge_A
                ),

                right_entry_z=(
                    rev_right_paths.entry_z
                ),

                right_core_z=(
                    rev_right_paths.core_z
                ),

                right_module_z=(
                    rev_right.module_z
                ),
            )
        )


        expected_local_scores = (
            batch_size,
            candidate_count,
        )


        if (
            forward_pre_feedback_scores.shape
            != expected_local_scores
        ):
            raise RuntimeError(
                "Forward pre-feedback score shape drift"
            )


        if (
            reverse_pre_feedback_scores.shape
            != expected_local_scores
        ):
            raise RuntimeError(
                "Reverse pre-feedback score shape drift"
            )


        if not torch.isfinite(
            forward_pre_feedback_scores
        ).all():
            raise RuntimeError(
                "Non-finite forward pre-feedback scores"
            )


        if not torch.isfinite(
            reverse_pre_feedback_scores
        ).all():
            raise RuntimeError(
                "Non-finite reverse pre-feedback scores"
            )


        # ==========================================================
        # NATURAL ASSEMBLY JUNCTION STATES.
        #
        # Same JunctionEncoder semantics as query J.
        # Same inherited 64 -> 256 seam projection.
        # ==========================================================

        assembly_junction_64 = (
            self.junction_encoder(
                assembly_junction_aa,
                assembly_junction_mask,
                assembly_junction_kind,
                assembly_junction_log_length,
            )
        )


        if (
            assembly_junction_64.ndim != 2
            or assembly_junction_64.shape[-1]
            != JUNCTION_DIM
        ):
            raise RuntimeError(
                "Unexpected assembly junction shape"
            )


        assembly_junction_z = (
            self
            .edge_encoder
            .junction_seam_projection(
                assembly_junction_64
            )
        )


        if (
            assembly_junction_z.ndim != 2
            or assembly_junction_z.shape[-1]
            != MODEL_DIM
        ):
            raise RuntimeError(
                "Unexpected projected assembly junction shape"
            )


        # ==========================================================
        # Candidate module states are REUSED from local V2-A branch.
        #
        # No candidate biological re-encoding.
        # ==========================================================

        forward_candidate_module_z = (
            fwd_right
            .module_z
            .reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )


        reverse_candidate_module_z = (
            rev_left
            .module_z
            .reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )


        # ==========================================================
        # Candidate-condition BEFORE any assembly attention.
        # ==========================================================

        forward_track = (
            self
            .assembly_track_builder
            .build(
                base_module_z=(
                    assembly_modules
                    .module_z
                ),

                base_junction_z=(
                    assembly_junction_z
                ),

                module_offset=(
                    assembly_module_offset
                ),

                transition_offset=(
                    assembly_transition_offset
                ),

                module_count=(
                    assembly_module_count
                ),

                query_transition_index=(
                    assembly_query_transition_index
                ),

                candidate_module_index=(
                    assembly_forward_candidate_module_index
                ),

                far_mask_transition_index=(
                    assembly_forward_far_mask_transition_index
                ),

                candidate_module_z=(
                    forward_candidate_module_z
                ),

                j_mask_z=(
                    self
                    .assembly_encoder
                    .j_mask_z
                ),

                direction="forward",
            )
        )


        reverse_track = (
            self
            .assembly_track_builder
            .build(
                base_module_z=(
                    assembly_modules
                    .module_z
                ),

                base_junction_z=(
                    assembly_junction_z
                ),

                module_offset=(
                    assembly_module_offset
                ),

                transition_offset=(
                    assembly_transition_offset
                ),

                module_count=(
                    assembly_module_count
                ),

                query_transition_index=(
                    assembly_query_transition_index
                ),

                candidate_module_index=(
                    assembly_reverse_candidate_module_index
                ),

                far_mask_transition_index=(
                    assembly_reverse_far_mask_transition_index
                ),

                candidate_module_z=(
                    reverse_candidate_module_z
                ),

                j_mask_z=(
                    self
                    .assembly_encoder
                    .j_mask_z
                ),

                direction="reverse",
            )
        )


        # ==========================================================
        # BANDED ASSEMBLY CONTEXTUALIZATION.
        # ==========================================================

        forward_assembly_encoded = (
            self.assembly_encoder(
                forward_track
            )
        )


        reverse_assembly_encoded = (
            self.assembly_encoder(
                reverse_track
            )
        )


        # ==========================================================
        # GLOBAL [ASM]-STYLE READOUT AFTER BANDED CONTEXTUALIZATION.
        # ==========================================================

        forward_assembly_z = (
            self.assembly_pool(
                forward_assembly_encoded
            )
        )


        reverse_assembly_z = (
            self.assembly_pool(
                reverse_assembly_encoded
            )
        )


        expected_assembly = (
            batch_size,
            candidate_count,
            MODEL_DIM,
        )


        if (
            forward_assembly_z.shape
            != expected_assembly
        ):
            raise RuntimeError(
                "Forward global assembly shape drift"
            )


        if (
            reverse_assembly_z.shape
            != expected_assembly
        ):
            raise RuntimeError(
                "Reverse global assembly shape drift"
            )


        # ==========================================================
        # WHOLE-ASSEMBLY COHERENCE SCORES.
        # Shared head in both directions.
        # ==========================================================

        forward_assembly_scores = (
            self.assembly_scorer(
                forward_assembly_z
            )
        )


        reverse_assembly_scores = (
            self.assembly_scorer(
                reverse_assembly_z
            )
        )


        # ==========================================================
        # V2-C FEEDBACK.
        #
        # B:
        #   feedback_enabled=False
        #
        # C:
        #   feedback_enabled=True
        #
        # z_edge_C = z_edge_A + g W(z_assembly)
        # ==========================================================

        forward_edge_C = (
            self.assembly_feedback(
                local_edge_z=(
                    forward_edge_A
                ),

                assembly_z=(
                    forward_assembly_z
                ),

                enabled=(
                    self.feedback_enabled
                ),
            )
        )


        reverse_edge_C = (
            self.assembly_feedback(
                local_edge_z=(
                    reverse_edge_A
                ),

                assembly_z=(
                    reverse_assembly_z
                ),

                enabled=(
                    self.feedback_enabled
                ),
            )
        )


        # ==========================================================
        # EXISTING V2-A LOCAL SCORER — UNCHANGED.
        # Only z_edge may now contain gated assembly feedback.
        # ==========================================================

        forward_local_scores = (
            self.local_scorer(
                left_module_z=(
                    fwd_left.module_z
                ),

                left_core_z=(
                    fwd_left_paths.core_z
                ),

                left_exit_z=(
                    fwd_left_paths.exit_z
                ),

                z_edge=(
                    forward_edge_C
                ),

                right_entry_z=(
                    fwd_right_paths
                    .entry_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                right_core_z=(
                    fwd_right_paths
                    .core_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                right_module_z=(
                    forward_candidate_module_z
                ),
            )
        )


        reverse_local_scores = (
            self.local_scorer(
                left_module_z=(
                    reverse_candidate_module_z
                ),

                left_core_z=(
                    rev_left_paths
                    .core_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                left_exit_z=(
                    rev_left_paths
                    .exit_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                z_edge=(
                    reverse_edge_C
                ),

                right_entry_z=(
                    rev_right_paths.entry_z
                ),

                right_core_z=(
                    rev_right_paths.core_z
                ),

                right_module_z=(
                    rev_right.module_z
                ),
            )
        )


        expected_scores = (
            batch_size,
            candidate_count,
        )


        if (
            forward_local_scores.shape
            != expected_scores
        ):
            raise RuntimeError(
                "Forward C local score shape drift"
            )


        if (
            reverse_local_scores.shape
            != expected_scores
        ):
            raise RuntimeError(
                "Reverse C local score shape drift"
            )


        # ==========================================================
        # FINAL A / B / C SCORE COMPOSITION.
        #
        # A-like:
        #   local only, no feedback
        #
        # B:
        #   local + assembly
        #   no feedback
        #
        # C:
        #   feedback-conditioned local + assembly
        # ==========================================================

        if self.assembly_score_enabled:

            forward_scores = (
                forward_local_scores
                + forward_assembly_scores
            )

            reverse_scores = (
                reverse_local_scores
                + reverse_assembly_scores
            )

        else:

            forward_scores = (
                forward_local_scores
            )

            reverse_scores = (
                reverse_local_scores
            )


        feedback_gate = (
            self
            .assembly_feedback
            .gate_value()
        )


        result = RouteAV2COutput(
            forward_scores=(
                forward_scores
            ),

            reverse_scores=(
                reverse_scores
            ),

            forward_pre_feedback_scores=(
                forward_pre_feedback_scores
            ),

            reverse_pre_feedback_scores=(
                reverse_pre_feedback_scores
            ),

            forward_local_scores=(
                forward_local_scores
            ),

            reverse_local_scores=(
                reverse_local_scores
            ),

            forward_assembly_scores=(
                forward_assembly_scores
            ),

            reverse_assembly_scores=(
                reverse_assembly_scores
            ),

            forward_assembly_z=(
                forward_assembly_z
            ),

            reverse_assembly_z=(
                reverse_assembly_z
            ),

            z_junction=(
                z_junction
            ),

            feedback_gate=(
                feedback_gate
            ),

            feedback_enabled=(
                self.feedback_enabled
            ),

            assembly_score_enabled=(
                self.assembly_score_enabled
            ),
        )


        result.validate()

        return result
