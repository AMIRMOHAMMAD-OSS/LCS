#!/bin/bash
#SBATCH --account=nef@h100
#SBATCH --partition=gpu_p6
#SBATCH --constraint=h100
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=8
#SBATCH --hint=nomultithread
#SBATCH --time=00:30:00
#SBATCH --job-name=bode2_v13_esmc
#SBATCH --output=logs/bode2_v13_esmc_%j.out
#SBATCH --error=logs/bode2_v13_esmc_%j.err

set -euo pipefail

module purge
module load arch/h100
module load pytorch-gpu/py3/2.8.0

cd "$WORK/NeurALPSv2"

source "$WORK/NeurALPSv2/envs/esmc/bin/activate"

export PYTHONPATH="$WORK/NeurALPSv2/src:${PYTHONPATH:-}"

export HF_HOME="$WORK/.cache/huggingface"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=false

mkdir -p logs

echo "================================================================================"
echo "BODE PHASE-2 STRUCTURED V1.3 ESM-C"
echo "================================================================================"
echo "HOST: $(hostname)"
echo "START: $(date)"
echo "SLURM_JOB_ID: ${SLURM_JOB_ID:-NA}"
nvidia-smi --query-gpu=name,memory.total --format=csv,noheader
echo

python -u \
  src/esmc_bode_phase2_structured_v1_3.py

echo
echo "END: $(date)"
echo "================================================================================"
echo "JOB COMPLETE"
echo "================================================================================"
