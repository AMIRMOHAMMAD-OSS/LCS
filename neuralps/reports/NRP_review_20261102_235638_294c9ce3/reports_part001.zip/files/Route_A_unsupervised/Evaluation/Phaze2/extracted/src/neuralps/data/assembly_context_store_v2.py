from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import csv
import gzip


@dataclass(
    frozen=True,
)
class AssemblyLineRecordV2:
    """
    Canonical occurrence-level Route-A assembly line.

    module_uids:
        ordered M1..Mn

    module_sequence_hashes:
        ordered sequence identities for M1..Mn

    transition_uids:
        ordered J1..J(n-1), where Ji connects Mi -> M(i+1)

    transition_types:
        ordered physical transition types matching transition_uids
    """

    assembly_line_id: str
    split: str

    module_uids: tuple[str, ...]
    module_sequence_hashes: tuple[str, ...]

    transition_uids: tuple[str, ...]
    transition_types: tuple[str, ...]

    module_count: int

    def validate(self) -> None:

        if self.module_count < 2:
            raise RuntimeError(
                f"{self.assembly_line_id}: "
                "assembly has fewer than 2 modules"
            )

        if len(self.module_uids) != self.module_count:
            raise RuntimeError(
                f"{self.assembly_line_id}: "
                "module UID count mismatch"
            )

        if (
            len(self.module_sequence_hashes)
            != self.module_count
        ):
            raise RuntimeError(
                f"{self.assembly_line_id}: "
                "module sequence-hash count mismatch"
            )

        expected_transitions = (
            self.module_count - 1
        )

        if (
            len(self.transition_uids)
            != expected_transitions
        ):
            raise RuntimeError(
                f"{self.assembly_line_id}: "
                "transition UID count mismatch"
            )

        if (
            len(self.transition_types)
            != expected_transitions
        ):
            raise RuntimeError(
                f"{self.assembly_line_id}: "
                "transition-type count mismatch"
            )

        if len(set(self.module_uids)) != len(
            self.module_uids
        ):
            # module_uid is occurrence identity in the structured corpus,
            # so duplicates inside one assembly are not expected.
            raise RuntimeError(
                f"{self.assembly_line_id}: "
                "duplicate module_uid"
            )

        if len(set(self.transition_uids)) != len(
            self.transition_uids
        ):
            raise RuntimeError(
                f"{self.assembly_line_id}: "
                "duplicate transition_uid"
            )


class AssemblyContextStoreV2:
    """
    Read-only canonical M-J-M-J Route-A assembly store.

    Ordering comes ONLY from:
      module_occurrences.global_module_index
      interfaces.left/right_global_module_index

    No graph reconstruction or heuristic sorting is used.
    """

    def __init__(
        self,
        *,
        module_occurrences_path: str | Path,
        interfaces_path: str | Path,
        junctions_path: str | Path,
    ) -> None:

        self.module_occurrences_path = Path(
            module_occurrences_path
        )

        self.interfaces_path = Path(
            interfaces_path
        )

        self.junctions_path = Path(
            junctions_path
        )

        modules_by_assembly: dict[
            str,
            dict[int, dict],
        ] = {}

        assembly_split: dict[
            str,
            str,
        ] = {}


        # ==========================================================
        # Ordered module occurrences.
        # ==========================================================

        with gzip.open(
            self.module_occurrences_path,
            "rt",
            encoding="utf-8",
            newline="",
        ) as f:

            reader = csv.DictReader(
                f,
                delimiter="\t",
            )

            required = {
                "assembly_line_id",
                "split",
                "global_module_index",
                "module_count",
                "module_uid",
                "sequence_hash",
            }

            fields = set(
                reader.fieldnames
                or []
            )

            if not required.issubset(
                fields
            ):
                raise RuntimeError(
                    "module_occurrences missing "
                    "required V2-B fields"
                )

            for row in reader:

                assembly_id = row[
                    "assembly_line_id"
                ]

                split = row[
                    "split"
                ]

                index = int(
                    row[
                        "global_module_index"
                    ]
                )

                if index <= 0:
                    raise RuntimeError(
                        f"{assembly_id}: "
                        "global_module_index must be >=1"
                    )

                previous_split = (
                    assembly_split.get(
                        assembly_id
                    )
                )

                if (
                    previous_split is not None
                    and previous_split != split
                ):
                    raise RuntimeError(
                        f"{assembly_id}: split drift "
                        f"{previous_split} vs {split}"
                    )

                assembly_split[
                    assembly_id
                ] = split

                index_map = (
                    modules_by_assembly
                    .setdefault(
                        assembly_id,
                        {},
                    )
                )

                if index in index_map:
                    raise RuntimeError(
                        f"{assembly_id}: "
                        "duplicate global module index "
                        f"{index}"
                    )

                index_map[
                    index
                ] = row


        # ==========================================================
        # Junction identities actually present in junction table.
        # ==========================================================

        junction_by_uid = {}

        with gzip.open(
            self.junctions_path,
            "rt",
            encoding="utf-8",
            newline="",
        ) as f:

            reader = csv.DictReader(
                f,
                delimiter="\t",
            )

            required = {
                "transition_uid",
                "assembly_line_id",
                "split",
                "transition_type",
            }

            fields = set(
                reader.fieldnames
                or []
            )

            if not required.issubset(
                fields
            ):
                raise RuntimeError(
                    "junctions missing required "
                    "V2-B fields"
                )

            for row in reader:

                uid = row[
                    "transition_uid"
                ]

                if uid in junction_by_uid:
                    raise RuntimeError(
                        "Duplicate transition_uid "
                        f"in junction table: {uid}"
                    )

                junction_by_uid[
                    uid
                ] = row


        # ==========================================================
        # Ordered physical interfaces.
        # ==========================================================

        transitions_by_assembly: dict[
            str,
            dict[int, dict],
        ] = {}

        with gzip.open(
            self.interfaces_path,
            "rt",
            encoding="utf-8",
            newline="",
        ) as f:

            reader = csv.DictReader(
                f,
                delimiter="\t",
            )

            required = {
                "interface_id",
                "transition_uid",
                "assembly_line_id",
                "split",
                "left_global_module_index",
                "right_global_module_index",
                "left_module_uid",
                "right_module_uid",
                "transition_type",
                "module_count",
            }

            fields = set(
                reader.fieldnames
                or []
            )

            if not required.issubset(
                fields
            ):
                raise RuntimeError(
                    "interfaces missing required "
                    "V2-B fields"
                )

            for row in reader:

                assembly_id = row[
                    "assembly_line_id"
                ]

                left_index = int(
                    row[
                        "left_global_module_index"
                    ]
                )

                right_index = int(
                    row[
                        "right_global_module_index"
                    ]
                )

                if (
                    right_index
                    != left_index + 1
                ):
                    raise RuntimeError(
                        f"{assembly_id}: "
                        "non-adjacent interface "
                        f"{left_index}->{right_index}"
                    )

                if assembly_id not in (
                    modules_by_assembly
                ):
                    raise RuntimeError(
                        f"{assembly_id}: interface "
                        "assembly missing from modules"
                    )

                module_map = (
                    modules_by_assembly[
                        assembly_id
                    ]
                )

                if left_index not in module_map:
                    raise RuntimeError(
                        f"{assembly_id}: "
                        "left module index missing"
                    )

                if right_index not in module_map:
                    raise RuntimeError(
                        f"{assembly_id}: "
                        "right module index missing"
                    )

                if (
                    module_map[
                        left_index
                    ][
                        "module_uid"
                    ]
                    != row[
                        "left_module_uid"
                    ]
                ):
                    raise RuntimeError(
                        f"{assembly_id}: "
                        "left UID/index disagreement"
                    )

                if (
                    module_map[
                        right_index
                    ][
                        "module_uid"
                    ]
                    != row[
                        "right_module_uid"
                    ]
                ):
                    raise RuntimeError(
                        f"{assembly_id}: "
                        "right UID/index disagreement"
                    )

                transition_uid = row[
                    "transition_uid"
                ]

                if transition_uid not in (
                    junction_by_uid
                ):
                    raise RuntimeError(
                        f"{transition_uid}: "
                        "missing junction record"
                    )

                junction_row = (
                    junction_by_uid[
                        transition_uid
                    ]
                )

                if (
                    junction_row[
                        "assembly_line_id"
                    ]
                    != assembly_id
                ):
                    raise RuntimeError(
                        f"{transition_uid}: "
                        "junction assembly mismatch"
                    )

                if (
                    junction_row[
                        "transition_type"
                    ]
                    != row[
                        "transition_type"
                    ]
                ):
                    raise RuntimeError(
                        f"{transition_uid}: "
                        "transition-type mismatch"
                    )

                index_map = (
                    transitions_by_assembly
                    .setdefault(
                        assembly_id,
                        {},
                    )
                )

                if left_index in index_map:
                    raise RuntimeError(
                        f"{assembly_id}: "
                        "duplicate outgoing transition "
                        f"from module {left_index}"
                    )

                index_map[
                    left_index
                ] = row


        # ==========================================================
        # Freeze canonical records.
        # ==========================================================

        records = {}

        split_counts = {}

        max_module_count = 0

        chain_break_lines = 0

        for (
            assembly_id,
            module_map,
        ) in modules_by_assembly.items():

            split = assembly_split[
                assembly_id
            ]

            indices = sorted(
                module_map
            )

            expected_indices = list(
                range(
                    1,
                    len(indices) + 1,
                )
            )

            if indices != expected_indices:
                raise RuntimeError(
                    f"{assembly_id}: "
                    "non-contiguous module indices "
                    f"{indices}"
                )

            declared_counts = {
                int(
                    module_map[i][
                        "module_count"
                    ]
                )
                for i in indices
            }

            if len(
                declared_counts
            ) != 1:
                raise RuntimeError(
                    f"{assembly_id}: "
                    "module_count drift"
                )

            module_count = next(
                iter(
                    declared_counts
                )
            )

            if module_count != len(
                indices
            ):
                raise RuntimeError(
                    f"{assembly_id}: "
                    "declared module_count mismatch"
                )

            transition_map = (
                transitions_by_assembly.get(
                    assembly_id,
                    {},
                )
            )

            expected_transition_indices = list(
                range(
                    1,
                    module_count,
                )
            )

            if (
                sorted(
                    transition_map
                )
                != expected_transition_indices
            ):
                raise RuntimeError(
                    f"{assembly_id}: "
                    "transition index coverage drift"
                )

            module_uids = tuple(
                module_map[i][
                    "module_uid"
                ]
                for i in indices
            )

            module_hashes = tuple(
                module_map[i][
                    "sequence_hash"
                ]
                for i in indices
            )

            transition_uids = tuple(
                transition_map[i][
                    "transition_uid"
                ]
                for i in (
                    expected_transition_indices
                )
            )

            transition_types = tuple(
                transition_map[i][
                    "transition_type"
                ]
                for i in (
                    expected_transition_indices
                )
            )

            record = (
                AssemblyLineRecordV2(
                    assembly_line_id=(
                        assembly_id
                    ),

                    split=(
                        split
                    ),

                    module_uids=(
                        module_uids
                    ),

                    module_sequence_hashes=(
                        module_hashes
                    ),

                    transition_uids=(
                        transition_uids
                    ),

                    transition_types=(
                        transition_types
                    ),

                    module_count=(
                        module_count
                    ),
                )
            )

            record.validate()

            records[
                assembly_id
            ] = record

            split_counts[
                split
            ] = (
                split_counts.get(
                    split,
                    0,
                )
                + 1
            )

            max_module_count = max(
                max_module_count,
                module_count,
            )

            if (
                "inter_protein_chain_break"
                in transition_types
            ):
                chain_break_lines += 1


        if set(
            transitions_by_assembly
        ) != set(
            modules_by_assembly
        ):
            missing = (
                set(
                    transitions_by_assembly
                )
                ^ set(
                    modules_by_assembly
                )
            )

            raise RuntimeError(
                "Assembly membership mismatch "
                f"between modules/interfaces: "
                f"{len(missing)}"
            )


        self._records = records

        self.split_counts = dict(
            sorted(
                split_counts.items()
            )
        )

        self.max_module_count = (
            max_module_count
        )

        self.chain_break_lines = (
            chain_break_lines
        )


    def __len__(
        self,
    ) -> int:

        return len(
            self._records
        )


    def __contains__(
        self,
        assembly_line_id: str,
    ) -> bool:

        return (
            assembly_line_id
            in self._records
        )


    def get(
        self,
        assembly_line_id: str,
    ) -> AssemblyLineRecordV2:

        try:
            return self._records[
                assembly_line_id
            ]

        except KeyError as exc:
            raise KeyError(
                "Unknown assembly_line_id: "
                f"{assembly_line_id}"
            ) from exc
