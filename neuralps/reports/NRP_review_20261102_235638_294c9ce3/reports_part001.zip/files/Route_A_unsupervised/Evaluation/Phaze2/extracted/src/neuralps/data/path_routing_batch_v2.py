from __future__ import annotations

from dataclasses import dataclass

import torch

from neuralps.data.structured_module_batch_v1_1 import (
    DOMAIN_KIND,
    StructuredModuleBatchV1_1,
)

from neuralps.data.structured_path_store_v2 import (
    StructuredPathStoreV2,
)


@dataclass(
    frozen=True,
    slots=True,
)
class PathRoutingBatchV2:
    """
    V2 masks and gather indices over an existing V1.1 D/B batch.

    True in entry/core/exit masks means:
        biological token belongs to that routed span.

    -1 in A/carrier index means unavailable.
    """

    entry_mask: torch.Tensor
    core_mask: torch.Tensor
    exit_mask: torch.Tensor

    entry_available: torch.Tensor
    core_available: torch.Tensor
    exit_available: torch.Tensor

    initial_token_index: torch.Tensor
    terminal_token_index: torch.Tensor

    a_token_index: torch.Tensor
    carrier_token_index: torch.Tensor

    module_uids: tuple[str, ...]

    def validate_against(
        self,
        structured: StructuredModuleBatchV1_1,
    ) -> None:

        batch_size = len(
            self.module_uids
        )

        if tuple(
            structured.module_uids
        ) != self.module_uids:
            raise RuntimeError(
                "V2 routing/V1.1 module UID mismatch"
            )

        token_width = (
            structured.token_esmc.shape[1]
        )

        expected_2d = (
            batch_size,
            token_width,
        )

        for name, tensor in (
            (
                "entry_mask",
                self.entry_mask,
            ),
            (
                "core_mask",
                self.core_mask,
            ),
            (
                "exit_mask",
                self.exit_mask,
            ),
        ):

            if tensor.shape != expected_2d:
                raise RuntimeError(
                    f"{name} shape mismatch"
                )

            if tensor.dtype != torch.bool:
                raise RuntimeError(
                    f"{name} must be bool"
                )

            # A routed biological span may never select padding.
            if torch.any(
                tensor
                & structured.token_padding_mask
            ):
                raise RuntimeError(
                    f"{name} selects padding"
                )

        expected_1d = (
            batch_size,
        )

        for name, tensor in (
            (
                "entry_available",
                self.entry_available,
            ),
            (
                "core_available",
                self.core_available,
            ),
            (
                "exit_available",
                self.exit_available,
            ),
        ):

            if tensor.shape != expected_1d:
                raise RuntimeError(
                    f"{name} shape mismatch"
                )

            if tensor.dtype != torch.bool:
                raise RuntimeError(
                    f"{name} must be bool"
                )

        for name, tensor in (
            (
                "initial_token_index",
                self.initial_token_index,
            ),
            (
                "terminal_token_index",
                self.terminal_token_index,
            ),
            (
                "a_token_index",
                self.a_token_index,
            ),
            (
                "carrier_token_index",
                self.carrier_token_index,
            ),
        ):

            if tensor.shape != expected_1d:
                raise RuntimeError(
                    f"{name} shape mismatch"
                )

            if tensor.dtype != torch.long:
                raise RuntimeError(
                    f"{name} must be long"
                )

        # Availability must exactly match nonempty masks.
        if not torch.equal(
            self.entry_available,
            self.entry_mask.any(
                dim=1
            ),
        ):
            raise RuntimeError(
                "entry availability/mask mismatch"
            )

        if not torch.equal(
            self.core_available,
            self.core_mask.any(
                dim=1
            ),
        ):
            raise RuntimeError(
                "core availability/mask mismatch"
            )

        if not torch.equal(
            self.exit_available,
            self.exit_mask.any(
                dim=1
            ),
        ):
            raise RuntimeError(
                "exit availability/mask mismatch"
            )

        # Universal initial/terminal indices must point to domains.
        row_index = torch.arange(
            batch_size,
            dtype=torch.long,
            device=(
                structured.token_kind.device
            ),
        )

        if not torch.all(
            structured.token_kind[
                row_index,
                self.initial_token_index,
            ]
            == DOMAIN_KIND
        ):
            raise RuntimeError(
                "Initial token does not point to domain"
            )

        if not torch.all(
            structured.token_kind[
                row_index,
                self.terminal_token_index,
            ]
            == DOMAIN_KIND
        ):
            raise RuntimeError(
                "Terminal token does not point to domain"
            )

        # Available A/carrier indices must also point to domains.
        a_rows = (
            self.a_token_index
            >= 0
        )

        if torch.any(a_rows):

            rows = row_index[
                a_rows
            ]

            cols = self.a_token_index[
                a_rows
            ]

            if not torch.all(
                structured.token_kind[
                    rows,
                    cols,
                ]
                == DOMAIN_KIND
            ):
                raise RuntimeError(
                    "A index does not point to domain"
                )

        carrier_rows = (
            self.carrier_token_index
            >= 0
        )

        if torch.any(
            carrier_rows
        ):

            rows = row_index[
                carrier_rows
            ]

            cols = (
                self.carrier_token_index[
                    carrier_rows
                ]
            )

            if not torch.all(
                structured.token_kind[
                    rows,
                    cols,
                ]
                == DOMAIN_KIND
            ):
                raise RuntimeError(
                    "Carrier index does not point to domain"
                )


class PathRoutingBatchBuilderV2:
    """
    Build V2 routing masks over an already-built frozen V1.1
    StructuredModuleBatchV1_1.

    No embeddings are duplicated or recomputed.
    """

    def __init__(
        self,
        *,
        path_store: StructuredPathStoreV2,
    ) -> None:

        self.path_store = (
            path_store
        )

    def build(
        self,
        structured: StructuredModuleBatchV1_1,
    ) -> PathRoutingBatchV2:

        structured.validate_fast()

        module_uids = tuple(
            structured.module_uids
        )

        batch_size = len(
            module_uids
        )

        token_width = (
            structured.token_esmc.shape[1]
        )

        entry_mask = torch.zeros(
            (
                batch_size,
                token_width,
            ),
            dtype=torch.bool,
        )

        core_mask = torch.zeros_like(
            entry_mask
        )

        exit_mask = torch.zeros_like(
            entry_mask
        )

        entry_available = torch.zeros(
            batch_size,
            dtype=torch.bool,
        )

        core_available = torch.zeros(
            batch_size,
            dtype=torch.bool,
        )

        exit_available = torch.zeros(
            batch_size,
            dtype=torch.bool,
        )

        initial_token_index = torch.zeros(
            batch_size,
            dtype=torch.long,
        )

        terminal_token_index = torch.zeros(
            batch_size,
            dtype=torch.long,
        )

        a_token_index = torch.full(
            (
                batch_size,
            ),
            -1,
            dtype=torch.long,
        )

        carrier_token_index = torch.full(
            (
                batch_size,
            ),
            -1,
            dtype=torch.long,
        )

        for i, uid in enumerate(
            module_uids
        ):

            record = (
                self.path_store.get(
                    uid
                )
            )

            observed_count = int(
                structured.token_count[
                    i
                ].item()
            )

            if (
                observed_count
                != record.biological_token_count
            ):
                raise RuntimeError(
                    f"{uid}: V1.1/V2 token-count mismatch "
                    f"{observed_count} vs "
                    f"{record.biological_token_count}"
                )

            if (
                record.terminal_token_index
                >= observed_count
            ):
                raise RuntimeError(
                    f"{uid}: terminal index outside "
                    "biological token range"
                )

            initial_token_index[
                i
            ] = (
                record.initial_token_index
            )

            terminal_token_index[
                i
            ] = (
                record.terminal_token_index
            )

            if (
                record.a_token_index
                is not None
            ):

                a_token_index[
                    i
                ] = (
                    record.a_token_index
                )

            if (
                record.carrier_token_index
                is not None
            ):

                carrier_token_index[
                    i
                ] = (
                    record.carrier_token_index
                )

            for (
                span,
                mask,
                available,
            ) in (
                (
                    record.entry_span,
                    entry_mask,
                    entry_available,
                ),
                (
                    record.core_span,
                    core_mask,
                    core_available,
                ),
                (
                    record.exit_span,
                    exit_mask,
                    exit_available,
                ),
            ):

                if span is None:
                    continue

                start, end = span

                if not (
                    0
                    <= start
                    < end
                    <= observed_count
                ):
                    raise RuntimeError(
                        f"{uid}: invalid V2 routing "
                        f"span {span}"
                    )

                mask[
                    i,
                    start:end,
                ] = True

                available[
                    i
                ] = True

        result = PathRoutingBatchV2(
            entry_mask=entry_mask,
            core_mask=core_mask,
            exit_mask=exit_mask,
            entry_available=(
                entry_available
            ),
            core_available=(
                core_available
            ),
            exit_available=(
                exit_available
            ),
            initial_token_index=(
                initial_token_index
            ),
            terminal_token_index=(
                terminal_token_index
            ),
            a_token_index=(
                a_token_index
            ),
            carrier_token_index=(
                carrier_token_index
            ),
            module_uids=(
                module_uids
            ),
        )

        result.validate_against(
            structured
        )

        return result
