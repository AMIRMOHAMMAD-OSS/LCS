#!/usr/bin/env python3

from pathlib import Path
import re
import shutil


ROOT = Path.cwd()

SRC_A = (
    ROOT
    / "scripts"
    / "evaluate_bode_v2a_epoch22_meeting.py"
)

SRC_C = (
    ROOT
    / "scripts"
    / "evaluate_bode_v2c_epoch30.py"
)

SRC_D = (
    ROOT
    / "scripts"
    / "evaluate_bode_v2d_epoch30.py"
)


DST_A = (
    ROOT
    / "scripts"
    / "evaluate_bode_phase2_v2a_epoch30.py"
)

DST_C = (
    ROOT
    / "scripts"
    / "evaluate_bode_phase2_v2c_epoch30.py"
)

DST_D = (
    ROOT
    / "scripts"
    / "evaluate_bode_phase2_v2d_epoch30.py"
)


for p in (
    SRC_A,
    SRC_C,
    SRC_D,
):

    if not p.is_file():
        raise FileNotFoundError(p)


def replace_assignment(
    text,
    name,
    body,
):

    pattern = (
        rf"^{re.escape(name)} = \(\n"
        rf".*?"
        rf"^\)\n"
    )


    replacement = (
        f"{name} = (\n"
        f"{body}"
        f")\n"
    )


    out, n = re.subn(
        pattern,
        replacement,
        text,
        count=1,
        flags=(
            re.MULTILINE
            |
            re.DOTALL
        ),
    )


    if n != 1:

        raise RuntimeError(
            f"Could not replace assignment: {name}"
        )


    return out


def replace_required(
    text,
    old,
    new,
    label,
):

    if old not in text:

        raise RuntimeError(
            f"Required pattern absent: {label}"
        )


    return text.replace(
        old,
        new,
    )


# ======================================================================
# V2-A
# ======================================================================

a = SRC_A.read_text()


a = replace_assignment(
    a,
    "INTERFACES",
    '''    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "evaluation_v1_3"
    / "interfaces.tsv.gz"
''',
)


a = replace_assignment(
    a,
    "STRUCTURED",
    '''    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "structured_v1_3"
''',
)


a = replace_assignment(
    a,
    "BODE_EMBED",
    '''    ROOT
    / "results"
    / "bode_phase2_esmc600m_structured_v1_3"
''',
)


a = replace_assignment(
    a,
    "BOUNDARY_EMBED",
    '''    ROOT
    / "results"
    / "bode_phase2_esmc600m_structured_v1_3"
    / "boundaries"
''',
)


a = replace_assignment(
    a,
    "ACTIVITY",
    '''    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "evaluation_v1_3"
    / "experimental_construct_activity.tsv.gz"
''',
)


a = replace_assignment(
    a,
    "CHECKPOINT",
    '''    ROOT
    / "results"
    / "training"
    / "routeA_v2a"
    / "A0_seed20260813"
    / "checkpoints"
    / "epoch_0030.pt"
''',
)


a = replace_assignment(
    a,
    "OUT",
    '''    ROOT
    / "results"
    / "analysis"
    / "bode_phase2_v1_3"
    / "v2a_epoch30"
''',
)


# Phase-1 cardinalities -> Phase-2.
a = a.replace(
    "!= 1368",
    "!= 424",
)

a = a.replace(
    "== 1368",
    "== 424",
)

a = a.replace(
    "!= 1692",
    "!= 530",
)

a = a.replace(
    "== 1692",
    "== 530",
)

a = a.replace(
    "Expected exactly 1368 Bode interfaces",
    "Expected exactly 424 Phase-2 Bode interfaces",
)

a = a.replace(
    "Expected 1692 Bode module UIDs",
    "Expected 530 Phase-2 Bode module UIDs",
)

a = a.replace(
    "Expected 324 activity labels",
    "Expected 106 Phase-2 activity labels",
)

a = a.replace(
    "len(labels) != 324",
    "len(labels) != 106",
)

a = a.replace(
    "len(labels) == 324",
    "len(labels) == 106",
)


# Frozen checkpoint is genuinely epoch 30.
a = re.sub(
    r'"epoch"\s*:\s*(?:15|22),',
    '"epoch": 30,',
    a,
)


# Exact Phase-2 label balance.
pattern = (
    r"if label_counts != \{"
    r".*?"
    r"\}:"
)

replacement = '''if label_counts != {
    0: 42,
    1: 64,
}:'''


a, n = re.subn(
    pattern,
    replacement,
    a,
    count=1,
    flags=re.DOTALL,
)


if n != 1:

    raise RuntimeError(
        "Could not patch V2-A label-count contract"
    )


# Rename historical artifact filenames.
a = a.replace(
    "bode_v2a_epoch22_",
    "phase2_v2a_epoch30_",
)

a = a.replace(
    "BODE V2-A EPOCH-15 EVALUATION",
    "BODE PHASE-2 V2-A EPOCH-30 EVALUATION",
)

a = a.replace(
    "BODE V2-A EPOCH-22",
    "BODE PHASE-2 V2-A EPOCH-30",
)


DST_A.write_text(a)


# ======================================================================
# V2-C / V2-D COMMON PATCH
# ======================================================================

def patch_cd(
    src,
    dst,
    model_name,
):

    s = src.read_text()


    s = replace_assignment(
        s,
        "BODE_INTERFACES",
        '''    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "evaluation_v1_3"
    / "interfaces.tsv.gz"
''',
    )


    s = replace_assignment(
        s,
        "BODE_STRUCTURED",
        '''    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "structured_v1_3"
''',
    )


    s = replace_assignment(
        s,
        "BODE_EMBED",
        '''    ROOT
    / "results"
    / "bode_phase2_esmc600m_structured_v1_3"
''',
    )


    s = replace_assignment(
        s,
        "BODE_BOUNDARY",
        '''    ROOT
    / "results"
    / "bode_phase2_esmc600m_structured_v1_3"
    / "boundaries"
''',
    )


    s = replace_assignment(
        s,
        "BODE_CONTEXT",
        '''    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "assembly_context_v1_3"
''',
    )


    s = replace_assignment(
        s,
        "LABEL_ATLAS",
        '''    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "evaluation_v1_3"
    / "construct_atlas.tsv"
''',
    )


    out_name = (
        "v2c_epoch30"
        if model_name == "V2-C"
        else
        "v2d_epoch30"
    )


    s = replace_assignment(
        s,
        "OUT",
        f'''    ROOT
    / "results"
    / "analysis"
    / "bode_phase2_v1_3"
    / "{out_name}"
''',
    )


    # --------------------------------------------------------------
    # Normalize evaluator to epoch 30 only.
    # --------------------------------------------------------------

    epoch_pattern = (
        r"summary_rows = \[\]\s*"
        r"for epoch in "
        r"(?:range\([\s\S]*?\)|\([\s\S]*?\)):"
    )


    epoch_replacement = '''summary_rows = []


for epoch in (
    30,
):'''


    s, n = re.subn(
        epoch_pattern,
        epoch_replacement,
        s,
        count=1,
    )


    if n != 1:

        raise RuntimeError(
            f"{model_name}: could not normalize epoch loop"
        )


    # --------------------------------------------------------------
    # Phase-1 cardinalities -> Phase-2.
    # --------------------------------------------------------------

    s = s.replace(
        "assert len(interfaces) == 1368",
        "assert len(interfaces) == 424",
    )

    s = s.replace(
        "assert len(items_all) == 1368",
        "assert len(items_all) == 424",
    )

    s = s.replace(
        "assert len(module_pool) == 1692",
        "assert len(module_pool) == 530",
    )

    s = s.replace(
        "assert len(labels) == 324",
        "assert len(labels) == 106",
    )


    # Catch alternate explicit comparisons too.
    s = s.replace(
        "!= 1368",
        "!= 424",
    )

    s = s.replace(
        "== 1368",
        "== 424",
    )

    s = s.replace(
        "!= 1692",
        "!= 530",
    )

    s = s.replace(
        "== 1692",
        "== 530",
    )


    # --------------------------------------------------------------
    # CRITICAL: never restore the historical truncated V2-D loop.
    # --------------------------------------------------------------

    if (
        "min(len(items_all), 32)"
        in s
        or
        "min(len(items_all), 64)"
        in s
    ):

        raise RuntimeError(
            f"{model_name}: truncated inference loop detected"
        )


    # Output naming cleanup.
    if model_name == "V2-C":

        s = s.replace(
            "v2c_epochs01_05_activity_summary.tsv",
            "phase2_v2c_epoch30_activity_summary.tsv",
        )

    else:

        s = s.replace(
            "v2d_epoch30_activity_summary.tsv",
            "phase2_v2d_epoch30_activity_summary.tsv",
        )


    dst.write_text(s)


patch_cd(
    SRC_C,
    DST_C,
    "V2-C",
)

patch_cd(
    SRC_D,
    DST_D,
    "V2-D",
)


# ======================================================================
# STATIC SAFETY AUDIT
# ======================================================================

for p in (
    DST_A,
    DST_C,
    DST_D,
):

    text = p.read_text()


    forbidden = [
        'bode_inference_v1_0',
        'bode_structured_v1_1_exploratory',
        'bode_v2c_context_e22',
        'construct_atlas_e22.tsv',
        'bode_esmc600m_embeddings_v1_1',
        'min(len(items_all), 32)',
    ]


    bad = [
        x
        for x in forbidden
        if x in text
    ]


    if bad:

        raise RuntimeError(
            f"{p.name}: stale Phase-1 references remain: {bad}"
        )


print("CREATED:")
print(DST_A)
print(DST_C)
print(DST_D)
print()
print("PHASE-2 EVALUATOR GENERATION: PASS")
