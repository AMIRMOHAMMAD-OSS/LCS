#!/usr/bin/env python3

from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
import gzip
import hashlib
import json
import shutil

import pandas as pd
from Bio import SeqIO


# ======================================================================
# PATHS
# ======================================================================

ROOT = Path.cwd()

STRUCTURED = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "structured_v1_3"
)

MODULES = (
    STRUCTURED
    / "structured_modules.tsv.gz"
)

DOMAINS = (
    STRUCTURED
    / "structured_domains.tsv.gz"
)

SCARS = (
    STRUCTURED
    / "scar_boundary_map.tsv.gz"
)

GB = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "genbank_raw"
    / "106 NRPS sequences.gb"
)

OUT = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "assembly_context_v1_3"
)

TMP = (
    OUT.parent
    / ".assembly_context_v1_3.tmp"
)


# ======================================================================
# FROZEN CONTRACT
# ======================================================================

SPLIT = "external_bode_phase2"

EXPECTED_CONSTRUCTS = 106
EXPECTED_MODULES = 530
EXPECTED_TRANSITIONS = 424

EXPECTED_LINKERS = 347
EXPECTED_CHAIN_BREAKS = 77

EXPECTED_PAIR_BREAKS = {
    (1, 2): 2,
    (2, 3): 73,
    (3, 4): 2,
    (4, 5): 0,
}

EMPTY_SEQUENCE_HASH = hashlib.sha256(
    b""
).hexdigest()


# ======================================================================
# HELPERS
# ======================================================================

def construct_name(
    rec,
):

    name = str(
        rec.name
    )

    if "_(" in name:

        return name.split(
            "_(",
            1,
        )[0]

    return name


def sha256_sequence(
    seq,
):

    return hashlib.sha256(
        str(seq).encode(
            "ascii"
        )
    ).hexdigest()


def write_tsv_gz(
    path,
    rows,
    fields,
):

    df = pd.DataFrame(
        rows,
        columns=fields,
    )

    df.to_csv(
        path,
        sep="\t",
        index=False,
        compression="gzip",
    )


# ======================================================================
# TRANSACTION START
# ======================================================================

if TMP.exists():

    shutil.rmtree(
        TMP
    )


TMP.mkdir(
    parents=True,
    exist_ok=False,
)


print(
    "=" * 110
)

print(
    "BODE PHASE-2 ASSEMBLY CONTEXT V1.3"
)

print(
    "=" * 110
)

print(
    "Experimental activity/product labels are NOT read."
)

print(
    "Split-intein scars are already frozen as B tokens."
)

print(
    "J classification is based on physical transition geometry."
)


# ======================================================================
# LOAD
# ======================================================================

modules = pd.read_csv(
    MODULES,
    sep="\t",
)

domains = pd.read_csv(
    DOMAINS,
    sep="\t",
)

scars = pd.read_csv(
    SCARS,
    sep="\t",
)


records = list(
    SeqIO.parse(
        str(
            GB
        ),
        "genbank",
    )
)


record_by_construct = {
    construct_name(
        rec
    ):
        rec

    for rec in records
}


if len(
    record_by_construct
) != EXPECTED_CONSTRUCTS:

    raise RuntimeError(
        "GenBank construct count mismatch"
    )


if len(
    modules
) != EXPECTED_MODULES:

    raise RuntimeError(
        "Structured module count mismatch"
    )


if len(
    domains
) != 1854:

    raise RuntimeError(
        "Structured domain count mismatch"
    )


if len(
    scars
) != 212:

    raise RuntimeError(
        "Scar count mismatch"
    )


# ======================================================================
# MODULE / DOMAIN CONTRACT
# ======================================================================

modules_by_construct = defaultdict(
    list
)


for row in modules.to_dict(
    "records"
):

    modules_by_construct[
        str(
            row[
                "construct_id"
            ]
        )
    ].append(
        row
    )


if len(
    modules_by_construct
) != EXPECTED_CONSTRUCTS:

    raise RuntimeError(
        "Module construct count mismatch"
    )


domains_by_module = {}


for module_uid, group in domains.groupby(
    "module_uid",
    sort=False,
):

    group = group.sort_values(
        "component_order"
    )


    orders = (
        group[
            "component_order"
        ]
        .astype(
            int
        )
        .tolist()
    )


    if orders != list(
        range(
            1,
            len(
                group
            )
            +
            1,
        )
    ):

        raise RuntimeError(
            f"{module_uid}: "
            "component-order drift"
        )


    domains_by_module[
        str(
            module_uid
        )
    ] = {
        "first":
            group.iloc[
                0
            ],

        "last":
            group.iloc[
                -1
            ],
    }


if len(
    domains_by_module
) != EXPECTED_MODULES:

    raise RuntimeError(
        "Domain/module mapping mismatch"
    )


# ======================================================================
# SCAR INTERVALS
#
# Critical negative check:
# no J interval may contain an engineered split-intein scar.
# ======================================================================

scar_intervals = defaultdict(
    list
)


for row in scars.to_dict(
    "records"
):

    scar_intervals[
        str(
            row[
                "construct_id"
            ]
        )
    ].append(
        {
            "scar_name":
                str(
                    row[
                        "scar_name"
                    ]
                ),

            "start":
                int(
                    row[
                        "construct_nt_start"
                    ]
                ),

            "end":
                int(
                    row[
                        "construct_nt_end"
                    ]
                ),
        }
    )


if sum(
    len(
        x
    )
    for x in scar_intervals.values()
) != 212:

    raise RuntimeError(
        "Scar interval contract mismatch"
    )


# ======================================================================
# OUTPUT ROWS
# ======================================================================

module_occurrence_rows = []

interface_rows = []

junction_rows = []

geometry_rows = []

assembly_rows = []


transition_type_counts = Counter()

break_pair_counts = Counter()

linker_pair_counts = Counter()

unique_linker_sequences = {}

protein_count_distribution = Counter()


# ======================================================================
# BUILD 106 ASSEMBLIES
# ======================================================================

for construct_id in sorted(
    modules_by_construct
):

    if construct_id not in (
        record_by_construct
    ):

        raise RuntimeError(
            f"{construct_id}: "
            "missing GenBank record"
        )


    rec = record_by_construct[
        construct_id
    ]


    ms = sorted(
        modules_by_construct[
            construct_id
        ],
        key=lambda x:
            int(
                x[
                    "module_index"
                ]
            ),
    )


    if len(
        ms
    ) != 5:

        raise RuntimeError(
            f"{construct_id}: "
            f"expected 5 modules, "
            f"got {len(ms)}"
        )


    observed_indices = [
        int(
            x[
                "module_index"
            ]
        )
        for x in ms
    ]


    if observed_indices != [
        1,
        2,
        3,
        4,
        5,
    ]:

        raise RuntimeError(
            f"{construct_id}: "
            f"module ordering drift "
            f"{observed_indices}"
        )


    assembly_line_id = (
        f"{construct_id}"
        f"|assembly_line=1"
    )


    # ----------------------------------------------------------
    # First classify all 4 transitions.
    # ----------------------------------------------------------

    transitions_here = []


    for interface_index in range(
        1,
        5,
    ):

        left = ms[
            interface_index
            -
            1
        ]

        right = ms[
            interface_index
        ]


        left_uid = str(
            left[
                "module_uid"
            ]
        )

        right_uid = str(
            right[
                "module_uid"
            ]
        )


        left_terminal = (
            domains_by_module[
                left_uid
            ][
                "last"
            ]
        )


        right_initial = (
            domains_by_module[
                right_uid
            ][
                "first"
            ]
        )


        left_end = int(
            left_terminal[
                "construct_nt_end_0based_exclusive"
            ]
        )

        right_start = int(
            right_initial[
                "construct_nt_start_0based"
            ]
        )


        gap_nt = (
            right_start
            -
            left_end
        )


        if gap_nt < 0:

            raise RuntimeError(
                f"{construct_id} J{interface_index}: "
                "adjacent modules overlap"
            )


        left_source = str(
            left_terminal[
                "source_locus_tag"
            ]
        )

        right_source = str(
            right_initial[
                "source_locus_tag"
            ]
        )


        same_source_locus = (
            left_source
            ==
            right_source
        )


        codon_aligned = (
            gap_nt
            %
            3
            ==
            0
        )


        translated_gap = None

        contains_stop = None


        if codon_aligned:

            nt = rec.seq[
                left_end:
                right_start
            ]


            translated_gap = str(
                nt.translate()
            )


            contains_stop = (
                "*"
                in
                translated_gap
            )


        # ------------------------------------------------------
        # Engineered scar must NEVER intersect J.
        # ------------------------------------------------------

        overlapping_scars = []


        for scar in scar_intervals[
            construct_id
        ]:

            if (
                scar[
                    "start"
                ]
                <
                right_start
                and
                scar[
                    "end"
                ]
                >
                left_end
            ):

                overlapping_scars.append(
                    scar[
                        "scar_name"
                    ]
                )


        if overlapping_scars:

            raise RuntimeError(
                f"{construct_id} J{interface_index}: "
                "engineered scar unexpectedly "
                f"intersects J: {overlapping_scars}"
            )


        # ------------------------------------------------------
        # EXACT audited partition.
        #
        # SAME-CHAIN LINKER:
        #   same source locus
        #   + codon-aligned physical interval
        #   + no stop codon
        #
        # CHAIN BREAK:
        #   source-locus change
        #   + frame discontinuity
        #
        # Any third pattern is NOT silently classified.
        # ------------------------------------------------------

        if (
            same_source_locus
            and
            codon_aligned
            and
            contains_stop
            is False
        ):

            transition_type = (
                "inter_module_linker_candidate"
            )

            junction_kind = (
                "same_chain_linker"
            )

            sequence_available = True

            sequence = (
                translated_gap
                if translated_gap
                is not None
                else ""
            )

            length_aa = len(
                sequence
            )


            if length_aa <= 0:

                raise RuntimeError(
                    f"{construct_id} J{interface_index}: "
                    "unexpected zero-length linker"
                )


            sequence_hash = (
                sha256_sequence(
                    sequence
                )
            )


            previous = (
                unique_linker_sequences.get(
                    sequence_hash
                )
            )


            if previous is None:

                unique_linker_sequences[
                    sequence_hash
                ] = sequence

            elif previous != sequence:

                raise RuntimeError(
                    "SHA256 collision in J sequences"
                )


            linker_pair_counts[
                (
                    interface_index,
                    interface_index
                    +
                    1,
                )
            ] += 1


        elif (
            not same_source_locus
            and
            not codon_aligned
        ):

            transition_type = (
                "inter_protein_chain_break"
            )

            junction_kind = (
                "chain_break"
            )

            sequence_available = False

            sequence = ""

            length_aa = 0

            sequence_hash = (
                EMPTY_SEQUENCE_HASH
            )


            break_pair_counts[
                (
                    interface_index,
                    interface_index
                    +
                    1,
                )
            ] += 1


        else:

            raise RuntimeError(
                f"{construct_id} J{interface_index}: "
                "transition does not match the "
                "audited linker/chain-break partition\n"
                f"same_source_locus="
                f"{same_source_locus}\n"
                f"gap_nt={gap_nt}\n"
                f"codon_aligned="
                f"{codon_aligned}\n"
                f"contains_stop="
                f"{contains_stop}\n"
                f"left_source="
                f"{left_source}\n"
                f"right_source="
                f"{right_source}"
            )


        transition_uid = (
            f"{assembly_line_id}"
            f"|transition="
            f"{interface_index}__"
            f"{interface_index + 1}"
        )


        transition_type_counts[
            transition_type
        ] += 1


        transitions_here.append(
            {
                "interface_index":
                    interface_index,

                "transition_uid":
                    transition_uid,

                "left_uid":
                    left_uid,

                "right_uid":
                    right_uid,

                "transition_type":
                    transition_type,

                "junction_kind":
                    junction_kind,

                "sequence_available":
                    sequence_available,

                "sequence":
                    sequence,

                "length_aa":
                    length_aa,

                "sequence_hash":
                    sequence_hash,

                "left_end_nt":
                    left_end,

                "right_start_nt":
                    right_start,

                "gap_nt":
                    gap_nt,

                "same_source_locus":
                    same_source_locus,

                "left_source_locus":
                    left_source,

                "right_source_locus":
                    right_source,

                "codon_aligned":
                    codon_aligned,

                "contains_stop":
                    contains_stop,
            }
        )


    # ----------------------------------------------------------
    # Chain-aware protein order.
    #
    # Historical Route-A protein_order is 1-based.
    # ----------------------------------------------------------

    protein_order = 1


    for module_index, module in enumerate(
        ms,
        start=1,
    ):

        module_occurrence_rows.append(
            {
                "assembly_line_id":
                    assembly_line_id,

                "construct_id":
                    construct_id,

                "split":
                    SPLIT,

                "global_module_index":
                    module_index,

                "module_count":
                    5,

                "protein_order":
                    protein_order,

                "module_uid":
                    str(
                        module[
                            "module_uid"
                        ]
                    ),

                "sequence_hash":
                    str(
                        module[
                            "module_sequence_hash"
                        ]
                    ),
            }
        )


        if module_index <= 4:

            transition = (
                transitions_here[
                    module_index
                    -
                    1
                ]
            )


            if (
                transition[
                    "transition_type"
                ]
                ==
                "inter_protein_chain_break"
            ):

                protein_order += 1


    chain_break_count = sum(
        t[
            "transition_type"
        ]
        ==
        "inter_protein_chain_break"

        for t in transitions_here
    )


    protein_count = (
        chain_break_count
        +
        1
    )


    protein_count_distribution[
        protein_count
    ] += 1


    assembly_rows.append(
        {
            "assembly_line_id":
                assembly_line_id,

            "construct_id":
                construct_id,

            "split":
                SPLIT,

            "module_count":
                5,

            "transition_count":
                4,

            "chain_break_count":
                chain_break_count,

            "protein_count":
                protein_count,
        }
    )


    # ----------------------------------------------------------
    # Interfaces + JunctionStore rows.
    # ----------------------------------------------------------

    for t in transitions_here:

        interface_index = int(
            t[
                "interface_index"
            ]
        )


        interface_rows.append(
            {
                "interface_id":
                    t[
                        "transition_uid"
                    ],

                "transition_uid":
                    t[
                        "transition_uid"
                    ],

                "assembly_line_id":
                    assembly_line_id,

                "construct_id":
                    construct_id,

                "split":
                    SPLIT,

                "interface_index":
                    interface_index,

                "left_global_module_index":
                    interface_index,

                "right_global_module_index":
                    interface_index
                    +
                    1,

                "left_module_uid":
                    t[
                        "left_uid"
                    ],

                "right_module_uid":
                    t[
                        "right_uid"
                    ],

                "transition_type":
                    t[
                        "transition_type"
                    ],

                "module_count":
                    5,
            }
        )


        junction_rows.append(
            {
                # ----------------------------------------------
                # JunctionStore required fields
                # ----------------------------------------------
                "transition_uid":
                    t[
                        "transition_uid"
                    ],

                "assembly_line_id":
                    assembly_line_id,

                "construct_id":
                    construct_id,

                "split":
                    SPLIT,

                "transition_type":
                    t[
                        "transition_type"
                    ],

                "sequence_available":
                    (
                        "True"
                        if t[
                            "sequence_available"
                        ]
                        else
                        "False"
                    ),

                "sequence":
                    t[
                        "sequence"
                    ],

                "length_aa":
                    t[
                        "length_aa"
                    ],

                "sequence_sha256":
                    t[
                        "sequence_hash"
                    ],

                # ----------------------------------------------
                # Extra explicit assembly/J metadata
                # ----------------------------------------------
                "interface_index":
                    interface_index,

                "junction_kind":
                    t[
                        "junction_kind"
                    ],

                "junction_sequence_hash":
                    t[
                        "sequence_hash"
                    ],

                "junction_sequence_length":
                    t[
                        "length_aa"
                    ],
            }
        )


        geometry_rows.append(
            {
                "construct_id":
                    construct_id,

                "assembly_line_id":
                    assembly_line_id,

                "interface_index":
                    interface_index,

                "transition_uid":
                    t[
                        "transition_uid"
                    ],

                "left_module_uid":
                    t[
                        "left_uid"
                    ],

                "right_module_uid":
                    t[
                        "right_uid"
                    ],

                "left_source_locus":
                    t[
                        "left_source_locus"
                    ],

                "right_source_locus":
                    t[
                        "right_source_locus"
                    ],

                "same_source_locus":
                    t[
                        "same_source_locus"
                    ],

                "left_end_nt":
                    t[
                        "left_end_nt"
                    ],

                "right_start_nt":
                    t[
                        "right_start_nt"
                    ],

                "gap_nt":
                    t[
                        "gap_nt"
                    ],

                "codon_aligned":
                    t[
                        "codon_aligned"
                    ],

                "contains_stop":
                    (
                        ""
                        if t[
                            "contains_stop"
                        ]
                        is None
                        else
                        t[
                            "contains_stop"
                        ]
                    ),

                "transition_type":
                    t[
                        "transition_type"
                    ],

                "junction_kind":
                    t[
                        "junction_kind"
                    ],

                "junction_length_aa":
                    t[
                        "length_aa"
                    ],

                "junction_sequence_hash":
                    t[
                        "sequence_hash"
                    ],
            }
        )


# ======================================================================
# HARD GLOBAL CONTRACT
# ======================================================================

if len(
    module_occurrence_rows
) != EXPECTED_MODULES:

    raise RuntimeError(
        "Module-occurrence count mismatch"
    )


if len(
    interface_rows
) != EXPECTED_TRANSITIONS:

    raise RuntimeError(
        "Interface count mismatch"
    )


if len(
    junction_rows
) != EXPECTED_TRANSITIONS:

    raise RuntimeError(
        "Junction count mismatch"
    )


if len(
    geometry_rows
) != EXPECTED_TRANSITIONS:

    raise RuntimeError(
        "Geometry count mismatch"
    )


if len(
    assembly_rows
) != EXPECTED_CONSTRUCTS:

    raise RuntimeError(
        "Assembly count mismatch"
    )


observed_linkers = (
    transition_type_counts[
        "inter_module_linker_candidate"
    ]
)


observed_breaks = (
    transition_type_counts[
        "inter_protein_chain_break"
    ]
)


if observed_linkers != EXPECTED_LINKERS:

    raise RuntimeError(
        f"Expected {EXPECTED_LINKERS} linkers, "
        f"got {observed_linkers}"
    )


if observed_breaks != EXPECTED_CHAIN_BREAKS:

    raise RuntimeError(
        f"Expected {EXPECTED_CHAIN_BREAKS} chain breaks, "
        f"got {observed_breaks}"
    )


for pair, expected in (
    EXPECTED_PAIR_BREAKS.items()
):

    observed = break_pair_counts[
        pair
    ]


    if observed != expected:

        raise RuntimeError(
            f"Chain-break count drift at "
            f"M{pair[0]}->M{pair[1]}: "
            f"{observed} vs {expected}"
        )


if len(
    unique_linker_sequences
) != 32:

    raise RuntimeError(
        "Expected 32 unique "
        "same-chain linker sequences, "
        f"got {len(unique_linker_sequences)}"
    )


# ======================================================================
# WRITE
# ======================================================================

MODULE_FIELDS = [
    "assembly_line_id",
    "construct_id",
    "split",
    "global_module_index",
    "module_count",
    "protein_order",
    "module_uid",
    "sequence_hash",
]


INTERFACE_FIELDS = [
    "interface_id",
    "transition_uid",
    "assembly_line_id",
    "construct_id",
    "split",
    "interface_index",
    "left_global_module_index",
    "right_global_module_index",
    "left_module_uid",
    "right_module_uid",
    "transition_type",
    "module_count",
]


JUNCTION_FIELDS = [
    "transition_uid",
    "assembly_line_id",
    "construct_id",
    "split",
    "transition_type",
    "sequence_available",
    "sequence",
    "length_aa",
    "sequence_sha256",
    "interface_index",
    "junction_kind",
    "junction_sequence_hash",
    "junction_sequence_length",
]


GEOMETRY_FIELDS = [
    "construct_id",
    "assembly_line_id",
    "interface_index",
    "transition_uid",
    "left_module_uid",
    "right_module_uid",
    "left_source_locus",
    "right_source_locus",
    "same_source_locus",
    "left_end_nt",
    "right_start_nt",
    "gap_nt",
    "codon_aligned",
    "contains_stop",
    "transition_type",
    "junction_kind",
    "junction_length_aa",
    "junction_sequence_hash",
]


ASSEMBLY_FIELDS = [
    "assembly_line_id",
    "construct_id",
    "split",
    "module_count",
    "transition_count",
    "chain_break_count",
    "protein_count",
]


write_tsv_gz(
    TMP
    / "module_occurrences.tsv.gz",
    module_occurrence_rows,
    MODULE_FIELDS,
)


write_tsv_gz(
    TMP
    / "interfaces.tsv.gz",
    interface_rows,
    INTERFACE_FIELDS,
)


write_tsv_gz(
    TMP
    / "junctions.tsv.gz",
    junction_rows,
    JUNCTION_FIELDS,
)


write_tsv_gz(
    TMP
    / "transition_geometry.tsv.gz",
    geometry_rows,
    GEOMETRY_FIELDS,
)


write_tsv_gz(
    TMP
    / "assemblies.tsv.gz",
    assembly_rows,
    ASSEMBLY_FIELDS,
)


# ======================================================================
# UNIQUE SAME-CHAIN LINKER FASTA — audit/provenance only.
#
# J does NOT require ESM-C.
# ======================================================================

with gzip.open(
    TMP
    / "unique_same_chain_linkers.fasta.gz",
    "wt",
) as f:

    for h in sorted(
        unique_linker_sequences
    ):

        seq = (
            unique_linker_sequences[
                h
            ]
        )

        f.write(
            f">{h}\n"
            f"{seq}\n"
        )


# ======================================================================
# SUMMARY
# ======================================================================

summary = {
    "status":
        "bode_phase2_assembly_context_v1_3",

    "experimental_activity_labels_used":
        False,

    "split":
        SPLIT,

    "constructs":
        EXPECTED_CONSTRUCTS,

    "module_occurrences":
        len(
            module_occurrence_rows
        ),

    "interfaces":
        len(
            interface_rows
        ),

    "junctions":
        len(
            junction_rows
        ),

    "same_chain_linkers":
        observed_linkers,

    "inter_protein_chain_breaks":
        observed_breaks,

    "unique_same_chain_linker_sequences":
        len(
            unique_linker_sequences
        ),

    "chain_breaks_by_module_pair":
        {
            f"M{a}->M{b}":
                break_pair_counts[
                    (
                        a,
                        b,
                    )
                ]

            for a, b in (
                (1, 2),
                (2, 3),
                (3, 4),
                (4, 5),
            )
        },

    "same_chain_linkers_by_module_pair":
        {
            f"M{a}->M{b}":
                linker_pair_counts[
                    (
                        a,
                        b,
                    )
                ]

            for a, b in (
                (1, 2),
                (2, 3),
                (3, 4),
                (4, 5),
            )
        },

    "protein_count_distribution":
        {
            str(k):
                int(v)

            for k, v in sorted(
                protein_count_distribution.items()
            )
        },

    "engineered_scar_J_intersections":
        0,

    "chain_break_sequence_policy":
        (
            "empty sequence, length 0, "
            "sha256(empty); learned CHAIN_BREAK "
            "representation in Route-A runtime"
        ),
}


with (
    TMP
    / "build_summary.json"
).open(
    "w"
) as f:

    json.dump(
        summary,
        f,
        indent=2,
        sort_keys=True,
    )

    f.write(
        "\n"
    )


# ======================================================================
# REAL RUNTIME VALIDATION
# ======================================================================

print()
print(
    "=" * 110
)

print(
    "RUNTIME VALIDATION"
)

print(
    "=" * 110
)


from neuralps.data.assembly_context_store_v2 import (
    AssemblyContextStoreV2,
)

from neuralps.data.junction_store import (
    JunctionStore,
)

from neuralps.data.assembly_junction_batch_v2 import (
    AssemblyJunctionBatchBuilderV2,
)


assembly_store = (
    AssemblyContextStoreV2(
        module_occurrences_path=(
            TMP
            / "module_occurrences.tsv.gz"
        ),

        interfaces_path=(
            TMP
            / "interfaces.tsv.gz"
        ),

        junctions_path=(
            TMP
            / "junctions.tsv.gz"
        ),
    )
)


if len(
    assembly_store
) != EXPECTED_CONSTRUCTS:

    raise RuntimeError(
        "AssemblyContextStoreV2 "
        "assembly-count mismatch"
    )


junction_store = JunctionStore(
    TMP
    / "junctions.tsv.gz"
)


if len(
    junction_store
) != EXPECTED_TRANSITIONS:

    raise RuntimeError(
        "JunctionStore count mismatch"
    )


# ----------------------------------------------------------
# Verify every runtime JunctionRecord.
# ----------------------------------------------------------

runtime_linkers = 0

runtime_breaks = 0


for row in junction_rows:

    uid = row[
        "transition_uid"
    ]


    record = junction_store.get(
        uid
    )


    if record.is_chain_break:

        runtime_breaks += 1


        if record.sequence:

            raise RuntimeError(
                f"{uid}: runtime chain break "
                "contains sequence"
            )


        if record.length_aa != 0:

            raise RuntimeError(
                f"{uid}: runtime chain break "
                "has nonzero length"
            )


    elif record.is_linker:

        runtime_linkers += 1


        if not record.sequence:

            raise RuntimeError(
                f"{uid}: runtime linker "
                "has no sequence"
            )


        if (
            len(
                record.sequence
            )
            !=
            record.length_aa
        ):

            raise RuntimeError(
                f"{uid}: runtime linker "
                "length mismatch"
            )


    else:

        raise RuntimeError(
            f"{uid}: unknown runtime J kind"
        )


if runtime_linkers != 347:

    raise RuntimeError(
        "Runtime linker count mismatch"
    )


if runtime_breaks != 77:

    raise RuntimeError(
        "Runtime chain-break count mismatch"
    )


# ----------------------------------------------------------
# Tensorize all 424 junctions through the real V2 builder.
# ----------------------------------------------------------

junction_builder = (
    AssemblyJunctionBatchBuilderV2(
        junction_store
    )
)


ordered_transition_uids = tuple(
    row[
        "transition_uid"
    ]
    for row in interface_rows
)


junction_batch = (
    junction_builder.build(
        ordered_transition_uids
    )
)


junction_batch.validate()


if (
    len(
        junction_batch
        .transition_uids
    )
    !=
    EXPECTED_TRANSITIONS
):

    raise RuntimeError(
        "Assembly junction batch size mismatch"
    )


print(
    "AssemblyContextStoreV2:",
    len(
        assembly_store
    ),
    "assemblies PASS",
)

print(
    "JunctionStore:",
    len(
        junction_store
    ),
    "junctions PASS",
)

print(
    "runtime same-chain linkers:",
    runtime_linkers,
    "PASS",
)

print(
    "runtime chain breaks:",
    runtime_breaks,
    "PASS",
)

print(
    "AssemblyJunctionBatchBuilderV2:",
    len(
        junction_batch
        .transition_uids
    ),
    "PASS",
)


# ======================================================================
# COMMIT
# ======================================================================

if OUT.exists():

    backup = (
        OUT.with_name(
            OUT.name
            +
            "_backup"
        )
    )


    if backup.exists():

        shutil.rmtree(
            backup
        )


    OUT.rename(
        backup
    )


TMP.rename(
    OUT
)


print()
print(
    "=" * 110
)

print(
    "FINAL PHASE-2 ASSEMBLY CONTRACT"
)

print(
    "=" * 110
)

print(
    "constructs:                    106"
)

print(
    "module occurrences:            530"
)

print(
    "J positions:                   424"
)

print(
    "same-chain linker J:           347"
)

print(
    "inter-protein chain-break J:    77"
)

print(
    "unique same-chain J sequences:  32"
)

print(
    "engineered scars at J:           0"
)

print()
print(
    "chain breaks by module pair:"
)

for pair in (
    (1, 2),
    (2, 3),
    (3, 4),
    (4, 5),
):

    print(
        f"  M{pair[0]} -> M{pair[1]}:",
        break_pair_counts[
            pair
        ],
    )


print()
print(
    "protein-count distribution:"
)

for k, v in sorted(
    protein_count_distribution.items()
):

    print(
        f"  {k} proteins:",
        v,
        "constructs",
    )


print()
print(
    "OUTPUT:"
)

print(
    OUT
)

print()
print(
    "=" * 110
)

print(
    "BODE PHASE-2 ASSEMBLY CONTEXT V1.3: FULL PASS"
)

print(
    "=" * 110
)
