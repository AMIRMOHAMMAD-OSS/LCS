#!/usr/bin/env python3

from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
import gzip
import hashlib
import json
import re
import shutil

import pandas as pd
import torch
from Bio import SeqIO


# ======================================================================
# PATHS
# ======================================================================

ROOT = Path.cwd()

GB = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "genbank_raw"
    / "106 NRPS sequences.gb"
)

OUT = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "structured_v1_3"
)

TMP = OUT.parent / ".structured_v1_3.tmp"

OLD_DOMAIN_EMBEDDINGS = (
    ROOT
    / "results"
    / "bode_esmc600m_embeddings_structured_v1_1"
    / "structured_domain_embeddings.pt"
)

OLD_DOMAIN_INDEX = (
    ROOT
    / "results"
    / "bode_esmc600m_embeddings_structured_v1_1"
    / "structured_domain_embedding_index.tsv"
)


# ======================================================================
# EXPECTED BIOLOGICAL CONTRACT
# ======================================================================

EXPECTED_CONSTRUCTS = 106
EXPECTED_MODULES = 530
EXPECTED_DOMAINS = 1854
EXPECTED_BOUNDARIES = 1324
EXPECTED_SCARS = 212

BOUNDARY_FLANK_AA = 64

SPLIT = "external_bode_phase2"


CORE_TYPES = {
    "Condensation_Starter",
    "Condensation_LCL",
    "Condensation_DCL",
    "Condensation_Dual",
    "AMP-binding",
    "PCP",
    "Epimerization",
    "TIGR01720",
}


# ======================================================================
# HELPERS
# ======================================================================

def one(q, key, default=""):
    values = q.get(key, [])

    return (
        str(values[0])
        if values
        else default
    )


def clean_aa(seq):
    return "".join(
        str(seq).split()
    ).upper()


def sha256(seq):
    return hashlib.sha256(
        str(seq).encode("ascii")
    ).hexdigest()


def construct_name(rec):
    name = str(rec.name)

    if "_(" in name:
        return name.split(
            "_(",
            1,
        )[0]

    return name


def domain_type(q):

    if (
        one(q, "aSTool")
        !=
        "nrps_pks_domains"
    ):
        return None


    raw = one(
        q,
        "aSDomain",
    ).strip()


    subtypes = [
        str(x).strip()
        for x in q.get(
            "domain_subtypes",
            [],
        )
        if str(x).strip()
    ]


    if raw == "Condensation":

        dtype = None

        for subtype in subtypes:

            if subtype.startswith(
                "Condensation_"
            ):
                dtype = subtype
                break


        if dtype is None:

            domain_id = one(
                q,
                "domain_id",
            )

            for candidate in (
                "Condensation_Starter",
                "Condensation_LCL",
                "Condensation_DCL",
                "Condensation_Dual",
            ):

                if candidate in domain_id:
                    dtype = candidate
                    break


        if dtype is None:
            return None

    else:

        dtype = raw


    if dtype not in CORE_TYPES:
        return None


    return dtype


def transferred_translation(q):

    for key in (
        "Transferred_Translation",
        "X-Transferred_Translation",
        "translation",
    ):

        value = one(
            q,
            key,
        )

        if value:

            seq = clean_aa(
                value
            )

            if seq:
                return seq


    return ""


def write_fasta_gz(
    path,
    mapping,
):

    with gzip.open(
        path,
        "wt",
    ) as handle:

        for h in sorted(mapping):

            seq = mapping[h]

            handle.write(
                f">{h}\n"
            )

            for start in range(
                0,
                len(seq),
                80,
            ):

                handle.write(
                    seq[
                        start:
                        start + 80
                    ]
                    + "\n"
                )


# ======================================================================
# TRANSACTION START
# ======================================================================

if TMP.exists():
    shutil.rmtree(TMP)

TMP.mkdir(
    parents=True
)


records = list(
    SeqIO.parse(
        str(GB),
        "genbank",
    )
)


assert len(records) == 106


print("=" * 110)
print("BODE PHASE-2 STRUCTURED V1.3")
print("=" * 110)

print(
    "experimental activity/product labels are NOT read"
)

print(
    "domain identity is occurrence-level, not donor-identity-level"
)


# ======================================================================
# 1. RAW DOMAIN FEATURES
# ======================================================================

all_occurrences = []

duplicate_clusters = 0

raw_feature_count = 0


for rec in records:

    raw_record_id = str(
        rec.id
    )

    cid = construct_name(
        rec
    )


    grouped = defaultdict(list)


    for feature_index, feat in enumerate(
        rec.features
    ):

        if feat.type != "aSDomain":
            continue


        q = feat.qualifiers

        dtype = domain_type(q)

        if dtype is None:
            continue


        locus = one(
            q,
            "locus_tag",
        )


        try:

            pstart = int(
                one(
                    q,
                    "protein_start",
                )
            )

            pend = int(
                one(
                    q,
                    "protein_end",
                )
            )

        except Exception:

            continue


        start = int(
            feat.location.start
        )

        end = int(
            feat.location.end
        )


        seq = transferred_translation(q)


        grouped[
            (
                locus,
                dtype,
                pstart,
                pend,
            )
        ].append(
            {
                "feature_index":
                    feature_index,

                "start":
                    start,

                "end":
                    end,

                "sequence":
                    seq,

                "domain_id":
                    one(
                        q,
                        "domain_id",
                    ),
            }
        )

        raw_feature_count += 1


    # ==================================================================
    # Cluster overlapping raw annotations of the SAME donor domain.
    #
    # Distant clusters remain separate engineered occurrences.
    # ==================================================================

    for donor_key, features in grouped.items():

        locus, dtype, pstart, pend = donor_key


        features = sorted(
            features,
            key=lambda x: (
                x["start"],
                x["end"],
            ),
        )


        clusters = []

        current = []


        for feature in features:

            if not current:

                current = [feature]
                continue


            max_end = max(
                x["end"]
                for x in current
            )


            if (
                feature["start"]
                <
                max_end
            ):

                current.append(
                    feature
                )

            else:

                clusters.append(
                    current
                )

                current = [feature]


        if current:
            clusters.append(
                current
            )


        for occurrence_number, cluster in enumerate(
            clusters,
            start=1,
        ):

            if len(cluster) > 1:
                duplicate_clusters += 1


            cluster_start = min(
                x["start"]
                for x in cluster
            )

            cluster_end = max(
                x["end"]
                for x in cluster
            )


            sequences = {
                x["sequence"]
                for x in cluster
                if x["sequence"]
            }


            if len(sequences) != 1:

                raise RuntimeError(
                    f"{cid} {donor_key}: "
                    f"expected one mature translation "
                    f"per occurrence cluster, got {len(sequences)}"
                )


            domain_seq = next(
                iter(sequences)
            )


            domain_hash = sha256(
                domain_seq
            )


            # ----------------------------------------------------------
            # Crucial physical check:
            #
            # union of overlapping partial annotations should recover
            # the full exact coding span.
            # ----------------------------------------------------------

            nt_length = (
                cluster_end
                -
                cluster_start
            )


            expected_nt_length = (
                3
                *
                len(domain_seq)
            )


            if (
                nt_length
                !=
                expected_nt_length
            ):

                raise RuntimeError(
                    f"{cid} {locus} {dtype} "
                    f"{pstart}:{pend} occurrence "
                    f"{occurrence_number}: "
                    f"cluster NT={nt_length}, "
                    f"expected NT={expected_nt_length}"
                )


            observed_aa = str(
                rec.seq[
                    cluster_start:
                    cluster_end
                ].translate()
            )


            if observed_aa != domain_seq:

                raise RuntimeError(
                    f"{cid} {locus} {dtype} "
                    f"{pstart}:{pend} occurrence "
                    f"{occurrence_number}: "
                    "DNA translation != transferred AA"
                )


            occurrence_uid = (
                f"{raw_record_id}"
                f"|{locus}"
                f"|{dtype}"
                f"|{pstart}:{pend}"
                f"|occ={occurrence_number}"
                f"|nt={cluster_start}:{cluster_end}"
            )


            all_occurrences.append(
                {
                    "raw_record_id":
                        raw_record_id,

                    "construct_id":
                        cid,

                    "domain_uid":
                        occurrence_uid,

                    "locus_tag":
                        locus,

                    "domain_type":
                        dtype,

                    "donor_protein_start":
                        pstart,

                    "donor_protein_end":
                        pend,

                    "occurrence_index":
                        occurrence_number,

                    "construct_nt_start":
                        cluster_start,

                    "construct_nt_end":
                        cluster_end,

                    "domain_sequence":
                        domain_seq,

                    "domain_sequence_hash":
                        domain_hash,

                    "domain_length":
                        len(domain_seq),

                    "raw_annotation_count":
                        len(cluster),
                }
            )


occ = pd.DataFrame(
    all_occurrences
)


# ======================================================================
# 2. GLOBAL DOMAIN CONTRACT
# ======================================================================

if len(occ) != EXPECTED_DOMAINS:

    raise RuntimeError(
        f"Expected {EXPECTED_DOMAINS} domain occurrences, "
        f"got {len(occ)}"
    )


counts = Counter(
    occ["domain_type"]
)


expected_counts = {
    "AMP-binding":
        530,

    "PCP":
        530,

    "Condensation_Starter":
        106,

    "Condensation_LCL":
        228,

    "Condensation_DCL":
        175,

    "Condensation_Dual":
        21,

    "Epimerization":
        175,

    "TIGR01720":
        89,
}


if dict(counts) != expected_counts:

    raise RuntimeError(
        "Domain-type counts drifted:\n"
        f"{dict(counts)}"
    )


print()
print("=" * 110)
print("DOMAIN OCCURRENCE CONTRACT")
print("=" * 110)

print(
    "raw retained annotations:",
    raw_feature_count,
)

print(
    "occurrence domains:",
    len(occ),
)

print(
    "duplicate/partial annotation clusters:",
    duplicate_clusters,
)

print(
    "unique domain hashes:",
    occ[
        "domain_sequence_hash"
    ].nunique(),
)


# ======================================================================
# 3. BUILD FIVE MODULES PER CONSTRUCT
# ======================================================================

module_rows = []

assigned_rows = []

module_members = defaultdict(list)


for construct_id, g in occ.groupby(
    "construct_id",
    sort=False,
):

    g = g.sort_values(
        [
            "construct_nt_start",
            "construct_nt_end",
            "domain_type",
        ]
    )


    current = []

    modules = []


    for domain in g.to_dict(
        "records"
    ):

        dtype = domain[
            "domain_type"
        ]


        starts_module = (
            dtype.startswith(
                "Condensation_"
            )
            or
            dtype
            ==
            "AMP-binding"
        )


        current_has_pcp = any(
            x[
                "domain_type"
            ]
            ==
            "PCP"
            for x in current
        )


        if (
            current
            and
            current_has_pcp
            and
            starts_module
        ):

            modules.append(
                current
            )

            current = []


        current.append(
            domain
        )


    if current:

        modules.append(
            current
        )


    if len(modules) != 5:

        raise RuntimeError(
            f"{construct_id}: expected 5 modules, "
            f"got {len(modules)}"
        )


    for module_index, members in enumerate(
        modules,
        start=1,
    ):

        types = [
            x[
                "domain_type"
            ]
            for x in members
        ]


        if (
            types.count(
                "AMP-binding"
            )
            != 1
            or
            types.count(
                "PCP"
            )
            != 1
        ):

            raise RuntimeError(
                f"{construct_id} M{module_index}: "
                f"invalid architecture {types}"
            )


        module_uid = (
            f"{construct_id}"
            f"|module={module_index}"
        )


        for component_order, domain in enumerate(
            members,
            start=1,
        ):

            domain = dict(
                domain
            )

            domain[
                "module_uid"
            ] = module_uid

            domain[
                "module_index"
            ] = module_index

            domain[
                "component_order"
            ] = component_order


            assigned_rows.append(
                domain
            )

            module_members[
                module_uid
            ].append(
                domain
            )


        module_rows.append(
            {
                "construct_id":
                    construct_id,

                "module_uid":
                    module_uid,

                "module_index":
                    module_index,

                "component_count":
                    len(members),

                "architecture":
                    "->".join(types),

                "construct_nt_start":
                    members[0][
                        "construct_nt_start"
                    ],

                "construct_nt_end":
                    members[-1][
                        "construct_nt_end"
                    ],
            }
        )


assigned = pd.DataFrame(
    assigned_rows
)


if len(module_rows) != EXPECTED_MODULES:

    raise RuntimeError(
        "Expected 530 modules"
    )


if len(assigned) != EXPECTED_DOMAINS:

    raise RuntimeError(
        "Domain assignment count mismatch"
    )


print()
print("=" * 110)
print("MODULE CONTRACT")
print("=" * 110)

print(
    "constructs:",
    assigned[
        "construct_id"
    ].nunique(),
)

print(
    "modules:",
    len(module_rows),
)

print(
    "domains:",
    len(assigned),
)

print(
    "modules per construct:",
    Counter(
        pd.DataFrame(
            module_rows
        )
        .groupby(
            "construct_id"
        )
        .size()
    ),
)


# ======================================================================
# 4. WHOLE-MODULE SEQUENCES
#
# Actual engineered mature sequence from first retained D through
# last retained D.
# ======================================================================

record_by_construct = {
    construct_name(rec):
        rec

    for rec in records
}


structured_modules = []

structured_domains = []

unique_modules = {}


for module_uid in sorted(
    module_members,
    key=lambda uid: (
        uid.split("|module=")[0],
        int(
            uid.split("|module=")[1]
        ),
    ),
):

    members = sorted(
        module_members[
            module_uid
        ],
        key=lambda x:
            x[
                "component_order"
            ],
    )


    construct_id = members[0][
        "construct_id"
    ]

    rec = record_by_construct[
        construct_id
    ]


    module_nt_start = members[0][
        "construct_nt_start"
    ]

    module_nt_end = members[-1][
        "construct_nt_end"
    ]


    if (
        module_nt_end
        -
        module_nt_start
    ) % 3 != 0:

        raise RuntimeError(
            f"{module_uid}: "
            "module span not codon aligned"
        )


    module_seq = str(
        rec.seq[
            module_nt_start:
            module_nt_end
        ].translate()
    )


    if "*" in module_seq:

        raise RuntimeError(
            f"{module_uid}: internal stop codon"
        )


    module_hash = sha256(
        module_seq
    )


    unique_modules[
        module_hash
    ] = module_seq


    component_types = []


    for d in members:

        local_start = (
            d[
                "construct_nt_start"
            ]
            -
            module_nt_start
        ) // 3


        local_end = (
            d[
                "construct_nt_end"
            ]
            -
            module_nt_start
        ) // 3


        observed = module_seq[
            local_start:
            local_end
        ]


        if (
            observed
            !=
            d[
                "domain_sequence"
            ]
        ):

            raise RuntimeError(
                f"{module_uid}/{d['domain_uid']}: "
                "domain does not align exactly "
                "inside whole module"
            )


        component_types.append(
            d[
                "domain_type"
            ]
        )


        structured_domains.append(
            {
                "module_uid":
                    module_uid,

                "split":
                    SPLIT,

                "component_order":
                    d[
                        "component_order"
                    ],

                "domain_uid":
                    d[
                        "domain_uid"
                    ],

                "domain_type":
                    d[
                        "domain_type"
                    ],

                "domain_sequence_hash":
                    d[
                        "domain_sequence_hash"
                    ],

                "domain_length":
                    d[
                        "domain_length"
                    ],

                "domain_start_module_0based":
                    local_start,

                "domain_end_module_0based_exclusive":
                    local_end,

                "construct_nt_start_0based":
                    d[
                        "construct_nt_start"
                    ],

                "construct_nt_end_0based_exclusive":
                    d[
                        "construct_nt_end"
                    ],

                "source_locus_tag":
                    d[
                        "locus_tag"
                    ],

                "donor_protein_start":
                    d[
                        "donor_protein_start"
                    ],

                "donor_protein_end":
                    d[
                        "donor_protein_end"
                    ],

                "occurrence_index":
                    d[
                        "occurrence_index"
                    ],
            }
        )


    component_count = len(
        members
    )


    token_count = (
        2
        *
        component_count
        -
        1
    )


    if token_count > 11:

        raise RuntimeError(
            f"{module_uid}: "
            f"{token_count} biological tokens > 11"
        )


    structured_modules.append(
        {
            "module_uid":
                module_uid,

            "split":
                SPLIT,

            "module_sequence_hash":
                module_hash,

            "module_sequence_length":
                len(module_seq),

            "component_count":
                component_count,

            "internal_boundary_count":
                component_count
                -
                1,

            "component_architecture":
                "->".join(
                    component_types
                ),

            "initial_component":
                component_types[0],

            "terminal_component":
                component_types[-1],

            "construct_id":
                construct_id,

            "module_index":
                members[0][
                    "module_index"
                ],

            "construct_nt_start_0based":
                module_nt_start,

            "construct_nt_end_0based_exclusive":
                module_nt_end,
        }
    )


# ======================================================================
# 5. INTERNAL B TOKENS
# ======================================================================

domains_by_module = defaultdict(list)


for row in structured_domains:

    domains_by_module[
        row[
            "module_uid"
        ]
    ].append(
        row
    )


module_seq_lookup = {
    row[
        "module_uid"
    ]:
        unique_modules[
            row[
                "module_sequence_hash"
            ]
        ]

    for row in structured_modules
}


boundary_rows = []

unique_boundaries = {}


for module_uid, domains in domains_by_module.items():

    domains = sorted(
        domains,
        key=lambda x:
            x[
                "component_order"
            ],
    )


    module_seq = module_seq_lookup[
        module_uid
    ]


    for left, right in zip(
        domains[:-1],
        domains[1:],
    ):

        left_start = left[
            "domain_start_module_0based"
        ]

        left_end = left[
            "domain_end_module_0based_exclusive"
        ]

        right_start = right[
            "domain_start_module_0based"
        ]

        right_end = right[
            "domain_end_module_0based_exclusive"
        ]


        window_start = max(
            left_start,
            left_end
            -
            BOUNDARY_FLANK_AA,
        )


        window_end = min(
            right_end,
            right_start
            +
            BOUNDARY_FLANK_AA,
        )


        if window_end <= window_start:

            raise RuntimeError(
                f"{module_uid}: "
                "invalid boundary window"
            )


        boundary_seq = module_seq[
            window_start:
            window_end
        ]


        boundary_hash = sha256(
            boundary_seq
        )


        unique_boundaries[
            boundary_hash
        ] = boundary_seq


        boundary_rows.append(
            {
                "boundary_uid":
                    (
                        f"{module_uid}"
                        f"|boundary="
                        f"{left['component_order']}-"
                        f"{right['component_order']}"
                    ),

                "module_uid":
                    module_uid,

                "split":
                    SPLIT,

                "left_component_order":
                    left[
                        "component_order"
                    ],

                "right_component_order":
                    right[
                        "component_order"
                    ],

                "left_domain_uid":
                    left[
                        "domain_uid"
                    ],

                "right_domain_uid":
                    right[
                        "domain_uid"
                    ],

                "left_domain_type":
                    left[
                        "domain_type"
                    ],

                "right_domain_type":
                    right[
                        "domain_type"
                    ],

                "window_start_module_0based":
                    window_start,

                "window_end_module_0based_exclusive":
                    window_end,

                "boundary_sequence_hash":
                    boundary_hash,

                "boundary_sequence_length":
                    len(
                        boundary_seq
                    ),

                "boundary_flank_policy_aa":
                    BOUNDARY_FLANK_AA,

                "engineered_scar_name":
                    "",

                "engineered_scar_sequence":
                    "",
            }
        )


if len(boundary_rows) != EXPECTED_BOUNDARIES:

    raise RuntimeError(
        f"Expected {EXPECTED_BOUNDARIES} B occurrences, "
        f"got {len(boundary_rows)}"
    )


# ======================================================================
# 6. MAP THE 212 ENGINEERED SCARS TO EXACT A->PCP B TOKENS
# ======================================================================

boundaries_by_construct = defaultdict(list)


for i, row in enumerate(
    boundary_rows
):

    construct_id = (
        row[
            "module_uid"
        ].split(
            "|module="
        )[0]
    )

    boundaries_by_construct[
        construct_id
    ].append(
        (
            i,
            row,
        )
    )


scar_rows = []


for rec in records:

    cid = construct_name(
        rec
    )


    labels = {}


    for feat in rec.features:

        label = one(
            feat.qualifiers,
            "label",
        ).strip()


        if label in {
            "LNR",
            "SAV",
            "NPC",
            "SEI",
        }:

            labels[
                label
            ] = (
                int(
                    feat.location.start
                ),
                int(
                    feat.location.end
                ),
            )


    specs = (
        (
            "scar1",
            "LNR",
            "SAV",
            "LNRSAV",
            2,
        ),

        (
            "scar2",
            "NPC",
            "SEI",
            "NPCSEI",
            3,
        ),
    )


    for (
        scar_name,
        left_label,
        right_label,
        scar_sequence,
        expected_module,
    ) in specs:

        scar_start = labels[
            left_label
        ][0]

        scar_end = labels[
            right_label
        ][1]


        hits = []


        for boundary_index, boundary in (
            boundaries_by_construct[
                cid
            ]
        ):

            module_uid = boundary[
                "module_uid"
            ]


            module_index = int(
                module_uid.split(
                    "|module="
                )[1]
            )


            if module_index != expected_module:
                continue


            if (
                boundary[
                    "left_domain_type"
                ]
                !=
                "AMP-binding"
                or
                boundary[
                    "right_domain_type"
                ]
                !=
                "PCP"
            ):

                continue


            left_domain = next(
                x
                for x in structured_domains
                if x[
                    "domain_uid"
                ]
                ==
                boundary[
                    "left_domain_uid"
                ]
            )


            right_domain = next(
                x
                for x in structured_domains
                if x[
                    "domain_uid"
                ]
                ==
                boundary[
                    "right_domain_uid"
                ]
            )


            gap_start = left_domain[
                "construct_nt_end_0based_exclusive"
            ]

            gap_end = right_domain[
                "construct_nt_start_0based"
            ]


            if (
                gap_start
                <=
                scar_start
                and
                scar_end
                <=
                gap_end
            ):

                hits.append(
                    (
                        boundary_index,
                        boundary,
                    )
                )


        if len(hits) != 1:

            raise RuntimeError(
                f"{cid}/{scar_name}: "
                f"expected exactly one B hit, "
                f"got {len(hits)}"
            )


        boundary_index, boundary = hits[0]


        boundary_rows[
            boundary_index
        ][
            "engineered_scar_name"
        ] = scar_name

        boundary_rows[
            boundary_index
        ][
            "engineered_scar_sequence"
        ] = scar_sequence


        bseq = unique_boundaries[
            boundary[
                "boundary_sequence_hash"
            ]
        ]


        if scar_sequence not in bseq:

            raise RuntimeError(
                f"{cid}/{scar_name}: "
                "scar not contained in B sequence"
            )


        scar_rows.append(
            {
                "construct_id":
                    cid,

                "scar_name":
                    scar_name,

                "scar_sequence":
                    scar_sequence,

                "module_uid":
                    boundary[
                        "module_uid"
                    ],

                "boundary_uid":
                    boundary[
                        "boundary_uid"
                    ],

                "construct_nt_start":
                    scar_start,

                "construct_nt_end":
                    scar_end,

                "boundary_sequence_hash":
                    boundary[
                        "boundary_sequence_hash"
                    ],
            }
        )


if len(scar_rows) != EXPECTED_SCARS:

    raise RuntimeError(
        "Expected 212 scar mappings"
    )


if (
    len(
        {
            x[
                "boundary_uid"
            ]
            for x in scar_rows
        }
    )
    !=
    EXPECTED_SCARS
):

    raise RuntimeError(
        "Scar B occurrences are not unique"
    )


# ======================================================================
# 7. DOMAIN ESM-C REUSE AUDIT
# ======================================================================

domain_hashes = set(
    occ[
        "domain_sequence_hash"
    ]
)


embedding_reuse = {
    "embedding_store_exists":
        False,

    "required_domain_hashes":
        len(
            domain_hashes
        ),

    "missing_domain_hashes":
        None,

    "obsolete_domain_hashes":
        None,

    "can_reuse_existing_domain_esmc":
        False,
}


if OLD_DOMAIN_EMBEDDINGS.exists():

    payload = torch.load(
        OLD_DOMAIN_EMBEDDINGS,
        map_location="cpu",
        weights_only=False,
    )


    embedded_ids = set(
        payload[
            "ids"
        ]
    )


    missing = (
        domain_hashes
        -
        embedded_ids
    )


    obsolete = (
        embedded_ids
        -
        domain_hashes
    )


    embedding_reuse = {
        "embedding_store_exists":
            True,

        "required_domain_hashes":
            len(
                domain_hashes
            ),

        "embedded_domain_hashes":
            len(
                embedded_ids
            ),

        "missing_domain_hashes":
            len(
                missing
            ),

        "obsolete_domain_hashes":
            len(
                obsolete
            ),

        "can_reuse_existing_domain_esmc":
            len(
                missing
            )
            ==
            0,
    }


# ======================================================================
# 8. WRITE OUTPUT
# ======================================================================

pd.DataFrame(
    structured_modules
).to_csv(
    TMP
    / "structured_modules.tsv.gz",
    sep="\t",
    index=False,
    compression="gzip",
)


pd.DataFrame(
    structured_domains
).to_csv(
    TMP
    / "structured_domains.tsv.gz",
    sep="\t",
    index=False,
    compression="gzip",
)


pd.DataFrame(
    boundary_rows
).to_csv(
    TMP
    / "internal_boundaries.tsv.gz",
    sep="\t",
    index=False,
    compression="gzip",
)


pd.DataFrame(
    scar_rows
).to_csv(
    TMP
    / "scar_boundary_map.tsv.gz",
    sep="\t",
    index=False,
    compression="gzip",
)


domain_seq_map = {
    row[
        "domain_sequence_hash"
    ]:
        row[
            "domain_sequence"
        ]

    for row in all_occurrences
}


write_fasta_gz(
    TMP
    / "unique_domains.fasta.gz",
    domain_seq_map,
)


write_fasta_gz(
    TMP
    / "unique_modules.fasta.gz",
    unique_modules,
)


write_fasta_gz(
    TMP
    / "unique_internal_boundaries.fasta.gz",
    unique_boundaries,
)


summary = {
    "constructs":
        106,

    "functional_modules":
        len(
            structured_modules
        ),

    "domain_occurrences":
        len(
            structured_domains
        ),

    "internal_boundary_occurrences":
        len(
            boundary_rows
        ),

    "true_inter_module_transition_count_expected":
        (
            len(
                structured_modules
            )
            -
            106
        ),

    "engineered_scar_occurrences":
        len(
            scar_rows
        ),

    "unique_domain_sequences":
        len(
            domain_seq_map
        ),

    "unique_module_sequences":
        len(
            unique_modules
        ),

    "unique_boundary_sequences":
        len(
            unique_boundaries
        ),

    "domain_type_counts":
        dict(
            counts
        ),

    "domain_esmc_reuse":
        embedding_reuse,

    "boundary_flank_policy_aa":
        64,
}


with (
    TMP
    / "build_summary.json"
).open("w") as handle:

    json.dump(
        summary,
        handle,
        indent=2,
        sort_keys=True,
    )

    handle.write("\n")


# ======================================================================
# 9. HARD FINAL CONTRACT
# ======================================================================

assert len(
    structured_modules
) == 530

assert len(
    structured_domains
) == 1854

assert len(
    boundary_rows
) == 1324

assert (
    len(
        structured_modules
    )
    -
    106
    ==
    424
)

assert len(
    scar_rows
) == 212

assert (
    max(
        2
        *
        int(
            x[
                "component_count"
            ]
        )
        -
        1

        for x in structured_modules
    )
    <=
    11
)


# ======================================================================
# 10. COMMIT
# ======================================================================

if OUT.exists():

    backup = OUT.with_name(
        OUT.name
        +
        "_backup"
    )

    if backup.exists():
        shutil.rmtree(
            backup
        )

    OUT.rename(
        backup
    )


TMP.rename(
    OUT
)


print()
print("=" * 110)
print("STRUCTURED V1.3 FINAL CONTRACT")
print("=" * 110)

print(
    "constructs:                 106"
)

print(
    "modules:                    530"
)

print(
    "D occurrences:             1854"
)

print(
    "B occurrences:             1324"
)

print(
    "expected true J positions:  424"
)

print(
    "scar B occurrences:         212"
)

print(
    "unique D sequences:",
    len(
        domain_seq_map
    ),
)

print(
    "unique M sequences:",
    len(
        unique_modules
    ),
)

print(
    "unique B sequences:",
    len(
        unique_boundaries
    ),
)

print()
print(
    "DOMAIN ESM-C REUSE:"
)

for k, v in (
    embedding_reuse.items()
):

    print(
        f"  {k}: {v}"
    )


print()
print(
    "OUTPUT:"
)

print(
    OUT
)

print()
print("=" * 110)
print("BODE PHASE-2 STRUCTURED V1.3: FULL PASS")
print("=" * 110)
