from __future__ import annotations

import torch

from neuralps.data.collate_v1_1 import (
    RouteATrainCollatorV1_1,
)

from neuralps.data.structured_module_batch_v1_1 import (
    StructuredModuleBatchV1_1,
    StructuredModuleBatchBuilderV1_1,
)

from neuralps.data.path_routing_batch_v2 import (
    PathRoutingBatchV2,
    PathRoutingBatchBuilderV2,
)


ESMC_DIM = 1152


class RouteATrainCollatorV2:
    """
    Route-A V2 bidirectional structured collator.

    Preserves the complete V1.1 forward collation contract:

        fixed left [B]
        right candidates [B,K]
        one observed physical junction [B]

    and adds:

        reverse left candidates [B,K]
        fixed right [B]

    Both directions are augmented with V2 entry/core/exit routing.

    IMPORTANT:
    - no taxonomy enters model tensors
    - no domain-type labels enter model tensors
    - no substrate labels enter model tensors
    - the physical junction is collated ONCE by the inherited
      V1.0/V1.1 collator and shared by both directions
    - candidate index 0 remains the observed natural partner
      in both directions
    """

    def __init__(
        self,
        *,
        module_embedding_store,
        structured_batch_builder: (
            StructuredModuleBatchBuilderV1_1
        ),
        path_routing_builder: (
            PathRoutingBatchBuilderV2
        ),
    ) -> None:

        self.module_embedding_store = (
            module_embedding_store
        )

        self.structured_batch_builder = (
            structured_batch_builder
        )

        self.path_routing_builder = (
            path_routing_builder
        )

        # ----------------------------------------------------------
        # Exact V1.1 forward behavior.
        # ----------------------------------------------------------

        self.forward_collator = (
            RouteATrainCollatorV1_1(
                module_embedding_store=(
                    module_embedding_store
                ),
                structured_batch_builder=(
                    structured_batch_builder
                ),
            )
        )


    @staticmethod
    def _add_fixed_routing(
        *,
        result: dict,
        prefix: str,
        routing: PathRoutingBatchV2,
        batch_size: int,
    ) -> None:

        if (
            routing.entry_mask.shape[0]
            != batch_size
        ):
            raise RuntimeError(
                f"{prefix}: routing batch mismatch"
            )

        result[
            f"{prefix}_entry_mask"
        ] = routing.entry_mask

        result[
            f"{prefix}_core_mask"
        ] = routing.core_mask

        result[
            f"{prefix}_exit_mask"
        ] = routing.exit_mask


        result[
            f"{prefix}_entry_available"
        ] = routing.entry_available

        result[
            f"{prefix}_core_available"
        ] = routing.core_available

        result[
            f"{prefix}_exit_available"
        ] = routing.exit_available


        result[
            f"{prefix}_initial_token_index"
        ] = routing.initial_token_index

        result[
            f"{prefix}_terminal_token_index"
        ] = routing.terminal_token_index

        result[
            f"{prefix}_a_token_index"
        ] = routing.a_token_index

        result[
            f"{prefix}_carrier_token_index"
        ] = routing.carrier_token_index


    @staticmethod
    def _add_candidate_routing(
        *,
        result: dict,
        prefix: str,
        routing: PathRoutingBatchV2,
        batch_size: int,
        candidate_count: int,
    ) -> None:

        expected_flat = (
            batch_size
            * candidate_count
        )

        if (
            routing.entry_mask.shape[0]
            != expected_flat
        ):
            raise RuntimeError(
                f"{prefix}: flattened routing batch mismatch"
            )

        token_width = (
            routing.entry_mask.shape[1]
        )


        # ----------------------------------------------------------
        # Path masks [B*K,T] -> [B,K,T]
        # ----------------------------------------------------------

        for name in (
            "entry_mask",
            "core_mask",
            "exit_mask",
        ):

            tensor = getattr(
                routing,
                name,
            )

            result[
                f"{prefix}_{name}"
            ] = tensor.reshape(
                batch_size,
                candidate_count,
                token_width,
            )


        # ----------------------------------------------------------
        # Availability/index vectors [B*K] -> [B,K]
        # ----------------------------------------------------------

        for name in (
            "entry_available",
            "core_available",
            "exit_available",
            "initial_token_index",
            "terminal_token_index",
            "a_token_index",
            "carrier_token_index",
        ):

            tensor = getattr(
                routing,
                name,
            )

            result[
                f"{prefix}_{name}"
            ] = tensor.reshape(
                batch_size,
                candidate_count,
            )


    @staticmethod
    def _validate_fp32_finite(
        result: dict,
        keys,
    ) -> None:

        for key in keys:

            tensor = result[
                key
            ]

            if (
                tensor.dtype
                != torch.float32
            ):
                raise RuntimeError(
                    f"{key} must be FP32"
                )

            if not torch.isfinite(
                tensor
            ).all():
                raise RuntimeError(
                    f"{key} contains non-finite values"
                )


    def __call__(
        self,
        items,
    ):

        batch_size = len(
            items
        )

        if batch_size == 0:
            raise ValueError(
                "Empty V2 batch"
            )


        # ==========================================================
        # Candidate-panel contract.
        # ==========================================================

        candidate_count = len(
            items[0][
                "candidate_right_module_uids"
            ]
        )

        if candidate_count < 2:
            raise RuntimeError(
                "At least two candidates required"
            )


        for item in items:

            forward_uid_count = len(
                item[
                    "candidate_right_module_uids"
                ]
            )

            forward_hash_count = len(
                item[
                    "candidate_right_hashes"
                ]
            )

            reverse_uid_count = len(
                item[
                    "candidate_left_module_uids"
                ]
            )

            reverse_hash_count = len(
                item[
                    "candidate_left_hashes"
                ]
            )

            if not (
                forward_uid_count
                == forward_hash_count
                == reverse_uid_count
                == reverse_hash_count
                == candidate_count
            ):
                raise RuntimeError(
                    "Forward/reverse candidate-count mismatch"
                )


        # ==========================================================
        # Exact V1.1 forward collation.
        #
        # Includes ONE inherited physical junction tensor set.
        # ==========================================================

        result = (
            self.forward_collator(
                items
            )
        )


        # ==========================================================
        # Reconstruct lightweight forward StructuredModuleBatch
        # wrappers around ALREADY-COLLATED V1.1 tensors.
        #
        # No embeddings are reloaded here.
        # ==========================================================

        forward_left_uids = tuple(
            result[
                "left_module_uids"
            ]
        )

        forward_right_uids_nested = tuple(
            tuple(
                row
            )
            for row in result[
                "right_module_uids"
            ]
        )

        forward_right_uids_flat = tuple(
            uid
            for row in forward_right_uids_nested
            for uid in row
        )


        forward_left_struct = (
            StructuredModuleBatchV1_1(
                whole_module_esmc=(
                    result[
                        "left_whole_module_esmc"
                    ]
                ),
                token_esmc=(
                    result[
                        "left_token_esmc"
                    ]
                ),
                token_kind=(
                    result[
                        "left_token_kind"
                    ]
                ),
                token_padding_mask=(
                    result[
                        "left_token_padding_mask"
                    ]
                ),
                token_count=(
                    result[
                        "left_token_count"
                    ]
                ),
                module_uids=(
                    forward_left_uids
                ),
            )
        )


        forward_right_width = (
            result[
                "right_token_esmc"
            ].shape[2]
        )


        forward_right_struct = (
            StructuredModuleBatchV1_1(
                whole_module_esmc=(
                    result[
                        "right_whole_module_esmc"
                    ]
                    .reshape(
                        batch_size
                        * candidate_count,
                        ESMC_DIM,
                    )
                ),
                token_esmc=(
                    result[
                        "right_token_esmc"
                    ]
                    .reshape(
                        batch_size
                        * candidate_count,
                        forward_right_width,
                        ESMC_DIM,
                    )
                ),
                token_kind=(
                    result[
                        "right_token_kind"
                    ]
                    .reshape(
                        batch_size
                        * candidate_count,
                        forward_right_width,
                    )
                ),
                token_padding_mask=(
                    result[
                        "right_token_padding_mask"
                    ]
                    .reshape(
                        batch_size
                        * candidate_count,
                        forward_right_width,
                    )
                ),
                token_count=(
                    result[
                        "right_token_count"
                    ]
                    .reshape(
                        batch_size
                        * candidate_count,
                    )
                ),
                module_uids=(
                    forward_right_uids_flat
                ),
            )
        )


        forward_left_struct.validate_fast()
        forward_right_struct.validate_fast()


        # ==========================================================
        # V2 routing on the already-existing forward tensors.
        # ==========================================================

        forward_left_routing = (
            self.path_routing_builder.build(
                forward_left_struct
            )
        )

        forward_right_routing = (
            self.path_routing_builder.build(
                forward_right_struct
            )
        )


        self._add_fixed_routing(
            result=result,
            prefix="left",
            routing=(
                forward_left_routing
            ),
            batch_size=batch_size,
        )


        self._add_candidate_routing(
            result=result,
            prefix="right",
            routing=(
                forward_right_routing
            ),
            batch_size=batch_size,
            candidate_count=(
                candidate_count
            ),
        )


        # ==========================================================
        # Reverse occurrence identities.
        # ==========================================================

        reverse_left_uids_nested = tuple(
            tuple(
                item[
                    "candidate_left_module_uids"
                ]
            )
            for item in items
        )

        reverse_left_hashes_nested = tuple(
            tuple(
                item[
                    "candidate_left_hashes"
                ]
            )
            for item in items
        )

        reverse_left_uids_flat = tuple(
            uid
            for row in reverse_left_uids_nested
            for uid in row
        )


        reverse_right_uids = tuple(
            item[
                "right_module_uid"
            ]
            for item in items
        )

        reverse_right_hashes = tuple(
            item[
                "right_sequence_hash"
            ]
            for item in items
        )


        # ==========================================================
        # Strong reverse UID <-> whole-sequence-hash validation.
        # ==========================================================

        structured_store = (
            self.structured_batch_builder
            .structured_store
        )


        for item in items:

            right_uid = (
                item[
                    "right_module_uid"
                ]
            )

            right_hash = (
                item[
                    "right_sequence_hash"
                ]
            )

            if (
                structured_store.get(
                    right_uid
                ).module_sequence_hash
                != right_hash
            ):
                raise RuntimeError(
                    "Reverse fixed-right UID/hash mismatch"
                )


            for uid, sequence_hash in zip(
                item[
                    "candidate_left_module_uids"
                ],
                item[
                    "candidate_left_hashes"
                ],
            ):

                if (
                    structured_store.get(
                        uid
                    ).module_sequence_hash
                    != sequence_hash
                ):
                    raise RuntimeError(
                        "Reverse left candidate UID/hash mismatch"
                    )


        # ==========================================================
        # Candidate-zero cross-direction invariants.
        # ==========================================================

        for b, item in enumerate(
            items
        ):

            if (
                item[
                    "candidate_left_module_uids"
                ][0]
                != item[
                    "left_module_uid"
                ]
            ):
                raise RuntimeError(
                    "Reverse candidate 0 != observed left UID"
                )

            if (
                item[
                    "candidate_right_module_uids"
                ][0]
                != item[
                    "right_module_uid"
                ]
            ):
                raise RuntimeError(
                    "Forward candidate 0 != observed right UID"
                )

            if (
                item[
                    "candidate_left_hashes"
                ][0]
                != item[
                    "left_sequence_hash"
                ]
            ):
                raise RuntimeError(
                    "Reverse candidate 0 != observed left hash"
                )

            if (
                item[
                    "candidate_right_hashes"
                ][0]
                != item[
                    "right_sequence_hash"
                ]
            ):
                raise RuntimeError(
                    "Forward candidate 0 != observed right hash"
                )


        # ==========================================================
        # Build NEW reverse structured tensors.
        #
        # First implementation favors transparent correctness.
        # Positive modules may therefore be represented in both
        # directional branches. We can deduplicate later.
        # ==========================================================

        reverse_left_struct = (
            self.structured_batch_builder.build(
                reverse_left_uids_flat
            )
        )

        reverse_right_struct = (
            self.structured_batch_builder.build(
                reverse_right_uids
            )
        )


        reverse_left_struct.validate_fast()
        reverse_right_struct.validate_fast()


        # ==========================================================
        # V2 routing for reverse tensors.
        # ==========================================================

        reverse_left_routing = (
            self.path_routing_builder.build(
                reverse_left_struct
            )
        )

        reverse_right_routing = (
            self.path_routing_builder.build(
                reverse_right_struct
            )
        )


        # ==========================================================
        # Preserve reverse candidate dimension.
        # ==========================================================

        reverse_left_width = (
            reverse_left_struct
            .token_esmc
            .shape[1]
        )


        result[
            "reverse_left_whole_module_esmc"
        ] = (
            reverse_left_struct
            .whole_module_esmc
            .reshape(
                batch_size,
                candidate_count,
                ESMC_DIM,
            )
        )

        result[
            "reverse_left_token_esmc"
        ] = (
            reverse_left_struct
            .token_esmc
            .reshape(
                batch_size,
                candidate_count,
                reverse_left_width,
                ESMC_DIM,
            )
        )

        result[
            "reverse_left_token_kind"
        ] = (
            reverse_left_struct
            .token_kind
            .reshape(
                batch_size,
                candidate_count,
                reverse_left_width,
            )
        )

        result[
            "reverse_left_token_padding_mask"
        ] = (
            reverse_left_struct
            .token_padding_mask
            .reshape(
                batch_size,
                candidate_count,
                reverse_left_width,
            )
        )

        result[
            "reverse_left_token_count"
        ] = (
            reverse_left_struct
            .token_count
            .reshape(
                batch_size,
                candidate_count,
            )
        )


        # ==========================================================
        # Fixed reverse-right tensors.
        # ==========================================================

        result[
            "reverse_right_whole_module_esmc"
        ] = (
            reverse_right_struct
            .whole_module_esmc
        )

        result[
            "reverse_right_token_esmc"
        ] = (
            reverse_right_struct
            .token_esmc
        )

        result[
            "reverse_right_token_kind"
        ] = (
            reverse_right_struct
            .token_kind
        )

        result[
            "reverse_right_token_padding_mask"
        ] = (
            reverse_right_struct
            .token_padding_mask
        )

        result[
            "reverse_right_token_count"
        ] = (
            reverse_right_struct
            .token_count
        )


        # ==========================================================
        # Reverse routing tensors.
        # ==========================================================

        self._add_candidate_routing(
            result=result,
            prefix="reverse_left",
            routing=(
                reverse_left_routing
            ),
            batch_size=batch_size,
            candidate_count=(
                candidate_count
            ),
        )


        self._add_fixed_routing(
            result=result,
            prefix="reverse_right",
            routing=(
                reverse_right_routing
            ),
            batch_size=batch_size,
        )


        # ==========================================================
        # Non-tensor identity metadata.
        # ==========================================================

        result[
            "reverse_left_module_uids"
        ] = (
            reverse_left_uids_nested
        )

        result[
            "reverse_right_module_uids"
        ] = (
            reverse_right_uids
        )


        result[
            "reverse_left_hashes"
        ] = (
            reverse_left_hashes_nested
        )

        result[
            "reverse_right_hashes"
        ] = (
            reverse_right_hashes
        )


        # ==========================================================
        # Explicit bidirectional targets.
        #
        # Preserve old "target" for V1.1 compatibility.
        # ==========================================================

        if (
            "target"
            not in result
        ):
            raise RuntimeError(
                "Inherited collator did not return target"
            )

        target = result[
            "target"
        ]

        if (
            not torch.is_tensor(
                target
            )
            or target.shape
            != (
                batch_size,
            )
        ):
            raise RuntimeError(
                "Unexpected inherited target shape"
            )

        if not torch.all(
            target
            == 0
        ):
            raise RuntimeError(
                "V2 requires observed candidate at index 0"
            )


        result[
            "forward_target"
        ] = target

        result[
            "reverse_target"
        ] = torch.zeros_like(
            target
        )


        # ==========================================================
        # Final structural shape checks.
        # ==========================================================

        if (
            result[
                "left_whole_module_esmc"
            ].shape
            != (
                batch_size,
                ESMC_DIM,
            )
        ):
            raise RuntimeError(
                "Forward fixed-left whole shape mismatch"
            )


        if (
            result[
                "right_whole_module_esmc"
            ].shape
            != (
                batch_size,
                candidate_count,
                ESMC_DIM,
            )
        ):
            raise RuntimeError(
                "Forward candidate-right whole shape mismatch"
            )


        if (
            result[
                "reverse_left_whole_module_esmc"
            ].shape
            != (
                batch_size,
                candidate_count,
                ESMC_DIM,
            )
        ):
            raise RuntimeError(
                "Reverse candidate-left whole shape mismatch"
            )


        if (
            result[
                "reverse_right_whole_module_esmc"
            ].shape
            != (
                batch_size,
                ESMC_DIM,
            )
        ):
            raise RuntimeError(
                "Reverse fixed-right whole shape mismatch"
            )


        # ==========================================================
        # Candidate-zero whole-ESMC parity.
        #
        # Same biological occurrence/sequence is represented in
        # the two directional views.
        # ==========================================================

        if not torch.equal(
            result[
                "left_whole_module_esmc"
            ],
            result[
                "reverse_left_whole_module_esmc"
            ][:, 0, :],
        ):
            raise RuntimeError(
                "Observed left whole-ESMC mismatch "
                "between forward/reverse views"
            )


        if not torch.equal(
            result[
                "right_whole_module_esmc"
            ][:, 0, :],
            result[
                "reverse_right_whole_module_esmc"
            ],
        ):
            raise RuntimeError(
                "Observed right whole-ESMC mismatch "
                "between forward/reverse views"
            )


        # ==========================================================
        # FP32 / finite embedding contracts.
        # ==========================================================

        self._validate_fp32_finite(
            result,
            (
                "left_whole_module_esmc",
                "left_token_esmc",
                "right_whole_module_esmc",
                "right_token_esmc",
                "reverse_left_whole_module_esmc",
                "reverse_left_token_esmc",
                "reverse_right_whole_module_esmc",
                "reverse_right_token_esmc",
            ),
        )


        return result
