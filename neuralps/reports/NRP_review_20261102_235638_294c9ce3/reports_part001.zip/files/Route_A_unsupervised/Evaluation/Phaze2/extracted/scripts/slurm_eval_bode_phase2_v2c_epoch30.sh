#!/bin/bash
#SBATCH --account=nef@h100
#SBATCH --partition=gpu_p6
#SBATCH --constraint=h100
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=8
#SBATCH --hint=nomultithread
#SBATCH --time=01:00:00
#SBATCH --job-name=bode2_v2c_e30
#SBATCH --output=logs/bode_phase2_v1_3/v2c_%j.out
#SBATCH --error=logs/bode_phase2_v1_3/v2c_%j.err

set -euo pipefail

module purge
module load arch/h100
module load pytorch-gpu/py3/2.8.0

cd "$WORK/NeurALPSv2"

source "$WORK/NeurALPSv2/envs/esmc/bin/activate"

export PYTHONPATH="$WORK/NeurALPSv2/src:${PYTHONPATH:-}"

python -u \
  scripts/evaluate_bode_phase2_v2c_epoch30.py
