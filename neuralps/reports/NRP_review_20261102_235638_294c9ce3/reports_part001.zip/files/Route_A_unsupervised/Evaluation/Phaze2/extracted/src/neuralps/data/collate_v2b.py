from __future__ import annotations

import torch

from neuralps.data.collate_v2 import (
    RouteATrainCollatorV2,
)

from neuralps.data.structured_module_batch_v1_1 import (
    StructuredModuleBatchBuilderV1_1,
)

from neuralps.data.path_routing_batch_v2 import (
    PathRoutingBatchBuilderV2,
)

from neuralps.data.assembly_context_store_v2 import (
    AssemblyContextStoreV2,
)

from neuralps.data.assembly_index_batch_v2 import (
    AssemblyIndexBatchBuilderV2,
)

from neuralps.data.junction_store import (
    JunctionStore,
)

from neuralps.data.assembly_junction_batch_v2 import (
    AssemblyJunctionBatchBuilderV2,
)


class RouteATrainCollatorV2B(
    RouteATrainCollatorV2
):
    """
    Route-A V2-B collator.

    The complete V2-A local batch is inherited unchanged.

    V2-B appends ONE flattened natural assembly representation
    per query:

        natural modules:
            flattened occurrence-specific structured modules

        natural junctions:
            flattened inherited V1.x raw junction tensors

        assembly coordinates:
            CSR-style offsets
            query J index
            candidate M replacement slots
            far-side J_MASK slots

    IMPORTANT:

    - Candidate-conditioned full assemblies are NOT materialized.
    - Candidate module panels already produced by V2-A are reused.
    - Natural assembly module/junction states are encoded once.
    - Candidate replacement happens later in the neural model.
    - J_MASK replacement happens later in the neural model.
    - No taxonomy/source/accession features enter neural tensors.
    """

    def __init__(
        self,
        *,
        module_embedding_store,

        structured_batch_builder: (
            StructuredModuleBatchBuilderV1_1
        ),

        path_routing_builder: (
            PathRoutingBatchBuilderV2
        ),

        assembly_store: (
            AssemblyContextStoreV2
        ),

        junction_store: (
            JunctionStore
        ),
    ) -> None:

        super().__init__(
            module_embedding_store=(
                module_embedding_store
            ),

            structured_batch_builder=(
                structured_batch_builder
            ),

            path_routing_builder=(
                path_routing_builder
            ),
        )

        self.assembly_store = (
            assembly_store
        )

        self.junction_store = (
            junction_store
        )

        self.assembly_index_builder = (
            AssemblyIndexBatchBuilderV2(
                assembly_store
            )
        )

        self.assembly_junction_builder = (
            AssemblyJunctionBatchBuilderV2(
                junction_store
            )
        )


    def __call__(
        self,
        items,
    ):

        if not items:
            raise ValueError(
                "Empty V2-B batch"
            )

        # ==========================================================
        # EXACT V2-A local branch.
        # ==========================================================

        result = super().__call__(
            items
        )

        batch_size = len(
            items
        )


        # ==========================================================
        # Compact assembly coordinates.
        # ==========================================================

        assembly_index = (
            self.assembly_index_builder.build(
                items
            )
        )

        assembly_index.validate()


        if (
            len(
                assembly_index
                .assembly_line_ids
            )
            != batch_size
        ):
            raise RuntimeError(
                "V2-B assembly batch-size mismatch"
            )


        # ==========================================================
        # Natural assembly modules.
        #
        # IMPORTANT:
        # Only Σ M_b modules are resolved.
        # There is NO candidate dimension here.
        # ==========================================================

        assembly_modules = (
            self
            .structured_batch_builder
            .build(
                assembly_index
                .module_uids_flat
            )
        )

        assembly_modules.validate_fast()


        if (
            tuple(
                assembly_modules.module_uids
            )
            != assembly_index
            .module_uids_flat
        ):
            raise RuntimeError(
                "V2-B assembly module UID ordering drift"
            )


        # Strong UID -> whole-sequence-hash consistency.
        structured_store = (
            self
            .structured_batch_builder
            .structured_store
        )

        for uid, expected_hash in zip(
            assembly_index
            .module_uids_flat,

            assembly_index
            .module_hashes_flat,
        ):

            observed_hash = (
                structured_store
                .get(uid)
                .module_sequence_hash
            )

            if observed_hash != expected_hash:
                raise RuntimeError(
                    "V2-B assembly module "
                    "UID/hash mismatch"
                )


        # ==========================================================
        # Natural assembly physical junctions.
        #
        # Only Σ(M_b - 1) junctions are tensorized.
        # ==========================================================

        assembly_junctions = (
            self
            .assembly_junction_builder
            .build(
                assembly_index
                .transition_uids_flat
            )
        )

        assembly_junctions.validate()


        if (
            assembly_junctions
            .transition_uids
            != assembly_index
            .transition_uids_flat
        ):
            raise RuntimeError(
                "V2-B assembly transition ordering drift"
            )


        # ==========================================================
        # Query-junction equivalence.
        #
        # The same physical query seam appears:
        #
        #   A) in the inherited V2-A query tensors
        #   B) inside the flattened natural assembly
        #
        # They MUST encode identically before any neural layer.
        # ==========================================================

        for b in range(
            batch_size
        ):

            q = int(
                assembly_index
                .query_transition_index[b]
            )

            flat_j = (
                int(
                    assembly_index
                    .transition_offset[b]
                )
                + q
            )


            if (
                assembly_index
                .transition_uids_flat[
                    flat_j
                ]
                != items[b][
                    "transition_uid"
                ]
            ):
                raise RuntimeError(
                    "V2-B flattened query "
                    "transition UID mismatch"
                )


            # Junction kind must match exactly.
            if not torch.equal(
                result[
                    "junction_kind"
                ][b],

                assembly_junctions
                .junction_kind[
                    flat_j
                ],
            ):
                raise RuntimeError(
                    "V2-A/V2-B query junction "
                    "kind mismatch"
                )


            # Length feature must match exactly.
            if not torch.equal(
                result[
                    "junction_log_length"
                ][b],

                assembly_junctions
                .junction_log_length[
                    flat_j
                ],
            ):
                raise RuntimeError(
                    "V2-A/V2-B query junction "
                    "length-feature mismatch"
                )


            local_tokens = (
                result[
                    "junction_aa"
                ][b][
                    result[
                        "junction_mask"
                    ][b]
                ]
            )

            assembly_tokens = (
                assembly_junctions
                .junction_aa[
                    flat_j
                ][
                    assembly_junctions
                    .junction_mask[
                        flat_j
                    ]
                ]
            )


            if not torch.equal(
                local_tokens,
                assembly_tokens,
            ):
                raise RuntimeError(
                    "V2-A/V2-B query junction "
                    "AA-token mismatch"
                )


        # ==========================================================
        # Append natural-assembly structured module tensors.
        # ==========================================================

        result[
            "assembly_module_whole_module_esmc"
        ] = (
            assembly_modules
            .whole_module_esmc
        )

        result[
            "assembly_module_token_esmc"
        ] = (
            assembly_modules
            .token_esmc
        )

        result[
            "assembly_module_token_kind"
        ] = (
            assembly_modules
            .token_kind
        )

        result[
            "assembly_module_token_padding_mask"
        ] = (
            assembly_modules
            .token_padding_mask
        )

        result[
            "assembly_module_token_count"
        ] = (
            assembly_modules
            .token_count
        )


        # ==========================================================
        # Append natural-assembly junction tensors.
        # ==========================================================

        result[
            "assembly_junction_aa"
        ] = (
            assembly_junctions
            .junction_aa
        )

        result[
            "assembly_junction_mask"
        ] = (
            assembly_junctions
            .junction_mask
        )

        result[
            "assembly_junction_kind"
        ] = (
            assembly_junctions
            .junction_kind
        )

        result[
            "assembly_junction_length"
        ] = (
            assembly_junctions
            .junction_length
        )

        result[
            "assembly_junction_log_length"
        ] = (
            assembly_junctions
            .junction_log_length
        )


        # ==========================================================
        # Compact assembly indexing tensors.
        # ==========================================================

        result[
            "assembly_module_offset"
        ] = (
            assembly_index
            .module_offset
        )

        result[
            "assembly_transition_offset"
        ] = (
            assembly_index
            .transition_offset
        )

        result[
            "assembly_module_count"
        ] = (
            assembly_index
            .module_count
        )

        result[
            "assembly_query_transition_index"
        ] = (
            assembly_index
            .query_transition_index
        )

        result[
            "assembly_forward_candidate_module_index"
        ] = (
            assembly_index
            .forward_candidate_module_index
        )

        result[
            "assembly_reverse_candidate_module_index"
        ] = (
            assembly_index
            .reverse_candidate_module_index
        )

        result[
            "assembly_forward_far_mask_transition_index"
        ] = (
            assembly_index
            .forward_far_mask_transition_index
        )

        result[
            "assembly_reverse_far_mask_transition_index"
        ] = (
            assembly_index
            .reverse_far_mask_transition_index
        )


        # ==========================================================
        # Audit/lookup identities only.
        #
        # These are NOT neural features.
        # ==========================================================

        result[
            "assembly_line_ids"
        ] = (
            assembly_index
            .assembly_line_ids
        )

        result[
            "assembly_module_uids"
        ] = (
            assembly_index
            .module_uids_flat
        )

        result[
            "assembly_module_hashes"
        ] = (
            assembly_index
            .module_hashes_flat
        )

        result[
            "assembly_transition_uids"
        ] = (
            assembly_index
            .transition_uids_flat
        )

        result[
            "assembly_transition_types"
        ] = (
            assembly_index
            .transition_types_flat
        )


        # ==========================================================
        # Final dimensional checks.
        # ==========================================================

        total_modules = int(
            assembly_index
            .module_offset[-1]
        )

        total_transitions = int(
            assembly_index
            .transition_offset[-1]
        )


        if (
            result[
                "assembly_module_whole_module_esmc"
            ].shape[0]
            != total_modules
        ):
            raise RuntimeError(
                "V2-B flattened module tensor "
                "count mismatch"
            )


        if (
            result[
                "assembly_junction_aa"
            ].shape[0]
            != total_transitions
        ):
            raise RuntimeError(
                "V2-B flattened junction tensor "
                "count mismatch"
            )


        if (
            total_transitions
            != total_modules
            - batch_size
        ):
            raise RuntimeError(
                "V2-B batch M/J invariant failed"
            )


        # V2-B collator itself must not create any candidate-expanded
        # assembly tensor.
        #
        # Candidate dimension appears only inside the model.
        forbidden = (
            "assembly_candidate_tokens",
            "assembly_forward_candidate_tokens",
            "assembly_reverse_candidate_tokens",
        )

        for key in forbidden:

            if key in result:
                raise RuntimeError(
                    "Candidate-expanded assembly "
                    "tensor leaked into collator"
                )


        return result
