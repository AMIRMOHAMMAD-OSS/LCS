#!/usr/bin/env python3

from pathlib import Path
from collections import Counter, defaultdict
import hashlib

import pandas as pd
from Bio import SeqIO


# ======================================================================
# PATHS
# ======================================================================

ROOT = Path.cwd()

STRUCTURED = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "structured_v1_3"
)

MODULES = (
    STRUCTURED
    / "structured_modules.tsv.gz"
)

DOMAINS = (
    STRUCTURED
    / "structured_domains.tsv.gz"
)

GB = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "genbank_raw"
    / "106 NRPS sequences.gb"
)


EXPECTED_CONSTRUCTS = 106
EXPECTED_MODULES = 530
EXPECTED_TRANSITIONS = 424


# ======================================================================
# HELPERS
# ======================================================================

def construct_name(rec):

    name = str(
        rec.name
    )

    if "_(" in name:

        return name.split(
            "_(",
            1,
        )[0]

    return name


def sha256_sequence(seq):

    return hashlib.sha256(
        str(seq).encode(
            "ascii"
        )
    ).hexdigest()


# ======================================================================
# LOAD
# ======================================================================

modules = pd.read_csv(
    MODULES,
    sep="\t",
)

domains = pd.read_csv(
    DOMAINS,
    sep="\t",
)

records = list(
    SeqIO.parse(
        str(GB),
        "genbank",
    )
)


record_by_construct = {
    construct_name(rec):
        rec

    for rec in records
}


print("=" * 120)
print("BODE PHASE-2 V1.3 TRUE INTER-MODULE J AUDIT")
print("=" * 120)


print(
    "constructs:",
    len(
        record_by_construct
    ),
)

print(
    "modules:",
    len(
        modules
    ),
)

print(
    "domains:",
    len(
        domains
    ),
)


if len(
    record_by_construct
) != EXPECTED_CONSTRUCTS:

    raise RuntimeError(
        "Construct count mismatch"
    )


if len(
    modules
) != EXPECTED_MODULES:

    raise RuntimeError(
        "Module count mismatch"
    )


# ======================================================================
# DOMAIN ENDPOINTS PER MODULE
# ======================================================================

domains_by_module = {}


for module_uid, group in domains.groupby(
    "module_uid",
    sort=False,
):

    group = group.sort_values(
        "component_order"
    )


    orders = (
        group[
            "component_order"
        ]
        .astype(int)
        .tolist()
    )


    if orders != list(
        range(
            1,
            len(group) + 1,
        )
    ):

        raise RuntimeError(
            f"{module_uid}: "
            "non-contiguous component order"
        )


    domains_by_module[
        str(module_uid)
    ] = {
        "first":
            group.iloc[0],

        "last":
            group.iloc[-1],
    }


if len(
    domains_by_module
) != EXPECTED_MODULES:

    raise RuntimeError(
        "Domain/module mapping mismatch"
    )


# ======================================================================
# BUILD ALL 424 ADJACENT MODULE PAIRS
# ======================================================================

rows = []

problems = []


modules_by_construct = defaultdict(
    list
)


for row in modules.to_dict(
    "records"
):

    modules_by_construct[
        str(
            row[
                "construct_id"
            ]
        )
    ].append(
        row
    )


if len(
    modules_by_construct
) != EXPECTED_CONSTRUCTS:

    raise RuntimeError(
        "Structured module construct count mismatch"
    )


for construct_id in sorted(
    modules_by_construct
):

    rec = record_by_construct[
        construct_id
    ]


    ms = sorted(
        modules_by_construct[
            construct_id
        ],
        key=lambda x:
            int(
                x[
                    "module_index"
                ]
            ),
    )


    if len(ms) != 5:

        raise RuntimeError(
            f"{construct_id}: expected 5 modules"
        )


    observed_indices = [
        int(
            x[
                "module_index"
            ]
        )
        for x in ms
    ]


    if observed_indices != [
        1,
        2,
        3,
        4,
        5,
    ]:

        raise RuntimeError(
            f"{construct_id}: bad module order "
            f"{observed_indices}"
        )


    for interface_index in range(
        1,
        5,
    ):

        left = ms[
            interface_index
            -
            1
        ]

        right = ms[
            interface_index
        ]


        left_uid = str(
            left[
                "module_uid"
            ]
        )

        right_uid = str(
            right[
                "module_uid"
            ]
        )


        left_terminal = (
            domains_by_module[
                left_uid
            ][
                "last"
            ]
        )

        right_initial = (
            domains_by_module[
                right_uid
            ][
                "first"
            ]
        )


        left_end = int(
            left_terminal[
                "construct_nt_end_0based_exclusive"
            ]
        )

        right_start = int(
            right_initial[
                "construct_nt_start_0based"
            ]
        )


        nt_gap_length = (
            right_start
            -
            left_end
        )


        nonoverlap = (
            nt_gap_length
            >=
            0
        )


        codon_aligned = (
            nonoverlap
            and
            (
                nt_gap_length
                %
                3
                ==
                0
            )
        )


        junction_sequence = None

        contains_stop = None


        if codon_aligned:

            nt_seq = rec.seq[
                left_end:
                right_start
            ]


            junction_sequence = str(
                nt_seq.translate()
            )


            contains_stop = (
                "*"
                in
                junction_sequence
            )


        same_source_locus = (
            str(
                left_terminal[
                    "source_locus_tag"
                ]
            )
            ==
            str(
                right_initial[
                    "source_locus_tag"
                ]
            )
        )


        if (
            codon_aligned
            and
            not contains_stop
        ):

            status = (
                "TRANSLATED_CONTIGUOUS_CANDIDATE"
            )

            seq = junction_sequence

            seq_hash = sha256_sequence(
                seq
            )

            aa_length = len(
                seq
            )

        else:

            status = (
                "UNRESOLVED_AS_RAW_LINKER"
            )

            seq = ""

            seq_hash = ""

            aa_length = None


        transition_uid = (
            f"{construct_id}"
            f"|transition="
            f"{interface_index}-"
            f"{interface_index + 1}"
        )


        result = {
            "construct_id":
                construct_id,

            "interface_index":
                interface_index,

            "transition_uid":
                transition_uid,

            "left_module_uid":
                left_uid,

            "right_module_uid":
                right_uid,

            "left_module_index":
                interface_index,

            "right_module_index":
                interface_index + 1,

            "left_terminal_domain_type":
                str(
                    left_terminal[
                        "domain_type"
                    ]
                ),

            "right_initial_domain_type":
                str(
                    right_initial[
                        "domain_type"
                    ]
                ),

            "left_source_locus":
                str(
                    left_terminal[
                        "source_locus_tag"
                    ]
                ),

            "right_source_locus":
                str(
                    right_initial[
                        "source_locus_tag"
                    ]
                ),

            "same_source_locus":
                same_source_locus,

            "left_end_nt":
                left_end,

            "right_start_nt":
                right_start,

            "gap_nt":
                nt_gap_length,

            "nonoverlap":
                nonoverlap,

            "codon_aligned":
                codon_aligned,

            "contains_stop":
                contains_stop,

            "junction_length_aa":
                aa_length,

            "junction_sequence_hash":
                seq_hash,

            "status":
                status,
        }


        rows.append(
            result
        )


        if (
            status
            !=
            "TRANSLATED_CONTIGUOUS_CANDIDATE"
        ):

            problems.append(
                result
            )


# ======================================================================
# GLOBAL CONTRACT
# ======================================================================

if len(rows) != EXPECTED_TRANSITIONS:

    raise RuntimeError(
        f"Expected {EXPECTED_TRANSITIONS} transitions, "
        f"got {len(rows)}"
    )


df = pd.DataFrame(
    rows
)


print()
print("=" * 120)
print("GLOBAL J GEOMETRY")
print("=" * 120)


print(
    "transitions:",
    len(df),
)


print(
    "module-pair distribution:"
)

print(
    df.groupby(
        [
            "left_module_index",
            "right_module_index",
        ]
    )
    .size()
    .to_string()
)


print()
print(
    "status:"
)

print(
    df[
        "status"
    ]
    .value_counts()
    .to_string()
)


print()
print(
    "same source locus:",
    Counter(
        df[
            "same_source_locus"
        ].tolist()
    ),
)


print(
    "non-overlapping:",
    Counter(
        df[
            "nonoverlap"
        ].tolist()
    ),
)


print(
    "codon aligned:",
    Counter(
        df[
            "codon_aligned"
        ].tolist()
    ),
)


translated = df[
    df[
        "status"
    ]
    ==
    "TRANSLATED_CONTIGUOUS_CANDIDATE"
]


if len(translated):

    lengths = (
        translated[
            "junction_length_aa"
        ]
        .astype(int)
    )


    print()
    print(
        "translated J AA length range:",
        int(
            lengths.min()
        ),
        "-",
        int(
            lengths.max()
        ),
    )


    print(
        "translated J AA length median:",
        float(
            lengths.median()
        ),
    )


    print(
        "unique translated J sequences:",
        translated[
            "junction_sequence_hash"
        ].nunique(),
    )


# ======================================================================
# DOMAIN ARCHITECTURE AT J
# ======================================================================

print()
print("=" * 120)
print("J ENDPOINT ARCHITECTURES")
print("=" * 120)


print(
    df.groupby(
        [
            "left_terminal_domain_type",
            "right_initial_domain_type",
        ]
    )
    .size()
    .sort_values(
        ascending=False
    )
    .to_string()
)


# ======================================================================
# SOURCE-LOCUS CHANGES BY MODULE PAIR
# ======================================================================

print()
print("=" * 120)
print("SOURCE LOCUS CONTINUITY BY MODULE PAIR")
print("=" * 120)


for pair, group in df.groupby(
    [
        "left_module_index",
        "right_module_index",
    ]
):

    print()
    print(
        f"M{pair[0]} -> M{pair[1]}"
    )

    print(
        Counter(
            group[
                "same_source_locus"
            ].tolist()
        )
    )


# ======================================================================
# FIRST TRANSITIONS
# ======================================================================

print()
print("=" * 120)
print("FIRST 30 J POSITIONS")
print("=" * 120)


display_columns = [
    "construct_id",
    "interface_index",
    "left_terminal_domain_type",
    "right_initial_domain_type",
    "left_source_locus",
    "right_source_locus",
    "gap_nt",
    "junction_length_aa",
    "status",
]


print(
    df[
        display_columns
    ]
    .head(30)
    .to_string(
        index=False
    )
)


# ======================================================================
# PROBLEMS — DO NOT SILENTLY CONVERT THESE INTO CHAIN BREAKS
# ======================================================================

print()
print("=" * 120)
print("UNRESOLVED J POSITIONS")
print("=" * 120)


print(
    "count:",
    len(
        problems
    ),
)


if problems:

    problem_df = pd.DataFrame(
        problems
    )


    print(
        problem_df[
            display_columns
            +
            [
                "left_end_nt",
                "right_start_nt",
                "codon_aligned",
                "contains_stop",
            ]
        ]
        .head(100)
        .to_string(
            index=False
        )
    )


# ======================================================================
# IMPORTANT FINAL RESULT
# ======================================================================

print()
print("=" * 120)
print("FINAL J AUDIT")
print("=" * 120)


print(
    "530 modules - 106 constructs =",
    530 - 106,
    "J positions"
)


print(
    "observed J positions:",
    len(df),
)


print(
    "directly translated contiguous candidates:",
    len(translated),
)


print(
    "unresolved:",
    len(problems),
)


if len(problems) == 0:

    print()
    print(
        "ALL 424 INTER-MODULE POSITIONS ARE "
        "DIRECTLY TRANSLATABLE FROM THE ENGINEERED "
        "CONSTRUCT GEOMETRY."
    )

    print()
    print(
        "BODE PHASE-2 V1.3 J GEOMETRY: FULL PASS"
    )

else:

    print()
    print(
        "BODE PHASE-2 V1.3 J GEOMETRY: "
        "REQUIRES EXPLICIT RESOLUTION"
    )

    print(
        "No chain-break semantics have been assigned "
        "automatically."
    )
