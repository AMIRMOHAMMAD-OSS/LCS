from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import torch

from neuralps.data.embedding_store import (
    EmbeddingStore,
)

from neuralps.data.structured_module_store_v1_1 import (
    StructuredModuleStoreV1_1,
)


DOMAIN_KIND = 0
BOUNDARY_KIND = 1

ESMC_DIM = 1152
MAX_BIOLOGICAL_TOKENS = 11
MAX_TOKENS_WITH_CLS = 12


@dataclass(
    frozen=True,
    slots=True,
)
class StructuredModuleBatchV1_1:
    """
    Frozen ESMC inputs for the trainable V1-A module encoder.

    whole_module_esmc:
        [B, 1152]

    token_esmc:
        [B, T, 1152], where T <= 11 and excludes CLS.

    token_kind:
        [B, T]
        0 = domain
        1 = internal boundary

        Padding values are arbitrary because padding positions are
        identified exclusively through token_padding_mask.

    token_padding_mask:
        [B, T]
        True = padding
        False = biological token

    token_count:
        [B]
        number of biological D/B tokens before padding.

    module_uids:
        original occurrence-level module identifiers.
    """

    whole_module_esmc: torch.Tensor

    token_esmc: torch.Tensor

    token_kind: torch.Tensor

    token_padding_mask: torch.Tensor

    token_count: torch.Tensor

    module_uids: tuple[str, ...]

    def validate(
        self,
    ) -> None:

        batch_size = len(
            self.module_uids
        )

        if batch_size <= 0:
            raise RuntimeError(
                "Structured module batch is empty"
            )

        if self.whole_module_esmc.shape != (
            batch_size,
            ESMC_DIM,
        ):
            raise RuntimeError(
                "Unexpected whole-module ESMC shape: "
                f"{tuple(self.whole_module_esmc.shape)}"
            )

        if self.token_esmc.ndim != 3:
            raise RuntimeError(
                "token_esmc must have rank 3"
            )

        if self.token_esmc.shape[0] != batch_size:
            raise RuntimeError(
                "token_esmc batch dimension mismatch"
            )

        if (
            self.token_esmc.shape[2]
            != ESMC_DIM
        ):
            raise RuntimeError(
                "token_esmc ESMC dimension mismatch"
            )

        token_width = (
            self.token_esmc.shape[1]
        )

        if not (
            1
            <= token_width
            <= MAX_BIOLOGICAL_TOKENS
        ):
            raise RuntimeError(
                "Invalid biological token width: "
                f"{token_width}"
            )

        if self.token_kind.shape != (
            batch_size,
            token_width,
        ):
            raise RuntimeError(
                "token_kind shape mismatch"
            )

        if (
            self.token_padding_mask.shape
            != (
                batch_size,
                token_width,
            )
        ):
            raise RuntimeError(
                "token_padding_mask shape mismatch"
            )

        if self.token_count.shape != (
            batch_size,
        ):
            raise RuntimeError(
                "token_count shape mismatch"
            )

        if (
            self.whole_module_esmc.dtype
            != torch.float32
        ):
            raise RuntimeError(
                "whole-module ESMC must be FP32"
            )

        if (
            self.token_esmc.dtype
            != torch.float32
        ):
            raise RuntimeError(
                "token ESMC must be FP32"
            )

        if (
            self.token_kind.dtype
            != torch.long
        ):
            raise RuntimeError(
                "token_kind must be torch.long"
            )

        if (
            self.token_padding_mask.dtype
            != torch.bool
        ):
            raise RuntimeError(
                "token_padding_mask must be bool"
            )

        if (
            self.token_count.dtype
            != torch.long
        ):
            raise RuntimeError(
                "token_count must be torch.long"
            )

        if not torch.isfinite(
            self.whole_module_esmc
        ).all():
            raise RuntimeError(
                "Non-finite whole-module ESMC"
            )

        if not torch.isfinite(
            self.token_esmc
        ).all():
            raise RuntimeError(
                "Non-finite token ESMC"
            )

        observed_counts = (
            (~self.token_padding_mask)
            .sum(
                dim=1
            )
            .to(
                dtype=torch.long
            )
        )

        if not torch.equal(
            observed_counts,
            self.token_count,
        ):
            raise RuntimeError(
                "token_count does not match padding mask"
            )

        if torch.any(
            self.token_count < 3
        ):
            # Every frozen v1.1 module contains at least:
            # D1 B1 D2
            raise RuntimeError(
                "A structured module contains fewer than "
                "3 biological tokens"
            )

        if torch.any(
            self.token_count
            > MAX_BIOLOGICAL_TOKENS
        ):
            raise RuntimeError(
                "A structured module exceeds frozen "
                "V1-A token limit"
            )


    def validate_fast(
        self,
    ) -> None:
        """
        GPU-safe structural validation.

        Unlike validate(), this performs no value scans or tensor
        reductions. Full value/finite validation remains in the CPU
        batch builder before tensors are transferred to the accelerator.
        """

        batch_size = len(
            self.module_uids
        )

        if batch_size <= 0:
            raise RuntimeError(
                "Structured module batch is empty"
            )

        if self.whole_module_esmc.shape != (
            batch_size,
            ESMC_DIM,
        ):
            raise RuntimeError(
                "Unexpected whole-module ESMC shape"
            )

        if self.token_esmc.ndim != 3:
            raise RuntimeError(
                "token_esmc must have rank 3"
            )

        if (
            self.token_esmc.shape[0]
            != batch_size
        ):
            raise RuntimeError(
                "token_esmc batch mismatch"
            )

        if (
            self.token_esmc.shape[2]
            != ESMC_DIM
        ):
            raise RuntimeError(
                "token_esmc ESMC dimension mismatch"
            )

        token_width = (
            self.token_esmc.shape[1]
        )

        if not (
            1
            <= token_width
            <= MAX_BIOLOGICAL_TOKENS
        ):
            raise RuntimeError(
                "Invalid biological token width"
            )

        expected_2d = (
            batch_size,
            token_width,
        )

        if (
            self.token_kind.shape
            != expected_2d
        ):
            raise RuntimeError(
                "token_kind shape mismatch"
            )

        if (
            self.token_padding_mask.shape
            != expected_2d
        ):
            raise RuntimeError(
                "token_padding_mask shape mismatch"
            )

        if self.token_count.shape != (
            batch_size,
        ):
            raise RuntimeError(
                "token_count shape mismatch"
            )

        if (
            self.whole_module_esmc.dtype
            != torch.float32
        ):
            raise RuntimeError(
                "whole-module ESMC must be FP32"
            )

        if (
            self.token_esmc.dtype
            != torch.float32
        ):
            raise RuntimeError(
                "token ESMC must be FP32"
            )

        if (
            self.token_kind.dtype
            != torch.long
        ):
            raise RuntimeError(
                "token_kind must be torch.long"
            )

        if (
            self.token_padding_mask.dtype
            != torch.bool
        ):
            raise RuntimeError(
                "token_padding_mask must be bool"
            )

        if (
            self.token_count.dtype
            != torch.long
        ):
            raise RuntimeError(
                "token_count must be torch.long"
            )


class StructuredModuleBatchBuilderV1_1:
    """
    Resolve occurrence-specific module structure into frozen ESMC tensors.

    The structured decomposition remains keyed by module_uid.
    Whole-module ESMC vectors remain deduplicated by sequence hash.
    """

    def __init__(
        self,
        *,
        structured_store: StructuredModuleStoreV1_1,
        module_embedding_store: EmbeddingStore,
        domain_embedding_store: EmbeddingStore,
        boundary_embedding_store: EmbeddingStore,
    ) -> None:

        self.structured_store = (
            structured_store
        )

        self.module_embedding_store = (
            module_embedding_store
        )

        self.domain_embedding_store = (
            domain_embedding_store
        )

        self.boundary_embedding_store = (
            boundary_embedding_store
        )


    def build(
        self,
        module_uids: Sequence[str],
        *,
        whole_module_esmc: torch.Tensor | None = None,
    ) -> StructuredModuleBatchV1_1:

        module_uids = tuple(
            str(uid)
            for uid in module_uids
        )

        if not module_uids:
            raise ValueError(
                "module_uids cannot be empty"
            )

        records = [
            self.structured_store.get(
                uid
            )
            for uid in module_uids
        ]

        batch_size = len(
            records
        )

        token_counts = [
            len(
                record.tokens
            )
            for record in records
        ]

        max_token_count = max(
            token_counts
        )

        if (
            max_token_count
            > MAX_BIOLOGICAL_TOKENS
        ):
            raise RuntimeError(
                "Frozen V1-A biological token limit "
                f"exceeded: {max_token_count}"
            )


        # --------------------------------------------------------------
        # Whole-module ESMC.
        # --------------------------------------------------------------

        module_hashes = [
            record.module_sequence_hash
            for record in records
        ]

        if whole_module_esmc is None:

            whole_module_esmc = (
                self.module_embedding_store.get_many(
                    module_hashes
                )
            )

        else:

            if not torch.is_tensor(
                whole_module_esmc
            ):
                whole_module_esmc = (
                    torch.as_tensor(
                        whole_module_esmc
                    )
                )

            whole_module_esmc = (
                whole_module_esmc.float()
            )

            if whole_module_esmc.shape != (
                batch_size,
                ESMC_DIM,
            ):
                raise RuntimeError(
                    "Preloaded whole-module ESMC "
                    "shape mismatch: "
                    f"{tuple(whole_module_esmc.shape)}"
                )

            if not torch.isfinite(
                whole_module_esmc
            ).all():
                raise RuntimeError(
                    "Preloaded whole-module ESMC "
                    "contains non-finite values"
                )


        # --------------------------------------------------------------
        # Flatten ordered D/B hashes while preserving exact occurrence
        # structure.
        # --------------------------------------------------------------

        domain_hashes = []

        boundary_hashes = []

        token_layout = []

        for batch_index, record in enumerate(
            records
        ):

            for token_index, token in enumerate(
                record.tokens
            ):

                if (
                    token.position
                    != token_index + 1
                ):
                    raise RuntimeError(
                        f"{record.module_uid}: "
                        "non-contiguous structured token position"
                    )

                if token.kind == "domain":

                    source_index = len(
                        domain_hashes
                    )

                    domain_hashes.append(
                        token.sequence_hash
                    )

                    kind_id = (
                        DOMAIN_KIND
                    )

                elif token.kind == "boundary":

                    source_index = len(
                        boundary_hashes
                    )

                    boundary_hashes.append(
                        token.sequence_hash
                    )

                    kind_id = (
                        BOUNDARY_KIND
                    )

                else:
                    raise RuntimeError(
                        "Unknown structured token kind: "
                        f"{token.kind}"
                    )

                token_layout.append(
                    (
                        batch_index,
                        token_index,
                        kind_id,
                        source_index,
                    )
                )


        domain_esmc = (
            self.domain_embedding_store.get_many(
                domain_hashes
            )
        )

        boundary_esmc = (
            self.boundary_embedding_store.get_many(
                boundary_hashes
            )
        )


        # --------------------------------------------------------------
        # Padded biological-token batch.
        # CLS is inserted by the trainable encoder, not here.
        # --------------------------------------------------------------

        token_esmc = torch.zeros(
            (
                batch_size,
                max_token_count,
                ESMC_DIM,
            ),
            dtype=torch.float32,
        )

        token_kind = torch.zeros(
            (
                batch_size,
                max_token_count,
            ),
            dtype=torch.long,
        )

        token_padding_mask = torch.ones(
            (
                batch_size,
                max_token_count,
            ),
            dtype=torch.bool,
        )


        for (
            batch_index,
            token_index,
            kind_id,
            source_index,
        ) in token_layout:

            if kind_id == DOMAIN_KIND:

                vector = domain_esmc[
                    source_index
                ]

            else:

                vector = boundary_esmc[
                    source_index
                ]


            token_esmc[
                batch_index,
                token_index,
            ] = vector

            token_kind[
                batch_index,
                token_index,
            ] = kind_id

            token_padding_mask[
                batch_index,
                token_index,
            ] = False


        token_count = torch.tensor(
            token_counts,
            dtype=torch.long,
        )


        result = StructuredModuleBatchV1_1(
            whole_module_esmc=(
                whole_module_esmc
            ),
            token_esmc=(
                token_esmc
            ),
            token_kind=(
                token_kind
            ),
            token_padding_mask=(
                token_padding_mask
            ),
            token_count=(
                token_count
            ),
            module_uids=(
                module_uids
            ),
        )

        result.validate()

        return result
