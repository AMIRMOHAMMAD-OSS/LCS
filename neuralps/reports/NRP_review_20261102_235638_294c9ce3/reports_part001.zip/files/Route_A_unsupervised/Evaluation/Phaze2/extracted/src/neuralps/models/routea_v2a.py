from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from neuralps.data.structured_module_batch_v1_1 import (
    StructuredModuleBatchV1_1,
)
from neuralps.data.path_routing_batch_v2 import (
    PathRoutingBatchV2,
)

from neuralps.models.structured_module_encoder_v2 import (
    StructuredModuleEncoderV2,
)
from neuralps.models.path_attention_pool_v2 import (
    PathAttentionPoolV2,
)
from neuralps.models.edge_encoder_v2 import (
    EdgeEncoderV2,
)
from neuralps.models.local_interface_scorer_v2 import (
    LocalInterfaceScorerV2,
)
from neuralps.models.routea_v1_0 import (
    JunctionEncoder,
)


MODEL_DIM = 256
JUNCTION_DIM = 64


@dataclass(
    frozen=True,
    slots=True,
)
class RouteAV2AOutput:
    """
    Bidirectional local Route-A V2-A retrieval scores.

    forward_scores:
        [B,K]
        fixed observed left, candidate rights

    reverse_scores:
        [B,K]
        candidate lefts, fixed observed right

    z_junction:
        [B,64]
        ONE inherited physical junction representation shared
        between both retrieval directions.
    """

    forward_scores: torch.Tensor
    reverse_scores: torch.Tensor
    z_junction: torch.Tensor


class RouteAV2A(nn.Module):
    """
    Route-A V2-A local bidirectional model.

    No assembly-level contextualization.
    No feedback.
    No recycling.
    No taxonomy/domain-type categorical neural inputs.

    Components are shared between forward and reverse retrieval.
    """

    def __init__(
        self,
        *,
        module_encoder: StructuredModuleEncoderV2 | None = None,
        path_pool: PathAttentionPoolV2 | None = None,
        junction_encoder: JunctionEncoder | None = None,
        edge_encoder: EdgeEncoderV2 | None = None,
        local_scorer: LocalInterfaceScorerV2 | None = None,
    ) -> None:

        super().__init__()

        self.module_encoder = (
            StructuredModuleEncoderV2()
            if module_encoder is None
            else module_encoder
        )

        self.path_pool = (
            PathAttentionPoolV2()
            if path_pool is None
            else path_pool
        )

        self.junction_encoder = (
            JunctionEncoder()
            if junction_encoder is None
            else junction_encoder
        )

        self.edge_encoder = (
            EdgeEncoderV2()
            if edge_encoder is None
            else edge_encoder
        )

        self.local_scorer = (
            LocalInterfaceScorerV2()
            if local_scorer is None
            else local_scorer
        )


    @staticmethod
    def _gather_domain_state(
        token_z: torch.Tensor,
        token_index: torch.Tensor,
        *,
        name: str,
    ) -> torch.Tensor:

        if token_z.ndim != 3:
            raise RuntimeError(
                f"{name}: token_z must have shape [N,T,D]"
            )

        batch_size = token_z.shape[0]

        if token_index.shape != (
            batch_size,
        ):
            raise RuntimeError(
                f"{name}: token index shape mismatch"
            )

        if torch.any(
            token_index < 0
        ):
            raise RuntimeError(
                f"{name}: negative token index"
            )

        if torch.any(
            token_index
            >= token_z.shape[1]
        ):
            raise RuntimeError(
                f"{name}: token index outside token width"
            )

        rows = torch.arange(
            batch_size,
            device=token_z.device,
            dtype=torch.long,
        )

        result = token_z[
            rows,
            token_index,
            :,
        ]

        if result.shape != (
            batch_size,
            MODEL_DIM,
        ):
            raise RuntimeError(
                f"{name}: gathered state shape mismatch"
            )

        return result


    def forward(
        self,
        *,
        forward_left_structured: StructuredModuleBatchV1_1,
        forward_left_routing: PathRoutingBatchV2,

        forward_right_structured: StructuredModuleBatchV1_1,
        forward_right_routing: PathRoutingBatchV2,

        reverse_left_structured: StructuredModuleBatchV1_1,
        reverse_left_routing: PathRoutingBatchV2,

        reverse_right_structured: StructuredModuleBatchV1_1,
        reverse_right_routing: PathRoutingBatchV2,

        junction_aa: torch.Tensor,
        junction_mask: torch.Tensor,
        junction_kind: torch.Tensor,
        junction_log_length: torch.Tensor,

        batch_size: int,
        candidate_count: int,
    ) -> RouteAV2AOutput:

        if batch_size <= 0:
            raise RuntimeError(
                "batch_size must be positive"
            )

        if candidate_count < 2:
            raise RuntimeError(
                "candidate_count must be >= 2"
            )


        # ==========================================================
        # Exact shared V1.1-derived module encoder.
        # ==========================================================

        fwd_left = self.module_encoder(
            forward_left_structured
        )

        fwd_right = self.module_encoder(
            forward_right_structured
        )

        rev_left = self.module_encoder(
            reverse_left_structured
        )

        rev_right = self.module_encoder(
            reverse_right_structured
        )


        # ==========================================================
        # Shared biological path pooling.
        # ==========================================================

        fwd_left_paths = self.path_pool(
            fwd_left,
            forward_left_routing,
        )

        fwd_right_paths = self.path_pool(
            fwd_right,
            forward_right_routing,
        )

        rev_left_paths = self.path_pool(
            rev_left,
            reverse_left_routing,
        )

        rev_right_paths = self.path_pool(
            rev_right,
            reverse_right_routing,
        )


        # ==========================================================
        # Universal physical interface-facing domain states.
        # ==========================================================

        fwd_left_terminal = (
            self._gather_domain_state(
                fwd_left.token_z,
                forward_left_routing
                .terminal_token_index,
                name="forward left terminal",
            )
            .unsqueeze(1)
            .expand(
                -1,
                candidate_count,
                -1,
            )
        )

        fwd_right_initial = (
            self._gather_domain_state(
                fwd_right.token_z,
                forward_right_routing
                .initial_token_index,
                name="forward right initial",
            )
            .reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )


        rev_left_terminal = (
            self._gather_domain_state(
                rev_left.token_z,
                reverse_left_routing
                .terminal_token_index,
                name="reverse left terminal",
            )
            .reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )

        rev_right_initial = (
            self._gather_domain_state(
                rev_right.token_z,
                reverse_right_routing
                .initial_token_index,
                name="reverse right initial",
            )
            .unsqueeze(1)
            .expand(
                -1,
                candidate_count,
                -1,
            )
        )


        # ==========================================================
        # ONE inherited physical junction encoding.
        # ==========================================================

        z_junction = self.junction_encoder(
            junction_aa,
            junction_mask,
            junction_kind,
            junction_log_length,
        )

        if z_junction.shape != (
            batch_size,
            JUNCTION_DIM,
        ):
            raise RuntimeError(
                "Unexpected inherited junction shape"
            )


        # ==========================================================
        # Shared universal edge encoder.
        # ==========================================================

        forward_edge = self.edge_encoder(
            left_terminal_z=(
                fwd_left_terminal
            ),
            z_junction=(
                z_junction
            ),
            right_initial_z=(
                fwd_right_initial
            ),
        )

        reverse_edge = self.edge_encoder(
            left_terminal_z=(
                rev_left_terminal
            ),
            z_junction=(
                z_junction
            ),
            right_initial_z=(
                rev_right_initial
            ),
        )


        # ==========================================================
        # Ordered forward retrieval.
        # ==========================================================

        forward_scores = self.local_scorer(
            left_module_z=(
                fwd_left.module_z
            ),
            left_core_z=(
                fwd_left_paths.core_z
            ),
            left_exit_z=(
                fwd_left_paths.exit_z
            ),

            z_edge=(
                forward_edge
            ),

            right_entry_z=(
                fwd_right_paths.entry_z
                .reshape(
                    batch_size,
                    candidate_count,
                    MODEL_DIM,
                )
            ),
            right_core_z=(
                fwd_right_paths.core_z
                .reshape(
                    batch_size,
                    candidate_count,
                    MODEL_DIM,
                )
            ),
            right_module_z=(
                fwd_right.module_z
                .reshape(
                    batch_size,
                    candidate_count,
                    MODEL_DIM,
                )
            ),
        )


        # ==========================================================
        # Ordered reverse retrieval.
        # ==========================================================

        reverse_scores = self.local_scorer(
            left_module_z=(
                rev_left.module_z
                .reshape(
                    batch_size,
                    candidate_count,
                    MODEL_DIM,
                )
            ),
            left_core_z=(
                rev_left_paths.core_z
                .reshape(
                    batch_size,
                    candidate_count,
                    MODEL_DIM,
                )
            ),
            left_exit_z=(
                rev_left_paths.exit_z
                .reshape(
                    batch_size,
                    candidate_count,
                    MODEL_DIM,
                )
            ),

            z_edge=(
                reverse_edge
            ),

            right_entry_z=(
                rev_right_paths.entry_z
            ),
            right_core_z=(
                rev_right_paths.core_z
            ),
            right_module_z=(
                rev_right.module_z
            ),
        )


        expected = (
            batch_size,
            candidate_count,
        )

        if (
            forward_scores.shape
            != expected
        ):
            raise RuntimeError(
                "Forward V2-A score shape mismatch"
            )

        if (
            reverse_scores.shape
            != expected
        ):
            raise RuntimeError(
                "Reverse V2-A score shape mismatch"
            )

        if not torch.isfinite(
            forward_scores
        ).all():
            raise RuntimeError(
                "Non-finite forward V2-A scores"
            )

        if not torch.isfinite(
            reverse_scores
        ).all():
            raise RuntimeError(
                "Non-finite reverse V2-A scores"
            )


        return RouteAV2AOutput(
            forward_scores=(
                forward_scores
            ),
            reverse_scores=(
                reverse_scores
            ),
            z_junction=(
                z_junction
            ),
        )
