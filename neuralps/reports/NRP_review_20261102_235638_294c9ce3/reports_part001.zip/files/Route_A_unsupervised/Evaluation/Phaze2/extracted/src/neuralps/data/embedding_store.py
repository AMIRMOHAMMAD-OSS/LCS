from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
import gzip

import torch


class EmbeddingStore:
    """
    Read-only lookup for sharded Route-A ESMC embeddings.

    Biological occurrences remain separate in the dataset.
    Exact duplicate amino-acid sequences reuse one cached ESMC vector.
    """

    def __init__(
        self,
        root: str | Path,
        kind: str,
        max_cached_shards: int = 4,
    ):
        if kind not in {"domains", "modules", "boundaries"}:
            raise ValueError(
                "kind must be 'domains', 'modules', or 'boundaries'"
            )

        self.root = Path(root)
        self.kind = kind
        self.max_cached_shards = int(max_cached_shards)

        if not self.root.exists():
            raise FileNotFoundError(self.root)

        self.index_path = (
            self.root
            / f"{kind}_embedding_index.tsv.gz"
        )

        if not self.index_path.exists():
            raise FileNotFoundError(self.index_path)

        self._index = {}
        self._cache = OrderedDict()

        self._load_index()

    def _load_index(self):
        with gzip.open(self.index_path, "rt") as f:
            header = next(f).rstrip("\n").split("\t")

            expected = [
                "sequence_hash",
                "length",
                "shard_index",
                "row_index",
            ]

            if header != expected:
                raise RuntimeError(
                    f"Unexpected {self.kind} embedding index "
                    f"header: {header}"
                )

            for line in f:
                sequence_hash, length, shard, row = (
                    line.rstrip("\n").split("\t")
                )

                if sequence_hash in self._index:
                    raise RuntimeError(
                        f"Duplicate sequence hash in embedding "
                        f"index: {sequence_hash}"
                    )

                self._index[sequence_hash] = (
                    int(length),
                    int(shard),
                    int(row),
                )

    def __len__(self):
        return len(self._index)

    @property
    def embedding_dim(self):
        return 1152

    def contains(self, sequence_hash: str) -> bool:
        return sequence_hash in self._index

    def length(self, sequence_hash: str) -> int:
        return self._index[sequence_hash][0]

    def _shard_path(self, shard_index: int) -> Path:
        return (
            self.root
            / f"{self.kind}_shard_{shard_index:04d}.pt"
        )

    def _load_shard(self, shard_index: int):
        if shard_index in self._cache:
            payload = self._cache.pop(shard_index)
            self._cache[shard_index] = payload
            return payload

        path = self._shard_path(shard_index)

        if not path.exists():
            raise FileNotFoundError(path)

        payload = torch.load(
            path,
            map_location="cpu",
            weights_only=False,
        )

        if payload["kind"] != self.kind:
            raise RuntimeError(
                f"Shard kind mismatch in {path}"
            )

        embeddings = payload["embeddings"]

        if embeddings.ndim != 2:
            raise RuntimeError(
                f"Invalid embedding tensor in {path}"
            )

        if embeddings.shape[1] != 1152:
            raise RuntimeError(
                f"Unexpected embedding dimension "
                f"{embeddings.shape[1]} in {path}"
            )

        if embeddings.dtype != torch.float32:
            raise RuntimeError(
                f"Expected float32 embeddings in {path}, "
                f"found {embeddings.dtype}"
            )

        self._cache[shard_index] = payload

        while len(self._cache) > self.max_cached_shards:
            self._cache.popitem(last=False)

        return payload

    def get(
        self,
        sequence_hash: str,
        clone: bool = False,
    ) -> torch.Tensor:
        try:
            length, shard_index, row_index = (
                self._index[sequence_hash]
            )
        except KeyError:
            raise KeyError(
                f"Unknown {self.kind} sequence hash: "
                f"{sequence_hash}"
            )

        payload = self._load_shard(shard_index)

        if payload["sequence_hashes"][row_index] != sequence_hash:
            raise RuntimeError(
                "Embedding index / shard hash mismatch "
                f"for {sequence_hash}"
            )

        if int(payload["lengths"][row_index]) != length:
            raise RuntimeError(
                "Embedding index / shard length mismatch "
                f"for {sequence_hash}"
            )

        vector = payload["embeddings"][row_index]

        return vector.clone() if clone else vector

    def get_many(
        self,
        sequence_hashes: list[str],
    ) -> torch.Tensor:
        """
        Return [N, 1152] CPU float32 tensor.

        Lookups are grouped by shard to reduce repeated I/O.
        """

        if not sequence_hashes:
            return torch.empty(
                (0, self.embedding_dim),
                dtype=torch.float32,
            )

        requests = {}

        for output_row, sequence_hash in enumerate(
            sequence_hashes
        ):
            if sequence_hash not in self._index:
                raise KeyError(
                    f"Unknown {self.kind} sequence hash: "
                    f"{sequence_hash}"
                )

            length, shard_index, row_index = (
                self._index[sequence_hash]
            )

            requests.setdefault(
                shard_index,
                [],
            ).append(
                (
                    output_row,
                    row_index,
                    sequence_hash,
                    length,
                )
            )

        output = torch.empty(
            (
                len(sequence_hashes),
                self.embedding_dim,
            ),
            dtype=torch.float32,
        )

        for shard_index, items in requests.items():
            payload = self._load_shard(shard_index)

            for (
                output_row,
                row_index,
                sequence_hash,
                expected_length,
            ) in items:
                if (
                    payload["sequence_hashes"][row_index]
                    != sequence_hash
                ):
                    raise RuntimeError(
                        "Embedding index / shard mismatch"
                    )

                if (
                    int(payload["lengths"][row_index])
                    != expected_length
                ):
                    raise RuntimeError(
                        "Embedding length mismatch"
                    )

                output[output_row] = (
                    payload["embeddings"][row_index]
                )

        return output

    def cache_info(self):
        return {
            "kind": self.kind,
            "indexed_sequences": len(self),
            "cached_shards": list(self._cache.keys()),
            "max_cached_shards": self.max_cached_shards,
        }
