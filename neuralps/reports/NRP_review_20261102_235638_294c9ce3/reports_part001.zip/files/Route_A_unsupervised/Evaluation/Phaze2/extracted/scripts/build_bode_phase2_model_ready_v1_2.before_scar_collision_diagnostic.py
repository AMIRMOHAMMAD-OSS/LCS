#!/usr/bin/env python3
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
import gzip
import hashlib
import json
import os
import re
import shutil

import pandas as pd
from Bio import SeqIO


# ======================================================================
# CONFIGURATION
# ======================================================================

ROOT = (
    Path(os.environ["WORK"])
    / "NeurALPSv2"
)

GB = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "genbank_raw"
    / "106 NRPS sequences.gb"
)

STRUCTURED_V12 = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "structured_v1_2"
)

DOMAIN_TABLE = (
    STRUCTURED_V12
    / "structured_domains.tsv"
)

DOMAIN_FASTA = (
    STRUCTURED_V12
    / "structured_domain_sequences.fasta"
)

CONSTRUCT_TABLE = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "v2_validation"
    / "engineered_constructs.tsv.gz"
)

FINAL_OUT = (
    ROOT
    / "data"
    / "bode_engineered_confidential"
    / "processed"
    / "model_ready_v1_2"
)

TMP_OUT = (
    FINAL_OUT.parent
    / f".model_ready_v1_2.tmp.{os.getpid()}"
)


SPLIT = "external_bode_phase2"

BOUNDARY_FLANK_AA = 64

EXPECTED_CONSTRUCTS = 106
EXPECTED_DOMAINS = 1807
EXPECTED_UNIQUE_DOMAIN_HASHES = 122
EXPECTED_MODULES = 517
EXPECTED_BOUNDARIES = 1290
EXPECTED_TRANSITIONS = 411
EXPECTED_SCARS = 212


REAL_DOMAIN_TYPES = {
    "AMP-binding",
    "PCP",
    "Epimerization",
    "TIGR01720",
    "Condensation_Starter",
    "Condensation_LCL",
    "Condensation_DCL",
    "Condensation_Dual",
}


# ======================================================================
# HELPERS
# ======================================================================

def one(
    qualifiers,
    key,
    default="",
):
    values = qualifiers.get(
        key,
        [],
    )

    return (
        str(values[0])
        if values
        else default
    )


def clean_aa(
    seq,
):
    return re.sub(
        r"[^A-Za-z]",
        "",
        str(seq),
    ).upper()


def sha256_sequence(
    seq,
):
    return hashlib.sha256(
        str(seq).encode(
            "ascii"
        )
    ).hexdigest()


def canonical_construct_id(
    record,
):
    name = str(
        record.name
    )

    if "_(" in name:
        return name.split(
            "_(",
            1,
        )[0]

    return name


def raw_domain_type(
    qualifiers,
):

    if (
        one(
            qualifiers,
            "aSTool",
        )
        !=
        "nrps_pks_domains"
    ):
        return None


    raw = one(
        qualifiers,
        "aSDomain",
    ).strip()


    subtypes = [
        str(x).strip()
        for x in qualifiers.get(
            "domain_subtypes",
            [],
        )
        if str(x).strip()
    ]


    if raw == "Condensation":

        if not subtypes:
            return None

        dtype = subtypes[0]

    else:
        dtype = raw


    if dtype not in REAL_DOMAIN_TYPES:
        return None


    return dtype


def translated_feature_sequence(
    qualifiers,
):

    for key in (
        "Transferred_Translation",
        "X-Transferred_Translation",
        "translation",
    ):

        value = one(
            qualifiers,
            key,
        )

        if value:

            return clean_aa(
                value
            )

    return ""


def translate_nt(
    seq,
):

    if len(seq) % 3 != 0:
        raise RuntimeError(
            "Attempted translation of "
            "non-triplet nucleotide span"
        )

    return str(
        seq.translate()
    )


def write_fasta_gz(
    path,
    sequences,
    *,
    prefix,
):

    with gzip.open(
        path,
        "wt",
    ) as f:

        for sequence_hash in sorted(
            sequences
        ):

            seq = sequences[
                sequence_hash
            ]

            f.write(
                f">{sequence_hash}"
                f"|kind={prefix}\n"
            )

            for start in range(
                0,
                len(seq),
                80,
            ):

                f.write(
                    seq[
                        start:
                        start + 80
                    ]
                    + "\n"
                )


def write_tsv_gz(
    path,
    rows,
    fields,
):

    df = pd.DataFrame(
        rows,
        columns=fields,
    )

    df.to_csv(
        path,
        sep="\t",
        index=False,
        compression="gzip",
    )


# ======================================================================
# START CLEAN TRANSACTION
# ======================================================================

if TMP_OUT.exists():
    shutil.rmtree(
        TMP_OUT
    )

TMP_OUT.mkdir(
    parents=True,
    exist_ok=False,
)


print(
    "=" * 100
)

print(
    "BODE PHASE-2 MODEL-READY V1.2 BUILD"
)

print(
    "=" * 100
)

print(
    "IMPORTANT:"
)

print(
    "  experimental activity/product labels are NOT read"
)

print(
    "  frozen structured domain universe is the only domain universe"
)

print(
    "  old 963-aSModule representation is NOT used"
)

print(
    "  experimental scars are internal B positions, NOT J"
)


# ======================================================================
# 1. LOAD FROZEN DOMAIN UNIVERSE
# ======================================================================

domains_v12 = pd.read_csv(
    DOMAIN_TABLE,
    sep="\t",
)


domain_sequences = {
    rec.id:
        clean_aa(
            rec.seq
        )

    for rec in SeqIO.parse(
        str(
            DOMAIN_FASTA
        ),
        "fasta",
    )
}


if len(
    domains_v12
) != EXPECTED_DOMAINS:

    raise RuntimeError(
        "Frozen V1.2 domain-count mismatch: "
        f"{len(domains_v12)}"
    )


if (
    domains_v12[
        "domain_sequence_hash"
    ].nunique()
    !=
    EXPECTED_UNIQUE_DOMAIN_HASHES
):

    raise RuntimeError(
        "Frozen V1.2 unique-domain-hash mismatch"
    )


required_hashes = set(
    domains_v12[
        "domain_sequence_hash"
    ].astype(
        str
    )
)


missing_domain_sequences = (
    required_hashes
    -
    set(
        domain_sequences
    )
)


if missing_domain_sequences:

    raise RuntimeError(
        "V1.2 FASTA missing domain hashes: "
        f"{len(missing_domain_sequences)}"
    )


for h in sorted(
    required_hashes
):

    if (
        sha256_sequence(
            domain_sequences[h]
        )
        !=
        h
    ):

        raise RuntimeError(
            f"Domain FASTA hash mismatch: {h}"
        )


print()
print(
    "=" * 100
)

print(
    "FROZEN DOMAIN UNIVERSE"
)

print(
    "=" * 100
)

print(
    "domain occurrences:",
    len(
        domains_v12
    ),
)

print(
    "unique domain hashes:",
    len(
        required_hashes
    ),
)


# ======================================================================
# 2. LOAD GENBANK + CANONICAL CONSTRUCT IDs
# ======================================================================

records = list(
    SeqIO.parse(
        str(
            GB
        ),
        "genbank",
    )
)


construct_table = pd.read_csv(
    CONSTRUCT_TABLE,
    sep="\t",
)


if len(records) != EXPECTED_CONSTRUCTS:

    raise RuntimeError(
        f"Expected {EXPECTED_CONSTRUCTS} GenBank records, "
        f"got {len(records)}"
    )


if len(
    construct_table
) != EXPECTED_CONSTRUCTS:

    raise RuntimeError(
        "Construct-table count mismatch"
    )


records_by_raw_id = {
    str(rec.id):
        rec

    for rec in records
}


canonical_by_raw_id = {
    str(rec.id):
        canonical_construct_id(
            rec
        )

    for rec in records
}


raw_id_by_canonical = {
    canonical:
        raw_id

    for raw_id, canonical
    in canonical_by_raw_id.items()
}


if len(
    raw_id_by_canonical
) != EXPECTED_CONSTRUCTS:

    raise RuntimeError(
        "Canonical construct IDs are not unique"
    )


table_construct_ids = set(
    construct_table[
        "construct_id"
    ].astype(
        str
    )
)


if (
    table_construct_ids
    !=
    set(
        raw_id_by_canonical
    )
):

    raise RuntimeError(
        "GenBank <-> engineered_constructs "
        "canonical ID mismatch"
    )


for row in construct_table.itertuples():

    raw_id = raw_id_by_canonical[
        str(
            row.construct_id
        )
    ]

    rec = records_by_raw_id[
        raw_id
    ]

    if (
        len(
            rec.seq
        )
        !=
        int(
            row.sequence_length
        )
    ):

        raise RuntimeError(
            f"{row.construct_id}: "
            "construct length mismatch"
        )


print()
print(
    "construct identity contract: PASS"
)


# ======================================================================
# 3. RAW FEATURE CANDIDATES FOR THE FROZEN 1807 DOMAINS
# ======================================================================

feature_candidates = defaultdict(
    list
)


for rec in records:

    raw_id = str(
        rec.id
    )


    for feature_index, feat in enumerate(
        rec.features
    ):

        if feat.type != "aSDomain":
            continue


        q = feat.qualifiers

        dtype = raw_domain_type(
            q
        )


        if dtype is None:
            continue


        strand = (
            int(
                feat.location.strand
            )
            if feat.location.strand
            is not None
            else 1
        )


        if strand != 1:

            raise RuntimeError(
                f"{raw_id}: retained engineered "
                "domain is not on + strand"
            )


        locus = one(
            q,
            "locus_tag",
        )


        try:

            protein_start = int(
                one(
                    q,
                    "protein_start",
                )
            )

            protein_end = int(
                one(
                    q,
                    "protein_end",
                )
            )

        except Exception:

            continue


        transferred = (
            translated_feature_sequence(
                q
            )
        )


        key = (
            raw_id,
            str(
                locus
            ),
            dtype,
            protein_start,
            protein_end,
        )


        feature_candidates[
            key
        ].append(
            {
                "feature_index":
                    feature_index,

                "nt_start":
                    int(
                        feat.location.start
                    ),

                "nt_end":
                    int(
                        feat.location.end
                    ),

                "strand":
                    strand,

                "feature_sequence":
                    transferred,

                "feature_sequence_hash":
                    (
                        sha256_sequence(
                            transferred
                        )
                        if transferred
                        else ""
                    ),

                "domain_id":
                    one(
                        q,
                        "domain_id",
                    ).strip(),
            }
        )


# ======================================================================
# 4. MAP EVERY FROZEN V1.2 DOMAIN TO ONE RAW FEATURE
# ======================================================================

mapped_domains = []

mapping_failures = []

raw_duplicate_cases = 0


for row in domains_v12.itertuples():

    key = (
        str(
            row.construct_id
        ),
        str(
            row.locus_tag
        ),
        str(
            row.domain_type
        ),
        int(
            row.domain_start_aa_0based
        ),
        int(
            row.domain_end_aa_0based_exclusive
        ),
    )


    candidates = feature_candidates.get(
        key,
        [],
    )


    if not candidates:

        mapping_failures.append(
            (
                row.domain_uid,
                key,
            )
        )

        continue


    if len(
        candidates
    ) > 1:

        raw_duplicate_cases += 1


    expected_hash = str(
        row.domain_sequence_hash
    )


    expected_aa = (
        domain_sequences[
            expected_hash
        ]
    )


    expected_nt_length = (
        3
        *
        len(
            expected_aa
        )
    )


    ranked = sorted(
        candidates,
        key=lambda c: (
            0
            if c[
                "feature_sequence_hash"
            ]
            ==
            expected_hash
            else 1,

            abs(
                (
                    c[
                        "nt_end"
                    ]
                    -
                    c[
                        "nt_start"
                    ]
                )
                -
                expected_nt_length
            ),

            -(
                c[
                    "nt_end"
                ]
                -
                c[
                    "nt_start"
                ]
            ),

            c[
                "nt_start"
            ],

            c[
                "feature_index"
            ],
        ),
    )


    chosen = ranked[0]


    mapped_domains.append(
        {
            "raw_construct_id":
                str(
                    row.construct_id
                ),

            "construct_id":
                canonical_by_raw_id[
                    str(
                        row.construct_id
                    )
                ],

            "domain_uid":
                str(
                    row.domain_uid
                ),

            "locus_tag":
                str(
                    row.locus_tag
                ),

            "domain_type":
                str(
                    row.domain_type
                ),

            "domain_sequence_hash":
                expected_hash,

            "domain_sequence":
                expected_aa,

            "protein_start":
                int(
                    row.domain_start_aa_0based
                ),

            "protein_end":
                int(
                    row.domain_end_aa_0based_exclusive
                ),

            "raw_feature_index":
                int(
                    chosen[
                        "feature_index"
                    ]
                ),

            "annotated_nt_start":
                int(
                    chosen[
                        "nt_start"
                    ]
                ),

            "annotated_nt_end":
                int(
                    chosen[
                        "nt_end"
                    ]
                ),

            "raw_domain_id":
                str(
                    chosen[
                        "domain_id"
                    ]
                ),
        }
    )


if mapping_failures:

    for failure in (
        mapping_failures[:30]
    ):

        print(
            "MAPPING FAILURE:",
            failure,
        )

    raise RuntimeError(
        "Frozen-domain raw mapping incomplete: "
        f"{len(mapping_failures)} failures"
    )


mapped = pd.DataFrame(
    mapped_domains
)


if len(
    mapped
) != EXPECTED_DOMAINS:

    raise RuntimeError(
        "Expected all 1807 domains to map"
    )


print()
print(
    "=" * 100
)

print(
    "FROZEN DOMAIN -> RAW FEATURE"
)

print(
    "=" * 100
)

print(
    "mapped:",
    len(
        mapped
    ),
    "/",
    EXPECTED_DOMAINS,
)

print(
    "raw duplicate-coordinate cases:",
    raw_duplicate_cases,
)


# ======================================================================
# 5. RESOLVE EXACT CODING NUCLEOTIDE SPAN OF EACH DOMAIN
#
# IMPORTANT:
#
# Most transferred aSDomain feature intervals correspond exactly to the
# mature-domain coding span.
#
# A subset of Geneious-transferred annotations is clipped/non-triplet:
#
#     feature genomic span
#         !=
#     full transferred protein-domain span
#
# The frozen V1.2 amino-acid sequence remains authoritative.
#
# Resolution policy:
#
#   1. Try the annotation itself / +/- 3 nt.
#
#   2. If that cannot reproduce the frozen domain sequence, search a
#      LOCAL genomic neighborhood in all three translation frames.
#
#   3. Accept ONLY an exact amino-acid sequence match.
#
#   4. Rank exact matches by overlap/proximity to the transferred raw
#      feature annotation.
#
# There is:
#   - no fuzzy alignment
#   - no approximate AA matching
#   - no activity-label information
# ======================================================================

GENOMIC_DOMAIN_SEARCH_FLANK_NT = 4096


def exact_translation_spans_in_window(
    *,
    record,
    expected_aa,
    window_start,
    window_end,
):

    window_start = max(
        0,
        int(
            window_start
        ),
    )

    window_end = min(
        len(
            record.seq
        ),
        int(
            window_end
        ),
    )

    if (
        window_end
        <=
        window_start
    ):

        return []


    target_length_nt = (
        3
        *
        len(
            expected_aa
        )
    )


    hits = set()


    # --------------------------------------------------------------
    # Search all three local translation frames.
    # --------------------------------------------------------------

    for offset in (
        0,
        1,
        2,
    ):

        frame_start = (
            window_start
            +
            offset
        )


        available_nt = (
            window_end
            -
            frame_start
        )


        usable_nt = (
            available_nt
            -
            (
                available_nt
                %
                3
            )
        )


        if usable_nt < target_length_nt:

            continue


        nt = record.seq[
            frame_start:
            frame_start
            +
            usable_nt
        ]


        aa = str(
            nt.translate()
        )


        search_from = 0


        while True:

            aa_index = aa.find(
                expected_aa,
                search_from,
            )


            if aa_index < 0:

                break


            coding_start = (
                frame_start
                +
                3
                *
                aa_index
            )


            coding_end = (
                coding_start
                +
                target_length_nt
            )


            # --------------------------------------------------
            # Hard verification against the original DNA.
            # --------------------------------------------------

            observed = str(
                record.seq[
                    coding_start:
                    coding_end
                ].translate()
            )


            if observed != expected_aa:

                raise RuntimeError(
                    "Internal exact-search inconsistency"
                )


            hits.add(
                (
                    int(
                        coding_start
                    ),
                    int(
                        coding_end
                    ),
                )
            )


            search_from = (
                aa_index
                +
                1
            )


    return sorted(
        hits
    )


resolved_rows = []

coding_failures = []

coding_resolution_modes = Counter()

multi_exact_match_cases = []


for row in mapped.to_dict(
    "records"
):

    rec = records_by_raw_id[
        row[
            "raw_construct_id"
        ]
    ]


    expected = row[
        "domain_sequence"
    ]


    expected_nt_length = (
        3
        *
        len(
            expected
        )
    )


    annotated_start = int(
        row[
            "annotated_nt_start"
        ]
    )

    annotated_end = int(
        row[
            "annotated_nt_end"
        ]
    )


    # ==========================================================
    # A. FAST PATH:
    # annotation-proximal exact reconstruction.
    # ==========================================================

    direct_candidates = []


    for start_shift in range(
        -3,
        4,
    ):

        coding_start = (
            annotated_start
            +
            start_shift
        )


        coding_end = (
            coding_start
            +
            expected_nt_length
        )


        if (
            coding_start < 0
            or
            coding_end
            >
            len(
                rec.seq
            )
        ):

            continue


        observed = str(
            rec.seq[
                coding_start:
                coding_end
            ].translate()
        )


        if observed != expected:

            continue


        direct_candidates.append(
            (
                abs(
                    coding_start
                    -
                    annotated_start
                )
                +
                abs(
                    coding_end
                    -
                    annotated_end
                ),

                abs(
                    coding_start
                    -
                    annotated_start
                ),

                coding_start,

                coding_end,
            )
        )


    if direct_candidates:

        direct_candidates.sort()

        best = (
            direct_candidates[
                0
            ]
        )


        coding_start = int(
            best[
                2
            ]
        )

        coding_end = int(
            best[
                3
            ]
        )


        resolution_mode = (
            "annotation_proximal_exact"
        )


    else:

        # ======================================================
        # B. CLIPPED / TRANSFERRED FEATURE FALLBACK
        #
        # Search locally in all three translation frames.
        # ======================================================

        search_start = max(
            0,
            annotated_start
            -
            GENOMIC_DOMAIN_SEARCH_FLANK_NT,
        )


        search_end = min(
            len(
                rec.seq
            ),
            annotated_end
            +
            GENOMIC_DOMAIN_SEARCH_FLANK_NT,
        )


        exact_hits = (
            exact_translation_spans_in_window(
                record=rec,
                expected_aa=expected,
                window_start=search_start,
                window_end=search_end,
            )
        )


        if not exact_hits:

            coding_failures.append(
                (
                    row[
                        "domain_uid"
                    ],
                    annotated_start,
                    annotated_end,
                    len(
                        expected
                    ),
                    "NO_LOCAL_EXACT_AA_MATCH",
                )
            )

            continue


        # ------------------------------------------------------
        # Rank only EXACT sequence matches.
        #
        # Prefer the candidate having maximum genomic overlap
        # with the transferred annotation, then minimum center
        # displacement, then minimum endpoint displacement.
        # ------------------------------------------------------

        ranked_hits = []


        for (
            candidate_start,
            candidate_end,
        ) in exact_hits:

            overlap = max(
                0,
                min(
                    candidate_end,
                    annotated_end,
                )
                -
                max(
                    candidate_start,
                    annotated_start,
                ),
            )


            center_distance_x2 = abs(
                (
                    candidate_start
                    +
                    candidate_end
                )
                -
                (
                    annotated_start
                    +
                    annotated_end
                )
            )


            endpoint_distance = (
                abs(
                    candidate_start
                    -
                    annotated_start
                )
                +
                abs(
                    candidate_end
                    -
                    annotated_end
                )
            )


            ranked_hits.append(
                (
                    -overlap,
                    center_distance_x2,
                    endpoint_distance,
                    candidate_start,
                    candidate_end,
                )
            )


        ranked_hits.sort()


        best = ranked_hits[
            0
        ]


        coding_start = int(
            best[
                3
            ]
        )

        coding_end = int(
            best[
                4
            ]
        )


        resolution_mode = (
            "local_exact_translation_search"
        )


        if len(
            exact_hits
        ) > 1:

            multi_exact_match_cases.append(
                {
                    "domain_uid":
                        row[
                            "domain_uid"
                        ],

                    "annotated":
                        (
                            annotated_start,
                            annotated_end,
                        ),

                    "exact_hits":
                        exact_hits,

                    "selected":
                        (
                            coding_start,
                            coding_end,
                        ),
                }
            )


    # ==========================================================
    # C. FINAL HARD VERIFICATION
    # ==========================================================

    if (
        coding_end
        -
        coding_start
        !=
        expected_nt_length
    ):

        raise RuntimeError(
            f"{row['domain_uid']}: "
            "resolved domain NT length mismatch"
        )


    if (
        (
            coding_end
            -
            coding_start
        )
        %
        3
        !=
        0
    ):

        raise RuntimeError(
            f"{row['domain_uid']}: "
            "resolved domain is not codon aligned"
        )


    final_observed = str(
        rec.seq[
            coding_start:
            coding_end
        ].translate()
    )


    if final_observed != expected:

        raise RuntimeError(
            f"{row['domain_uid']}: "
            "resolved genomic domain does not "
            "reproduce frozen V1.2 AA sequence"
        )


    row[
        "coding_nt_start"
    ] = coding_start

    row[
        "coding_nt_end"
    ] = coding_end

    row[
        "coding_resolution_mode"
    ] = resolution_mode


    coding_resolution_modes[
        resolution_mode
    ] += 1


    resolved_rows.append(
        row
    )


if coding_failures:

    print()

    print(
        "FIRST CODING-SPAN FAILURES"
    )

    for x in (
        coding_failures[
            :30
        ]
    ):

        print(x)


    raise RuntimeError(
        "Could not recover exact genomic coding spans "
        "for all frozen domains: "
        f"{len(coding_failures)} failures"
    )


resolved = pd.DataFrame(
    resolved_rows
)


if len(
    resolved
) != EXPECTED_DOMAINS:

    raise RuntimeError(
        "Coding-span resolution lost frozen domains"
    )


if (
    resolved[
        "domain_uid"
    ].nunique()
    !=
    EXPECTED_DOMAINS
):

    raise RuntimeError(
        "Coding-span resolution duplicated domains"
    )


print()

print(
    "=" * 100
)

print(
    "EXACT GENOMIC DOMAIN RESOLUTION"
)

print(
    "=" * 100
)

print(
    "resolved:",
    len(
        resolved
    ),
    "/",
    EXPECTED_DOMAINS,
)

print(
    "resolution modes:",
    dict(
        coding_resolution_modes
    ),
)

print(
    "multiple local exact-match cases:",
    len(
        multi_exact_match_cases
    ),
)


# --------------------------------------------------------------
# Every accepted occurrence has an EXACT DNA -> frozen-AA match.
# --------------------------------------------------------------

for row in resolved.itertuples():

    rec = records_by_raw_id[
        row.raw_construct_id
    ]

    observed = str(
        rec.seq[
            int(
                row.coding_nt_start
            ):
            int(
                row.coding_nt_end
            )
        ].translate()
    )


    if (
        observed
        !=
        row.domain_sequence
    ):

        raise RuntimeError(
            f"{row.domain_uid}: "
            "post-resolution exact sequence audit failed"
        )


print(
    "DNA -> frozen V1.2 domain sequence:",
    "1807 / 1807 PASS",
)


# ======================================================================
# 6. RECONSTRUCT THE FROZEN 517 FUNCTIONAL MODULES
# ======================================================================

assigned_rows = []

module_members = defaultdict(
    list
)

module_count_by_construct = Counter()


for construct_id, group in resolved.groupby(
    "construct_id",
    sort=False,
):

    group = group.sort_values(
        [
            "coding_nt_start",
            "coding_nt_end",
            "protein_start",
            "protein_end",
            "domain_type",
        ]
    )


    current = []

    modules_here = []


    for d in group.to_dict(
        "records"
    ):

        dtype = d[
            "domain_type"
        ]


        starts_new = (
            dtype.startswith(
                "Condensation_"
            )
            or
            dtype
            ==
            "AMP-binding"
        )


        current_has_pcp = any(
            x[
                "domain_type"
            ]
            ==
            "PCP"

            for x in current
        )


        if (
            current
            and
            current_has_pcp
            and
            starts_new
        ):

            modules_here.append(
                current
            )

            current = []


        current.append(
            d
        )


    if current:

        modules_here.append(
            current
        )


    module_count_by_construct[
        construct_id
    ] = len(
        modules_here
    )


    for module_index, member_list in enumerate(
        modules_here,
        start=1,
    ):

        module_uid = (
            f"{construct_id}"
            f"|module={module_index}"
        )


        types = [
            x[
                "domain_type"
            ]
            for x in member_list
        ]


        if (
            types.count(
                "AMP-binding"
            )
            != 1
        ):

            raise RuntimeError(
                f"{module_uid}: "
                "module must contain exactly one AMP-binding; "
                f"{types}"
            )


        if (
            types.count(
                "PCP"
            )
            != 1
        ):

            raise RuntimeError(
                f"{module_uid}: "
                "module must contain exactly one PCP; "
                f"{types}"
            )


        for component_order, d in enumerate(
            member_list,
            start=1,
        ):

            d = dict(
                d
            )

            d[
                "module_uid"
            ] = module_uid

            d[
                "module_index"
            ] = module_index

            d[
                "component_order"
            ] = component_order


            assigned_rows.append(
                d
            )

            module_members[
                module_uid
            ].append(
                d
            )


assigned = pd.DataFrame(
    assigned_rows
)


if len(
    module_members
) != EXPECTED_MODULES:

    raise RuntimeError(
        "Functional-module count mismatch: "
        f"{len(module_members)}"
    )


if len(
    assigned
) != EXPECTED_DOMAINS:

    raise RuntimeError(
        "Not all domains assigned exactly once"
    )


if (
    assigned[
        "domain_uid"
    ].nunique()
    !=
    EXPECTED_DOMAINS
):

    raise RuntimeError(
        "A frozen domain was assigned more "
        "than once"
    )


observed_module_distribution = Counter(
    module_count_by_construct.values()
)


if dict(
    sorted(
        observed_module_distribution.items()
    )
) != {
    4: 13,
    5: 93,
}:

    raise RuntimeError(
        "Functional module-count distribution drift: "
        f"{dict(observed_module_distribution)}"
    )


print()
print(
    "=" * 100
)

print(
    "FUNCTIONAL MODULE RECONSTRUCTION"
)

print(
    "=" * 100
)

print(
    "constructs:",
    len(
        module_count_by_construct
    ),
)

print(
    "functional modules:",
    len(
        module_members
    ),
)

print(
    "assigned domains:",
    len(
        assigned
    ),
)

print(
    "module-count distribution:",
    dict(
        sorted(
            observed_module_distribution.items()
        )
    ),
)


# ======================================================================
# 7. BUILD EXACT MATURE WHOLE-MODULE SEQUENCES
#
# Frozen Route-A module sequence convention:
#
#     first retained biological domain start
#     ->
#     last retained biological domain end
#
# This preserves:
#   - complete real inter-domain gaps
#   - overlap geometry
#   - engineered scar sequence
#
# Every retained D must be an exact slice of this translated module.
# ======================================================================

module_rows = []

structured_domain_rows = []

module_sequences_by_hash = {}

module_meta = {}


for module_uid in sorted(
    module_members,
    key=lambda uid: (
        uid.split(
            "|module="
        )[0],
        int(
            uid.split(
                "|module="
            )[1]
        ),
    ),
):

    members = sorted(
        module_members[
            module_uid
        ],
        key=lambda x:
            x[
                "component_order"
            ],
    )


    construct_id = members[0][
        "construct_id"
    ]

    raw_construct_id = members[0][
        "raw_construct_id"
    ]

    module_index = int(
        members[0][
            "module_index"
        ]
    )


    rec = records_by_raw_id[
        raw_construct_id
    ]


    module_nt_start = int(
        members[0][
            "coding_nt_start"
        ]
    )

    module_nt_end = int(
        members[-1][
            "coding_nt_end"
        ]
    )


    if (
        module_nt_end
        <=
        module_nt_start
    ):

        raise RuntimeError(
            f"{module_uid}: invalid nucleotide span"
        )


    if (
        module_nt_end
        -
        module_nt_start
    ) % 3 != 0:

        raise RuntimeError(
            f"{module_uid}: whole-module "
            "span is not codon aligned"
        )


    module_seq = translate_nt(
        rec.seq[
            module_nt_start:
            module_nt_end
        ]
    )


    if "*" in module_seq:

        raise RuntimeError(
            f"{module_uid}: internal stop codon "
            "inside reconstructed functional module"
        )


    component_types = []


    for d in members:

        start_nt = int(
            d[
                "coding_nt_start"
            ]
        )

        end_nt = int(
            d[
                "coding_nt_end"
            ]
        )


        if (
            start_nt
            -
            module_nt_start
        ) % 3 != 0:

            raise RuntimeError(
                f"{module_uid}/{d['domain_uid']}: "
                "domain is out of module reading frame"
            )


        if (
            end_nt
            -
            module_nt_start
        ) % 3 != 0:

            raise RuntimeError(
                f"{module_uid}/{d['domain_uid']}: "
                "domain end is out of frame"
            )


        local_start = (
            start_nt
            -
            module_nt_start
        ) // 3


        local_end = (
            end_nt
            -
            module_nt_start
        ) // 3


        expected_domain_seq = d[
            "domain_sequence"
        ]


        observed_domain_seq = (
            module_seq[
                local_start:
                local_end
            ]
        )


        if (
            observed_domain_seq
            !=
            expected_domain_seq
        ):

            raise RuntimeError(
                f"{module_uid}/{d['domain_uid']}: "
                "whole-module/domain sequence "
                "alignment mismatch"
            )


        component_types.append(
            d[
                "domain_type"
            ]
        )


        structured_domain_rows.append(
            {
                "module_uid":
                    module_uid,

                "split":
                    SPLIT,

                "component_order":
                    int(
                        d[
                            "component_order"
                        ]
                    ),

                "domain_uid":
                    d[
                        "domain_uid"
                    ],

                "domain_type":
                    d[
                        "domain_type"
                    ],

                "domain_sequence_hash":
                    d[
                        "domain_sequence_hash"
                    ],

                "domain_length":
                    len(
                        expected_domain_seq
                    ),

                # External Phase-2 mature-module frame.
                # These fields are module-local because there is no
                # single native protein coordinate system across
                # engineered split-intein fusion segments.
                "domain_start_aa_0based":
                    local_start,

                "domain_end_aa_0based_exclusive":
                    local_end,

                "domain_start_module_0based":
                    local_start,

                "domain_end_module_0based_exclusive":
                    local_end,

                "predicted_monomer_consensus":
                    "",

                # Audit-only engineered DNA coordinates.
                "construct_nt_start_0based":
                    start_nt,

                "construct_nt_end_0based_exclusive":
                    end_nt,

                "source_locus_tag":
                    d[
                        "locus_tag"
                    ],
            }
        )


    module_hash = sha256_sequence(
        module_seq
    )


    previous = (
        module_sequences_by_hash.get(
            module_hash
        )
    )


    if previous is None:

        module_sequences_by_hash[
            module_hash
        ] = module_seq

    elif previous != module_seq:

        raise RuntimeError(
            "SHA256 collision in whole modules"
        )


    component_count = len(
        members
    )

    internal_boundary_count = (
        component_count
        -
        1
    )


    biological_token_count = (
        2
        *
        component_count
        -
        1
    )


    if biological_token_count > 11:

        raise RuntimeError(
            f"{module_uid}: frozen V1-A "
            "token limit exceeded: "
            f"{biological_token_count}"
        )


    architecture = "->".join(
        component_types
    )


    module_row = {
        "module_uid":
            module_uid,

        "split":
            SPLIT,

        "module_sequence_hash":
            module_hash,

        "module_sequence_length":
            len(
                module_seq
            ),

        "occurrence_count":
            1,

        "component_count":
            component_count,

        "internal_boundary_count":
            internal_boundary_count,

        "component_architecture":
            architecture,

        "initial_component":
            component_types[0],

        "terminal_component":
            component_types[-1],

        "predicted_monomers":
            "",

        "has_loader":
            True,

        "has_carrier":
            True,

        "operational_complete":
            True,

        "contiguous_locus":
            "engineered_mature_module",

        # Local mature-module coordinate frame.
        "module_start_aa_0based":
            0,

        "module_end_aa_0based_exclusive":
            len(
                module_seq
            ),

        "accession":
            construct_id,

        "record_id":
            construct_id,

        "area_index":
            1,

        "genome_key":
            "",

        "species":
            "",

        "genus":
            "",

        "family":
            "",

        "order":
            "",

        # Audit-only engineered DNA coordinates.
        "construct_nt_start_0based":
            module_nt_start,

        "construct_nt_end_0based_exclusive":
            module_nt_end,

        "module_index":
            module_index,
    }


    module_rows.append(
        module_row
    )


    module_meta[
        module_uid
    ] = {
        **module_row,
        "sequence":
            module_seq,

        "raw_construct_id":
            raw_construct_id,
    }


if len(
    module_rows
) != EXPECTED_MODULES:

    raise RuntimeError(
        "Whole-module construction count mismatch"
    )


if len(
    structured_domain_rows
) != EXPECTED_DOMAINS:

    raise RuntimeError(
        "Structured-domain output count mismatch"
    )


print()
print(
    "=" * 100
)

print(
    "WHOLE-MODULE SEQUENCE CONTRACT"
)

print(
    "=" * 100
)

print(
    "module sequences:",
    len(
        module_rows
    ),
)

print(
    "unique module sequences:",
    len(
        module_sequences_by_hash
    ),
)

print(
    "all 1807 D sequences align exactly "
    "inside reconstructed modules: PASS",
)


# ======================================================================
# 8. BUILD EXACT 1290 INTERNAL B TOKENS
#
# Exact frozen Route-A rule:
#
# window_start = max(
#     left_start,
#     left_end - 64
# )
#
# window_end = min(
#     right_end,
#     right_start + 64
# )
# ======================================================================

domains_by_module = defaultdict(
    list
)


for row in structured_domain_rows:

    domains_by_module[
        row[
            "module_uid"
        ]
    ].append(
        row
    )


boundary_rows = []

unique_boundary_sequences = {}


for module_uid in sorted(
    domains_by_module
):

    rows = sorted(
        domains_by_module[
            module_uid
        ],
        key=lambda r:
            int(
                r[
                    "component_order"
                ]
            ),
    )


    module_seq = module_meta[
        module_uid
    ][
        "sequence"
    ]


    module_nt_start = int(
        module_meta[
            module_uid
        ][
            "construct_nt_start_0based"
        ]
    )


    for left, right in zip(
        rows[:-1],
        rows[1:],
    ):

        left_order = int(
            left[
                "component_order"
            ]
        )

        right_order = int(
            right[
                "component_order"
            ]
        )


        if (
            right_order
            !=
            left_order
            +
            1
        ):

            raise RuntimeError(
                f"{module_uid}: "
                "non-adjacent component order"
            )


        left_start = int(
            left[
                "domain_start_module_0based"
            ]
        )

        left_end = int(
            left[
                "domain_end_module_0based_exclusive"
            ]
        )

        right_start = int(
            right[
                "domain_start_module_0based"
            ]
        )

        right_end = int(
            right[
                "domain_end_module_0based_exclusive"
            ]
        )


        signed_gap = (
            right_start
            -
            left_end
        )


        if signed_gap > 0:

            geometry = (
                "positive_gap"
            )

        elif signed_gap == 0:

            geometry = (
                "touching"
            )

        else:

            geometry = (
                "overlap"
            )


        window_start = max(
            left_start,
            left_end
            -
            BOUNDARY_FLANK_AA,
        )


        window_end = min(
            right_end,
            right_start
            +
            BOUNDARY_FLANK_AA,
        )


        if (
            window_end
            <=
            window_start
        ):

            raise RuntimeError(
                f"{module_uid}: "
                "invalid internal B window "
                f"{window_start}:{window_end}"
            )


        boundary_seq = (
            module_seq[
                window_start:
                window_end
            ]
        )


        boundary_hash = sha256_sequence(
            boundary_seq
        )


        previous = (
            unique_boundary_sequences.get(
                boundary_hash
            )
        )


        if previous is None:

            unique_boundary_sequences[
                boundary_hash
            ] = boundary_seq

        elif previous != boundary_seq:

            raise RuntimeError(
                "SHA256 collision in B sequences"
            )


        raw_left_end = (
            module_nt_start
            +
            3
            *
            left_end
        )

        raw_right_start = (
            module_nt_start
            +
            3
            *
            right_start
        )


        boundary_rows.append(
            {
                "boundary_uid":
                    (
                        f"{module_uid}"
                        f"|boundary="
                        f"{left_order}-{right_order}"
                    ),

                "module_uid":
                    module_uid,

                "split":
                    SPLIT,

                "left_component_order":
                    left_order,

                "right_component_order":
                    right_order,

                "left_domain_uid":
                    left[
                        "domain_uid"
                    ],

                "right_domain_uid":
                    right[
                        "domain_uid"
                    ],

                "left_domain_type":
                    left[
                        "domain_type"
                    ],

                "right_domain_type":
                    right[
                        "domain_type"
                    ],

                "boundary_type":
                    (
                        f"{left['domain_type']}"
                        f"->{right['domain_type']}"
                    ),

                "geometry_class":
                    geometry,

                "signed_gap_length":
                    signed_gap,

                "overlap_length":
                    max(
                        -signed_gap,
                        0,
                    ),

                "positive_gap_length":
                    max(
                        signed_gap,
                        0,
                    ),

                "left_domain_start_aa_0based":
                    left_start,

                "left_domain_end_aa_0based_exclusive":
                    left_end,

                "right_domain_start_aa_0based":
                    right_start,

                "right_domain_end_aa_0based_exclusive":
                    right_end,

                "window_start_aa_0based":
                    window_start,

                "window_end_aa_0based_exclusive":
                    window_end,

                "window_start_module_0based":
                    window_start,

                "window_end_module_0based_exclusive":
                    window_end,

                "left_domain_context_length":
                    (
                        left_end
                        -
                        window_start
                    ),

                "right_domain_context_length":
                    (
                        window_end
                        -
                        right_start
                    ),

                "boundary_sequence_length":
                    len(
                        boundary_seq
                    ),

                "boundary_sequence_hash":
                    boundary_hash,

                "boundary_flank_policy_aa":
                    BOUNDARY_FLANK_AA,

                # Audit-only DNA gap occupied between the two D tokens.
                "construct_gap_start_nt_0based":
                    raw_left_end,

                "construct_gap_end_nt_0based_exclusive":
                    raw_right_start,

                "engineered_scar_name":
                    "",

                "engineered_scar_sequence":
                    "",
            }
        )


if len(
    boundary_rows
) != EXPECTED_BOUNDARIES:

    raise RuntimeError(
        "Internal B arithmetic mismatch: "
        f"{len(boundary_rows)}"
    )


print()
print(
    "=" * 100
)

print(
    "INTERNAL B TOKENS"
)

print(
    "=" * 100
)

print(
    "B occurrences:",
    len(
        boundary_rows
    ),
)

print(
    "unique B sequences:",
    len(
        unique_boundary_sequences
    ),
)


# ======================================================================
# 9. RAW ENGINEERED SCAR LABELS
# ======================================================================

label_spans = defaultdict(
    lambda:
        defaultdict(
            list
        )
)


for rec in records:

    raw_id = str(
        rec.id
    )


    for feat in rec.features:

        label = one(
            feat.qualifiers,
            "label",
        ).strip()


        if label not in {
            "LNR",
            "SAV",
            "NPC",
            "NPR",
            "SEI",
        }:

            continue


        label_spans[
            raw_id
        ][
            label
        ].append(
            (
                int(
                    feat.location.start
                ),
                int(
                    feat.location.end
                ),
            )
        )


scar_specs = (
    (
        "scar1",
        "LNR",
        "SAV",
        "LNRSAV",
    ),

    (
        "scar2",
        "NPC",
        "SEI",
        "NPCSEI",
    ),
)


scar_rows = []


boundaries_by_construct = defaultdict(
    list
)


for index, row in enumerate(
    boundary_rows
):

    construct_id = (
        row[
            "module_uid"
        ].split(
            "|module="
        )[0]
    )

    boundaries_by_construct[
        construct_id
    ].append(
        (
            index,
            row,
        )
    )


for raw_id in records_by_raw_id:

    construct_id = canonical_by_raw_id[
        raw_id
    ]


    labels = label_spans[
        raw_id
    ]


    if len(
        labels[
            "LNR"
        ]
    ) != 1:

        raise RuntimeError(
            f"{construct_id}: expected one LNR"
        )


    if len(
        labels[
            "SAV"
        ]
    ) != 1:

        raise RuntimeError(
            f"{construct_id}: expected one SAV"
        )


    if len(
        labels[
            "NPC"
        ]
    ) != 1:

        raise RuntimeError(
            f"{construct_id}: expected one NPC"
        )


    if len(
        labels[
            "SEI"
        ]
    ) != 1:

        raise RuntimeError(
            f"{construct_id}: expected one SEI"
        )


    if len(
        labels[
            "NPR"
        ]
    ) != 0:

        raise RuntimeError(
            f"{construct_id}: NPR unexpectedly present"
        )


    rec = records_by_raw_id[
        raw_id
    ]


    for (
        scar_name,
        left_label,
        right_label,
        expected_sequence,
    ) in scar_specs:

        left_start, left_end = (
            labels[
                left_label
            ][0]
        )

        right_start, right_end = (
            labels[
                right_label
            ][0]
        )


        if left_end != right_start:

            raise RuntimeError(
                f"{construct_id}/{scar_name}: "
                "scar label halves are not adjacent"
            )


        scar_start = left_start

        scar_end = right_end


        scar_nt = rec.seq[
            scar_start:
            scar_end
        ]


        if len(
            scar_nt
        ) % 3 != 0:

            raise RuntimeError(
                f"{construct_id}/{scar_name}: "
                "scar not codon aligned"
            )


        observed_sequence = (
            translate_nt(
                scar_nt
            )
        )


        if (
            observed_sequence
            !=
            expected_sequence
        ):

            raise RuntimeError(
                f"{construct_id}/{scar_name}: "
                f"expected {expected_sequence}, "
                f"got {observed_sequence}"
            )


        hits = []


        for boundary_index, b in (
            boundaries_by_construct[
                construct_id
            ]
        ):

            gap_start = int(
                b[
                    "construct_gap_start_nt_0based"
                ]
            )

            gap_end = int(
                b[
                    "construct_gap_end_nt_0based_exclusive"
                ]
            )


            if (
                gap_start
                <=
                scar_start
                and
                scar_end
                <=
                gap_end
            ):

                hits.append(
                    (
                        boundary_index,
                        b,
                    )
                )


        if len(
            hits
        ) != 1:

            raise RuntimeError(
                f"{construct_id}/{scar_name}: "
                "expected exactly one containing "
                f"B gap, found {len(hits)}"
            )


        boundary_index, boundary = (
            hits[0]
        )


        if (
            boundary[
                "left_domain_type"
            ]
            !=
            "AMP-binding"
            or
            boundary[
                "right_domain_type"
            ]
            !=
            "PCP"
        ):

            raise RuntimeError(
                f"{construct_id}/{scar_name}: "
                "scar is not at A->PCP B"
            )


        boundary_hash = boundary[
            "boundary_sequence_hash"
        ]


        boundary_seq = (
            unique_boundary_sequences[
                boundary_hash
            ]
        )


        if (
            expected_sequence
            not in
            boundary_seq
        ):

            raise RuntimeError(
                f"{construct_id}/{scar_name}: "
                "B sequence does not actually "
                "contain the translated scar"
            )


        boundary_rows[
            boundary_index
        ][
            "engineered_scar_name"
        ] = scar_name


        boundary_rows[
            boundary_index
        ][
            "engineered_scar_sequence"
        ] = expected_sequence


        scar_rows.append(
            {
                "construct_id":
                    construct_id,

                "scar_name":
                    scar_name,

                "scar_sequence":
                    expected_sequence,

                "construct_nt_start_0based":
                    scar_start,

                "construct_nt_end_0based_exclusive":
                    scar_end,

                "module_uid":
                    boundary[
                        "module_uid"
                    ],

                "boundary_uid":
                    boundary[
                        "boundary_uid"
                    ],

                "left_domain_type":
                    boundary[
                        "left_domain_type"
                    ],

                "right_domain_type":
                    boundary[
                        "right_domain_type"
                    ],

                "boundary_sequence_hash":
                    boundary_hash,
            }
        )


if len(
    scar_rows
) != EXPECTED_SCARS:

    raise RuntimeError(
        "Scar count mismatch: "
        f"{len(scar_rows)}"
    )


scar_boundary_uids = [
    row[
        "boundary_uid"
    ]
    for row in scar_rows
]


if len(
    set(
        scar_boundary_uids
    )
) != EXPECTED_SCARS:

    raise RuntimeError(
        "Two scars mapped to the same B occurrence"
    )


print()
print(
    "=" * 100
)

print(
    "ENGINEERED SCAR CONTRACT"
)

print(
    "=" * 100
)

print(
    "scar occurrences:",
    len(
        scar_rows
    ),
)

print(
    "LNRSAV A->PCP B:",
    sum(
        x[
            "scar_sequence"
        ]
        ==
        "LNRSAV"

        for x in scar_rows
    ),
)

print(
    "NPCSEI A->PCP B:",
    sum(
        x[
            "scar_sequence"
        ]
        ==
        "NPCSEI"

        for x in scar_rows
    ),
)

print(
    "all 212 scars physically present "
    "inside their model B sequence: PASS"
)


# ======================================================================
# 10. BUILD THE 411 TRUE INTER-MODULE J POSITIONS
#
# These are NOT the experimental split-intein scars.
#
# Same reading frame + codon-aligned gap + no stop:
#     actual raw AA linker
#
# Otherwise:
#     inter_protein_chain_break
#     no fabricated sequence
# ======================================================================

module_occurrence_rows = []

context_interface_rows = []

junction_rows = []

inference_interface_rows = []

assembly_rows = []


modules_by_construct = defaultdict(
    list
)


for row in module_rows:

    modules_by_construct[
        row[
            "accession"
        ]
    ].append(
        row
    )


for construct_id in sorted(
    modules_by_construct
):

    rows = sorted(
        modules_by_construct[
            construct_id
        ],
        key=lambda r:
            int(
                r[
                    "module_index"
                ]
            ),
    )


    module_count = len(
        rows
    )


    expected_count = (
        module_count_by_construct[
            construct_id
        ]
    )


    if module_count != expected_count:

        raise RuntimeError(
            f"{construct_id}: "
            "module-count drift"
        )


    raw_id = raw_id_by_canonical[
        construct_id
    ]

    rec = records_by_raw_id[
        raw_id
    ]


    assembly_line_id = (
        f"{construct_id}"
        f"|assembly_line=1"
    )


    transition_rows_here = []


    for module_index, module in enumerate(
        rows,
        start=1,
    ):

        if (
            int(
                module[
                    "module_index"
                ]
            )
            !=
            module_index
        ):

            raise RuntimeError(
                f"{construct_id}: "
                "non-contiguous module ordering"
            )


        module_occurrence_rows.append(
            {
                "assembly_line_id":
                    assembly_line_id,

                "split":
                    SPLIT,

                "global_module_index":
                    module_index,

                "module_count":
                    module_count,

                "module_uid":
                    module[
                        "module_uid"
                    ],

                "sequence_hash":
                    module[
                        "module_sequence_hash"
                    ],
            }
        )


    for i in range(
        module_count
        -
        1
    ):

        left = rows[i]

        right = rows[
            i
            +
            1
        ]


        left_index = (
            i
            +
            1
        )

        right_index = (
            i
            +
            2
        )


        left_nt_end = int(
            left[
                "construct_nt_end_0based_exclusive"
            ]
        )

        right_nt_start = int(
            right[
                "construct_nt_start_0based"
            ]
        )


        if (
            right_nt_start
            <
            left_nt_end
        ):

            raise RuntimeError(
                f"{construct_id}: "
                f"M{left_index}->M{right_index} "
                "has overlapping module spans; "
                "Route-A external transition "
                "cannot be represented safely"
            )


        gap_nt = rec.seq[
            left_nt_end:
            right_nt_start
        ]


        codon_aligned = (
            len(
                gap_nt
            )
            %
            3
            ==
            0
        )


        linker_seq = None


        if codon_aligned:

            translated_gap = (
                translate_nt(
                    gap_nt
                )
            )


            if "*" not in translated_gap:

                linker_seq = (
                    translated_gap
                )


        if linker_seq is not None:

            transition_type = (
                "inter_module_linker_candidate"
            )

            sequence_available = True

            junction_sequence = (
                linker_seq
            )

            junction_length = len(
                linker_seq
            )

            junction_kind = (
                "same_chain_linker"
            )

        else:

            transition_type = (
                "inter_protein_chain_break"
            )

            sequence_available = False

            junction_sequence = ""

            junction_length = 0

            junction_kind = (
                "chain_break"
            )


        transition_uid = (
            f"{assembly_line_id}"
            f"|transition="
            f"{left_index}__{right_index}"
        )


        sequence_sha256 = (
            sha256_sequence(
                junction_sequence
            )
        )


        transition_rows_here.append(
            {
                "transition_uid":
                    transition_uid,

                "transition_type":
                    transition_type,
            }
        )


        junction_rows.append(
            {
                "transition_uid":
                    transition_uid,

                "assembly_line_id":
                    assembly_line_id,

                "split":
                    SPLIT,

                "transition_type":
                    transition_type,

                "sequence_available":
                    (
                        "True"
                        if sequence_available
                        else
                        "False"
                    ),

                "sequence":
                    junction_sequence,

                "length_aa":
                    junction_length,

                "sequence_sha256":
                    sequence_sha256,
            }
        )


        context_interface_rows.append(
            {
                "interface_id":
                    transition_uid,

                "transition_uid":
                    transition_uid,

                "assembly_line_id":
                    assembly_line_id,

                "split":
                    SPLIT,

                "left_global_module_index":
                    left_index,

                "right_global_module_index":
                    right_index,

                "left_module_uid":
                    left[
                        "module_uid"
                    ],

                "right_module_uid":
                    right[
                        "module_uid"
                    ],

                "transition_type":
                    transition_type,

                "module_count":
                    module_count,
            }
        )


        inference_interface_rows.append(
            {
                "assembly_line_id":
                    assembly_line_id,

                "construct_id":
                    construct_id,

                "transition_uid":
                    transition_uid,

                "left_global_module_index":
                    left_index,

                "right_global_module_index":
                    right_index,

                "left_module_uid":
                    left[
                        "module_uid"
                    ],

                "right_module_uid":
                    right[
                        "module_uid"
                    ],

                "left_sequence_hash":
                    left[
                        "module_sequence_hash"
                    ],

                "right_sequence_hash":
                    right[
                        "module_sequence_hash"
                    ],

                "transition_type":
                    transition_type,

                "junction_kind":
                    junction_kind,

                "junction_sequence":
                    junction_sequence,

                "junction_length_aa":
                    junction_length,

                "left_terminal_component":
                    left[
                        "terminal_component"
                    ],

                "right_initial_component":
                    right[
                        "initial_component"
                    ],

                "module_count":
                    module_count,

                # Filled below after per-construct chain count known.
                "protein_count":
                    None,

                "chain_break_count":
                    None,
            }
        )


    chain_break_count = sum(
        row[
            "transition_type"
        ]
        ==
        "inter_protein_chain_break"

        for row in transition_rows_here
    )


    protein_count = (
        chain_break_count
        +
        1
    )


    assembly_rows.append(
        {
            "assembly_line_id":
                assembly_line_id,

            "construct_id":
                construct_id,

            "split":
                SPLIT,

            "module_count":
                module_count,

            "transition_count":
                module_count
                -
                1,

            "protein_count":
                protein_count,

            "chain_break_count":
                chain_break_count,
        }
    )


    for row in inference_interface_rows:

        if (
            row[
                "construct_id"
            ]
            ==
            construct_id
        ):

            row[
                "protein_count"
            ] = protein_count

            row[
                "chain_break_count"
            ] = chain_break_count


if len(
    module_occurrence_rows
) != EXPECTED_MODULES:

    raise RuntimeError(
        "module_occurrences count mismatch"
    )


if len(
    context_interface_rows
) != EXPECTED_TRANSITIONS:

    raise RuntimeError(
        "context interface count mismatch"
    )


if len(
    junction_rows
) != EXPECTED_TRANSITIONS:

    raise RuntimeError(
        "junction count mismatch"
    )


if len(
    inference_interface_rows
) != EXPECTED_TRANSITIONS:

    raise RuntimeError(
        "inference interface count mismatch"
    )


if len(
    assembly_rows
) != EXPECTED_CONSTRUCTS:

    raise RuntimeError(
        "assembly count mismatch"
    )


transition_type_counts = Counter(
    row[
        "transition_type"
    ]
    for row in junction_rows
)


print()
print(
    "=" * 100
)

print(
    "TRUE INTER-MODULE J CONTRACT"
)

print(
    "=" * 100
)

print(
    "J occurrences:",
    len(
        junction_rows
    ),
)

print(
    "transition types:",
    dict(
        transition_type_counts
    ),
)


# ======================================================================
# 11. HARD GLOBAL ARITHMETIC
# ======================================================================

if (
    len(
        structured_domain_rows
    )
    -
    len(
        module_rows
    )
    !=
    EXPECTED_BOUNDARIES
):

    raise RuntimeError(
        "Global D-M=B arithmetic failed"
    )


if (
    len(
        module_rows
    )
    -
    EXPECTED_CONSTRUCTS
    !=
    EXPECTED_TRANSITIONS
):

    raise RuntimeError(
        "Global M-construct=J arithmetic failed"
    )


token_counts = [
    (
        2
        *
        int(
            row[
                "component_count"
            ]
        )
        -
        1
    )

    for row in module_rows
]


if max(
    token_counts
) > 11:

    raise RuntimeError(
        "Frozen V1-A biological token limit exceeded"
    )


# ======================================================================
# 12. WRITE TEMPORARY OUTPUTS
# ======================================================================

MODULE_FIELDS = [
    "module_uid",
    "split",
    "module_sequence_hash",
    "module_sequence_length",
    "occurrence_count",
    "component_count",
    "internal_boundary_count",
    "component_architecture",
    "initial_component",
    "terminal_component",
    "predicted_monomers",
    "has_loader",
    "has_carrier",
    "operational_complete",
    "contiguous_locus",
    "module_start_aa_0based",
    "module_end_aa_0based_exclusive",
    "accession",
    "record_id",
    "area_index",
    "genome_key",
    "species",
    "genus",
    "family",
    "order",
    "construct_nt_start_0based",
    "construct_nt_end_0based_exclusive",
    "module_index",
]


DOMAIN_FIELDS = [
    "module_uid",
    "split",
    "component_order",
    "domain_uid",
    "domain_type",
    "domain_sequence_hash",
    "domain_length",
    "domain_start_aa_0based",
    "domain_end_aa_0based_exclusive",
    "domain_start_module_0based",
    "domain_end_module_0based_exclusive",
    "predicted_monomer_consensus",
    "construct_nt_start_0based",
    "construct_nt_end_0based_exclusive",
    "source_locus_tag",
]


BOUNDARY_FIELDS = [
    "boundary_uid",
    "module_uid",
    "split",
    "left_component_order",
    "right_component_order",
    "left_domain_uid",
    "right_domain_uid",
    "left_domain_type",
    "right_domain_type",
    "boundary_type",
    "geometry_class",
    "signed_gap_length",
    "overlap_length",
    "positive_gap_length",
    "left_domain_start_aa_0based",
    "left_domain_end_aa_0based_exclusive",
    "right_domain_start_aa_0based",
    "right_domain_end_aa_0based_exclusive",
    "window_start_aa_0based",
    "window_end_aa_0based_exclusive",
    "window_start_module_0based",
    "window_end_module_0based_exclusive",
    "left_domain_context_length",
    "right_domain_context_length",
    "boundary_sequence_length",
    "boundary_sequence_hash",
    "boundary_flank_policy_aa",
    "construct_gap_start_nt_0based",
    "construct_gap_end_nt_0based_exclusive",
    "engineered_scar_name",
    "engineered_scar_sequence",
]


MODULE_OCCURRENCE_FIELDS = [
    "assembly_line_id",
    "split",
    "global_module_index",
    "module_count",
    "module_uid",
    "sequence_hash",
]


CONTEXT_INTERFACE_FIELDS = [
    "interface_id",
    "transition_uid",
    "assembly_line_id",
    "split",
    "left_global_module_index",
    "right_global_module_index",
    "left_module_uid",
    "right_module_uid",
    "transition_type",
    "module_count",
]


JUNCTION_FIELDS = [
    "transition_uid",
    "assembly_line_id",
    "split",
    "transition_type",
    "sequence_available",
    "sequence",
    "length_aa",
    "sequence_sha256",
]


INFERENCE_INTERFACE_FIELDS = [
    "assembly_line_id",
    "construct_id",
    "transition_uid",
    "left_global_module_index",
    "right_global_module_index",
    "left_module_uid",
    "right_module_uid",
    "left_sequence_hash",
    "right_sequence_hash",
    "transition_type",
    "junction_kind",
    "junction_sequence",
    "junction_length_aa",
    "left_terminal_component",
    "right_initial_component",
    "module_count",
    "protein_count",
    "chain_break_count",
]


SCAR_FIELDS = [
    "construct_id",
    "scar_name",
    "scar_sequence",
    "construct_nt_start_0based",
    "construct_nt_end_0based_exclusive",
    "module_uid",
    "boundary_uid",
    "left_domain_type",
    "right_domain_type",
    "boundary_sequence_hash",
]


ASSEMBLY_FIELDS = [
    "assembly_line_id",
    "construct_id",
    "split",
    "module_count",
    "transition_count",
    "protein_count",
    "chain_break_count",
]


write_tsv_gz(
    TMP_OUT
    / "structured_modules.tsv.gz",
    module_rows,
    MODULE_FIELDS,
)


write_tsv_gz(
    TMP_OUT
    / "structured_domains.tsv.gz",
    structured_domain_rows,
    DOMAIN_FIELDS,
)


write_tsv_gz(
    TMP_OUT
    / "internal_boundaries.tsv.gz",
    boundary_rows,
    BOUNDARY_FIELDS,
)


write_tsv_gz(
    TMP_OUT
    / "module_occurrences.tsv.gz",
    module_occurrence_rows,
    MODULE_OCCURRENCE_FIELDS,
)


write_tsv_gz(
    TMP_OUT
    / "interfaces.tsv.gz",
    context_interface_rows,
    CONTEXT_INTERFACE_FIELDS,
)


write_tsv_gz(
    TMP_OUT
    / "junctions.tsv.gz",
    junction_rows,
    JUNCTION_FIELDS,
)


write_tsv_gz(
    TMP_OUT
    / "inference_interfaces.tsv.gz",
    inference_interface_rows,
    INFERENCE_INTERFACE_FIELDS,
)


write_tsv_gz(
    TMP_OUT
    / "scar_boundary_map.tsv.gz",
    scar_rows,
    SCAR_FIELDS,
)


write_tsv_gz(
    TMP_OUT
    / "assemblies.tsv.gz",
    assembly_rows,
    ASSEMBLY_FIELDS,
)


write_fasta_gz(
    TMP_OUT
    / "unique_modules.fasta.gz",
    module_sequences_by_hash,
    prefix="module",
)


write_fasta_gz(
    TMP_OUT
    / "unique_internal_boundaries.fasta.gz",
    unique_boundary_sequences,
    prefix="boundary",
)


module_occurrence_hash_rows = [
    {
        "module_uid":
            row[
                "module_uid"
            ],

        "module_sequence_hash":
            row[
                "module_sequence_hash"
            ],
    }

    for row in module_rows
]


write_tsv_gz(
    TMP_OUT
    / "module_occurrence_to_hash.tsv.gz",
    module_occurrence_hash_rows,
    [
        "module_uid",
        "module_sequence_hash",
    ],
)


boundary_occurrence_hash_rows = [
    {
        "boundary_uid":
            row[
                "boundary_uid"
            ],

        "boundary_sequence_hash":
            row[
                "boundary_sequence_hash"
            ],
    }

    for row in boundary_rows
]


write_tsv_gz(
    TMP_OUT
    / "boundary_occurrence_to_hash.tsv.gz",
    boundary_occurrence_hash_rows,
    [
        "boundary_uid",
        "boundary_sequence_hash",
    ],
)


summary = {
    "status":
        "bode_phase2_model_ready_v1_2",

    "experimental_activity_labels_used":
        False,

    "source_structured_domain_version":
        "structured_v1_2",

    "split":
        SPLIT,

    "constructs":
        EXPECTED_CONSTRUCTS,

    "functional_modules":
        len(
            module_rows
        ),

    "unique_module_sequences":
        len(
            module_sequences_by_hash
        ),

    "structured_domains":
        len(
            structured_domain_rows
        ),

    "unique_domain_sequences_required":
        len(
            required_hashes
        ),

    "internal_boundaries":
        len(
            boundary_rows
        ),

    "unique_internal_boundary_sequences":
        len(
            unique_boundary_sequences
        ),

    "inter_module_junctions":
        len(
            junction_rows
        ),

    "transition_type_counts":
        dict(
            transition_type_counts
        ),

    "experimental_scar_occurrences":
        len(
            scar_rows
        ),

    "scar1_LNRSAV_occurrences":
        sum(
            row[
                "scar_sequence"
            ]
            ==
            "LNRSAV"

            for row in scar_rows
        ),

    "scar2_NPCSEI_occurrences":
        sum(
            row[
                "scar_sequence"
            ]
            ==
            "NPCSEI"

            for row in scar_rows
        ),

    "experimental_scars_as_J":
        0,

    "boundary_flank_policy_aa":
        BOUNDARY_FLANK_AA,

    "max_biological_tokens":
        max(
            token_counts
        ),
}


with (
    TMP_OUT
    / "build_summary.json"
).open(
    "w",
) as f:

    json.dump(
        summary,
        f,
        indent=2,
        sort_keys=True,
    )

    f.write(
        "\n"
    )


# ======================================================================
# 13. LOAD THROUGH THE REAL RUNTIME STORES BEFORE COMMIT
# ======================================================================

print()
print(
    "=" * 100
)

print(
    "RUNTIME CONTRACT VALIDATION"
)

print(
    "=" * 100
)


from neuralps.data.structured_module_store_v1_1 import (
    StructuredModuleStoreV1_1,
)

from neuralps.data.assembly_context_store_v2 import (
    AssemblyContextStoreV2,
)

from neuralps.data.junction_store import (
    JunctionStore,
)


structured_store = (
    StructuredModuleStoreV1_1(
        TMP_OUT
    )
)


if len(
    structured_store
) != EXPECTED_MODULES:

    raise RuntimeError(
        "StructuredModuleStore runtime "
        "count mismatch"
    )


assembly_store = (
    AssemblyContextStoreV2(
        module_occurrences_path=(
            TMP_OUT
            / "module_occurrences.tsv.gz"
        ),

        interfaces_path=(
            TMP_OUT
            / "interfaces.tsv.gz"
        ),

        junctions_path=(
            TMP_OUT
            / "junctions.tsv.gz"
        ),
    )
)


if len(
    assembly_store
) != EXPECTED_CONSTRUCTS:

    raise RuntimeError(
        "AssemblyContextStore runtime "
        "count mismatch"
    )


junction_store = (
    JunctionStore(
        TMP_OUT
        / "junctions.tsv.gz"
    )
)


if len(
    junction_store
) != EXPECTED_TRANSITIONS:

    raise RuntimeError(
        "JunctionStore runtime "
        "count mismatch"
    )


print(
    "StructuredModuleStoreV1_1:",
    len(
        structured_store
    ),
    "PASS",
)

print(
    "AssemblyContextStoreV2:",
    len(
        assembly_store
    ),
    "PASS",
)

print(
    "JunctionStore:",
    len(
        junction_store
    ),
    "PASS",
)


# ======================================================================
# 14. FINAL HARD CONTRACT
# ======================================================================

assert len(
    module_rows
) == 517

assert len(
    structured_domain_rows
) == 1807

assert len(
    boundary_rows
) == 1290

assert len(
    junction_rows
) == 411

assert len(
    scar_rows
) == 212

assert sum(
    row[
        "scar_sequence"
    ]
    ==
    "LNRSAV"

    for row in scar_rows
) == 106

assert sum(
    row[
        "scar_sequence"
    ]
    ==
    "NPCSEI"

    for row in scar_rows
) == 106

assert all(
    row[
        "left_domain_type"
    ]
    ==
    "AMP-binding"
    and
    row[
        "right_domain_type"
    ]
    ==
    "PCP"

    for row in scar_rows
)

assert (
    len(
        structured_domain_rows
    )
    -
    len(
        module_rows
    )
    ==
    1290
)

assert (
    len(
        module_rows
    )
    -
    106
    ==
    411
)


# ======================================================================
# 15. ATOMIC COMMIT
# ======================================================================

backup = None


if FINAL_OUT.exists():

    stamp = datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )

    backup = (
        FINAL_OUT.parent
        /
        (
            FINAL_OUT.name
            +
            f"_backup_{stamp}"
        )
    )

    FINAL_OUT.rename(
        backup
    )


TMP_OUT.rename(
    FINAL_OUT
)


print()
print(
    "=" * 100
)

print(
    "FINAL MODEL-READY PHASE-2 CONTRACT"
)

print(
    "=" * 100
)

print(
    "constructs:              106"
)

print(
    "functional modules:      517"
)

print(
    "D occurrences:          1807"
)

print(
    "B occurrences:          1290"
)

print(
    "J occurrences:           411"
)

print(
    "engineered scar B:       212"
)

print(
    "scar1 LNRSAV B:          106"
)

print(
    "scar2 NPCSEI B:          106"
)

print(
    "scar-as-J:                 0"
)

print(
    "unique modules:",
    len(
        module_sequences_by_hash
    ),
)

print(
    "unique B:",
    len(
        unique_boundary_sequences
    ),
)

print(
    "J types:",
    dict(
        transition_type_counts
    ),
)


print()
print(
    "OUTPUT:"
)

print(
    FINAL_OUT
)


if backup is not None:

    print(
        "previous output preserved:"
    )

    print(
        backup
    )


print()
print(
    "=" * 100
)

print(
    "BODE PHASE-2 MODEL-READY V1.2: FULL PASS"
)

print(
    "=" * 100
)
