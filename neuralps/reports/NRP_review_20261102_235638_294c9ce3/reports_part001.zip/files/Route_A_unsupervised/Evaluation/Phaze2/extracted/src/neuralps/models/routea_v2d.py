from __future__ import annotations

from dataclasses import dataclass, replace, fields

import torch

from neuralps.data.structured_module_batch_v1_1 import (
    StructuredModuleBatchV1_1,
)

from neuralps.data.path_routing_batch_v2 import (
    PathRoutingBatchV2,
)

from neuralps.models.routea_v2a import (
    RouteAV2A,
    MODEL_DIM,
    JUNCTION_DIM,
)

from neuralps.models.candidate_assembly_track_v2 import (
    CandidateAssemblyTrackBuilderV2,
)

from neuralps.models.assembly_encoder_v2 import (
    AssemblyEncoderV2,
)

from neuralps.models.assembly_readout_feedback_v2 import (
    AssemblyGlobalPoolV2,
    AssemblyCoherenceScorerV2,
)


# ==========================================================
# V2-D hierarchical biological interaction modules
# ==========================================================

from neuralps.models.biological_seams_v2d import (
    ATSeamEncoderV2D,
    TCSeamEncoderV2D,
)


from neuralps.models.assembly_biology_cross_v2d import (
    AssemblyBiologicalCrossBlockV2D,
    gather_assembly_neighborhood_v2d,
    BIO_A,
    BIO_PATH_CORE,
    BIO_CARRIER,
    BIO_AT_SEAM,
    BIO_EXIT,
    BIO_PHYSICAL_EDGE,
    BIO_DOWNSTREAM_ENTRY,
    BIO_TC_SEAM,
)


from neuralps.models.assembly_structure_v2d import (
    FullDAssemblyStructureBuilderV2D,
)


from neuralps.models.assembly_encoder_v2d import (
    AssemblyEncoderV2D,
)


from neuralps.models.biological_token_feedback_full_v2d import (
    BiologicalTokenAssemblyFeedbackV2D,
)


from neuralps.models.hierarchical_module_rebuild_v2d import (
    HierarchicalModuleRebuilderV2D,
)


from neuralps.models.biological_feedback_v2d import (
    BiologicalSeamToModuleFeedbackV2D,
    QueryJunctionRefinerV2D,
    LocalAssemblyTrackRebuilderV2D,
)


from neuralps.models.round2_local_refiner_v2d import (
    Round2LocalEdgeRefinerV2D,
)


@dataclass(
    frozen=True,
    slots=True,
)
class RouteAV2DOutput:
    """
    Route-A V2-D bidirectional output.

    final forward/reverse scores:
        local score after optional assembly->local feedback
        +
        optional whole-assembly coherence score

    Shapes:
        all score tensors [B,K]

        forward_assembly_z:
            [B,K,256]

        reverse_assembly_z:
            [B,K,256]

        z_junction:
            [B,64]

    """

    forward_scores: torch.Tensor
    reverse_scores: torch.Tensor

    # Local compatibility score before final V2-D assembly contextual scoring.
    forward_pre_feedback_scores: torch.Tensor
    reverse_pre_feedback_scores: torch.Tensor

    # Local scores AFTER optional feedback.
    forward_local_scores: torch.Tensor
    reverse_local_scores: torch.Tensor

    forward_assembly_scores: torch.Tensor
    reverse_assembly_scores: torch.Tensor

    forward_assembly_z: torch.Tensor
    reverse_assembly_z: torch.Tensor

    z_junction: torch.Tensor



    def validate(
        self,
    ) -> None:

        if self.forward_scores.ndim != 2:
            raise RuntimeError(
                "forward_scores must be [B,K]"
            )

        if self.reverse_scores.shape != (
            self.forward_scores.shape
        ):
            raise RuntimeError(
                "reverse score shape mismatch"
            )

        expected_scores = (
            self.forward_scores.shape
        )


        for name in (
            "forward_pre_feedback_scores",
            "reverse_pre_feedback_scores",
            "forward_local_scores",
            "reverse_local_scores",
            "forward_assembly_scores",
            "reverse_assembly_scores",
        ):

            value = getattr(
                self,
                name,
            )

            if value.shape != expected_scores:
                raise RuntimeError(
                    f"{name} shape mismatch"
                )

            if not torch.isfinite(
                value
            ).all():
                raise RuntimeError(
                    f"non-finite {name}"
                )


        B, K = expected_scores


        for name in (
            "forward_assembly_z",
            "reverse_assembly_z",
        ):

            value = getattr(
                self,
                name,
            )

            if value.shape != (
                B,
                K,
                MODEL_DIM,
            ):
                raise RuntimeError(
                    f"{name} shape mismatch"
                )

            if not torch.isfinite(
                value
            ).all():
                raise RuntimeError(
                    f"non-finite {name}"
                )


        if self.z_junction.shape != (
            B,
            JUNCTION_DIM,
        ):
            raise RuntimeError(
                "z_junction shape mismatch"
            )


        if not torch.isfinite(
            self.forward_scores
        ).all():
            raise RuntimeError(
                "non-finite forward final scores"
            )


        if not torch.isfinite(
            self.reverse_scores
        ).all():
            raise RuntimeError(
                "non-finite reverse final scores"
            )


class RouteAV2D(
    RouteAV2A
):
    """
    Route-A V2-D.

    Shared V2-A local biology:
        StructuredModuleEncoderV2
        PathAttentionPoolV2
        JunctionEncoder
        EdgeEncoderV2
        LocalInterfaceScorerV2

    Added assembly path:
        natural M/J representations
            ↓
        candidate replacement
        far-side J_MASK
            ↓
        4-layer banded AssemblyEncoderV2
            ↓
        learned global [ASM] readout
            ↓
        whole-assembly coherence score

    C additionally performs:

        z_edge_C =
            z_edge_A
            + g * W(z_assembly)

        g ~= 0.01 initially

    V2-D performs hierarchical assembly recycling:

        module/junction representations
                |
                v
        assembly contextualization
                |
                v
        biological seam interaction
                |
                v
        module rebuilding
                |
                v
        second assembly pass
                |
                v
        contextualized edge refinement
    """

    def __init__(
        self,
        *,
        attention_radius: int = 4,
        assembly_dropout: float = 0.1,
        **local_kwargs,
    ) -> None:

        super().__init__(
            **local_kwargs
        )


        # ----------------------------------------------------------
        # Candidate-conditioning primitive.
        # No trainable parameters.
        # ----------------------------------------------------------

        self.assembly_track_builder = (
            CandidateAssemblyTrackBuilderV2()
        )


        # ----------------------------------------------------------
        # Candidate-conditioned banded assembly contextualization.
        # ----------------------------------------------------------

        self.assembly_encoder = (
            AssemblyEncoderV2(
                attention_radius=(
                    attention_radius
                ),

                dropout=(
                    assembly_dropout
                ),
            )
        )


        # ----------------------------------------------------------
        # Global [ASM]-style READOUT after banded contextualization.
        # ----------------------------------------------------------

        self.assembly_pool = (
            AssemblyGlobalPoolV2(
                dropout=(
                    assembly_dropout
                ),
            )
        )


        # ----------------------------------------------------------
        # Shared forward/reverse assembly coherence head.
        # ----------------------------------------------------------

        self.assembly_scorer = (
            AssemblyCoherenceScorerV2()
        )


        # ----------------------------------------------------------
        # V2-D hierarchical biological interaction.
        #
        # Assembly level
        #       |
        #       +---- AT seam interaction
        #       |
        #       +---- TC seam interaction
        #       |
        #       v
        # Module rebuilding
        #       |
        #       v
        # Assembly recycling
        #       |
        #       v
        # Round-2 edge refinement
        #
        # This replaces the legacy scalar feedback bottleneck.
        # ----------------------------------------------------------

        self.at_encoder = ATSeamEncoderV2D()

        self.tc_encoder = TCSeamEncoderV2D()


        self.at_cross = (
            AssemblyBiologicalCrossBlockV2D()
        )

        self.tc_cross = (
            AssemblyBiologicalCrossBlockV2D()
        )


        self.module_rebuilder = (
            HierarchicalModuleRebuilderV2D()
        )


        self.seam_module_feedback = (
            BiologicalSeamToModuleFeedbackV2D()
        )


        self.edge_refiner = (
            Round2LocalEdgeRefinerV2D()
        )


        # ----------------------------------------------------------
        # FULL V2-D ASSEMBLY HIERARCHY.
        #
        # The core AssemblyEncoderV2 remains responsible
        # for the proven candidate-conditioned CORE track.
        #
        # FullDAssemblyStructureBuilderV2D then promotes that core:
        #
        #   M-J-M-J-...
        #
        # into:
        #
        #   [ASM]-M-J-M-J-...
        #
        # with the directional leakage firewall preserved.
        # ----------------------------------------------------------

        self.full_d_structure_builder = (
            FullDAssemblyStructureBuilderV2D()
        )


        self.full_d_assembly_encoder = (
            AssemblyEncoderV2D(
                local_radius=attention_radius,
                dropout=assembly_dropout,
            )
        )


        # ----------------------------------------------------------
        # Assembly -> biological-token feedback.
        # ----------------------------------------------------------

        self.token_feedback = (
            BiologicalTokenAssemblyFeedbackV2D(
                dropout=assembly_dropout,
            )
        )


        # ----------------------------------------------------------
        # Round-1 query-junction biological refinement followed by
        # rebuilding of the candidate-conditioned Full-D track.
        #
        # This is the bridge into the SECOND assembly pass.
        # ----------------------------------------------------------

        self.query_junction_refiner = (
            QueryJunctionRefinerV2D()
        )


        self.local_track_rebuilder = (
            LocalAssemblyTrackRebuilderV2D()
        )


    def forward(
        self,
        *,
        # ==========================================================
        # Exact V2-A local inputs.
        # ==========================================================

        forward_left_structured: (
            StructuredModuleBatchV1_1
        ),

        forward_left_routing: (
            PathRoutingBatchV2
        ),

        forward_right_structured: (
            StructuredModuleBatchV1_1
        ),

        forward_right_routing: (
            PathRoutingBatchV2
        ),

        reverse_left_structured: (
            StructuredModuleBatchV1_1
        ),

        reverse_left_routing: (
            PathRoutingBatchV2
        ),

        reverse_right_structured: (
            StructuredModuleBatchV1_1
        ),

        reverse_right_routing: (
            PathRoutingBatchV2
        ),

        junction_aa: torch.Tensor,
        junction_mask: torch.Tensor,
        junction_kind: torch.Tensor,
        junction_log_length: torch.Tensor,


        # ==========================================================
        # Compact natural assembly inputs from RouteATrainCollatorV2B.
        # ==========================================================

        assembly_structured: (
            StructuredModuleBatchV1_1
        ),

        assembly_junction_aa: torch.Tensor,
        assembly_junction_mask: torch.Tensor,
        assembly_junction_kind: torch.Tensor,
        assembly_junction_log_length: torch.Tensor,

        assembly_module_offset: torch.Tensor,
        assembly_transition_offset: torch.Tensor,
        assembly_module_count: torch.Tensor,

        assembly_query_transition_index: torch.Tensor,

        assembly_forward_candidate_module_index: torch.Tensor,
        assembly_reverse_candidate_module_index: torch.Tensor,

        assembly_forward_far_mask_transition_index: torch.Tensor,
        assembly_reverse_far_mask_transition_index: torch.Tensor,


        batch_size: int,
        candidate_count: int,
    ) -> RouteAV2DOutput:

        if batch_size <= 0:
            raise RuntimeError(
                "batch_size must be positive"
            )


        if candidate_count < 2:
            raise RuntimeError(
                "candidate_count must be >=2"
            )


        # ==========================================================
        # EXACT V2-A MODULE ENCODING.
        # ==========================================================

        fwd_left = self.module_encoder(
            forward_left_structured
        )

        fwd_right = self.module_encoder(
            forward_right_structured
        )

        rev_left = self.module_encoder(
            reverse_left_structured
        )

        rev_right = self.module_encoder(
            reverse_right_structured
        )


        # ==========================================================
        # Natural assembly modules use THE SAME module encoder.
        # ==========================================================

        assembly_modules = self.module_encoder(
            assembly_structured
        )


        if (
            assembly_modules.module_z.ndim
            != 2
            or assembly_modules.module_z.shape[-1]
            != MODEL_DIM
        ):
            raise RuntimeError(
                "Unexpected natural assembly module_z"
            )


        # ==========================================================
        # EXACT V2-A PATH POOLING.
        # ==========================================================

        fwd_left_paths = self.path_pool(
            fwd_left,
            forward_left_routing,
        )

        fwd_right_paths = self.path_pool(
            fwd_right,
            forward_right_routing,
        )

        rev_left_paths = self.path_pool(
            rev_left,
            reverse_left_routing,
        )

        rev_right_paths = self.path_pool(
            rev_right,
            reverse_right_routing,
        )


        # ==========================================================
        # EXACT V2-A INTERFACE-FACING DOMAIN STATES.
        # ==========================================================

        fwd_left_terminal = (
            self._gather_domain_state(
                fwd_left.token_z,

                forward_left_routing
                .terminal_token_index,

                name=(
                    "forward left terminal"
                ),
            )
            .unsqueeze(1)
            .expand(
                -1,
                candidate_count,
                -1,
            )
        )


        fwd_right_initial = (
            self._gather_domain_state(
                fwd_right.token_z,

                forward_right_routing
                .initial_token_index,

                name=(
                    "forward right initial"
                ),
            )
            .reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )


        rev_left_terminal = (
            self._gather_domain_state(
                rev_left.token_z,

                reverse_left_routing
                .terminal_token_index,

                name=(
                    "reverse left terminal"
                ),
            )
            .reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )


        rev_right_initial = (
            self._gather_domain_state(
                rev_right.token_z,

                reverse_right_routing
                .initial_token_index,

                name=(
                    "reverse right initial"
                ),
            )
            .unsqueeze(1)
            .expand(
                -1,
                candidate_count,
                -1,
            )
        )


        # ==========================================================
        # EXACT V2-A QUERY JUNCTION.
        # ==========================================================

        z_junction = self.junction_encoder(
            junction_aa,
            junction_mask,
            junction_kind,
            junction_log_length,
        )


        if z_junction.shape != (
            batch_size,
            JUNCTION_DIM,
        ):
            raise RuntimeError(
                "Unexpected local query junction shape"
            )


        # ==========================================================
        # EXACT V2-A LOCAL EDGE STATES.
        # ==========================================================

        forward_edge_A = self.edge_encoder(
            left_terminal_z=(
                fwd_left_terminal
            ),

            z_junction=(
                z_junction
            ),

            right_initial_z=(
                fwd_right_initial
            ),
        )


        reverse_edge_A = self.edge_encoder(
            left_terminal_z=(
                rev_left_terminal
            ),

            z_junction=(
                z_junction
            ),

            right_initial_z=(
                rev_right_initial
            ),
        )


        expected_edge = (
            batch_size,
            candidate_count,
            MODEL_DIM,
        )


        if forward_edge_A.shape != expected_edge:
            raise RuntimeError(
                "Forward local edge shape drift"
            )


        if reverse_edge_A.shape != expected_edge:
            raise RuntimeError(
                "Reverse local edge shape drift"
            )


        # ==========================================================
        # EXACT PRE-FEEDBACK V2-A-LIKE LOCAL SCORES.
        #
        # These scores use forward_edge_A / reverse_edge_A BEFORE
        # assembly context is allowed to modify the local seam.
        #
        # They provide the protected local SSL branch:
        #
        #   L_A = bidirectional InfoNCE(pre-feedback local)
        #
        # while the normal final scores provide:
        #
        #   L_context = bidirectional InfoNCE(contextual final)
        # ==========================================================

        forward_pre_feedback_scores = (
            self.local_scorer(
                left_module_z=(
                    fwd_left.module_z
                ),

                left_core_z=(
                    fwd_left_paths.core_z
                ),

                left_exit_z=(
                    fwd_left_paths.exit_z
                ),

                z_edge=(
                    forward_edge_A
                ),

                right_entry_z=(
                    fwd_right_paths
                    .entry_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                right_core_z=(
                    fwd_right_paths
                    .core_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                right_module_z=(
                    fwd_right
                    .module_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),
            )
        )


        reverse_pre_feedback_scores = (
            self.local_scorer(
                left_module_z=(
                    rev_left
                    .module_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                left_core_z=(
                    rev_left_paths
                    .core_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                left_exit_z=(
                    rev_left_paths
                    .exit_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                z_edge=(
                    reverse_edge_A
                ),

                right_entry_z=(
                    rev_right_paths.entry_z
                ),

                right_core_z=(
                    rev_right_paths.core_z
                ),

                right_module_z=(
                    rev_right.module_z
                ),
            )
        )


        expected_local_scores = (
            batch_size,
            candidate_count,
        )


        if (
            forward_pre_feedback_scores.shape
            != expected_local_scores
        ):
            raise RuntimeError(
                "Forward pre-feedback score shape drift"
            )


        if (
            reverse_pre_feedback_scores.shape
            != expected_local_scores
        ):
            raise RuntimeError(
                "Reverse pre-feedback score shape drift"
            )


        if not torch.isfinite(
            forward_pre_feedback_scores
        ).all():
            raise RuntimeError(
                "Non-finite forward pre-feedback scores"
            )


        if not torch.isfinite(
            reverse_pre_feedback_scores
        ).all():
            raise RuntimeError(
                "Non-finite reverse pre-feedback scores"
            )


        # ==========================================================
        # NATURAL ASSEMBLY JUNCTION STATES.
        #
        # Same JunctionEncoder semantics as query J.
        # Same inherited 64 -> 256 seam projection.
        # ==========================================================

        assembly_junction_64 = (
            self.junction_encoder(
                assembly_junction_aa,
                assembly_junction_mask,
                assembly_junction_kind,
                assembly_junction_log_length,
            )
        )


        if (
            assembly_junction_64.ndim != 2
            or assembly_junction_64.shape[-1]
            != JUNCTION_DIM
        ):
            raise RuntimeError(
                "Unexpected assembly junction shape"
            )


        assembly_junction_z = (
            self
            .edge_encoder
            .junction_seam_projection(
                assembly_junction_64
            )
        )


        if (
            assembly_junction_z.ndim != 2
            or assembly_junction_z.shape[-1]
            != MODEL_DIM
        ):
            raise RuntimeError(
                "Unexpected projected assembly junction shape"
            )


        # ==========================================================
        # Candidate module states are REUSED from local V2-A branch.
        #
        # No candidate biological re-encoding.
        # ==========================================================

        forward_candidate_module_z = (
            fwd_right
            .module_z
            .reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )


        reverse_candidate_module_z = (
            rev_left
            .module_z
            .reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )


        # ==========================================================
        # Candidate-condition BEFORE any assembly attention.
        # ==========================================================

        forward_track = (
            self
            .assembly_track_builder
            .build(
                base_module_z=(
                    assembly_modules
                    .module_z
                ),

                base_junction_z=(
                    assembly_junction_z
                ),

                module_offset=(
                    assembly_module_offset
                ),

                transition_offset=(
                    assembly_transition_offset
                ),

                module_count=(
                    assembly_module_count
                ),

                query_transition_index=(
                    assembly_query_transition_index
                ),

                candidate_module_index=(
                    assembly_forward_candidate_module_index
                ),

                far_mask_transition_index=(
                    assembly_forward_far_mask_transition_index
                ),

                candidate_module_z=(
                    forward_candidate_module_z
                ),

                j_mask_z=(
                    self
                    .assembly_encoder
                    .j_mask_z
                ),

                direction="forward",
            )
        )


        reverse_track = (
            self
            .assembly_track_builder
            .build(
                base_module_z=(
                    assembly_modules
                    .module_z
                ),

                base_junction_z=(
                    assembly_junction_z
                ),

                module_offset=(
                    assembly_module_offset
                ),

                transition_offset=(
                    assembly_transition_offset
                ),

                module_count=(
                    assembly_module_count
                ),

                query_transition_index=(
                    assembly_query_transition_index
                ),

                candidate_module_index=(
                    assembly_reverse_candidate_module_index
                ),

                far_mask_transition_index=(
                    assembly_reverse_far_mask_transition_index
                ),

                candidate_module_z=(
                    reverse_candidate_module_z
                ),

                j_mask_z=(
                    self
                    .assembly_encoder
                    .j_mask_z
                ),

                direction="reverse",
            )
        )


        # ==========================================================
        # V2-D CORE ASSEMBLY CONTEXTUALIZATION.
        #
        # Retained as the proven candidate-conditioned core path.
        # ==========================================================

        forward_assembly_encoded = (
            self.assembly_encoder(
                forward_track
            )
        )


        reverse_assembly_encoded = (
            self.assembly_encoder(
                reverse_track
            )
        )


        # ==========================================================
        # V2-D FULL STRUCTURAL TRACK.
        #
        # Promote:
        #
        #     M-J-M-J-...
        #
        # to:
        #
        #     [ASM]-M-J-M-J-...
        #
        # while preserving the audited directional leakage firewall.
        # ==========================================================

        forward_full_track = (
            self.full_d_structure_builder.build(
                core_track=forward_track,

                assembly_junction_kind=(
                    assembly_junction_kind
                ),

                transition_offset=(
                    assembly_module_count - 1
                ),

                module_count=(
                    assembly_module_count
                ),
            )
        )


        reverse_full_track = (
            self.full_d_structure_builder.build(
                core_track=reverse_track,

                assembly_junction_kind=(
                    assembly_junction_kind
                ),

                transition_offset=(
                    assembly_module_count - 1
                ),

                module_count=(
                    assembly_module_count
                ),
            )
        )


        # ==========================================================
        # V2-D ASSEMBLY ROUND 1.
        #
        # [ASM] <-> all visible M/J
        # M/J   <-> local visible M/J
        # hidden far side remains inaccessible.
        # ==========================================================

        forward_full_pass1 = (
            self.full_d_assembly_encoder(
                forward_full_track
            )
        )


        reverse_full_pass1 = (
            self.full_d_assembly_encoder(
                reverse_full_track
            )
        )


        # ==========================================================
        # Query-local assembly memories for biology interaction:
        #
        #     [ASM, M_left, J_query, M_right]
        # ==========================================================

        forward_full_neighborhood = (
            gather_assembly_neighborhood_v2d(
                encoded=forward_full_pass1,
                structure=forward_full_track,
            )
        )


        reverse_full_neighborhood = (
            gather_assembly_neighborhood_v2d(
                encoded=reverse_full_pass1,
                structure=reverse_full_track,
            )
        )


        # ==========================================================
        # V2-D BIOLOGICAL SEAMS AFTER FULL-D ROUND 1.
        #
        # Build explicit:
        #
        #   A -> carrier / AT
        #
        # and:
        #
        #   carrier -> exit -> physical J -> downstream entry / TC
        #
        # for BOTH physical modules adjacent to the query junction.
        # ==========================================================

        def _gather_optional_token_state(
            token_z: torch.Tensor,
            token_index: torch.Tensor,
        ):
            """
            Gather an optional structured token.

            token_z:
                [N,T,D]

            token_index:
                [N], with -1 meaning unavailable.
            """

            if token_z.ndim != 3:
                raise RuntimeError(
                    "optional token source must be [N,T,D]"
                )

            if token_index.shape != (
                token_z.shape[0],
            ):
                raise RuntimeError(
                    "optional token index geometry drift"
                )

            valid = (
                token_index >= 0
            )

            safe_index = (
                token_index.clamp(
                    min=0,
                    max=token_z.shape[1] - 1,
                )
            )

            row = torch.arange(
                token_z.shape[0],
                device=token_z.device,
            )

            z = token_z[
                row,
                safe_index,
            ]

            z = torch.where(
                valid.unsqueeze(-1),
                z,
                torch.zeros_like(z),
            )

            return z, valid


        def _expand_fixed_to_candidates(
            x: torch.Tensor,
        ) -> torch.Tensor:
            """
            [B,...] -> [B,K,...]
            """

            if x.shape[0] != batch_size:
                raise RuntimeError(
                    "fixed-side batch geometry drift"
                )

            return (
                x.unsqueeze(1)
                .expand(
                    (
                        batch_size,
                        candidate_count,
                    )
                    + tuple(
                        x.shape[1:]
                    )
                )
            )


        def _reshape_candidate_side(
            x: torch.Tensor,
        ) -> torch.Tensor:
            """
            [B*K,...] -> [B,K,...]
            """

            if x.shape[0] != (
                batch_size
                * candidate_count
            ):
                raise RuntimeError(
                    "candidate-side batch geometry drift"
                )

            return x.reshape(
                (
                    batch_size,
                    candidate_count,
                )
                + tuple(
                    x.shape[1:]
                )
            )


        # ==========================================================
        # RAW AT SEAMS.
        # ==========================================================

        fwd_left_at_raw = (
            self.at_encoder(
                token_z=fwd_left.token_z,

                a_token_index=(
                    forward_left_routing.a_token_index
                ),

                carrier_token_index=(
                    forward_left_routing.carrier_token_index
                ),

                core_z=(
                    fwd_left_paths.core_z
                ),

                core_available=(
                    fwd_left_paths.core_available
                ),
            )
        )


        fwd_right_at_raw = (
            self.at_encoder(
                token_z=fwd_right.token_z,

                a_token_index=(
                    forward_right_routing.a_token_index
                ),

                carrier_token_index=(
                    forward_right_routing.carrier_token_index
                ),

                core_z=(
                    fwd_right_paths.core_z
                ),

                core_available=(
                    fwd_right_paths.core_available
                ),
            )
        )


        rev_left_at_raw = (
            self.at_encoder(
                token_z=rev_left.token_z,

                a_token_index=(
                    reverse_left_routing.a_token_index
                ),

                carrier_token_index=(
                    reverse_left_routing.carrier_token_index
                ),

                core_z=(
                    rev_left_paths.core_z
                ),

                core_available=(
                    rev_left_paths.core_available
                ),
            )
        )


        rev_right_at_raw = (
            self.at_encoder(
                token_z=rev_right.token_z,

                a_token_index=(
                    reverse_right_routing.a_token_index
                ),

                carrier_token_index=(
                    reverse_right_routing.carrier_token_index
                ),

                core_z=(
                    rev_right_paths.core_z
                ),

                core_available=(
                    rev_right_paths.core_available
                ),
            )
        )


        # ==========================================================
        # Gather A / carrier states required by explicit AT and TC
        # biological queries.
        # ==========================================================

        (
            fwd_left_a_z_0,
            fwd_left_a_available_0,
        ) = _gather_optional_token_state(
            fwd_left.token_z,
            forward_left_routing.a_token_index,
        )

        (
            fwd_left_carrier_z_0,
            fwd_left_carrier_available_0,
        ) = _gather_optional_token_state(
            fwd_left.token_z,
            forward_left_routing.carrier_token_index,
        )


        (
            fwd_right_a_z_0,
            fwd_right_a_available_0,
        ) = _gather_optional_token_state(
            fwd_right.token_z,
            forward_right_routing.a_token_index,
        )

        (
            fwd_right_carrier_z_0,
            fwd_right_carrier_available_0,
        ) = _gather_optional_token_state(
            fwd_right.token_z,
            forward_right_routing.carrier_token_index,
        )


        (
            rev_left_a_z_0,
            rev_left_a_available_0,
        ) = _gather_optional_token_state(
            rev_left.token_z,
            reverse_left_routing.a_token_index,
        )

        (
            rev_left_carrier_z_0,
            rev_left_carrier_available_0,
        ) = _gather_optional_token_state(
            rev_left.token_z,
            reverse_left_routing.carrier_token_index,
        )


        (
            rev_right_a_z_0,
            rev_right_a_available_0,
        ) = _gather_optional_token_state(
            rev_right.token_z,
            reverse_right_routing.a_token_index,
        )

        (
            rev_right_carrier_z_0,
            rev_right_carrier_available_0,
        ) = _gather_optional_token_state(
            rev_right.token_z,
            reverse_right_routing.carrier_token_index,
        )


        # ==========================================================
        # Put fixed and candidate sides into common [B,K,...]
        # geometry.
        # ==========================================================

        fwd_left_a_z = (
            _expand_fixed_to_candidates(
                fwd_left_a_z_0
            )
        )

        fwd_left_carrier_z = (
            _expand_fixed_to_candidates(
                fwd_left_carrier_z_0
            )
        )

        fwd_left_core_z = (
            _expand_fixed_to_candidates(
                fwd_left_paths.core_z
            )
        )

        fwd_left_at_z = (
            _expand_fixed_to_candidates(
                fwd_left_at_raw.z_at
            )
        )

        fwd_left_at_available = (
            _expand_fixed_to_candidates(
                fwd_left_at_raw.available
            )
        )


        fwd_right_a_z = (
            _reshape_candidate_side(
                fwd_right_a_z_0
            )
        )

        fwd_right_carrier_z = (
            _reshape_candidate_side(
                fwd_right_carrier_z_0
            )
        )

        fwd_right_core_z = (
            _reshape_candidate_side(
                fwd_right_paths.core_z
            )
        )

        fwd_right_at_z = (
            _reshape_candidate_side(
                fwd_right_at_raw.z_at
            )
        )

        fwd_right_at_available = (
            _reshape_candidate_side(
                fwd_right_at_raw.available
            )
        )


        rev_left_a_z = (
            _reshape_candidate_side(
                rev_left_a_z_0
            )
        )

        rev_left_carrier_z = (
            _reshape_candidate_side(
                rev_left_carrier_z_0
            )
        )

        rev_left_core_z = (
            _reshape_candidate_side(
                rev_left_paths.core_z
            )
        )

        rev_left_at_z = (
            _reshape_candidate_side(
                rev_left_at_raw.z_at
            )
        )

        rev_left_at_available = (
            _reshape_candidate_side(
                rev_left_at_raw.available
            )
        )


        rev_right_a_z = (
            _expand_fixed_to_candidates(
                rev_right_a_z_0
            )
        )

        rev_right_carrier_z = (
            _expand_fixed_to_candidates(
                rev_right_carrier_z_0
            )
        )

        rev_right_core_z = (
            _expand_fixed_to_candidates(
                rev_right_paths.core_z
            )
        )

        rev_right_at_z = (
            _expand_fixed_to_candidates(
                rev_right_at_raw.z_at
            )
        )

        rev_right_at_available = (
            _expand_fixed_to_candidates(
                rev_right_at_raw.available
            )
        )


        # ==========================================================
        # RAW TC SEAMS.
        # ==========================================================

        fwd_left_exit_z = (
            _expand_fixed_to_candidates(
                fwd_left_paths.exit_z
            )
        )

        fwd_left_exit_available = (
            _expand_fixed_to_candidates(
                fwd_left_paths.exit_available
            )
        )

        fwd_right_entry_z = (
            _reshape_candidate_side(
                fwd_right_paths.entry_z
            )
        )

        fwd_right_entry_available = (
            _reshape_candidate_side(
                fwd_right_paths.entry_available
            )
        )


        forward_tc_available = (
            _expand_fixed_to_candidates(
                fwd_left_carrier_available_0
            )
            & fwd_left_exit_available
            & fwd_right_entry_available
        )


        forward_tc_raw = (
            self.tc_encoder(
                left_carrier_z=(
                    fwd_left_carrier_z
                ),

                left_exit_z=(
                    fwd_left_exit_z
                ),

                edge_z=(
                    forward_edge_A
                ),

                right_entry_z=(
                    fwd_right_entry_z
                ),

                available=(
                    forward_tc_available
                ),
            )
        )


        rev_left_exit_z = (
            _reshape_candidate_side(
                rev_left_paths.exit_z
            )
        )

        rev_left_exit_available = (
            _reshape_candidate_side(
                rev_left_paths.exit_available
            )
        )

        rev_right_entry_z = (
            _expand_fixed_to_candidates(
                rev_right_paths.entry_z
            )
        )

        rev_right_entry_available = (
            _expand_fixed_to_candidates(
                rev_right_paths.entry_available
            )
        )


        reverse_tc_available = (
            _reshape_candidate_side(
                rev_left_carrier_available_0
            )
            & rev_left_exit_available
            & rev_right_entry_available
        )


        reverse_tc_raw = (
            self.tc_encoder(
                left_carrier_z=(
                    rev_left_carrier_z
                ),

                left_exit_z=(
                    rev_left_exit_z
                ),

                edge_z=(
                    reverse_edge_A
                ),

                right_entry_z=(
                    rev_right_entry_z
                ),

                available=(
                    reverse_tc_available
                ),
            )
        )


        # ==========================================================
        # Biological role tensors.
        # ==========================================================

        at_role_kind = torch.tensor(
            [
                BIO_A,
                BIO_PATH_CORE,
                BIO_CARRIER,
                BIO_AT_SEAM,
            ],
            dtype=torch.long,
            device=forward_edge_A.device,
        ).view(
            1,
            1,
            4,
        ).expand(
            batch_size,
            candidate_count,
            4,
        )


        tc_role_kind = torch.tensor(
            [
                BIO_EXIT,
                BIO_PHYSICAL_EDGE,
                BIO_DOWNSTREAM_ENTRY,
                BIO_TC_SEAM,
            ],
            dtype=torch.long,
            device=forward_edge_A.device,
        ).view(
            1,
            1,
            4,
        ).expand(
            batch_size,
            candidate_count,
            4,
        )


        # ==========================================================
        # AT BIOLOGY <-> ROUND-1 ASSEMBLY.
        #
        # We contextualize LEFT and RIGHT AT states independently
        # against the SAME candidate-conditioned local assembly
        # neighborhood:
        #
        #     [ASM, M_left, J_query, M_right]
        # ==========================================================

        forward_left_at_query = torch.stack(
            [
                fwd_left_a_z,
                fwd_left_core_z,
                fwd_left_carrier_z,
                fwd_left_at_z,
            ],
            dim=2,
        )

        forward_left_at_valid = (
            fwd_left_at_available
            .unsqueeze(-1)
            .expand(
                batch_size,
                candidate_count,
                4,
            )
        )


        forward_left_at_cross = (
            self.at_cross(
                query_z=(
                    forward_left_at_query
                ),

                query_role_kind=(
                    at_role_kind
                ),

                query_valid_mask=(
                    forward_left_at_valid
                ),

                memory_z=(
                    forward_full_neighborhood.memory_z
                ),

                memory_valid_mask=(
                    forward_full_neighborhood.memory_valid_mask
                ),
            )
        )


        forward_right_at_query = torch.stack(
            [
                fwd_right_a_z,
                fwd_right_core_z,
                fwd_right_carrier_z,
                fwd_right_at_z,
            ],
            dim=2,
        )

        forward_right_at_valid = (
            fwd_right_at_available
            .unsqueeze(-1)
            .expand(
                batch_size,
                candidate_count,
                4,
            )
        )


        forward_right_at_cross = (
            self.at_cross(
                query_z=(
                    forward_right_at_query
                ),

                query_role_kind=(
                    at_role_kind
                ),

                query_valid_mask=(
                    forward_right_at_valid
                ),

                memory_z=(
                    forward_full_neighborhood.memory_z
                ),

                memory_valid_mask=(
                    forward_full_neighborhood.memory_valid_mask
                ),
            )
        )


        reverse_left_at_query = torch.stack(
            [
                rev_left_a_z,
                rev_left_core_z,
                rev_left_carrier_z,
                rev_left_at_z,
            ],
            dim=2,
        )

        reverse_left_at_valid = (
            rev_left_at_available
            .unsqueeze(-1)
            .expand(
                batch_size,
                candidate_count,
                4,
            )
        )


        reverse_left_at_cross = (
            self.at_cross(
                query_z=(
                    reverse_left_at_query
                ),

                query_role_kind=(
                    at_role_kind
                ),

                query_valid_mask=(
                    reverse_left_at_valid
                ),

                memory_z=(
                    reverse_full_neighborhood.memory_z
                ),

                memory_valid_mask=(
                    reverse_full_neighborhood.memory_valid_mask
                ),
            )
        )


        reverse_right_at_query = torch.stack(
            [
                rev_right_a_z,
                rev_right_core_z,
                rev_right_carrier_z,
                rev_right_at_z,
            ],
            dim=2,
        )

        reverse_right_at_valid = (
            rev_right_at_available
            .unsqueeze(-1)
            .expand(
                batch_size,
                candidate_count,
                4,
            )
        )


        reverse_right_at_cross = (
            self.at_cross(
                query_z=(
                    reverse_right_at_query
                ),

                query_role_kind=(
                    at_role_kind
                ),

                query_valid_mask=(
                    reverse_right_at_valid
                ),

                memory_z=(
                    reverse_full_neighborhood.memory_z
                ),

                memory_valid_mask=(
                    reverse_full_neighborhood.memory_valid_mask
                ),
            )
        )


        # ==========================================================
        # TC BIOLOGY <-> ROUND-1 ASSEMBLY.
        # ==========================================================

        forward_tc_query = torch.stack(
            [
                fwd_left_exit_z,
                forward_edge_A,
                fwd_right_entry_z,
                forward_tc_raw.z_tc,
            ],
            dim=2,
        )

        forward_tc_valid = (
            forward_tc_raw.available
            .unsqueeze(-1)
            .expand(
                batch_size,
                candidate_count,
                4,
            )
        )


        forward_tc_cross = (
            self.tc_cross(
                query_z=(
                    forward_tc_query
                ),

                query_role_kind=(
                    tc_role_kind
                ),

                query_valid_mask=(
                    forward_tc_valid
                ),

                memory_z=(
                    forward_full_neighborhood.memory_z
                ),

                memory_valid_mask=(
                    forward_full_neighborhood.memory_valid_mask
                ),
            )
        )


        reverse_tc_query = torch.stack(
            [
                rev_left_exit_z,
                reverse_edge_A,
                rev_right_entry_z,
                reverse_tc_raw.z_tc,
            ],
            dim=2,
        )

        reverse_tc_valid = (
            reverse_tc_raw.available
            .unsqueeze(-1)
            .expand(
                batch_size,
                candidate_count,
                4,
            )
        )


        reverse_tc_cross = (
            self.tc_cross(
                query_z=(
                    reverse_tc_query
                ),

                query_role_kind=(
                    tc_role_kind
                ),

                query_valid_mask=(
                    reverse_tc_valid
                ),

                memory_z=(
                    reverse_full_neighborhood.memory_z
                ),

                memory_valid_mask=(
                    reverse_full_neighborhood.memory_valid_mask
                ),
            )
        )



        # ==========================================================
        # FULL V2-D F3B — ASSEMBLY -> D/B BIOLOGICAL FEEDBACK.
        #
        # Tested memory:
        #
        #   0  ASM
        #   1  self module
        #   2  query J
        #   3  other module
        #   4  contextual AT
        #   5  contextual TC
        #
        # [MOD] itself is protected from token-level feedback.
        # ==========================================================

        def _expand_fixed_dataclass_v2d(
            obj,
        ):
            updates = {}

            for field in fields(obj):

                value = getattr(
                    obj,
                    field.name,
                )

                if (
                    torch.is_tensor(value)
                    and value.ndim >= 1
                    and value.shape[0] == batch_size
                ):
                    updates[field.name] = (
                        value
                        .unsqueeze(1)
                        .expand(
                            (
                                batch_size,
                                candidate_count,
                            )
                            + tuple(
                                value.shape[1:]
                            )
                        )
                        .reshape(
                            (
                                batch_size
                                * candidate_count,
                            )
                            + tuple(
                                value.shape[1:]
                            )
                        )
                    )

                elif (
                    field.name == "module_uids"
                    and value is not None
                    and len(value) == batch_size
                ):
                    updates[field.name] = tuple(
                        uid
                        for uid in value
                        for _ in range(
                            candidate_count
                        )
                    )

            return replace(
                obj,
                **updates,
            )


        # ----------------------------------------------------------
        # Correct physical/candidate geometry.
        #
        # forward:
        #     left  = fixed
        #     right = candidate
        #
        # reverse:
        #     left  = candidate
        #     right = fixed
        # ----------------------------------------------------------

        fwd_left_exp = (
            _expand_fixed_dataclass_v2d(
                fwd_left
            )
        )

        fwd_left_routing_exp = (
            _expand_fixed_dataclass_v2d(
                forward_left_routing
            )
        )

        fwd_right_exp = fwd_right
        fwd_right_routing_exp = (
            forward_right_routing
        )


        rev_left_exp = rev_left
        rev_left_routing_exp = (
            reverse_left_routing
        )

        rev_right_exp = (
            _expand_fixed_dataclass_v2d(
                rev_right
            )
        )

        rev_right_routing_exp = (
            _expand_fixed_dataclass_v2d(
                reverse_right_routing
            )
        )


        def _module_token_bk_v2d(
            module,
        ):
            return module.token_z.reshape(
                batch_size,
                candidate_count,
                module.token_z.shape[1],
                MODEL_DIM,
            )


        def _module_padding_bk_v2d(
            module,
        ):
            return (
                module.token_padding_mask
                .reshape(
                    batch_size,
                    candidate_count,
                    module.token_padding_mask.shape[1],
                )
            )


        def _module_z_bk_v2d(
            module,
        ):
            return module.module_z.reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )


        # ==========================================================
        # Six-slot assembly/seam feedback memories.
        # ==========================================================

        def _build_feedback_memory_v2d(
            *,
            neighborhood,
            self_slot: int,
            other_slot: int,
            at_z,
            at_available,
            tc_z,
            tc_available,
        ):
            memory_z = torch.stack(
                (
                    neighborhood.memory_z[
                        :, :, 0, :
                    ],

                    neighborhood.memory_z[
                        :, :, self_slot, :
                    ],

                    neighborhood.memory_z[
                        :, :, 2, :
                    ],

                    neighborhood.memory_z[
                        :, :, other_slot, :
                    ],

                    at_z,
                    tc_z,
                ),
                dim=2,
            )

            memory_valid = torch.stack(
                (
                    neighborhood.memory_valid_mask[
                        :, :, 0
                    ],

                    neighborhood.memory_valid_mask[
                        :, :, self_slot
                    ],

                    neighborhood.memory_valid_mask[
                        :, :, 2
                    ],

                    neighborhood.memory_valid_mask[
                        :, :, other_slot
                    ],

                    at_available,
                    tc_available,
                ),
                dim=2,
            )

            return (
                memory_z,
                memory_valid,
            )


        fwd_left_memory = (
            _build_feedback_memory_v2d(
                neighborhood=(
                    forward_full_neighborhood
                ),

                self_slot=1,
                other_slot=3,

                at_z=(
                    forward_left_at_cross.summary_z
                ),

                at_available=(
                    fwd_left_at_available
                ),

                tc_z=(
                    forward_tc_cross.summary_z
                ),

                tc_available=(
                    forward_tc_raw.available
                ),
            )
        )


        fwd_right_memory = (
            _build_feedback_memory_v2d(
                neighborhood=(
                    forward_full_neighborhood
                ),

                self_slot=3,
                other_slot=1,

                at_z=(
                    forward_right_at_cross.summary_z
                ),

                at_available=(
                    fwd_right_at_available
                ),

                tc_z=(
                    forward_tc_cross.summary_z
                ),

                tc_available=(
                    forward_tc_raw.available
                ),
            )
        )


        rev_left_memory = (
            _build_feedback_memory_v2d(
                neighborhood=(
                    reverse_full_neighborhood
                ),

                self_slot=1,
                other_slot=3,

                at_z=(
                    reverse_left_at_cross.summary_z
                ),

                at_available=(
                    rev_left_at_available
                ),

                tc_z=(
                    reverse_tc_cross.summary_z
                ),

                tc_available=(
                    reverse_tc_raw.available
                ),
            )
        )


        rev_right_memory = (
            _build_feedback_memory_v2d(
                neighborhood=(
                    reverse_full_neighborhood
                ),

                self_slot=3,
                other_slot=1,

                at_z=(
                    reverse_right_at_cross.summary_z
                ),

                at_available=(
                    rev_right_at_available
                ),

                tc_z=(
                    reverse_tc_cross.summary_z
                ),

                tc_available=(
                    reverse_tc_raw.available
                ),
            )
        )


        # ==========================================================
        # REAL structured D/B-token feedback.
        #
        # Every real structured token may receive candidate-specific
        # assembly/seam context EXCEPT [MOD], which remains exactly
        # protected at this stage.
        # ==========================================================

        def _refine_real_module_v2d(
            *,
            module,
            feedback_memory,
        ):
            token_z = (
                _module_token_bk_v2d(
                    module
                )
            )

            padding = (
                _module_padding_bk_v2d(
                    module
                )
            )

            refine_mask = (
                ~padding
            ).clone()

            # Exact F3B contract:
            # protect [MOD].
            refine_mask[
                :, :, 0
            ] = False

            refined = (
                self.token_feedback(
                    raw_token_z=token_z,

                    token_padding_mask=(
                        padding
                    ),

                    refine_mask=(
                        refine_mask
                    ),

                    memory_z=(
                        feedback_memory[0]
                    ),

                    memory_valid_mask=(
                        feedback_memory[1]
                    ),
                )
            )

            return (
                refined,
                padding,
                refine_mask,
            )


        (
            fwd_left_refined,
            fwd_left_padding2,
            fwd_left_refine_mask2,
        ) = _refine_real_module_v2d(
            module=fwd_left_exp,
            feedback_memory=fwd_left_memory,
        )


        (
            fwd_right_refined,
            fwd_right_padding2,
            fwd_right_refine_mask2,
        ) = _refine_real_module_v2d(
            module=fwd_right_exp,
            feedback_memory=fwd_right_memory,
        )


        (
            rev_left_refined,
            rev_left_padding2,
            rev_left_refine_mask2,
        ) = _refine_real_module_v2d(
            module=rev_left_exp,
            feedback_memory=rev_left_memory,
        )


        (
            rev_right_refined,
            rev_right_padding2,
            rev_right_refine_mask2,
        ) = _refine_real_module_v2d(
            module=rev_right_exp,
            feedback_memory=rev_right_memory,
        )


        # ----------------------------------------------------------
        # Preserve the two critical structural invariants.
        # ----------------------------------------------------------

        for (
            name,
            raw_module,
            refined,
        ) in (
            (
                "forward-left",
                fwd_left_exp,
                fwd_left_refined,
            ),
            (
                "forward-right",
                fwd_right_exp,
                fwd_right_refined,
            ),
            (
                "reverse-left",
                rev_left_exp,
                rev_left_refined,
            ),
            (
                "reverse-right",
                rev_right_exp,
                rev_right_refined,
            ),
        ):
            raw_token_bk = (
                _module_token_bk_v2d(
                    raw_module
                )
            )

            if not torch.equal(
                refined.token_z[
                    :, :, 0, :
                ],
                raw_token_bk[
                    :, :, 0, :
                ],
            ):
                raise RuntimeError(
                    f"{name} [MOD] changed "
                    "during D/B feedback"
                )

            if torch.any(
                refined.token_z[
                    refined.token_padding_mask
                ]
                != 0
            ):
                raise RuntimeError(
                    f"{name} padding lost "
                    "exact-zero invariant"
                )


        # ==========================================================
        # Replace ONLY structured token states.
        #
        # Raw/local module zM is deliberately retained separately and
        # later acts as the residual query for hierarchical rebuilding.
        # ==========================================================

        def _replace_tokens_v2d(
            module,
            refined,
        ):
            return replace(
                module,

                token_z=(
                    refined.token_z
                    .reshape(
                        batch_size
                        * candidate_count,

                        refined.token_z.shape[2],

                        MODEL_DIM,
                    )
                ),

                token_padding_mask=(
                    refined.token_padding_mask
                    .reshape(
                        batch_size
                        * candidate_count,

                        refined.token_padding_mask.shape[2],
                    )
                ),
            )


        fwd_left2 = _replace_tokens_v2d(
            fwd_left_exp,
            fwd_left_refined,
        )

        fwd_right2 = _replace_tokens_v2d(
            fwd_right_exp,
            fwd_right_refined,
        )

        rev_left2 = _replace_tokens_v2d(
            rev_left_exp,
            rev_left_refined,
        )

        rev_right2 = _replace_tokens_v2d(
            rev_right_exp,
            rev_right_refined,
        )


        # ==========================================================
        # RECOMPUTE ENTRY / CORE / EXIT FROM REFINED D/B STATES.
        # ==========================================================

        fwd_left_paths2 = (
            self.path_pool(
                fwd_left2,
                fwd_left_routing_exp,
            )
        )

        fwd_right_paths2 = (
            self.path_pool(
                fwd_right2,
                fwd_right_routing_exp,
            )
        )

        rev_left_paths2 = (
            self.path_pool(
                rev_left2,
                rev_left_routing_exp,
            )
        )

        rev_right_paths2 = (
            self.path_pool(
                rev_right2,
                rev_right_routing_exp,
            )
        )


        # ==========================================================
        # RECOMPUTE AT FROM REFINED D/B STATES.
        # ==========================================================

        fwd_left_at2 = (
            self.at_encoder(
                token_z=fwd_left2.token_z,

                a_token_index=(
                    fwd_left_routing_exp.a_token_index
                ),

                carrier_token_index=(
                    fwd_left_routing_exp.carrier_token_index
                ),

                core_z=(
                    fwd_left_paths2.core_z
                ),

                core_available=(
                    fwd_left_paths2.core_available
                ),
            )
        )


        fwd_right_at2 = (
            self.at_encoder(
                token_z=fwd_right2.token_z,

                a_token_index=(
                    fwd_right_routing_exp.a_token_index
                ),

                carrier_token_index=(
                    fwd_right_routing_exp.carrier_token_index
                ),

                core_z=(
                    fwd_right_paths2.core_z
                ),

                core_available=(
                    fwd_right_paths2.core_available
                ),
            )
        )


        rev_left_at2 = (
            self.at_encoder(
                token_z=rev_left2.token_z,

                a_token_index=(
                    rev_left_routing_exp.a_token_index
                ),

                carrier_token_index=(
                    rev_left_routing_exp.carrier_token_index
                ),

                core_z=(
                    rev_left_paths2.core_z
                ),

                core_available=(
                    rev_left_paths2.core_available
                ),
            )
        )


        rev_right_at2 = (
            self.at_encoder(
                token_z=rev_right2.token_z,

                a_token_index=(
                    rev_right_routing_exp.a_token_index
                ),

                carrier_token_index=(
                    rev_right_routing_exp.carrier_token_index
                ),

                core_z=(
                    rev_right_paths2.core_z
                ),

                core_available=(
                    rev_right_paths2.core_available
                ),
            )
        )


        # ==========================================================
        # RECOMPUTE PHYSICAL ENDPOINT STATES.
        #
        # Junction embedding itself has NOT been recycled yet.
        # That happens after hierarchical zM rebuilding.
        # ==========================================================

        (
            fwd_left_terminal2_0,
            fwd_left_terminal_available2_0,
        ) = _gather_optional_token_state(
            fwd_left2.token_z,
            fwd_left_routing_exp.terminal_token_index,
        )


        (
            fwd_right_initial2_0,
            fwd_right_initial_available2_0,
        ) = _gather_optional_token_state(
            fwd_right2.token_z,
            fwd_right_routing_exp.initial_token_index,
        )


        (
            rev_left_terminal2_0,
            rev_left_terminal_available2_0,
        ) = _gather_optional_token_state(
            rev_left2.token_z,
            rev_left_routing_exp.terminal_token_index,
        )


        (
            rev_right_initial2_0,
            rev_right_initial_available2_0,
        ) = _gather_optional_token_state(
            rev_right2.token_z,
            rev_right_routing_exp.initial_token_index,
        )


        fwd_left_terminal2 = (
            fwd_left_terminal2_0.reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )

        fwd_right_initial2 = (
            fwd_right_initial2_0.reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )

        rev_left_terminal2 = (
            rev_left_terminal2_0.reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )

        rev_right_initial2 = (
            rev_right_initial2_0.reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )


        forward_edge_2 = (
            self.edge_encoder(
                left_terminal_z=(
                    fwd_left_terminal2
                ),

                z_junction=(
                    z_junction
                ),

                right_initial_z=(
                    fwd_right_initial2
                ),
            )
        )


        reverse_edge_2 = (
            self.edge_encoder(
                left_terminal_z=(
                    rev_left_terminal2
                ),

                z_junction=(
                    z_junction
                ),

                right_initial_z=(
                    rev_right_initial2
                ),
            )
        )


        # ==========================================================
        # RECOMPUTE TC FROM THE REFINED PHYSICAL HIERARCHY.
        # ==========================================================

        (
            fwd_left_carrier2_0,
            fwd_left_carrier_available2_0,
        ) = _gather_optional_token_state(
            fwd_left2.token_z,
            fwd_left_routing_exp.carrier_token_index,
        )


        (
            rev_left_carrier2_0,
            rev_left_carrier_available2_0,
        ) = _gather_optional_token_state(
            rev_left2.token_z,
            rev_left_routing_exp.carrier_token_index,
        )


        fwd_left_carrier2 = (
            fwd_left_carrier2_0.reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )

        rev_left_carrier2 = (
            rev_left_carrier2_0.reshape(
                batch_size,
                candidate_count,
                MODEL_DIM,
            )
        )


        forward_tc_available2 = (
            fwd_left_carrier_available2_0.reshape(
                batch_size,
                candidate_count,
            )

            & fwd_left_paths2.exit_available.reshape(
                batch_size,
                candidate_count,
            )

            & fwd_right_paths2.entry_available.reshape(
                batch_size,
                candidate_count,
            )

            & fwd_right_initial_available2_0.reshape(
                batch_size,
                candidate_count,
            )
        )


        reverse_tc_available2 = (
            rev_left_carrier_available2_0.reshape(
                batch_size,
                candidate_count,
            )

            & rev_left_paths2.exit_available.reshape(
                batch_size,
                candidate_count,
            )

            & rev_right_paths2.entry_available.reshape(
                batch_size,
                candidate_count,
            )

            & rev_right_initial_available2_0.reshape(
                batch_size,
                candidate_count,
            )
        )


        forward_tc2 = (
            self.tc_encoder(
                left_carrier_z=(
                    fwd_left_carrier2
                ),

                left_exit_z=(
                    fwd_left_paths2.exit_z.reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                edge_z=(
                    forward_edge_2
                ),

                right_entry_z=(
                    fwd_right_paths2.entry_z.reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                available=(
                    forward_tc_available2
                ),
            )
        )


        reverse_tc2 = (
            self.tc_encoder(
                left_carrier_z=(
                    rev_left_carrier2
                ),

                left_exit_z=(
                    rev_left_paths2.exit_z.reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                edge_z=(
                    reverse_edge_2
                ),

                right_entry_z=(
                    rev_right_paths2.entry_z.reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                available=(
                    reverse_tc_available2
                ),
            )
        )


        # ==========================================================
        # HIERARCHICAL MODULE REBUILD.
        #
        # raw zM
        #   +
        # refined [MOD]/D/B
        #   +
        # round-1 assembly Mself
        #   +
        # recomputed AT
        #   +
        # recomputed TC
        #
        # -> candidate-conditioned hierarchical zM.
        # ==========================================================

        fwd_left_module2 = (
            self.module_rebuilder(
                raw_module_z=(
                    _module_z_bk_v2d(
                        fwd_left_exp
                    )
                ),

                refined_token_z=(
                    fwd_left_refined.token_z
                ),

                token_padding_mask=(
                    fwd_left_padding2
                ),

                assembly_module_z=(
                    forward_full_neighborhood.memory_z[
                        :, :, 1, :
                    ]
                ),

                at_z=(
                    fwd_left_at2.z_at.reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                at_available=(
                    fwd_left_at2.available.reshape(
                        batch_size,
                        candidate_count,
                    )
                ),

                tc_z=(
                    forward_tc2.z_tc
                ),

                tc_available=(
                    forward_tc2.available
                ),
            )
        )


        fwd_right_module2 = (
            self.module_rebuilder(
                raw_module_z=(
                    _module_z_bk_v2d(
                        fwd_right_exp
                    )
                ),

                refined_token_z=(
                    fwd_right_refined.token_z
                ),

                token_padding_mask=(
                    fwd_right_padding2
                ),

                assembly_module_z=(
                    forward_full_neighborhood.memory_z[
                        :, :, 3, :
                    ]
                ),

                at_z=(
                    fwd_right_at2.z_at.reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                at_available=(
                    fwd_right_at2.available.reshape(
                        batch_size,
                        candidate_count,
                    )
                ),

                tc_z=(
                    forward_tc2.z_tc
                ),

                tc_available=(
                    forward_tc2.available
                ),
            )
        )


        rev_left_module2 = (
            self.module_rebuilder(
                raw_module_z=(
                    _module_z_bk_v2d(
                        rev_left_exp
                    )
                ),

                refined_token_z=(
                    rev_left_refined.token_z
                ),

                token_padding_mask=(
                    rev_left_padding2
                ),

                assembly_module_z=(
                    reverse_full_neighborhood.memory_z[
                        :, :, 1, :
                    ]
                ),

                at_z=(
                    rev_left_at2.z_at.reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                at_available=(
                    rev_left_at2.available.reshape(
                        batch_size,
                        candidate_count,
                    )
                ),

                tc_z=(
                    reverse_tc2.z_tc
                ),

                tc_available=(
                    reverse_tc2.available
                ),
            )
        )


        rev_right_module2 = (
            self.module_rebuilder(
                raw_module_z=(
                    _module_z_bk_v2d(
                        rev_right_exp
                    )
                ),

                refined_token_z=(
                    rev_right_refined.token_z
                ),

                token_padding_mask=(
                    rev_right_padding2
                ),

                assembly_module_z=(
                    reverse_full_neighborhood.memory_z[
                        :, :, 3, :
                    ]
                ),

                at_z=(
                    rev_right_at2.z_at.reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                at_available=(
                    rev_right_at2.available.reshape(
                        batch_size,
                        candidate_count,
                    )
                ),

                tc_z=(
                    reverse_tc2.z_tc
                ),

                tc_available=(
                    reverse_tc2.available
                ),
            )
        )



        # ==========================================================
        # V2-D ROUND 2 RECYCLE.
        #
        # Hierarchical biological states are now returned to the
        # candidate-conditioned assembly representation.
        #
        #     rebuilt M_left
        #          +
        #     refined J_query
        #          +
        #     rebuilt M_right
        #
        # are written ONLY into q-1 / q / q+1 of the core
        # CandidateAssemblyTrackV2.  All distant positions,
        # J_MASK and padding remain exact identity.
        # ==========================================================


        # ----------------------------------------------------------
        # Candidate-conditioned physical query-junction refinement.
        #
        # raw biological junction:
        #       [B,64]
        #
        # round-1 assembly query state:
        #       [B,K,256]
        #
        # result:
        #       [B,K,64]
        # ----------------------------------------------------------

        forward_query_junction64_2 = (
            self.query_junction_refiner(
                raw_junction_z=(
                    z_junction
                ),

                assembly_query_z=(
                    forward_full_pass1.query_z
                ),
            )
        )


        reverse_query_junction64_2 = (
            self.query_junction_refiner(
                raw_junction_z=(
                    z_junction
                ),

                assembly_query_z=(
                    reverse_full_pass1.query_z
                ),
            )
        )


        expected_refined_junction = (
            batch_size,
            candidate_count,
            z_junction.shape[-1],
        )


        if (
            forward_query_junction64_2.shape
            != expected_refined_junction
        ):
            raise RuntimeError(
                "forward refined query-J geometry drift"
            )


        if (
            reverse_query_junction64_2.shape
            != expected_refined_junction
        ):
            raise RuntimeError(
                "reverse refined query-J geometry drift"
            )


        # ----------------------------------------------------------
        # Convert the refined 64-D physical seam back to the
        # 256-D assembly-token space used by CandidateAssemblyTrackV2.
        #
        # Reuse the same learned physical-junction projection already
        # owned by EdgeEncoderV2; do not create a second arbitrary
        # J projection.
        # ----------------------------------------------------------

        forward_query_junction_z2 = (
            self.edge_encoder
            .junction_seam_projection(
                forward_query_junction64_2
            )
        )


        reverse_query_junction_z2 = (
            self.edge_encoder
            .junction_seam_projection(
                reverse_query_junction64_2
            )
        )


        expected_query_token = (
            batch_size,
            candidate_count,
            MODEL_DIM,
        )


        if (
            forward_query_junction_z2.shape
            != expected_query_token
        ):
            raise RuntimeError(
                "forward projected query-J geometry drift"
            )


        if (
            reverse_query_junction_z2.shape
            != expected_query_token
        ):
            raise RuntimeError(
                "reverse projected query-J geometry drift"
            )


        # ----------------------------------------------------------
        # Query-local CORE-track rebuild.
        #
        # Forward:
        #
        #     fixed-left M' -- J' -- candidate-right M'
        #
        # Reverse:
        #
        #     candidate-left M' -- J' -- fixed-right M'
        #
        # The LocalAssemblyTrackRebuilderV2D itself asserts the
        # direction/candidate adjacency contract.
        # ----------------------------------------------------------

        forward_track_round2_core = (
            self.local_track_rebuilder(
                base_track=(
                    forward_track
                ),

                left_module_z=(
                    fwd_left_module2.module_z
                ),

                query_junction_z=(
                    forward_query_junction_z2
                ),

                right_module_z=(
                    fwd_right_module2.module_z
                ),
            )
        )


        reverse_track_round2_core = (
            self.local_track_rebuilder(
                base_track=(
                    reverse_track
                ),

                left_module_z=(
                    rev_left_module2.module_z
                ),

                query_junction_z=(
                    reverse_query_junction_z2
                ),

                right_module_z=(
                    rev_right_module2.module_z
                ),
            )
        )


        # ==========================================================
        # Reconstruct leakage-safe Full-D structures.
        #
        # Candidate replacement remains owned by the original
        # CandidateAssemblyTrackBuilderV2.  This step only restores
        # [ASM] + Full-D structural metadata around the rebuilt core
        # track.
        # ==========================================================

        forward_full_track_round2 = (
            self.full_d_structure_builder.build(
                core_track=(
                    forward_track_round2_core
                ),

                assembly_junction_kind=(
                    assembly_junction_kind
                ),

                transition_offset=(
                    assembly_module_count - 1
                ),

                module_count=(
                    assembly_module_count
                ),
            )
        )


        reverse_full_track_round2 = (
            self.full_d_structure_builder.build(
                core_track=(
                    reverse_track_round2_core
                ),

                assembly_junction_kind=(
                    assembly_junction_kind
                ),

                transition_offset=(
                    assembly_module_count - 1
                ),

                module_count=(
                    assembly_module_count
                ),
            )
        )


        # ==========================================================
        # FULL-D ASSEMBLY PASS 2.
        #
        # IMPORTANT:
        #     SAME AssemblyEncoderV2D parameters are reused.
        #
        # This is recycling, not a second independently parameterized
        # assembly network.
        # ==========================================================

        forward_full_pass2 = (
            self.full_d_assembly_encoder(
                forward_full_track_round2
            )
        )


        reverse_full_pass2 = (
            self.full_d_assembly_encoder(
                reverse_full_track_round2
            )
        )


        # ----------------------------------------------------------
        # Extract the round-2 biological neighborhood.
        #
        # These are now the final recycled:
        #
        #     [ASM, M_left, J_query, M_right]
        #
        # states for downstream local edge refinement / scoring.
        # ----------------------------------------------------------

        forward_full_neighborhood2 = (
            gather_assembly_neighborhood_v2d(
                encoded=(
                    forward_full_pass2
                ),

                structure=(
                    forward_full_track_round2
                ),
            )
        )


        reverse_full_neighborhood2 = (
            gather_assembly_neighborhood_v2d(
                encoded=(
                    reverse_full_pass2
                ),

                structure=(
                    reverse_full_track_round2
                ),
            )
        )


        # ==========================================================
        # ROUND-2 LOCAL EDGE REFINEMENT.
        #
        # Physical edge stays a protected residual path:
        #
        #     edge_A + small gated contextual delta
        #
        # using the RECYCLED 256-D M-J-M assembly neighborhood.
        # ==========================================================

        forward_edge_D = (
            self.edge_refiner(
                z_edge=(
                    forward_edge_2
                ),

                left_module_z=(
                    forward_full_neighborhood2
                    .memory_z[
                        :, :, 1, :
                    ]
                ),

                query_junction_z=(
                    forward_full_neighborhood2
                    .memory_z[
                        :, :, 2, :
                    ]
                ),

                right_module_z=(
                    forward_full_neighborhood2
                    .memory_z[
                        :, :, 3, :
                    ]
                ),
            )
        )


        reverse_edge_D = (
            self.edge_refiner(
                z_edge=(
                    reverse_edge_2
                ),

                left_module_z=(
                    reverse_full_neighborhood2
                    .memory_z[
                        :, :, 1, :
                    ]
                ),

                query_junction_z=(
                    reverse_full_neighborhood2
                    .memory_z[
                        :, :, 2, :
                    ]
                ),

                right_module_z=(
                    reverse_full_neighborhood2
                    .memory_z[
                        :, :, 3, :
                    ]
                ),
            )
        )


        expected_edge_D = (
            batch_size,
            candidate_count,
            MODEL_DIM,
        )


        if (
            forward_edge_D.shape
            != expected_edge_D
        ):
            raise RuntimeError(
                "forward round-2 edge geometry drift"
            )


        if (
            reverse_edge_D.shape
            != expected_edge_D
        ):
            raise RuntimeError(
                "reverse round-2 edge geometry drift"
            )



        # ==========================================================
        # GLOBAL [ASM]-STYLE READOUT AFTER BANDED CONTEXTUALIZATION.
        # ==========================================================

        # Final V2-D assembly representation comes from the
        # SECOND Full-D assembly pass after biological rebuilding.
        forward_assembly_z = (
            forward_full_pass2.asm_z
        )


        reverse_assembly_z = (
            reverse_full_pass2.asm_z
        )


        expected_assembly = (
            batch_size,
            candidate_count,
            MODEL_DIM,
        )


        if (
            forward_assembly_z.shape
            != expected_assembly
        ):
            raise RuntimeError(
                "Forward global assembly shape drift"
            )


        if (
            reverse_assembly_z.shape
            != expected_assembly
        ):
            raise RuntimeError(
                "Reverse global assembly shape drift"
            )


        # ==========================================================
        # WHOLE-ASSEMBLY COHERENCE SCORES.
        # Shared head in both directions.
        # ==========================================================

        forward_assembly_scores = (
            self.assembly_scorer(
                forward_assembly_z
            )
        )


        reverse_assembly_scores = (
            self.assembly_scorer(
                reverse_assembly_z
            )
        )


        # ==========================================================
        # V2-D FINAL RECYCLED LOCAL EDGE.
        #
        # V2-D replaces the V2-C scalar assembly-feedback bottleneck
        # with the full hierarchical recycle:
        #
        # assembly -> AT/TC -> D/B -> zM -> assembly round 2 -> edge_D
        #
        # Therefore edge_D is the final local edge representation.
        # ==========================================================

        forward_edge_final = forward_edge_D
        reverse_edge_final = reverse_edge_D


        # ==========================================================
        # EXISTING V2-A LOCAL SCORER — UNCHANGED.
        # Only z_edge may now contain gated assembly feedback.
        # ==========================================================

        forward_local_scores = (
            self.local_scorer(
                left_module_z=(
                    fwd_left.module_z
                ),

                left_core_z=(
                    fwd_left_paths.core_z
                ),

                left_exit_z=(
                    fwd_left_paths.exit_z
                ),

                z_edge=(
                    forward_edge_final
                ),

                right_entry_z=(
                    fwd_right_paths
                    .entry_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                right_core_z=(
                    fwd_right_paths
                    .core_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                right_module_z=(
                    forward_candidate_module_z
                ),
            )
        )


        reverse_local_scores = (
            self.local_scorer(
                left_module_z=(
                    reverse_candidate_module_z
                ),

                left_core_z=(
                    rev_left_paths
                    .core_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                left_exit_z=(
                    rev_left_paths
                    .exit_z
                    .reshape(
                        batch_size,
                        candidate_count,
                        MODEL_DIM,
                    )
                ),

                z_edge=(
                    reverse_edge_final
                ),

                right_entry_z=(
                    rev_right_paths.entry_z
                ),

                right_core_z=(
                    rev_right_paths.core_z
                ),

                right_module_z=(
                    rev_right.module_z
                ),
            )
        )


        expected_scores = (
            batch_size,
            candidate_count,
        )


        if (
            forward_local_scores.shape
            != expected_scores
        ):
            raise RuntimeError(
                "Forward C local score shape drift"
            )


        if (
            reverse_local_scores.shape
            != expected_scores
        ):
            raise RuntimeError(
                "Reverse C local score shape drift"
            )



        # ==========================================================
        # FINAL V2-D SCORE COMPOSITION.
        #
        # V2-D always combines:
        #
        #   contextualized local edge
        #   +
        #   assembly coherence
        #
        # No V2-C A/B/C ablation logic exists here.
        # ==========================================================

        forward_scores = (
            forward_local_scores
            + forward_assembly_scores
        )

        reverse_scores = (
            reverse_local_scores
            + reverse_assembly_scores
        )



        result = RouteAV2DOutput(
            forward_scores=(
                forward_scores
            ),

            reverse_scores=(
                reverse_scores
            ),

            forward_pre_feedback_scores=(
                forward_pre_feedback_scores
            ),

            reverse_pre_feedback_scores=(
                reverse_pre_feedback_scores
            ),

            forward_local_scores=(
                forward_local_scores
            ),

            reverse_local_scores=(
                reverse_local_scores
            ),

            forward_assembly_scores=(
                forward_assembly_scores
            ),

            reverse_assembly_scores=(
                reverse_assembly_scores
            ),

            forward_assembly_z=(
                forward_assembly_z
            ),

            reverse_assembly_z=(
                reverse_assembly_z
            ),

            z_junction=(
                z_junction
            ),

        )


        result.validate()

        return result
