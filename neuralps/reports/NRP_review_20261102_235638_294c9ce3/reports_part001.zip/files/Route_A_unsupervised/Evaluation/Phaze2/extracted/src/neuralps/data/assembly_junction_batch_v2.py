from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import torch

from neuralps.data.collate import (
    AA_TO_ID,
    UNK_ID,
    PAD_ID,
    JUNCTION_SEQUENCE,
    JUNCTION_ZERO_LINKER,
    JUNCTION_CHAIN_BREAK,
)

from neuralps.data.junction_store import (
    JunctionStore,
)


@dataclass(
    frozen=True,
    slots=True,
)
class AssemblyJunctionBatchV2:
    """
    Flattened natural Route-A assembly junctions.

    Junction semantics are exactly inherited from the frozen
    V1.0/V1.1 query-junction contract:

      0 = non-empty same-chain linker
      1 = zero-length same-chain linker
      2 = inter-protein chain break

    Candidate-conditioned J_MASK is NOT inserted here.
    That happens later on GPU after junction encoding.
    """

    junction_aa: torch.Tensor
    junction_mask: torch.Tensor

    junction_kind: torch.Tensor
    junction_length: torch.Tensor
    junction_log_length: torch.Tensor

    transition_uids: tuple[str, ...]

    unknown_residue_count: int
    total_linker_residue_count: int

    def validate(
        self,
    ) -> None:

        n = len(
            self.transition_uids
        )

        if self.junction_aa.ndim != 2:
            raise RuntimeError(
                "assembly junction_aa must be rank 2"
            )

        if self.junction_aa.shape[0] != n:
            raise RuntimeError(
                "assembly junction batch-size mismatch"
            )

        if (
            self.junction_mask.shape
            != self.junction_aa.shape
        ):
            raise RuntimeError(
                "assembly junction mask shape mismatch"
            )

        for name in (
            "junction_kind",
            "junction_length",
            "junction_log_length",
        ):

            value = getattr(
                self,
                name,
            )

            if value.shape != (n,):
                raise RuntimeError(
                    f"{name} shape mismatch"
                )

        if (
            self.junction_aa.dtype
            != torch.long
        ):
            raise RuntimeError(
                "junction_aa must be torch.long"
            )

        if (
            self.junction_mask.dtype
            != torch.bool
        ):
            raise RuntimeError(
                "junction_mask must be bool"
            )

        if (
            self.junction_kind.dtype
            != torch.long
        ):
            raise RuntimeError(
                "junction_kind must be torch.long"
            )

        if (
            self.junction_length.dtype
            != torch.float32
        ):
            raise RuntimeError(
                "junction_length must be float32"
            )

        if (
            self.junction_log_length.dtype
            != torch.float32
        ):
            raise RuntimeError(
                "junction_log_length must be float32"
            )

        if n:

            if torch.any(
                self.junction_kind < 0
            ):
                raise RuntimeError(
                    "negative junction kind"
                )

            if torch.any(
                self.junction_kind > 2
            ):
                raise RuntimeError(
                    "unknown junction kind"
                )

            expected_log = torch.log1p(
                self.junction_length
            )

            if not torch.equal(
                self.junction_log_length,
                expected_log,
            ):
                raise RuntimeError(
                    "junction log-length drift"
                )


class AssemblyJunctionBatchBuilderV2:
    """
    Convert a flattened transition_uid sequence into exact
    inherited Route-A junction tensors.

    This deliberately does NOT use EdgeEncoderV2.

    Output is the same raw junction representation consumed by
    JunctionEncoder.
    """

    def __init__(
        self,
        junction_store: JunctionStore,
    ) -> None:

        self.junction_store = (
            junction_store
        )


    @staticmethod
    def _encode_sequence(
        sequence: str,
    ) -> list[int]:

        return [
            AA_TO_ID.get(
                aa.upper(),
                UNK_ID,
            )
            for aa in sequence
        ]


    def build(
        self,
        transition_uids: Sequence[str],
    ) -> AssemblyJunctionBatchV2:

        transition_uids = tuple(
            str(uid)
            for uid in transition_uids
        )

        if not transition_uids:
            raise ValueError(
                "transition_uids cannot be empty"
            )

        encoded = []
        kinds = []
        lengths = []

        unknown_residues = 0
        total_residues = 0


        for uid in transition_uids:

            record = (
                self.junction_store.get(
                    uid
                )
            )

            sequence = record.sequence
            length = int(
                record.length_aa
            )


            if record.is_chain_break:

                if sequence != "":
                    raise RuntimeError(
                        f"{uid}: chain break contains residues"
                    )

                if length != 0:
                    raise RuntimeError(
                        f"{uid}: chain break length != 0"
                    )

                tokens = []

                kind = (
                    JUNCTION_CHAIN_BREAK
                )


            elif length == 0:

                if not record.is_linker:
                    raise RuntimeError(
                        f"{uid}: zero-length non-linker"
                    )

                if sequence != "":
                    raise RuntimeError(
                        f"{uid}: zero linker contains residues"
                    )

                tokens = []

                kind = (
                    JUNCTION_ZERO_LINKER
                )


            else:

                if not record.is_linker:
                    raise RuntimeError(
                        f"{uid}: non-empty non-linker junction"
                    )

                if len(sequence) != length:
                    raise RuntimeError(
                        f"{uid}: linker length mismatch"
                    )

                tokens = (
                    self._encode_sequence(
                        sequence
                    )
                )

                kind = (
                    JUNCTION_SEQUENCE
                )

                total_residues += len(
                    tokens
                )

                unknown_residues += sum(
                    token == UNK_ID
                    for token in tokens
                )


            encoded.append(
                tokens
            )

            kinds.append(
                kind
            )

            lengths.append(
                length
            )


        max_length = max(
            (
                len(tokens)
                for tokens in encoded
            ),
            default=0,
        )

        padded_length = max(
            max_length,
            1,
        )

        n = len(
            transition_uids
        )


        junction_aa = torch.full(
            (
                n,
                padded_length,
            ),
            PAD_ID,
            dtype=torch.long,
        )

        junction_mask = torch.zeros(
            (
                n,
                padded_length,
            ),
            dtype=torch.bool,
        )


        for i, tokens in enumerate(
            encoded
        ):

            if not tokens:
                continue

            width = len(
                tokens
            )

            junction_aa[
                i,
                :width,
            ] = torch.tensor(
                tokens,
                dtype=torch.long,
            )

            junction_mask[
                i,
                :width,
            ] = True


        junction_kind = torch.tensor(
            kinds,
            dtype=torch.long,
        )

        junction_length = torch.tensor(
            lengths,
            dtype=torch.float32,
        )

        junction_log_length = torch.log1p(
            junction_length
        )


        result = AssemblyJunctionBatchV2(
            junction_aa=(
                junction_aa
            ),

            junction_mask=(
                junction_mask
            ),

            junction_kind=(
                junction_kind
            ),

            junction_length=(
                junction_length
            ),

            junction_log_length=(
                junction_log_length
            ),

            transition_uids=(
                transition_uids
            ),

            unknown_residue_count=(
                unknown_residues
            ),

            total_linker_residue_count=(
                total_residues
            ),
        )

        result.validate()

        return result
