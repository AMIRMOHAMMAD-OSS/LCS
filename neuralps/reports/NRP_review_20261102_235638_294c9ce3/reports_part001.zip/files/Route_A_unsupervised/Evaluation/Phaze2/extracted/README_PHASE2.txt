NeurALPSv2 — Bode Phase-2 External Evaluation
==============================================

AUTHORITATIVE PHASE-2 V1.3 BIOLOGY

Constructs:
    106

Experimental labels:
    active   = 64
    inactive = 42

Biological modules:
    530
    exactly 5 modules per construct

Domain occurrences:
    1854

Internal B occurrences:
    1324

True inter-module J:
    424

J types:
    same-chain linker = 347
    chain break       = 77

Unique ESM-C representations:
    modules    = 215
    domains    = 133
    boundaries = 269

Split-intein scars:
    LNRSAV = 106
    NPCSEI = 106

Both scars are intra-module B events.
Neither scar is an inter-module J.


FINAL FROZEN MODEL EVALUATIONS
==============================

V2-A epoch 30
--------------
Primary symmetric_mean:
    ROC-AUC = 0.565104
    AP      = 0.674361

Full interface coverage:
    424 / 424


V2-C epoch 30
--------------
final_mean:
    ROC-AUC = 0.5485
    AP      = 0.6340

final_min:
    ROC-AUC = 0.5009
    AP      = 0.6215


V2-D epoch 30
--------------
final_mean:
    ROC-AUC = 0.5753
    AP      = 0.6997

final_min:
    ROC-AUC = 0.5820
    AP      = 0.7018

Full score coverage:
    424 / 424


IMPORTANT
=========

This is an external-validation dataset.

Experimental activity labels were not used to construct model inputs
or ESM-C representations. Labels are used only for post-scoring
external evaluation metrics.

The old Phase-1 Bode module topology and cardinalities are not valid
for this Phase-2 archive.

Authoritative representation:
    106 constructs
    530 modules
    1854 D
    1324 B
    424 J
