# Source attribution

Bülbül et al. (2026). *Generative AI designs functional thiolation domains for
reprogramming non-ribosomal peptide synthetases*. Nature Communications.
https://doi.org/10.1038/s41467-026-77963-6

The publisher's original supplementary files are in `raw/`. Their URLs,
retrieval dates and SHA-256 checksums are in `provenance/sources.json`.
The publisher's source ZIP was byte-identical to the user-supplied copy.

The article states a Creative Commons Attribution 4.0 International license
(https://creativecommons.org/licenses/by/4.0/), subject to separately credited
third-party material. Retain the original attribution and any third-party notices.
The original sources have not been edited. Derived tables normalize identifiers,
extract measurements and sequences, annotate discrepancies, and reconstruct a
conservative subset of constructs; those changes are documented in this package.

The authors' archived code release is also included unchanged:
Kevin George, *uds-lsv/T-domain-design: Official Release*, v1.0.0,
https://doi.org/10.5281/zenodo.21829302 . Zenodo identifies this release as CC BY 4.0.
Its source snapshot corresponds to GitHub commit
`c50e4d09f3c9d44fa6bf2ae8c39974d5943fb76b`.
The release is retained for provenance; none of its training code was run.

This preparation is an independent research curation, not an author-endorsed
correction or a replacement for the original measurements. Cite the paper and
the archived code when using their respective materials.
