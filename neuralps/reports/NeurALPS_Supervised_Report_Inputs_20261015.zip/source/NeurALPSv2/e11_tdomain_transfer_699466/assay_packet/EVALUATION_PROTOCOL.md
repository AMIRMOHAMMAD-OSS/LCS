# First evaluation and future training rules

## Recommended first use

Keep the existing NeurALPS checkpoint and compatibility-score definition fixed.
Evaluate the curated main-assay T3 swaps before changing pretraining or fitting an
activity head. The recipient scaffold is held constant, so ranking the variants
addresses a more specific question than mixing unrelated assembly families.

1. Run the project's standard domain annotation on the 65 reconstructed protein
   chains in `reconstructed_T3_primary_sequence_subset.fasta`; build ESMC domain
   and boundary inputs using the same definitions as the existing model. Check
   that each exchanged interval in `evaluation/annotation_queue.json` maps to the
   intended T3 and its actual adjacent boundaries. Protein coordinates in that
   queue are zero-based, end-exclusive; they identify the cloned fragment, not a
   claim about the canonical domain's exact boundaries.
2. Score with the fixed checkpoint selected at step 26000. Preserve the existing
   mask, score direction and aggregation for the initial comparison. Any global-path
   ablation or new masking rule is a separately named, prespecified comparison;
   do not select a winner on these labels and call its score an untouched test.
3. Compare scores with published production as a quantitative endpoint (for
   example Spearman rank correlation) and with `reported_nonzero_production`
   (AUROC and average precision). Include sample counts, prevalence and uncertainty.
   The binary endpoint is reported production >0; it does not define a physical
   compatibility threshold. Avoid choosing a score threshold using these labels.
4. Report the same analysis on the 63-construct source-agreement subset and
   retain the AI-52/64 discrepancy in the results. Preserve source-specific
   quantitative summaries when assessing sensitivity to endpoint provenance.
5. Stratify by generation round and documented ancestry. Bootstrap uncertainty
   with documented related variants grouped together where feasible; these
   minimum groups do not remove all unknown sequence similarity or selection
   dependence. Do not treat biological/technical replicates as independent
   classification examples.

No model scores were generated during this preparation. The paper's labels were
read for curation and eligibility checks. This is a retrospective evaluation on a
new study, not a prospective blind trial or proof of a novel protein-family test.
An overlap audit against the actual NeurALPS pretraining sequences and existing
BODE data still needs to be completed before making strong independence claims.

## Secondary questions

- **Context dependence:** Use verified same-design/different-recipient or position
  comparisons from Fig6/7. Keep products, assay platforms and culture conditions
  separate. A peak height for one peptide is not quantitatively comparable to
  the peak height of a different peptide without appropriate normalization.
  Missing rows are not measured failures.
  The package includes 20 primer-supported Fig7 construct reconstructions, with
  19 in the sequence-consistent subset and all triplicates linked explicitly.
  Their raw peak-area means remain quantitative measurements; no definitive
  activity classification was inferred from these means. Three matched native
  hybrid control proteins are provided separately.
- **Hybrid screen:** S14's 300 observed expected-product combinations are useful
  for audit and quantitative exploration. They are not yet an authoritative
  binary activity benchmark: control matching and processing must first be
  reconciled. Do not train on the raw 0/1/2 ion-mode count as activity severity.
- **Mutagenesis:** Retain all 182 measured variants, but analyze premature stops
  separately from intact-domain compatibility. Full epPCR construct reconstruction
  and boundary verification are pending; a short protein record with a stop must
  not be spliced into an intact downstream NRPS as if translation continued.

## If supervised learning is added later

`evaluation/variant_groups.csv` supplies minimum grouping constraints, not fixed
train/test assignments. The recommended frozen-score evaluation does not need a
fitted train/test split.

The 182 epPCR variants belong to only four documented parental libraries: WT (50),
AI-2 (53), AI-12 (42), and AI-15 (37). A later exploratory leave-one-parent-family-out
analysis can use those four groups, with all hyperparameter selection confined
to training groups. Keep each parent, its descendants, every sequence version,
and every occurrence across contexts on the same side of the split.
The named WT GxpS T3 control belongs to `known_ancestry_WT`, including its control
replicates. Anonymous controls from other recipient systems must not be assigned
to that lineage solely because their assay label also says WT.

AI-32–36 are motif-restored descendants of AI-5,6,8,9,11 respectively; those pairs
also stay together. AI-27–31 have unresolved guided-seed ancestry and are excluded
from strict ancestry-transfer split construction until resolved. The remaining
singleton minimum groups are not evidence of unrelated origin. Add a declared
sequence-only homology grouping rule before making homology-transfer claims.

A held-out recipient context with shared variants measures **known-variant context
transfer**. To claim unseen-variant transfer too, purge its variant/ancestry groups
from all training contexts. Do not force generic five-fold or percentage splits
when too few independent groups remain. Round 3 was selected using prior
experimental labels, so it is not an independently sampled discovery cohort.

This study provides measured T-domain swaps. It does not provide causal ground
truth for arbitrary boundary failures across every NRPS domain type. Even a useful
ranking result would support prioritization of candidate edits, not automatic
certification of an assembly's functionality.
