"""Read-only integrity checks for the exact 3,675 native-preserving doubles."""
from __future__ import annotations
import argparse
import hashlib
import json
import sqlite3
from pathlib import Path

HERE = Path(__file__).resolve().parent
INPUT_NAME = 'NeurALPS_3675_Double_Inputs_20261104'
ENCODING_NAME = INPUT_NAME
CACHE_DIRECTORY = 'e0_cache_final_491894'
CACHE_ROWS = 548713
CACHE_DIM = 1152


class IntegrityError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise IntegrityError(message)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            result.update(block)
    return result.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
    temporary.replace(path)


def bindings():
    return read(HERE / 'INPUT_BINDINGS.json')


def _check(root, relative, expected, full, deferred):
    relative = Path(relative)
    require(not relative.is_absolute() and '..' not in relative.parts, 'Unsafe asset path')
    path = root / relative
    require(path.is_file() and not path.is_symlink(), 'Missing/linked asset: ' + str(path))
    if full or path.stat().st_size <= 4 << 20:
        before = path.stat()
        require(sha(path) == expected, 'Checksum differs: ' + str(path))
        after = path.stat()
        require((before.st_size, before.st_mtime_ns, before.st_ino) ==
                (after.st_size, after.st_mtime_ns, after.st_ino), 'Asset changed while hashing')
    else:
        deferred.append(str(path))


def validate_input(root, full=True):
    root = Path(root).resolve()
    source = bindings()
    require(source['candidate_count'] == 3675 and source['exactly_two_exchanges'] is True,
            'Wrong double input scope')
    inputs, deferred = root / INPUT_NAME, []
    for relative, expected in source['input_files_sha256'].items():
        _check(inputs, relative, expected, full, deferred)
    return dict(status='DOUBLE_INPUTS_VERIFIED', candidate_count=3675,
                package_sha256=source['input_manifest_sha256'],
                package=str(inputs), files=len(source['input_files_sha256']),
                deferred_large_hashes=deferred, unique_model_sequences=source['unique_model_sequences'],
                feature_bank_sha256=source['feature_bank_sha256'], embedding_extraction=False)


def cache_row_lookup(root):
    """Read only the105 existing hash→row bindings; no vector/model work."""
    root = Path(root).resolve()
    missing = read(root / INPUT_NAME / 'feature_bank/feature_bank.json')['missing_hashes']
    require(len(missing) == len(set(missing)) == bindings()['main_cache_rows_required'],
            'Unexpected missing-vector scope')
    cache = root / CACHE_DIRECTORY
    index = cache / 'feature_index.sqlite3'
    require(index.is_file() and not index.is_symlink(), 'Missing/linked original feature index')
    require(not Path(str(index) + '-wal').exists(), 'Original feature index has a WAL; refusing mutable input')
    require((cache / 'features.f32').stat().st_size == CACHE_ROWS * CACHE_DIM * 4,
            'Original feature matrix byte count differs')
    rows = {}
    with sqlite3.connect(index.resolve().as_uri() + '?mode=ro', uri=True) as db:
        db.execute('PRAGMA query_only=ON')
        for h in missing:
            matches = db.execute('SELECT feature_row,status FROM features WHERE hash=?', (h,)).fetchall()
            require(len(matches) == 1 and matches[0][1] == 'covered',
                    'Required original cached embedding unavailable; no extraction fallback: ' + h)
            row = matches[0][0]
            require(type(row) is int and 0 <= row < CACHE_ROWS, 'Invalid original cache row')
            rows[h] = row
    return rows


def validate(root, full=False):
    root = Path(root).resolve()
    manifest = read(HERE / 'PACKAGE_MANIFEST.json')
    require(manifest['schema'] == 'neuralps_3675_double_scoring_package_v1', 'Wrong scoring package')
    deferred = []
    for relative, expected in manifest['files'].items():
        _check(HERE, relative, expected, True, deferred)
    input_check = validate_input(root, full=full)
    deferred.extend(input_check['deferred_large_hashes'])
    assets = read(HERE / 'ASSETS.json')
    for relative, expected in assets['project_files_sha256'].items():
        _check(root, relative, expected, full, deferred)
    cache_rows = cache_row_lookup(root)
    return dict(status='DOUBLE_SCORING_FULL_INPUTS_OK' if full else 'DOUBLE_SCORING_PREFLIGHT_OK',
                package_sha256=sha(HERE / 'PACKAGE_MANIFEST.json'), input_check=input_check,
                input_package=str(root / INPUT_NAME), candidate_count=3675,
                known_double_parity_count=33, training=False, embedding_extraction=False,
                original_cache_rows_available=len(cache_rows),
                project_assets=len(assets['project_files_sha256']), deferred_large_hashes=deferred)


# Only immutable metadata is read at import. No scientific libraries or model work.
BANK_SHA = {'feature_bank.npz': bindings()['feature_bank_sha256']}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--inputs-only', action='store_true')
    args = parser.parse_args()
    print(json.dumps(validate_input(args.root, full=True) if args.inputs_only else
                     validate(args.root, full=args.full), indent=2, sort_keys=True))
