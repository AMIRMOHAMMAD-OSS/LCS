# Exact double-exchange construction and scoring

This package scores all **3,675** possible exact doubles: choose two of XUT2,
XUT3 and XUT4, then choose one of 35 donors at each exchanged position. The
remaining destination retains its verified native block. There are 1,225 designs
for each native position. `X` in an assembly ID means the native destination;
the structural records preserve the original constructor's `native` token.

The native expression plasmids are XUT2=`pIG016`, XUT3=`pIG017`, XUT4=`pIG018`.
No triple score is substituted or averaged to produce a double score.

## Run on Jean Zay

Transfer **NeurALPS_3675_Double_Review_and_Scoring_20261104.zip** into:

`/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2`

Then run:

```bash
cd /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2
unzip -n NeurALPS_3675_Double_Review_and_Scoring_20261104.zip
python3 -B NeurALPS_3675_Double_Scoring_20261104/submit.py preflight
python3 -B NeurALPS_3675_Double_Scoring_20261104/submit.py run
```

The ZIP must place these two sibling directories directly under that project root:

```text
NeurALPS_3675_Double_Inputs_20261104/
NeurALPS_3675_Double_Scoring_20261104/
```

`preflight` performs read-only standard-library checks, including the 105 required
hash-to-row lookups in the existing embedding index. It performs no model work
on the login node. `run` submits one bounded allocation: **one A100, eight CPUs,
maximum one hour, no automatic requeue or follow-up job**. Repeating `run` after
a recorded submission shows status instead of creating a duplicate allocation.

Check progress:

```bash
python3 -B NeurALPS_3675_Double_Scoring_20261104/submit.py status
```

If interrupted, use the exact output path printed by the launcher:

```bash
python3 -B NeurALPS_3675_Double_Scoring_20261104/submit.py resume /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/neuralps_3675_double_score_TIMESTAMP_HASH
```

Replace the last path with the actual one. Resume requires an empty targeted
live-queue query and a terminal accounting record for the previous allocation.
An absent job ID alone never authorizes a new submission. Sealed chunks are
retained and checked; incompatible settings, changed assets or integrity failures
stop the run. A completed output is not submitted again.

## Existing embeddings and fitted models

All 2,750 required sequence hashes have known sequence provenance. The input
package supplies 2,645 previously extracted embeddings. The remaining 105 hashes
are original source-assembly A-to-PCP connection windows, with matching original
slot evidence in `feature_bank/missing_source_evidence.json`.

The allocated job copies these 105 vectors from the existing, read-only
`e0_cache_final_491894` cache. Its matrix and SQLite index are checksum-pinned.
The job writes a resolved bank and provenance in its new output directory, then
includes the resolved matrix hash in the run identity. **It never runs ESM,
trains a model, or changes existing inputs/checkpoints.** If an expected cached
row is absent, incomplete or corrupt, it stops without an extraction fallback.

The original frozen SSL26 checkpoint, natural-training means, four packaged
typed heads, chemistry head and nine fitted neural checkpoints are reused with
their original hashes. They must remain at their existing project-relative
paths recorded in `ASSETS.json` and `supervised/ASSETS.json`.

Before scoring the complete library, the job requires:

- The inherited numerical map/export tests, with no skipped Torch tests.
- All 33 previously scored doubles to reproduce the saved supervised predictions
  and typed features within 1e-4 absolute tolerance.
- All 33 complete physical maps to reproduce within 1e-5 absolute tolerance,
  including exact masking plans.
- Compact versus direct input equality and original versus batched map parity
  for every chain count present, including four-chain doubles.

These are numerical regression checks, not fitting or activity-based selection.
No experimental outcomes enter scoring.

## Outputs

The launcher prints `RESULT_ZIP` and `RESULT_SHA256` on completion. Retrieve that
`inspection.zip`; it contains:

- `scores.csv` and `scores.npz`: all 3,675 doubles, all 65 numerical fields,
  twelve primary score columns, and `known_33_double` flags in the CSV.
- `compatibility_maps.npz` and `full_maps.jsonl.gz`: every 128,415 physical
  object, including domain and connection values, corrected B/J/UNKNOWN labels,
  coordinates/provenance in the full JSONL, and exact hidden-role masks.
- `resolved_feature_bank.npz` and `FEATURE_BANK_RESOLUTION.json`.
- `ranked_double_candidates.csv`: all 3,675 actual double predictions with twelve
  individual score ranks and the documented consensus/robustness summaries.
- `untested_positive_components.csv`: the 1,223 untested doubles whose two
  position-matched single components had positive outcomes; this is an evidence
  filter, not proof that these doubles will produce product.
- `RANKING_METHOD.json`: exact ranking definitions and interpretation.
- Completion, manifests, run identity, model metadata and numerical gate reports.
- The scoring source needed to reproduce the job.

The companion input package retains all complete mature assemblies and their
source blocks. Rankings are calculated within this exact-double library.
The scores remain exploratory, prospectively unvalidated model outputs.
Fewer exchanges alone do not establish that a double will be more active or
more reliable than a triple.

## Validation already performed locally

The construction package audits all 3,675 routes, source coordinates, sequence
hashes and compact indices, preserves the known 33 double inputs, and verifies
the 2,645+105 disjoint feature-hash partition. The scorer's 17 local tests pass,
including active-job rejection, stale-ID accounting handling, scheduler-error
rejection, native chemistry features and read-only cache failure handling.
Eight inherited map/export tests pass locally. Three Torch-dependent tests and
the real-checkpoint 33-double inference gates are **pending Jean Zay execution**;
the runner requires them to pass before scoring the library. No job has been
submitted by creating or reviewing this bundle.
