"""Expected BODE2 substrate identities for the existing frozen chemistry head.

These are paper donor annotations, not A-domain protein residue sequences and
not measured peptide products. A domain's annotated substrate replaces peptide
position 2, 3, or 4. Outer positions stay Thr and Trp. Beta-alanine is distinct
from alanine. The existing model vocabulary must stay fixed at inference.
"""
from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import itertools
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = json.loads((HERE / "donor_substrates.json").read_text())
DONOR_SUBSTRATES = SOURCE["donor_substrate"]
NATIVE_AMINO_ACIDS = tuple(SOURCE["native_amino_acids"])
MODEL_SHA256 = "461cfbab1637ce33b573a8960233d1a4bbb6758ca794d1ef9a26318d562b8dad"
MODEL_RELATIVE_PATH = "NeurALPS_Patrick_Multi_Test_20261103/single_results/typed_chemistry__bode2_only.npz"


def normalized_donors(donors):
    """Require exact donor identifiers; X denotes a native block for controls."""
    if not isinstance(donors, (list, tuple)) or len(donors) != 3:
        raise ValueError("Expected three donor strings ordered XUT2, XUT3, XUT4")
    if any(not isinstance(d, str) or (d != "X" and d not in DONOR_SUBSTRATES)
           for d in donors):
        raise ValueError("Unknown or malformed BODE2 donor identifier")
    return tuple(donors)


def expected_amino_acids(donors):
    donors = normalized_donors(donors)
    amino_acids = list(NATIVE_AMINO_ACIDS)
    for position, donor in enumerate(donors, start=1):
        if donor != "X":
            amino_acids[position] = DONOR_SUBSTRATES[donor]
    return amino_acids


def expected_features(donors):
    """Exact aa_pos/pair feature naming used to fit the 105-single head."""
    aa = expected_amino_acids(donors)
    features = {f"aa_pos{i}={value}": 1.0 for i, value in enumerate(aa, 1)}
    features.update({f"pair_{i}_{i + 1}={a}>{b}": 1.0
                     for i, (a, b) in enumerate(zip(aa[:-1], aa[1:]), 1)})
    return features


def features_for_record(record):
    """Consume donor identities only; no observed outcomes enter this feature."""
    donors = normalized_donors(record["donors"])
    if record.get("dataset", "bode2") != "bode2":
        raise ValueError("BODE2 chemistry cannot be applied to another dataset")
    if record.get("assembly_id") != "BODE2_" + "-".join(donors):
        raise ValueError("Assembly ID and donor tuple disagree")
    return expected_features(donors)


def coverage(features, training_feature_names):
    """Report extrapolated terms; never expand or fit the training vocabulary."""
    names = set(training_feature_names)
    unseen = sorted(set(features) - names)
    return {"unseen_feature_count": len(unseen),
            "unseen_pair_count": sum(name.startswith("pair_") for name in unseen),
            "unseen_features": unseen,
            "policy": "Unseen terms have zero learned coefficient"}


def _canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=True).encode()).hexdigest()


def audit(package=None):
    """Verify saved old inputs and optionally the full library inventory."""
    refs = json.loads((HERE / "chemistry_reference_fixtures.json").read_text())
    if len(DONOR_SUBSTRATES) != 35 or NATIVE_AMINO_ACIDS != ("Thr", "Phe", "Ala", "Pro", "Trp"):
        raise ValueError("Unexpected chemistry source scope")
    results = {}
    for name, expected_count in (("single105", 105), ("known60", 60)):
        rows = refs[name]
        if len(rows) != expected_count:
            raise ValueError("Incorrect chemistry reference count")
        for row in rows:
            if expected_features(row["donors"]) != row["features"]:
                raise ValueError("Chemistry regression mismatch: " + row["assembly_id"])
        results[name + "_features_exact"] = expected_count
        results[name + "_features_sha256"] = _canonical_hash([
            {"assembly_id": r["assembly_id"], "features": expected_features(r["donors"])}
            for r in rows])
    training_names = sorted({key for row in refs["single105"] for key in row["features"]})
    rows = []
    pair_coverage = Counter()
    for ds in itertools.product(sorted(DONOR_SUBSTRATES), repeat=3):
        feat = expected_features(ds)
        rows.append({"assembly_id": "BODE2_" + "-".join(ds), "features": feat})
        cov = coverage(feat, training_names)
        pair_coverage[cov["unseen_pair_count"]] += 1
        if cov["unseen_feature_count"] != cov["unseen_pair_count"]:
            raise ValueError("An annotated AA identity was absent from single training")
    results.update(candidate_count=len(rows),
                   full_library_features_sha256=_canonical_hash(rows),
                   training_feature_count=len(training_names),
                   unseen_pair_count_distribution=dict(sorted(pair_coverage.items())),
                   distinct_expected_sequences=len({tuple(expected_amino_acids(ds)) for ds in
                       itertools.product(sorted(DONOR_SUBSTRATES), repeat=3)}))
    if package is not None:
        with gzip.open(Path(package) / "data/candidate_inventory.csv.gz", "rt") as handle:
            inventory = list(csv.DictReader(handle))
        if [r["assembly_id"] for r in inventory] != [r["assembly_id"] for r in rows]:
            raise ValueError("Full library chemistry identity/order mismatch")
        lookup = {r["assembly_id"]: r["features"] for r in rows}
        known27 = [r for r in refs["known60"] if "X" not in r["donors"]]
        if len(known27) != 27 or any(lookup[r["assembly_id"]] != r["features"] for r in known27):
            raise ValueError("Known27 chemistry mismatch")
        for record in inventory:
            ds = [record["donor_xut2"], record["donor_xut3"], record["donor_xut4"]]
            features_for_record({"assembly_id": record["assembly_id"], "donors": ds})
        results["package_inventory_exact"] = len(inventory)
        results["known27_exact"] = 27
    return dict(status="PASS", semantics="Source-expected substrate identities; conditional mature peptide composition",
                model_sha256=MODEL_SHA256, no_training=True, no_outcome_features=True,
                no_measured_product_features=True, **results)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = audit(args.package)
    text = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(text)
    print(text, end="")
