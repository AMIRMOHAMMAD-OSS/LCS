NeurALPS full-library chemistry adapter

This reuses the existing typed_chemistry__bode2_only head from the earlier
Patrick test. No new model is trained, no combination outcome is a feature,
and no combination outcome is used to choose a model or coefficient.

The user-described A-domain amino-acid approach is interpreted according to
the earlier experiment: source-annotated expected amino-acid substrates in
the resulting peptide, not the amino-acid residues of the A-domain protein.
Protein A-domain embeddings already exist in the reviewed feature bank.

Expected peptide: Thr, substrate(XUT2 donor), substrate(XUT3 donor),
substrate(XUT4 donor), Trp. An X control preserves native Phe, Ala, Pro at
positions 2, 3, 4 respectively. Each of five positional identities and four
ordered adjacent pairs receives a 1.0 feature. These nine exact feature keys
reproduce the old pipeline. beta-Ala is distinct from Ala. This feature does
not encode chirality, N-acylation, successful splicing, expression, or the
measured product catalogue. Expected composition is conditional on the
design-implied mature construct functioning as intended.

All 35 donor assignments were checked independently against the explicit
A-domain substrate column in the original manuscript SI workbook, sheet
Domain Similarity. The only spelling normalization is βAla to beta-Ala.
The source workbook SHA256 and old input SHA256 values are in
donor_substrates.json. The resulting feature dictionaries match all 105 old
single-exchange inputs and all 60 old combination inputs exactly.

The head was fitted to all 105 BODE2 singles after donor-held-out tuning;
lambda=10.0. Its scores use the BODE2 study intercept and have no prospective
calibration guarantee. Read the existing model, do not refit:
  NeurALPS_Patrick_Multi_Test_20261103/single_results/typed_chemistry__bode2_only.npz
  SHA256 461cfbab1637ce33b573a8960233d1a4bbb6758ca794d1ef9a26318d562b8dad

The fixed training vocabulary has 180 chemistry features. Of 42,875 designs,
1,429 contain no unseen pair terms, 5,542 contain one, and 35,904 contain two.
All positional amino-acid identity terms were seen in single training.
Unseen pair terms receive zero learned coefficient; do not expand or refit
the vocabulary on the new library. There are 8,000 distinct expected
five-position substrate sequences; these are not physical-sequence
equivalence groups and must not be used to deduplicate model inference.

Prior known-combination evaluation was already performed before this job:
  chemistry doubles AUROC 0.685; log loss 0.5989165574
  chemistry triples AUROC 0.4944444444; log loss 1.0180523306
  typed-only doubles AUROC 0.695; triples AUROC 0.4944444444
The BODE1 improvement does not establish an improvement on BODE2 triples.
Preserve this arm as a separate score column alongside the existing scores.
Do not reinterpret the unsupervised compatibility maps as chemistry-head
attributions or activity probabilities.

API:
  expected_features([donor_xut2, donor_xut3, donor_xut4]) -> dict
  features_for_record(record) -> dict, checking assembly ID and donor tuple
  expected_amino_acids(donors) -> list of five source-expected substrates
  coverage(features, fixed_training_names) -> unseen-term audit

Module-adjacent donor_substrates.json is required at inference. The reference
fixtures contain only identities/expectations, not labels, and are needed
only for audit/tests. Run:
  python -B -m unittest -v test_chemistry_features
  python -B chemistry_features.py --package /path/to/input/package

All five local tests passed, including full Cartesian feature coverage,
exact source/previous-panel round trips, label independence, beta-alanine
identity, native controls, and rejection of mismatched or unknown donors.
The independent audit also checked the actual 42,875 inventory order and
all 27 known triple entries. This is feature validation; the current local
work has not executed the chemistry head on the new full library.
