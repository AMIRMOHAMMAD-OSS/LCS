import unittest

try:
    from . import chemistry_features as chemistry
except ImportError:
    import chemistry_features as chemistry


class ChemistryTests(unittest.TestCase):
    def test_archived_source_and_full_library_regression(self):
        result = chemistry.audit()
        self.assertEqual(result["single105_features_exact"], 105)
        self.assertEqual(result["known60_features_exact"], 60)
        self.assertEqual(result["candidate_count"], 42875)

    def test_beta_alanine_is_distinct_and_native_blocks_are_position_specific(self):
        self.assertEqual(chemistry.expected_amino_acids(["044", "X", "045"]),
                         ["Thr", "beta-Ala", "Ala", "beta-Ala", "Trp"])
        self.assertEqual(chemistry.expected_amino_acids(["X", "X", "X"]),
                         ["Thr", "Phe", "Ala", "Pro", "Trp"])

    def test_outcomes_cannot_change_features(self):
        base = {"assembly_id": "BODE2_044-038-080", "donors": ["044", "038", "080"]}
        self.assertEqual(chemistry.features_for_record(dict(base, observed_activity=0)),
                         chemistry.features_for_record(dict(base, observed_activity=1,
                                                           measured_product="ignored")))

    def test_mismatched_identity_and_unknown_donor_are_rejected(self):
        for donors in ([38, "038", "080"], ["037", "038", "080"], ["038", "080"]):
            with self.assertRaises(ValueError):
                chemistry.expected_features(donors)
        with self.assertRaises(ValueError):
            chemistry.features_for_record({"assembly_id": "BODE2_038-038-080",
                                            "donors": ["044", "038", "080"]})

    def test_unseen_pairs_are_reported_without_mutating_training_vocabulary(self):
        names = ["aa_pos1=Thr"]
        result = chemistry.coverage(chemistry.expected_features(["038", "038", "038"]), names)
        self.assertEqual(names, ["aa_pos1=Thr"])
        self.assertEqual(result["unseen_feature_count"], 8)
        self.assertEqual(result["unseen_pair_count"], 4)


if __name__ == "__main__":
    unittest.main()
