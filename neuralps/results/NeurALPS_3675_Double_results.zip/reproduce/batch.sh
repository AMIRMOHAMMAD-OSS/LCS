#!/usr/bin/env bash
set -euo pipefail
NRPS_SCORE_PACKAGE="${1:?package directory}"
NRPS_SCORE_ROOT="${2:?project root}"
NRPS_SCORE_OUTPUT="${3:?output directory}"
NRPS_SCORE_REQUEST="${4:?request file}"
: "${SLURM_JOB_ID:?Submit through submit.py}"
NRPS_SCORE_START=$(date +%s)
NRPS_SCORE_PY=$(command -v python3)
NRPS_SCORE_STAGE=environment_setup

function nrps_score_failure() {
    local nrps_exit="$?"
    if [ "$nrps_exit" -ne 0 ]; then
        "$NRPS_SCORE_PY" -I -B - "$NRPS_SCORE_OUTPUT" "$NRPS_SCORE_STAGE" "$nrps_exit" <<'PY' || true
import hashlib, json, os, sys, time, zipfile
from pathlib import Path
out, stage, code = sys.argv[1:]
out = Path(out)
failure = dict(stage=stage, exit_code=int(code), job_id=os.environ.get('SLURM_JOB_ID'),
               utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
               status='BATCH_FAILED_NOT_COMPLETE')
temporary = out / 'BATCH_FAILURE.json.tmp'
temporary.write_text(json.dumps(failure, indent=2) + '\n')
temporary.replace(out / 'BATCH_FAILURE.json')
temporary = out / 'failure_inspection.zip.tmp'
with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(out.iterdir()):
        if path.is_file() and not path.is_symlink() and path.suffix in ('.json', '.sha256', '.log'):
            archive.write(path, path.name)
temporary.replace(out / 'failure_inspection.zip')
print('BATCH_FAILURE:', json.dumps(failure), flush=True)
print('RESULT_ZIP:', out / 'failure_inspection.zip', flush=True)
PY
    fi
    return "$nrps_exit"
}
trap nrps_score_failure EXIT

module purge
module load arch/a100
module load pytorch-gpu/py3/2.8.0
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
NRPS_SCORE_PY=$(command -v python3)

NRPS_SCORE_STAGE=request_check
"$NRPS_SCORE_PY" -B - "$NRPS_SCORE_PACKAGE" "$NRPS_SCORE_ROOT" \
    "$NRPS_SCORE_OUTPUT" "$NRPS_SCORE_REQUEST" <<'PY'
import json, os, sys, time
from pathlib import Path
package, root, out, request = map(lambda value: Path(value).resolve(), sys.argv[1:])
sys.path.insert(0, str(package))
from submit import check_request
try:
    checked = check_request(package, root, out, request)
except (ValueError, AssertionError) as exc:
    failure = dict(stage='request_check', exception=type(exc).__name__, message=str(exc),
                   job_id=os.environ.get('SLURM_JOB_ID'),
                   utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    path = out / 'INTEGRITY_FAILURE.json'
    temporary = path.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(failure, indent=2) + '\n')
    temporary.replace(path)
    raise
print('REQUEST_IDENTITY_OK:', checked['package_sha256'], flush=True)
PY

NRPS_SCORE_STAGE=full_input_validation
srun --ntasks=1 "$NRPS_SCORE_PY" -B - "$NRPS_SCORE_PACKAGE" \
    "$NRPS_SCORE_ROOT" "$NRPS_SCORE_OUTPUT" 2>&1 <<'PY' | tee -a "$NRPS_SCORE_OUTPUT/validation.log"
import json, os, sys, time
from pathlib import Path
package, root, out = map(Path, sys.argv[1:])
sys.path.insert(0, str(package))
from common import validate, write
try:
    result = validate(root, full=True)
except (ValueError, AssertionError) as exc:
    write(out / 'INTEGRITY_FAILURE.json', dict(
        stage='full_input_validation', exception=type(exc).__name__, message=str(exc),
        job_id=os.environ.get('SLURM_JOB_ID'),
        utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
    raise
print(json.dumps(result, indent=2, sort_keys=True), flush=True)
PY

NRPS_SCORE_NOW=$(date +%s)
NRPS_SCORE_REMAINING=$((3300 - NRPS_SCORE_NOW + NRPS_SCORE_START))
if [ "$NRPS_SCORE_REMAINING" -lt 120 ]; then
    "$NRPS_SCORE_PY" -I -B - "$NRPS_SCORE_OUTPUT" <<'PY'
import json, os, sys, time
from pathlib import Path
out = Path(sys.argv[1])
body = dict(status='PAUSED', reason='Allocation budget consumed during verification; resume this output.',
            job_id=os.environ.get('SLURM_JOB_ID'),
            utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
temporary = out / 'PAUSED.json.tmp'
temporary.write_text(json.dumps(body, indent=2) + '\n')
temporary.replace(out / 'PAUSED.json')
print(json.dumps(body), flush=True)
PY
    exit 0
fi

NRPS_SCORE_STAGE=scoring_and_parity_gates
srun --ntasks=1 "$NRPS_SCORE_PY" -B "$NRPS_SCORE_PACKAGE/run_scoring.py" \
    --root "$NRPS_SCORE_ROOT" --out "$NRPS_SCORE_OUTPUT" \
    --request "$NRPS_SCORE_REQUEST" --seconds "$NRPS_SCORE_REMAINING" \
    2>&1 | tee -a "$NRPS_SCORE_OUTPUT/scoring.log"
