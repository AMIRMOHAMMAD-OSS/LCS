Frozen SSL26 complete physical-object maps

Imports:
  from maps.scorer import MapScorer, required_assets, compare_results, CONTRACT
  scorer = MapScorer(root, vectors, device='cuda', threads=8, query_batch=64)
  results = scorer.score_records([(record, parents), ...])
  scorer.verify_sources_unchanged()
  metadata = scorer.summary()

root is the Jean Zay NeurALPSv2 directory. vectors is a SHA256-keyed mapping of
already validated float32 ESM-C vectors. Each parents mapping contains the exact
mature-chain strings keyed by parent sequence hash. No ESM module, environment,
checkpoint or original ESM cache is loaded. All vectors come from the completed
2,602-row feature bank. required_assets() returns the three pinned SSL26/target
files for controller preflight. MapScorer verifies hashes before torch.load.

Input library reconstruction/feature-bank validation and per-chunk checkpointing
belong to the controller. Use bounded chunks such as 64 records. Returned results
are ordered like the input pairs. Each contains every physical route object,
original annotation and feature slots, per-query masking metadata, full mixed
score and raw-cosine diagnostic, plus complete-coverage assembly aggregates.
Missing or insufficient-context objects are retained and make aggregates null.
No phenotype label is read. Identifiers do not enter the neural inputs.

The full path is the original frozen encoder: four local layers (radius 6),
two global read/write blocks (four global slots), and masked decoder. The global
path is active. There is no separate local-only diagnostic pass in this job.
Full global+local context does not mean two independent scores are blended.

Masking and scoring:
- One complete physical object is primary per query.
- Its amino-acid spans, every exact sequence copy elsewhere in the mature
  parents, and all intersecting observed feature dependencies are hidden.
- Collateral overlaps are not recursively enlarged into arbitrary whole-domain
  residue spans.
- For a noncovalent protein break, both terminal roles are jointly hidden;
  their reconstruction losses are averaged; that boundary counts once.
- At least two distinct visible context objects must remain within 24 route
  positions; otherwise the object is explicitly unscored.
- Per-role loss is 0.25*(1-raw cosine)+0.75*(1-type-centered cosine).
  If ||target-type_mean|| <=1e-6, use raw cosine for that role instead.
- Object score=1-mean(role losses), range[-1,1], higher agreement is better.
- Type means are the original natural-training means; specific mean requires
  at least 100 unique feature rows, else original broad/terminal-role mean.
- balanced_mean=0.5*(mean domains + mean all physical boundaries).
  balanced_q25=0.5*(domain lower quartile + boundary lower quartile).
  Plain mean,q25,minimum and family means are also exported unchanged.
These are reconstruction diagnostics, not calibrated activity probabilities.

Performance changes are restricted to batching:
The original collator builds each clean chunk once. Query batches gather full
records and mask them independently on GPU. Vectorized role reductions avoid
one GPU synchronization per physical object. The frozen encoder, masking rules,
target means and arithmetic definition are unchanged. Original source files
were copied byte-for-byte; see ORIGINAL_SOURCE_HASHES.json.

Required validation before scoring:
  python3 -B -m maps.tests --require-torch
This covers mixed record lengths, several query batch sizes, noncovalent roles,
centered-target fallback and label independence, comparing the new batched
path against the original Runtime.score_plans implementation. Local environment
lacks Torch: five non-Torch tests passed; three numerical tests must run in the
Jean Zay PyTorch module.

On the actual checkpoint, run score_records on the 27 existing triple records and
compare each output to archived maps using compare_results(...,atol=1e-5).
Also compare score_records to score_records_reference for representative new
records including all four chain-count cases and exact donor repetitions.
The controller must stop if these numerical checks fail. They validate batching
and source identity, not new biological predictive performance.

Local audit independently reproduced every original masking plan for all 60
historic double/triple records: 2,042/2,042 exact, including 16 noncovalent objects.
See REAL_MASK_PARITY.json. No GPU predictions were generated in that audit.
