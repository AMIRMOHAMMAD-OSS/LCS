"""Scientific-contract and batching regressions; Torch tests mandatory on Jean Zay."""
import argparse
import copy
import functools
import importlib.util
import json
from pathlib import Path
import random
import sys
import unittest
import numpy as np

from .scorer import (MapScorer, validate_record, result_shell, finish_result,
                     compare_results, make_plan, aggregate, CONTRACT)
from .vendor_map.neuralps.contracts import seqsha

HAS_TORCH = importlib.util.find_spec('torch') is not None


def fixture(alias=False, short=False, feature_dim=8):
    rng = random.Random(47)
    proteins = [''.join(rng.choices('ACDEFGHIKLMNPQRSTVWY', k=100)) for _ in range(2)]
    if alias:
        proteins[1] = proteins[1][:40] + proteins[0][20:30] + proteins[1][50:]
    ph = [seqsha(s) for s in proteins]
    parents = dict(zip(ph, proteins))
    route = [dict(kind=k, domain_type=1 if k == 0 else 0, chain=c)
             for k,c in [(0,1),(1,1),(0,1),(2,-1),(0,2),(1,2),(0,2)]]
    spans = [(0,0,0,0,10),(1,0,0,7,23),(2,0,0,20,30),(3,1,0,80,90),
             (3,2,1,0,10),(4,0,1,20,30),(5,0,1,27,43),(6,0,1,40,50)]
    if short:
        route=route[:5];spans=[s for s in spans if s[0]<5]
    slots=[];vectors={};nrng=np.random.default_rng(8)
    for j,role,p,a,b in spans:
        h=seqsha(proteins[p][a:b]);kind=route[j]['kind']
        group='D:1' if kind==0 else 'C:1:1' if kind==1 else 'B:'+('cterm' if role==1 else 'nterm')
        slots.append(dict(object_index=j,slot=role,kind=kind,state='OBSERVED',sequence_hash=h,
                          parent_sequence_hash=ph[p],start=a,end=b,length=b-a,group=group))
        if h not in vectors:vectors[h]=nrng.normal(size=feature_dim).astype('f4')
    record=dict(assembly_id='fixture'+str(alias)+str(short),route=route,model_slots=slots,
                parent_sequence_hashes={'p1':ph[0],'p2':ph[1]})
    return record,parents,vectors


class Contracts(unittest.TestCase):
    def test_joint_nonco_roles_and_no_recursive_overlap_expansion(self):
        rec,parents,vectors=fixture();validate_record(rec,parents,vectors)
        plan=make_plan(rec,[3],parents)
        self.assertEqual(set(map(tuple,plan['primary'])),{(3,1),(3,2)})
        plan=make_plan(rec,[2],parents)
        self.assertIn((1,0),map(tuple,plan['hidden']))
        self.assertNotIn((0,0),map(tuple,plan['hidden']))

    def test_duplicate_copy_and_its_overlap_are_hidden(self):
        rec,parents,vectors=fixture(alias=True);validate_record(rec,parents,vectors)
        plan=make_plan(rec,[2],parents)
        self.assertIn((6,0),map(tuple,plan['hidden']))
        self.assertIn((5,0),map(tuple,plan['hidden']))
        self.assertEqual(plan['status'],'READY')

    def test_parent_and_slot_tampering_rejected(self):
        rec,parents,vectors=fixture();changed=dict(parents);h=next(iter(parents));changed[h]='A'+parents[h][1:]
        with self.assertRaisesRegex(ValueError,'Parent sequence'):validate_record(rec,changed,vectors)
        rec['model_slots'][0]['start']+=1
        with self.assertRaisesRegex(ValueError,'Slot sequence'):validate_record(rec,parents,vectors)

    def test_missing_object_never_dropped_from_aggregate(self):
        objects=[dict(object_index=0,kind=0,status='SCORED',scores={'full':.8}),
                 dict(object_index=1,kind=2,status='MISSING_SEQUENCE_FEATURE',scores={})]
        r=aggregate(objects,'full');self.assertFalse(r['complete']);self.assertIsNone(r['balanced_mean'])
        self.assertEqual(r['total'],2)

    def test_balanced_aggregate_counts_nonco_once(self):
        objects=[dict(object_index=j,kind=k,status='SCORED',scores={'full':s}) for j,k,s in [(0,0,.8),(1,2,.2),(2,0,.6)]]
        r=aggregate(objects,'full');self.assertAlmostEqual(r['balanced_mean'],.45);self.assertEqual(r['total'],3)
        self.assertFalse(CONTRACT['activity_probability']);self.assertEqual(CONTRACT['computed_paths'],['full'])


@unittest.skipUnless(HAS_TORCH,'Torch unavailable; mandatory on Jean Zay')
class Numerical(unittest.TestCase):
    def runtime(self,vectors):
        import torch
        from .vendor_map.neuralps.assembly_model import AssemblyEncoder,Config,collate_records
        from .vendor_map.neuralps.scoring import Runtime
        torch.set_num_threads(1);torch.manual_seed(28)
        rt=Runtime.__new__(Runtime)
        rt.model=AssemblyEncoder(Config(feature_dim=8,width=16,heads=4,local_layers=1,radius=3,
                                      global_layers=1,global_slots=2,dropout=0)).eval().requires_grad_(False)
        with torch.no_grad():rt.model.global_blocks[0].write.out_proj.weight.normal_(0,.1)
        rt.collate=functools.partial(collate_records,feature_dim=8);rt.device='cpu'
        rt.means={'m':np.linspace(.1,.3,8,dtype='f4')}
        rt.mean_map={k:('m',100) for k in ['D','C','B:cterm','B:nterm']}
        return rt

    def test_batched_heterogeneous_records_equal_original_runtime(self):
        a,pa,va=fixture();b,pb,vb=fixture(alias=True,short=True)
        vectors={**va,**vb};rt=self.runtime(vectors)
        scorer=MapScorer.from_runtime(rt,vectors,query_batch=4)
        reference=scorer.score_records_reference([(a,pa),(b,pb)],microbatch=1)
        actual=scorer.score_records([(a,pa),(b,pb)])
        for x,y in zip(actual,reference):self.assertEqual(compare_results(x,y)['status'],'PASS')
        for count in (1,3,64):
            other=MapScorer.from_runtime(rt,vectors,query_batch=count).score_records([(a,pa),(b,pb)])
            for x,y in zip(other,reference):self.assertEqual(compare_results(x,y)['status'],'PASS')

    def test_centered_fallback_and_roles_match_original(self):
        a,parents,vectors=fixture();rt=self.runtime(vectors)
        # Exact equality exercises the raw-cosine fallback for the first target role.
        rt.means['same']=vectors[a['model_slots'][0]['sequence_hash']]
        a['model_slots'][0]['group']='special'
        rt.mean_map['special']=('same',100)
        scorer=MapScorer.from_runtime(rt,vectors,query_batch=64)
        self.assertEqual(compare_results(scorer.score_records([(a,parents)])[0],
                                         scorer.score_records_reference([(a,parents)])[0])['status'],'PASS')

    def test_activity_labels_never_change_maps(self):
        a,parents,vectors=fixture();rt=self.runtime(vectors);scorer=MapScorer.from_runtime(rt,vectors)
        b=copy.deepcopy(a);b['observed_activity']=1;b['label']=0
        x,y=scorer.score_records([(a,parents),(b,parents)])
        self.assertEqual(compare_results(x,y)['maximum_absolute_error'],0.)


if __name__=='__main__':
    if '--require-torch' in sys.argv:
        sys.argv.remove('--require-torch')
        if not HAS_TORCH:raise SystemExit('Torch is required for map numerical regressions')
    unittest.main(verbosity=2)
