"""Local read-only masking parity against all 2,042 published prior map objects."""
import gzip,json,sys
from pathlib import Path
import numpy as np
from .scorer import validate_record,make_plan,required_assets


def audit(input_package, previous_results):
    p=Path(input_package);old=Path(previous_results)
    source=json.load(gzip.open(p/'inputs/known_multis_model_inputs.json.gz','rt'))
    saved=json.load(gzip.open(old/'maps/maps.json.gz','rt'))
    expected={r['assembly_id']:r for r in saved['assemblies']}
    with np.load(old/'feature_bank/feature_bank.npz',allow_pickle=False) as z:
        vectors=dict(zip(z['hashes'].tolist(),z['vectors']))
    count=0; kinds={0:0,1:0,2:0};largest=0
    for record in source['records']:
        validate_record(record,source['parents'],vectors)
        for j,obj in enumerate(record['route']):
            plan=make_plan(record,[j],source['parents']);original=expected[record['assembly_id']]['objects'][j]
            assert plan['status']=='READY' and original['status']=='SCORED'
            for key in ('targets','primary','hidden','remaining_context_by_target','masked_fraction'):
                assert json.loads(json.dumps(plan[key]))==original['mask'][key],(record['assembly_id'],j,key)
            assert len(plan['primary'])==(2 if obj['kind']==2 else 1)
            count+=1;kinds[obj['kind']]+=1;largest=max(largest,len(plan['hidden']))
    return dict(status='PASS',assemblies=len(source['records']),physical_objects=count,
                objects_by_kind=kinds,all_masks_exactly_match_prior_run=True,largest_hidden_slot_count=largest,
                map_required_assets=required_assets(),gpu_inference_performed=False)

if __name__=='__main__':
    report=audit(sys.argv[1],sys.argv[2])
    print(json.dumps(report,indent=2,sort_keys=True))
