"""Frozen SSL26 physical-object maps using the verified map/masking contract.

Only query batching is new: clean assemblies are collated once per chunk, then
independent masked queries share a forward batch. No ESM imports or activity
labels enter this module. Every query retains its complete local/global context.
"""
from __future__ import annotations
from collections import Counter
import hashlib
import json
from pathlib import Path
import numpy as np

from .legacy_map_audit import MAP_CONTRACT, aggregate, digest
from .vendor_map.neuralps.contracts import require, seqsha, sha
from .vendor_map.neuralps.scoring import make_plan, slots_by_object, predict_mode

SCHEMA = 'neuralps_42875_frozen_physical_maps_v1'
REQUIRED_ASSETS = {
    'e1_ssl_continue30_v1_530757/best.pt': '9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f',
    'e1_ssl_targets_497189/targets.npz': '7d81ce504a6b64e6b1c5cf2e71a639dde1b05ec4b2787e655dd235bad536961f',
    'e1_ssl_targets_497189/manifest.json': 'd4571217575bba57d0ee20cd9e2511d5b1a0a792bac7b2caf33033b67816e9db',
}
CONTRACT = dict(MAP_CONTRACT, diagnostic_path=None, computed_paths=['full'],
    checkpoint_sha256=REQUIRED_ASSETS['e1_ssl_continue30_v1_530757/best.pt'],
    target_scope='Complete mature engineered assemblies, conditional on successful splicing',
    whole_construct_aggregates='Descriptive reconstruction diagnostics, not calibrated activity probabilities')


def required_assets():
    return dict(REQUIRED_ASSETS)


def verify_assets(root):
    root = Path(root).resolve()
    verified, signatures = {}, {}
    for relative, expected in REQUIRED_ASSETS.items():
        path = (root / relative).resolve()
        require(root in path.parents and path.is_file(), 'Missing map source: ' + relative)
        before = path.stat()
        actual = sha(path)
        after = path.stat()
        signature = (after.st_size, after.st_mtime_ns, after.st_ino)
        require((before.st_size, before.st_mtime_ns, before.st_ino) == signature,
                'Map source changed while hashing: ' + relative)
        require(actual == expected, 'Frozen map source checksum changed: ' + relative)
        verified[relative] = actual
        signatures[relative] = signature
    return verified, signatures


def validate_record(record, parents, vectors):
    """Cheap physical integrity gate; does not infer annotations or create vectors."""
    route, slots = record['route'], record['model_slots']
    require(route and slots, 'Empty assembly map input')
    by = slots_by_object(record)
    require(set(by) == set(range(len(route))), 'Route/slot coverage mismatch')
    for h in set(record['parent_sequence_hashes'].values()):
        require(h in parents and seqsha(parents[h]) == h, 'Parent sequence checksum mismatch')
    for j, obj in enumerate(route):
        require(obj['kind'] in (0, 1, 2), 'Invalid physical object kind')
        expected = [1, 2] if obj['kind'] == 2 else [0]
        require([s['slot'] for s in by[j]] == expected, 'Invalid physical object roles')
    for slot in slots:
        require(slot['state'] in ('OBSERVED', 'EMPTY', 'MISSING'), 'Unexpected clean slot state')
        require(slot['kind'] == route[slot['object_index']]['kind'], 'Slot/object kind mismatch')
        parent = parents[slot['parent_sequence_hash']]
        require(0 <= slot['start'] <= slot['end'] <= len(parent), 'Invalid slot coordinate')
        sequence = parent[slot['start']:slot['end']]
        require(len(sequence) == slot['length'], 'Slot sequence length mismatch')
        if slot['state'] == 'OBSERVED':
            require(sequence and seqsha(sequence) == slot['sequence_hash'], 'Slot sequence hash mismatch')
            require(slot['sequence_hash'] in vectors, 'Missing completed feature-bank vector')
    return by


def result_shell(record, by):
    return dict(assembly_id=record['assembly_id'], record_sha256=digest(record),
        objects=[dict(object_index=j, kind=o['kind'], annotation=o, slots=by[j],
                      status='PENDING', scores={}, rawcos={}, mask={})
                 for j, o in enumerate(record['route'])])


def finish_result(result):
    result['independent_aggregate'] = {'full': aggregate(result['objects'], 'full')}
    result['rawcos_aggregate'] = {'full': aggregate(result['objects'], 'full', field='rawcos')}
    return result


def compare_results(actual, expected, atol=1e-5):
    """Compare numeric legacy maps without requiring display-label identity."""
    require(actual['assembly_id'] == expected['assembly_id'], 'Map parity identity mismatch')
    require(len(actual['objects']) == len(expected['objects']), 'Map parity object count mismatch')
    maximum, compared = 0., 0
    for a, b in zip(actual['objects'], expected['objects']):
        require(a['object_index'] == b['object_index'] and a['kind'] == b['kind'], 'Map parity object mismatch')
        require(a['status'] == b['status'], 'Map parity availability mismatch')
        for field in ('scores', 'rawcos'):
            av, bv = a.get(field, {}).get('full'), b.get(field, {}).get('full')
            require((av is None) == (bv is None), 'Map parity missing score mismatch')
            if av is not None:
                error = abs(float(av) - float(bv)); maximum = max(maximum, error); compared += 1
                require(np.isfinite(error) and error <= atol, 'Frozen map numerical parity failed')
        for key in ('targets', 'primary', 'hidden', 'remaining_context_by_target'):
            av, bv = a['mask'].get(key), b['mask'].get(key)
            # JSON normalizes tuples into lists in archived maps.
            require(json.loads(json.dumps(av)) == json.loads(json.dumps(bv)), 'Map parity mask mismatch: ' + key)
    for family in ('independent_aggregate', 'rawcos_aggregate'):
        for key, bv in expected[family]['full'].items():
            av = actual[family]['full'][key]
            if isinstance(bv, (float, int)) and not isinstance(bv, bool):
                error = abs(float(av) - float(bv)); maximum = max(maximum, error)
                require(np.isfinite(error) and error <= atol, 'Map aggregate numerical parity failed')
            else:
                require(av == bv, 'Map aggregate status parity failed')
    return dict(status='PASS', maximum_absolute_error=maximum, compared_object_scores=compared,
                absolute_tolerance=atol)


class MapScorer:
    def __init__(self, root, vectors, device='cuda', threads=8, query_batch=64):
        from .vendor_map.score_all_parts import load_runtime
        require(device in ('cpu', 'cuda') and type(threads) is int and threads > 0, 'Invalid map runtime settings')
        require(type(query_batch) is int and query_batch > 0, 'Invalid map query batch')
        self.root = Path(root).resolve()
        self.source_hashes, self.signatures = verify_assets(self.root)
        self.runtime, self.environment = load_runtime(self.root, device, threads)
        self.query_batch = query_batch
        self.vectors = vectors
        self._prepare_vector_means()
        self.total_queries = 0

    @classmethod
    def from_runtime(cls, runtime, vectors, query_batch=64):
        """Test/controlled adapter constructor; never used to bypass source validation."""
        require(type(query_batch) is int and query_batch > 0, 'Invalid map query batch')
        obj = cls.__new__(cls)
        obj.runtime, obj.vectors, obj.query_batch = runtime, vectors, query_batch
        obj.root, obj.source_hashes, obj.signatures, obj.environment = None, {}, {}, {}
        obj.total_queries = 0
        obj._prepare_vector_means()
        return obj

    def _prepare_vector_means(self):
        import torch
        self.hashes = sorted(self.vectors)
        require(self.hashes, 'Empty completed feature bank')
        matrix = np.stack([np.asarray(self.vectors[h], np.float32) for h in self.hashes])
        dim = self.runtime.model.cfg.feature_dim
        require(matrix.shape == (len(self.hashes), dim) and np.isfinite(matrix).all()
                and np.all(np.abs(matrix).sum(1) > 0), 'Invalid completed feature bank')
        self.vector_rows = {h: i for i, h in enumerate(self.hashes)}
        self.vector_tensor = torch.as_tensor(matrix, device=self.runtime.device)
        self._mean_cache = {}

    def verify_sources_unchanged(self):
        if self.root is None:
            return
        for relative, signature in self.signatures.items():
            st = (self.root / relative).stat()
            require((st.st_size, st.st_mtime_ns, st.st_ino) == signature, 'Map source changed during inference')

    def _mean(self, slot):
        key = (slot['group'], slot['kind'])
        if key not in self._mean_cache:
            self._mean_cache[key] = self.runtime.target_mean(slot)
        return self._mean_cache[key]

    def _score_query_batch(self, clean, queries):
        import torch
        from torch.nn import functional as F
        rt = self.runtime
        device = rt.device
        selector = torch.tensor([q[0] for q in queries], dtype=torch.long, device=device)
        batch = {k: v.index_select(0, selector) for k, v in clean.items()}
        hb, hj, hr = [], [], []
        obj_index, roles, feature_rows, means, role_valid = [], [], [], [], []
        dim = self.runtime.model.cfg.feature_dim
        for b, (_, j, plan, slots) in enumerate(queries):
            for jj, rr in plan['hidden']:
                hb.append(b); hj.append(jj); hr.append(rr)
            require(1 <= len(slots) <= 2, 'Invalid primary role count')
            obj_index.append(j)
            roles.append([s['slot'] for s in slots] + [0] * (2 - len(slots)))
            feature_rows.append([self.vector_rows[s['sequence_hash']] for s in slots] + [0] * (2 - len(slots)))
            means.append(np.stack([self._mean(s) for s in slots] + [np.zeros(dim, np.float32)] * (2 - len(slots))))
            role_valid.append([True] * len(slots) + [False] * (2 - len(slots)))
        h = tuple(torch.tensor(v, dtype=torch.long, device=device) for v in (hb, hj, hr))
        batch['state'][h] = 4
        batch['x'][h] = float('nan')
        with torch.inference_mode():
            pred = predict_mode(rt.model, batch, local=False)
            require(bool(torch.isfinite(pred).all()), 'Nonfinite masked reconstruction')
            qi = torch.arange(len(queries), device=device)[:, None]
            ji = torch.tensor(obj_index, device=device)[:, None]
            ri = torch.tensor(roles, device=device)
            p = pred[qi, ji, ri].float()
            target = self.vector_tensor[torch.tensor(feature_rows, device=device)].float()
            mean = torch.as_tensor(np.stack(means), device=device).float()
            valid = torch.tensor(role_valid, dtype=torch.bool, device=device)
            rawcos = F.cosine_similarity(p, target, dim=-1, eps=1e-6)
            rawloss = 1 - rawcos
            centeredloss = 1 - F.cosine_similarity(p - mean, target - mean, dim=-1, eps=1e-6)
            loss = torch.where((target - mean).norm(dim=-1) > 1e-6, .25 * rawloss + .75 * centeredloss, rawloss)
            nroles = valid.sum(dim=1)
            mixed = 1 - torch.where(valid, loss, torch.zeros_like(loss)).sum(dim=1) / nroles
            raw = torch.where(valid, rawcos, torch.zeros_like(rawcos)).sum(dim=1) / nroles
            result = torch.stack((mixed, raw), dim=1).cpu().numpy()
        require(np.isfinite(result).all() and np.all(np.abs(result) <= 1.00001), 'Invalid map score range')
        return result

    def score_records(self, record_parents):
        """Return one legacy-compatible full-context map per (record,parents) pair.

        The caller owns atomic chunk checkpointing and soft deadlines. A failed
        chunk returns no results; only complete results should be published.
        """
        pairs = list(record_parents)
        require(pairs, 'Empty map record chunk')
        records, outputs, queries = [], [], []
        for i, (record, parents) in enumerate(pairs):
            by = validate_record(record, parents, self.vectors)
            records.append(record)
            result = result_shell(record, by); outputs.append(result)
            for j in range(len(record['route'])):
                plan = make_plan(record, [j], parents)
                out = result['objects'][j]
                out['status'] = plan['status']
                out['mask'] = dict(plan)
                if plan['status'] == 'READY':
                    queries.append((i, j, plan, by[j]))
        clean = self.runtime.collate(records, self.vectors.__getitem__)
        clean = {k: v.to(self.runtime.device) for k, v in clean.items()}
        for start in range(0, len(queries), self.query_batch):
            chunk = queries[start:start + self.query_batch]
            scores = self._score_query_batch(clean, chunk)
            for (i, j, plan, _), (mixed, raw) in zip(chunk, scores):
                out = outputs[i]['objects'][j]
                out['status'] = 'SCORED'
                out['scores'] = {'full': float(mixed)}
                out['rawcos'] = {'full': float(raw)}
                out['mask'] = dict(plan, status='SCORED')
            self.total_queries += len(chunk)
        return [finish_result(result) for result in outputs]

    def score_records_reference(self, record_parents, microbatch=8):
        """Unchanged legacy scoring route for mandatory numerical parity tests."""
        outputs = []
        for record, parents in record_parents:
            by = validate_record(record, parents, self.vectors)
            plans = {'object_' + str(j): make_plan(record, [j], parents) for j in range(len(record['route']))}
            scores = self.runtime.score_plans(record, parents, self.vectors, plans, modes=('full',), microbatch=microbatch)
            result = result_shell(record, by)
            for j, out in enumerate(result['objects']):
                score = scores['object_' + str(j)]
                out.update(status=score['status'], scores=score['objects'].get(str(j), {}),
                    rawcos=score.get('objects_rawcos', {}).get(str(j), {}),
                    mask={k: v for k, v in score.items() if k not in ('objects', 'objects_rawcos')})
            outputs.append(finish_result(result))
        return outputs

    def summary(self):
        return dict(schema=SCHEMA, contract=CONTRACT, source_hashes=self.source_hashes,
                    environment=self.environment, query_batch=self.query_batch,
                    queries_scored_this_process=self.total_queries, training=False, esmc_inference=False)
