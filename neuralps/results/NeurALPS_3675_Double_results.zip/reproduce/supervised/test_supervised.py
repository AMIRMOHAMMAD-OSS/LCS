"""CPU tests on genuine earlier features, fitted heads and sealed predictions.

GPU weight loading/parity is required separately through SupervisedScorer.parity.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import unittest

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from supervised import runner as sr

ARGS = argparse.Namespace(legacy=HERE.parent/'legacy', report=None)


class SupervisedTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture = sr.load_parity_fixture()
        cls.manifest = sr.assets()
        legacy = Path(ARGS.legacy)
        for rel, expected in cls.manifest['legacy_sha256'].items():
            assert sr.sha(legacy / rel) == expected
        cls.ft = sr._module(legacy / 'core/frozen_test.py', '_supervised_test_frozen')
        cls.rt = sr._module(legacy / 'runtime.py', '_supervised_test_runtime')
        cls.models = {name: cls.ft.load_model(HERE/item['package_path'])[0]
                      for name,item in cls.manifest['frozen_heads'].items()}

    def test_four_real_frozen_heads_reproduce_all60_sealed_probabilities(self):
        from scipy.special import expit
        for name, model in self.models.items():
            actual = expit(self.ft.predict_logits(model, self.fixture['typed'], study='bode2'))
            np.testing.assert_allclose(actual,self.fixture['candidates'][name],rtol=0,atol=1e-12)

    def test_all_three_seed_means_reproduce_sealed_probabilities(self):
        for arm, members in self.fixture['members'].items():
            self.assertEqual([m['seed'] for m in members],list(sr.SEEDS))
            actual,sd = sr.summarize_member_predictions([m['probability'] for m in members])
            np.testing.assert_array_equal(actual,self.fixture['candidates'][arm+'__bode2_only'])
            self.assertTrue(np.all(sd>=0))
        with self.assertRaises(ValueError):sr.summarize_member_predictions([[.1],[.2]])
        with self.assertRaises(ValueError):sr.summarize_member_predictions([[.1],[.2],[np.nan]])

    def test_fixed_probability_blends_reproduce_sealed_predictions(self):
        for arm in sr.ARMS[1:]:
            actual=.5*self.fixture['candidates']['typed__bode2_only']+.5*self.fixture['candidates'][arm+'__bode2_only']
            np.testing.assert_array_equal(actual,self.fixture['candidates']['blend50_typed_'+arm])

    def test_prior_neural_manifests_all105_single_rows(self):
        for arm in sr.ARMS:
            members=self.manifest['neural_checkpoints'][arm]
            self.assertEqual([m['seed'] for m in members],list(sr.SEEDS))
            self.assertEqual(len({m['sha256'] for m in members}),3)
            for m in members:
                self.assertEqual(m['trained_on'],'105 BODE2 single exchanges only')
                self.assertGreater(m['selected_epoch'],0)

    def test_label_rejection_and_frozen_head_dimensions(self):
        for name,model in self.models.items():
            self.assertEqual(len(model['mean']),2822)
            self.assertEqual(len(model['scale']),2822)
            self.assertFalse(model['chemistry_feature_names'])
        with self.assertRaises(ValueError):self.rt.reject_labels([{'assembly_id':'x','label':1}])
        with self.assertRaises(ValueError):self.rt.reject_labels([{'expected':{'activity':1}}])

    def test_column_composition_matches_all_nonchemistry_candidates(self):
        scorer=object.__new__(sr.SupervisedScorer)
        scorer.ft,scorer.rt=self.ft,self.rt
        scorer.heads,scorer.chemistry_head=self.models,None
        n=len(self.fixture['assembly_ids'])
        members={}
        for arm,ms in self.fixture['members'].items():
            for m in ms:
                members[f"{arm}__seed{m['seed']}__logit"]=m['logits'].copy()
                members[f"{arm}__seed{m['seed']}__probability"]=m['probability'].copy()
        scorer._typed_and_members=lambda records,vectors:(self.fixture['typed'].copy(),members.copy())
        records=[{'assembly_id':aid} for aid in self.fixture['assembly_ids']]
        out=scorer.score_records(records,{},return_typed=True)
        self.assertEqual(out['__typed_features'].shape,(60,2822))
        for name,p in self.fixture['candidates'].items():
            if name=='typed_chemistry__bode2_only':continue
            np.testing.assert_allclose(out[name+'__probability'],p,rtol=0,atol=1e-12)
        gate=scorer.parity(records,{},self.fixture,tolerance=1e-10)
        self.assertEqual(gate['status'],'PASS')
        bad=dict(self.fixture,candidates=dict(self.fixture['candidates']))
        bad['candidates']['typed__bode2_only']=bad['candidates']['typed__bode2_only'].copy()+.01
        with self.assertRaisesRegex(ValueError,'parity failed'):
            scorer.parity(records,{},bad,tolerance=1e-10)


def main():
    global ARGS
    parser=argparse.ArgumentParser()
    parser.add_argument('--legacy',type=Path,default=HERE.parent/'legacy')
    parser.add_argument('--report',type=Path)
    ARGS=parser.parse_args()
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SupervisedTests))
    summary=dict(status='PASS' if result.wasSuccessful() else 'FAIL',tests_run=result.testsRun,
                 errors=len(result.errors),failures=len(result.failures),skipped=len(result.skipped),
                 evidence='Actual frozen-head predictions and earlier neural member values; GPU forward gate remains required.')
    if ARGS.report:ARGS.report.write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary))
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__=='__main__':main()
