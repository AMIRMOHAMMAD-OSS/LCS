FIXED SUPERVISED COMPARATORS FOR THE 42,875 LIBRARY

Implementation: supervised/runner.py
Install this directory unchanged at package/supervised. Exact earlier inference
and fitting-code definitions are read from package/legacy (or legacy_dir).
ASSETS.json here is local to this subpackage; root package assets may have their
own separate manifest.

Public API
  from supervised.runner import SupervisedScorer, validate_assets, load_parity_fixture
  validate_assets(root, legacy_dir=package/'legacy', include_chemistry=True)
  scorer = SupervisedScorer(root, device='cuda', batch_size=32,
                            legacy_dir=package/'legacy', include_chemistry=True)
  columns = scorer.score_records(records, vectors, chemistry=feature_dicts)

records: a bounded list of audited complete assembly records.
vectors: SHA256 -> 1152-dimensional float32 feature vector mapping.
chemistry: aligned expected-substrate dictionaries from chemistry_features.py.
return_typed=True additionally returns __typed_features [n,2822]; otherwise every
returned value is a 1-D numeric column. The controller owns assembly IDs,
chunk transactions, all outputs and resume. Scorer never reads outcome labels,
fits anything, edits the original inputs/cache, or selects a winner.

Mandatory GPU parity gate before bulk scoring
  report = scorer.parity(known27_records, vectors, load_parity_fixture(),
                         chemistry=known27_feature_dicts, tolerance=1e-4)
This compares IDs against the prior sealed 60-combination predictions, all 10
candidate probabilities, every neural member logit and probability, and the
frozen typed2822 representations. The bundled fixture is features/predictions
only; it contains no activity labels. Subsetting by assembly_id allows the known
27 triples to be verified against the completed full-library bank.

Fixed candidates, same prior experiment
- typed__bode2_only: frozen natural SSL26 typed2822 logistic head,105BODE2singles.
- typed__bode2_bode1_w025: same representation,105BODE2+324correctedBODE1.
- typed__bode2_tdomain_w025:105BODE2+65T-domain.
- typed__all3_w025:105BODE2+324correctedBODE1+65T-domain.
  All slopes use lambda10 and weighted study-mean loss; auxiliary weights0.25.
  Per-study intercepts are fitted; all target predictions use the BODE2 intercept.
  The four small exact fitted heads are bundled under heads/.
- typed_chemistry__bode2_only: original existing lambda10 typed+chemistry head,
  trained on105BODE2singles. The original NPZ is loaded from Jean Zay; no refit.
- raw_mlp__bode2_only: original three-seed rawESMC global MLP comparator.
- ssl10_finetune__bode2_only: original three-seed full-assembly fine-tuned encoder.
- ssl26_finetune__bode2_only: original three-seed full-assembly fine-tuned encoder.
  Each neural member was selected on the original singles inner split and
  refitted on all105singles; none used the60combinations for fitting.
- blend50_typed_ssl10_finetune and blend50_typed_ssl26_finetune:
  fixed equal-weight probability blends from the original comparison.

Neural seeds17,29,43; exact existing checkpoint paths/hashes and selected epochs
are pinned in ASSETS.json. No checkpoint regeneration or training fallback is
provided: absent/changed weights stop preflight.

Column names
Individual frozen heads and neural members: <name>__logit and __probability.
Neural members: raw_mlp__seed17, ssl10_finetune__seed17, etc.
Neural ensembles: <arm>__bode2_only__probability and __seed_sd.
Ensemble score is arithmetic mean of three probabilities, not sigmoid of mean
logits. seed_sd is descriptive seed variability, not a confidence interval.
Blends expose probability only; no ambiguous ensemble logit is invented.

Runtime
All existing checkpoints are loaded once, frozen in eval mode. Ten encoder/head
objects persist (one frozenSSL26 plus nine fitted neural members; raw MLPs are
small). This is modest memory on the intended80GB A100. Inputs are collated and
scored in bounded minibatches. Torch2.8, no autocast/ESMC inference, TF32disabled,
deterministic settings match the prior fitting/inference runtime. CUBLAS config
must be set before CUDA operations; constructor sets it if absent.

Validation executed locally
Six tests passed against actual saved typed60 features, all four real frozen
heads, earlier nine member predictions, sealed ensemble/blend predictions,
label-rejection policy and fixed provenance. The probability-composition tests
use previously computed member predictions; GPU forward inference remains the
mandatory allocated-job gate above. No local Torch/GPU claim is made.

Scientific interpretation
These are fixed exploratory expected-product-detection scores, not established
activation probabilities for unmeasured triples. All comparators are exported;
there is no new supervised winner selection or probability calibration. The
unsupervised physical-object maps are computed independently by the map runner.
