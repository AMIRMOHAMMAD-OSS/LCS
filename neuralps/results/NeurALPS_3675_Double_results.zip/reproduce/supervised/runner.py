"""Inference-only reuse of the fixed Patrick multi-exchange comparison models.

No training, ESM extraction, activity-label access or candidate selection occurs.
The controller owns output transactions and resume. Models are loaded once; a
small record chunk is scored by every fixed comparator before it is committed.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
ARMS = ('raw_mlp', 'ssl10_finetune', 'ssl26_finetune')
SEEDS = (17, 29, 43)
SEMANTICS = 'Uncalibrated expected-product detection score; exploratory triple ranking, no prospective calibration claim.'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def assets():
    return json.loads((HERE / 'ASSETS.json').read_text())


def default_legacy_dir():
    return HERE.parent / 'legacy'


def validate_assets(root, legacy_dir=None, include_chemistry=True, hash_files=True):
    """Read-only, CPU-only asset verification for submission preflight."""
    root = Path(root).resolve()
    legacy_dir = Path(legacy_dir or default_legacy_dir()).resolve()
    manifest = assets()
    entries = []
    for relative, expected in manifest['legacy_sha256'].items():
        entries.append((legacy_dir / relative, expected, 'legacy_code'))
    frozen = manifest['frozen_encoder']
    entries.append((root / frozen['relative_path'], frozen['sha256'], 'frozen_ssl26'))
    for item in manifest['frozen_heads'].values():
        path = HERE / item['package_path']
        entries += [(path, item['sha256'], 'frozen_head'),
                    (path.with_suffix('.json'), item['metadata_sha256'], 'frozen_head_metadata')]
    for arm in ARMS:
        for item in manifest['neural_checkpoints'][arm]:
            entries.append((root / item['relative_path'], item['sha256'], 'fitted_' + arm))
    if include_chemistry:
        item = manifest['chemistry_head']; path = root / item['relative_path']
        entries += [(path, item['sha256'], 'chemistry_head'),
                    (path.with_suffix('.json'), item['metadata_sha256'], 'chemistry_head_metadata')]
    proof = []
    for path, expected, kind in entries:
        require(path.is_file(), 'Required fixed supervised asset missing: ' + str(path))
        if hash_files:
            require(sha(path) == expected, 'Fixed supervised asset checksum mismatch: ' + str(path))
        proof.append(dict(path=str(path), sha256=expected, role=kind,
                          checksum_verified=bool(hash_files)))
    return dict(schema=manifest['schema'], assets=proof, training_performed=False,
                seed_ensembles='Arithmetic mean of probabilities for seeds17,29,43; never mean logits.',
                score_interpretation=SEMANTICS)


def _module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_legacy(legacy_dir=None):
    """Import exact checked legacy modules without hijacking controller.runtime."""
    legacy_dir = Path(legacy_dir or default_legacy_dir()).resolve()
    manifest = assets()
    for relative, expected in manifest['legacy_sha256'].items():
        require(sha(legacy_dir / relative) == expected, 'Legacy supervised code differs: ' + relative)
    core = str(legacy_dir / 'core')
    if core not in sys.path:
        sys.path.insert(0, core)
    ft = _module(legacy_dir / 'core/frozen_test.py', '_neuralps42875_frozen_test')
    nb = _module(legacy_dir / 'core/neural_backend.py', '_neuralps42875_neural_backend')
    rt = _module(legacy_dir / 'runtime.py', '_neuralps42875_multi_runtime')
    # SavedClassifier imports this original package name internally. Refuse a
    # stale or unrelated pre-import rather than silently loading different code.
    import vendor_neural.assembly_model as am
    require(sha(am.__file__) == manifest['legacy_sha256']['core/vendor_neural/assembly_model.py'],
            'Imported assembly model has wrong identity')
    return ft, nb, rt, am


def summarize_member_predictions(member_probabilities):
    """Three equal-weight seed scores and descriptive seed variability only."""
    values = np.asarray(member_probabilities, dtype=np.float64)
    require(values.ndim == 2 and values.shape[0] == 3 and values.shape[1] > 0,
            'Exactly three aligned seed predictions are required')
    require(np.isfinite(values).all() and ((values >= 0) & (values <= 1)).all(),
            'Invalid member probability')
    return values.mean(axis=0), values.std(axis=0, ddof=0)


class SupervisedScorer:
    def __init__(self, root, device='cuda', batch_size=32, legacy_dir=None,
                 include_chemistry=True, threads=8):
        require(type(batch_size) is int and batch_size > 0, 'Invalid supervised batch size')
        require(type(threads) is int and threads > 0, 'Invalid thread count')
        self.root = Path(root).resolve()
        self.legacy_dir = Path(legacy_dir or default_legacy_dir()).resolve()
        self.device, self.batch_size = str(device), batch_size
        self.assets = assets()
        self.asset_proof = validate_assets(self.root, self.legacy_dir, include_chemistry)
        initial_asset_stats = {item['path']: self._stat_signature(item['path'])
                               for item in self.asset_proof['assets']}
        os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
        import torch
        if self.device.startswith('cuda'):
            require(torch.cuda.is_available(), 'CUDA unavailable in allocated supervised scoring job')
        torch.set_num_threads(threads)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.set_float32_matmul_precision('highest')
        torch.use_deterministic_algorithms(True)
        self.torch = torch
        self.ft, self.nb, self.rt, self.am = load_legacy(self.legacy_dir)
        frozen = self.assets['frozen_encoder']
        # Only explicitly pinned, user-provided, trusted scientific checkpoints
        # are loaded with weights_only=False; hashes were checked above.
        payload = torch.load(self.root / frozen['relative_path'], map_location='cpu', weights_only=False)
        require(payload['step'] == frozen['step'], 'Wrong frozen SSL26 training step')
        self.frozen = self.am.AssemblyEncoder(self.am.Config(**payload['config']['settings']['encoder']))
        require(self.frozen.cfg.width == 256 and self.frozen.cfg.feature_dim == 1152,
                'Frozen typed readout requires width256 and ESM feature dimension1152')
        self.frozen.load_state_dict(payload['model'], strict=True)
        self.frozen.to(self.device).eval().requires_grad_(False)
        del payload
        self.heads = {}
        for name, item in self.assets['frozen_heads'].items():
            model, metadata = self.ft.load_model(HERE / item['package_path'])
            require(not model['chemistry_feature_names'] and len(model['mean']) == 2822,
                    'Incorrect frozen typed head dimension')
            require(metadata['counts'] == item['training_counts'] and metadata['multi_outcomes_used'] is False,
                    'Frozen head training provenance differs')
            self.heads[name] = model
        self.chemistry_head = None
        if include_chemistry:
            item = self.assets['chemistry_head']
            self.chemistry_head, metadata = self.ft.load_model(self.root / item['relative_path'])
            require(bool(self.chemistry_head['chemistry_feature_names']), 'Chemistry head lacks chemistry columns')
            require(metadata['selected'] == item['selected'] and metadata['train_indices'] == list(range(324, 429)),
                    'Chemistry head training provenance differs')
        self.classifiers = {}
        self.member_metadata = {}
        for arm in ARMS:
            self.classifiers[arm] = []
            self.member_metadata[arm] = []
            for item in self.assets['neural_checkpoints'][arm]:
                classifier = self.nb.SavedClassifier(self.root / item['relative_path'], item['sha256'], device=self.device)
                m = classifier.manifest
                require(classifier.arm == arm and m['seed'] == item['seed'] and
                        m['selected_epoch'] == item['selected_epoch'] and m['input_identity'] == item['input_identity'],
                        'Neural checkpoint training identity differs')
                fit = m['fit_report']
                require(fit['train_indices'] == list(range(324, 429)) and fit['validation_indices'] == [] and
                        fit['test_labels_read'] is False, 'Expected single-exchange-only fitted model')
                self.classifiers[arm].append((item['seed'], classifier))
                self.member_metadata[arm].append(dict(seed=item['seed'], checkpoint_sha256=item['sha256'],
                                                     selected_epoch=item['selected_epoch']))
        self.metadata = dict(schema='neuralps_42875_fixed_supervised_scores_v1',
            frozen_encoder_sha256=frozen['sha256'], frozen_heads=self.assets['frozen_heads'],
            neural_members=self.member_metadata, chemistry_available=include_chemistry,
            chemistry_head=self.assets['chemistry_head'] if include_chemistry else None,
            primary_candidates=list(self.heads) + [a + '__bode2_only' for a in ARMS] +
                ['blend50_typed_' + a for a in ARMS[1:]] +
                (['typed_chemistry__bode2_only'] if include_chemistry else []),
            seed_ensemble='Arithmetic mean of three probabilities; members retained.',
            seed_sd='Descriptive population standard deviation across three seeds; not a confidence interval.',
            blends='Fixed 0.5*typed__bode2_only+0.5*neural ensemble; inherited from previous comparison.',
            frozen_readout='Exact legacy typed_pool, float64,2822 dimensions from clean frozenSSL26 context.',
            training_performed=False, labels_read=False, score_interpretation=SEMANTICS,
            torch_version=torch.__version__, batch_size=batch_size)
        self._asset_stats = {item['path']: self._stat_signature(item['path'])
                             for item in self.asset_proof['assets']}
        require(self._asset_stats == initial_asset_stats,
                'Supervised source changed during model loading')

    @staticmethod
    def _stat_signature(path):
        st = Path(path).stat()
        return (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)

    @property
    def chemistry_feature_names(self):
        return list(self.chemistry_head['chemistry_feature_names']) if self.chemistry_head is not None else []

    def verify_sources_unchanged(self):
        for path, expected in self._asset_stats.items():
            require(self._stat_signature(path) == expected,
                    'Supervised source changed during inference: ' + path)
        return dict(status='PASS', source_files=len(self._asset_stats), verification='stat identity against checksum-verified loaded files')

    def _typed_and_members(self, records, vectors):
        n = len(records)
        typed = np.empty((n, 2822), dtype=np.float64)
        columns = {}
        for arm in ARMS:
            for seed, _ in self.classifiers[arm]:
                for suffix in ('logit', 'probability'):
                    columns[f'{arm}__seed{seed}__{suffix}'] = np.empty(n, dtype=np.float64)
        for start in range(0, n, self.batch_size):
            subset = records[start:start + self.batch_size]
            batch = self.rt.contexts_to_batch(subset, vectors, device=self.device)
            with self.torch.no_grad():
                hidden = self.frozen.features(batch, context=True).cpu().numpy()
            for j, record in enumerate(subset):
                typed[start+j] = self.rt.typed_pool(hidden[j, :len(record['route'])], record['route'])
            for arm in ARMS:
                for seed, classifier in self.classifiers[arm]:
                    prediction = classifier.predict_batch(batch)
                    columns[f'{arm}__seed{seed}__logit'][start:start+len(subset)] = prediction['logits']
                    columns[f'{arm}__seed{seed}__probability'][start:start+len(subset)] = prediction['probability']
            del batch, hidden
        require(np.isfinite(typed).all(), 'Nonfinite frozen typed representation')
        return typed, columns

    def score_records(self, records, vectors, chemistry=None, return_typed=False):
        """Return column->float64 vector; optional __typed_features is [n,2822].

        records are already reconstructed clean complete assemblies; vectors is a
        sequence-SHA256->1152-vector mapping. Chemistry, when supplied, is the
        aligned list of expected-substrate feature dictionaries, never outcomes.
        The controller retains record IDs and owns atomically saving chunks.
        """
        records = list(records)
        require(records and len({r['assembly_id'] for r in records}) == len(records),
                'Empty or duplicate supervised record batch')
        self.rt.reject_labels(records)
        if chemistry is not None:
            require(self.chemistry_head is not None and len(chemistry) == len(records),
                    'Chemistry head unavailable or chemistry rows misaligned')
            self.rt.reject_labels(chemistry)
        typed, columns = self._typed_and_members(records, vectors)
        from scipy.special import expit
        for name, model in self.heads.items():
            logits = np.asarray(self.ft.predict_logits(model, typed, study='bode2'), dtype=np.float64)
            columns[name + '__logit'] = logits
            columns[name + '__probability'] = expit(logits)
        if chemistry is not None:
            logits = np.asarray(self.ft.predict_logits(self.chemistry_head,
                self.ft.FeatureBundle(typed, chemistry), study='bode2'), dtype=np.float64)
            columns['typed_chemistry__bode2_only__logit'] = logits
            columns['typed_chemistry__bode2_only__probability'] = expit(logits)
        for arm in ARMS:
            mean, sd = summarize_member_predictions([columns[f'{arm}__seed{s}__probability'] for s in SEEDS])
            columns[arm + '__bode2_only__probability'] = mean
            columns[arm + '__bode2_only__seed_sd'] = sd
        for arm in ARMS[1:]:
            columns['blend50_typed_' + arm + '__probability'] = (
                0.5 * columns['typed__bode2_only__probability'] +
                0.5 * columns[arm + '__bode2_only__probability'])
        for name, values in columns.items():
            require(values.shape == (len(records),) and np.isfinite(values).all(),
                    'Invalid supervised output: ' + name)
            if name.endswith('__probability'):
                require(((values >= 0) & (values <= 1)).all(), 'Probability outside[0,1]: ' + name)
        if return_typed:
            columns['__typed_features'] = typed
        return columns

    def parity(self, records, vectors, fixture, chemistry=None, tolerance=1e-4):
        """Gate actual weights/inference against earlier sealed known predictions.

        fixture contains assembly_ids, candidates and optional typed/member data.
        It is prediction-only; no biological activity labels enter this check.
        """
        ids = [r['assembly_id'] for r in records]
        expected_ids = fixture['assembly_ids']; positions = {aid: i for i, aid in enumerate(expected_ids)}
        require(len(positions) == len(expected_ids) and all(aid in positions for aid in ids),
                'Parity fixture identity mismatch')
        take = [positions[aid] for aid in ids]
        actual = self.score_records(records, vectors, chemistry, return_typed=True)
        errors = {}
        for name, expected in fixture['candidates'].items():
            if name == 'typed_chemistry__bode2_only' and chemistry is None:
                continue
            key = name + '__probability'
            require(key in actual, 'Missing historical candidate: ' + name)
            error = float(np.max(np.abs(actual[key] - np.asarray(expected, dtype=np.float64)[take])))
            require(error <= tolerance, 'Historical supervised probability parity failed: ' + name + ': ' + str(error))
            errors[key] = error
        if 'typed' in fixture:
            error = float(np.max(np.abs(actual['__typed_features'] - np.asarray(fixture['typed'])[take])))
            require(error <= tolerance, 'Historical frozen typed feature parity failed: ' + str(error))
            errors['typed_feature_max_abs'] = error
        for arm, members in fixture.get('members', {}).items():
            for member in members:
                for suffix, source in (('logit', 'logits'), ('probability', 'probability')):
                    key = f"{arm}__seed{member['seed']}__{suffix}"
                    error = float(np.max(np.abs(actual[key] - np.asarray(member[source])[take])))
                    require(error <= tolerance, 'Historical neural member parity failed: ' + key + ': ' + str(error))
                    errors[key] = error
        return dict(status='PASS', assemblies=len(records), assembly_ids=ids, tolerance=tolerance,
                    max_abs_errors=errors, activity_labels_read=False, training_performed=False)


def load_parity_fixture():
    """Earlier predictions/features only; no outcome labels or new fitting."""
    manifest = json.loads((HERE / 'PARITY_FIXTURE.json').read_text())
    path = HERE / 'parity_fixture.npz'
    require(sha(path) == manifest['fixture_sha256'], 'Historical supervised fixture checksum mismatch')
    with np.load(path, allow_pickle=False) as archive:
        result = dict(assembly_ids=archive['assembly_ids'].tolist(), typed=archive['typed'].copy(),
                      candidates={}, members={})
        for name in manifest['candidate_names']:
            result['candidates'][name] = archive['candidate::' + name].copy()
        for arm, seeds in manifest['member_seeds'].items():
            result['members'][arm] = [dict(seed=s,
                logits=archive[f'member::{arm}::{s}::logits'].copy(),
                probability=archive[f'member::{arm}::{s}::probability'].copy()) for s in seeds]
    return result
