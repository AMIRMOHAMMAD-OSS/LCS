#!/usr/bin/env python3
"""Restore supported B/J annotations for map/export views, without altering inputs.

These tags describe source module boundaries; physical connectivity is the
separate ``kind`` field. New cross-source adjacencies remain UNKNOWN. This
module never writes the original input archive or its files.

Usage from scoring/export code:
    annotations = BoundaryAnnotations(package_directory)
    displayed_record = annotations.annotate_record(record)

Use the original record for inference, or the returned copy: every model field
and sequence remains identical. The returned copy changes only auxiliary
connection annotations and adds their provenance.
"""
from __future__ import annotations

import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

POLICY = 'exact_source_adjacency_or_unknown_v1'
SOURCE_RELATIVE = 'provenance/source_audit/source_evidence/routes.jsonl.gz'
SOURCE_SHA256 = '83b0f2e07adc07c5d53c6d41f387fb50f43ff85f9ef1ba70e241ea13d1005a21'
ALLOWED = {'B', 'J', 'UNKNOWN'}


def _sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def _source_domain(domain):
    return domain.get('source_domain', domain)


def _signature(left, boundary, right):
    """Require the same endpoints and connection sequence/state, not just names."""
    return (
        left['domain_type'], left['canonical_domain_type'], left['seq_hash'],
        right['domain_type'], right['canonical_domain_type'], right['seq_hash'],
        boundary['kind'], boundary.get('seq_hash'), boundary.get('cterm_hash'),
        boundary.get('nterm_hash'), boundary.get('state0'),
        boundary.get('cterm_state'), boundary.get('nterm_state'),
    )


def _boundaries(record):
    route = record['route']
    if not route or len(route) % 2 != 1:
        raise ValueError('Expected an alternating domain/connection route')
    for j, obj in enumerate(route):
        if j % 2 == 0:
            if obj['kind'] != 0:
                raise ValueError('Expected a domain at even route index')
        else:
            if obj['kind'] not in (1, 2):
                raise ValueError('Expected a physical connection at odd index')
            yield j, route[j - 1], obj, route[j + 1]


class BoundaryAnnotations:
    def __init__(self, package):
        self.package = Path(package).resolve()
        path = self.package / SOURCE_RELATIVE
        if _sha(path) != SOURCE_SHA256:
            raise ValueError('Original BODE2 route evidence checksum differs')
        self.index = {}
        self.source_records = []
        with gzip.open(path, 'rt') as stream:
            for line in stream:
                record = json.loads(line)
                self.source_records.append(record)
                for j, left, boundary, right in _boundaries(record):
                    key = (left['source_domain_uid'], right['source_domain_uid'])
                    if key in self.index:
                        raise ValueError('Duplicate original source adjacency')
                    annotation = boundary['annotation']
                    if annotation not in ALLOWED:
                        raise ValueError('Unexpected original annotation')
                    self.index[key] = dict(
                        annotation=annotation,
                        signature=_signature(left, boundary, right),
                        source_assembly_id=record['assembly_id'],
                        source_boundary_id=boundary['boundary_id'],
                        source_object_index=j,
                    )
        if len(self.source_records) != 106:
            raise ValueError('Expected exactly 106 original source records')

    def annotate_record(self, record):
        """Return a shallow copy with copied connection dictionaries only.

        Never infer module membership from stale module_uid values on a new
        recombination. ``kind=1`` remains covalent even when annotation=UNKNOWN;
        ``kind=2`` remains a two-ended physical break.
        """
        result = dict(record)
        result['route'] = list(record['route'])
        result['boundary_annotation_policy'] = POLICY
        for j, left, boundary, right in _boundaries(record):
            source_left, source_right = _source_domain(left), _source_domain(right)
            key = (source_left['source_domain_uid'], source_right['source_domain_uid'])
            match = self.index.get(key)
            fixed = dict(boundary)
            fixed.setdefault('legacy_reconstruction_annotation', boundary.get('annotation'))
            provenance = dict(policy=POLICY, left_source_domain_uid=key[0],
                              right_source_domain_uid=key[1])
            if match is not None and match['signature'] == _signature(left, boundary, right):
                fixed['annotation'] = match['annotation']
                provenance.update(status='EXACT_SOURCE_ADJACENCY',
                                  source_assembly_id=match['source_assembly_id'],
                                  source_boundary_id=match['source_boundary_id'],
                                  source_object_index=match['source_object_index'])
            else:
                fixed['annotation'] = 'UNKNOWN'
                provenance['status'] = ('SOURCE_ADJACENCY_CHANGED' if match is not None
                                        else 'NEW_SOURCE_ADJACENCY')
            fixed['annotation_provenance'] = provenance
            result['route'][j] = fixed
        return result


def _model_payload(record):
    """Actual collator-relevant data plus full sequence/coordinate information."""
    cleaned = dict(record)
    cleaned.pop('boundary_annotation_policy', None)
    cleaned['route'] = []
    for obj in record['route']:
        if obj['kind']:
            obj = {k: v for k, v in obj.items() if k not in {
                'annotation', 'legacy_reconstruction_annotation', 'annotation_provenance'}}
        cleaned['route'].append(obj)
    return cleaned


def audit(package):
    annotator = BoundaryAnnotations(package)
    original_count = 0
    original_labels = Counter()
    for record in annotator.source_records:
        result = annotator.annotate_record(record)
        if _model_payload(record) != _model_payload(result):
            raise AssertionError('A model/sequence field changed')
        for j, _, boundary, _ in _boundaries(record):
            if result['route'][j]['annotation'] != boundary['annotation']:
                raise AssertionError('Original source annotation did not reproduce')
            original_count += 1
            original_labels[boundary['annotation']] += 1
    counts, labels, kinds, changes = Counter(), Counter(), Counter(), Counter()
    sample_ids, n = [], 0
    path = Path(package) / 'data/assemblies.jsonl.gz'
    with gzip.open(path, 'rt') as stream:
        for line in stream:
            record = json.loads(line)
            result = annotator.annotate_record(record)
            if _model_payload(record) != _model_payload(result):
                raise AssertionError('A model/sequence field changed')
            if annotator.annotate_record(result) != result:
                raise AssertionError('Overlay is not idempotent')
            for j, _, old, _ in _boundaries(record):
                new = result['route'][j]
                counts[new['annotation_provenance']['status']] += 1
                labels[new['annotation']] += 1
                kinds[str(new['kind'])] += 1
                changes[str(old['annotation']) + '->' + new['annotation']] += 1
            if n < 3:
                sample_ids.append(record['assembly_id'])
            n += 1
    if n != 42875:
        raise AssertionError('Expected the complete 42875-assembly universe')
    return dict(status='PASS', policy=POLICY, original_records=106,
                original_boundaries_reproduced=original_count,
                original_boundary_labels=dict(original_labels),
                library_records_checked=n, source_match_counts=dict(counts),
                corrected_label_counts=dict(labels),
                unchanged_physical_kind_counts=dict(kinds),
                annotation_transitions=dict(changes),
                all_other_record_fields_unchanged=True, idempotent=True,
                package_files_modified=False, original_source_sha256=SOURCE_SHA256,
                limits=['B/J are retained source annotations, not newly validated module assignments.',
                        'New source adjacencies are UNKNOWN even if they resemble native domain pairs.',
                        'This overlay does not classify module membership, change physical topology, or change model tensors.'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', required=True, type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    report = audit(args.package)
    text = json.dumps(report, indent=2, sort_keys=True) + '\n'
    if args.report:
        args.report.write_text(text)
    print(text)


if __name__ == '__main__':
    main()
