"""Exploratory rank consensus, applied only after model scores are complete.

Experimental annotations never affect any score, rank or model fit. The
untested-positive-components view is an explicitly labelled evidence filter.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
FAMILIES = {
    'typed_structural': ['typed__all3_w025__probability',
                         'typed__bode2_bode1_w025__probability',
                         'typed__bode2_only__probability',
                         'typed__bode2_tdomain_w025__probability'],
    'typed_chemistry': ['typed_chemistry__bode2_only__probability'],
    'raw_mlp': ['raw_mlp__bode2_only__probability'],
    'ssl_finetuned': ['ssl10_finetune__bode2_only__probability',
                      'ssl26_finetune__bode2_only__probability'],
    'derived_blends': ['blend50_typed_ssl10_finetune__probability',
                       'blend50_typed_ssl26_finetune__probability'],
    'unsupervised_map': ['unsupervised__balanced_mean', 'unsupervised__balanced_q25'],
}
SCORES = [column for group in FAMILIES.values() for column in group]
METHODS = ['all12_mean_rank', 'six_family_balanced_rank',
           'five_family_no_derived_blend_rank', 'worst_model_rank']


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def midranks(values):
    """Descending exact-tie midranks, with rank 1 the largest value."""
    require(bool(values) and all(math.isfinite(x) for x in values),
            'Ranking requires finite nonempty score columns')
    order = sorted(range(len(values)), key=lambda i: -values[i])
    ranks = [0.0] * len(values)
    start = 0
    while start < len(order):
        end = start + 1
        while end < len(order) and values[order[end]] == values[order[start]]:
            end += 1
        rank = (start + 1 + end) / 2
        for index in order[start:end]:
            ranks[index] = rank
        start = end
    return ranks


def rank_rows(source_rows):
    """Rank the supplied universe without reading experimental annotations."""
    rows = [dict(row) for row in source_rows]
    require(rows and len({r['assembly_id'] for r in rows}) == len(rows),
            'Empty or duplicate candidate universe')
    for score in SCORES:
        values = [float(row[score]) for row in rows]
        ranks = midranks(values)
        for row, value, rank in zip(rows, values, ranks):
            row[score] = value
            row[score + '__rank'] = rank
    for row in rows:
        ranks = [row[score + '__rank'] for score in SCORES]
        family = {name: sum(row[s + '__rank'] for s in members) / len(members)
                  for name, members in FAMILIES.items()}
        row.update({name + '__mean_rank': value for name, value in family.items()})
        row['all12_mean_rank'] = sum(ranks) / len(ranks)
        row['six_family_balanced_rank'] = sum(family.values()) / len(family)
        row['five_family_no_derived_blend_rank'] = sum(
            value for name, value in family.items() if name != 'derived_blends') / 5
        row['worst_model_rank'] = max(ranks)
    for method in METHODS:
        ordered = sorted(rows, key=lambda r: (r[method], r['six_family_balanced_rank'],
                                             r['all12_mean_rank'], r['assembly_id']))
        for order, row in enumerate(ordered, 1):
            row[method + '__order'] = order
    return sorted(rows, key=lambda r: r['all12_mean_rank__order'])


def write_csv(path, rows, columns):
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(path)


def write_ranking(out):
    out = Path(out)
    source = out / 'scores.csv'
    with source.open(newline='') as stream:
        source_rows = list(csv.DictReader(stream))
    require(len(source_rows) == 3675, 'Exactly 3,675 complete double scores required')
    rows = rank_rows(source_rows)
    # Labels and single-exchange evidence are joined only after every rank exists.
    evidence_path = HERE / 'ranking_evidence.json'
    evidence = json.loads(evidence_path.read_text())
    annotations = {r['construct_id']: r for r in evidence['all_double_annotations']}
    require(len(annotations) == 3675, 'Double evidence inventory differs')
    ids = {r['assembly_id'] for r in rows}
    require(ids == {'BODE2_' + key for key in annotations},
            'Scored IDs differ from the exact-double evidence inventory')
    evidence_columns = ['exchange_positions', 'retained_native_xut', 'plasmid_combination',
                        'both_components_single_positive', 'known_double_tested',
                        'known_double_produced', 'known_double_production_category',
                        'known_double_source_conflict']
    for row in rows:
        annotation = annotations[row['assembly_id'].removeprefix('BODE2_')]
        row['exchange_positions'] = ','.join(map(str, annotation['swapped_xuts']))
        row['retained_native_xut'] = annotation['native_xut']
        row['plasmid_combination'] = annotation['plasmid_combination']
        for key in evidence_columns[3:]:
            value = annotation[key]
            row[key] = int(value) if isinstance(value, bool) else value
    candidates = [row for row in rows if row['both_components_single_positive']
                  and not row['known_double_tested']]
    require(len(candidates) == 1223, 'Untested positive-components inventory differs')
    require(sum(row['known_double_tested'] for row in rows) == 33,
            'Known-double inventory differs')
    lead = ['assembly_id'] + [item for method in METHODS
                              for item in [method + '__order', method]]
    columns = lead + evidence_columns + ['donor_xut2', 'donor_xut3', 'donor_xut4',
        'expected_peptide_aa'] + SCORES + [s + '__rank' for s in SCORES] + [
        name + '__mean_rank' for name in FAMILIES]
    write_csv(out / 'ranked_double_candidates.csv', rows, columns)
    write_csv(out / 'untested_positive_components.csv', candidates, columns)
    method = dict(
        status='EXPLORATORY_RANKING_COMPLETE', candidates=3675, scores_per_candidate=12,
        score_source_sha256=sha(source), evidence_sha256=sha(evidence_path),
        rank_universe='All 3,675 exact double exchanges; all reported ranks use this universe',
        raw_score_averaging=False, experimental_outcomes_used_in_ranking=False,
        model_training_performed=False, family_members=FAMILIES,
        methods={
            'all12_mean_rank': 'Mean descending exact-tie midrank across all 12 scores; lower is better',
            'six_family_balanced_rank': 'Equal mean of six within-family mean ranks; lower is better',
            'five_family_no_derived_blend_rank': 'Equal family mean omitting derived blends; lower is better',
            'worst_model_rank': 'Largest individual score rank; lower is better',
        },
        ordering_ties='Family-balanced rank, then all12 mean rank, then assembly ID',
        untested_positive_components_count=1223,
        filtered_view='Both position-matched component singles reported positive; double untested. '
                      'No new rank calculation after filtering.',
        production_category_definitions=evidence['production_categories'],
        limitations=[
            'These are exploratory preferences, not validated success probabilities or a yield ranking.',
            'All scores are correlated; family weighting and omitted-blend sensitivity are not independent votes.',
            'A retained native XUT is not a guarantee of functional double exchange.',
            'Positive component singles do not establish positive double-exchange function.',
            'Source outcome conflicts remain explicitly flagged.',
        ],
    )
    path = out / 'RANKING_METHOD.json'
    temporary = path.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(method, indent=2, sort_keys=True) + '\n')
    temporary.replace(path)
    return ['ranked_double_candidates.csv', 'untested_positive_components.csv', 'RANKING_METHOD.json']


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps({'ranking_files': write_ranking(args.out)}))
