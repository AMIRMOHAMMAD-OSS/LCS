"""Local structural/transaction tests. No fitted weights, inference, or Slurm."""
import gzip
import importlib.util
import json
from pathlib import Path
import sqlite3
import subprocess
import tempfile
import unittest
from unittest import mock

import numpy as np

import common
import run_scoring
import submit

HERE = Path(__file__).resolve().parent


class QueueGuard(unittest.TestCase):
    def runner(self, responses):
        calls = []
        def run(command, **kwargs):
            calls.append(command)
            code, stdout, stderr = responses.pop(0)
            return subprocess.CompletedProcess(command, code, stdout, stderr)
        return run, calls

    def test_active_target_blocks_without_accounting(self):
        run, calls = self.runner([(0, '1945888|RUNNING\n', '')])
        with self.assertRaisesRegex(ValueError, 'still queued/running'):
            submit.confirm_previous_terminal('1945888', run)
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0], ['squeue', '--noheader', '--jobs', '1945888', '--format', '%i|%T'])

    def test_absent_completed_job_accepted_with_accounting(self):
        run, calls = self.runner([(1, '', 'slurm_load_jobs error: Invalid job id specified'),
                                 (0, '1945888|COMPLETED|0:0\n', '')])
        proof = submit.confirm_previous_terminal('1945888', run)
        self.assertEqual(proof['accounting_state'], 'COMPLETED')
        self.assertEqual(len(calls), 2)

    def test_cancelled_by_user_is_terminal(self):
        run, _ = self.runner([(0, '', ''), (0, '1945888|CANCELLED by 1234|0:15\n', '')])
        self.assertEqual(submit.confirm_previous_terminal('1945888', run)['accounting_state'], 'CANCELLED')

    def test_real_scheduler_failure_never_submits(self):
        run, calls = self.runner([(1, '', 'Unable to contact slurm controller')])
        with self.assertRaisesRegex(ValueError, 'Live queue query failed'):
            submit.confirm_previous_terminal('1945888', run)
        self.assertEqual(len(calls), 1)

    def test_unrelated_array_row_does_not_authorize_submission(self):
        run, calls = self.runner([(0, '1839175_[119-120,129,138,141]|PENDING\n', '')])
        with self.assertRaisesRegex(ValueError, 'still queued/running'):
            submit.confirm_previous_terminal('1945888', run)
        self.assertEqual(len(calls), 1)

    def test_accounting_lag_rechecked_once(self):
        run, calls = self.runner([(0, '', ''), (0, '', ''), (0, '', ''),
                                 (0, '1945888|TIMEOUT|0:15\n', '')])
        self.assertEqual(submit.confirm_previous_terminal('1945888', run)['queries'], 2)
        self.assertEqual(len(calls), 4)

    def test_missing_accounting_fails_closed(self):
        run, calls = self.runner([(0, '', ''), (0, '', ''), (0, '', ''), (0, '', '')])
        with self.assertRaisesRegex(RuntimeError, 'refusing to submit'):
            submit.confirm_previous_terminal('1945888', run)
        self.assertEqual(len(calls), 4)

    def test_accounting_active_is_not_terminal(self):
        run, _ = self.runner([(0, '', ''), (0, '1945888|RUNNING|0:0\n', ''),
                             (0, '', ''), (0, '1945888|PENDING|0:0\n', '')])
        with self.assertRaisesRegex(RuntimeError, 'still PENDING'):
            submit.confirm_previous_terminal('1945888', run)


class CachedRowGate(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        inp = self.root / common.INPUT_NAME / 'feature_bank'
        inp.mkdir(parents=True)
        (inp / 'feature_bank.json').write_text(json.dumps({'missing_hashes': ['a', 'b']}))
        self.cache = self.root / common.CACHE_DIRECTORY
        self.cache.mkdir()
        (self.cache / 'features.f32').write_bytes(bytes(3 * 2 * 4))
        with sqlite3.connect(self.cache / 'feature_index.sqlite3') as db:
            db.execute('CREATE TABLE features(hash TEXT,feature_row INTEGER,status TEXT)')
            db.executemany('INSERT INTO features VALUES(?,?,?)', [('a', 0, 'covered'), ('b', 2, 'covered')])
        self.patches = [mock.patch.object(common, 'CACHE_ROWS', 3), mock.patch.object(common, 'CACHE_DIM', 2),
                        mock.patch.object(common, 'bindings', return_value={'main_cache_rows_required': 2})]
        for patch in self.patches:
            patch.start()

    def tearDown(self):
        for patch in reversed(self.patches):
            patch.stop()
        self.temp.cleanup()

    def test_unique_covered_rows(self):
        self.assertEqual(common.cache_row_lookup(self.root), {'a': 0, 'b': 2})

    def test_missing_covered_row_has_no_extraction_fallback(self):
        with sqlite3.connect(self.cache / 'feature_index.sqlite3') as db:
            db.execute("UPDATE features SET status='missing' WHERE hash='b'")
        with self.assertRaisesRegex(ValueError, 'no extraction fallback'):
            common.cache_row_lookup(self.root)

    def test_duplicate_hash_rejected(self):
        with sqlite3.connect(self.cache / 'feature_index.sqlite3') as db:
            db.execute("INSERT INTO features VALUES('b',1,'covered')")
        with self.assertRaises(ValueError):
            common.cache_row_lookup(self.root)

    def test_wal_rejected(self):
        (self.cache / 'feature_index.sqlite3-wal').touch()
        with self.assertRaisesRegex(ValueError, 'WAL'):
            common.cache_row_lookup(self.root)

    def test_out_of_bounds_row_rejected(self):
        with sqlite3.connect(self.cache / 'feature_index.sqlite3') as db:
            db.execute("UPDATE features SET feature_row=3 WHERE hash='b'")
        with self.assertRaisesRegex(ValueError, 'Invalid original cache row'):
            common.cache_row_lookup(self.root)


class DoubleStructure(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path = HERE.parent / common.INPUT_NAME / 'library_io.py'
        spec = importlib.util.spec_from_file_location('test_double_input_io', path)
        cls.io = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.io)
        cls.library = cls.io.Library()

    def test_complete_two_exchange_scope(self):
        lib = self.library
        self.assertEqual(len(lib), 3675)
        choices = lib.arrays['donor_choices']
        self.assertTrue(np.all(np.sum(choices == 'native', axis=1) == 1))
        self.assertEqual(len(set(lib.arrays['assembly_ids'])), 3675)
        for position in range(3):
            self.assertEqual(int(np.sum(choices[:, position] == 'native')), 1225)

    def test_known33_records_and_chemistry_exact(self):
        path = HERE.parent / common.INPUT_NAME / 'inputs/known_multis_model_inputs.json.gz'
        previous = json.load(gzip.open(path, 'rt'))
        expected = {r['assembly_id']: r for r in previous['records'] if r['cohort'] == 'doubles'}
        import chemistry
        fixture = json.loads((HERE / 'chemistry/chemistry_reference_fixtures.json').read_text())
        chem = {r['assembly_id']: r['features'] for r in fixture['known60']}
        actual = run_scoring.known33_pairs(self.library)
        self.assertEqual(len(actual), 33)
        for record, parents in actual:
            old = expected[record['assembly_id']]
            self.assertEqual(self.io.model_signature(record), self.io.model_signature(old))
            self.assertEqual(self.io.sequence_signature(record), self.io.sequence_signature(old))
            self.assertEqual(run_scoring.chemistry_features(record), chem[record['assembly_id']])
            self.assertEqual(record['donors'].count('native'), 1)

    def test_cached_bank_coverage_identity_and_missing_proof(self):
        inputs = HERE.parent / common.INPUT_NAME
        report = json.loads((inputs / 'feature_bank/feature_bank.json').read_text())
        with np.load(inputs / 'feature_bank/cached_feature_bank.npz', allow_pickle=False) as data:
            cached = set(data['hashes'].tolist())
            self.assertTrue(np.isfinite(data['vectors']).all())
        missing = set(report['missing_hashes'])
        self.assertFalse(cached & missing)
        self.assertEqual(cached | missing, set(self.library.sequence_hashes.tolist()))
        self.assertEqual((len(cached), len(missing)), (2645, 105))

    def test_request_and_bounded_resources(self):
        cmd = submit.command(Path('/project'), Path('/project/output'), Path('/project/request'))
        self.assertIn('--gres=gpu:1', cmd)
        self.assertIn('--time=01:00:00', cmd)
        self.assertIn('--cpus-per-task=8', cmd)
        self.assertIn('--no-requeue', cmd)
        self.assertFalse(any('array' in item for item in cmd))


if __name__ == '__main__':
    unittest.main(verbosity=2)
