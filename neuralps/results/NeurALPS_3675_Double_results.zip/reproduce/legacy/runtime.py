"""Label-free inference on verified complete, mature multi-exchange assemblies.

Embedding runs in envs/esmc_connections_hf. Classifier inference runs in the
original Patrick training environment, using the unchanged neural_backend.
This module never reads an activity label, constructs a route, or fits a model.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "core"))
DIM = 1152
CACHE = "e0_cache_final_491894"
CACHE_ROWS = 548713
CACHE_SHA = {
    "features.f32": "5a7c2f3afd527785ce3c12eaa3b97138034f4dfc811d840b5b44cf1534b9ef90",
    "feature_index.sqlite3": "09a6bde676c2e22bcba78879cf53c1d1979d672bcc1763a9eb49e218f387735b",
}
SSL26_PATH = "e1_ssl_continue30_v1_530757/best.pt"
SSL26_SHA = "9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f"
EMBED_BACKEND_SHA = "7f265efe1ac8eafa97d1ad0b4e6b69145dbbd217a6c225a4a637c306a3ba1f4d"
TYPED_B2_SHA = "dd7e5327d8cff64757fd2384e4c58a1bfc7c3728dfeee653ae93f13bf5e20d94"
AA = frozenset("ACDEFGHIKLMNPQRSTVWY")
FORBIDDEN_KEYS = frozenset(("label", "labels", "activity", "observed_activity", "yield", "titer", "outcome", "outcomes", "assay"))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            result.update(block)
    return result.hexdigest()


def seqsha(sequence):
    return hashlib.sha256(sequence.encode("ascii")).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


def reject_labels(value):
    if isinstance(value, dict):
        require(not (FORBIDDEN_KEYS & {str(k).lower() for k in value}), "Activity labels are forbidden in structural inputs")
        for v in value.values():
            reject_labels(v)
    elif isinstance(value, list):
        for v in value:
            reject_labels(v)


def load_inputs(path):
    path = Path(path)
    with (gzip.open(path, "rt") if path.suffix == ".gz" else path.open()) as stream:
        payload = json.load(stream)
    require(set(payload) == {"records", "parents"}, "Unexpected multi-route input schema")
    validate_records(payload["records"], payload["parents"])
    return payload["records"], payload["parents"]


def validate_records(records, parents):
    """Recheck all physical sequences and model slots without evaluating labels."""
    reject_labels(records)
    require(records and isinstance(parents, dict), "Empty routes/parents")
    require(len({r["assembly_id"] for r in records}) == len(records), "Duplicate assembly identity")
    for h, sequence in parents.items():
        require(isinstance(sequence, str) and sequence and set(sequence) <= AA and seqsha(sequence) == h,
                "Parent sequence/hash mismatch")
    sequences = {}
    for record in records:
        require(record["boundary_window_policy"] == "physical_end_extradomain_tail64_v1", "Wrong boundary policy")
        require(record.get("cache_dependency_policy", "independent_sequence") == "independent_sequence", "Wrong embedding policy")
        route, slots = record["route"], record["model_slots"]
        require(route and len(route) % 2 == 1, "Route must alternate domains and connections")
        for j, obj in enumerate(route):
            require(obj["kind"] == 0 if j % 2 == 0 else obj["kind"] in (1, 2), "Invalid object ordering")
            if obj["kind"] == 0:
                require(type(obj["domain_type"]) is int and 0 <= obj["domain_type"] < 32, "Invalid domain vocabulary")
        seen = set()
        for slot in slots:
            j, k = slot["object_index"], slot["slot"]
            require(type(j) is int and 0 <= j < len(route) and k in (0, 1, 2), "Invalid slot index")
            require((j, k) not in seen, "Duplicate model slot")
            seen.add((j, k))
            kind = route[j]["kind"]
            require(slot["kind"] == kind and (k == 0 if kind != 2 else k in (1, 2)), "Wrong object/role slot")
            require(slot["state"] in ("OBSERVED", "EMPTY", "MISSING", "NA"), "Masked/unknown inference slot")
            ph, uid = slot["parent_sequence_hash"], slot["protein_uid"]
            require(record["parent_sequence_hashes"].get(uid) == ph and ph in parents, "Slot parent identity mismatch")
            parent = parents[ph]
            require(record["parent_lengths"][uid] == len(parent), "Parent length mismatch")
            a, b = slot["start"], slot["end"]
            require(type(a) is int and type(b) is int and 0 <= a <= b <= len(parent), "Invalid physical slot interval")
            sequence = parent[a:b]
            require(len(sequence) == slot["length"], "Slot length mismatch")
            if slot["state"] == "OBSERVED":
                h = slot["sequence_hash"]
                require(0 < len(sequence) <= 2046 and seqsha(sequence) == h, "Slot sequence/hash mismatch")
                object_hash = (route[j].get("seq_hash") if kind != 2 else
                               route[j].get("cterm_hash" if k == 1 else "nterm_hash"))
                require(object_hash == h, "Route object and model-slot hashes differ")
                if kind == 0:
                    require(route[j]["protein_uid"] == uid and route[j]["start_aa_0based"] == a and
                            route[j]["end_aa_0based_exclusive"] == b, "Domain object and slot coordinates differ")
                require(h not in sequences or sequences[h] == sequence, "Sequence hash collision")
                sequences[h] = sequence
        expected = {(j, k) for j, obj in enumerate(route) for k in ((1, 2) if obj["kind"] == 2 else (0,))}
        require(seen == expected, "Missing or unexpected model slot")
    return sequences


def _readonly(path):
    path = Path(path).resolve()
    require(not Path(str(path) + "-wal").exists(), "Cache has a WAL; immutable input required")
    db = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
    db.execute("PRAGMA query_only=ON")
    return db


def _historical_references(root):
    contract_path = root / "NeurALPS_TDomain_Embed_20261006/CONTRACT.json"
    contract = json.loads(contract_path.read_text())
    relative = contract["reference_manifest"]
    ref_path = (root / relative).resolve()
    require(root.resolve() in ref_path.parents, "Reference path leaves project root")
    expected = contract["project_files_sha256"].get(relative)
    require(expected is not None and sha(ref_path) == expected, "Historical reference manifest lacks valid pinned hash")
    refs = json.loads(ref_path.read_text())["references"]
    require(len(refs) >= 8 and len({r["hash"] for r in refs}) == len(refs), "Too few/duplicate historical references")
    for r in refs:
        require(r["hash"] == seqsha(r["seq"]) and r["length"] == len(r["seq"]), "Reference sequence mismatch")
    return refs, dict(contract_sha256=sha(contract_path), manifest=relative, manifest_sha256=expected)


def prepare_feature_bank(root, records, parents, out, references=None):
    """Verify main cache, embed only missing hashes, save a small self-contained bank.

    Invoke in the existing ESM-C environment; output must be a new directory.
    Returns (dict hash->1152D ndarray, provenance report). Existing main cache is
    opened read-only. Completed banks can be loaded with load_feature_bank.
    """
    root, out = Path(root).resolve(), Path(out).resolve()
    require(not out.exists(), "Feature-bank output already exists; use load_feature_bank for completed runs")
    sequences = validate_records(records, parents)
    cache = root / CACHE
    for name, expected in CACHE_SHA.items():
        require(sha(cache / name) == expected, "Main feature cache checksum changed: " + name)
    require((cache / "features.f32").stat().st_size == CACHE_ROWS * DIM * 4, "Main cache byte count differs")
    vectors, missing = {}, []
    data = np.memmap(cache / "features.f32", mode="r", dtype="<f4", shape=(CACHE_ROWS, DIM))
    with _readonly(cache / "feature_index.sqlite3") as db:
        for h, sequence in sorted(sequences.items()):
            hits = db.execute("SELECT feature_row,status FROM features WHERE hash=?", (h,)).fetchall()
            require(len(hits) <= 1, "Duplicate main-cache sequence hash")
            if hits and hits[0][1] == "covered":
                row = hits[0][0]
                require(type(row) is int and 0 <= row < CACHE_ROWS, "Invalid main-cache feature row")
                vectors[h] = np.array(data[row], copy=True)
            else:
                missing.append((h, sequence))
    del data
    out.mkdir(parents=True)
    report = dict(schema="patrick_multi_feature_bank_v1", structural_sha256=digest(records),
                  parents_sha256=digest(parents), source_cache_sha256=CACHE_SHA,
                  sequence_count=len(sequences), reused_count=len(vectors), new_count=len(missing),
                  labels_read=False, embedding_dimension=DIM)
    if missing:
        backend_path = HERE / "vendor_embed/embedding_backend.py"
        require(sha(backend_path) == EMBED_BACKEND_SHA, "Vendored embedding backend changed")
        from vendor_embed.embedding_backend import run_backend
        if references is None:
            references, ref_proof = _historical_references(root)
        else:
            ref_proof = dict(explicit_references_sha256=digest(references))
        report["reference_source"] = ref_proof
        sidecar = out / "novel_sidecar"
        sidecar.mkdir()
        backend = run_backend(root, sidecar, missing, references,
                              progress=lambda event: print(json.dumps(event), flush=True))
        report["embedding_backend"] = backend
        z = np.memmap(sidecar / "features.f32", mode="r", dtype="<f4", shape=(len(missing), DIM))
        with _readonly(sidecar / "feature_index.sqlite3") as db:
            entries = list(db.execute("SELECT hash,feature_row,status FROM features"))
            require({h for h, _, _ in entries} == {h for h, _ in missing}, "New feature identity mismatch")
            for h, row, status in entries:
                require(status == "covered" and 0 <= row < len(missing), "Invalid new-cache row")
                vectors[h] = np.array(z[row], copy=True)
        del z
    hashes = sorted(sequences)
    matrix = np.stack([vectors[h] for h in hashes]).astype("<f4")
    require(matrix.shape == (len(hashes), DIM) and np.isfinite(matrix).all() and
            (np.linalg.norm(matrix.astype(np.float64), axis=1) > 0).all(), "Invalid final feature bank")
    np.savez(out / "feature_bank.npz", hashes=np.array(hashes), vectors=matrix)
    report["feature_bank_sha256"] = sha(out / "feature_bank.npz")
    atomic_json(out / "feature_bank.json", report)
    return vectors, report


def load_feature_bank(path, records=None, parents=None):
    path = Path(path)
    report = json.loads((path / "feature_bank.json").read_text())
    require(sha(path / "feature_bank.npz") == report["feature_bank_sha256"], "Saved bank checksum mismatch")
    with np.load(path / "feature_bank.npz", allow_pickle=False) as z:
        hashes, matrix = z["hashes"].tolist(), z["vectors"].copy()
    require(len(set(hashes)) == len(hashes) and matrix.shape == (len(hashes), DIM), "Invalid saved bank dimensions")
    require(np.isfinite(matrix).all() and (np.linalg.norm(matrix.astype(np.float64), axis=1) > 0).all(), "Invalid bank vectors")
    if records is not None:
        sequences = validate_records(records, parents)
        require(set(hashes) == set(sequences), "Saved bank sequence set differs")
        require(report["structural_sha256"] == digest(records) and report["parents_sha256"] == digest(parents), "Saved bank input identity differs")
    return dict(zip(hashes, matrix)), report


def contexts_to_batch(records, vectors, device="cuda"):
    from vendor_neural.assembly_model import collate_records
    reject_labels(records)
    require(records, "Empty assembly batch")
    return {key: value.to(device) for key, value in collate_records(records, vectors.__getitem__).items()}


def typed_pool(hidden, route):
    """Exact float64 typed2822 readout used by the uploaded logistic model."""
    hidden = np.asarray(hidden, dtype=np.float64)
    require(hidden.shape == (len(route), 256), "Typed readout requires object context width256")
    groups = [[], [], []]
    for j, obj in enumerate(route):
        kind = obj["kind"]
        if kind == 0:
            value = hidden[j]
        else:
            require(0 < j < len(route) - 1 and route[j-1]["kind"] == route[j+1]["kind"] == 0, "Invalid boundary neighbors")
            left, right = hidden[j-1], hidden[j+1]
            value = np.concatenate([left, hidden[j], right, left * right, np.abs(left - right)])
        groups[kind].append(value)
    means = [np.mean(g, axis=0) if g else np.zeros(256 if k == 0 else 1280) for k, g in enumerate(groups)]
    extra = np.asarray([v for g in groups for v in (np.log1p(len(g)), float(bool(g)))])
    return np.concatenate([*means, extra])


def typed_features(root, records, vectors, device="cuda"):
    import torch
    from vendor_neural.assembly_model import AssemblyEncoder, Config
    source_path = Path(root) / SSL26_PATH
    require(sha(source_path) == SSL26_SHA, "Frozen SSL26 checksum mismatch")
    source = torch.load(source_path, map_location="cpu", weights_only=False)
    require(source["step"] == 26000, "Wrong frozen SSL26 update")
    model = AssemblyEncoder(Config(**source["config"]["settings"]["encoder"]))
    model.load_state_dict(source["model"], strict=True)
    model.to(device).eval().requires_grad_(False)
    output = []
    with torch.no_grad():
        for record in records:
            batch = contexts_to_batch([record], vectors, device)
            hidden = model.features(batch)[0, :len(record["route"])].cpu().numpy()
            output.append(typed_pool(hidden, record["route"]))
    del model
    result = np.stack(output)
    require(result.shape == (len(records), 2822) and np.isfinite(result).all(), "Typed feature matrix differs")
    return result


def score_frozen_head(path, typed, chemistry=None, expected_sha256=None):
    from frozen_test import load_model, predict_logits, FeatureBundle
    path = Path(path)
    if expected_sha256 is not None:
        require(sha(path) == expected_sha256, "Unexpected frozen deployment head")
    model, metadata = load_model(path)
    if model["chemistry_feature_names"]:
        require(chemistry is not None and len(chemistry) == len(typed), "Frozen chemistry head needs aligned dictionaries")
        reject_labels(chemistry)
        x = FeatureBundle(typed, chemistry)
    else:
        x = typed
    logits = predict_logits(model, x, study="bode2")
    require(np.isfinite(logits).all(), "Nonfinite frozen prediction")
    from scipy.special import expit
    return dict(logits=logits.tolist(), probability=expit(logits).tolist(),
                checkpoint_sha256=sha(path), interpretation="uncalibrated expected-product detection score")


def saved_classifier_predictions(checkpoints, records, vectors, device="cuda", batch_size=16):
    """checkpoints=[{'path':..., 'sha256':...}], same arm, distinct fitted seeds."""
    from neural_backend import SavedClassifier
    require(checkpoints and type(batch_size) is int and batch_size > 0, "Invalid inference request")
    outputs, seen_seeds, arm = [], set(), None
    for item in checkpoints:
        clf = SavedClassifier(item["path"], item["sha256"], device=device)
        require(arm is None or clf.arm == arm, "Ensemble must use one classifier arm")
        arm = clf.arm
        seed = clf.manifest["seed"]
        require(seed not in seen_seeds, "Duplicate ensemble seed")
        seen_seeds.add(seed)
        logits, probabilities = [], []
        for i in range(0, len(records), batch_size):
            result = clf.predict_batch(contexts_to_batch(records[i:i + batch_size], vectors, device))
            logits.extend(result["logits"].tolist())
            probabilities.extend(result["probability"].tolist())
        outputs.append(dict(seed=seed, checkpoint_sha256=item["sha256"], logits=logits, probability=probabilities))
        del clf
    ensemble = np.mean([o["probability"] for o in outputs], axis=0)
    require(ensemble.shape == (len(records),) and np.isfinite(ensemble).all(), "Invalid ensemble output")
    return dict(arm=arm, members=outputs, probability=ensemble.tolist(),
                ensemble="arithmetic mean of seed probabilities", labels_read=False,
                interpretation="uncalibrated expected-product detection score")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["embed"])
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--inputs", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    records, parents = load_inputs(args.inputs)
    _, report = prepare_feature_bank(args.root, records, parents, args.out)
    print(json.dumps({k: v for k, v in report.items() if k != "embedding_backend"}, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
