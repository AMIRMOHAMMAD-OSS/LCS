#!/usr/bin/env python3
"""Mandatory numerical map regressions and scalar-export semantics.

Default requires PyTorch and refuses skipped tests. --allow-missing-torch exists
only for transparent local development; it is not an inference approval gate.
Real-checkpoint and known27 regressions additionally run in run_scoring.gates.
"""
from __future__ import annotations
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import unittest

import numpy as np
from maps import tests as map_tests
from maps.scorer import aggregate
from run_scoring import map_scalars, rank_descending

HERE = Path(__file__).resolve().parent


class ExportSemantics(unittest.TestCase):
    def test_incomplete_map_cannot_outrank_real_negative_agreement(self):
        def result(score):
            values = dict(complete=score is not None, scored=3 if score is not None else 0,
                          total=3, **{k: score for k in ('balanced_mean','balanced_q25','mean','q25',
                                                      'minimum','domains_mean','boundaries_mean')})
            return dict(independent_aggregate={'full':values},rawcos_aggregate={'full':dict(values)},
                        objects=[{}, {}, {}])
        columns = map_scalars([result(-.7),result(None),result(-.2),result(0.)])
        np.testing.assert_array_equal(columns['map_complete'],[1,0,1,1])
        np.testing.assert_array_equal(rank_descending(columns['unsupervised__balanced_mean'],
                                                     columns['map_complete'].astype(bool)),[3,0,2,1])
        self.assertEqual(columns['map_scored_objects'][1],0)
        self.assertEqual(columns['map_total_objects'][1],3)

    def test_competition_ranks_preserve_ties_and_invalid_rows(self):
        np.testing.assert_array_equal(rank_descending(np.array([.3,.8,.8,.4,1.]),
                                                     np.array([1,1,1,1,0],bool)),[4,1,1,3,0])

    def test_historical_fixture_aggregates_match_individual_objects(self):
        source=json.loads((HERE/'references/known27_maps.json').read_text())
        self.assertFalse(source['activity_labels_included'])
        self.assertEqual(len(source['assemblies']),27)
        self.assertEqual(sum(len(a['objects']) for a in source['assemblies']),927)
        for item in source['assemblies']:
            self.assertNotIn('label',item)
            self.assertNotIn('observed_activity',item)
            for family,field in (('independent_aggregate','scores'),('rawcos_aggregate','rawcos')):
                actual=aggregate(item['objects'],'full',field=field)
                expected=item[family]['full']
                for key,val in actual.items():
                    if isinstance(val,(float,int)) and not isinstance(val,bool):
                        self.assertAlmostEqual(val,expected[key],places=12)
                    else:self.assertEqual(val,expected[key])


def run(allow_missing_torch=False):
    """Return a validation report; leave caller RNG/thread settings unchanged."""
    has_torch=importlib.util.find_spec('torch') is not None
    if not has_torch and not allow_missing_torch:
        raise ValueError('Torch is required; use the Jean Zay PyTorch module before scoring')
    old_threads=old_rng=old_cuda_rng=None
    if has_torch:
        import torch
        old_threads=torch.get_num_threads()
        old_rng=torch.random.get_rng_state()
        if torch.cuda.is_initialized():
            old_cuda_rng=torch.cuda.get_rng_state_all()
    try:
        loader=unittest.defaultTestLoader
        suite=unittest.TestSuite([loader.loadTestsFromModule(map_tests),loader.loadTestsFromTestCase(ExportSemantics)])
        result=unittest.TextTestRunner(verbosity=2).run(suite)
        passed=result.testsRun-len(result.skipped)-len(result.failures)-len(result.errors)
        ok=result.wasSuccessful() and (allow_missing_torch or not result.skipped)
        report=dict(status=('PASS' if not result.skipped else 'LOCAL_ONLY_NUMERICAL_TESTS_PENDING') if ok else 'FAIL',
                    tests_run=result.testsRun,passed=passed,failures=len(result.failures),errors=len(result.errors),
                    skipped=[dict(test=str(t),reason=r) for t,r in result.skipped],torch_available=has_torch,
                    actual_checkpoint_parity='Required separately in run_scoring.gates before library inference')
        if has_torch:
            report['torch_version']=torch.__version__
        if not ok:
            raise AssertionError('Numerical regression tests failed or skipped: '+json.dumps(report,sort_keys=True))
        return report
    finally:
        if has_torch:
            torch.set_num_threads(old_threads)
            torch.random.set_rng_state(old_rng)
            if old_cuda_rng is not None:
                torch.cuda.set_rng_state_all(old_cuda_rng)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group()
    mode.add_argument('--require-torch',action='store_true',help='Default: missing Torch or skipped tests fail')
    mode.add_argument('--allow-missing-torch',action='store_true',help='Local audit only; skipped numerical tests remain explicit')
    parser.add_argument('--report',type=Path)
    args=parser.parse_args()
    report=run(allow_missing_torch=args.allow_missing_torch)
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,sort_keys=True),flush=True)

if __name__=='__main__':main()
