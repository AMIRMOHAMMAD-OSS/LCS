#!/usr/bin/env python3
"""Fixed retrospective known-donor composition transfer; never fit on multis."""
from __future__ import annotations
import argparse
import collections
import csv
import datetime
import hashlib
import importlib.util
import json
import signal
import sys
import time
import traceback
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'core'))
import numpy as np
from scipy.special import expit
import frozen_test as ft
import neural_backend as nb
import runtime as rt

STOP = False
POOLS = {'typed__bode2_only': (0., 0.), 'typed__bode2_bode1_w025': (.25, 0.),
         'typed__bode2_tdomain_w025': (0., .25), 'typed__all3_w025': (.25, .25)}
ARMS = ('raw_mlp', 'ssl10_finetune', 'ssl26_finetune')
SEEDS = (17, 29, 43)


def read(path):
    return json.loads(Path(path).read_text())


def signal_stop(signum, frame):
    global STOP
    STOP = True


def progress(out, stage, **fields):
    item = dict(stage=stage, updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **fields)
    rt.atomic_json(out / 'progress.json', item)
    print(json.dumps(item), flush=True)


def check_budget(deadline):
    if STOP or time.monotonic() >= deadline:
        raise nb.TrainingPaused('Stopped at a completed stage; resume the same output directory')


def pool_indices(rows, alpha, beta):
    enabled = {'bode2'} | ({'bode1'} if alpha > 0 else set()) | ({'tdomain'} if beta > 0 else set())
    return [i for i, r in enumerate(rows) if r['dataset'] in enabled]


def exact_overlap_audit(training_records, test_records):
    train = collections.defaultdict(list)
    test = collections.defaultdict(list)
    for r in training_records:
        train[nb._route_fingerprint(r)].append(r['assembly_id'])
    for r in test_records:
        test[nb._route_fingerprint(r)].append(r['assembly_id'])
    return dict(training_n=len(training_records), test_n=len(test_records),
                train_test_duplicates=[dict(fingerprint=h, training=train[h], test=test[h])
                                       for h in sorted(set(train) & set(test))],
                test_duplicates=[dict(fingerprint=h, ids=v) for h, v in test.items() if len(v) > 1],
                domain_reuse_allowed=True, task='new combinations of known donors, not unseen-donor transfer')


def seal_predictions(out, ids, candidates, maps):
    rt.require(len(ids) == len(set(ids)), 'Duplicate prediction IDs')
    for name, p in candidates.items():
        a = np.asarray(p, dtype=float)
        rt.require(a.shape == (len(ids),) and np.isfinite(a).all() and ((0 <= a) & (a <= 1)).all(),
                   'Invalid candidate probabilities: ' + name)
    for name, values in maps.items():
        a = np.asarray(values, dtype=float)
        rt.require(a.shape == (len(ids),) and np.isfinite(a).all(), 'Incomplete map diagnostic: ' + name)
    payload = dict(assembly_ids=ids, candidates=candidates, map_diagnostics=maps,
                   multi_activity_labels_read=False,
                   probability_interpretation='uncalibrated expected-product detection scores')
    path = out / 'predictions.json'
    if path.exists():
        rt.require(read(path) == payload, 'Completed prediction seal would change on resume')
    else:
        rt.atomic_json(path, payload)
    rt.atomic_json(out / 'prediction_seal.json', dict(predictions_sha256=rt.sha(path),
                   protocol_sha256=rt.sha(HERE / 'PROTOCOL.json'),
                   package_sha256=rt.sha(HERE / 'PACKAGE_MANIFEST.json'),
                   multi_activity_labels_read=False, candidate_names=list(candidates)))
    return payload


def evaluate_predictions(prediction, label_rows):
    ids = prediction['assembly_ids']
    labels = {r['assembly_id']: r for r in label_rows}
    rt.require(len(labels) == len(label_rows) and set(labels) == set(ids), 'Label identity mismatch')
    rows = [labels[k] for k in ids]
    y = np.array([int(r['produced']) for r in rows])
    rt.require(set(y) <= {0, 1}, 'Invalid outcomes')
    table = []
    for cohort in ('doubles', 'triples', 'combined_descriptive'):
        take = np.array([i for i, r in enumerate(rows) if cohort == 'combined_descriptive' or r['dataset'] == cohort])
        rt.require(len(take) > 0, 'Missing evaluation cohort')
        for name, values in prediction['candidates'].items():
            table.append(dict(cohort=cohort, candidate=name, **ft.metrics(y[take], np.asarray(values)[take])))
        for name, values in prediction.get('map_diagnostics', {}).items():
            scores = ft.metrics(y[take], np.asarray(values)[take])
            table.append(dict(cohort=cohort, candidate='map__' + name,
                              **{k: scores[k] for k in ('n', 'positive', 'auroc', 'average_precision',
                                                       'precision_top20_tie_expected', 'top20_n')}))
    return dict(status='RETROSPECTIVE_COMBINATION_COMPARISON_COMPLETE', metrics=table,
                confidence_intervals=None,
                reason_no_row_bootstrap='Constructs share donors; independent-row intervals would be misleading.',
                selection='No automatic winner or calibrated probability claim. Selection using these60 is development.',
                applicability='Designed mature products conditional on successful splicing; known donors only. '
                              'All60 are combinations of successful single exchanges; doubles all fix donor080 '
                              'atXUT4 and triples form one3x3x3library. Not representative of all35^3designs.')


def pack_inspection(out):
    """Results and reproducibility records, excluding large weights/optimizer states."""
    dest = out / 'inspection.zip'
    tmp = out / 'inspection.zip.tmp'
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(out.rglob('*')):
            if (p.is_file() and p.suffix in ('.json', '.csv', '.tsv', '.txt', '.log', '.npz', '.gz')
                    and p.stat().st_size < 25 * 1024 * 1024 and 'abandoned_partial' not in p.parts):
                z.write(p, p.relative_to(out).as_posix())
        for p in sorted(HERE.rglob('*')):
            if p.is_file() and (p.suffix in ('.py', '.json', '.txt', '.sh', '.gz') or p.name == 'README.txt'):
                if p.name not in ('SUBMISSION.json',) and '__pycache__' not in p.parts:
                    z.write(p, 'reproduce/' + p.relative_to(HERE).as_posix())
    tmp.replace(dest)
    print('RESULT_ZIP:', dest, flush=True)
    print('RESULT_SHA256:', rt.sha(dest), flush=True)


def run(root, out, seconds):
    spec = importlib.util.spec_from_file_location('multi_package_integrity', HERE / 'selftest.py')
    integrity = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(integrity)
    integrity.validate_package()
    deadline = time.monotonic() + seconds
    out.mkdir(parents=True, exist_ok=True)
    contract = dict(package_sha256=rt.sha(HERE / 'PACKAGE_MANIFEST.json'), root=str(root))
    if (out / 'RUN_CONTRACT.json').exists():
        rt.require(read(out / 'RUN_CONTRACT.json') == contract, 'Resume contract changed')
    else:
        rt.atomic_json(out / 'RUN_CONTRACT.json', contract)
    records, parents = rt.load_inputs(HERE / 'inputs/known_multis_model_inputs.json.gz')
    ids = [r['assembly_id'] for r in records]
    vectors, feature_report = rt.load_feature_bank(out / 'feature_bank', records, parents)
    rows = read(HERE / 'core/inputs/metadata.json')['rows']
    arrays = np.load(HERE / 'core/inputs/features.npz', allow_pickle=False)
    x = arrays['typed']
    y = np.array([r['observed_activity'] for r in rows])
    progress(out, 'original_runtime_and_exact_overlap')
    original = nb.NeuralRuntime(root, rows, device='cuda', threads=8)
    audit = exact_overlap_audit(original.records, records)
    rt.atomic_json(out / 'exact_input_overlap.json', audit)
    rt.require(not audit['train_test_duplicates'] and not audit['test_duplicates'],
               'Exact complete model-input duplicate found; inspect before interpreting heldout results')
    # Round-trip old records through the new inference adapter, not only a shape test.
    sample = [324, 347, 428]
    parity_records = [original.records[i] for i in sample]
    parity_vectors = {}
    for i in sample:
        rec = original.records[i]
        parity_vectors.update(original.vectors[(rec['dataset'], rec['assembly_id'])])
    adapted = rt.typed_features(root, parity_records, parity_vectors)
    diff = float(np.max(np.abs(adapted - x[sample])))
    rt.atomic_json(out / 'new_adapter_parity.json', dict(indices=sample, max_abs=diff, tolerance=1e-4))
    rt.require(diff <= 1e-4, 'New full-assembly feature adapter disagrees with verified single features')
    check_budget(deadline)
    progress(out, 'complete_multi_features')
    typed = rt.typed_features(root, records, vectors)
    np.savez_compressed(out / 'multi_features.npz', typed=typed, assembly_ids=np.asarray(ids))
    candidates = {}
    (out / 'deployment').mkdir(exist_ok=True)
    for name, (alpha, beta) in POOLS.items():
        check_budget(deadline)
        progress(out, 'frozen_fit', candidate=name)
        indices = pool_indices(rows, alpha, beta)
        model = ft.fit_model(x[indices], y[indices], [rows[i]['dataset'] for i in indices],
                             ft.cohort_weights(rows, indices, alpha, beta), 10.)
        metadata = dict(train_indices=indices, counts=dict(collections.Counter(rows[i]['dataset'] for i in indices)),
                        alpha=alpha, beta=beta, lambda_fixed_from_single_development=10.,
                        multi_outcomes_used=False, task='known-donor combination transfer')
        if name == 'typed__bode2_only':
            reference, reference_meta = ft.load_model(HERE / 'single_results/typed__bode2_only.npz')
            error = float(np.max(np.abs(ft.predict_logits(model, x[indices]) - ft.predict_logits(reference, x[indices]))))
            rt.require(error <= 1e-5, 'Frozen reference refit failed parity')
            metadata['reference_refit_max_logit_abs'] = error
            model = reference
            model.update({k: reference_meta[k] for k in ('iterations', 'gradient_inf')})
        ft.save_model(out / 'deployment' / (name + '.npz'), model, metadata)
        candidates[name] = expit(ft.predict_logits(model, typed)).tolist()
    chemistry_rows = read(HERE / 'inputs/expected_chemistry.json')
    rt.require([r['assembly_id'] for r in chemistry_rows] == ids, 'Chemistry order mismatch')
    chemistry = [r['features'] for r in chemistry_rows]
    model, _ = ft.load_model(HERE / 'single_results/typed_chemistry__bode2_only.npz')
    candidates['typed_chemistry__bode2_only'] = expit(ft.predict_logits(model, ft.FeatureBundle(typed, chemistry))).tolist()
    known_names = set(model['chemistry_feature_names'])
    rt.atomic_json(out / 'chemistry_coverage.json', dict(
        interpretation='Expected donor-annotation amino acids only; unseen pair terms receive zero learned coefficient.',
        unseen_by_construct={aid: sorted(set(c) - known_names) for aid, c in zip(ids, chemistry)}))
    all_target = pool_indices(rows, 0, 0)
    split = read(HERE / 'single_results/typed__bode2_only.json')['inner_splits'][0]
    train, val = split['train_indices'], split['test_indices']
    rt.require(not set(train) & set(val) and set(train) | set(val) == set(all_target), 'Bad final-fit inner split')
    checkpoints = {}
    for arm in ARMS:
        checkpoints[arm] = []
        for seed in SEEDS:
            check_budget(deadline)
            work = out / 'neural' / arm / ('seed' + str(seed))
            work.mkdir(parents=True, exist_ok=True)
            complete = work / 'complete.json'
            if complete.exists():
                fit = read(complete)
                rt.require(rt.sha(work / 'checkpoint.pt') == fit['checkpoint_sha256'], 'Saved fit checksum changed')
            else:
                progress(out, 'neural_select_epoch', arm=arm, seed=seed)
                selection = nb.fit_select(original, arm, train, val, y, ft.cohort_weights(rows, train), seed,
                    work_dir=work / 'select', deadline_monotonic=deadline, stop_requested=lambda: STOP)
                rt.atomic_json(work / 'epoch_selection.json', selection)
                check_budget(deadline)
                progress(out, 'neural_full_single_refit', arm=arm, seed=seed, epoch=selection['selected_epoch'])
                fit = nb.refit_predict(original, arm, all_target, y, ft.cohort_weights(rows, all_target), seed,
                    selection['selected_epoch'], [], work / 'checkpoint.pt', work_dir=work / 'refit',
                    deadline_monotonic=deadline, stop_requested=lambda: STOP)
                rt.atomic_json(complete, fit)
            checkpoints[arm].append(dict(path=str(work / 'checkpoint.pt'), sha256=fit['checkpoint_sha256']))
        inference = rt.saved_classifier_predictions(checkpoints[arm], records, vectors)
        rt.atomic_json(out / (arm + '_inference.json'), inference)
        candidates[arm + '__bode2_only'] = inference['probability']
    for arm in ('ssl10_finetune', 'ssl26_finetune'):
        candidates['blend50_typed_' + arm] = (.5 * np.asarray(candidates['typed__bode2_only']) +
                                             .5 * np.asarray(candidates[arm + '__bode2_only'])).tolist()
    check_budget(deadline)
    progress(out, 'frozen_physical_object_maps')
    import multi_maps
    map_result = multi_maps.run(root, records, parents, vectors, out / 'maps',
                               deadline_monotonic=deadline, stop_requested=lambda: STOP)
    # This adapter key is defined by multi_maps; map values are never treated as activity probabilities.
    maps = map_result['diagnostic_scores']
    prediction = seal_predictions(out, ids, candidates, maps)
    progress(out, 'PREDICTIONS_SEALED', candidates=len(candidates))
    # The only multi-outcome access in the fit/inference/evaluation pipeline occurs after this seal.
    evaluation = evaluate_predictions(prediction, read(HERE / 'inputs/known_multis_labels.json'))
    rt.atomic_json(out / 'evaluation.json', evaluation)
    fields = sorted({k for r in evaluation['metrics'] for k in r})
    with (out / 'comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader(); writer.writerows(evaluation['metrics'])
    rt.atomic_json(out / 'deployment_candidates.json', dict(checkpoints=checkpoints,
                   frozen_models=list(POOLS), compatibility_map=map_result['contract'],
                   note='No multi outcomes used for fitting. Do not interpret fit metrics as a new prospective test.'))
    rt.atomic_json(out / 'COMPLETE.json', dict(status=evaluation['status'], n_multis=len(ids),
                   prediction_sha256=rt.sha(out / 'predictions.json'), protocol_sha256=rt.sha(HERE / 'PROTOCOL.json'),
                   model_selection='Await scientific comparison; no automatic promotion'))
    progress(out, 'COMPLETE', status=evaluation['status'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--seconds', type=int, default=6000)
    args = parser.parse_args()
    signal.signal(signal.SIGUSR1, signal_stop)
    signal.signal(signal.SIGTERM, signal_stop)
    out = args.out.resolve(); out.mkdir(parents=True, exist_ok=True)
    try:
        run(args.root.resolve(), out, args.seconds)
    except nb.TrainingPaused as exc:
        rt.atomic_json(out / 'PAUSED.json', dict(reason=str(exc), resume='python3 submit.py resume'))
        progress(out, 'PAUSED', reason=str(exc))
    except Exception as exc:
        rt.atomic_json(out / 'fatal_error.json', dict(error=str(exc), traceback=traceback.format_exc()))
        raise
    finally:
        pack_inspection(out)


if __name__ == '__main__':
    main()
