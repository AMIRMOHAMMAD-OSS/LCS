"""CPU contract tests; Torch tests are mandatory on the Jean Zay run.

Local absence of Torch is reported as a skip, never represented as GPU parity.
Use --require-torch to fail if numerical tensor tests cannot run.
"""
import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import sqlite3

import numpy as np
import runtime as rt


def fixture():
    seq = "ACDEFGHIKLMNPQRSTVWY"
    ph = rt.seqsha(seq)
    route, slots = [], []
    for j, (kind, a, b) in enumerate(((0, 0, 5), (1, 3, 12), (0, 10, 20))):
        h = rt.seqsha(seq[a:b])
        route.append(dict(kind=kind, domain_type=1 if kind == 0 else 0, chain=1, seq_hash=h,
                          protein_uid="chain1", start_aa_0based=a, end_aa_0based_exclusive=b))
        slots.append(dict(object_index=j, slot=0, kind=kind, state="OBSERVED", protein_uid="chain1",
                          parent_sequence_hash=ph, start=a, end=b, length=b-a, sequence_hash=h))
    r = dict(assembly_id="toy", boundary_window_policy="physical_end_extradomain_tail64_v1", route=route,
             model_slots=slots, parent_sequence_hashes={"chain1": ph}, parent_lengths={"chain1": len(seq)})
    return [r], {ph: seq}


class Contracts(unittest.TestCase):
    def test_valid_physical_slots(self):
        records, parents = fixture()
        self.assertEqual(len(rt.validate_records(records, parents)), 3)

    def test_labels_rejected(self):
        records, parents = fixture()
        records[0]["observed_activity"] = 1
        with self.assertRaisesRegex(ValueError, "labels"):
            rt.validate_records(records, parents)

    def test_nested_labels_rejected(self):
        records, parents = fixture()
        records[0]["route"][0]["source_domain"] = {"label": 0}
        with self.assertRaises(ValueError):
            rt.validate_records(records, parents)

    def test_parent_mutation_rejected(self):
        records, parents = fixture()
        key = next(iter(parents))
        parents[key] = "A" + parents[key][1:-1] + "A"
        with self.assertRaisesRegex(ValueError, "Parent"):
            rt.validate_records(records, parents)

    def test_missing_and_duplicate_slots_rejected(self):
        records, parents = fixture()
        for slots in (records[0]["model_slots"][:-1], records[0]["model_slots"] * 2):
            r = copy.deepcopy(records)
            r[0]["model_slots"] = slots
            with self.assertRaises(ValueError):
                rt.validate_records(r, parents)

    def test_physical_coordinate_mutation_rejected(self):
        records, parents = fixture()
        records[0]["model_slots"][0]["start"] = 1
        with self.assertRaises(ValueError):
            rt.validate_records(records, parents)

    def test_domain_slot_disagreement_rejected(self):
        records, parents = fixture()
        records[0]["route"][0]["start_aa_0based"] = 1
        with self.assertRaises(ValueError):
            rt.validate_records(records, parents)

    def test_masked_slot_rejected(self):
        records, parents = fixture()
        records[0]["model_slots"][0]["state"] = "MASKED"
        with self.assertRaises(ValueError):
            rt.validate_records(records, parents)

    def test_typed_readout_formula_and_zero_break_group(self):
        hidden = np.stack([np.full(256, 2.), np.full(256, 3.), np.full(256, 5.)])
        route = fixture()[0][0]["route"]
        actual = rt.typed_pool(hidden, route)
        expected_connection = np.concatenate([hidden[0], hidden[1], hidden[2], hidden[0]*hidden[2], abs(hidden[0]-hidden[2])])
        expected = np.concatenate([np.full(256, 3.5), expected_connection, np.zeros(1280),
                                   [np.log(3), 1, np.log(2), 1, 0, 0]])
        self.assertEqual(actual.shape, (2822,))
        np.testing.assert_allclose(actual, expected, atol=1e-15, rtol=0)

    def test_break_feature_group(self):
        hidden = np.arange(3*256).reshape(3, 256)
        route = fixture()[0][0]["route"]
        route[1]["kind"] = 2
        actual = rt.typed_pool(hidden, route)
        self.assertTrue((actual[256:1536] == 0).all())
        np.testing.assert_allclose(actual[-6:], [np.log(3), 1, 0, 0, np.log(2), 1])

    def test_saved_bank_integrity(self):
        records, parents = fixture()
        sequences = rt.validate_records(records, parents)
        with tempfile.TemporaryDirectory() as name:
            path = Path(name)
            np.savez(path / "feature_bank.npz", hashes=np.array(sorted(sequences)), vectors=np.ones((3, 1152), dtype="f4"))
            report = dict(feature_bank_sha256=rt.sha(path / "feature_bank.npz"), structural_sha256=rt.digest(records), parents_sha256=rt.digest(parents))
            rt.atomic_json(path / "feature_bank.json", report)
            vectors, loaded = rt.load_feature_bank(path, records, parents)
            self.assertEqual(set(vectors), set(sequences))
            with (path / "feature_bank.npz").open("ab") as f:
                f.write(b"tamper")
            with self.assertRaisesRegex(ValueError, "checksum"):
                rt.load_feature_bank(path, records, parents)

    def test_vendored_embedding_source(self):
        self.assertEqual(rt.sha(rt.HERE / "vendor_embed/embedding_backend.py"), rt.EMBED_BACKEND_SHA)

    def test_only_missing_hashes_go_to_embedding_backend(self):
        records, parents = fixture()
        sequences = rt.validate_records(records, parents)
        known = sorted(sequences)[0]
        invoked = []
        def fake_backend(root, out, rows, references, progress=None):
            invoked.extend(rows)
            np.full((len(rows), 1152), 3, dtype="<f4").tofile(out / "features.f32")
            with sqlite3.connect(out / "feature_index.sqlite3") as db:
                db.execute("CREATE TABLE features(hash TEXT PRIMARY KEY, feature_row INT, status TEXT)")
                db.executemany("INSERT INTO features VALUES(?,?,?)", [(h, i, "covered") for i, (h, _) in enumerate(rows)])
            return {"test_backend": True}
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            cache = root / rt.CACHE
            cache.mkdir()
            np.full((1, 1152), 2, dtype="<f4").tofile(cache / "features.f32")
            with sqlite3.connect(cache / "feature_index.sqlite3") as db:
                db.execute("CREATE TABLE features(hash TEXT PRIMARY KEY, feature_row INT, status TEXT)")
                db.execute("INSERT INTO features VALUES(?,?,?)", (known, 0, "covered"))
            pins = {name: rt.sha(cache / name) for name in rt.CACHE_SHA}
            with patch.object(rt, "CACHE_ROWS", 1), patch.object(rt, "CACHE_SHA", pins), \
                    patch("vendor_embed.embedding_backend.run_backend", fake_backend):
                vectors, report = rt.prepare_feature_bank(root, records, parents, root / "bank", references=[])
            self.assertEqual({h for h, _ in invoked}, set(sequences) - {known})
            self.assertEqual((report["reused_count"], report["new_count"]), (1, 2))
            self.assertTrue((vectors[known] == 2).all())
            self.assertTrue(all((vectors[h] == 3).all() for h in set(sequences) - {known}))
            loaded, _ = rt.load_feature_bank(root / "bank", records, parents)
            self.assertEqual(set(loaded), set(sequences))

    def test_actual_known_sixty_if_packaged(self):
        path = rt.HERE / "inputs/known_multis_model_inputs.json.gz"
        if not path.exists():
            self.skipTest("Final input bundle not yet assembled")
        records, parents = rt.load_inputs(path)
        self.assertEqual((len(records), len(parents), len(rt.validate_records(records, parents))), (60, 63, 239))


TORCH = importlib.util.find_spec("torch") is not None


@unittest.skipUnless(TORCH, "Torch unavailable locally; Jean Zay numerical tests required")
class TensorContracts(unittest.TestCase):
    def test_clean_batch_and_global770(self):
        import torch
        from neural_backend import pool_objects
        records, parents = fixture()
        vectors = {h: np.ones(1152, dtype="f4") for h in rt.validate_records(records, parents)}
        batch = rt.contexts_to_batch(records, vectors, "cpu")
        self.assertEqual(set(batch), {"x", "state", "kind", "domain_type", "chain", "valid"})
        self.assertEqual(tuple(batch["x"].shape), (1, 3, 3, 1152))
        h = torch.arange(3*256, dtype=torch.float32).reshape(1, 3, 256)
        pooled = pool_objects(h, batch)
        self.assertEqual(tuple(pooled.shape), (1, 770))
        torch.testing.assert_close(pooled[0, :256], (h[0, 0]+h[0, 2])/2)
        torch.testing.assert_close(pooled[0, 256:512], h[0, 1])

    def test_model_batch_padding_invariance(self):
        import torch
        from vendor_neural.assembly_model import AssemblyEncoder, Config
        torch.manual_seed(123)
        records, parents = fixture()
        vectors = {h: np.ones(1152, dtype="f4") for h in rt.validate_records(records, parents)}
        shorter = copy.deepcopy(records[0]); shorter["assembly_id"] = "short"
        shorter["route"] = shorter["route"][:1]; shorter["model_slots"] = shorter["model_slots"][:1]
        model = AssemblyEncoder(Config(local_layers=1, global_layers=1)).eval()
        with torch.no_grad():
            single = model.features(rt.contexts_to_batch([shorter], vectors, "cpu"))[0, :1]
            joint = model.features(rt.contexts_to_batch([shorter, records[0]], vectors, "cpu"))[0, :1]
        torch.testing.assert_close(single, joint, atol=2e-5, rtol=2e-5)


if __name__ == "__main__":
    if "--require-torch" in sys.argv:
        sys.argv.remove("--require-torch")
        if not TORCH:
            raise SystemExit("Torch is required for the Jean Zay numerical gate")
    unittest.main()
