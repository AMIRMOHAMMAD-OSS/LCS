NeurALPS Patrick: complete-combination test, 2026-11-03

Purpose
-------
Compare complete mature BODE2 double/triple inputs using models trained on the
105 single exchanges, with optional frozen-model augmentation from BODE1 and
T-domain data. This package is the next stage, not a replacement for the
completed single-exchange experiment. Read RESULTS_REVIEW.txt for that result.

This is retrospective testing of combinations of known donors. All 60 designs
use individually active single-exchange constituents. The 33 doubles share
donor080 at XUT4; the 27 triples form a 3x3x3 library. Results cannot establish
accuracy across all 35^3 candidate designs or on unseen donors. A model chosen
using these 60 needs subsequent prospective confirmation.

The reconstructed sequences are design-implied mature exteins, conditional on
successful intein splicing. They do not model splicing efficiency, expression,
or independently establish the experimental mature product sequences.

Contents and comparisons
------------------------
* Complete inputs for 33 doubles and 27 triples. Annotated LNR|SAV and NPC|SEI
  splice boundaries reproduce all 105 singles plus native exactly. Internal
  physical protein-chain breaks are retained.
* Frozen SSL26 typed2822 logistic heads: BODE2 only, +BODE1, +T-domain, all3.
  Each optional source has total weight 0.25 relative to BODE2 weight 1.0.
  These are normalized study means, not per-row weights. Lambda10 is fixed
  from single-exchange development; study intercepts are separate.
* Existing BODE2 typed+expected-amino-acid head, unchanged. Novel pair-feature
  categories receive no learned coefficient and are explicitly reported.
* Raw ESM-C pooled MLP, SSL10 fine-tuning, SSL26 fine-tuning: each fits all105
  singles after epoch selection on the first recorded donor-group inner split,
  using seeds17/29/43 and averaging probabilities. No multi outcomes in fits.
* Two fixed equal-weight blends: typed plus SSL10; typed plus SSL26.
* Frozen natural SSL26 full-path physical-object maps on all60. Overlap and
  exact aliases are masked with the target. Protein-break roles are masked
  together and averaged once. Map scores remain reconstruction diagnostics.

No labels from these60 enter fitting, epoch selection, embedding, maps, or
inference. All predictions are saved and sealed before evaluation. This is a
computational separation, not a claim that these historical outcomes were
previously unknown to the investigators. Exact complete-input duplicates with
any of494 original training records cause a stop. Reusing domains is deliberate
for this known-donor composition task; it was excluded in the previous
unseen-donor test.

Run on Jean Zay
---------------
Place NeurALPS_Patrick_Multi_Test_20261103.zip in:
/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/

cd /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2
unzip -n NeurALPS_Patrick_Multi_Test_20261103.zip
python3 -B NeurALPS_Patrick_Multi_Test_20261103/selftest.py
python3 -B NeurALPS_Patrick_Multi_Test_20261103/submit.py run

The self-test and submission preflight are lightweight on the login node.
Numerical tests, cache verification, missing-vector extraction and model work
run inside one A100 allocation: 8CPUs, 2-hour maximum. No new downloads or
environment installations. Historical ESM-C extraction runs in its own existing
environment; classifier fitting uses the recorded PyTorch2.8 module.

Status:
python3 -B NeurALPS_Patrick_Multi_Test_20261103/submit.py status

If PAUSED rather than failed, resume the same saved states:
python3 -B NeurALPS_Patrick_Multi_Test_20261103/submit.py resume

Do not edit a failed package or bypass a checksum/parity failure. Return its
status/log or inspection.zip for diagnosis. Existing project assets and prior
run outputs are opened read-only. The new run writes only its own output
directory and its submission receipt. Repeated run commands do not duplicate
an existing submission.

Outputs
-------
New output: neuralps_patrick_multi_<UTC>_<packagehash>/
  comparison.csv            Separate double/triple metrics plus descriptive60
  predictions.json          Every candidate and map diagnostic, before labels
  prediction_seal.json      Hashes and label-separation record
  exact_input_overlap.json  Full494-to60 exact-input overlap check
  new_adapter_parity.json   New adapter checked on3 verified original singles
  chemistry_coverage.json   Unseen categorical pair terms
  maps/maps.json.gz         Every physical object, masks, score, coverage
  deployment/               Frozen source-pool heads
  neural/                   Fitted seed checkpoints and resumable optimizer state
  inspection.zip            Review bundle, excluding large neural weights/states

Keep all weights on Jean Zay. Transfer only inspection.zip back via the Mac:
scp -J apandi@gate.lcqb.hosted.lip6.fr \
  unh87ms@jean-zay.idris.fr:<printed_output_path>/inspection.zip \
  /Users/amir/Desktop/NeurALPS_Patrick_Multi_results.zip

Then upload the ZIP to LCS neuralps/results, using the established skip-LFS
checkout. Return the commit and SHA256. The runner reports descriptive results;
it does not automatically declare a prospective winner or train on these60.

Validation scope
----------------
The original package is included unchanged under core/. Its45 numerical tests
already passed on Jean Zay. New local CPU checks cover input reconstruction,
pool weights, exact frozen-head refit, save/load, label-sealed evaluation,
cache reuse, map masking/aggregation and resumption. New tensor tests cannot
run in this local environment and are mandatory in the GPU job before fitting.

The exact manifest, protocol and source hashes are included. Read
LOCAL_VALIDATION.json for measured local test results, and PROTOCOL.json for
the complete fixed comparison. Reusable composition source and registry are
included, but this allocation does not score all42875 possible combinations.
