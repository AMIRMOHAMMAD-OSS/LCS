"""Contract tests and mandatory-on-Jean-Zay tensor regression tests for maps."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import numpy as np
import multi_maps as maps
import runtime


def inputs():
    return runtime.load_inputs(Path(__file__).parent / "inputs/known_multis_model_inputs.json.gz")


class FakeScorer:
    def score_plans(self, record, parents, vectors, plans, modes, microbatch):
        assert modes == ("full",)
        result = {}
        for name, plan in plans.items():
            assert len(plan["targets"]) == 1
            j = plan["targets"][0]
            result[name] = dict(plan, status="SCORED", objects={str(j): {"full": j / 100}},
                                objects_rawcos={str(j): {"full": .9}})
        return result


class Contracts(unittest.TestCase):
    def test_every_known_object_has_valid_single_target_plan(self):
        records, parents = inputs()
        for record in records:
            for j, obj in enumerate(record["route"]):
                plan = maps.make_plan(record, [j], parents)
                self.assertEqual(plan["status"], "READY")
                self.assertEqual(plan["targets"], [j])
                self.assertTrue(set(map(tuple, plan["primary"])) <= set(map(tuple, plan["hidden"])))
                self.assertEqual(len(plan["primary"]), 2 if obj["kind"] == 2 else 1)

    def test_break_counts_once_and_full_only_aggregation(self):
        records, parents = inputs()
        record = next(r for r in records if any(o["kind"] == 2 for o in r["route"]))
        result = maps.score_assembly(FakeScorer(), record, parents, {}, microbatch=2)
        self.assertEqual(len(result["objects"]), len(record["route"]))
        agg = result["independent_aggregate"]["full"]
        domains = [j / 100 for j, o in enumerate(record["route"]) if o["kind"] == 0]
        boundaries = [j / 100 for j, o in enumerate(record["route"]) if o["kind"] != 0]
        self.assertAlmostEqual(agg["balanced_mean"], .5 * (np.mean(domains) + np.mean(boundaries)))
        self.assertAlmostEqual(agg["balanced_q25"], .5 * (np.quantile(domains, .25) + np.quantile(boundaries, .25)))

    def test_incomplete_coverage_has_no_aggregate(self):
        records, parents = inputs()
        result = maps.score_assembly(FakeScorer(), records[0], parents, {})
        result["objects"][0]["status"] = "INSUFFICIENT_VISIBLE_CONTEXT"
        agg = maps.aggregate(result["objects"], "full")
        self.assertFalse(agg["complete"])
        self.assertIsNone(agg["balanced_mean"])
        self.assertIsNone(agg["balanced_q25"])

    def test_saved_result_tamper_and_route_change_rejected(self):
        records, parents = inputs(); record = records[0]
        result = maps.score_assembly(FakeScorer(), record, parents, {})
        with tempfile.TemporaryDirectory() as name:
            path = Path(name) / "map.json"
            maps.write_json(path, dict(run_identity="id", result_sha256=maps.digest(result), result=result))
            self.assertEqual(maps._saved(path, "id", record), json.loads(json.dumps(result)))
            changed = copy.deepcopy(record); changed["assembly_id"] = "changed"
            with self.assertRaises(ValueError): maps._saved(path, "id", changed)
            result["objects"][0]["scores"]["full"] = .123456
            maps.write_json(path, dict(run_identity="id", result_sha256="incorrect", result=result))
            with self.assertRaises(ValueError): maps._saved(path, "id", record)

    def test_deadline_raises_resumable_pause(self):
        from neural_backend import TrainingPaused
        with self.assertRaises(TrainingPaused): maps._pause(time.monotonic() - 1, None)
        with self.assertRaises(TrainingPaused): maps._pause(None, lambda: True)
        maps._pause(None, lambda: False)

    def test_feature_digest_deterministic_and_sensitive(self):
        a = {"a": np.zeros(1152, dtype="f4"), "b": np.ones(1152, dtype="f4")}
        self.assertEqual(maps.vector_digest(a), maps.vector_digest(dict(reversed(list(a.items())))))
        b = copy.deepcopy(a); b["a"][0] = 1
        self.assertNotEqual(maps.vector_digest(a), maps.vector_digest(b))

    def test_complete_run_resume_reuses_sealed_constructs(self):
        records, parents = inputs(); records = records[:2]
        hashes = runtime.validate_records(records, parents)
        vectors = {h: np.ones(1152, dtype="f4") for h in hashes}
        scorer = FakeScorer()
        from vendor_map import score_all_parts
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            pins = {}
            for relative in list(maps.PINNED) + ["e1_ssl_targets_497189/manifest.json"]:
                path = root / relative; path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text("test fixture")
                if relative in maps.PINNED: pins[relative] = maps.sha(path)
            with patch.object(maps, "PINNED", pins), patch.object(score_all_parts, "load_runtime", return_value=(scorer, {})):
                first = maps.run(root, records, parents, vectors, root / "out", device="cpu")
                with patch.object(scorer, "score_plans", side_effect=AssertionError("Resume unexpectedly rescored")):
                    second = maps.run(root, records, parents, vectors, root / "out", device="cpu")
            self.assertEqual(first["diagnostic_scores"], second["diagnostic_scores"])
            self.assertEqual(second["summary"]["assemblies"], 2)
            self.assertFalse(second["summary"]["labels_read"])
            self.assertEqual(set(second["diagnostic_scores"]), {"full_balanced_mean", "full_balanced_q25"})


@unittest.skipUnless(importlib.util.find_spec("torch"), "Torch unavailable locally; mandatory on Jean Zay")
class Numerical(unittest.TestCase):
    def test_raw_centered_role_average_and_fallback(self):
        import torch
        from vendor_map.neuralps.scoring import reconstruction_agreement
        p = torch.tensor([[1., 2., 3.], [0., 3., 1.]])
        t = torch.tensor([[2., 1., 0.], [0., 1., 1.]])
        m = torch.tensor([[.1, .3, .5], [0., 1., 1.]])
        expected = []
        for pp, tt, mm in zip(p.numpy(), t.numpy(), m.numpy()):
            cos = lambda x, y: np.dot(x, y) / max(np.linalg.norm(x) * np.linalg.norm(y), 1e-12)
            raw = cos(pp, tt)
            expected.append(raw if np.linalg.norm(tt - mm) <= 1e-6 else .25 * raw + .75 * cos(pp-mm, tt-mm))
        self.assertAlmostEqual(float(reconstruction_agreement(p, t, m)), float(np.mean(expected)), places=6)

    def test_full_path_microbatch_invariance(self):
        import torch
        from vendor_map.neuralps.scoring import Runtime
        from vendor_map.neuralps.assembly_model import AssemblyEncoder, Config, collate_records
        torch.set_num_threads(1); torch.manual_seed(812)
        records, parents = inputs()
        record = next(r for r in records if any(o["kind"] == 2 for o in r["route"]))
        rt = Runtime.__new__(Runtime)
        rt.model = AssemblyEncoder(Config(width=8, heads=2, local_layers=1, global_layers=1, dropout=0.)).eval().requires_grad_(False)
        rt.device = "cpu"; rt.collate = collate_records
        rt.means = {"zero": np.zeros(1152, dtype="f4")}
        rt.mean_map = {k: ["zero", 100] for k in ["D", "C", "B:cterm", "B:nterm"]}
        hashes = {s["sequence_hash"] for s in record["model_slots"] if s["state"] == "OBSERVED"}
        rng = np.random.default_rng(9)
        vectors = {h: rng.normal(size=1152).astype("f4") for h in sorted(hashes)}
        a = maps.score_assembly(rt, record, parents, vectors, 1)
        b = maps.score_assembly(rt, record, parents, vectors, 8)
        self.assertTrue(a["independent_aggregate"]["full"]["complete"])
        np.testing.assert_allclose([o["scores"]["full"] for o in a["objects"]],
                                   [o["scores"]["full"] for o in b["objects"]], atol=1e-5, rtol=0)


if __name__ == "__main__":
    require_torch = "--require-torch" in sys.argv
    if require_torch:
        sys.argv.remove("--require-torch")
        if importlib.util.find_spec("torch") is None:
            raise SystemExit("Torch is required for Jean Zay map tests")
    unittest.main()
