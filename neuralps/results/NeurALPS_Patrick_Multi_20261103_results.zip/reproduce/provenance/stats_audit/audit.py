"""Independent arithmetic and membership audit of Patrick run's saved predictions.
No original evaluation functions are imported and no neural model is rerun.
"""
from pathlib import Path
import collections,hashlib,json
import numpy as np

ROOT=Path(__file__).resolve().parent.parent/'extracted'
OUT=Path(__file__).resolve().parent
def read(p):return json.loads((ROOT/p).read_text())
rows=read('reproduce/inputs/metadata.json')['rows']
ids=[i for i,r in enumerate(rows) if r['dataset']=='bode2']
lookup={i:j for j,i in enumerate(ids)}
y=np.array([rows[i]['observed_activity'] for i in ids])
positions=np.array([rows[i]['metadata']['position'] for i in ids])
groups=np.array([rows[i]['group'] for i in ids])
splits=read('frozen/outer_splits.json')
folds=np.empty(len(ids),dtype=object)
for f in splits:
 for i in f['test_indices']:folds[lookup[i]]=f['fold']
assert len(ids)==105 and y.sum()==63 and len(set(groups))==35
pred={}
for r in read('frozen/heldout_predictions.json'):
 assert r['assembly_id']==rows[r['index']]['assembly_id']
 assert r['label']==rows[r['index']]['observed_activity']
 k=r['feature_arm']+'__'+r['procedure']
 pred.setdefault(k,np.full(105,np.nan))[lookup[r['index']]]=r['probability']
seed_logits=collections.defaultdict(lambda:collections.defaultdict(lambda:np.full(105,np.nan)))
epoch={};weights={};seed_mean_max_error=0.
for f in splits:
 d=read('neural/'+f['fold']+'/predictions.json')
 assert d['test_indices']==f['test_indices']
 jj=[lookup[i] for i in d['test_indices']]
 for k,r in d['models'].items():
  pp=[]
  for s in r['seed_results']:
   z=np.asarray(s['logits']);pp.append(1/(1+np.exp(-z)))
   seed_logits[k][s['seed']][jj]=z
   epoch.setdefault(k,[]).append({'fold':f['fold'],'seed':s['seed'],'selected_epoch':s['selected_epoch']})
  err=float(np.max(np.abs(np.mean(pp,axis=0)-r['probability'])))
  seed_mean_max_error=max(seed_mean_max_error,err)
  pred.setdefault(k,np.full(105,np.nan))[jj]=r['probability']
  weights.setdefault(k,{})[f['fold']]=r['selected_source_weights']
for proc in ['bode2_only','inner_selected_pool']:
 for arm in ['ssl10_finetune','ssl26_finetune']:
  pred['blend__typed__'+arm+'__'+proc]=.5*(pred['typed__'+proc]+pred[arm+'__'+proc])
assert all(np.isfinite(p).all() for p in pred.values())

def auc(y,p):
 a=p[y==1];b=p[y==0]
 return None if not len(a) or not len(b) else float(np.mean((a[:,None]>b)+.5*(a[:,None]==b)))
def ap(y,p):
 if not y.sum():return 0.
 ix=np.argsort(-p,kind='stable');ys=y[ix];ps=p[ix];total=0.;npos=0;seen=0
 for score in np.unique(ps)[::-1]:
  take=ps==score;npos+=ys[take].sum();seen+=take.sum()
  total+=ys[take].sum()/y.sum()*npos/seen
 return float(total)
def loss(y,p):
 q=np.clip(p,1e-12,1-1e-12)
 return -y*np.log(q)-(1-y)*np.log1p(-q)
def metrics(p):
 cells={};positionmeans={}
 for pos in sorted(set(positions)):
  vals=[]
  for fold in sorted(set(folds)):
   take=(positions==pos)&(folds==fold);v=auc(y[take],p[take]);cells[pos+'__'+fold]=v
   if v is not None:vals.append(v)
  positionmeans[pos]={'auroc':float(np.mean(vals)),'defined':len(vals),'total':5}
 return dict(auroc=auc(y,p),average_precision=ap(y,p),log_loss=float(loss(y,p).mean()),
             brier=float(np.mean((p-y)**2)),same_fold_position_macro_auroc=float(np.mean([v['auroc']for v in positionmeans.values()])),
             conditional_cells=cells,conditional_positions=positionmeans)
summary={k:metrics(p)for k,p in pred.items()}
reported=read('comparison.json');max_error=0.
for k,m in summary.items():
 for met in ['auroc','average_precision','log_loss','brier','same_fold_position_macro_auroc']:
  max_error=max(max_error,abs(m[met]-reported[k][met]));assert abs(m[met]-reported[k][met])<1e-12,(k,met)
donors=sorted(set(groups));rng=np.random.default_rng(20261103)
draws=rng.integers(0,35,size=(2000,35));base=pred['typed__bode2_only'];intervals={};ci_error=0.
prior=read('paired_differences.json')
for k,p in pred.items():
 intervals[k]={}
 for met,d in [('log_loss',loss(y,p)-loss(y,base)),('brier',(p-y)**2-(base-y)**2)]:
  groupmeans=np.array([d[groups==g].mean()for g in donors]);boot=groupmeans[draws].mean(axis=1)
  interval=np.quantile(boot,[.025,.975]);saved=np.array(prior[k]['contrasts'][met]['ci95'])
  ci_error=max(ci_error,float(np.abs(interval-saved).max()));assert np.allclose(interval,saved,rtol=0,atol=1e-12)
  intervals[k][met]={'difference':float(d.mean()),'ci95':interval.tolist()}
neural_contracts=[]
for f in splits:
 test=set(f['test_indices'])
 for path in sorted((ROOT/'neural'/f['fold']).glob('*/seed*/*/contract.json')):
  d=json.loads(path.read_text());tr=d['train_indices'];va=d['validation_indices']
  assert not set(tr)&test and not set(va)&test and not set(tr)&set(va)
  assert d['train_labels']==[float(rows[i]['observed_activity'])for i in tr]
  assert d['validation_labels']==[float(rows[i]['observed_activity'])for i in va]
  assert len(d['train_weights'])==len(tr)
  neural_contracts.append({'path':str(path.relative_to(ROOT)),'train_size':len(tr),'validation_size':len(va),
    'cohorts':dict(collections.Counter(rows[i]['dataset']for i in tr))})
assert len(neural_contracts)==180
assert all('tdomain' not in x['cohorts']for x in neural_contracts)
seed_summary={}
for name,sd in seed_logits.items():
 seed_summary[name]={str(seed):metrics(1/(1+np.exp(-zz))) for seed,zz in sd.items()}
pool_folds={}
for f in splits:
 d=read('frozen/folds/typed__'+f['fold']+'.json')
 pool_folds[f['fold']]={'selected':d['procedures']['inner_selected_pool']['selected'],
   'unavailable':[t for t in d['inner_trials']if not t.get('available',True)]}
pool_differences={}
for arm in ['raw_mlp','ssl10_finetune','ssl26_finetune']:
 p=pred[arm+'__inner_selected_pool'];q=pred[arm+'__bode2_only'];pool_differences[arm]={}
 for fold in sorted(set(folds)):
  take=folds==fold;pool_differences[arm][fold]={'max_probability_difference':float(np.abs(p[take]-q[take]).max()),
    'bode2_only_log_loss':float(loss(y[take],q[take]).mean()),'inner_selected_pool_log_loss':float(loss(y[take],p[take]).mean())}
result={'status':'INDEPENDENT_ARITHMETIC_AND_MEMBERSHIP_PASS','candidate_count':len(summary),
 'n':105,'donors':35,'max_metric_difference':max_error,'max_ci_endpoint_difference':ci_error,
 'max_seed_probability_mean_difference':seed_mean_max_error,'neural_contract_count':len(neural_contracts),
 'all_outer_test_labels_excluded_from_fits':True,'all_contract_training_labels_match_corrected_table':True,
 'tdomain_used_in_neural_training':False,'metrics':summary,'paired_intervals':intervals,
 'source_weights_by_fold':pool_folds,'pool_vs_bode2_by_fold':pool_differences,
 'neural_selected_epochs':epoch,'seed_metrics':seed_summary,'neural_contracts':neural_contracts,
 'limitations':['Saved prediction arithmetic and recorded membership verified; GPU execution not independently rerun.',
 'Paired intervals condition on fixed OOF predictions and omit refitting and model-selection uncertainty.',
 'Five-fold same-position macro AUROC has only3/5 defined Termination cells; all candidates share the same cells.',
 'Every Tdomain source trial unavailable under strict pIG064 purge, so this run does not estimate Tdomain/allthree augmentation benefit.',
 'All source augmentation occurs in outerfold03; other fourfolds neural pooled/B2 predictions are identical.']}
(OUT/'independent_stats_audit.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:result[k]for k in ['status','candidate_count','n','donors','max_metric_difference','max_ci_endpoint_difference','max_seed_probability_mean_difference','neural_contract_count']},indent=2))
