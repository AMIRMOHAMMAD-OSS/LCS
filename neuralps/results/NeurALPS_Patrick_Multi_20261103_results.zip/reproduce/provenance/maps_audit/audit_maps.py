"""Independent arithmetic, masking and hash audit; no checkpoint inference."""
from pathlib import Path
import collections, csv, gzip, hashlib, json
import numpy as np

ROOT=Path(__file__).resolve().parents[1]/'extracted'
OUT=Path(__file__).resolve().parent
def load(p): return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with gzip.open(ROOT/'maps/maps.json.gz','rt') as f:maps=json.load(f)
with gzip.open(ROOT/'bode2_structural_handoff.json.gz','rt') as f:struct=json.load(f)
rows=load(ROOT/'reproduce/inputs/metadata.json')['rows']
meta={r['assembly_id']:r for r in rows if r['dataset']=='bode2'}
records={r['assembly_id']:r for r in struct['records']}
folds=load(ROOT/'frozen/outer_splits.json')
fold_by_id={rows[i]['assembly_id']:s['fold'] for s in folds for i in s['test_indices']}
assert set(records)==set(meta)=={x['assembly_id'] for x in maps['assemblies']}

def auc(y,s):
    y=np.asarray(y);s=np.asarray(s);p=s[y==1];n=s[y==0]
    return None if not len(p) or not len(n) else float(((p[:,None]>n).sum()+.5*(p[:,None]==n).sum())/(len(p)*len(n)))

def aggs(objects,mode,field):
    a=np.array([o[field][mode] for o in objects]);d=np.array([o[field][mode] for o in objects if o['kind']==0]);b=np.array([o[field][mode] for o in objects if o['kind']!=0])
    return dict(mean=float(a.mean()),q25=float(np.quantile(a,.25)),minimum=float(a.min()),
                domains_mean=float(d.mean()),boundaries_mean=float(b.mean()),
                balanced_mean=float((d.mean()+b.mean())/2),
                balanced_q25=float((np.quantile(d,.25)+np.quantile(b,.25))/2))

hashchecks={}
for name,entry in load(ROOT/'maps/RESULTS_MANIFEST.json').items():
    assert sha(ROOT/'maps'/name)==entry['sha256'] and (ROOT/'maps'/name).stat().st_size==entry['bytes'];hashchecks[name]=True
assert sha(ROOT/'maps/maps.json.gz')==load(ROOT/'maps/prediction_seal.json')['sha256']
provenance=load(ROOT/'maps/provenance.json')
for name,digest in provenance['code_sha256'].items():
    assert sha(ROOT/'reproduce'/name)==digest

counts=collections.Counter();max_agg_error=0.;min_visible=999;closure_checks=0;sequence_checks=0
values=collections.defaultdict(list);ids=[];all_scores=collections.defaultdict(list)
for row in maps['assemblies']:
    aid=row['assembly_id'];ids.append(aid);rec=records[aid]
    assert [o['object_index'] for o in row['objects']]==list(range(len(rec['route'])))
    parents={h:struct['parents'][h] for h in set(rec['parent_sequence_hashes'].values())}
    for h,seq in parents.items():assert hashlib.sha256(seq.encode()).hexdigest()==h
    slots={(s['object_index'],s['slot']):s for s in rec['model_slots']}
    for key,s in slots.items():
        if s['state']=='OBSERVED':
            seq=parents[s['parent_sequence_hash']][s['start']:s['end']]
            assert hashlib.sha256(seq.encode()).hexdigest()==s['sequence_hash'];sequence_checks+=1
    for obj in row['objects']:
        j=obj['object_index'];counts[obj['kind']]+=1;assert obj['status']=='SCORED'
        assert obj['mask']['targets']==[j]
        prim={key for key,s in slots.items() if key[0]==j}
        assert prim==set(map(tuple,obj['mask']['primary']))
        assert all(slots[k]['state']=='OBSERVED' for k in prim)
        forbidden={h:[] for h in parents}
        for key in prim:
            s=slots[key];target=parents[s['parent_sequence_hash']][s['start']:s['end']]
            for h,seq in parents.items():
                k=0
                while True:
                    hit=seq.find(target,k)
                    if hit<0:break
                    forbidden[h].append((hit,hit+len(target)));k=hit+1
        hidden={key for key,s in slots.items() if s['state']=='OBSERVED' and
                any(s['start']<end and start<s['end'] for start,end in forbidden[s['parent_sequence_hash']])}
        assert hidden==set(map(tuple,obj['mask']['hidden']));closure_checks+=1
        visible=collections.defaultdict(set)
        for key,s in slots.items():
            if s['state']=='OBSERVED' and key not in hidden:visible[key[0]].add(s['sequence_hash'])
        seen=set();n=0
        for k in sorted(visible):
            if k!=j and abs(k-j)<=24 and visible[k]-seen:n+=1;seen|=visible[k]
        assert n==obj['mask']['remaining_context_by_target'][str(j)] and n>=2;min_visible=min(min_visible,n)
        assert abs(obj['mask']['masked_fraction']-len(hidden)/sum(s['state']=='OBSERVED' for s in slots.values()))<1e-14
        for field in ['scores','rawcos']:
            for mode in ['full','local']:
                v=obj[field][mode];assert np.isfinite(v) and -1-1e-6<=v<=1+1e-6;all_scores[(field,mode)].append(v)
    for family,field,subset in [('independent_aggregate','scores',row['objects']),
       ('independent_exchange_aggregate','scores',[o for o in row['objects'] if o['is_exchange_domain'] or o['is_touching_exchange_boundary']]),
       ('rawcos_aggregate','rawcos',row['objects'])]:
        for mode in ['full','local']:
            expected=aggs(subset,mode,field)
            assert row[family][mode]['complete'] and row[family][mode]['total']==len(subset)
            for key,v in expected.items():
                max_agg_error=max(max_agg_error,abs(v-row[family][mode][key]));values[(family,mode,key)].append(v)
    for mode in ['full','local']:values[('historical_joint_exchange',mode,'balanced_mean')].append(row['joint_exchange_parity']['aggregate'][mode]['balanced'])

y=np.array([meta[aid]['observed_activity'] for aid in ids]);pos=np.array([meta[aid]['metadata']['position'] for aid in ids]);fold=np.array([fold_by_id[aid] for aid in ids]);metrics=[]
for key,score in sorted(values.items()):
    score=np.asarray(score);bypos={};samefold={}
    for position in sorted(set(pos)):
        take=pos==position;bypos[position]=auc(y[take],score[take]);cells=[]
        for ff in sorted(set(fold)):
            q=take&(fold==ff);v=auc(y[q],score[q]);cells.append(dict(fold=ff,n=int(q.sum()),positives=int(y[q].sum()),auroc=v))
        vv=[c['auroc'] for c in cells if c['auroc'] is not None];samefold[position]=dict(auroc=float(np.mean(vv)) if vv else None,cells=cells)
    metrics.append(dict(family=key[0],mode=key[1],aggregation=key[2],pooled_auc=auc(y,score),position_auc=bypos,
                    position_macro_auc=float(np.mean(list(bypos.values()))),same_fold_position_macro_auc=float(np.mean([c['auroc'] for c in samefold.values()])),same_fold_position_metrics=samefold))
for r in load(ROOT/'maps/summary.json')['diagnostic_metrics']:
    m=next(m for m in metrics if all(m[k]==r[k] for k in ['family','mode','aggregation']))
    assert abs(m['pooled_auc']-r['auroc'])<1e-14
assert max_agg_error<1e-14
summary=dict(assemblies=len(ids),objects=sum(counts.values()),kind_counts=dict(counts),
    closure_checks=closure_checks,slot_sequence_checks=sequence_checks,minimum_visible_distinct_context_objects=min_visible,
    maximum_aggregation_difference=max_agg_error,all32_reported_aucs_recomputed=True,map_file_hashes=hashchecks,
    map_code_hashes_verified=len(provenance['code_sha256']),
    joint_regional_parity_max_recorded_error=max(r['joint_exchange_parity']['maximum_absolute_error'] for r in maps['assemblies']),
    joint_regional_parity_recomputed=False,checkpoint_inference_repeated=False,
    score_ranges={f'{k[0]}_{k[1]}':[min(v),max(v)] for k,v in all_scores.items()},
    interpretation='Arithmetic and masking recomputation from uploaded inputs; checkpoint inference provenance verified by recorded hashes, not independently rerun')
(OUT/'audit_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'association_metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
print(json.dumps(summary,indent=2))
print('\nSELECTED ASSOCIATIONS')
for m in metrics:
    if m['aggregation'] in ['balanced_mean','balanced_q25']:
        print(m['family'],m['mode'],m['aggregation'],round(m['pooled_auc'],6),round(m['same_fold_position_macro_auc'],6))
