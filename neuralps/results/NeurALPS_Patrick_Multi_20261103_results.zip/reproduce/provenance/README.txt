BODE2 mature-assembly reconstruction audit
=========================================

DECISION: Existing supplied evidence is sufficient to construct design-implied
mature assemblies for the 33 measured doubles, 27 measured triples, and the
35^3 prospective donor combinations. Additional sequence-source upload is not
needed for these exact source-plasmid combinations.

This is not a claim that the resulting proteins were independently sequenced,
nor a prediction that the precursor proteins splice efficiently in vivo. The
sequences describe the mature exteins conditional on the documented split-intein
assembly succeeding. They preserve all internal physical protein breaks and
all remaining cloning scars, including the annotation named "Ser-Ala" whose
verified amino-acid sequence is AS.

Basis of reconstruction
-----------------------
The original reconstruction evidence records contiguous, unique LNR|SAV and
NPC|SEI scar coordinates on physical mature chains. Those two annotated seams
define the three plasmid-derived blocks. The manuscript describes the tripartite
architecture with two orthogonal split-intein pairs and one targeted XUT per
plasmid. Sequence alignment is not used to locate a cut.

All 105 new structural-handoff records exactly equal the earlier verified route,
slots, parent lengths, and parent hashes. All native parent proteins are present
in the new handoff as well. For each single swap, both non-target blocks are
identical to the native blocks in sequence and approved domain coordinates/types.
No annotated domain crosses either split-intein seam.

Recomposition using the source donor block and two native blocks exactly
reproduces every original physical parent hash, chain break, model-route field,
slot coordinate and slot sequence hash for all 105 singles plus native (106/106).
Every measured multi's donor tuple also reproduces the independently recorded
plasmid combination in the source CSV.

Results and files
-----------------
AUDIT.json: summary and source hashes.
roundtrip_audit.json: 106 exact roundtrip checks.
verified_block_registry.json.gz: sequence/domain/source-coordinate registry.
known_multis_model_inputs.json.gz: 60 model-ready records and 63 unique mature
    parent sequences, including physical source-slice provenance.
known_multis_labels.json: separate outcome manifest copied from source CSVs.
all_known_model_sequences.json.gz: 239 unique observed slot sequences.
known_multis_new_sequences.json.gz: 33 unique sequences absent from the verified
    singles+native inventory. All are covalent A-to-PCP windows (C:2:1), length
    154-168 residues, used at 73 slot occurrences.
prospective_42875_inventory.tsv.gz: all 42,875 donor/plasmid combinations, chain
    counts, ordered physical-parent hashes and model-input fingerprints. No
    activity prediction is attached and no candidates have been selected.
prospective_new_sequences.json.gz: 2,312 unique model sequences absent from
    singles+native, lengths 154-184 residues. The complete prospective set uses
    2,602 unique model sequences.

Known multis: 45 one-chain, 14 two-chain, 1 three-chain.
Prospective: 35,937 one-chain, 6,534 two-chain, 396 three-chain, 8 four-chain.
Blindly concatenating whole original proteins would therefore be incorrect.

Next computational step on Jean Zay
----------------------------------
First query the full frozen 548,713-row feature cache for every required hash.
The numbers 33 and 2,312 are absent relative to BODE2 singles+native, not proven
absent from that full cache. Reuse covered vectors; infer only cache misses.

Use the same frozen ESM-C600M independent-sequence feature contract: mean final
hidden state over actual amino-acid tokens, excluding CLS/EOS/PAD, 1152 features;
no parent-level or contextual embedding and no training. Keep new vectors in a
separate sidecar; do not change the original frozen cache. The new windows are
well below the 2046-residue limit and need no chunking. Include reference cache
sequences and verify cosine >=0.999 and relative L2 <=0.02 against cached vectors.
Exact file/checkpoint/software dependencies are in JZ_DEPENDENCIES.json.

Then run the frozen selected supervised model and predeclared challenger(s),
and the independently fixed compatibility-map definition. Seal predictions
before opening known_multis_labels.json. The 60 existing multi outcomes must
not be described as a new prospective experiment. Use them as a separately
reported transfer test; do not tune repeatedly on their outcomes.

Reproduction
------------
From the analysis workspace:
  python build_multis.py
  python build_multis.py --full-inventory

Portable materialization from this directory (registry alone is sufficient):
  python build_multis.py --compose 045 047 059 --output candidate_045_047_059.json.gz

Full audit reproduction needs the source paths recorded in AUDIT.json; the
portable compose mode needs only build_multis.py and verified_block_registry.

Implementation notes
--------------------
Frozen physical_end_extradomain_tail64_v1 slots are rebuilt explicitly. The
legacy connection_rules.break_terminus helper selects domain-adjacent residues
and must not be substituted. Physical end windows are C:[max(domain_end,L-64),L)
and N:[0,min(domain_start,64)). Covalent windows span the two domain edges plus
20 residues on each side, clamped to the physical parent.

Original nucleotide feature coordinates are nested in source_domain; they are
not claimed as coordinates on newly composed DNA. Top-level domain amino-acid
coordinates and source-slice target offsets refer to the composed mature chain.
The copied module_uid is an original source grouping, not a newly inferred
module annotation. The model's domain/type/chain/slot contract does not use it.

No model scores, new ESM-C features, or experimental validation were produced
by this audit. No original source or project cache was modified.
