#!/usr/bin/env python3
"""Independent, CPU-only audit of known-multiexchange evaluation scope."""
import collections
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "analysis/patrick_results_20261103"


def load(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == ".gz" else data)


def signature(record):
    # Same semantic signature independently implemented from recorded contract.
    payload = {
        "tokens": [(o["kind"], o["domain_type"] if o["kind"] == 0 else 0,
                    o["chain"] if o["kind"] != 2 else -1)
                   for o in record["route"]],
        "slots": sorted((s["object_index"], s["slot"], s["state"],
                         s["sequence_hash"] if s["state"] == "OBSERVED" else None)
                        for s in record["model_slots"]),
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True,
                                    separators=(",", ":")).encode()).hexdigest()


def main():
    singles = load(BASE / "extracted/bode2_structural_handoff.json.gz")["records"]
    multis = load(BASE / "multis_audit/known_multis_model_inputs.json.gz")["records"]
    labels = load(BASE / "multis_audit/known_multis_labels.json")
    rows = load(ROOT / "output/NeurALPS_Patrick_Test_20261103/inputs/metadata.json")["rows"]
    single_outcomes = {
        (r["metadata"]["donor"].removeprefix("pIG"),
         int(r["metadata"]["exchange_position"])): r["observed_activity"]
        for r in rows if r["dataset"] == "bode2"
    }
    old_signatures = collections.defaultdict(list)
    new_signatures = collections.defaultdict(list)
    for record in singles:
        old_signatures[signature(record)].append(record["assembly_id"])
    for record in multis:
        new_signatures[signature(record)].append(record["assembly_id"])
    scope = {}
    for cohort in ("doubles", "triples"):
        chosen = [r for r in labels if r["dataset"] == cohort]
        constituents = collections.Counter()
        for row in chosen:
            outcomes = [single_outcomes[(row[f"donor_xut{i}"], i)] for i in (2, 3, 4)
                        if row[f"donor_xut{i}"] != "native"]
            constituents[",".join(map(str, outcomes))] += 1
        scope[cohort] = dict(
            n=len(chosen), positive=sum(int(r["produced"]) for r in chosen),
            constituent_single_outcome_patterns=dict(constituents),
            donor_counts_by_position={str(i): dict(collections.Counter(r[f"donor_xut{i}"]
                                            for r in chosen)) for i in (2, 3, 4)},
        )
    report = dict(
        schema="independent_known_combinations_scope_audit_v1",
        exact_duplicates_among_multis=[v for v in new_signatures.values() if len(v) > 1],
        exact_matches_to_105_singles=[dict(multis=v, singles=old_signatures[k])
                                       for k, v in new_signatures.items() if k in old_signatures],
        full_494_input_overlap_check="REQUIRES_JEAN_ZAY_STRUCTURAL_INPUTS",
        scopes=scope,
        distribution={name: dict(route_length=dict(collections.Counter(len(r["route"]) for r in recs)),
                                  chain_count=dict(collections.Counter(len(r["parent_sequence_hashes"]) for r in recs)))
                      for name, recs in (("105_singles", singles), ("60_multis", multis))},
        scope_warning="All60combinations contain only active constituent singles; all doubles fix donor080 atXUT4; triples are3x3x3. Not representative of unrestricted35x35x35library.",
    )
    assert not report["exact_duplicates_among_multis"]
    assert not report["exact_matches_to_105_singles"]
    assert scope["doubles"]["constituent_single_outcome_patterns"] == {"1,1": 33}
    assert scope["triples"]["constituent_single_outcome_patterns"] == {"1,1,1": 27}
    destination = Path(__file__).with_name("audit.json")
    destination.write_text(json.dumps(report, indent=2) + "\n")
    print(destination)


if __name__ == "__main__":
    main()
