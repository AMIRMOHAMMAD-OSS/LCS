#!/usr/bin/env python3
"""Exercise orchestration with real frozen fits and mocked GPU operations.

This is an integration/API test, not model-performance evidence.
"""
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
from unittest.mock import patch
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
PKG = ROOT / "output/NeurALPS_Patrick_Multi_Test_20261103"
sys.path.insert(0, str(PKG))
spec = importlib.util.spec_from_file_location("multi_runner_integration", PKG / "run_test.py")
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
rows = json.loads((PKG / "core/inputs/metadata.json").read_text())["rows"]
with np.load(PKG / "core/inputs/features.npz") as z:
    features = z["typed"].copy()
with gzip.open(ROOT / "analysis/patrick_results_20261103/extracted/bode2_structural_handoff.json.gz", "rt") as f:
    source_singles = {r["assembly_id"]: r for r in json.load(f)["records"]}


class FakeRuntime:
    def __init__(self, root, input_rows, **kwargs):
        assert input_rows == rows
        self.records, self.vectors = [], {}
        for i, row in enumerate(rows):
            if row["dataset"] == "bode2":
                record = copy.deepcopy(source_singles[row["assembly_id"]])
            else:
                # Fake auxiliary fingerprints are unique and cannot overlap a test input.
                record = copy.deepcopy(next(iter(source_singles.values())))
                record["assembly_id"] = row["assembly_id"]
                slot = next(s for s in record["model_slots"] if s["state"] == "OBSERVED")
                slot["sequence_hash"] = hashlib.sha256(("fake_auxiliary_" + str(i)).encode()).hexdigest()
            record["dataset"] = row["dataset"]
            self.records.append(record)
            self.vectors[(row["dataset"], row["assembly_id"])] = {}


def main():
    events, fits = [], []
    with tempfile.TemporaryDirectory(prefix="multi_mock_integration_") as td:
        out = Path(td) / "output"
        read_original = runner.read

        def guarded_read(path):
            path = Path(path)
            if path.name == "known_multis_labels.json":
                assert (out / "prediction_seal.json").is_file(), "Outcome access before prediction seal"
                seal = read_original(out / "prediction_seal.json")
                assert seal["predictions_sha256"] == runner.rt.sha(out / "predictions.json")
                events.append("multi_labels_after_seal")
            return read_original(path)

        def fake_typed(root, records, vectors, **kwargs):
            if len(records) == 3:
                indices = [next(i for i, r in enumerate(rows) if r["assembly_id"] == rec["assembly_id"]) for rec in records]
                return features[indices].copy()
            assert len(records) == 60
            return features[324:384].copy()

        def fake_select(runtime, arm, train, val, labels, weights, seed, **kwargs):
            assert set(train).isdisjoint(val)
            assert set(train) | set(val) == set(range(324, 429))
            assert len(labels) == 494 and len(weights) == len(train)
            assert not (out / "prediction_seal.json").exists()
            fits.append(("select", arm, seed))
            return {"selected_epoch": 11, "validation_indices": val,
                    "validation_logits": [0.] * len(val), "mocked_gpu": True}

        def fake_refit(runtime, arm, train, labels, weights, seed, epochs, predict, checkpoint, **kwargs):
            assert set(train) == set(range(324, 429)) and predict == [] and epochs == 11
            assert len(weights) == 105
            checkpoint = Path(checkpoint)
            checkpoint.write_text(json.dumps({"arm": arm, "seed": seed}))
            fits.append(("refit", arm, seed))
            return {"checkpoint_sha256": runner.rt.sha(checkpoint), "checkpoint": str(checkpoint),
                    "prediction_indices": [], "logits": [], "mocked_gpu": True}

        def fake_inference(checkpoints, records, vectors, **kwargs):
            assert len(checkpoints) == 3
            manifests = []
            for c in checkpoints:
                assert runner.rt.sha(c["path"]) == c["sha256"]
                manifests.append(json.loads(Path(c["path"]).read_text()))
            assert {m["seed"] for m in manifests} == {17, 29, 43}
            assert len({m["arm"] for m in manifests}) == 1
            return {"probability": np.linspace(.2, .8, len(records)).tolist(), "mocked_gpu": True}

        def fake_maps(root, records, parents, vectors, dest, **kwargs):
            return {"diagnostic_scores": {"mock_agreement": np.linspace(.3, .9, len(records)).tolist()},
                    "contract": {"mocked_gpu": True}}

        fake_module = types.ModuleType("multi_maps")
        fake_module.run = fake_maps
        with patch.object(runner, "read", guarded_read), \
             patch.object(runner.nb, "NeuralRuntime", FakeRuntime), \
             patch.object(runner.nb, "fit_select", fake_select), \
             patch.object(runner.nb, "refit_predict", fake_refit), \
             patch.object(runner.rt, "load_feature_bank", lambda *a, **k: ({}, {"mocked_gpu": True})), \
             patch.object(runner.rt, "typed_features", fake_typed), \
             patch.object(runner.rt, "saved_classifier_predictions", fake_inference), \
             patch.dict(sys.modules, {"multi_maps": fake_module}):
            runner.run(ROOT, out, 6000)
            first_prediction_sha = runner.rt.sha(out / "predictions.json")
            first_fits = len(fits)
            # Completed resume must reuse fits and preserve the sealed predictions.
            runner.run(ROOT, out, 6000)
            assert len(fits) == first_fits
            assert runner.rt.sha(out / "predictions.json") == first_prediction_sha
        assert events == ["multi_labels_after_seal", "multi_labels_after_seal"]
        assert len(fits) == len(runner.ARMS) * len(runner.SEEDS) * 2
        result = read_original(out / "evaluation.json")
        pred = read_original(out / "predictions.json")
        assert len(pred["assembly_ids"]) == 60
        expected_candidates = len(runner.POOLS) + 1 + len(runner.ARMS) + 2
        assert len(pred["candidates"]) == expected_candidates
        assert len(result["metrics"]) == 3 * (expected_candidates + 1)
        assert read_original(out / "COMPLETE.json")["status"] == "RETROSPECTIVE_COMBINATION_COMPARISON_COMPLETE"
        for name in runner.POOLS:
            model, meta = runner.ft.load_model(out / "deployment" / (name + ".npz"))
            assert meta["multi_outcomes_used"] is False
            assert model["lambda"] == 10.
        report = {"status": "PASS", "real_frozen_fits": len(runner.POOLS),
                  "mocked_neural_select_and_refit_calls": len(fits),
                  "candidate_count": expected_candidates, "evaluated_rows": 60,
                  "outcome_access": events, "evaluation_rows": len(result["metrics"]),
                  "completed_resume_reuses_fits_and_preserves_predictions": True,
                  "gpu_inference_performed": False,
                  "scope": "Orchestration/API integration only; fake multi features/predictions are not scientific evidence."}
        Path(__file__).with_name("mock_integration_result.json").write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps(report))


if __name__ == "__main__":
    main()
