#!/usr/bin/env python3
"""Audited mature-extein composition from annotated tripartite split-intein seams.

No outcome is used to choose a sequence, domain, cut, or model slot. This is a
sequence/feature-input reconstruction; it does not predict activity or model
splicing success. Standard-library only. Original inputs are read-only.
"""
import argparse
import copy
import csv
import gzip
import hashlib
import itertools
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
EXTRACTED = ROOT / 'analysis/patrick_results_20261103/extracted'
OLD = ROOT / 'analysis/live_jeanzay_20261102/extracted/files/project/e0_training_prep_461027/bode2'
HANDOFF = EXTRACTED / 'bode2_structural_handoff.json.gz'
EVIDENCE = OLD / 'reconstruction_evidence.jsonl.gz'
ROUTES = OLD / 'routes.jsonl.gz'
METADATA = EXTRACTED / 'reproduce/inputs/metadata.json'
PROVENANCE = ROOT / 'output/NeurALPS_Patrick_Test_20261103/provenance'

def sha(x):
    return hashlib.sha256(x.encode() if isinstance(x, str) else x).hexdigest()

def jsha(x):
    return sha(json.dumps(x, sort_keys=True, separators=(',', ':')))

def check(ok, message):
    if not ok:
        raise ValueError(message)

def read_jsonl(path):
    with gzip.open(path, 'rt') as stream:
        return [json.loads(line) for line in stream]

def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')

def write_gz(path, data):
    # mtime=0 makes outputs stable for identical inputs.
    with path.open('wb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed:
        compressed.write(json.dumps(data, sort_keys=True, separators=(',', ':')).encode())

def chain_order(record):
    uids = list(record['parent_sequence_hashes'])
    return sorted(uids, key=lambda uid: int(uid.rsplit('=', 1)[1]))

def factor(record, evidence, parents):
    """Cut ONLY at contiguous annotated LNR|SAV and NPC|SEI scar interfaces."""
    uids = chain_order(record)
    check([x['protein_uid'] for x in evidence['coding_intervals']] == uids,
          'Physical-chain order disagrees with original coding intervals')
    scars = evidence['scars']
    cuts = []
    for left, right in [('LNR', 'SAV'), ('NPC', 'SEI')]:
        a, b = [s for s in scars if s['source_label'] == left], [s for s in scars if s['source_label'] == right]
        check(len(a) == len(b) == 1, 'Scar annotations are not unique')
        a, b = a[0], b[0]
        check(a['protein_uid'] == b['protein_uid'] and a['end_aa'] == b['start_aa'], 'Scar pair is not contiguous on one chain')
        for scar in (a, b):
            seq = parents[record['parent_sequence_hashes'][scar['protein_uid']]]
            check(seq[scar['start_aa']:scar['end_aa']] == scar['sequence'] == scar['source_label'], 'Scar sequence mismatch')
        cuts.append((uids.index(a['protein_uid']), a['end_aa']))
    check(cuts[0] < cuts[1], 'Scar order invalid')
    cuts = [(0, 0)] + cuts + [(len(uids)-1, record['parent_lengths'][uids[-1]])]
    result = []
    for block_index, (start, end) in enumerate(zip(cuts, cuts[1:])):
        slices = []
        for chain in range(start[0], end[0]+1):
            uid = uids[chain]
            begin = start[1] if chain == start[0] else 0
            finish = end[1] if chain == end[0] else record['parent_lengths'][uid]
            check(finish > begin, 'Empty source chain slice')
            parent = parents[record['parent_sequence_hashes'][uid]]
            local = []
            for domain in record['route']:
                if domain['kind'] != 0 or domain['protein_uid'] != uid:
                    continue
                a, b = domain['start_aa_0based'], domain['end_aa_0based_exclusive']
                intersects = max(a, begin) < min(b, finish)
                if intersects:
                    check(begin <= a < b <= finish, 'Annotated domain straddles a split-intein seam')
                    d = copy.deepcopy(domain)
                    d['start_aa_0based'], d['end_aa_0based_exclusive'] = a-begin, b-begin
                    d['source_domain'] = copy.deepcopy(domain)
                    local.append(d)
            slices.append(dict(sequence=parent[begin:finish], domains=local,
                source_assembly_id=record['assembly_id'], source_protein_uid=uid,
                source_parent_sequence_hash=record['parent_sequence_hashes'][uid],
                source_start=begin, source_end=finish, block_index=block_index))
        result.append(slices)
    return result

def block_signature(block):
    # Stable physical sequence + approved domain interval/type/hash semantics.
    return [(s['sequence'], [(d['start_aa_0based'], d['end_aa_0based_exclusive'], d['domain_type'],
        d['raw_domain_type'], d['canonical_domain_type'], d['seq_hash']) for d in s['domains']]) for s in block]

def compose_blocks(blocks):
    """Merge only the two certified splice seams; retain internal chain breaks."""
    chains = []
    for block in blocks:
        for i, s in enumerate(block):
            if chains and i == 0:
                target = chains[-1]
            else:
                target = dict(sequence='', domains=[], source_slices=[])
                chains.append(target)
            offset = len(target['sequence'])
            target['sequence'] += s['sequence']
            target['source_slices'].append({k: v for k, v in s.items() if k not in {'sequence', 'domains'}} |
                dict(target_start=offset, target_end=len(target['sequence'])))
            for domain in s['domains']:
                d = copy.deepcopy(domain)
                d['start_aa_0based'] += offset
                d['end_aa_0based_exclusive'] += offset
                target['domains'].append(d)
    return chains

def build_record(assembly_id, chains, sequence_sink=None):
    """Rebuild frozen physical_end_extradomain_tail64_v1 slots explicitly.

    Do not import the legacy connection_rules.break_terminus helper, whose
    domain-adjacent window differs from the physical-end contract.
    """
    parents, parent_hashes, lengths, domains = {}, {}, {}, []
    source_slices = {}
    for ci, chain in enumerate(chains, 1):
        uid = assembly_id + '|mature_chain=' + str(ci)
        seq = chain['sequence']; ph = sha(seq)
        check(seq and set(seq) <= set('ACDEFGHIKLMNPQRSTVWY'), 'Invalid amino-acid sequence')
        parents[ph] = seq; parent_hashes[uid] = ph; lengths[uid] = len(seq)
        source_slices[uid] = chain['source_slices']
        check(chain['domains'], 'Chain without annotated domains')
        for domain in chain['domains']:
            d = copy.deepcopy(domain)
            d.update(chain=ci, protein_uid=uid)
            a, b = d['start_aa_0based'], d['end_aa_0based_exclusive']
            check(0 <= a < b <= len(seq) and sha(seq[a:b]) == d['seq_hash'], 'Copied domain sequence mismatch')
            d['source_domain_uid'] = f"{uid}|{d['canonical_domain_type']}|{a}:{b}"
            # Original feature coordinates remain nested in source_domain.
            for key in ['source_start_nt', 'source_end_nt', 'source_feature_indices']:
                d.pop(key, None)
            domains.append(d)
    route, slots = [], []
    def slot(index, role, kind, d, a, b, group):
        uid = d['protein_uid']; ph = parent_hashes[uid]
        seq = parents[ph][a:b]
        check(0 <= a <= b <= lengths[uid], 'Slot lies outside physical parent')
        observed = len(seq) >= (1 if kind == 0 else 3)
        h = sha(seq) if observed else None
        if observed and sequence_sink is not None:
            if h in sequence_sink:
                check(sequence_sink[h] == seq, 'Sequence-hash collision')
            sequence_sink[h] = seq
        state = 'OBSERVED' if observed else 'MISSING'
        slots.append(dict(object_index=index, slot=role, kind=kind, state=state,
            sequence_hash=h, length=len(seq), protein_uid=uid, parent_sequence_hash=ph,
            start=a, end=b, group=group))
        return h, state
    for i, d in enumerate(domains):
        if i:
            left = domains[i-1]; broken = left['chain'] != d['chain']
            boundary = dict(boundary_id=f'{assembly_id}|boundary={i}', left_domain_uid=left['source_domain_uid'],
                right_domain_uid=d['source_domain_uid'], left_protein_uid=left['protein_uid'],
                right_protein_uid=d['protein_uid'], annotation='J' if broken else 'B', domain_type=0,
                kind=2 if broken else 1, chain=-1 if broken else d['chain'], seq_hash=None,
                cterm_hash=None, nterm_hash=None, meta=[0 if broken else .5, 0, 0, 0, 0, 0])
            if broken:
                edge = left['end_aa_0based_exclusive']; L = lengths[left['protein_uid']]
                h, state = slot(len(route), 1, 2, left, max(edge, L-64), L, 'B:cterm')
                boundary.update(cterm_hash=h, cterm_state=state)
                edge = d['start_aa_0based']
                h, state = slot(len(route), 2, 2, d, 0, min(edge, 64), 'B:nterm')
                boundary.update(nterm_hash=h, nterm_state=state)
            else:
                a, b = sorted([left['end_aa_0based_exclusive'], d['start_aa_0based']])
                h, state = slot(len(route), 0, 1, left, max(0, a-20), min(lengths[left['protein_uid']], b+20),
                    f"C:{left['domain_type']}:{d['domain_type']}")
                boundary.update(seq_hash=h, state0=state)
            route.append(boundary)
        d['occurrence_id'] = f'{assembly_id}|domain_occurrence={i+1}'
        slot(len(route), 0, 0, d, d['start_aa_0based'], d['end_aa_0based_exclusive'], 'D:'+str(d['domain_type']))
        route.append(d)
    return dict(assembly_id=assembly_id, route=route, model_slots=slots, n_domains=len(domains),
        n_chains=len(chains), parent_sequence_hashes=parent_hashes, parent_lengths=lengths,
        boundary_window_policy='physical_end_extradomain_tail64_v1',
        cache_dependency_policy='independent_sequence', physical_parent_source_slices=source_slices), parents

def proof_and_blocks():
    h = json.load(gzip.open(HANDOFF, 'rt'))
    parents = h['parents']
    for ph, seq in parents.items():
        check(sha(seq) == ph, 'Handoff parent sequence hash mismatch')
    records = {r['assembly_id']: r for r in read_jsonl(ROUTES)}
    evidence = {e['assembly_id']: e for e in read_jsonl(EVIDENCE)}
    check(len(records) == len(evidence) == 106 and len(h['records']) == 105, 'Unexpected source cohort')
    for r in h['records']:
        old = records[r['assembly_id']]
        for key in ['route', 'model_slots', 'parent_sequence_hashes', 'parent_lengths', 'boundary_window_policy']:
            check(r[key] == old[key], 'New handoff differs from old verified route: '+key)
    native = next(r for r in records.values() if r['assembly_id'].startswith('NRPS000_'))
    base = factor(native, evidence[native['assembly_id']], parents)
    registry = [{ 'native': b } for b in base]
    annotations = [{ 'native': dict(source_assembly_id=native['assembly_id'], plasmid=p)}
        for p in ['pIG016', 'pIG017', 'pIG018']]
    rows = [r for r in json.loads(METADATA.read_text())['rows'] if r['dataset'] == 'bode2']
    check(len(rows) == 105, 'Unexpected BODE2 metadata size')
    roundtrips, old_sequences = [], {}
    import re
    for row in rows:
        r = records[row['assembly_id']]
        blocks = factor(r, evidence[r['assembly_id']], parents)
        target = row['metadata']['exchange_position'] - 2
        donor = row['metadata']['donor'].removeprefix('pIG')
        for i, b in enumerate(blocks):
            if i != target:
                check(block_signature(b) == block_signature(base[i]), 'Unexpected non-target block change: '+r['assembly_id'])
        check(donor not in registry[target], 'Duplicate donor-position mapping')
        registry[target][donor] = blocks[target]
        plasmids = re.findall(r'pIG\d+', r['assembly_id'])
        check(len(plasmids) == 3, 'Unresolved source plasmids')
        annotations[target][donor] = dict(source_assembly_id=r['assembly_id'], plasmid=plasmids[target])
    donor_sets = [set(r)-{'native'} for r in registry]
    check(donor_sets[0] == donor_sets[1] == donor_sets[2] and len(donor_sets[0]) == 35, 'Donor coverage incomplete')
    for row in rows + [dict(assembly_id=native['assembly_id'], metadata=None)]:
        original = records[row['assembly_id']]
        choice = ['native'] * 3
        if row['metadata']:
            choice[row['metadata']['exchange_position']-2] = row['metadata']['donor'].removeprefix('pIG')
        chains = compose_blocks([registry[i][donor] for i, donor in enumerate(choice)])
        rebuilt, ps = build_record(original['assembly_id'], chains, old_sequences)
        for key in ['parent_sequence_hashes', 'parent_lengths', 'model_slots']:
            check(rebuilt[key] == original[key], 'Roundtrip mismatch '+key+': '+original['assembly_id'])
        keys = ['kind', 'chain', 'domain_type', 'seq_hash', 'cterm_hash', 'nterm_hash', 'meta']
        check([[o.get(k) for k in keys] for o in rebuilt['route']] ==
              [[o.get(k) for k in keys] for o in original['route']], 'Roundtrip model-route mismatch')
        roundtrips.append(dict(assembly_id=original['assembly_id'], donors=choice,
            parent_hashes_exact=True, physical_breaks_exact=True, domain_model_route_exact=True,
            model_slots_exact=True, n_chains=len(chains), n_slots=len(rebuilt['model_slots'])))
    return registry, annotations, old_sequences, roundtrips

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--full-inventory', action='store_true')
    parser.add_argument('--compose', nargs=3, metavar=('XUT2', 'XUT3', 'XUT4'),
                        help='Materialize three donor IDs (e.g. 045 047 059); native is allowed')
    parser.add_argument('--registry', type=Path, default=HERE/'verified_block_registry.json.gz')
    parser.add_argument('--output', type=Path, help='Required destination for --compose')
    args = parser.parse_args()
    HERE.mkdir(exist_ok=True, parents=True)
    if args.compose:
        check(args.output is not None and not args.output.exists(), 'Supply a new --output path')
        stored = json.load(gzip.open(args.registry, 'rt'))
        registry = stored['blocks']; annotations = stored['sources']
        check(all(d in registry[i] for i,d in enumerate(args.compose)), 'Unknown donor ID')
        sequences = {}
        aid = 'BODE2_'+'-'.join(args.compose)
        chains = compose_blocks([registry[i][d] for i,d in enumerate(args.compose)])
        record, parents = build_record(aid, chains, sequences)
        record.update(dataset='bode2', donors=args.compose,
            plasmid_combination='-'.join(annotations[i][d]['plasmid'] for i,d in enumerate(args.compose)))
        write_gz(args.output, dict(records=[record], parents=parents, sequences=sequences,
            source_registry_sha256=sha(args.registry.read_bytes()), model_scoring_performed=False))
        print('MATERIALIZED:', args.output)
        return
    registry, annotations, old_sequences, roundtrips = proof_and_blocks()
    write_json(HERE/'roundtrip_audit.json', roundtrips)
    write_gz(HERE/'verified_block_registry.json.gz', dict(blocks=registry, sources=annotations))
    print('FACTORING_PROOF_OK: 105 engineered singles + native; every physical parent, route model field and slot exactly reproduced', flush=True)
    known, labels = [], []
    for name in ['doubles', 'triples']:
        with (PROVENANCE/f'bode2_{name}.csv').open(newline='') as stream:
            rows = list(csv.DictReader(stream))
        check(len(rows) == (33 if name == 'doubles' else 27), 'Unexpected multi-label count')
        for row in rows:
            donors = [row[f'donor_xut{i}'] for i in [2,3,4]]
            p = '-'.join(annotations[i][d]['plasmid'] for i, d in enumerate(donors))
            check(p == row['plasmid_combination'], 'Multi donor/plasmid mapping mismatch')
            known.append(dict(assembly_id='BODE2_'+row['construct_id'], donors=donors,
                plasmid_combination=p, cohort=name))
            labels.append(dict(assembly_id='BODE2_'+row['construct_id'], **row))
    # Labels remain separate and cannot affect composition or model-input hashes.
    new_sequences, new_parents, records = {}, {}, []
    for item in known:
        chains = compose_blocks([registry[i][d] for i, d in enumerate(item['donors'])])
        r, ps = build_record(item['assembly_id'], chains, new_sequences)
        r.update(item, dataset='bode2'); records.append(r); new_parents.update(ps)
    write_gz(HERE/'known_multis_model_inputs.json.gz', dict(records=records, parents=new_parents))
    write_json(HERE/'known_multis_labels.json', labels)
    novel = {h: s for h, s in new_sequences.items() if h not in old_sequences}
    write_gz(HERE/'known_multis_new_sequences.json.gz', novel)
    write_gz(HERE/'all_known_model_sequences.json.gz', new_sequences)
    status = dict(schema='bode2_verified_tripartite_composition_v1', roundtrips_passed=len(roundtrips),
        proof_basis='annotated contiguous LNR|SAV and NPC|SEI split-intein interfaces; original physical CDS chains retained',
        sequences_are='hypothesized successfully spliced mature exteins from reviewed source plasmid constructs; not new experimentally sequenced constructs',
        known_multis=len(records), doubles=33, triples=27, unique_known_parent_sequences=len(new_parents),
        unique_existing_model_sequences=len(old_sequences), unique_known_multi_model_sequences=len(new_sequences),
        unique_new_known_multi_model_sequences=len(novel),
        novel_known_sequence_lengths=sorted(Counter(map(len, novel.values())).items()),
        known_multi_chain_counts=dict(Counter(r['n_chains'] for r in records)),
        model_scoring_performed=False, source_hashes={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [HANDOFF,EVIDENCE,ROUTES,METADATA]},
        note='No activity labels or learned scores are used by factoring, composition, or slot construction.')
    if args.full_inventory:
        donors = sorted(set(registry[0])-{'native'})
        full_sequences, count, chain_counts, inventory_hash = {}, 0, Counter(), hashlib.sha256()
        with gzip.open(HERE/'prospective_42875_inventory.tsv.gz', 'wt', newline='') as stream:
            writer = csv.writer(stream, delimiter='\t')
            writer.writerow(['assembly_id', 'donor_xut2', 'donor_xut3', 'donor_xut4', 'plasmids', 'n_chains',
                'physical_parent_hashes', 'domain_route_fingerprint', 'model_slot_fingerprint'])
            for combination in itertools.product(donors, repeat=3):
                aid = 'BODE2_'+'-'.join(combination)
                chains = compose_blocks([registry[i][d] for i, d in enumerate(combination)])
                r, ps = build_record(aid, chains, full_sequences)
                domain_sig = [[o['kind'], o['chain'], o['domain_type'], o.get('seq_hash'), o.get('cterm_hash'), o.get('nterm_hash')] for o in r['route']]
                slot_sig = [[s[k] for k in ['object_index','slot','kind','state','sequence_hash','length','start','end','group']] for s in r['model_slots']]
                values = [aid, *combination, '-'.join(annotations[i][d]['plasmid'] for i,d in enumerate(combination)),
                    len(chains), ','.join(r['parent_sequence_hashes'].values()), jsha(domain_sig), jsha(slot_sig)]
                writer.writerow(values); inventory_hash.update(json.dumps(values,separators=(',',':')).encode()+b'\n')
                chain_counts[len(chains)] += 1; count += 1
        full_novel = {h:s for h,s in full_sequences.items() if h not in old_sequences}
        write_gz(HERE/'prospective_new_sequences.json.gz', full_novel)
        status.update(prospective_inventory_count=count, prospective_inventory_content_sha256=inventory_hash.hexdigest(),
            prospective_chain_counts=dict(chain_counts), prospective_unique_model_sequences=len(full_sequences),
            prospective_unique_new_model_sequences=len(full_novel),
            prospective_new_sequence_lengths=sorted(Counter(map(len,full_novel.values())).items()))
    write_json(HERE/'AUDIT.json', status)
    print(json.dumps(status, indent=2))

if __name__ == '__main__':
    main()
