"""Frozen, label-free physical-object maps for complete multi-exchange inputs.

The unchanged, numerically verified single-exchange map implementation supplies
masking, reconstruction and aggregation. Only the source of complete inputs and
the per-construct resume wrapper are new. Activity classifiers are independent.
"""
from collections import Counter
import csv
import fcntl
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "core"))
import runtime as inputs_runtime
from map_audit import MAP_CONTRACT, aggregate, digest, encoded, require, sha, write_json
from vendor_map.neuralps.scoring import make_plan, slots_by_object

SCHEMA = "patrick_multi_frozen_physical_map_v1"
PINNED = {
    "e1_ssl_continue30_v1_530757/best.pt": "9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f",
    "e1_ssl_targets_497189/targets.npz": "7d81ce504a6b64e6b1c5cf2e71a639dde1b05ec4b2787e655dd235bad536961f",
}
CONTRACT = dict(MAP_CONTRACT, diagnostic_path=None,
                checkpoint_sha256=PINNED["e1_ssl_continue30_v1_530757/best.pt"],
                computed_paths=["full"],
                target_scope="Complete design-implied mature multi-exchange assemblies, conditional on successful splicing",
                whole_construct_aggregates="Descriptive reconstruction diagnostics, not calibrated activity probabilities")


def vector_digest(vectors):
    h = hashlib.sha256()
    for key in sorted(vectors):
        value = np.asarray(vectors[key], dtype="<f4")
        require(value.shape == (1152,) and np.isfinite(value).all(), "Invalid physical input vector")
        h.update(key.encode("ascii")); h.update(value.tobytes(order="C"))
    return h.hexdigest()


def score_assembly(model_runtime, record, parents, vectors, microbatch=8):
    """Exactly one primary physical object per query, including both break roles."""
    plans = {"object_" + str(j): make_plan(record, [j], parents)
             for j in range(len(record["route"]))}
    scores = model_runtime.score_plans(record, parents, vectors, plans,
                                      modes=("full",), microbatch=microbatch)
    slots = slots_by_object(record)
    objects = []
    for j, annotation in enumerate(record["route"]):
        result = scores["object_" + str(j)]
        objects.append(dict(object_index=j, kind=annotation["kind"], annotation=annotation,
                            slots=slots[j], status=result["status"],
                            scores=result["objects"].get(str(j), {}),
                            rawcos=result.get("objects_rawcos", {}).get(str(j), {}),
                            mask={k: v for k, v in result.items()
                                  if k not in ("objects", "objects_rawcos")}))
    return dict(assembly_id=record["assembly_id"], record_sha256=digest(record),
                objects=objects, independent_aggregate={"full": aggregate(objects, "full")},
                rawcos_aggregate={"full": aggregate(objects, "full", field="rawcos")})


def _saved(path, identity, record):
    envelope = json.loads(Path(path).read_text())
    result = envelope["result"]
    require(envelope["run_identity"] == identity and envelope["result_sha256"] == digest(result),
            "Saved multi-map identity/hash mismatch")
    require(result["assembly_id"] == record["assembly_id"] and result["record_sha256"] == digest(record),
            "Saved multi-map physical input mismatch")
    require([o["object_index"] for o in result["objects"]] == list(range(len(record["route"]))),
            "Saved multi-map is incomplete")
    return result


def _pause(deadline_monotonic, stop_requested):
    if ((stop_requested is not None and stop_requested()) or
            (deadline_monotonic is not None and time.monotonic() >= deadline_monotonic - 30)):
        from neural_backend import TrainingPaused
        raise TrainingPaused("Frozen multi-map paused between complete construct checkpoints")


def run(root, records, parents, vectors, out, deadline_monotonic=None,
        stop_requested=None, device="cuda", threads=8, microbatch=8):
    """Return {'assemblies': [...], 'summary': ...}; no activity labels read.

    Each result has independent_aggregate.full.balanced_mean/balanced_q25.
    Missing object scores make all whole-assembly aggregates null. Output files
    include every object and mask, plus hashes; failed or paused runs can resume.
    """
    from vendor_map.score_all_parts import load_runtime
    root, out = Path(root).resolve(), Path(out).resolve()
    require(device in ("cpu", "cuda") and threads > 0 and microbatch > 0, "Invalid map runtime settings")
    sequences = inputs_runtime.validate_records(records, parents)
    require(set(sequences) <= set(vectors), "Missing map feature vectors")
    vectors = {h: vectors[h] for h in sequences}
    source_hashes, signatures = {}, {}
    for relative in list(PINNED) + ["e1_ssl_targets_497189/manifest.json"]:
        path = root / relative
        before = path.stat(); actual = sha(path); after = path.stat()
        signature = (after.st_size, after.st_mtime_ns, after.st_ino)
        require((before.st_size, before.st_mtime_ns, before.st_ino) == signature, "Map source changed during hashing")
        require(relative not in PINNED or actual == PINNED[relative], "Frozen map source checksum changed: " + relative)
        signatures[relative] = signature; source_hashes[relative] = actual
    _pause(deadline_monotonic, stop_requested)
    model_runtime, environment = load_runtime(root, device, threads)
    code_paths = [HERE / "multi_maps.py", HERE / "runtime.py", HERE / "core/map_audit.py"]
    code_paths += sorted((HERE / "core/vendor_map").rglob("*.py"))
    identity_body = dict(schema=SCHEMA, contract=CONTRACT, sources=source_hashes,
                         records_sha256=digest(records), parents_sha256=digest(parents),
                         vectors_sha256=vector_digest(vectors), microbatch=microbatch,
                         environment=environment,
                         code_sha256={str(p.relative_to(HERE)): sha(p) for p in code_paths})
    identity = digest(identity_body)
    out.mkdir(parents=True, exist_ok=True)
    with (out / ".map.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        runfile = out / "RUN_IDENTITY.json"
        if runfile.exists():
            require(json.loads(runfile.read_text())["run_identity"] == identity,
                    "Map resume inputs, code, environment or settings changed")
        else:
            require(not any(p.name != ".map.lock" for p in out.iterdir()), "Unrecognized nonempty map output")
            write_json(runfile, dict(run_identity=identity, identity=identity_body))
        working = out / "assemblies"; working.mkdir(exist_ok=True)
        results = []
        for number, record in enumerate(records, 1):
            _pause(deadline_monotonic, stop_requested)
            path = working / (hashlib.sha256(record["assembly_id"].encode()).hexdigest() + ".json")
            if path.exists():
                result = _saved(path, identity, record)
            else:
                result = score_assembly(model_runtime, record, parents, vectors, microbatch)
                write_json(path, dict(run_identity=identity, result_sha256=digest(result), result=result))
            results.append(result)
            print(json.dumps(dict(stage="multi_map", completed=number, total=len(records),
                                  assembly_id=record["assembly_id"])), flush=True)
        for relative, signature in signatures.items():
            stat = (root / relative).stat()
            require((stat.st_size, stat.st_mtime_ns, stat.st_ino) == signature,
                    "Frozen map source changed during inference")
        prediction = dict(schema=SCHEMA, contract=CONTRACT, run_identity=identity, assemblies=results)
        tmp = out / "maps.json.gz.tmp"
        tmp.write_bytes(gzip.compress(encoded(prediction), compresslevel=6, mtime=0))
        tmp.replace(out / "maps.json.gz")
        rows = [dict(assembly_id=r["assembly_id"], object_index=o["object_index"], kind=o["kind"],
                     status=o["status"], full_mixed=o["scores"].get("full"),
                     full_rawcos=o["rawcos"].get("full")) for r in results for o in r["objects"]]
        tmp = out / "object_scores.csv.tmp"
        with tmp.open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
        tmp.replace(out / "object_scores.csv")
        summary = dict(schema=SCHEMA, status="MULTI_MAP_COMPLETE", assemblies=len(results), objects=len(rows),
                       object_status_counts=dict(Counter(r["status"] for r in rows)),
                       all_objects_scored=all(r["status"] == "SCORED" for r in rows),
                       labels_read=False, training_performed=False, contract=CONTRACT,
                       source_hashes=source_hashes, run_identity=identity)
        write_json(out / "summary.json", summary)
        write_json(out / "prediction_seal.json", dict(maps_sha256=sha(out / "maps.json.gz"),
                   object_scores_sha256=sha(out / "object_scores.csv"), labels_read=False,
                   map_definition_selected_from_activity_labels=False))
        del model_runtime
        diagnostics = {"full_" + key: [r["independent_aggregate"]["full"][key] for r in results]
                       for key in ("balanced_mean", "balanced_q25")}
        return dict(assemblies=results, summary=summary, diagnostic_scores=diagnostics, contract=CONTRACT)
