#!/usr/bin/env python3
"""Cheap package checks; --numeric adds local model/score contract checks."""
import argparse
import collections
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent


def validate_package():
    manifest = json.loads((HERE / 'PACKAGE_MANIFEST.json').read_text())
    for name, expected in manifest['files'].items():
        p = (HERE / name).resolve()
        if HERE not in p.parents or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != expected:
            raise ValueError('Missing/changed/unsafe package member: ' + name)
    # The original independently checked cohort and source are included unchanged.
    spec = importlib.util.spec_from_file_location('original_package_integrity', HERE / 'core/selftest.py')
    original = importlib.util.module_from_spec(spec); spec.loader.exec_module(original)
    old = original.validate_package()
    with gzip.open(HERE / 'inputs/known_multis_model_inputs.json.gz', 'rt') as stream:
        payload = json.load(stream)
    ids = [r['assembly_id'] for r in payload['records']]
    if len(ids) != 60 or len(set(ids)) != 60 or len(payload['parents']) != 63:
        raise ValueError('Complete combination input identities changed')
    chemistry = json.loads((HERE / 'inputs/expected_chemistry.json').read_text())
    if [r['assembly_id'] for r in chemistry] != ids:
        raise ValueError('Expected chemistry identity/order differs')
    return dict(package_files=len(manifest['files']), original=old, multi_inputs=60,
                scope='Integrity only; no activity evaluation and no GPU work on login node')


def numeric_tests():
    sys.path.insert(0, str(HERE))
    import run_test as run
    import numpy as np
    import runtime
    import frozen_test as ft
    class NumericTests(unittest.TestCase):
        def test_fixed_source_pool_counts_weights(self):
            rows = json.loads((HERE / 'core/inputs/metadata.json').read_text())['rows']
            for name, (a, b) in run.POOLS.items():
                ix = run.pool_indices(rows, a, b)
                self.assertEqual(len(ix), 105 + (324 if a else 0) + (65 if b else 0))
                w = ft.cohort_weights(rows, ix, a, b)
                self.assertAlmostEqual(float(w.sum()), 1.)
                for cohort, expected in [('bode2', 1.), ('bode1', a), ('tdomain', b)]:
                    self.assertAlmostEqual(float(sum(t for i, t in zip(ix, w) if rows[i]['dataset'] == cohort)),
                                           expected / (1 + a + b))

        def test_saved_head_refit_actual_105(self):
            rows = json.loads((HERE / 'core/inputs/metadata.json').read_text())['rows']
            ix = run.pool_indices(rows, 0, 0)
            with np.load(HERE / 'core/inputs/features.npz') as z: x = z['typed'][ix]
            fit = ft.fit_model(x, [rows[i]['observed_activity'] for i in ix], ['bode2'] * len(ix),
                              ft.cohort_weights(rows, ix), 10.)
            ref, meta = ft.load_model(HERE / 'single_results/typed__bode2_only.npz')
            self.assertLessEqual(float(np.max(np.abs(ft.predict_logits(fit, x) - ft.predict_logits(ref, x)))), 1e-5)
            ref.update({k: meta[k] for k in ('iterations', 'gradient_inf')})
            with tempfile.TemporaryDirectory() as d:
                p = Path(d) / 'head.npz'; ft.save_model(p, ref, {})
                copy, _ = ft.load_model(p)
                np.testing.assert_array_equal(ft.predict_logits(ref, x), ft.predict_logits(copy, x))

        def test_prediction_seal_and_per_cohort_evaluation(self):
            with tempfile.TemporaryDirectory() as d:
                ids = ['A', 'B', 'C', 'D']
                pred = run.seal_predictions(Path(d), ids, {'fixed': [.1, .8, .2, .9]},
                                            {'agreement': [.7, .8, .6, .9]})
                labels = [dict(assembly_id=k, produced=str(i % 2), dataset='doubles' if i < 2 else 'triples')
                          for i, k in enumerate(ids)]
                evaluation = run.evaluate_predictions(pred, labels)
                self.assertEqual(len(evaluation['metrics']), 6)
                self.assertTrue(all(r['auroc'] == 1. for r in evaluation['metrics']))
                self.assertTrue(all('log_loss' not in r for r in evaluation['metrics'] if r['candidate'].startswith('map__')))
                with self.assertRaises(ValueError):
                    run.seal_predictions(Path(d), ids, {'fixed': [.1, .8, .2, .8]}, {})
                with self.assertRaises(ValueError):
                    run.evaluate_predictions(pred, labels[:-1])

        def test_full_input_duplicate_audit(self):
            records, _ = runtime.load_inputs(HERE / 'inputs/known_multis_model_inputs.json.gz')
            audit = run.exact_overlap_audit([], records)
            self.assertEqual(audit['test_duplicates'], [])
            audit = run.exact_overlap_audit(records[:1], records)
            self.assertEqual(len(audit['train_test_duplicates']), 1)

        def test_first_epoch_split_groups_do_not_cross(self):
            rows = json.loads((HERE / 'core/inputs/metadata.json').read_text())['rows']
            split = json.loads((HERE / 'single_results/typed__bode2_only.json').read_text())['inner_splits'][0]
            tr, va = split['train_indices'], split['test_indices']
            self.assertFalse(set(tr) & set(va))
            self.assertFalse({rows[i]['group'] for i in tr} & {rows[i]['group'] for i in va})
            self.assertEqual(set(tr) | set(va), set(run.pool_indices(rows, 0, 0)))

    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(NumericTests))
    if not result.wasSuccessful():
        raise SystemExit(1)
    return dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--numeric', action='store_true')
    args = parser.parse_args()
    report = validate_package()
    if args.numeric:
        report['numeric'] = numeric_tests()
    print(json.dumps(report, indent=2))
