#!/usr/bin/env bash
set -euo pipefail
NRPS_MULTI_PACKAGE="${1:?package directory}"
NRPS_MULTI_ROOT="${2:?project root}"
NRPS_MULTI_OUTPUT="${3:?output directory}"
NRPS_MULTI_REQUEST="${4:?request file}"
: "${SLURM_JOB_ID:?Submit through submit.py}"
NRPS_MULTI_START=$(date +%s)
module purge
module load arch/a100
module load pytorch-gpu/py3/2.8.0
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
NRPS_MULTI_PY=$(command -v python3)
NRPS_MULTI_STAGE=request_check
function nrps_multi_failure() {
    local nrps_exit="$?"
    if [ "$nrps_exit" -ne 0 ]; then
        "$NRPS_MULTI_PY" -I -B - "$NRPS_MULTI_OUTPUT" "$NRPS_MULTI_STAGE" "$nrps_exit" <<'PY'
import json,sys,time
from pathlib import Path
out,stage,code=sys.argv[1:]
(Path(out)/'BATCH_FAILURE.json').write_text(json.dumps(dict(stage=stage,exit_code=int(code),utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())),indent=2)+'\n')
PY
    fi
}
trap nrps_multi_failure EXIT
"$NRPS_MULTI_PY" -I -B - "$NRPS_MULTI_PACKAGE" "$NRPS_MULTI_REQUEST" <<'PY'
import hashlib,json,sys
from pathlib import Path
package,request=map(Path,sys.argv[1:])
digest=hashlib.sha256(request.read_bytes()).hexdigest()
assert digest==request.with_suffix('.sha256').read_text().strip(), 'Request changed'
payload=json.loads(request.read_text())
assert payload['package_sha256']==hashlib.sha256((package/'PACKAGE_MANIFEST.json').read_bytes()).hexdigest(), 'Package manifest changed'
print('REQUEST_HASH_OK:',digest,flush=True)
PY
NRPS_MULTI_STAGE=numerical_selftests
srun --ntasks=1 "$NRPS_MULTI_PY" -B "$NRPS_MULTI_PACKAGE/selftest.py" --numeric
srun --ntasks=1 "$NRPS_MULTI_PY" -B "$NRPS_MULTI_PACKAGE/runtime_tests.py" --require-torch
if [ -f "$NRPS_MULTI_PACKAGE/multi_maps_tests.py" ]; then
    srun --ntasks=1 "$NRPS_MULTI_PY" -B "$NRPS_MULTI_PACKAGE/multi_maps_tests.py" --require-torch
fi
(
    cd -- "$NRPS_MULTI_PACKAGE/core"
    srun --ntasks=1 "$NRPS_MULTI_PY" -B - "$NRPS_MULTI_OUTPUT" <<'PY'
import sys
from pathlib import Path
from run_suite import numerical_tests
numerical_tests(Path(sys.argv[1]))
PY
)
NRPS_MULTI_STAGE=feature_bank
# A complete bank is validated before reuse. Interrupted extraction is preserved
# under this run's output and rebuilt into a fresh directory on explicit resume.
"$NRPS_MULTI_PY" -B - "$NRPS_MULTI_PACKAGE" "$NRPS_MULTI_OUTPUT" <<'PY'
import sys,time
from pathlib import Path
package,out=map(Path,sys.argv[1:]);sys.path.insert(0,str(package))
import runtime
bank=out/'feature_bank'
if (bank/'feature_bank.json').exists():
    records,parents=runtime.load_inputs(package/'inputs/known_multis_model_inputs.json.gz')
    runtime.load_feature_bank(bank,records,parents)
    print('FEATURE_BANK_REUSE_VERIFIED',flush=True)
elif bank.exists():
    target=out/('feature_bank_partial_'+str(time.time_ns()))
    bank.rename(target)
    print('PARTIAL_FEATURE_BANK_PRESERVED:',target,flush=True)
PY
if [ ! -f "$NRPS_MULTI_OUTPUT/feature_bank/feature_bank.json" ]; then
    (
        # This source helper activates the previously validated ESM-C environment.
        # A subshell keeps its environment changes out of supervised training.
        set +u
        export TMPDIR="$NRPS_MULTI_OUTPUT/embedding_tmp"
        mkdir -p -- "$TMPDIR"
        export SQLITE_TMPDIR="$TMPDIR"
        source "$NRPS_MULTI_ROOT/nrps_esmc_environment.sh"
        srun --ntasks=1 "$NRPS_MULTI_ROOT/envs/esmc_connections_hf/bin/python" -B \
            "$NRPS_MULTI_PACKAGE/runtime.py" embed --root "$NRPS_MULTI_ROOT" \
            --inputs "$NRPS_MULTI_PACKAGE/inputs/known_multis_model_inputs.json.gz" \
            --out "$NRPS_MULTI_OUTPUT/feature_bank"
    )
fi
NRPS_MULTI_NOW=$(date +%s)
NRPS_MULTI_REMAINING=$((6840 - NRPS_MULTI_NOW + NRPS_MULTI_START))
if [ "$NRPS_MULTI_REMAINING" -lt 60 ]; then
    "$NRPS_MULTI_PY" -I -B - "$NRPS_MULTI_OUTPUT" <<'PY'
import json,sys
from pathlib import Path
(Path(sys.argv[1])/'PAUSED.json').write_text(json.dumps(dict(reason='Allocation budget consumed during verification/embedding; feature bank saved. Resume this output.'),indent=2)+'\n')
PY
    exit 0
fi
NRPS_MULTI_STAGE=model_test
srun --ntasks=1 "$NRPS_MULTI_PY" -B "$NRPS_MULTI_PACKAGE/run_test.py" \
    --root "$NRPS_MULTI_ROOT" --out "$NRPS_MULTI_OUTPUT" --seconds "$NRPS_MULTI_REMAINING"
