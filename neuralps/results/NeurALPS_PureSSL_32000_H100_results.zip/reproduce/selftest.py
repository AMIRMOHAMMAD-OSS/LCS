#!/usr/bin/env python3
"""Standard-library contract checks; no checkpoint loading or Slurm submission.

The structured-mask checks use the pinned real physical masking closure and an
explicit synthetic legacy-chooser stub. They test fallback RNG preservation,
not the original legacy sampling distribution. The trainer separately runs the
real legacy chooser and tensor/attention/gradient checks on its compute node.
"""
from __future__ import annotations

import ast
from contextlib import redirect_stdout
import copy
import hashlib
import io
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import patch
import zipfile


PACKAGE = Path(__file__).resolve().parent
MASK_SHA = '2fadc2af85762a6e5ef0d21243863c125b5a919daae7753fd34372d51e264f61'
CLOSURE_SHA = 'a9a4e94fec9d07882e6e7527bcd57298cb8d79f7f2362c4c47c165545024bc2a'


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rejected(fn, exceptions=(RuntimeError, ValueError)):
    try:
        fn()
    except exceptions:
        return
    raise AssertionError('Expected rejection did not occur')


def synthetic_legacy_chooser(record, parent, rng, closure):
    """A test-only random single-object chooser, not the pretraining sampler."""
    from ssl_changes import plan_from_targets
    candidates = sorted({s['object_index'] for s in record['model_slots']
                         if s['state'] == 'OBSERVED'})
    rng.shuffle(candidates)
    for j in candidates:
        plan = plan_from_targets(record, parent, closure, [j])
        if plan is not None:
            return plan
    return None


def check_imports():
    probe = subprocess.run(
        [sys.executable, '-S', '-B', '-c',
         "import submit,train,ssl_protocol,sys; "
         "assert 'torch' not in sys.modules; assert 'numpy' not in sys.modules; "
         "assert not any(x.startswith(('supervised','labelled_')) for x in sys.modules); "
         "print('PASS')"],
        cwd=PACKAGE, capture_output=True, text=True, check=True)
    require(probe.stdout.strip() == 'PASS', 'Launcher/trainer imports require model dependencies')
    forbidden_modules = {'supervised', 'labelled_backend', 'labelled_multis'}
    forbidden_variables = {'labelled', 'supervised_loss', 'activity_loss', 'activity_head', 'head_opt'}
    for name in ('train.py', 'ssl_protocol.py', 'evaluation.py', 'submit.py'):
        tree = ast.parse((PACKAGE / name).read_text(), filename=name)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                modules = [x.name.split('.')[0] for x in node.names]
                require(not forbidden_modules.intersection(modules), name + ': labelled import')
            if isinstance(node, ast.ImportFrom):
                require((node.module or '').split('.')[0] not in forbidden_modules,
                        name + ': labelled import')
            if name == 'train.py' and isinstance(node, ast.Name):
                require(node.id not in forbidden_variables, 'Trainer contains activity-training state')
    require(not (PACKAGE / 'labelled_assets').exists(), 'Labelled assets must not be bundled')
    require(not (PACKAGE / 'supervised.py').exists(), 'Activity trainer must not be bundled')


def check_cross_module_contracts():
    """Check independently written launcher/trainer/loader wire contracts."""
    import submit
    import export_review as exporter
    require(submit.PREFIX == exporter.PREFIX == 'neuralps_ssl26to32_',
            'Launcher and exporter output prefixes disagree')
    trees = {name: ast.parse((PACKAGE / name).read_text(), filename=name)
             for name in ('train.py', 'evaluation.py', 'export_review.py')}
    functions = {name: {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
                 for name, tree in trees.items()}
    trainer_main = functions['train.py']['main']
    output_guards = [node for node in ast.walk(trainer_main)
                     if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                     and node.func.attr == 'startswith'
                     and ast.unparse(node.func.value) == 'args.out.name']
    require(len(output_guards) == 1 and len(output_guards[0].args) == 1,
            'Expected one explicit trainer output-prefix guard')
    prefix = output_guards[0].args[0]
    require(isinstance(prefix, ast.Constant) and prefix.value == submit.PREFIX,
            'Trainer output-prefix guard rejects launcher output directories')
    expected_status = 'PURE_SSL_CONTINUATION_COMPLETE'
    trainer_statuses = [kw.value.value for node in ast.walk(functions['train.py']['run'])
                        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                        and node.func.id == 'dict' for kw in node.keywords
                        if kw.arg == 'status' and isinstance(kw.value, ast.Constant)
                        and isinstance(kw.value.value, str) and kw.value.value.endswith('CONTINUATION_COMPLETE')]
    require(trainer_statuses == [expected_status], 'Trainer completion receipt schema differs')
    for filename, function_name in (('evaluation.py', 'load_ssl_candidate'),
                                    ('export_review.py', 'export_review')):
        fn = functions[filename][function_name]
        guards = [node for node in ast.walk(fn)
                  if isinstance(node, ast.Compare) and isinstance(node.left, ast.Call)
                  and isinstance(node.left.func, ast.Attribute) and node.left.func.attr == 'get'
                  and node.left.args and isinstance(node.left.args[0], ast.Constant)
                  and node.left.args[0].value == 'status'
                  and any(isinstance(x, ast.Constant) and x.value == expected_status
                          for x in node.comparators)]
        require(len(guards) == 1, filename + ': missing matching completion-status guard')
        require(not any(isinstance(node, ast.Constant) and isinstance(node.value, str)
                        and node.value == 'JOINT_CONTINUATION_COMPLETE' for node in ast.walk(fn)),
                filename + ': obsolete joint-run completion schema')
    require('load_joint_candidate' not in functions['evaluation.py'],
            'Obsolete activity-bearing inference loader remains')
    loader = functions['evaluation.py']['load_ssl_candidate']
    require([arg.arg for arg in loader.args.args] == ['root', 'out', 'device']
            and not loader.args.kwonlyargs,
            'Natural-only loader signature unexpectedly accepts activity loading')
    calls = {node.func.id for node in ast.walk(loader)
             if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)}
    require({'validate_state', 'enable_full_attention'} <= calls,
            'Inference loader must validate pure state and reapply full attention')
    returned_fields = {kw.arg for node in ast.walk(loader)
                       if isinstance(node, ast.Return) and isinstance(node.value, ast.Call)
                       and isinstance(node.value.func, ast.Name) and node.value.func.id == 'dict'
                       for kw in node.value.keywords}
    require('model' in returned_fields and not {'head', 'activity_head'} & returned_fields,
            'Natural-only loader return schema contains an activity head')


def check_masks():
    from ssl_changes import MASK_WEIGHTS, STRUCTURED_MAX_HIDDEN, mask_selftest
    from tests_support.masking_contract import masking_closure

    require(digest(PACKAGE / 'ssl_changes.py') == MASK_SHA, 'Original masking/attention code changed')
    require(digest(PACKAGE / 'tests_support/masking_contract.py') == CLOSURE_SHA,
            'Test closure differs from the original pinned closure')
    expected = dict(original=25, xut=20, xut_with_seams=10, xut_pair=8,
                    xut_interface=7, medium_span=5, long_span=5, dispersed=5,
                    break_side=5, break_pair=5, break_flanks=5)
    require(MASK_WEIGHTS == expected and sum(MASK_WEIGHTS.values()) == 100,
            'Mask policy probabilities differ')
    require(STRUCTURED_MAX_HIDDEN == .8, 'Structured hidden-fraction guard differs')
    result = mask_selftest(masking_closure, synthetic_legacy_chooser)
    require(all(value == 'PASS' for value in result.values()), 'Structured mask contract failed')


def check_protocol():
    import ssl_protocol as protocol
    require(protocol.PARENT_STEP == 26000 and protocol.END_STEP == 32000
            and protocol.UPDATES == 6000, 'Training budget differs')
    require(protocol.PARENT_REL == 'e1_ssl_continue30_v1_530757/best.pt', 'Wrong parent path')
    require(protocol.PARENT_SHA == '9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f',
            'Wrong parent identity')
    require(protocol.ATTENTION == 'full_distance_with_radius6_clipped_bias', 'Wrong attention policy')
    rates = [protocol.learning_rate(i) for i in range(1, protocol.UPDATES + 1)]
    for i, expected in ((0, 1e-5), (999, 2.5e-6), (1000, 2.5e-6), (5999, 1e-6)):
        require(math.isclose(rates[i], expected, rel_tol=1e-12, abs_tol=1e-16),
                f'Learning-rate phase endpoint differs at update {i + 1}')
    require(all(a >= b for a, b in zip(rates, rates[1:])), 'Learning-rate schedule is not monotone')
    for index in (0, -1, 6001):
        rejected(lambda index=index: protocol.learning_rate(index))
    require(protocol.UPDATES * 32 == 192000, 'Natural batch budget differs')


def check_resume_contract():
    import ssl_protocol as protocol
    config = dict(version=protocol.VERSION, activity_labels_used=False, classifier_training=False,
                  attention=protocol.ATTENTION, parent_step=protocol.PARENT_STEP,
                  parent_sha256=protocol.PARENT_SHA, final_step=protocol.END_STEP,
                  steps=protocol.UPDATES, settings=dict(batch=32))
    state = dict(config=config, step=27000, encoder_state={},
                 encoder_optimizer=dict(state={0: {}}, param_groups=[{'lr': 2.5e-6}, {'lr': 2.5e-6}]),
                 sampler=dict(attempted=27000 * 32 + 7, skipped=7), torch_rng='test-tensor',
                 cuda_rng=['test-cuda-state'], counts={'mask_original': 32000},
                 targets_manifest={}, target_means={})
    torch_stub = SimpleNamespace(is_tensor=lambda x: x == 'test-tensor')
    protocol.validate_state(state, config, 27000, torch_stub)
    for mutation in ('activity_state', 'sampler', 'counts', 'learning_rate', 'labelled_config'):
        altered = copy.deepcopy(state)
        if mutation == 'activity_state':
            altered['activity_state'] = {}
        elif mutation == 'sampler':
            altered['sampler']['attempted'] += 1
        elif mutation == 'counts':
            altered['counts']['mask_original'] -= 1
        elif mutation == 'learning_rate':
            altered['encoder_optimizer']['param_groups'][0]['lr'] *= 2
        else:
            altered['config']['activity_labels_used'] = True
        rejected(lambda altered=altered: protocol.validate_state(altered, config, 27000, torch_stub))


def check_scheduler_and_receipts():
    import submit
    reply = SimpleNamespace(stdout='1839175_[119-120,129,138,141,14 | unrelated_array\n', returncode=0)
    with patch.object(submit.subprocess, 'run', return_value=reply) as run:
        submit.check_queue('2120436', 'nrps_test')
        require(run.call_args.args[0][0] == 'squeue' and '-u' in run.call_args.args[0],
                'Queue guard must query the full user queue')
    for line in ('2120436 | another_name', '55 | nrps_test', 'malformed', '12|name|extra'):
        with patch.object(submit.subprocess, 'run', return_value=SimpleNamespace(stdout=line, returncode=0)):
            rejected(lambda: submit.check_queue('2120436', 'nrps_test'))
    with patch.object(submit.subprocess, 'run', side_effect=subprocess.CalledProcessError(1, 'squeue')):
        rejected(lambda: submit.check_queue('2120436', 'nrps_test'), (subprocess.SubprocessError,))
    with tempfile.TemporaryDirectory(prefix='nrps_ssl_contract_') as tmp:
        root = Path(tmp).resolve()
        output = root / (submit.PREFIX + 'synthetic')
        output.mkdir()
        with patch.dict(os.environ, {}, clear=True):
            rejected(lambda: submit.worker(root, output))
        request = dict(root=str(root), output=str(output), package=str(submit.PACKAGE),
                       package_manifest_sha256='package-test')
        submit.dump(output / 'REQUEST.json', request)
        (output / 'REQUEST.sha256').write_text(submit.sha(output / 'REQUEST.json') + '\n')
        require(submit.read_request(root, output, 'package-test') == request, 'Valid request rejected')
        rejected(lambda: submit.read_request(root, output, 'changed-package'))
        with (output / 'REQUEST.json').open('a') as stream:
            stream.write(' ')
        rejected(lambda: submit.read_request(root, output, 'package-test'))
        rejected(lambda: submit.checked_output(root, root))
        fake_parent = root / 'joint27000.pt'
        fake_parent.write_bytes(b'not the original checkpoint')
        rejected(lambda: submit.select_parent(root, fake_parent))


def check_export():
    import export_review as exporter
    import ssl_protocol as protocol
    with tempfile.TemporaryDirectory(prefix='nrps_ssl_export_') as tmp:
        root = Path(tmp).resolve()
        out = root / (exporter.PREFIX + 'synthetic')
        out.mkdir()
        source = root / 'synthetic_package'
        source.mkdir()
        (source / 'test.py').write_text('# synthetic reproduction entry\n')
        (source / 'not_exported.pt').write_bytes(b'large model placeholder')
        (out / 'latest.pt').write_bytes(b'synthetic checkpoint bytes, never torch-loaded')
        (out / 'checkpoints').mkdir()
        (out / 'checkpoints/step_32000.pt').write_bytes(b'synthetic model snapshot')
        (out / 'checkpoints/step_32000.json').write_text('{"step": 32000}\n')
        done = dict(status='PURE_SSL_CONTINUATION_COMPLETE', step=protocol.END_STEP,
                    parent_step=protocol.PARENT_STEP, additional_updates=protocol.UPDATES,
                    parent_sha256=protocol.PARENT_SHA, candidate_checkpoint='latest.pt',
                    candidate_sha256=exporter.sha(out / 'latest.pt'))
        (out / 'COMPLETE.json').write_text(json.dumps(done))
        (out / 'config.json').write_text('{"activity_labels_used": false}')
        for name in ('fixed_natural_views.json', 'attention_baseline.json', 'parent_natural.json',
                     'natural_comparison.json'):
            (out / name).write_text('{}\n')
        (out / 'natural_reference.json').write_text('{"status":"UNAVAILABLE"}')
        (out / 'progress.jsonl').write_text('{"step":32000}\n')
        with patch.object(exporter, 'PACKAGE', source):
            result = exporter.export_review(root, out)
        require(result['sha256'] == exporter.sha(out / 'inspection.zip'), 'Review checksum differs')
        with zipfile.ZipFile(result['path']) as archive:
            require(not any(name.endswith('.pt') for name in archive.namelist()),
                    'Review leaked model weights')
            require('reproduce/test.py' in archive.namelist(), 'Review source reproduction missing')
            manifest = json.loads(archive.read('REVIEW_MANIFEST.json'))
            require(manifest['checkpoint_included'] is False
                    and manifest['labelled_activity_evaluation_included'] is False,
                    'Review scope flags differ')
            for name, expected in manifest['files'].items():
                data = archive.read(name)
                require(len(data) == expected['bytes']
                        and hashlib.sha256(data).hexdigest() == expected['sha256'],
                        'Review entry checksum differs: ' + name)
        with (out / 'latest.pt').open('ab') as stream:
            stream.write(b'changed')
        with patch.object(exporter, 'PACKAGE', source):
            rejected(lambda: exporter.export_review(root, out))


def main():
    checks = []
    check_imports()
    checks.append('stdlib_login_imports_and_no_activity_training_dependencies')
    check_cross_module_contracts()
    checks.append('launcher_trainer_loader_export_prefix_and_completion_schema_agreement')
    check_protocol()
    checks.append('pinned_parent_6000_update_budget_and_piecewise_learning_rate')
    check_resume_contract()
    checks.append('resume_rejects_activity_state_sampler_counter_and_learning_rate_changes')
    check_masks()
    checks.append('original_mask_source_hash_and_requested_policy_mixture')
    checks.append('structured_XUT_span_break_overlap_and_fallback_rng_contracts')
    check_scheduler_and_receipts()
    checks.append('queue_guard_worker_allocation_request_integrity_and_parent_rejection')
    check_export()
    checks.append('review_export_scope_manifest_checksums_and_checkpoint_identity')
    manifest = PACKAGE / 'PACKAGE_MANIFEST.json'
    if manifest.exists():
        import submit
        submit.package_digest()
        checks.append('package_manifest_integrity')
    print(json.dumps(dict(status='PASS', checks=checks,
                          legacy_chooser_in_local_mask_tests='synthetic test stub; not original sampler',
                          checkpoint_loaded=False, gpu_execution=False, scheduler_submission=False,
                          compute_node_checks='real legacy masking, tensor attention/closure, original checkpoint, long-route finite gradients'),
                     indent=2))


if __name__ == '__main__':
    main()
