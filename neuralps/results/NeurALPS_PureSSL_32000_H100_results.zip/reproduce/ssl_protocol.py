"""Pinned natural-only 26k -> 32k continuation protocol (stdlib at import)."""
from __future__ import annotations

import math

VERSION = "neuralps_pure_ssl_xut_26000_32000_20261111_v1"
PARENT_REL = "e1_ssl_continue30_v1_530757/best.pt"
PARENT_SHA = "9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f"
PARENT_STEP = 26000
END_STEP = 32000
UPDATES = END_STEP - PARENT_STEP
ATTENTION = "full_distance_with_radius6_clipped_bias"
TARGET_SHA = "d4571217575bba57d0ee20cd9e2511d5b1a0a792bac7b2caf33033b67816e9db"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def learning_rate(update):
    """Replay the encoder schedules of the original 1k and subsequent 5k runs.

    The original first-50-update warmup applied to its activity head, not the
    natural encoder objective. Every one of these 6,000 updates trains the
    encoder on 32 natural views. At updates 1000 and 1001 the LR is continuous.
    """
    require(isinstance(update, int) and not isinstance(update, bool)
            and 1 <= update <= UPDATES, "Continuation LR index must be 1..6000")
    if update <= 1000:
        return 1e-5 * (.25 + .75 * .5 * (1 + math.cos(math.pi * (update - 1) / 999)))
    extension_update = update - 1000
    return 2.5e-6 * (.4 + .6 * .5 * (1 + math.cos(math.pi * (extension_update - 1) / 4999)))


def validate_state(state, config, expected_step, torch):
    """Fail closed on incompatible, incomplete, or activity-trained resumes."""
    required = {"config", "step", "encoder_state", "encoder_optimizer", "sampler",
                "torch_rng", "cuda_rng", "counts", "targets_manifest", "target_means"}
    require(required <= state.keys(), "Pure-SSL checkpoint lacks required state")
    require(not {"activity_state", "activity_optimizer", "labelled"}.intersection(state),
            "Activity-trained state cannot resume this natural-only branch")
    require(state["config"] == config and config.get("version") == VERSION
            and config.get("activity_labels_used") is False
            and config.get("classifier_training") is False
            and config.get("attention") == ATTENTION
            and config.get("parent_step") == PARENT_STEP
            and config.get("parent_sha256") == PARENT_SHA
            and config.get("final_step") == END_STEP
            and config.get("steps") == UPDATES,
            "Pure-SSL checkpoint protocol/configuration differs")
    require(isinstance(expected_step, int) and PARENT_STEP <= expected_step <= END_STEP
            and state["step"] == expected_step, "Pure-SSL checkpoint step differs")
    sampler = state["sampler"]
    require(sampler["attempted"] - sampler["skipped"]
            == expected_step * config["settings"]["batch"],
            "Sampler accepted-view count and checkpoint step disagree")
    counts = state["counts"]
    require(isinstance(counts, dict)
            and all(isinstance(v, int) and v >= 0 for v in counts.values()),
            "Invalid cumulative masking counters")
    require(sum(v for k, v in counts.items() if k.startswith("mask_"))
            == (expected_step - PARENT_STEP) * config["settings"]["batch"],
            "Realized mask count and natural-update count disagree")
    require(torch.is_tensor(state["torch_rng"]) and len(state["cuda_rng"]) == 1,
            "Checkpoint must contain CPU RNG and exactly one CUDA RNG")
    optimizer = state["encoder_optimizer"]
    require(bool(optimizer["state"]) and len(optimizer["param_groups"]) == 2,
            "Encoder optimizer state is incomplete")
    if expected_step > PARENT_STEP:
        expected_lr = learning_rate(expected_step - PARENT_STEP)
        require(all(math.isclose(g["lr"], expected_lr, rel_tol=1e-9, abs_tol=0.)
                    for g in optimizer["param_groups"]),
                "Saved encoder LR differs from the pinned piecewise schedule")


def restore_training_state(state, model, encoder_opt, sampler, torch):
    model.load_state_dict(state["encoder_state"], strict=True)
    encoder_opt.load_state_dict(state["encoder_optimizer"])
    sampler.load_state_dict(state["sampler"])
    torch.set_rng_state(state["torch_rng"])
    torch.cuda.set_rng_state_all(state["cuda_rng"])
