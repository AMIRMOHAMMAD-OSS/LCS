#!/usr/bin/env python3
"""Export completed pure-SSL diagnostics for the Jean Zay -> Mac -> LCS handoff."""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import zipfile

from ssl_protocol import END_STEP, PARENT_SHA, PARENT_STEP, UPDATES

PACKAGE = Path(__file__).resolve().parent
PREFIX = 'neuralps_ssl26to32_'
RECEIPT = 'neuralps_ssl26to32_submission.json'


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            value.update(block)
    return value.hexdigest()


def export_review(root, out):
    root, out = Path(root).resolve(), Path(out).resolve()
    if out.parent != root or not out.name.startswith(PREFIX):
        raise ValueError('Expected a dedicated pure-SSL continuation output within the project')
    done = json.loads((out / 'COMPLETE.json').read_text())
    if (done.get('status') != 'PURE_SSL_CONTINUATION_COMPLETE'
            or done.get('step') != END_STEP or done.get('parent_step') != PARENT_STEP
            or done.get('additional_updates') != UPDATES
            or done.get('parent_sha256') != PARENT_SHA
            or done.get('candidate_checkpoint') != 'latest.pt'
            or done.get('candidate_sha256') != sha(out / 'latest.pt')):
        raise ValueError('Expected the verified completed pure-SSL step 32000 checkpoint')
    config = json.loads((out / 'config.json').read_text())
    if config.get('activity_labels_used') is not False:
        raise ValueError('Pure-SSL configuration must explicitly declare no activity-label use')
    entries = []
    required = ('COMPLETE.json', 'config.json', 'fixed_natural_views.json',
                'attention_baseline.json', 'parent_natural.json', 'natural_comparison.json',
                'natural_reference.json', 'progress.jsonl')
    for name in required:
        if not (out / name).is_file():
            raise ValueError('Missing completed diagnostic: ' + name)
        entries.append((out / name, name))
    for name in ('REQUEST.json', 'REQUEST.sha256', 'SUBMISSION.json'):
        if (out / name).is_file():
            entries.append((out / name, name))
    ref = json.loads((out / 'natural_reference.json').read_text())
    if ref.get('status') == 'COMPLETE':
        rows = out / 'natural_reference.jsonl.gz'
        if ref.get('rows') != rows.name or sha(rows) != ref.get('rows_sha256'):
            raise ValueError('Natural reference row checksum differs')
        entries.append((rows, rows.name))
    # Model snapshots stay on Jean Zay. Their immutable hashes and diagnostics travel.
    entries.extend((path, str(path.relative_to(out)))
                   for path in sorted((out / 'checkpoints').glob('*.json')))
    for path in sorted(PACKAGE.rglob('*')):
        if (path.is_file() and '__pycache__' not in path.parts
                and path.suffix in {'.py', '.json', '.sh', '.txt', '.md'}):
            entries.append((path, 'reproduce/' + str(path.relative_to(PACKAGE))))
    output = out / 'inspection.zip'
    temp = out / f'inspection.zip.{os.getpid()}.tmp'
    manifest = {}
    try:
        with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path, relative in entries:
                if path.is_symlink() or relative in manifest:
                    raise ValueError('Unexpected symbolic link or duplicate archive path: ' + relative)
                data = path.read_bytes()
                manifest[relative] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
                archive.writestr(relative, data)
            archive.writestr('REVIEW_MANIFEST.json', json.dumps(dict(
                schema='neuralps_pure_ssl_26k_to_32k_review_v1', run=out.name,
                checkpoint_included=False, candidate_sha256=done['candidate_sha256'],
                activity_labels_used=False,
                labelled_activity_evaluation_included=False,
                files=manifest), indent=2, sort_keys=True) + '\n')
        if temp.stat().st_size >= 95_000_000:
            raise ValueError('Review exceeds the 95 MB transfer limit; the completed checkpoint is preserved')
        with zipfile.ZipFile(temp) as archive:
            if archive.testzip() is not None:
                raise ValueError('Review ZIP integrity check failed')
        os.replace(temp, output)
        digest = sha(output)
        hash_tmp = out / f'inspection.sha256.{os.getpid()}.tmp'
        hash_tmp.write_text(digest + '  inspection.zip\n')
        os.replace(hash_tmp, out / 'inspection.sha256')
        return dict(path=str(output), sha256=digest, bytes=output.stat().st_size)
    finally:
        temp.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', nargs='?', type=Path)
    parser.add_argument('--root', type=Path, default=PACKAGE.parent)
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output
    if output is None:
        output = Path(json.loads((root / RECEIPT).read_text())['output'])
    output = Path(output).resolve()
    if output.parent != root or not output.name.startswith(PREFIX) or not output.is_dir():
        raise ValueError('Expected a dedicated pure-SSL continuation output within the project')
    with (output / 'run.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        result = export_review(root, output)
    print('RESULT_ZIP:', result['path'])
    print('RESULT_SHA256:', result['sha256'])


if __name__ == '__main__':
    main()
