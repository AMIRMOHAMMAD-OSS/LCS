#!/usr/bin/env python3
"""Continue the original natural-only 26,000 checkpoint for 6,000 pure SSL updates."""
from __future__ import annotations

import argparse
from collections import deque
import fcntl
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


PACKAGE = Path(__file__).resolve().parent
PREFIX = 'neuralps_ssl26to32_'
RECEIPT = 'neuralps_ssl26to32_submission.json'
from ssl_protocol import PARENT_REL, PARENT_SHA, PARENT_STEP, END_STEP, UPDATES, ATTENTION

PARENT_FIELDS = ('parent', 'parent_step', 'parent_sha256', 'selection_reason')
PARENT26 = Path(PARENT_REL)
TARGETS = Path('e1_ssl_targets_497189/manifest.json')
TARGETS_SHA = 'd4571217575bba57d0ee20cd9e2511d5b1a0a792bac7b2caf33033b67816e9db'
DEV_VIEWS_SHA = 'b0bf1d468865180abe88f8864863c1f41af006121ac9f1ce7239d677ed465f08'
DIGEST = re.compile(r'[0-9a-f]{64}')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    with path.open() as stream:
        return json.load(stream)


def dump(path, data):
    temporary = path.with_name(f'.{path.name}.{os.getpid()}.tmp')
    temporary.write_text(json.dumps(data, indent=2, sort_keys=True, allow_nan=False) + '\n')
    temporary.replace(path)


def package_digest():
    manifest = PACKAGE / 'PACKAGE_MANIFEST.json'
    entries = load(manifest)['files']
    for relative in ('submit.py', 'batch.sh', 'train.py', 'ssl_protocol.py',
                     'evaluation.py', 'ssl_changes.py', 'export_review.py', 'selftest.py'):
        require(relative in entries, f'Package manifest is missing {relative}')
    for relative, expected in entries.items():
        path = (PACKAGE / relative).resolve()
        require(path.is_relative_to(PACKAGE) and path.is_file() and sha(path) == expected,
                f'Package file changed or missing: {relative}')
    return sha(manifest)


def check_inputs(root):
    """Reuse original source and target identities; the trainer hashes bulk input data."""
    from train import BASE_HASHES

    for relative, expected in BASE_HASHES.items():
        source = root / relative
        require(source.is_file() and sha(source) == expected, f'Original training source differs: {source}')
    path = root / TARGETS
    require(path.is_file() and sha(path) == TARGETS_SHA, f'Original natural target manifest differs: {path}')
    manifest = load(path)
    for info in manifest['fingerprints']:
        source = Path(info['path']).resolve()
        require(source.is_relative_to(root), f'Original data path is outside the project: {source}')
        stat = source.stat()
        require((stat.st_size, stat.st_mtime_ns) == (info['bytes'], info['mtime_ns']),
                f'Original natural input changed: {source}')
        if source.suffix == '.sqlite3':
            require(not Path(str(source) + '-wal').exists(), f'Unexpected WAL on natural input: {source}')
    bank = path.with_name('targets.npz')
    require(bank.is_file(), f'Target bank missing: {bank}')
    views = (root / PARENT26).with_name('dev_views.json')
    require(views.is_file() and sha(views) == DEV_VIEWS_SHA, f'Original development views differ: {views}')
    return {'targets_manifest_sha256': TARGETS_SHA, 'dev_views_sha256': DEV_VIEWS_SHA,
            'natural_train': len(manifest['ids']['train']), 'natural_dev': len(manifest['ids']['dev']),
            'activity_labels_used': False, 'labelled_assets_required': False,
            'large_input_hashes': 'verified on compute node before training'}


def select_parent(root, explicit=None, expected=None):
    """Validate the exact original checkpoint bytes without importing Torch."""
    pinned = (root / PARENT26).resolve()
    candidate = explicit.resolve() if explicit is not None else pinned
    require(candidate == pinned and pinned.is_relative_to(root),
            'Only the pinned original natural-only 26k checkpoint is accepted')
    require(expected is None or expected == PARENT_SHA,
            'The requested SHA differs from the pinned original 26k checkpoint')
    require(candidate.is_file() and sha(candidate) == PARENT_SHA,
            'Original 26k checkpoint missing or SHA-256 differs: ' + str(candidate))
    return dict(parent=str(candidate), parent_step=PARENT_STEP, parent_sha256=PARENT_SHA,
                selection_reason='exact original natural-only 26000 checkpoint; no fallback')


def verify_request_parent(root, request):
    current = select_parent(root, Path(request['parent']), request['parent_sha256'])
    require(all(current[key] == request[key] for key in PARENT_FIELDS if key != 'selection_reason'),
            'Pinned original parent differs from the launch request')
    require(request['steps'] == UPDATES and request['parent_step'] == PARENT_STEP,
            'This package extends step 26000 to step 32000 only')
    return current


def checked_output(root, output):
    output = output.resolve()
    require(output.parent == root and output.name.startswith(PREFIX) and output.is_dir(),
            f'Invalid pure-SSL output directory: {output}')
    return output


def read_request(root, output, digest):
    path = output / 'REQUEST.json'
    require(sha(path) == (output / 'REQUEST.sha256').read_text().strip(), 'Run request digest differs')
    request = load(path)
    require(request['root'] == str(root) and request['output'] == str(output)
            and request['package'] == str(PACKAGE) and request['package_manifest_sha256'] == digest,
            'Run path or package identity changed')
    return request


def check_queue(job_id, job_name):
    # Query the full user queue because a direct query for a finished job can error.
    result = subprocess.run(['squeue', '-h', '-u', getpass.getuser(), '-o', '%64i|%128j'],
                            capture_output=True, text=True, timeout=30, check=True)
    for row in result.stdout.splitlines():
        identifier, separator, name = row.partition('|')
        require(separator and identifier.strip() and name.strip() and '|' not in name,
                f'Unrecognized scheduler row: {row!r}')
        require(identifier.strip() != job_id and name.strip() != job_name,
                f'Allocation is already queued or running: {row}')


def concise_event(line):
    """Keep status readable when logs include full reference support tables."""
    try:
        event = json.loads(line)
    except (ValueError, TypeError):
        return line.rstrip()[:1200]
    if not isinstance(event, dict):
        return str(event)[:1200]
    keep = ('stage', 'status', 'step', 'parent_step', 'continuation_update',
            'additional_updates', 'elapsed_seconds', 'encoder_lr', 'anchor',
            'activity_labels_used', 'additional_natural_views',
            'candidate_checkpoint', 'candidate_sha256', 'heldout', 'diagnostics')
    result = {key: event[key] for key in keep if key in event}
    if isinstance(event.get('natural'), dict):
        result['natural'] = event['natural']
    return json.dumps(result or event, allow_nan=False)[:1800]


def status(receipt):
    record = load(receipt)
    output = Path(record['output'])
    print('Submission:', record['status'], '\nOutput:', output, flush=True)
    job_id = record.get('job_id', '')
    if job_id.isdigit():
        result = subprocess.run(['sacct', '-j', job_id, '--format=JobID,State,ExitCode,Elapsed'],
                                capture_output=True, text=True, timeout=30)
        print(result.stdout.strip() or result.stderr.strip(), flush=True)
        log = output / f'slurm_{job_id}.log'
        print('Log:', log, flush=True)
        if log.is_file():
            with log.open(errors='replace') as stream:
                for line in deque(stream, maxlen=6):
                    print(concise_event(line), flush=True)
    progress = output / 'progress.jsonl'
    if progress.is_file():
        with progress.open(errors='replace') as stream:
            for line in deque(stream, maxlen=1):
                print('Latest progress:', concise_event(line), flush=True)
    completion = output / 'COMPLETE.json'
    if completion.is_file():
        print('COMPLETE.json:', concise_event(completion.read_text()), flush=True)
    if (output / 'inspection.zip').is_file():
        print('RESULT_ZIP:', output / 'inspection.zip', flush=True)
        if (output / 'inspection.sha256').is_file():
            print('RESULT_SHA256:', (output / 'inspection.sha256').read_text().split()[0], flush=True)
    for name in ('pause.json', 'fatal_error.json'):
        path = output / name
        if path.is_file():
            print(f'{name}: {path.read_text()[:6000]}', flush=True)


def submit(root, output, request, hours, previous=None):
    receipt = root / RECEIPT
    job_name = 'nrps_ssl26to32_' + sha(output / 'REQUEST.json')[:10]
    old_job = previous.get('job_id', '') if previous else ''
    check_queue(old_job, job_name)
    cmd = ['sbatch', '--parsable', f'--job-name={job_name}', '--account=nef@a100',
           '--partition=gpu_p5', '--qos=qos_gpu_a100-t3', '--nodes=1', '--ntasks=1',
           '--cpus-per-task=8', '--hint=nomultithread', '--gres=gpu:1', '--constraint=a100',
           f'--time={hours:02d}:00:00', '--signal=USR1@180', '--no-requeue', '--propagate=NONE',
           f'--chdir={root}', f'--output={output}/slurm_%j.log', f'--error={output}/slurm_%j.log',
           str(PACKAGE / 'batch.sh'), str(PACKAGE), str(root), str(output)]
    record = dict(request, status='SUBMITTING', job_name=job_name, command=cmd,
                  previous_jobs=previous.get('previous_jobs', []) + [old_job] if previous else [])

    def persist():
        dump(output / 'SUBMISSION.json', record)
        dump(receipt, record)

    persist()
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired) as exc:
        record.update(status='SUBMISSION_UNCERTAIN', error=str(exc))
        persist()
        raise RuntimeError('Slurm submission outcome is uncertain. Inspect squeue before retrying.') from exc
    job_id = result.stdout.strip().split(';', 1)[0]
    if result.returncode != 0 or not job_id.isdigit():
        record.update(status='REJECTED_OR_UNCERTAIN', stdout=result.stdout, stderr=result.stderr)
        persist()
        raise RuntimeError('Slurm did not confirm a job. Inspect the receipt and queue: ' + result.stderr)
    record.update(status='SUBMITTED', job_id=job_id)
    persist()
    print('SUBMITTED_JOB:', job_id, '\nOutput:', output, flush=True)
    print(f'Resources: 1 A100, 8 CPUs, maximum {hours} hours; 6000 natural updates, step 26000 -> 32000; no activity supervision',
          flush=True)
    print('Log:', output / f'slurm_{job_id}.log', flush=True)
    print('Status: python3 -B', PACKAGE / 'submit.py', 'status', flush=True)
    print('Follow log: python3 -B', PACKAGE / 'submit.py', 'logs --follow', flush=True)
    print('Resume interrupted allocation: python3 -B', PACKAGE / 'submit.py',
          'resume', output, flush=True)


def worker(root, output):
    require(os.environ.get('SLURM_JOB_ID', '').isdigit(), 'Run the worker in a Slurm allocation')
    output = checked_output(root, output)
    with (output / 'run.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        require(not (output / 'COMPLETE.json').exists(), 'Training is already complete')
        request = read_request(root, output, package_digest())
        require(check_inputs(root) == request['inputs'], 'Inputs differ from the submission')
        verify_request_parent(root, request)
        args = [sys.executable, '-B', str(PACKAGE / 'train.py'), '--root', str(root),
                '--out', str(output), '--parent', request['parent'],
                '--parent-step', str(request['parent_step']), '--parent-sha256', request['parent_sha256'],
                '--steps', str(request['steps'])]
        if (output / 'latest.pt').is_file():
            args.append('--resume')
        os.set_inheritable(lock.fileno(), True)
        os.execv(sys.executable, args)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('preflight', 'run', 'status', 'logs', 'resume', 'worker', 'export'))
    parser.add_argument('output', nargs='?', type=Path)
    parser.add_argument('--root', type=Path, default=PACKAGE.parent)
    parser.add_argument('--parent', type=Path)
    parser.add_argument('--parent-sha256')
    parser.add_argument('--steps', type=int, choices=(UPDATES,), default=UPDATES,
                        help='Exactly 6000 additional natural updates, ending at step 32000')
    parser.add_argument('--hours', type=int, choices=(1, 2, 3, 4), default=4)
    parser.add_argument('--follow', action='store_true', help='Follow the latest allocation log with logs')
    args = parser.parse_intermixed_args()
    if args.follow and args.action != 'logs':
        parser.error('--follow is only valid with logs')
    root = args.root.resolve()
    receipt = root / RECEIPT
    if args.action == 'worker':
        require(args.output is not None, 'Worker requires an output directory')
        worker(root, args.output)
        return
    if args.action in ('status', 'logs', 'export'):
        selected = checked_output(root, args.output) if args.output else checked_output(root, Path(load(receipt)['output']))
        if args.action == 'status':
            status(selected / 'SUBMISSION.json')
        elif args.action == 'logs':
            record = load(selected / 'SUBMISSION.json')
            job_id = record.get('job_id', '')
            require(job_id.isdigit(), 'No confirmed allocation log is available')
            log = selected / f'slurm_{job_id}.log'
            if args.follow:
                os.execvp('tail', ['tail', '-n', '30', '-F', str(log)])
            require(log.is_file(), 'Log not created yet: ' + str(log))
            with log.open(errors='replace') as stream:
                for line in deque(stream, maxlen=30):
                    print(line.rstrip(), flush=True)
        else:
            from export_review import export_review
            with (selected / 'run.lock').open('a') as lock:
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                result = export_review(root, selected)
            print('RESULT_ZIP:', result['path'], flush=True)
            print('RESULT_SHA256:', result['sha256'], flush=True)
        return
    if args.action in ('run', 'preflight') and args.output is not None:
        parser.error('Output is assigned automatically for a new run')
    if args.parent_sha256 and not DIGEST.fullmatch(args.parent_sha256):
        parser.error('--parent-sha256 must be a lowercase SHA-256 digest')
    digest = package_digest()
    if args.action == 'preflight':
        parent = select_parent(root, args.parent, args.parent_sha256)
        print(json.dumps(dict(parent, inputs=check_inputs(root), package_manifest_sha256=digest,
                              additional_updates=args.steps, end_step=parent['parent_step'] + args.steps,
                              status='PREFLIGHT_OK', parent_step_validation='exact parent bytes verified; embedded state checked on compute',
                              attention=ATTENTION, activity_labels_used=False, classifier_training=False,
                              embedding_extraction=False, login_node_model_work=False),
                         indent=2), flush=True)
        return
    with (root / 'neuralps_ssl26to32_submission.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.action == 'run':
            if receipt.is_file():
                recorded = load(receipt)
                require(recorded.get('status') == 'SUBMITTED'
                        and recorded.get('job_id', '').isdigit(),
                        f'Existing submission outcome is unresolved. Inspect {receipt} and squeue before retrying.')
                print('Submission already recorded. Use status or resume.', flush=True)
                status(receipt)
                return
            inputs = check_inputs(root)
            parent = select_parent(root, args.parent, args.parent_sha256)
            stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
            output = root / (PREFIX + stamp + '_' + digest[:8])
            output.mkdir()
            request = dict(parent, root=str(root), output=str(output), package=str(PACKAGE),
                           package_manifest_sha256=digest, inputs=inputs, steps=args.steps)
            dump(output / 'REQUEST.json', request)
            (output / 'REQUEST.sha256').write_text(sha(output / 'REQUEST.json') + '\n')
            print(f"Parent step {parent['parent_step']}: {parent['parent']} ({parent['selection_reason']})",
                  flush=True)
            submit(root, output, request, args.hours)
            return
        require(args.parent is None and args.parent_sha256 is None,
                'The existing parent is fixed on resume')
        output = checked_output(root, args.output or Path(load(receipt)['output']))
        previous = load(output / 'SUBMISSION.json')
        require(previous['status'] == 'SUBMITTED' and previous.get('job_id', '').isdigit(),
                'Previous allocation was not confirmed. Inspect its receipt and the queue.')
        if (output / 'COMPLETE.json').is_file():
            status(output / 'SUBMISSION.json')
            return
        request = read_request(root, output, digest)
        require(check_inputs(root) == request['inputs'], 'Natural inputs differ from the submission')
        parent = verify_request_parent(root, request)
        with (output / 'run.lock').open('a') as run_lock:
            fcntl.flock(run_lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        # Release before sbatch so an immediately scheduled worker can take the lock.
        submit(root, output, request, args.hours, previous)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, subprocess.SubprocessError) as exc:
        sys.exit(f'ERROR: {exc}')
