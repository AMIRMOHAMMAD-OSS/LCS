#!/usr/bin/env python3
"""Compact, exact NeurALPS inputs. No labels, fitting, or activity scoring.

Feature banks passed as matrices must already be aligned to sequence_hashes.
Hash-keyed mappings are also supported. Importing this module requires NumPy,
but Torch is imported only by torch_batch.
"""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
STATES = {'NA': 0, 'OBSERVED': 1, 'EMPTY': 2, 'MISSING': 3, 'MASKED': 4}
REGISTRY_SHA256 = '5f0221a63d5f769ef10d746b8d63097082438b8e9feb5a92da5ad07db8eefe7d'
CONSTRUCTOR_SHA256 = 'a59df55260e23a7352c069010321140aaa17f2a259454808a8a5c1f0bcb00572'


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def model_signature(record):
    """Exactly core.neural_backend._route_fingerprint, including explicit states."""
    tokens = [(o['kind'], o['domain_type'] if o['kind'] == 0 else 0,
               o['chain'] if o['kind'] != 2 else -1) for o in record['route']]
    slots = sorted((s['object_index'], s['slot'], s['state'],
                    s['sequence_hash'] if s['state'] == 'OBSERVED' else None)
                   for s in record['model_slots'])
    return digest(dict(tokens=tokens, slots=slots))


def sequence_signature(record):
    """Physical-chain order matters; assembly identifiers are excluded."""
    uids = sorted(record['parent_sequence_hashes'], key=lambda uid: int(uid.rsplit('=', 1)[1]))
    return digest([record['parent_sequence_hashes'][uid] for uid in uids])


def load_constructor():
    path = HERE / 'vendor/build_multis.py'
    if file_sha256(path) != CONSTRUCTOR_SHA256:
        raise ValueError('Pinned constructor hash mismatch')
    spec = importlib.util.spec_from_file_location('pinned_multis_constructor', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_registry():
    path = HERE / 'inputs/verified_block_registry.json.gz'
    if file_sha256(path) != REGISTRY_SHA256:
        raise ValueError('Pinned block registry hash mismatch')
    with gzip.open(path, 'rt') as f:
        return json.load(f)


def reconstruct(donors, registry, constructor=None, assembly_id=None, sequence_sink=None):
    constructor = constructor or load_constructor()
    donors = list(donors)
    if len(donors) != 3 or any(d not in registry['blocks'][i] for i, d in enumerate(donors)):
        raise ValueError('Expected three registered donors (native is permitted)')
    aid = assembly_id or 'BODE2_' + '-'.join(donors)
    chains = constructor.compose_blocks([registry['blocks'][i][d] for i, d in enumerate(donors)])
    record, parents = constructor.build_record(aid, chains, sequence_sink)
    record.update(dataset='bode2', donors=donors,
                  plasmid_combination='-'.join(registry['sources'][i][d]['plasmid']
                                               for i, d in enumerate(donors)))
    return record, parents


def compact_records(records, sequence_hashes):
    """Pack records without expanding the 1,152-dimensional feature vectors."""
    records = list(records)
    if not records:
        raise ValueError('Empty record batch')
    hashes = [str(x) for x in sequence_hashes]
    if len(set(hashes)) != len(hashes):
        raise ValueError('Duplicate feature hash')
    rows = {h: i for i, h in enumerate(hashes)}
    b, t = len(records), max(len(r['route']) for r in records)
    out = dict(feature_row=np.full((b, t, 3), -1, np.int32),
               state=np.zeros((b, t, 3), np.uint8), kind=np.zeros((b, t), np.uint8),
               domain_type=np.zeros((b, t), np.uint8), chain=np.full((b, t), -1, np.int16),
               valid=np.zeros((b, t), bool), lengths=np.zeros(b, np.uint16),
               assembly_ids=np.array([r['assembly_id'] for r in records], dtype='U64'))
    for i, record in enumerate(records):
        n = len(record['route']); out['lengths'][i] = n; out['valid'][i, :n] = True
        for j, obj in enumerate(record['route']):
            kind = obj['kind']
            if kind not in (0, 1, 2):
                raise ValueError('Invalid route kind')
            out['kind'][i, j] = kind
            dt = obj['domain_type'] if kind == 0 else 0
            if not 0 <= dt < 32:
                raise ValueError('Invalid domain vocabulary ID')
            out['domain_type'][i, j] = dt
            out['chain'][i, j] = obj['chain'] if kind != 2 else -1
        seen = set()
        for slot in record['model_slots']:
            j, k = slot['object_index'], slot['slot']
            if not (0 <= j < n and 0 <= k < 3) or (j, k) in seen:
                raise ValueError('Invalid or duplicate model slot')
            seen.add((j, k))
            out['state'][i, j, k] = STATES[slot['state']]
            if slot['state'] == 'OBSERVED':
                out['feature_row'][i, j, k] = rows[slot['sequence_hash']]
    return out


def numpy_batch_from_compact(compact, indices, feature_bank, sequence_hashes):
    """Expand only the requested batch, matching legacy collate_records exactly."""
    indices = np.asarray(indices)
    if indices.ndim != 1 or not indices.size or not np.issubdtype(indices.dtype, np.integer):
        raise ValueError('Indices must be a nonempty one-dimensional integer sequence')
    if np.any(indices < 0) or np.any(indices >= len(compact['lengths'])):
        raise IndexError('Assembly index outside library')
    t = int(np.max(compact['lengths'][indices]))
    out = {k: np.asarray(compact[k][indices, :t], dtype=bool if k == 'valid' else np.int64)
           for k in ('state', 'kind', 'domain_type', 'chain', 'valid')}
    rows = compact['feature_row'][indices, :t]
    observed = (out['state'] == STATES['OBSERVED']) & out['valid'][..., None]
    if np.any(rows[observed] < 0):
        raise ValueError('Observed slot lacks a feature row')
    active = np.unique(rows[observed])
    if hasattr(feature_bank, 'keys'):
        vectors = np.stack([np.asarray(feature_bank[str(sequence_hashes[k])], np.float32) for k in active])
    else:
        bank = np.asarray(feature_bank)
        if bank.ndim != 2 or bank.shape != (len(sequence_hashes), 1152):
            raise ValueError('Feature bank must have shape (number of sequence hashes, 1152)')
        vectors = np.asarray(bank[active], np.float32)
    if vectors.shape != (len(active), 1152) or not np.isfinite(vectors).all() or np.any(np.abs(vectors).sum(axis=1) == 0):
        raise ValueError('Invalid observed cached vector')
    x = np.zeros((*rows.shape, 1152), np.float32)
    x[observed] = vectors[np.searchsorted(active, rows[observed])]
    out['x'] = x
    return out


class Library:
    def __init__(self, data_dir=None):
        self.data_dir = Path(data_dir) if data_dir is not None else HERE / 'data'
        with np.load(self.data_dir / 'model_indices.npz', allow_pickle=False) as z:
            self.arrays = {k: z[k] for k in z.files}
        self.sequence_hashes = self.arrays['sequence_hashes']
        self.registry = load_registry()
        self.constructor = load_constructor()
        self.donors = sorted(set(self.registry['blocks'][0]) - {'native'})
        if len(self) != 35 ** 3 or len(self.donors) != 35:
            raise ValueError('Incomplete 35-cubed library')

    def __len__(self):
        return len(self.arrays['lengths'])

    def get_record(self, index):
        if isinstance(index, bool) or not isinstance(index, (int, np.integer)) or not 0 <= index < len(self):
            raise IndexError('Assembly index outside library')
        n = len(self.donors)
        choice = [self.donors[index // (n * n)], self.donors[(index // n) % n], self.donors[index % n]]
        record, _ = reconstruct(choice, self.registry, self.constructor)
        if record['assembly_id'] != str(self.arrays['assembly_ids'][index]):
            raise ValueError('Library index identity mismatch')
        if model_signature(record) != str(self.arrays['model_signatures'][index]):
            raise ValueError('Recomposed model input signature mismatch')
        return record

    def numpy_batch(self, indices, feature_bank):
        return numpy_batch_from_compact(self.arrays, indices, feature_bank, self.sequence_hashes)

    def torch_batch(self, indices, feature_bank, device='cpu'):
        import torch
        return {k: torch.from_numpy(v).to(device) for k, v in self.numpy_batch(indices, feature_bank).items()}
