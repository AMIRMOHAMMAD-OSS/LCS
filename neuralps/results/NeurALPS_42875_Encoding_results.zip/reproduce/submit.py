#!/usr/bin/env python3
"""Submit one bounded A100 allocation to validate and encode 42,875 inputs.

This package does not train models, score compatibility, or submit follow-up jobs.
"""
import argparse
from collections import deque
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import time


HERE = Path(__file__).resolve().parent
PREFIX = 'neuralps_42875_encode_'
PREVIOUS_BANK = 'neuralps_patrick_multi_20261103T180935Z_c94bf80f/feature_bank'
REQUIRED = [
    'e0_cache_final_491894/features.f32',
    'e0_cache_final_491894/feature_index.sqlite3',
    'src/esmc_routeA_production.py',
    'models/ESMC-600M/model.safetensors',
    'envs/esmc_connections_hf/bin/python',
    'nrps_esmc_environment.sh',
    'NeurALPS_TDomain_Embed_20261006/CONTRACT.json',
    PREVIOUS_BANK + '/feature_bank.json',
    PREVIOUS_BANK + '/feature_bank.npz',
]


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    temporary.replace(path)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def preflight(root):
    # This import and cheap package validation use only the standard library.
    # Full package/data/cache/checkpoint hashes are checked in the allocation.
    from selftest import validate_package
    checked = validate_package(full=False)
    missing = [name for name in REQUIRED if not (root / name).is_file()]
    if missing:
        raise RuntimeError('Required recorded inputs missing: ' + ', '.join(missing))
    contract = read(root / 'NeurALPS_TDomain_Embed_20261006/CONTRACT.json')
    relative = contract['reference_manifest']
    reference = (root / relative).resolve()
    if root not in reference.parents or not reference.is_file():
        raise RuntimeError('Missing or unsafe historical embedding reference manifest')
    expected = contract['project_files_sha256'].get(relative)
    if not expected or sha(reference) != expected:
        raise RuntimeError('Historical embedding reference manifest checksum differs')
    return dict(package=checked, required_inputs=REQUIRED,
                embedding_reference=relative, embedding_reference_sha256=expected,
                large_asset_hashes='Verified inside allocation before use',
                scope='Reconstructed input validation and frozen ESM-C encoding only')


def command(root, out, request):
    return ['sbatch', '--parsable', '--job-name=nrps_42875_encode',
            '--account=nef@a100', '--partition=gpu_p5', '--qos=qos_gpu_a100-t3',
            '--nodes=1', '--ntasks=1', '--cpus-per-task=8', '--hint=nomultithread',
            '--gres=gpu:1', '--constraint=a100', '--time=02:00:00',
            '--no-requeue', '--propagate=NONE',
            '--chdir=' + str(root), '--output=' + str(out / 'slurm_%j.log'),
            '--error=' + str(out / 'slurm_%j.log'), str(HERE / 'batch.sh'),
            str(HERE), str(root), str(out), str(request)]


def status(info):
    job = info.get('job_id')
    if job:
        for cmd in (['squeue', '-j', job, '-o', '%.18i %.12P %.20j %.12T %.10M %.30R'],
                    ['sacct', '-j', job, '--format=JobID,State,ExitCode,Elapsed']):
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                print(result.stdout.strip() or result.stderr.strip(), flush=True)
            except (OSError, subprocess.TimeoutExpired) as exc:
                print('Scheduler status unavailable:', exc, flush=True)
    out = Path(info['output'])
    print('Submission:', info.get('status', 'UNKNOWN'), flush=True)
    print('Output:', out, flush=True)
    for relative in ('progress.json', 'feature_bank/progress.json', 'COMPLETE.json',
                     'PAUSED.json', 'fatal_error.json', 'BATCH_FAILURE.json'):
        path = out / relative
        if path.is_file():
            print(relative + ':', path.read_text(), flush=True)
    if job and (out / ('slurm_' + job + '.log')).is_file():
        with (out / ('slurm_' + job + '.log')).open(errors='replace') as stream:
            print(''.join(deque(stream, maxlen=16)), flush=True)
    if (out / 'inspection.zip').is_file():
        print('RESULT_ZIP:', out / 'inspection.zip', flush=True)
        print('RESULT_SHA256:', sha(out / 'inspection.zip'), flush=True)


def resolve_resume(root, output, receipt):
    info = read(receipt) if receipt.exists() else None
    if output is not None:
        out = output.resolve()
        if out.parent != root or not out.name.startswith(PREFIX):
            raise RuntimeError('Resume output must be an encoding directory directly under project root')
        if not info or info.get('output') != str(out):
            local_receipt = out / 'SUBMISSION.json'
            if not local_receipt.is_file():
                raise RuntimeError('No confirmed submission receipt in this output')
            info = read(local_receipt)
    if not info or not info.get('job_id'):
        raise RuntimeError('No confirmed prior job. Inspect SUBMISSION.json and squeue before retrying.')
    out = Path(info['output']).resolve()
    if out.parent != root or not out.name.startswith(PREFIX):
        raise RuntimeError('Resume receipt points outside the expected output directory')
    if info['root'] != str(root) or info['package_sha256'] != sha(HERE / 'PACKAGE_MANIFEST.json'):
        raise RuntimeError('Cannot resume with a different project or package')
    request_path = out / 'REQUEST.json'
    if sha(request_path) != (out / 'REQUEST.sha256').read_text().strip():
        raise RuntimeError('Resume request checksum differs')
    request = read(request_path)
    if (request['package'] != str(HERE) or request['output'] != str(out)
            or request['root'] != str(root)
            or request['package_sha256'] != info['package_sha256']):
        raise RuntimeError('Resume request names a different package, project, or output')
    result = subprocess.run(['squeue', '-h', '-j', info['job_id'], '-o', '%i %T'],
                            capture_output=True, text=True, timeout=30, check=True)
    if result.stdout.strip():
        raise RuntimeError('Previous allocation still queued/running: ' + result.stdout.strip())
    if (out / 'fatal_error.json').is_file() or (out / 'feature_bank/fatal_error.json').is_file():
        raise RuntimeError('Run failed an input/encoding integrity check. Inspect the failure before resuming.')
    return info, out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['preflight', 'run', 'resume', 'status'])
    parser.add_argument('output', type=Path, nargs='?', help='Existing output for resume or status')
    parser.add_argument('--root', type=Path, default=HERE.parent)
    args = parser.parse_args()
    root = args.root.resolve()
    receipt = HERE / 'SUBMISSION.json'
    if args.action == 'status':
        source = args.output.resolve() / 'SUBMISSION.json' if args.output else receipt
        if not source.is_file():
            raise RuntimeError('No submission recorded yet')
        status(read(source))
        return
    if args.output and args.action != 'resume':
        parser.error('An output directory is accepted only for resume/status')
    checked = preflight(root)
    print('PREFLIGHT_OK: package and recorded input paths; encoding only, no login-node model work', flush=True)
    if args.action == 'preflight':
        print(json.dumps(checked, indent=2))
        return
    with (HERE / 'submission.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        old = read(receipt) if receipt.exists() else None
        if args.action == 'run' and old:
            print('Already submitted; no duplicate allocation created. Use status or resume.', flush=True)
            status(old)
            return
        if args.action == 'resume':
            old, out = resolve_resume(root, args.output, receipt)
            if (out / 'COMPLETE.json').is_file():
                print('Encoding already complete; no new allocation created.', flush=True)
                status(old)
                return
        else:
            stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
            out = root / (PREFIX + stamp + '_' + sha(HERE / 'PACKAGE_MANIFEST.json')[:8])
            out.mkdir(exist_ok=False)
        request = out / 'REQUEST.json'
        if not request.exists():
            write(request, dict(root=str(root), output=str(out), package=str(HERE),
                                package_sha256=sha(HERE / 'PACKAGE_MANIFEST.json'), preflight=checked))
            (out / 'REQUEST.sha256').write_text(sha(request) + '\n')
        cmd = command(root, out, request)
        info = dict(status='SUBMITTING', root=str(root), output=str(out),
                    package_sha256=sha(HERE / 'PACKAGE_MANIFEST.json'), command=cmd,
                    previous_jobs=(old.get('previous_jobs', []) + [old['job_id']]) if old else [])
        write(receipt, info)
        write(out / 'SUBMISSION.json', info)
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        except (OSError, subprocess.TimeoutExpired) as exc:
            info.update(status='SUBMISSION_UNCERTAIN', error=str(exc))
            write(receipt, info)
            write(out / 'SUBMISSION.json', info)
            raise RuntimeError('Submission outcome uncertain; inspect squeue before another submission') from exc
        job = result.stdout.strip().split(';')[0]
        info.update(stdout=result.stdout.strip(), stderr=result.stderr.strip(), returncode=result.returncode)
        if result.returncode != 0 or not job.isdigit():
            info['status'] = 'REJECTED_OR_UNCERTAIN'
            write(receipt, info)
            write(out / 'SUBMISSION.json', info)
            raise RuntimeError('Slurm did not confirm a job:\n' + result.stdout + result.stderr)
        info.update(status='SUBMITTED', job_id=job)
        write(receipt, info)
        write(out / 'SUBMISSION.json', info)
        print('SUBMITTED_JOB:', job, flush=True)
        print('Resources: 1 A100, 8 CPUs, maximum 2 hours; no training or scoring', flush=True)
        print('Output:', out, flush=True)
        print('Status: python3 -B', HERE / 'submit.py', 'status', flush=True)
        print('Resume after an interrupted allocation: python3 -B', HERE / 'submit.py', 'resume', out, flush=True)


if __name__ == '__main__':
    main()
