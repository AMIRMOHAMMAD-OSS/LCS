#!/usr/bin/env python3
"""CPU structural and compact-index regression tests; no outcomes or fitting."""
import gzip
import importlib.util
import json
import sys
import unittest

import numpy as np

from build_library import known_roundtrip, validate_record
from library_io import (HERE, Library, compact_records, digest, file_sha256,
                        load_constructor, load_registry, model_signature,
                        numpy_batch_from_compact, reconstruct)

REQUIRE_TORCH = '--require-torch' in sys.argv
if REQUIRE_TORCH:
    sys.argv.remove('--require-torch')


class BuilderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.library = Library()
        cls.registry = load_registry()
        cls.constructor = load_constructor()
        with gzip.open(HERE/'inputs/known_multis_model_inputs.json.gz', 'rt') as f:
            cls.known = json.load(f)
        cls.audit = json.loads((HERE/'data/RECONSTRUCTION_AUDIT.json').read_text())

    def test_all60_registry_reconstruction_matches_cached_inputs(self):
        _, checks = known_roundtrip(self.registry, self.constructor)
        self.assertEqual(len(checks), 60)
        self.assertTrue(all(c['record_exact'] and c['parents_exact'] for c in checks))

    def test_full_stream_indices_and_known27_exact(self):
        """Stream all 42,875 outputs and compare every packed token and slot."""
        known = {r['assembly_id']:r for r in self.known['records'] if r['cohort']=='triples'}
        array = self.library.arrays
        hashes = self.library.sequence_hashes
        seen = set(); found = set(); n = 0
        with gzip.open(HERE/'data/assemblies.jsonl.gz', 'rt') as f:
            for i, line in enumerate(f):
                record = json.loads(line); aid = record['assembly_id']
                self.assertNotIn(aid, seen); seen.add(aid)
                self.assertEqual(aid, str(array['assembly_ids'][i]))
                self.assertEqual(model_signature(record), str(array['model_signatures'][i]))
                packed = compact_records([record], hashes)
                length = int(packed['lengths'][0])
                for key in ('feature_row', 'state', 'kind', 'domain_type', 'chain', 'valid'):
                    np.testing.assert_array_equal(packed[key][0], array[key][i,:length])
                if aid in known:
                    self.assertEqual(record, {k:known[aid][k] for k in record})
                    found.add(aid)
                n += 1
        self.assertEqual(n, 42875)
        self.assertEqual(found, set(known))

    def test_sorted_sequence_index_hash_and_content(self):
        with gzip.open(HERE/'data/unique_slot_sequences.json.gz','rt') as f:
            sequences = json.load(f)
        hashes = self.library.sequence_hashes.tolist()
        self.assertEqual(hashes, sorted(sequences))
        self.assertEqual(len(hashes),2602)
        self.assertEqual(digest(hashes),self.audit['sequence_index_hash'])
        for h, seq in sequences.items():
            self.assertEqual(self.constructor.sha(seq), h)
        np.testing.assert_array_equal(self.library.arrays['feature_row'] >= 0, self.library.arrays['state']==1)

    def test_random_access_and_cardinality(self):
        rng = np.random.default_rng(735)
        for i in [0, 42874, *rng.integers(0,42875,20).tolist()]:
            record = self.library.get_record(i)
            self.assertEqual(record['assembly_id'], str(self.library.arrays['assembly_ids'][i]))
        for invalid in [-1,42875,True,1.5]:
            with self.assertRaises(IndexError):
                self.library.get_record(invalid)
        self.assertEqual(self.audit['physical_chain_counts'], {'1':35937,'2':6534,'3':396,'4':8})
        self.assertEqual(self.audit['known_triple_constructs'],27)
        self.assertEqual(self.audit['novel_construct_ids'],42848)

    def test_numpy_expansion_exact_reference_all60(self):
        records = self.known['records']
        hashes = sorted({s['sequence_hash'] for r in records for s in r['model_slots'] if s['state']=='OBSERVED'})
        compact = compact_records(records, hashes)
        vectors = {h: np.full(1152, (i+1)/1000, np.float32) for i,h in enumerate(hashes)}
        out = numpy_batch_from_compact(compact, list(range(60)), vectors, hashes)
        for i, r in enumerate(records):
            n = len(r['route'])
            self.assertTrue(out['valid'][i,:n].all())
            self.assertFalse(out['valid'][i,n:].any())
            occupied = set()
            for s in r['model_slots']:
                j,k = s['object_index'],s['slot']; occupied.add((j,k))
                expected = vectors[s['sequence_hash']] if s['state']=='OBSERVED' else np.zeros(1152,np.float32)
                np.testing.assert_array_equal(out['x'][i,j,k],expected)
            for j in range(out['x'].shape[1]):
                for k in range(3):
                    if (j,k) not in occupied:
                        self.assertFalse(out['x'][i,j,k].any())
                        self.assertEqual(out['state'][i,j,k],0)

    def test_fail_closed_vectors_and_indices(self):
        hashes = self.library.sequence_hashes
        bank = np.ones((len(hashes),1152),np.float32)
        for indices in ([],[42875],[-1],[.5]):
            with self.assertRaises((ValueError,IndexError)):
                self.library.numpy_batch(indices,bank)
        with self.assertRaises(ValueError):
            self.library.numpy_batch([0],bank[:,:10])
        used = self.library.arrays['feature_row'][0]
        row = int(used[used>=0][0])
        bank[row,0]=np.nan
        with self.assertRaises(ValueError):
            self.library.numpy_batch([0],bank)
        bank[row]=0
        with self.assertRaises(ValueError):
            self.library.numpy_batch([0],bank)

    def test_no_fabricated_reproof_or_outcomes(self):
        self.assertFalse(self.audit['outcomes_loaded'])
        self.assertTrue(self.audit['historical106_roundtrip_proof_retained'])
        self.assertFalse(self.audit['historical106_rerun_from_raw_inputs'])
        historic = json.loads((HERE/'inputs/historical_roundtrip_audit.json').read_text())
        self.assertEqual(len(historic),106)

    def test_mature_parent_fasta_integrity(self):
        seen = set()
        current_hash, declared_length, pieces = None, None, []

        def check_parent():
            if current_hash is None:
                return
            sequence = ''.join(pieces)
            self.assertEqual(len(sequence), declared_length)
            self.assertEqual(self.constructor.sha(sequence), current_hash)
            self.assertNotIn(current_hash, seen)
            seen.add(current_hash)

        with gzip.open(HERE/'data/mature_parents.fasta.gz', 'rt') as f:
            for line in f:
                if line.startswith('>'):
                    check_parent()
                    fields = line[1:].split()
                    current_hash, declared_length, pieces = fields[0], int(fields[1].split('=')[1]), []
                else:
                    pieces.append(line.strip())
            check_parent()
        self.assertEqual(len(seen), self.audit['unique_mature_parent_sequences'])

    def test_data_checksums(self):
        for name, meta in self.audit['output_files'].items():
            path=HERE/'data'/name
            self.assertEqual(path.stat().st_size,meta['bytes'])
            self.assertEqual(file_sha256(path),meta['sha256'])

    def test_legacy_torch_collation_exact(self):
        if importlib.util.find_spec('torch') is None:
            if REQUIRE_TORCH:
                self.fail('--require-torch specified but Torch is not installed')
            self.skipTest('Torch absent; run --require-torch in the target environment')
        import torch
        path=HERE/'vendor_embed/legacy_assembly_model.py'
        spec=importlib.util.spec_from_file_location('independent_legacy_assembly_model',path)
        module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
        records=self.known['records']
        hashes=sorted({s['sequence_hash'] for r in records for s in r['model_slots'] if s['state']=='OBSERVED'})
        vectors={h:np.full(1152,(i+1)/1000,np.float32) for i,h in enumerate(hashes)}
        expected=module.collate_records(records,vectors.__getitem__)
        actual=numpy_batch_from_compact(compact_records(records,hashes),range(60),vectors,hashes)
        self.assertEqual(set(expected),set(actual))
        for k in expected:
            self.assertTrue(torch.equal(expected[k],torch.from_numpy(actual[k])),k)


if __name__ == '__main__':
    unittest.main(verbosity=2)
