#!/usr/bin/env bash
set -euo pipefail
NRPS_42875_PACKAGE="${1:?package directory}"
NRPS_42875_ROOT="${2:?project root}"
NRPS_42875_OUTPUT="${3:?output directory}"
NRPS_42875_REQUEST="${4:?request file}"
: "${SLURM_JOB_ID:?Submit through submit.py}"
NRPS_42875_PREVIOUS="$NRPS_42875_ROOT/neuralps_patrick_multi_20261103T180935Z_c94bf80f/feature_bank"
NRPS_42875_PY=$(command -v python3)
NRPS_42875_STAGE=environment_setup

function nrps_42875_failure() {
    local nrps_exit="$?"
    if [ "$nrps_exit" -ne 0 ]; then
        "$NRPS_42875_PY" -I -B - "$NRPS_42875_OUTPUT" "$NRPS_42875_STAGE" "$nrps_exit" <<'PY'
import json, os, sys, time, zipfile
from pathlib import Path
out, stage, code = sys.argv[1:]
out = Path(out)
failure = dict(stage=stage, exit_code=int(code), job_id=os.environ.get('SLURM_JOB_ID'),
               utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
               status='BATCH_FAILED_NOT_COMPLETE')
temporary = out / 'BATCH_FAILURE.json.tmp'
temporary.write_text(json.dumps(failure, indent=2) + '\n')
temporary.replace(out / 'BATCH_FAILURE.json')
# Return diagnostics even when tests fail before an encoder can start. A partial
# vector bank is deliberately not represented as a completed artifact.
temporary = out / 'inspection.zip.tmp'
with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as archive:
    candidates = list(out.glob('*.json')) + list(out.glob('*.sha256')) + list(out.glob('*.log'))
    candidates += list((out / 'feature_bank').glob('*.json'))
    for path in sorted(set(candidates)):
        if path.is_file() and not path.is_symlink():
            archive.write(path, str(path.relative_to(out)))
temporary.replace(out / 'inspection.zip')
print('BATCH_FAILURE:', json.dumps(failure), flush=True)
print('RESULT_ZIP:', out / 'inspection.zip', flush=True)
PY
    fi
    return "$nrps_exit"
}
trap nrps_42875_failure EXIT

module purge
module load arch/a100
module load pytorch-gpu/py3/2.8.0
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
NRPS_42875_PY=$(command -v python3)

function nrps_42875_stage() {
    NRPS_42875_STAGE="$1"
    "$NRPS_42875_PY" -I -B - "$NRPS_42875_OUTPUT" "$NRPS_42875_STAGE" <<'PY'
import json, os, sys, time
from pathlib import Path
out, stage = sys.argv[1:]
payload = dict(stage=stage, job_id=os.environ.get('SLURM_JOB_ID'),
               updated_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
path = Path(out) / 'progress.json'
temporary = path.with_suffix('.json.tmp')
temporary.write_text(json.dumps(payload, indent=2) + '\n')
temporary.replace(path)
print(json.dumps(payload), flush=True)
PY
}

nrps_42875_stage request_check
"$NRPS_42875_PY" -I -B - "$NRPS_42875_PACKAGE" "$NRPS_42875_ROOT" \
    "$NRPS_42875_OUTPUT" "$NRPS_42875_REQUEST" <<'PY'
import hashlib, json, os, sys
from pathlib import Path
package, root, out, request = map(lambda value: Path(value).resolve(), sys.argv[1:])
digest = hashlib.sha256(request.read_bytes()).hexdigest()
if digest != request.with_suffix('.sha256').read_text().strip():
    raise RuntimeError('Request changed')
payload = json.loads(request.read_text())
if (payload['package'] != str(package) or payload['root'] != str(root)
        or payload['output'] != str(out) or request != out / 'REQUEST.json'):
    raise RuntimeError('Request paths differ from submitted paths')
if payload['package_sha256'] != hashlib.sha256((package / 'PACKAGE_MANIFEST.json').read_bytes()).hexdigest():
    raise RuntimeError('Package manifest changed')
for name in ('BATCH_FAILURE.json', 'PAUSED.json'):
    path = out / name
    if path.exists():
        path.replace(out / (name + '.previous_' + os.environ['SLURM_JOB_ID']))
print('REQUEST_HASH_OK:', digest, flush=True)
PY

nrps_42875_stage package_and_reconstruction_tests
srun --ntasks=1 "$NRPS_42875_PY" -B "$NRPS_42875_PACKAGE/selftest.py" \
    --full --require-torch 2>&1 | tee "$NRPS_42875_OUTPUT/package_validation.log"
srun --ntasks=1 "$NRPS_42875_PY" -B "$NRPS_42875_PACKAGE/builder_tests.py" \
    --require-torch 2>&1 | tee "$NRPS_42875_OUTPUT/builder_tests.log"
nrps_42875_stage encoder_adapter_pretests
srun --ntasks=1 "$NRPS_42875_PY" -B "$NRPS_42875_PACKAGE/encoding_tests.py" \
    --library "$NRPS_42875_PACKAGE/data" --require-torch \
    --report "$NRPS_42875_OUTPUT/encoding_pretests.json" \
    2>&1 | tee "$NRPS_42875_OUTPUT/encoding_pretests.log"

nrps_42875_stage frozen_esmc_encoding
(
    # Reuse the already installed ESM-C environment. This subshell prevents its
    # environment changes from affecting the PyTorch 2.8 adapter checks below.
    set +u
    export TMPDIR="$NRPS_42875_OUTPUT/embedding_tmp"
    mkdir -p -- "$TMPDIR"
    export SQLITE_TMPDIR="$TMPDIR"
    source "$NRPS_42875_ROOT/nrps_esmc_environment.sh"
    export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
    srun --ntasks=1 "$NRPS_42875_ROOT/envs/esmc_connections_hf/bin/python" -B \
        "$NRPS_42875_PACKAGE/encode_library.py" --root "$NRPS_42875_ROOT" \
        --library "$NRPS_42875_PACKAGE/data" --out "$NRPS_42875_OUTPUT/feature_bank"
) 2>&1 | tee "$NRPS_42875_OUTPUT/encoding.log"

# A resumed run revalidates a complete bank. If extraction was interrupted before
# atomic publication, the encoder preserves that partial directory and reruns the
# missing-sequence extraction in a fresh temporary directory.
nrps_42875_stage encoded_input_parity_tests
srun --ntasks=1 "$NRPS_42875_PY" -B "$NRPS_42875_PACKAGE/encoding_tests.py" \
    --library "$NRPS_42875_PACKAGE/data" --require-torch \
    --feature-bank "$NRPS_42875_OUTPUT/feature_bank" --previous-bank "$NRPS_42875_PREVIOUS" \
    --report "$NRPS_42875_OUTPUT/encoding_posttests.json" \
    2>&1 | tee "$NRPS_42875_OUTPUT/encoding_posttests.log"

nrps_42875_stage package_results
"$NRPS_42875_PY" -I -B - "$NRPS_42875_PACKAGE" "$NRPS_42875_OUTPUT" <<'PY'
import hashlib, json, os, sys, time, zipfile
from pathlib import Path
import numpy as np
package, out = map(Path, sys.argv[1:])

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            digest.update(block)
    return digest.hexdigest()

bank = out / 'feature_bank'
if not (bank / 'feature_bank.json').is_file() or not (bank / 'feature_bank.npz').is_file():
    raise RuntimeError('Completed feature bank is missing')
metadata = json.loads((bank / 'feature_bank.json').read_text())
if metadata.get('status') != 'COMPLETE':
    raise RuntimeError('Feature bank is not marked complete')
with np.load(package / 'data/model_indices.npz', allow_pickle=False) as indices:
    count = int(len(indices['assembly_ids']))
    sequences = int(len(indices['sequence_hashes']))
if count != 42875:
    raise RuntimeError('Unexpected assembly count: ' + str(count))
artifacts = {str(path.relative_to(out)): sha(path) for path in sorted(bank.iterdir())
             if path.is_file() and not path.is_symlink()}
complete = dict(status='MODEL_INPUTS_READY_NO_SCORES', assemblies=count,
                unique_model_sequences=sequences, job_id=os.environ.get('SLURM_JOB_ID'),
                completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                package_sha256=sha(package / 'PACKAGE_MANIFEST.json'),
                model_indices_sha256=sha(package / 'data/model_indices.npz'),
                feature_bank_artifacts_sha256=artifacts,
                checks=['full_package_hashes', 'reconstruction_invariants',
                        'encoder_adapter_pretests', 'encoded_input_parity_tests'],
                training_performed=False, compatibility_scoring_performed=False,
                activity_prediction_performed=False)
complete_text = json.dumps(complete, indent=2, sort_keys=True) + '\n'
temporary = out / 'inspection.zip.tmp'
with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as archive:
    candidates = list(out.glob('*.json')) + list(out.glob('*.sha256')) + list(out.glob('*.log'))
    candidates += [path for path in bank.iterdir() if path.is_file()]
    for path in sorted(set(candidates)):
        if path.is_file() and not path.is_symlink() and path.name != 'COMPLETE.json':
            archive.write(path, str(path.relative_to(out)))
    archive.writestr('COMPLETE.json', complete_text)
    # The supplied input library remains on Jean Zay. Include the package's code
    # and small audit documents, plus the entire encoded feature bank above.
    for path in sorted(package.rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(package)
        if '__pycache__' in relative.parts or path.name in ('SUBMISSION.json', 'submission.lock'):
            continue
        if path.suffix in ('.py', '.sh', '.md', '.txt', '.json') and path.stat().st_size < (5 << 20):
            archive.write(path, 'reproduce/' + str(relative))
temporary.replace(out / 'inspection.zip')
result_sha = sha(out / 'inspection.zip')
# Publish run completion only after the inspection archive is safely written.
(out / 'COMPLETE.json.tmp').write_text(complete_text)
(out / 'COMPLETE.json.tmp').replace(out / 'COMPLETE.json')
(out / 'progress.json').write_text(json.dumps(dict(stage='COMPLETE', **complete), indent=2) + '\n')
print(json.dumps(complete, indent=2), flush=True)
print('RESULT_ZIP:', out / 'inspection.zip', flush=True)
print('RESULT_SHA256:', result_sha, flush=True)
PY
