"""CPU verification of encoding contracts and compact-to-model tensor parity.

--require-torch makes a missing PyTorch installation an error. Run that mode
under the project's PyTorch 2.8 module, separately from the ESM-C environment.
The optional --previous-bank checks actual historical vectors for all 60 cases;
--feature-bank additionally checks the completed 42,875-library bank.
"""
from __future__ import annotations

import argparse
import gzip
import importlib.util
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

import numpy as np
import encode_library as enc

HERE = Path(__file__).resolve().parent
ARGS = None
HAS_TORCH = importlib.util.find_spec("torch") is not None


def fake_cache(path, entries, rows):
    path.mkdir()
    np.array(rows, dtype="<f4").tofile(path / "features.f32")
    with sqlite3.connect(path / "feature_index.sqlite3") as db:
        db.execute("CREATE TABLE features(hash TEXT,feature_row INTEGER,status TEXT)")
        db.executemany("INSERT INTO features VALUES (?,?,?)", entries)


def vector(value):
    return np.full(enc.DIM, value, dtype=np.float32)


def synthetic_vectors(hashes):
    # Stable, distinct, finite vectors. Never used by a scientific scoring run.
    return {h: (np.arange(enc.DIM, dtype=np.float32) / 4096 + int(h[:6], 16) / 16777216 + 0.1).astype(np.float32)
            for h in hashes}


class EncodingUnitTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name)
        self.sequences = {enc.seqsha(s): s for s in ("ACD", "EFG", "HIK")}
        self.hashes = sorted(self.sequences)

    def tearDown(self):
        self.tmp.cleanup()

    def test_main_then_old_then_missing_exact_order(self):
        a, b, c = self.hashes
        cache = self.path / "cache"
        fake_cache(cache, [(a, 0, "covered")], [vector(1)])
        result, provenance, missing, equal = enc.select_vectors(self.sequences, self.hashes, cache, 1,
                                                               {a: vector(1), b: vector(2)})
        self.assertTrue(np.array_equal(result[0], vector(1)))
        self.assertTrue(np.array_equal(result[1], vector(2)))
        self.assertTrue(np.isnan(result[2]).all())
        self.assertEqual([p["source"] for p in provenance], ["main_cache", "previous_60_bank", "new_sidecar"])
        self.assertEqual(missing, [(c, self.sequences[c])])
        self.assertEqual(equal, 2)

    def test_old_main_disagreement_fails(self):
        a = self.hashes[0]
        cache = self.path / "cache"
        fake_cache(cache, [(a, 0, "covered")], [vector(1)])
        with self.assertRaisesRegex(ValueError, "differs from its main-cache"):
            enc.select_vectors(self.sequences, self.hashes, cache, 1, {a: vector(2)})

    def test_uncovered_hash_reuses_old_or_becomes_missing(self):
        a = self.hashes[0]
        cache = self.path / "cache"
        fake_cache(cache, [(a, None, "missing")], [vector(1)])
        result, _, missing, _ = enc.select_vectors(self.sequences, self.hashes, cache, 1, {a: vector(2)})
        self.assertTrue(np.array_equal(result[0], vector(2)))
        self.assertEqual(len(missing), 2)

    def test_duplicate_cache_hash_fails(self):
        a = self.hashes[0]
        cache = self.path / "cache"
        fake_cache(cache, [(a, 0, "covered"), (a, 0, "covered")], [vector(1)])
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            enc.select_vectors(self.sequences, self.hashes, cache, 1, {})

    def test_invalid_cache_row_fails(self):
        cache = self.path / "cache"
        fake_cache(cache, [(self.hashes[0], 5, "covered")], [vector(1)])
        with self.assertRaisesRegex(ValueError, "feature row"):
            enc.select_vectors(self.sequences, self.hashes, cache, 1, {})

    def test_nonfinite_cached_vector_fails(self):
        cache = self.path / "cache"
        fake_cache(cache, [(self.hashes[0], 0, "covered")], [vector(np.nan)])
        with self.assertRaisesRegex(ValueError, "nonfinite"):
            enc.select_vectors(self.sequences, self.hashes, cache, 1, {})

    def test_zero_vector_fails(self):
        with self.assertRaisesRegex(ValueError, "zero vector"):
            enc.valid_vectors(np.zeros((1, enc.DIM), dtype=np.float32), 1)

    def test_float64_storage_fails(self):
        with self.assertRaisesRegex(ValueError, "dtype"):
            enc.valid_vectors(np.ones((1, enc.DIM), dtype=np.float64), 1)

    def test_sidecar_merge_uses_hash_mapping_not_order(self):
        cache = self.path / "sidecar"
        a, b, c = self.hashes
        fake_cache(cache, [(c, 0, "covered"), (a, 1, "covered")], [vector(3), vector(1)])
        matrix = np.stack([vector(np.nan), vector(2), vector(np.nan)])
        backend = dict(status="ESMC_SIDECAR_COMPLETE", feature_rows=2,
                       files_sha256={name: enc.sha(cache / name) for name in ("features.f32", "feature_index.sqlite3")})
        enc.merge_sidecar(cache, [(a, self.sequences[a]), (c, self.sequences[c])], self.hashes, matrix, backend)
        self.assertTrue(np.array_equal(matrix, np.stack([vector(1), vector(2), vector(3)])))

    def test_sidecar_missing_identity_fails(self):
        cache = self.path / "sidecar"
        a, b, c = self.hashes
        fake_cache(cache, [(b, 0, "covered")], [vector(1)])
        backend = dict(status="ESMC_SIDECAR_COMPLETE", feature_rows=1,
                       files_sha256={name: enc.sha(cache / name) for name in ("features.f32", "feature_index.sqlite3")})
        with self.assertRaisesRegex(ValueError, "identity mismatch"):
            enc.merge_sidecar(cache, [(a, self.sequences[a])], self.hashes, np.stack([vector(1)] * 3), backend)

    def test_wal_input_rejected(self):
        cache = self.path / "cache"
        fake_cache(cache, [], [vector(1)])
        Path(str(cache / "feature_index.sqlite3") + "-wal").touch()
        with self.assertRaisesRegex(ValueError, "WAL"):
            enc.readonly(cache / "feature_index.sqlite3")

    def test_backend_unchanged(self):
        self.assertEqual(enc.sha(HERE / "vendor_embed/embedding_backend.py"), enc.EMBED_BACKEND_SHA)
        self.assertEqual(enc.sha(HERE / "vendor_embed/legacy_assembly_model.py"),
                         "551772090b00a9bf0d5a44fa85a4014e103079c4dabd1f2b99259ed5441dd2f4")

    def test_completed_bank_identity_and_tamper_checks(self):
        bank = self.path / "bank"
        bank.mkdir()
        matrix = np.stack([vector(i + 1) for i in range(3)])
        np.savez(bank / "feature_bank.npz", hashes=np.array(self.hashes), vectors=matrix)
        enc.atomic_json(bank / "row_provenance.json", [])
        identity = {"fixture": "identity"}
        report = dict(schema="neuralps_42875_feature_bank_v1", status="COMPLETE", library_identity=identity,
                      feature_bank_sha256=enc.sha(bank / "feature_bank.npz"),
                      row_provenance_sha256=enc.sha(bank / "row_provenance.json"), source_cache_sha256=enc.CACHE_SHA,
                      previous_bank_sha256=enc.PREVIOUS_SHA, embedding_backend_sha256=enc.EMBED_BACKEND_SHA)
        enc.atomic_json(bank / "feature_bank.json", report)
        loaded, _ = enc.load_feature_bank(bank, self.hashes, identity)
        self.assertTrue(np.array_equal(loaded, matrix))
        with self.assertRaisesRegex(ValueError, "different inputs"):
            enc.load_feature_bank(bank, self.hashes, {"fixture": "other"})
        with (bank / "feature_bank.npz").open("ab") as stream:
            stream.write(b"tamper")
        with self.assertRaisesRegex(ValueError, "checksum"):
            enc.load_feature_bank(bank)


class LibraryEncodingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not (ARGS.library / "model_indices.npz").exists():
            raise ValueError("Built library not present; run build_library.py before encoding tests")
        import library_io
        cls.io = library_io
        cls.library = library_io.Library(ARGS.library)
        cls.sequences, cls.hashes, cls.identity = enc.load_library(ARGS.library)
        with gzip.open(HERE / "inputs/known_multis_model_inputs.json.gz", "rt") as stream:
            cls.known = json.load(stream)["records"]
        cls.synthetic = synthetic_vectors(cls.hashes)
        cls.final = None
        if ARGS.feature_bank is not None:
            cls.final, _ = enc.load_feature_bank(ARGS.feature_bank, cls.hashes, cls.identity)

    def test_sequence_inventory_hash_alignment(self):
        self.assertEqual(self.hashes, sorted(self.sequences))
        self.assertEqual(self.identity["assembly_count"], 35 ** 3)

    def test_known60_actual_bank_exact_reuse(self):
        if ARGS.previous_bank is None:
            self.skipTest("Supply --previous-bank for actual 60-case vector comparison")
        previous = enc.load_previous_bank(ARGS.previous_bank)
        wanted = {s["sequence_hash"] for r in self.known for s in r["model_slots"] if s["state"] == "OBSERVED"}
        self.assertTrue(wanted <= set(previous))
        if self.final is not None:
            position = {h: i for i, h in enumerate(self.hashes)}
            for h in wanted & set(position):
                self.assertTrue(np.array_equal(self.final[position[h]], previous[h]), h)
        self.assertEqual(len(self.known), 60)

    @unittest.skipUnless(HAS_TORCH, "PyTorch unavailable; rerun with --require-torch in project Torch module")
    def test_all60_legacy_collator_tensor_parity(self):
        from vendor_embed.legacy_assembly_model import collate_records
        import torch
        wanted = sorted({s["sequence_hash"] for r in self.known for s in r["model_slots"] if s["state"] == "OBSERVED"})
        bank = enc.load_previous_bank(ARGS.previous_bank) if ARGS.previous_bank is not None else synthetic_vectors(wanted)
        compact = self.io.compact_records(self.known, wanted)
        for start in range(0, len(self.known), 8):
            indices = list(range(start, min(start + 8, len(self.known))))
            expected = collate_records([self.known[i] for i in indices], bank.__getitem__)
            actual = self.io.numpy_batch_from_compact(compact, indices, bank, wanted)
            self.assertEqual(set(actual), set(expected))
            for key in actual:
                self.assertTrue(torch.equal(torch.as_tensor(actual[key]), expected[key]), (start, key))

    @unittest.skipUnless(HAS_TORCH, "PyTorch unavailable; rerun with --require-torch in project Torch module")
    def test_library_batches_12plus_cases_include_four_chains(self):
        from vendor_embed.legacy_assembly_model import collate_records, AssemblyEncoder, Config
        import torch
        with np.load(ARGS.library / "model_indices.npz", allow_pickle=False) as z:
            chain, valid, kind = z["chain"], z["valid"], z["kind"]
            domain_mask = valid & (kind == 0)
            physical_ids = np.unique(chain[domain_mask])
            chain_counts = sum(np.any(domain_mask & (chain == c), axis=1) for c in physical_ids)
        selected = []
        for count in (1, 2, 3, 4):
            candidates = np.flatnonzero(chain_counts == count).tolist()
            self.assertTrue(candidates, "Missing physical chain count " + str(count))
            selected.extend(candidates[:4])
        self.assertGreaterEqual(len(selected), 12)
        bank = self.final if self.final is not None else self.synthetic
        lookup = ({h: bank[i] for i, h in enumerate(self.hashes)} if isinstance(bank, np.ndarray) else bank)
        records = [self.library.get_record(i) for i in selected]
        expected = collate_records(records, lookup.__getitem__)
        actual = self.library.torch_batch(selected, bank, device="cpu")
        self.assertEqual(set(actual), set(expected))
        for key in actual:
            self.assertTrue(torch.equal(actual[key], expected[key]), key)
        one = self.library.torch_batch([selected[-1]], bank, device="cpu")
        domain_mask = one["valid"][0] & (one["kind"][0] == 0)
        self.assertEqual(len(torch.unique(one["chain"][0][domain_mask])), 4)
        # A fresh tiny architecture checks legal four-chain inputs/shapes only;
        # it has no fitted weights and produces no scientific score.
        torch.manual_seed(0)
        model = AssemblyEncoder(Config(width=32, heads=4, local_layers=1, global_layers=1, dropout=0.0)).eval()
        with torch.no_grad():
            hidden = model.features(one)
        self.assertEqual(tuple(hidden.shape), (1, one["valid"].shape[1], 32))
        self.assertTrue(bool(torch.isfinite(hidden).all()))


def main():
    global ARGS
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--library", type=Path, default=HERE / "data")
    parser.add_argument("--feature-bank", type=Path)
    parser.add_argument("--previous-bank", type=Path)
    parser.add_argument("--require-torch", action="store_true")
    parser.add_argument("--report", type=Path)
    ARGS = parser.parse_args()
    if ARGS.require_torch and not HAS_TORCH:
        parser.error("--require-torch requested, but PyTorch is unavailable; use the original PyTorch 2.8 module")
    suite = unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = dict(status="PASS" if result.wasSuccessful() else "FAIL", tests_run=result.testsRun,
                  skipped=[dict(test=str(test), reason=reason) for test, reason in result.skipped],
                  failures=len(result.failures), errors=len(result.errors), torch_available=HAS_TORCH,
                  actual_previous_bank_supplied=ARGS.previous_bank is not None,
                  completed_library_bank_supplied=ARGS.feature_bank is not None)
    if HAS_TORCH:
        import torch
        report["torch_version"] = torch.__version__
    if ARGS.report:
        enc.atomic_json(ARGS.report, report)
    print(json.dumps(report, sort_keys=True), flush=True)
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__":
    main()
