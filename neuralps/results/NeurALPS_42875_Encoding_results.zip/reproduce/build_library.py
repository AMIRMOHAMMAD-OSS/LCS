#!/usr/bin/env python3
"""Materialize 35^3 mature-protein hypotheses from the pinned block registry.

This builder retains the historical 106-source proof and independently
recomposes the 60 cached multi-exchange inputs exactly. The separate portable
audit under provenance/source_audit independently rechecks the original 106
source cases using their raw evidence; its results are reported separately.
No assay outcomes are loaded by this builder.
"""
import argparse
from collections import Counter
from contextlib import contextmanager
import csv
import gzip
import io
import itertools
import json
from pathlib import Path
import time

import numpy as np
from library_io import (HERE, compact_records, digest, file_sha256, load_constructor,
                        load_registry, model_signature, reconstruct, sequence_signature)


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


@contextmanager
def gzip_text(path):
    # Write off-path and close every layer before publication. Besides preventing
    # incomplete readers, this prevents sync clients from publishing live streams.
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    with open(temporary, 'wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed:
            with io.TextIOWrapper(compressed, encoding='utf-8', newline='') as text:
                yield text
    temporary.replace(path)


def validate_record(record, parents, sequences):
    """Check all parent/slot sequences, coordinates, physical topology, and provenance."""
    import hashlib
    sha = lambda s: hashlib.sha256(s.encode()).hexdigest()
    uids = sorted(record['parent_sequence_hashes'], key=lambda u: int(u.rsplit('=', 1)[1]))
    assert len(uids) == record['n_chains']
    for uid in uids:
        ph = record['parent_sequence_hashes'][uid]; seq = parents[ph]
        assert sha(seq) == ph and len(seq) == record['parent_lengths'][uid]
        cursor = 0
        for source in record['physical_parent_source_slices'][uid]:
            assert source['target_start'] == cursor
            cursor = source['target_end']
            assert cursor - source['target_start'] == source['source_end'] - source['source_start']
        assert cursor == len(seq)
    domains = [o for o in record['route'] if o['kind'] == 0]
    assert len(domains) == record['n_domains'] and len(record['route']) == 2 * len(domains) - 1
    for j, obj in enumerate(record['route']):
        assert obj['kind'] == 0 if j % 2 == 0 else obj['kind'] in (1, 2)
        if obj['kind'] == 0:
            seq = parents[record['parent_sequence_hashes'][obj['protein_uid']]]
            a, b = obj['start_aa_0based'], obj['end_aa_0based_exclusive']
            assert 0 <= a < b <= len(seq) and sha(seq[a:b]) == obj['seq_hash']
        else:
            left, right = record['route'][j-1], record['route'][j+1]
            assert (obj['kind'] == 2) == (left['protein_uid'] != right['protein_uid'])
            assert obj['chain'] == (-1 if obj['kind'] == 2 else left['chain'])
    assert sum(o['kind'] == 2 for o in record['route']) == record['n_chains'] - 1
    locations = set()
    for slot in record['model_slots']:
        j, k = slot['object_index'], slot['slot']; obj = record['route'][j]
        assert (j, k) not in locations; locations.add((j, k))
        assert slot['kind'] == obj['kind']
        assert k == 0 if obj['kind'] != 2 else k in (1, 2)
        seq = parents[slot['parent_sequence_hash']]
        a, b = slot['start'], slot['end']
        assert 0 <= a <= b <= len(seq) and b-a == slot['length']
        fragment = seq[a:b]
        assert slot['parent_sequence_hash'] == record['parent_sequence_hashes'][slot['protein_uid']]
        if slot['state'] == 'OBSERVED':
            assert sha(fragment) == slot['sequence_hash'] and sequences[slot['sequence_hash']] == fragment
        else:
            assert slot['state'] == 'MISSING' and slot['sequence_hash'] is None
        assert (slot['state'] == 'OBSERVED') == (len(fragment) >= (1 if obj['kind'] == 0 else 3))
    assert len(locations) == len(record['route']) + record['n_chains'] - 1


def known_roundtrip(registry, constructor):
    path = HERE / 'inputs/known_multis_model_inputs.json.gz'
    expected_sha = '8c1649dd790f0f590049567df73ec7ec4bda48990ad3b8bbf87a8551db908cd5'
    assert file_sha256(path) == expected_sha
    with gzip.open(path, 'rt') as stream:
        known = json.load(stream)
    checks = []
    for old in known['records']:
        sequences = {}
        record, parents = reconstruct(old['donors'], registry, constructor, old['assembly_id'], sequences)
        assert {k: old[k] for k in record} == record, old['assembly_id']
        assert all(known['parents'][h] == seq for h, seq in parents.items())
        validate_record(record, parents, sequences)
        checks.append(dict(assembly_id=record['assembly_id'], donors=record['donors'],
                           cohort=old['cohort'], record_exact=True, parents_exact=True,
                           model_signature=model_signature(record)))
    assert len(checks) == 60 and Counter(r['cohort'] for r in checks) == {'doubles': 33, 'triples': 27}
    return known, checks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-dir', type=Path, default=HERE / 'data')
    args = parser.parse_args()
    output = args.output_dir; output.mkdir(parents=True, exist_ok=True)
    if (output / 'assemblies.jsonl.gz').exists():
        raise SystemExit('Output already contains assemblies; choose a new output directory.')
    start = time.monotonic()
    registry, constructor = load_registry(), load_constructor()
    donors = sorted(set(registry['blocks'][0]) - {'native'})
    assert len(donors) == 35 and all(set(b) == set(donors) | {'native'} for b in registry['blocks'])
    for i in range(3):
        for d in donors:
            block = registry['blocks'][i][d]
            if i in (0, 1):
                assert block[-1]['sequence'].endswith(('LNR', 'NPC')[i])
            if i in (1, 2):
                assert block[0]['sequence'].startswith(('SAV', 'SEI')[i-1])
    known, checks = known_roundtrip(registry, constructor)
    write_json(output / 'known60_roundtrip_audit.json', checks)
    known_ids = {r['assembly_id'] for r in known['records'] if r['cohort'] == 'triples'}
    known_models = {model_signature(r) for r in known['records']}
    known_sequences = {sequence_signature(r) for r in known['records']}
    unique_sequences, parents = {}, {}
    chunks, inventory, chain_counts, state_counts = [], [], Counter(), Counter()
    first_sequence, first_model, seq_counts, model_counts = {}, {}, Counter(), Counter()
    first_seen_hashes = []
    first_seen_rows = {}
    # The complete record file retains provenance. Compact arrays duplicate no AA vectors.
    with gzip_text(output / 'assemblies.jsonl.gz') as stream:
        for index, choice in enumerate(itertools.product(donors, repeat=3)):
            record, ps = reconstruct(choice, registry, constructor, sequence_sink=unique_sequences)
            validate_record(record, ps, unique_sequences)
            for h, seq in ps.items():
                if h in parents:
                    assert parents[h] == seq
                parents[h] = seq
            for h in unique_sequences:
                if h not in first_seen_rows:
                    first_seen_rows[h] = len(first_seen_hashes); first_seen_hashes.append(h)
            # Only small integers/states are retained per construct in memory.
            packed = compact_records([record], first_seen_hashes)
            chunks.append(packed)
            mh, sh = model_signature(record), sequence_signature(record)
            first_model.setdefault(mh, record['assembly_id']); first_sequence.setdefault(sh, record['assembly_id'])
            model_counts[mh] += 1; seq_counts[sh] += 1
            chain_counts[record['n_chains']] += 1
            state_counts.update(s['state'] for s in record['model_slots'])
            inventory.append(dict(index=index, assembly_id=record['assembly_id'], donor_xut2=choice[0],
                donor_xut3=choice[1], donor_xut4=choice[2], plasmid_combination=record['plasmid_combination'],
                n_chains=record['n_chains'], n_domains=record['n_domains'], n_route_objects=len(record['route']),
                known27_construct=record['assembly_id'] in known_ids,
                novel_construct_id=record['assembly_id'] not in known_ids,
                model_input_seen_in_known60=mh in known_models,
                sequence_seen_in_known60=sh in known_sequences,
                model_signature=mh, physical_sequence_signature=sh))
            stream.write(json.dumps(record, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n')
            if (index+1) % 2500 == 0:
                print(json.dumps(dict(stage='reconstruction', completed=index+1, total=35**3,
                                      unique_slot_sequences=len(unique_sequences), elapsed_s=round(time.monotonic()-start, 1))), flush=True)
    assert len(inventory) == 42875 and sum(r['known27_construct'] for r in inventory) == 27
    assert dict(chain_counts) == {1: 35937, 2: 6534, 3: 396, 4: 8}
    assert len(unique_sequences) == 2602
    sequence_hashes = sorted(unique_sequences)
    rows = {h: i for i, h in enumerate(sequence_hashes)}
    remap = np.array([rows[h] for h in first_seen_hashes] + [-1], dtype=np.int32)
    max_length = max(int(c['lengths'][0]) for c in chunks)
    final = dict(feature_row=np.full((42875, max_length, 3), -1, np.int32),
                 state=np.zeros((42875, max_length, 3), np.uint8),
                 kind=np.zeros((42875, max_length), np.uint8),
                 domain_type=np.zeros((42875, max_length), np.uint8),
                 chain=np.full((42875, max_length), -1, np.int16),
                 valid=np.zeros((42875, max_length), bool),
                 lengths=np.zeros(42875, np.uint16),
                 assembly_ids=np.array([r['assembly_id'] for r in inventory], dtype='U64'),
                 model_signatures=np.array([r['model_signature'] for r in inventory], dtype='U64'),
                 sequence_hashes=np.array(sequence_hashes, dtype='U64'))
    for i, chunk in enumerate(chunks):
        n = int(chunk['lengths'][0]); final['lengths'][i] = n
        for k in ('state', 'kind', 'domain_type', 'chain', 'valid'):
            final[k][i, :n] = chunk[k][0]
        final['feature_row'][i, :n] = remap[chunk['feature_row'][0]]
    assert np.all((final['feature_row'] >= 0) == (final['state'] == 1))
    with open(output / 'model_indices.npz.tmp', 'wb') as f:
        np.savez_compressed(f, **final)
    (output / 'model_indices.npz.tmp').replace(output / 'model_indices.npz')
    write_json(output / 'sequence_hashes.json', sequence_hashes)
    with gzip_text(output / 'unique_slot_sequences.json.gz') as f:
        json.dump(unique_sequences, f, sort_keys=True, separators=(',', ':'))
    with gzip_text(output / 'mature_parents.fasta.gz') as f:
        for h, sequence in sorted(parents.items()):
            f.write(f'>{h} length={len(sequence)}\n')
            for i in range(0, len(sequence), 80):
                f.write(sequence[i:i+80] + '\n')
    for row in inventory:
        mh, sh = row['model_signature'], row['physical_sequence_signature']
        row.update(model_duplicate_group_size=model_counts[mh], sequence_duplicate_group_size=seq_counts[sh],
                   model_representative=first_model[mh], sequence_representative=first_sequence[sh],
                   model_duplicate=model_counts[mh] > 1, sequence_duplicate=seq_counts[sh] > 1)
    with gzip_text(output / 'candidate_inventory.csv.gz') as f:
        writer = csv.DictWriter(f, fieldnames=list(inventory[0])); writer.writeheader(); writer.writerows(inventory)
    historical = json.loads((HERE/'inputs/historical_roundtrip_audit.json').read_text())
    assert len(historical) == 106 and all(all(r[k] for k in ('parent_hashes_exact', 'physical_breaks_exact',
        'domain_model_route_exact', 'model_slots_exact')) for r in historical)
    audit = dict(schema_version=1, status='FULL_42875_RECONSTRUCTION_AND_COMPACT_INDEX_COMPLETE',
        construction='hypothesized mature exteins after successful splicing; no activity or splicing predictions',
        outcomes_loaded=False, donor_count=35, candidates=42875, known_triple_constructs=27,
        novel_construct_ids=42848, known_double_controls_outside_library=33,
        known60_roundtrip_exact=True, historical106_roundtrip_proof_retained=True,
        historical106_rerun_from_raw_inputs=False,
        physical_chain_counts=dict(sorted(chain_counts.items())), unique_mature_parent_sequences=len(parents),
        unique_slot_sequences=len(unique_sequences), unique_physical_sequence_sets=len(seq_counts),
        unique_model_inputs=len(model_counts), max_route_objects=max_length,
        model_duplicate_candidates=sum(v for v in model_counts.values() if v > 1),
        sequence_duplicate_candidates=sum(v for v in seq_counts.values() if v > 1),
        novel_ids_matching_known60_model_inputs=sum(r['novel_construct_id'] and r['model_input_seen_in_known60'] for r in inventory),
        known27_identifiers=sorted(known_ids), state_counts=dict(state_counts),
        coordinate_topology_and_sequence_audits_passed=42875, compact_index_observed_rows_valid=True,
        sequence_index_hash=digest(sequence_hashes), model_signature_definition='exact core.neural_backend._route_fingerprint',
        source_pins={str(p.relative_to(HERE)): file_sha256(p) for p in sorted((HERE/'inputs').glob('*'))},
        constructor_sha256=file_sha256(HERE/'vendor/build_multis.py'),
        compact_arrays={k: dict(shape=list(v.shape), dtype=str(v.dtype)) for k,v in final.items()},
        elapsed_seconds=round(time.monotonic()-start, 1))
    audit['output_files'] = {p.name: dict(sha256=file_sha256(p), bytes=p.stat().st_size)
                             for p in sorted(output.iterdir()) if p.is_file() and p.name != 'RECONSTRUCTION_AUDIT.json'}
    write_json(output/'RECONSTRUCTION_AUDIT.json', audit)
    print(json.dumps(audit, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
