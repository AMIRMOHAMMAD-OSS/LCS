NeurALPS: complete 35 x 35 x 35 BODE2 input library
2026-11-03

WHAT IS COMPLETE
All 42,875 ordered donor triples have been reconstructed locally and exported.
Each uses one of the 35 verified donors at XUT2, XUT3 and XUT4. Repeated donor
identities are allowed. The 27 already measured triple IDs are marked in the
inventory; the other 42,848 named constructs are not marked as measured.
There are 42,875 distinct physical-sequence combinations and model inputs.

The reconstruction uses the verified positional block registry and the unchanged
constructor used for the 60 known multi-exchange cases. The independent source
audit reproduces all 106 single/native records and all 60 known multi records.
Its checks cover complete parent sequences, domain coordinates, physical chain
breaks, model slot sequences and the experimental donor/plasmid tuples.

No additional sequence upload is required for this representation. It represents
the mature extein proteins expected after successful intein splicing, preserving
internal protein breaks. It does not establish that unmeasured constructs splice,
express or function, and it is not a nucleotide cloning design.

The two splice interfaces are LNR|SAV and NPC|SEI. Golden Gate residues already
present in verified source sequences are retained exactly, with no additional
scar appended. In particular, old annotations called Ser-Ala actually contain
AS, and those actual residues are preserved. Source documentation and manuscript
provenance are in provenance/source_audit/.

PHYSICAL AND MODEL INVENTORY
One physical protein chain:    35,937 constructs
Two physical protein chains:   6,534 constructs
Three physical protein chains:   396 constructs
Four physical protein chains:      8 constructs
Distinct mature parent proteins: 40,569
Distinct domain/linker model sequences: 2,602
Maximum domain/connection route objects per construct: 43

WHAT STILL RUNS ON JEAN ZAY
Frozen ESM-C feature extraction for unique model sequences absent from both the
original main cache and the verified completed 60-case feature bank. Actual cache
hit/miss counts are determined on Jean Zay. This package does not perform model
training, compatibility-map inference or activity prediction.

Existing cached vectors are reused exactly. Each distinct sequence gets one
1,152-dimensional vector, shared by every construct that uses it. The compact
route arrays expand into the original model tensors only for the requested
batch. No enormous 42,875 x route-length x 3 x 1,152 feature file is needed.
The original frozen cache is opened read-only. New outputs have a separate path.

FILES
  data/assemblies.jsonl.gz
    Complete assembly records, domain annotations, physical topology, parent
    sequence hashes, source slices and model slots; one JSON object per line.
  data/mature_parents.fasta.gz
    Complete mature protein sequences deduplicated by SHA256. Record headers use
    the same parent hashes as assemblies.jsonl.gz.
  data/candidate_inventory.csv.gz
    Donor/plasmid tuples, known-27 flags, physical chain counts and exact sequence
    and model duplicate groups. These flags are metadata, not predictive inputs.
  data/model_indices.npz
    Compact feature-row, state, kind, domain-type, chain and validity arrays,
    assembly IDs, route lengths and sorted sequence hashes. No pickled objects.
  data/unique_slot_sequences.json.gz
    The 2,602 independent domain/connection amino-acid sequences keyed by SHA256.
  data/RECONSTRUCTION_AUDIT.json
    Cardinalities, source pins, full-library invariants and export checksums.
  library_io.py
    Exact random-access reconstruction and NumPy/Torch batch adapters.
  encode_library.py
    Frozen ESM-C extraction, source verification, shared feature-bank export.
  provenance/source_audit/
    Independent reconstruction verifier and portable original source evidence.
  PROTOCOL.json / PACKAGE_MANIFEST.json / LOCAL_VALIDATION.json
    Scope, immutable package hashes and local validation results.

The raw original source evidence retains original metadata for exact provenance;
activity outcomes are not used by reconstruction or encoding. Generated model
inputs and the embedding job do not use activity labels.

TRANSFER
If downloaded on Windows, first run in PowerShell:
  scp "$env:USERPROFILE\Downloads\NeurALPS_42875_Inputs_20261103.zip" amir@100.72.70.1:/Users/amir/Desktop/

Then run on the lab Mac (adjust the local download path if necessary):
  scp -J apandi@gate.lcqb.hosted.lip6.fr \
    /Users/amir/Desktop/NeurALPS_42875_Inputs_20261103.zip \
    unh87ms@jean-zay.idris.fr:/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/

The complete inputs archive is about 200 MiB, so transfer it directly rather than
attempting to commit it as a normal Git blob. The much smaller result inspection
ZIP can be returned through LCS after the run.

RUN ON JEAN ZAY
  cd /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2 &&
  unzip -n NeurALPS_42875_Inputs_20261103.zip &&
  python3 -B NeurALPS_42875_Inputs_20261103/selftest.py &&
  python3 -B NeurALPS_42875_Inputs_20261103/submit.py run

The wrapper requests one A100, eight CPUs, maximum two hours. It reuses the
existing PyTorch 2.8 module and installed ESM-C environment; no installation or
network download is performed. Full package hashes, reconstruction tests and
mandatory Torch batch parity checks run inside the allocation. The job stops
before encoding if these checks fail. Post-encoding tests verify the real vectors
and exact agreement with every shared vector from the known 60-case bank.

Status:
  python3 -B NeurALPS_42875_Inputs_20261103/submit.py status

Successful completion prints:
  MODEL_INPUTS_READY_NO_SCORES
  RESULT_ZIP: .../neuralps_42875_encode_.../inspection.zip
  RESULT_SHA256: ...

The result ZIP contains the full shared feature bank, source provenance,
validation logs and completion receipt. Send that ZIP through LCS for review
before the separate scoring step.

Running 'run' again does not submit a duplicate allocation. After an interrupted
allocation, inspect status and use:
  python3 -B NeurALPS_42875_Inputs_20261103/submit.py resume
A complete bank is reverified and reused. An incomplete extraction is retained
for diagnosis but restarted in a new temporary directory; partial vectors are
not silently accepted. A running/queued allocation cannot be resumed.

MODEL INPUT USE AFTER SUCCESSFUL ENCODING
From the extracted package directory, in a Python environment with NumPy/Torch:

  from pathlib import Path
  from library_io import Library
  from encode_library import load_library, load_feature_bank

  data = Path('data')
  sequences, hashes, identity = load_library(data)
  bank_dir = Path('/absolute/path/to/neuralps_42875_encode_RUN/feature_bank')
  vectors, report = load_feature_bank(bank_dir, hashes, identity)
  library = Library(data)
  batch = library.torch_batch([0, 1, 2], vectors, device='cuda')

batch contains x, state, kind, domain_type, chain and valid, matching the existing
collate_records contract. library.get_record(index) returns the full annotated
record for domain/linker map display. Scoring models/checkpoints are deliberately
not chosen or applied by this input package.

REPRODUCIBILITY
The complete files are already generated; reconstruction is not needed to submit.
To rebuild into a fresh directory using NumPy, consult:
  python3 -B build_library.py --help
Portable independent source check:
  python3 -B provenance/source_audit/audit_sources.py
Full package hash check:
  python3 -B selftest.py --full
Torch parity checks are mandatory on Jean Zay because Torch/GPU inference was not
available in the local preparation environment. LOCAL_VALIDATION.json separates
executed local checks from pending allocated-job checks.
