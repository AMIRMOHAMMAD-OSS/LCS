"""Standard-library package checks; no model load, training, or scoring.

Default checks file sizes and small-file hashes for a quick login-node preflight.
--full verifies every packaged byte and is mandatory inside the allocated job.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def validate_package(full=False):
    manifest = json.loads((HERE / 'PACKAGE_MANIFEST.json').read_text())
    files = manifest['files']
    sizes = manifest['bytes']
    require(set(files) == set(sizes), 'Manifest file/size sets differ')
    required = {'selftest.py', 'submit.py', 'batch.sh', 'build_library.py', 'library_io.py',
                'encode_library.py', 'builder_tests.py', 'encoding_tests.py', 'PROTOCOL.json',
                'data/RECONSTRUCTION_AUDIT.json', 'data/model_indices.npz',
                'data/assemblies.jsonl.gz', 'data/mature_parents.fasta.gz',
                'data/unique_slot_sequences.json.gz', 'inputs/verified_block_registry.json.gz'}
    require(required <= set(files), 'Required package files missing from manifest')
    checked = []
    deferred = []
    for name, expected in files.items():
        rel = Path(name)
        require(not rel.is_absolute() and '..' not in rel.parts, 'Unsafe manifest path')
        path = HERE / rel
        require(path.is_file() and not path.is_symlink(), 'Missing/linked package file: ' + name)
        require(path.stat().st_size == sizes[name], 'Package file size changed: ' + name)
        if full or sizes[name] <= (4 << 20):
            require(sha(path) == expected, 'Package checksum changed: ' + name)
            checked.append(name)
        else:
            deferred.append(name)
    protocol = json.loads((HERE / 'PROTOCOL.json').read_text())
    require(protocol['candidate_count'] == 35 ** 3, 'Candidate universe differs')
    require(protocol['training'] is False and protocol['activity_scoring'] is False,
            'This package must only reconstruct and embed')
    audit = json.loads((HERE / 'data/RECONSTRUCTION_AUDIT.json').read_text())
    require(audit['status'] == 'FULL_42875_RECONSTRUCTION_AND_COMPACT_INDEX_COMPLETE', 'Reconstruction is incomplete')
    require(audit['candidates'] == 42875 and audit['unique_slot_sequences'] == 2602, 'Reconstruction inventory differs')
    require(audit['known_triple_constructs'] == 27 and audit['known60_roundtrip_exact'] is True,
            'Known construct reconstruction differs')
    require(audit['coordinate_topology_and_sequence_audits_passed'] == 42875, 'Not all inputs were audited')
    with gzip.open(HERE / 'inputs/verified_block_registry.json.gz', 'rt') as stream:
        registry = json.load(stream)
    donor_sets = [sorted(k for k in block if k != 'native') for block in registry['blocks']]
    require(len(donor_sets) == 3 and all(len(x) == 35 for x in donor_sets), 'Donor library is not 35 x 35 x 35')
    require(donor_sets[0] == donor_sets[1] == donor_sets[2] == protocol['donor_ids'], 'Donor identities differ')
    with gzip.open(HERE / 'data/unique_slot_sequences.json.gz', 'rt') as stream:
        sequences = json.load(stream)
    require(len(sequences) == 2602, 'Unique sequence count differs')
    for key, sequence in sequences.items():
        require(hashlib.sha256(sequence.encode('ascii')).hexdigest() == key, 'Sequence hash differs')
        require(0 < len(sequence) <= 2046 and set(sequence) <= set('ACDEFGHIKLMNPQRSTVWY'),
                'Invalid amino-acid sequence')
    return {'status': 'PACKAGE_FULL_OK' if full else 'PACKAGE_PREFLIGHT_OK',
            'candidate_count': 42875, 'sequence_count': 2602,
            'files_hashed': len(checked), 'large_hashes_deferred_to_allocation': deferred,
            'training': False, 'activity_scoring': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--require-torch', action='store_true')
    args = parser.parse_args()
    result = validate_package(full=args.full)
    if args.require_torch:
        require(importlib.util.find_spec('torch') is not None, 'Allocated Torch environment is required')
        import torch
        result['torch_version'] = torch.__version__
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
