"""Unchanged historical ESM-C backend, checksum pinned by runtime.py."""
