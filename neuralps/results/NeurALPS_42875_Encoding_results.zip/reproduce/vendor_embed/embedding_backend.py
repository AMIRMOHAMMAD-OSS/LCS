"""Frozen ESM-C sidecar extraction; no activity scoring or parent embedding.

run_backend(root, out, rows, references, progress=None) requires an existing
output directory. rows contains (SHA256, amino-acid sequence) pairs. references
contains {hash, seq, length} records from the pinned historical repair manifest.
The optional progress callback receives one JSON-serializable event dictionary.
Exact pooling and length-dependent batch caps are loaded from the SHA-pinned
original producer's AST. Only these two function definitions are executed.
"""
from __future__ import annotations

import ast
import csv
import gzip
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sqlite3
import time

DIM = 1152
AA = frozenset("ACDEFGHIKLMNPQRSTVWY")
PRODUCER_SHA = "8948a0c221702e10117162d43fbf1f2caba7901fc5ad96ff37b164d6e18130bd"
CHECKPOINT_SHA = "e4232c30fd35fe2f57051ec88a703996ac94520580b4b836894207a3d45d9ff8"
FORK = "ef32577f55da19a4989cd7b22e004dc43a4998cb"
TRANSFORMERS_VERSION = "4.57.6"
POOLING = "mean final hidden state over actual amino-acid tokens; CLS/EOS/PAD excluded"
OUTPUT_NAMES = ("features.f32", "feature_index.sqlite3", "reference_comparison.json")


def _require(value, message):
    if not value:
        raise ValueError(message)


def _sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _seqsha(sequence):
    return hashlib.sha256(sequence.encode("ascii")).hexdigest()


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _write_json(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(_json(value) + "\n")
    os.replace(temporary, path)


def _emit(progress, stage, **values):
    event = dict(stage=stage, **values)
    if progress is None:
        print(_json(event), flush=True)
    else:
        progress(event)


def _validate_rows(rows, alphabet=AA):
    checked, seen = [], set()
    for digest, sequence in rows:
        _require(isinstance(sequence, str) and sequence and set(sequence) <= alphabet,
                 "Sequence alphabet differs from its input contract")
        _require(len(sequence) <= 2046, "Direct extraction requires at most 2046 residues")
        _require(isinstance(digest, str) and digest == _seqsha(sequence), "Feature sequence hash mismatch")
        _require(digest not in seen, "Duplicate feature sequence hash")
        seen.add(digest)
        checked.append((digest, sequence))
    _require(checked, "Empty feature extraction input")
    return sorted(checked, key=lambda row: (len(row[1]), row[0]))


def _load_original_functions(path, namespace):
    _require(_sha(path) == PRODUCER_SHA, "Frozen ESM-C producer checksum mismatch")
    tree = ast.parse(path.read_text(), filename=str(path))
    names = {"pooled_batch", "batch_size_for"}
    definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    _require(len(definitions) == 2 and {node.name for node in definitions} == names,
             "Original producer functions not found uniquely")
    for node in definitions:
        _require(not node.decorator_list, "Unexpected original function decorator")
    selected = ast.Module(body=definitions, type_ignores=[])
    exec(compile(ast.fix_missing_locations(selected), str(path), "exec"), namespace)
    return namespace["pooled_batch"], namespace["batch_size_for"]


def _check_tokens(tokenizer, sequences):
    encoded = tokenizer(sequences, padding=True, truncation=False, add_special_tokens=True,
                        return_special_tokens_mask=True)
    for sequence, ids, attention, special in zip(sequences, encoded["input_ids"],
                                               encoded["attention_mask"], encoded["special_tokens_mask"]):
        aa = [value for value, observed, is_special in zip(ids, attention, special) if observed and not is_special]
        _require(len(aa) == len(sequence), "Tokenizer residue count mismatch")
        _require(tokenizer.convert_ids_to_tokens(aa) == list(sequence), "Tokenizer residue round-trip mismatch")
        _require(ids[0] == tokenizer.cls_token_id and ids[len(sequence) + 1] == tokenizer.eos_token_id,
                 "Tokenizer CLS/EOS placement mismatch")
        _require(sum(bool(x) for x in attention) == len(sequence) + 2, "Unexpected special-token count")
    _require(max(len(ids) for ids in encoded["input_ids"]) <= 2048, "Tokenizer exceeded 2048 tokens")


def _is_cuda_oom(error, torch):
    return isinstance(error, torch.cuda.OutOfMemoryError) or (
        isinstance(error, RuntimeError) and "cuda out of memory" in str(error).lower())


def _infer_batches(records, pooled, batch_size, torch, progress, purpose, *, fixed_size=None):
    """Return CPU float32 rows; only CUDA OOM is eligible for batch halving."""
    result, log, start, reduced_cap = [], [], 0, None
    while start < len(records):
        allowed = fixed_size or batch_size("connections", len(records[start][1]))
        if reduced_cap is not None:
            allowed = min(allowed, reduced_cap)
        # Respect the original cap for every member, including boundary crossings.
        stop = start
        while stop < len(records) and stop - start < allowed:
            candidate_cap = fixed_size or batch_size("connections", len(records[stop][1]))
            if stop - start + 1 > candidate_cap:
                break
            allowed = min(allowed, candidate_cap)
            stop += 1
        size = stop - start
        _require(size >= 1, "Invalid extraction batch size")
        while True:
            batch = records[start:start + size]
            began = time.monotonic()
            fresh = None
            try:
                fresh = pooled([sequence for _, sequence in batch]).detach().cpu().float()
                _require(tuple(fresh.shape) == (size, DIM), "Unexpected pooled vector shape")
                _require(bool(torch.isfinite(fresh).all()), "Nonfinite pooled vector")
                _require(bool((fresh.norm(dim=1) > 0).all()), "Zero pooled vector")
            except RuntimeError as error:
                if not _is_cuda_oom(error, torch) or size == 1:
                    raise
                # Free the failed forward traceback before retrying.
                error.__traceback__ = None
                fresh = None
                torch.cuda.empty_cache()
                retry_size = max(1, size // 2)
                log.append(dict(purpose=purpose, start=start, requested_size=size,
                                status="CUDA_OOM_RETRY", next_size=retry_size))
                _emit(progress, "ESMC_BATCH_OOM_RETRY", purpose=purpose, start=start,
                      requested_size=size, next_size=retry_size)
                size = retry_size
                reduced_cap = size
                continue
            result.append(fresh)
            row = dict(purpose=purpose, start=start, size=size,
                       min_residues=min(len(s) for _, s in batch), max_residues=max(len(s) for _, s in batch),
                       status="COMPLETE", seconds=round(time.monotonic() - began, 4))
            log.append(row)
            start += size
            _emit(progress, "ESMC_BATCH_COMPLETE", completed=start, total=len(records), **row)
            break
    return torch.cat(result, dim=0), log


def _reference_vectors(root, references, torch):
    """Use historical domain shards: the smaller final store can omit these keys."""
    directory = root / "results/routeA_esmc600m_embeddings/domains"
    index = directory / "domains_embedding_index.tsv.gz"
    wanted = {r["hash"]: r for r in references}
    locations = {}
    with gzip.open(index, "rt", newline="") as stream:
        for row in csv.DictReader(stream, delimiter="\t"):
            digest = row["sequence_hash"]
            if digest not in wanted:
                continue
            _require(digest not in locations, "Duplicate historical reference index entry")
            _require(int(row["length"]) == wanted[digest]["length"], "Reference index length differs")
            shard, position = int(row["shard_index"]), int(row["row_index"])
            _require(shard >= 0 and position >= 0, "Invalid reference shard/row")
            locations[digest] = (shard, position)
    _require(set(locations) == set(wanted), "Historical domain cache lacks fixed references")
    cached, source_files = {}, {str(index.relative_to(root)): _sha(index)}
    for shard in sorted({position[0] for position in locations.values()}):
        path = directory / f"domains_shard_{shard:04d}.pt"
        source_files[str(path.relative_to(root))] = _sha(path)
        payload = torch.load(path, map_location="cpu", weights_only=True)
        expected_metadata = dict(kind="domains", pipeline_version="routeA_esmc600m_v1",
                                 model_name="ESMC-600M", inference_dtype="bfloat16",
                                 storage_dtype="float32", embedding_dimension=DIM, pooling=POOLING)
        for key, expected in expected_metadata.items():
            _require(payload.get(key) == expected, "Historical reference shard metadata differs: " + key)
        z = payload["embeddings"]
        _require(isinstance(z, torch.Tensor) and z.dtype == torch.float32 and z.ndim == 2 and z.shape[1] == DIM,
                 "Historical reference shard tensor shape/dtype differs")
        _require(len(payload["sequence_hashes"]) == len(payload["lengths"]) == len(z),
                 "Historical reference shard metadata length differs")
        for digest, (number, position) in locations.items():
            if number != shard:
                continue
            _require(position < len(z), "Historical reference index outside shard")
            _require(payload["sequence_hashes"][position] == digest and
                     int(payload["lengths"][position]) == wanted[digest]["length"],
                     "Historical reference index/shard identity mismatch")
            vector = z[position].clone()
            _require(bool(torch.isfinite(vector).all()) and float(vector.norm()) > 0,
                     "Invalid historical reference vector")
            cached[digest] = vector
        del payload, z
    return cached, dict(source="original_domain_shards", source_files_sha256=source_files,
                        locations={h: dict(shard=s, row=r) for h, (s, r) in locations.items()})


def run_backend(root: Path, out: Path, rows, references, progress=None):
    """Create a separate verified feature store; never touch original caches."""
    root, out = Path(root).resolve(), Path(out).resolve()
    _require(out.is_dir(), "Backend output directory must already exist")
    _require(not any((out / name).exists() for name in OUTPUT_NAMES), "Embedding outputs already exist")
    rows = _validate_rows(rows)
    references = list(references)
    _require(references, "Fixed cache reference gate must not be empty")
    # Historical repair references allowed uppercase amino-acid codes, including
    # unknown/rare codes if the tokenizer preserves them. New study inputs stay
    # restricted to the canonical 20-residue alphabet in the default path.
    _validate_rows([(r["hash"], r["seq"]) for r in references], alphabet=frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZ"))
    _require(all(type(r["length"]) is int and r["length"] == len(r["seq"]) for r in references),
             "Reference length differs from sequence")
    producer = root / "src/esmc_routeA_production.py"
    _require(_sha(producer) == PRODUCER_SHA, "Frozen producer checksum mismatch")
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    import numpy as np
    import torch
    import transformers
    from transformers import AutoConfig, AutoModel, AutoTokenizer
    from transformers.models.auto.modeling_auto import MODEL_MAPPING_NAMES
    _require(transformers.__version__ == TRANSFORMERS_VERSION, "Transformers version differs from pinned fork")
    dist = importlib.metadata.distribution("transformers")
    direct = json.loads(dist.read_text("direct_url.json") or "{}")
    _require(direct.get("vcs_info", {}).get("commit_id") == FORK, "Pinned Biohub Transformers commit not installed")
    _require(torch.cuda.is_available(), "A CUDA allocation is required for extraction")
    _require(torch.cuda.is_bf16_supported(), "CUDA device does not support BF16")
    model_dir = root / "models/ESMC-600M"
    _emit(progress, "ESMC_VERIFYING_CHECKPOINT", checkpoint=str(model_dir / "model.safetensors"))
    _require(_sha(model_dir / "model.safetensors") == CHECKPOINT_SHA, "ESM-C checkpoint checksum mismatch")
    cfg = AutoConfig.from_pretrained(model_dir, local_files_only=True)
    _require(cfg.model_type == "esmc" and cfg.d_model == DIM and cfg.n_layers == 36 and cfg.n_heads == 18,
             "Unexpected ESM-C architecture")
    tokenizer = AutoTokenizer.from_pretrained(model_dir, local_files_only=True)
    _require(type(tokenizer).__name__ == "ESMCTokenizer", "Unexpected tokenizer class")
    _require(MODEL_MAPPING_NAMES.get("esmc") == "ESMCModel", "Missing ESMCModel AutoModel mapping")
    _check_tokens(tokenizer, ["ACDEFGHIKLMNPQRSTVWY", "ACD", "A" * 512])
    for start in range(0, len(rows), 64):
        _check_tokens(tokenizer, [sequence for _, sequence in rows[start:start + 64]])
    _check_tokens(tokenizer, [r["seq"] for r in references])
    device = torch.device("cuda")
    _emit(progress, "ESMC_LOADING_MODEL", device=torch.cuda.get_device_name(device))
    model = AutoModel.from_pretrained(model_dir, dtype=torch.bfloat16, local_files_only=True)
    _require(type(model).__name__ == "ESMCModel", "Unexpected loaded ESM-C model class")
    model = model.to(device)
    model.eval()
    model.requires_grad_(False)
    _require(next(model.parameters()).dtype == torch.bfloat16, "Loaded model is not BF16")
    _require(not model.training and not any(p.requires_grad for p in model.parameters()), "Model is not frozen")
    torch.cuda.synchronize()
    pooled, batch_size = _load_original_functions(producer, dict(
        torch=torch, tokenizer=tokenizer, model=model, device=device, EMBED_DIM=DIM))
    cached, reference_provenance = _reference_vectors(root, references, torch)
    _emit(progress, "ESMC_REFERENCE_GATE_STARTED", references=len(references))
    ref_rows = [(r["hash"], r["seq"]) for r in references]
    fresh_refs, ref_batches = _infer_batches(ref_rows, pooled, batch_size, torch, progress,
                                            "historical_reference", fixed_size=4)
    comparisons = []
    for record, vector in zip(references, fresh_refs):
        old = cached[record["hash"]]
        cosine = float(torch.nn.functional.cosine_similarity(vector[None], old[None]))
        relative = float((vector - old).norm() / old.norm())
        comparisons.append(dict(hash=record["hash"], length=record["length"], cosine=cosine,
                                relative_l2=relative,
                                cached_vector_sha256=hashlib.sha256(old.numpy().astype("<f4").tobytes()).hexdigest()))
    minimum = min(r["cosine"] for r in comparisons)
    maximum = max(r["relative_l2"] for r in comparisons)
    gate = dict(status="PASS" if minimum >= .999 and maximum <= .02 else "FAIL",
                reference_count=len(references), min_cosine=minimum, max_relative_l2=maximum,
                cosine_threshold=.999, relative_l2_threshold=.02,
                interpretation="Historical provisional numerical tolerances; not bitwise equality.",
                comparisons=comparisons, batches=ref_batches, **reference_provenance)
    _write_json(out / "reference_comparison.json", gate)
    _emit(progress, "ESMC_REFERENCE_GATE_COMPLETE", status=gate["status"],
          min_cosine=minimum, max_relative_l2=maximum)
    _require(gate["status"] == "PASS", "Historical reference numerical gate failed; features not generated")
    features, batches = _infer_batches(rows, pooled, batch_size, torch, progress, "feature_extraction")
    array = np.asarray(features.numpy(), dtype="<f4", order="C")
    _require(array.shape == (len(rows), DIM) and np.isfinite(array).all() and
             (np.linalg.norm(array.astype(np.float64), axis=1) > 0).all(), "Final feature matrix invalid")
    feature_tmp = out / "features.f32.tmp"
    array.tofile(feature_tmp)
    _require(feature_tmp.stat().st_size == len(rows) * DIM * 4, "Feature file byte count differs")
    os.replace(feature_tmp, out / "features.f32")
    manifest = dict(schema="nrps_esmc_independent_feature_sidecar_v1", feature_rows=len(rows),
        embedding_dimension=DIM, model_name="ESMC-600M", model_path=str(model_dir),
        checkpoint_sha256=CHECKPOINT_SHA, producer_sha256=PRODUCER_SHA, fork_commit=FORK,
        pooling=POOLING, inference_dtype="bfloat16", storage_dtype="float32", storage_byte_order="little",
        feature_extraction_mode="independent_sequence", chunking="none_all_inputs_at_most_2046_residues",
        row_order="sequence_length_then_sha256", model_class=type(model).__name__,
        tokenizer_class=type(tokenizer).__name__, training=False, parent_sequences_embedded=False,
        torch_version=torch.__version__, torch_cuda=torch.version.cuda, device_name=torch.cuda.get_device_name(device),
        packages={name: importlib.metadata.version(name) for name in ("transformers", "tokenizers", "safetensors")},
        input_sequence_order_sha256=hashlib.sha256(_json([(h, len(s)) for h, s in rows]).encode()).hexdigest(),
        batch_policy="original_connections_caps_64_32_16; CUDA OOM only halving",
        batches=batches, reference_gate=dict(status=gate["status"], reference_count=len(references),
                                           min_cosine=minimum, max_relative_l2=maximum),
        model_auxiliary_files_sha256={p.name: _sha(p) for p in sorted(model_dir.iterdir())
                                     if p.is_file() and p.suffix in {".json", ".txt"}},
        files_sha256={"features.f32": _sha(out / "features.f32"),
                      "reference_comparison.json": _sha(out / "reference_comparison.json")})
    index_tmp = out / "feature_index.sqlite3.tmp"
    _require(not index_tmp.exists(), "Partial feature index already exists")
    with sqlite3.connect(index_tmp) as db:
        db.executescript("CREATE TABLE features(hash TEXT PRIMARY KEY,length INTEGER NOT NULL,"
                         "feature_row INTEGER UNIQUE NOT NULL,status TEXT NOT NULL);"
                         "CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);")
        db.executemany("INSERT INTO features VALUES(?,?,?,?)",
                       ((h, len(s), row, "covered") for row, (h, s) in enumerate(rows)))
        db.executemany("INSERT INTO metadata VALUES(?,?)", ((k, _json(v)) for k, v in manifest.items()))
        _require(db.execute("PRAGMA integrity_check").fetchone()[0] == "ok", "Feature index integrity failure")
        _require(db.execute("SELECT COUNT(*) FROM features").fetchone()[0] == len(rows), "Feature index count differs")
    db.close()
    os.replace(index_tmp, out / "feature_index.sqlite3")
    report = dict(status="ESMC_SIDECAR_COMPLETE", **manifest)
    # The index cannot contain its own checksum. Only the returned report does.
    report["files_sha256"] = dict(manifest["files_sha256"],
                                 **{"feature_index.sqlite3": _sha(out / "feature_index.sqlite3")})
    _emit(progress, "ESMC_SIDECAR_COMPLETE", feature_rows=len(rows), embedding_dimension=DIM,
          min_reference_cosine=minimum, max_reference_relative_l2=maximum)
    return report
