#!/usr/bin/env python3
"""Local mocked wrapper audit; submits no jobs and performs no real encoding.

All simulated inputs and receipts live in TemporaryDirectory instances. This is
an orchestration test, not evidence of Jean Zay execution or biological validity.
"""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from unittest.mock import patch


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_submission(package):
    source = package / 'submit.py'
    spec = importlib.util.spec_from_file_location('audited_submit', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    checks = []
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        mock_package = root / 'package'
        mock_package.mkdir()
        module.HERE = mock_package
        manifest = mock_package / 'PACKAGE_MANIFEST.json'
        manifest.write_text('{"files": {}}\n')
        out = root / (module.PREFIX + 'test')
        out.mkdir()
        request = out / 'REQUEST.json'
        module.write(request, dict(root=str(root), output=str(out), package=str(mock_package),
                                   package_sha256=module.sha(manifest)))
        (out / 'REQUEST.sha256').write_text(module.sha(request) + '\n')
        info = dict(root=str(root), output=str(out), package_sha256=module.sha(manifest),
                    job_id='123', status='SUBMITTED')
        receipt = mock_package / 'SUBMISSION.json'
        module.write(receipt, info)
        module.write(out / 'SUBMISSION.json', info)
        command = module.command(root, out, request)
        assert {'--gres=gpu:1', '--time=02:00:00', '--cpus-per-task=8',
                '--no-requeue', '--partition=gpu_p5'}.issubset(command)
        checks.append('bounded Slurm resources')
        empty = subprocess.CompletedProcess([], 0, '', '')
        with patch.object(module.subprocess, 'run', return_value=empty):
            assert module.resolve_resume(root, None, receipt)[1] == out
        checks.append('inactive intact run may resume')
        active = subprocess.CompletedProcess([], 0, '123 RUNNING\n', '')
        with patch.object(module.subprocess, 'run', return_value=active):
            try:
                module.resolve_resume(root, None, receipt)
            except RuntimeError as error:
                assert 'still queued/running' in str(error)
            else:
                raise AssertionError('active run accepted')
        checks.append('active run refuses duplicate')
        manifest.write_text('{"files": {}, "changed": true}\n')
        try:
            module.resolve_resume(root, None, receipt)
        except RuntimeError as error:
            assert 'different project or package' in str(error)
        else:
            raise AssertionError('changed manifest accepted')
        manifest.write_text('{"files": {}}\n')
        checks.append('changed package rejected')
        request.write_text(request.read_text() + ' ')
        try:
            module.resolve_resume(root, None, receipt)
        except RuntimeError as error:
            assert 'checksum differs' in str(error)
        else:
            raise AssertionError('changed request accepted')
        request.write_text(request.read_text()[:-1])
        checks.append('changed request rejected')
        (out / 'fatal_error.json').write_text('{}')
        with patch.object(module.subprocess, 'run', return_value=empty):
            try:
                module.resolve_resume(root, None, receipt)
            except RuntimeError as error:
                assert 'integrity check' in str(error)
            else:
                raise AssertionError('fatal run accepted')
        (out / 'fatal_error.json').unlink()
        checks.append('integrity failure blocks resume')
        with patch.object(module, 'preflight', return_value={}), \
                patch.object(module, 'status') as status, \
                patch.object(module.subprocess, 'run') as run, \
                patch.object(sys, 'argv', [str(source), 'run', '--root', str(root)]):
            module.main()
            run.assert_not_called()
            status.assert_called_once()
        checks.append('run receipt prevents duplicate')
        (out / 'COMPLETE.json').write_text('{}')
        with patch.object(module, 'preflight', return_value={}), \
                patch.object(module, 'status') as status, \
                patch.object(module.subprocess, 'run', return_value=empty) as run, \
                patch.object(sys, 'argv', [str(source), 'resume', '--root', str(root)]):
            module.main()
            assert run.call_count == 1 and run.call_args[0][0][0] == 'squeue'
            status.assert_called_once()
        checks.append('complete run does not resubmit')
        try:
            module.resolve_resume(root, root / 'outside', receipt)
        except RuntimeError as error:
            assert 'directly under project root' in str(error)
        else:
            raise AssertionError('bad output accepted')
        checks.append('output scope enforced')
    return checks


def mock_batch(package, fail_pretest):
    import zipfile
    import numpy as np
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        mock_package = root / 'package'
        out = root / 'out'
        mock_package.mkdir()
        out.mkdir()
        (mock_package / 'data').mkdir()
        manifest = mock_package / 'PACKAGE_MANIFEST.json'
        manifest.write_text('{"files": {}}')
        request = out / 'REQUEST.json'
        request.write_text(json.dumps(dict(package=str(mock_package), root=str(root),
                                           output=str(out), package_sha256=sha(manifest))))
        request.with_suffix('.sha256').write_text(sha(request))
        (mock_package / 'selftest.py').write_text(
            'raise SystemExit(7)\n' if fail_pretest else 'print("MOCK TEST PASS")\n')
        (mock_package / 'builder_tests.py').write_text('print("MOCK TEST PASS")\n')
        (mock_package / 'encoding_tests.py').write_text(
            'import sys,pathlib,json\na=sys.argv\n'
            'p=pathlib.Path(a[a.index("--report")+1]);'
            'p.write_text(json.dumps({"status":"PASS"}))\n')
        (mock_package / 'encode_library.py').write_text(
            'import sys,pathlib,json,numpy as np\na=sys.argv\n'
            'p=pathlib.Path(a[a.index("--out")+1]);p.mkdir();'
            '(p/"feature_bank.json").write_text(json.dumps({"status":"COMPLETE"}));'
            'np.savez(p/"feature_bank.npz",features=np.zeros((1,1152),dtype=np.float32))\n')
        np.savez(mock_package / 'data/model_indices.npz', assembly_ids=np.arange(42875),
                 sequence_hashes=np.array(['mock_sha']))
        (root / 'nrps_esmc_environment.sh').write_text(':\n')
        binary = root / 'envs/esmc_connections_hf/bin/python'
        binary.parent.mkdir(parents=True)
        binary.symlink_to(sys.executable)
        harness = ('module() { :; }; srun() { shift; "$@"; }; '
                   'export -f module srun; exec bash "$@"')
        result = subprocess.run(
            ['bash', '-c', harness, 'batch-harness', str(package / 'batch.sh'),
             str(mock_package), str(root), str(out), str(request)],
            env=dict(os.environ, SLURM_JOB_ID='test123'), capture_output=True, text=True)
        if fail_pretest:
            assert result.returncode == 7, (result.returncode, result.stdout, result.stderr)
            failure = json.loads((out / 'BATCH_FAILURE.json').read_text())
            assert failure['stage'] == 'package_and_reconstruction_tests'
            assert failure['exit_code'] == 7
            assert not (out / 'COMPLETE.json').exists()
            with zipfile.ZipFile(out / 'inspection.zip') as archive:
                assert 'BATCH_FAILURE.json' in archive.namelist()
            return 'failed pretest produces BATCH_FAILURE and inspection ZIP'
        assert result.returncode == 0, (result.returncode, result.stdout, result.stderr)
        complete = json.loads((out / 'COMPLETE.json').read_text())
        assert complete['status'] == 'MODEL_INPUTS_READY_NO_SCORES'
        assert complete['assemblies'] == 42875
        assert not (out / 'BATCH_FAILURE.json').exists()
        with zipfile.ZipFile(out / 'inspection.zip') as archive:
            assert 'feature_bank/feature_bank.npz' in archive.namelist()
            assert 'encoding_posttests.json' in archive.namelist()
            assert json.loads(archive.read('COMPLETE.json')) == complete
        return 'mocked full batch publishes complete bank and sealed inspection ZIP'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    package = args.package.resolve()
    ast.parse((package / 'submit.py').read_text())
    subprocess.run(['bash', '-n', str(package / 'batch.sh')], check=True)
    checks = ['Python AST syntax', 'Bash syntax'] + test_submission(package)
    checks.append(mock_batch(package, fail_pretest=True))
    checks.append(mock_batch(package, fail_pretest=False))
    result = dict(status='PASS', passed=len(checks), checks=checks,
                  scope='Mocked orchestration only; no Slurm job, real encoding, training, or scoring',
                  python=sys.version, numpy=__import__('numpy').__version__,
                  files_sha256={name: sha(package / name) for name in ('submit.py', 'batch.sh')},
                  audit_script_sha256=sha(Path(__file__).resolve()))
    if args.report:
        args.report.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
