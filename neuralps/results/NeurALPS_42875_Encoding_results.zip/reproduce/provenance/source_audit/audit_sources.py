#!/usr/bin/env python3
"""Independent audit: no production composer or feature builder is imported."""
import gzip
import hashlib
import itertools
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT
OLD = Path(__file__).resolve().parent / 'source_evidence'
OUT = Path(__file__).resolve().parent

def read(path):
    return json.load(gzip.open(path, 'rt') if path.suffix == '.gz' else path.open())

def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()

def file_sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def require(ok, msg):
    if not ok:
        raise AssertionError(msg)

registry_path = BASE / 'inputs/verified_block_registry.json.gz'
known_path = BASE / 'inputs/known_multis_model_inputs.json.gz'
label_path = OLD / 'known_multi_source_tuples.json'
registry = read(registry_path)
blocks, sources = registry['blocks'], registry['sources']
donors = sorted(set(blocks[0]) - {'native'})
require(len(donors) == 35 and all(set(donors) == set(b)-{'native'} for b in blocks), 'Donor sets differ')

def compose(choices):
    # Boundary labels are assigned from source block structure before forming chains.
    pieces = [(pi, si, fragment) for pi, donor in enumerate(choices)
              for si, fragment in enumerate(blocks[pi][donor])]
    chain_number = 0
    chain_pieces, all_domains = [[]], [[]]
    for n, (pi, si, fragment) in enumerate(pieces):
        if n and si > 0:  # Existing physical break inside the selected source block.
            chain_number += 1
            chain_pieces.append([])
            all_domains.append([])
        offset = sum(map(len, chain_pieces[chain_number]))
        chain_pieces[chain_number].append(fragment['sequence'])
        for d in fragment['domains']:
            all_domains[chain_number].append((
                d['start_aa_0based'] + offset,
                d['end_aa_0based_exclusive'] + offset,
                d['domain_type'], d['raw_domain_type'], d['canonical_domain_type'], d['seq_hash']))
    return [''.join(p) for p in chain_pieces], all_domains

def verify_record(record, choices):
    seqs, domains = compose(choices)
    uids = sorted(record['parent_sequence_hashes'], key=lambda s: int(s.rsplit('=', 1)[1]))
    require(len(uids) == len(seqs) == record['n_chains'], 'Physical chain count mismatch: '+record['assembly_id'])
    flat = []
    for ci, (uid, seq, expected_domains) in enumerate(zip(uids, seqs, domains)):
        require(sha(seq) == record['parent_sequence_hashes'][uid], 'Parent sequence mismatch: '+uid)
        require(len(seq) == record['parent_lengths'][uid], 'Parent length mismatch: '+uid)
        actual_domains = [(d['start_aa_0based'], d['end_aa_0based_exclusive'], d['domain_type'],
                           d['raw_domain_type'], d['canonical_domain_type'], d['seq_hash'])
                          for d in record['route'] if d['kind'] == 0 and d['protein_uid'] == uid]
        require(expected_domains == actual_domains, 'Domain annotation mismatch: '+uid)
        for d in expected_domains:
            require(sha(seq[d[0]:d[1]]) == d[-1], 'Domain residues mismatch: '+uid)
            flat.append((ci, uid, seq, d))
    expected_slots = []
    expected_kinds = []
    for di, (ci, uid, seq, dom) in enumerate(flat):
        if di:
            pci, puid, pseq, prev = flat[di-1]
            oi = len(expected_kinds)
            if pci != ci:
                expected_kinds.append(2)
                definitions = [(puid, pseq, max(prev[1], len(pseq)-64), len(pseq), 1, 'B:cterm'),
                               (uid, seq, 0, min(dom[0], 64), 2, 'B:nterm')]
            else:
                expected_kinds.append(1)
                lo, hi = sorted((prev[1], dom[0]))
                definitions = [(uid, seq, max(0,lo-20), min(len(seq),hi+20), 0, f'C:{prev[2]}:{dom[2]}')]
            for suid, sseq, lo, hi, role, group in definitions:
                length = hi-lo
                expected_slots.append(dict(object_index=oi,slot=role,kind=expected_kinds[-1],
                    state='OBSERVED' if length >= 3 else 'MISSING', sequence_hash=sha(sseq[lo:hi]) if length >= 3 else None,
                    length=length,protein_uid=suid,parent_sequence_hash=sha(sseq),start=lo,end=hi,group=group))
        oi = len(expected_kinds)
        expected_kinds.append(0)
        expected_slots.append(dict(object_index=oi,slot=0,kind=0,state='OBSERVED',sequence_hash=dom[-1],
            length=dom[1]-dom[0],protein_uid=uid,parent_sequence_hash=sha(seq),start=dom[0],end=dom[1],group='D:'+str(dom[2])))
    require(expected_kinds == [r['kind'] for r in record['route']], 'Boundary kinds mismatch')
    require(expected_slots == record['model_slots'], 'Model slots mismatch: '+record['assembly_id'])
    return dict(zip(uids, seqs))

original = {r['assembly_id']: r for r in map(json.loads, gzip.open(OLD/'routes.jsonl.gz', 'rt'))}
evidence = {r['assembly_id']: r for r in map(json.loads, gzip.open(OLD/'reconstruction_evidence.jsonl.gz', 'rt'))}
native_id = sources[0]['native']['source_assembly_id']
choices_by_source = {native_id: ['native']*3}
fragment_count = 0
for pi in range(3):
    for donor, fragments in blocks[pi].items():
        if donor != 'native':
            choice = ['native']*3
            choice[pi] = donor
            choices_by_source[sources[pi][donor]['source_assembly_id']] = choice
        require(fragments[0]['sequence'].startswith({0:'',1:'SAV',2:'SEI'}[pi]), 'Left splice scar mismatch')
        require(fragments[-1]['sequence'].endswith({0:'LNR',1:'NPC',2:''}[pi]), 'Right splice scar mismatch')
        for s in fragments:
            fragment_count += 1
            require(s['block_index'] == pi, 'Source position mismatch')
            require(s['source_end']-s['source_start'] == len(s['sequence']), 'Source interval length mismatch')
            require(s['source_assembly_id'] == sources[pi][donor]['source_assembly_id'], 'Source assembly mismatch')
            for d in s['domains']:
                a,b = d['start_aa_0based'],d['end_aa_0based_exclusive']
                require(0 <= a < b <= len(s['sequence']), 'Domain out of source slice')
                require(sha(s['sequence'][a:b]) == d['seq_hash'], 'Domain hash mismatch')
                orig = d['source_domain']
                require((orig['start_aa_0based'],orig['end_aa_0based_exclusive']) == (a+s['source_start'],b+s['source_start']), 'Domain offset mismatch')

source_parents = {}
scar_counts = Counter()
for aid, choices in choices_by_source.items():
    parents = verify_record(original[aid], choices)
    source_parents[aid] = parents
    ev = evidence[aid]
    require([x['protein_uid'] for x in ev['coding_intervals']] == list(parents), 'CDS order differs')
    for s in ev['scars']:
        residues = parents[s['protein_uid']][s['start_aa']:s['end_aa']]
        require(residues == s['sequence'], 'Annotated scar residues differ')
        scar_counts[s['source_label']+'='+residues] += 1
    for left,right in [('LNR','SAV'),('NPC','SEI')]:
        l = [s for s in ev['scars'] if s['source_label'] == left]
        r = [s for s in ev['scars'] if s['source_label'] == right]
        require(len(l)==len(r)==1 and l[0]['protein_uid']==r[0]['protein_uid'] and l[0]['end_aa']==r[0]['start_aa'], 'Splice annotation is not unique and contiguous')
for pi in range(3):
    for donor, fragments in blocks[pi].items():
        for s in fragments:
            full = source_parents[s['source_assembly_id']][s['source_protein_uid']]
            require(sha(full) == s['source_parent_sequence_hash'], 'Source parent hash differs')
            require(full[s['source_start']:s['source_end']] == s['sequence'], 'Source slice differs')

known = read(known_path)
labels = {r['assembly_id']:r for r in read(label_path)}
known_chain_counts = Counter()
for r in known['records']:
    verify_record(r,r['donors'])
    known_chain_counts[r['n_chains']] += 1
    label = labels[r['assembly_id']]
    require(r['donors'] == [label['donor_xut2'],label['donor_xut3'],label['donor_xut4']], 'Recorded donor tuple differs')
    plasmids = [sources[pi][d]['plasmid'] for pi,d in enumerate(r['donors'])]
    require('-'.join(plasmids) == label['plasmid_combination'], 'Recorded experimental plasmid tuple differs')
for h,s in known['parents'].items():
    require(sha(s)==h, 'Known parent hash differs')

prospective_chain_counts = Counter()
for choice in itertools.product(donors, repeat=3):
    prospective_chain_counts[1+sum(len(blocks[pi][d])-1 for pi,d in enumerate(choice))] += 1

report = {
 'status':'PASS',
 'method':'Independent implementation; no production composer or slot builder imported.',
 'original_records_reconstructed_exactly':len(choices_by_source),
 'original_records_cover_all_available':set(choices_by_source)==set(original)==set(evidence),
 'registry_position_donor_blocks':sum(map(len,blocks)),
 'registry_source_chain_slices_verified':fragment_count,
 'known_multis_reconstructed_exactly':len(known['records']),
 'known_multis_cohorts':dict(Counter(r['cohort'] for r in known['records'])),
 'known_multis_physical_chain_counts':dict(known_chain_counts),
 'prospective_designs':sum(prospective_chain_counts.values()),
 'prospective_physical_chain_counts':dict(sorted(prospective_chain_counts.items())),
 'internal_break_donors_by_position':[[d for d in donors if len(b[d])>1] for b in blocks],
 'original_annotated_scars_verified':dict(sorted(scar_counts.items())),
 'comparisons':['All physical parent sequence SHA256 hashes and lengths',
   'All domain interval/type/sequence hashes','All model slot definitions and sequence hashes',
   'All source slice coordinates and residues','All annotated scar residues',
   'Unique contiguous split-intein scar pairs','All 60 recorded donor and plasmid tuples'],
 'scope':'Design-implied mature protein model inputs, conditional on successful split-intein splicing; not newly sequenced proteins or DNA cloning designs.',
 'source_files':{str(p.relative_to(ROOT)):file_sha(p) for p in [registry_path,known_path,label_path,OLD/'routes.jsonl.gz',OLD/'reconstruction_evidence.jsonl.gz']}
}
(OUT/'INDEPENDENT_SOURCE_AUDIT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2,sort_keys=True))
