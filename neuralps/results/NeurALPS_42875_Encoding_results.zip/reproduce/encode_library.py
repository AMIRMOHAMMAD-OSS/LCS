"""Encode deduplicated model slots only; no scoring, fitting, or labels.

Run in the existing ESM-C environment. A completed output is immutable and may
be verified/reused. Interrupted attempts remain in a uniquely named .partial
sibling; a retry creates a fresh attempt without deleting any files. Only the
small K x 1152 feature bank is materialized, never an N x L x 3 x 1152 tensor.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
from datetime import datetime, timezone

import numpy as np

HERE = Path(__file__).resolve().parent
DIM = 1152
CACHE = "e0_cache_final_491894"
CACHE_ROWS = 548713
CACHE_SHA = {
    "features.f32": "5a7c2f3afd527785ce3c12eaa3b97138034f4dfc811d840b5b44cf1534b9ef90",
    "feature_index.sqlite3": "09a6bde676c2e22bcba78879cf53c1d1979d672bcc1763a9eb49e218f387735b",
}
PREVIOUS = "neuralps_patrick_multi_20261103T180935Z_c94bf80f/feature_bank"
PREVIOUS_SHA = {
    "feature_bank.npz": "b191191bf019a021fa50e44dc068f943296aa0dfd814313e548cd713e16010b7",
    "feature_bank.json": "217a2cac4594adca4bf8f05b1cb6f65191c178bcd4cd27ec33436cfeca8e7a2c",
}
EMBED_BACKEND_SHA = "7f265efe1ac8eafa97d1ad0b4e6b69145dbbd217a6c225a4a637c306a3ba1f4d"
CONTRACT = "NeurALPS_TDomain_Embed_20261006/CONTRACT.json"
CONTRACT_SHA = "0332de83d0b0682e6110dbe3b69302463ee955062bc59917d6ae293afa616bc8"
REFERENCE = "data/esmc_bode2_domains_v2/manifest.json"
REFERENCE_SHA = "77bdf6d21a4ea465cae437d690bebbfc7cdb05a77310cf48a8b1c02a0632b458"
CHECKPOINT_SHA = "e4232c30fd35fe2f57051ec88a703996ac94520580b4b836894207a3d45d9ff8"
PRODUCER_SHA = "8948a0c221702e10117162d43fbf1f2caba7901fc5ad96ff37b164d6e18130bd"
AA = frozenset("ACDEFGHIKLMNPQRSTVWY")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def seqsha(sequence):
    return hashlib.sha256(sequence.encode("ascii")).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")
    os.replace(temp, path)


def readonly(path):
    path = Path(path).resolve()
    require(not Path(str(path) + "-wal").exists(), "SQLite input has a WAL: " + str(path))
    db = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
    db.execute("PRAGMA query_only=ON")
    return db


def valid_vectors(matrix, rows):
    require(matrix.shape == (rows, DIM) and matrix.dtype == np.dtype("float32"), "Invalid feature dimensions/dtype")
    require(np.isfinite(matrix).all() and (np.linalg.norm(matrix.astype(np.float64), axis=1) > 0).all(),
            "Features contain a nonfinite or zero vector")


def load_library(path):
    path = Path(path)
    with gzip.open(path / "unique_slot_sequences.json.gz", "rt") as stream:
        sequences = json.load(stream)
    require(isinstance(sequences, dict) and sequences, "Empty unique sequence inventory")
    for h, sequence in sequences.items():
        require(isinstance(sequence, str) and 0 < len(sequence) <= 2046 and set(sequence) <= AA,
                "Invalid model-slot amino-acid sequence")
        require(h == seqsha(sequence), "Model-slot sequence SHA256 mismatch")
    with np.load(path / "model_indices.npz", allow_pickle=False) as indices:
        hashes = indices["sequence_hashes"].tolist()
        require(hashes == sorted(sequences), "Compact feature index and sequence inventory differ")
        feature_row, state, valid = indices["feature_row"], indices["state"], indices["valid"]
        require(feature_row.shape == state.shape and feature_row.shape[:2] == valid.shape and feature_row.shape[-1] == 3,
                "Invalid compact slot array shapes")
        observed = (state == 1) & valid[..., None]
        require(np.array_equal(feature_row >= 0, observed), "Feature rows must exist exactly at observed valid slots")
        require(np.isin(state, [0, 1, 2, 3]).all(), "Clean library contains an invalid or masked state")
        used = np.unique(feature_row[observed])
        require(np.array_equal(used, np.arange(len(hashes))), "Compact feature rows do not cover unique sequence index")
        assembly_count = len(indices["assembly_ids"])
        require(assembly_count == feature_row.shape[0] == 35 ** 3, "Expected the complete 42,875-assembly library")
        require(len(set(indices["assembly_ids"].tolist())) == assembly_count, "Duplicate compact assembly identity")
    identity = dict(sequence_inventory_sha256=sha(path / "unique_slot_sequences.json.gz"),
                    compact_indices_sha256=sha(path / "model_indices.npz"),
                    sequence_order_sha256=digest(hashes), assembly_count=assembly_count,
                    sequence_count=len(hashes))
    return sequences, hashes, identity


def load_previous_bank(path):
    path = Path(path)
    for name, expected in PREVIOUS_SHA.items():
        require(sha(path / name) == expected, "Completed 60-case bank checksum changed: " + name)
    report = json.loads((path / "feature_bank.json").read_text())
    require(report["feature_bank_sha256"] == PREVIOUS_SHA["feature_bank.npz"], "Previous bank manifest mismatch")
    require(report["source_cache_sha256"] == CACHE_SHA and report["embedding_dimension"] == DIM,
            "Previous bank embedding contract differs")
    backend = report["embedding_backend"]
    require(backend["checkpoint_sha256"] == CHECKPOINT_SHA and backend["producer_sha256"] == PRODUCER_SHA and
            backend["reference_gate"]["status"] == "PASS", "Previous sidecar producer/reference contract differs")
    with np.load(path / "feature_bank.npz", allow_pickle=False) as z:
        hashes, matrix = z["hashes"].tolist(), z["vectors"].copy()
    require(len(set(hashes)) == len(hashes) == report["sequence_count"], "Previous bank hash count differs")
    valid_vectors(matrix, len(hashes))
    return dict(zip(hashes, matrix))


def select_vectors(sequences, hashes, cache_path, cache_rows, previous):
    """Main-cache first, then verified previous vectors; return actual missing hashes.

    Caller verifies source file checksums before entry. This small function is
    independently tested with synthetic read-only caches and exact vectors.
    """
    cache_path = Path(cache_path)
    require((cache_path / "features.f32").stat().st_size == cache_rows * DIM * 4, "Main cache byte count differs")
    matrix = np.empty((len(hashes), DIM), dtype="<f4")
    provenance, missing, old_equal = [], [], 0
    data = np.memmap(cache_path / "features.f32", mode="r", dtype="<f4", shape=(cache_rows, DIM))
    with readonly(cache_path / "feature_index.sqlite3") as db:
        for i, h in enumerate(hashes):
            hits = db.execute("SELECT feature_row,status FROM features WHERE hash=?", (h,)).fetchall()
            require(len(hits) <= 1, "Duplicate main-cache sequence hash")
            if hits and hits[0][1] == "covered":
                row = hits[0][0]
                require(type(row) is int and 0 <= row < cache_rows, "Invalid main-cache feature row")
                matrix[i] = data[row]
                provenance.append(dict(hash=h, source="main_cache", source_row=row))
                if h in previous:
                    require(np.array_equal(matrix[i], previous[h]), "Previous 60-case vector differs from its main-cache source")
                    old_equal += 1
            elif h in previous:
                matrix[i] = previous[h]
                provenance.append(dict(hash=h, source="previous_60_bank"))
                old_equal += 1
            else:
                matrix[i].fill(np.nan)
                provenance.append(dict(hash=h, source="new_sidecar"))
                missing.append((h, sequences[h]))
    del data
    used = [i for i, p in enumerate(provenance) if p["source"] != "new_sidecar"]
    if used:
        valid_vectors(matrix[used], len(used))
    return matrix, provenance, missing, old_equal


def historical_references(root):
    contract_path, ref_path = root / CONTRACT, root / REFERENCE
    require(sha(contract_path) == CONTRACT_SHA, "Historical reference contract changed")
    require(sha(ref_path) == REFERENCE_SHA, "Historical reference manifest changed")
    contract = json.loads(contract_path.read_text())
    require(contract["reference_manifest"] == REFERENCE and contract["project_files_sha256"].get(REFERENCE) == REFERENCE_SHA,
            "Historical reference contract differs")
    refs = json.loads(ref_path.read_text())["references"]
    require(len(refs) >= 8 and len({r["hash"] for r in refs}) == len(refs), "Too few/duplicate historical references")
    for r in refs:
        require(r["hash"] == seqsha(r["seq"]) and r["length"] == len(r["seq"]), "Reference sequence mismatch")
    return refs


def merge_sidecar(sidecar, missing, hashes, matrix, backend):
    sidecar = Path(sidecar)
    require(backend["status"] == "ESMC_SIDECAR_COMPLETE" and backend["feature_rows"] == len(missing), "Backend did not complete")
    for name, expected in backend["files_sha256"].items():
        require(Path(name).name == name and sha(sidecar / name) == expected, "New sidecar checksum mismatch")
    require((sidecar / "features.f32").stat().st_size == len(missing) * DIM * 4, "New sidecar byte count differs")
    new = np.memmap(sidecar / "features.f32", mode="r", dtype="<f4", shape=(len(missing), DIM))
    index = {h: i for i, h in enumerate(hashes)}
    with readonly(sidecar / "feature_index.sqlite3") as db:
        entries = list(db.execute("SELECT hash,feature_row,status FROM features"))
        require(len(entries) == len(missing) and {h for h, _, _ in entries} == {h for h, _ in missing}, "New feature identity mismatch")
        require({row for _, row, _ in entries} == set(range(len(missing))), "New feature row mapping is not one-to-one")
        for h, row, status in entries:
            require(status == "covered" and type(row) is int, "Uncovered new-cache row")
            matrix[index[h]] = new[row]
    del new
    valid_vectors(matrix, len(hashes))


def load_feature_bank(path, hashes=None, identity=None):
    path = Path(path)
    report = json.loads((path / "feature_bank.json").read_text())
    require(report.get("schema") == "neuralps_42875_feature_bank_v1" and report.get("status") == "COMPLETE",
            "Feature-bank output is incomplete or incompatible")
    require(sha(path / "feature_bank.npz") == report["feature_bank_sha256"], "Saved feature-bank checksum mismatch")
    require(sha(path / "row_provenance.json") == report["row_provenance_sha256"], "Saved source provenance checksum mismatch")
    require(report.get("source_cache_sha256") == CACHE_SHA and report.get("previous_bank_sha256") == PREVIOUS_SHA and
            report.get("embedding_backend_sha256") == EMBED_BACKEND_SHA, "Saved bank source contract differs")
    with np.load(path / "feature_bank.npz", allow_pickle=False) as z:
        saved_hashes, matrix = z["hashes"].tolist(), z["vectors"].copy()
    require(saved_hashes == sorted(set(saved_hashes)), "Invalid saved bank row identities")
    valid_vectors(matrix, len(saved_hashes))
    require(hashes is None or hashes == saved_hashes, "Saved bank does not follow compact sequence order")
    require(identity is None or report["library_identity"] == identity, "Saved bank was built for different inputs")
    return matrix, report


def encode(root, library, out):
    root, library, out = Path(root).resolve(), Path(library).resolve(), Path(out).resolve()
    sequences, hashes, identity = load_library(library)
    if out.exists():
        _, report = load_feature_bank(out, hashes, identity)
        print(json.dumps(dict(stage="VERIFIED_COMPLETED_BANK", output=str(out), **report["counts"])), flush=True)
        return report
    require(sha(HERE / "vendor_embed/embedding_backend.py") == EMBED_BACKEND_SHA, "Vendored embedding backend changed")
    cache = root / CACHE
    for name, expected in CACHE_SHA.items():
        require(sha(cache / name) == expected, "Main feature cache checksum changed: " + name)
    previous = load_previous_bank(root / PREVIOUS)
    matrix, provenance, missing, equal_count = select_vectors(sequences, hashes, cache, CACHE_ROWS, previous)
    counts = dict(main_cache=sum(p["source"] == "main_cache" for p in provenance),
                  previous_60_bank=sum(p["source"] == "previous_60_bank" for p in provenance),
                  newly_embedded=len(missing), total=len(hashes), previous_bank_vectors_exact_equal=equal_count,
                  previous_bank_vectors_not_in_library=len(set(previous) - set(hashes)))
    require(sum(counts[k] for k in ("main_cache", "previous_60_bank", "newly_embedded")) == len(hashes), "Source counts differ")
    out.parent.mkdir(parents=True, exist_ok=True)
    attempt = Path(tempfile.mkdtemp(prefix="." + out.name + ".partial_", dir=out.parent))
    report = dict(schema="neuralps_42875_feature_bank_v1", status="ENCODING", library_identity=identity,
                  embedding_dimension=DIM, counts=counts, source_cache_sha256=CACHE_SHA,
                  previous_bank_sha256=PREVIOUS_SHA, embedding_backend_sha256=EMBED_BACKEND_SHA,
                  training=False, scoring=False, labels_read=False, created_utc=datetime.now(timezone.utc).isoformat(),
                  feature_extraction_mode="independent_sequence", parent_sequences_embedded=False,
                  pooling="mean final hidden state over actual amino-acid tokens; CLS/EOS/PAD excluded")
    def progress(event):
        atomic_json(attempt / "progress.json", event)
        print(json.dumps(event, sort_keys=True), flush=True)
    try:
        progress(dict(stage="SOURCE_SELECTION_COMPLETE", **counts))
        if missing:
            references = historical_references(root)
            sidecar = attempt / "novel_sidecar"
            sidecar.mkdir()
            from vendor_embed.embedding_backend import run_backend
            backend = run_backend(root, sidecar, missing, references, progress=progress)
            atomic_json(sidecar / "backend_report.json", backend)
            merge_sidecar(sidecar, missing, hashes, matrix, backend)
            report["embedding_backend"] = backend
            report["reference_source"] = dict(contract_sha256=CONTRACT_SHA, manifest_sha256=REFERENCE_SHA)
        valid_vectors(matrix, len(hashes))
        for i, h in enumerate(hashes):
            if h in previous:
                require(np.array_equal(matrix[i], previous[h]), "Final bank changed a previous 60-case feature")
        np.savez(attempt / "feature_bank.npz", hashes=np.array(hashes, dtype="U64"), vectors=matrix)
        atomic_json(attempt / "row_provenance.json", provenance)
        report["feature_bank_sha256"] = sha(attempt / "feature_bank.npz")
        report["row_provenance_sha256"] = sha(attempt / "row_provenance.json")
        report["status"] = "COMPLETE"
        atomic_json(attempt / "feature_bank.json", report)
        load_feature_bank(attempt, hashes, identity)
        progress(dict(stage="COMPLETE", **counts))
        require(not out.exists(), "Another process created the output during encoding")
        attempt.rename(out)
    except BaseException as error:
        atomic_json(attempt / "failure.json", dict(status="INCOMPLETE", exception=type(error).__name__,
                    message=str(error), retry="Run the same command; it creates a fresh attempt and preserves this one."))
        raise
    print(json.dumps(dict(stage="FEATURE_BANK_READY", path=str(out), sha256=report["feature_bank_sha256"])), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--library", type=Path, default=HERE / "data")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    encode(args.root, args.library, args.out)


if __name__ == "__main__":
    main()
