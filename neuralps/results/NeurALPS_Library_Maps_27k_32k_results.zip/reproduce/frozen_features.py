"""Label-free, frozen original-26k features for a small downstream readout.

The encoder keeps its original radius-six local blocks AND its global blocks.
No activity projection/readout is used, and no encoder optimizer exists here.
Feature arrays never contain assay outcomes or donor/plasmid identifiers.
Labels and split identifiers are written separately for downstream validation.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import time

import numpy as np


PACKAGE = Path(__file__).resolve().parent
SCHEMA = "neuralps_frozen26_readout_features_v1"
CHECKPOINT = "e1_ssl_continue30_v1_530757/best.pt"
CHECKPOINT_SHA = "9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f"
TARGET_MANIFEST = "e1_ssl_targets_497189/manifest.json"
TARGET_MANIFEST_SHA = "d4571217575bba57d0ee20cd9e2511d5b1a0a792bac7b2caf33033b67816e9db"
MASK_SOURCE_SHA = "a9a4e94fec9d07882e6e7527bcd57298cb8d79f7f2362c4c47c165545024bc2a"
MODEL_SOURCE_SHA = "551772090b00a9bf0d5a44fa85a4014e103079c4dabd1f2b99259ed5441dd2f4"
EXPECTED_CONFIG = dict(feature_dim=1152, width=256, heads=8, local_layers=4,
                       radius=6, global_layers=2, global_slots=4,
                       vocabulary_size=32, dropout=.1)
QUERY_BATCH = 16
REGIONS = ("whole", "domains", "covalent", "breaks", "xut2", "xut3", "xut4",
           "block_seams", "changed_units", "changed_seams", "break_cterm", "break_nterm")
MAP_STATS = ("mixed_mean", "mixed_q25", "mixed_min", "mixed_std",
             "raw_mean", "raw_q25", "raw_min", "raw_std",
             "log_total", "scored_fraction", "region_available")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for part in iter(lambda: stream.read(8 << 20), b""):
            h.update(part)
    return h.hexdigest()


def dump(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    tmp.replace(path)


def emit(stage, **kwargs):
    print(json.dumps(dict(stage=stage, **kwargs), allow_nan=False), flush=True)


def extraction_dependencies():
    files = [PACKAGE / name for name in ("frozen_features.py", "supervised.py", "labelled_backend.py",
             "labelled_multis.py", "vendor_neural/assembly_model.py", "vendor_neural/masking_contract.py")]
    files.extend(p for p in (PACKAGE / "labelled_assets").rglob("*") if p.is_file())
    return {str(p.relative_to(PACKAGE)): sha(p) for p in sorted(files)}


def state_digest(model):
    """Hash all tensors, including the unused legacy activity head."""
    h = hashlib.sha256()
    for key, tensor in sorted(model.state_dict().items()):
        array = tensor.detach().cpu().contiguous().numpy()
        h.update(key.encode() + b"\0" + str(array.dtype).encode() + b"\0")
        h.update(json.dumps(list(array.shape)).encode() + b"\0")
        h.update(array.tobytes())
    return h.hexdigest()


def source_signatures(root, verified_hashes=None):
    from labelled_backend import PINNED_INPUTS
    expected = dict(PINNED_INPUTS)
    expected[CHECKPOINT] = CHECKPOINT_SHA
    expected[TARGET_MANIFEST] = TARGET_MANIFEST_SHA
    verified = {}
    for relative, digest in sorted(expected.items()):
        path = root / relative
        require(path.is_file(), "Missing pinned input: " + relative)
        require(path.resolve().is_relative_to(root), "Pinned source resolves outside project: " + relative)
        if path.suffix == ".sqlite3":
            require(not Path(str(path) + "-wal").exists(), "Unexpected source database WAL")
        before = path.stat()
        actual = (verified_hashes or {}).get(relative) or sha(path)
        after = path.stat()
        require((before.st_size, before.st_mtime_ns, before.st_ino) ==
                (after.st_size, after.st_mtime_ns, after.st_ino), "Input changed during hash")
        require(actual == digest, "Pinned input checksum differs: " + relative)
        verified[relative] = dict(sha256=actual, bytes=after.st_size,
                                  mtime_ns=after.st_mtime_ns, inode=after.st_ino)
        emit("VERIFY_FROZEN_INPUT", file=relative, bytes=after.st_size)
    return verified


def verify_unchanged(root, verified):
    for relative, entry in verified.items():
        st = (root / relative).stat()
        require((st.st_size, st.st_mtime_ns, st.st_ino) ==
                (entry["bytes"], entry["mtime_ns"], entry["inode"]),
                "Pinned input changed during extraction: " + relative)


def load_encoder(root, device):
    import torch
    from vendor_neural.assembly_model import AssemblyEncoder, Config
    require(sha(PACKAGE / "vendor_neural/assembly_model.py") == MODEL_SOURCE_SHA,
            "Original encoder source changed")
    require(sha(PACKAGE / "vendor_neural/masking_contract.py") == MASK_SOURCE_SHA,
            "Original masking closure source changed")
    # Deserialization is only allowed after the caller verifies this exact file hash.
    require(sha(root / CHECKPOINT) == CHECKPOINT_SHA, "Wrong original checkpoint")
    parent = torch.load(root / CHECKPOINT, map_location="cpu", weights_only=True)
    require(parent.get("step") == 26000, "Checkpoint step is not 26000")
    cfg = parent["config"]
    require(cfg.get("activity_labels_used") is False, "Encoder has activity supervision")
    require(cfg["settings"]["encoder"] == EXPECTED_CONFIG, "Original encoder configuration differs")
    require(cfg.get("targets_manifest_sha256") == TARGET_MANIFEST_SHA,
            "Original natural target lineage differs")
    require(sha(root / TARGET_MANIFEST) == TARGET_MANIFEST_SHA, "Target manifest differs")
    manifest = json.loads((root / TARGET_MANIFEST).read_text())
    require(parent["targets_manifest"] == manifest, "Checkpoint/target manifest mismatch")
    require(set(parent["target_means"]) == set(manifest["means"]), "Target mean groups differ")
    means = {}
    for group, value in parent["target_means"].items():
        arr = value.detach().cpu().numpy().astype(np.float32, copy=True)
        require(arr.shape == (1152,) and np.isfinite(arr).all(), "Invalid target mean")
        require(manifest["means"][group][1] >= 0, "Invalid target mean support")
        means[group] = arr
    model = AssemblyEncoder(Config(**EXPECTED_CONFIG))
    require(all(bool(torch.isfinite(v).all()) for v in parent["model"].values()),
            "Nonfinite original model weights")
    model.load_state_dict(parent["model"], strict=True)
    model.to(device).eval().requires_grad_(False)
    require(all(block.radius == 6 for block in model.local) and len(model.global_blocks) == 2,
            "Original local/global architecture changed")
    del parent
    return model, means, manifest["means"]


def mean_for_slot(slot, means, mean_map):
    group = slot["group"]
    if group in mean_map and mean_map[group][1] >= 100:
        selected = group
    else:
        selected = group if slot["kind"] == 2 else ("D" if slot["kind"] == 0 else "C")
    require(selected in means, "Missing training-only target mean for " + str(group))
    return means[selected]


def make_plan(record, target, parents):
    """One physical object; no sequence aliases or overlapping residues stay visible."""
    from vendor_neural.masking_contract import masking_closure
    by = defaultdict(list)
    for slot in record["model_slots"]:
        by[slot["object_index"]].append(slot)
    slots = sorted(by[target], key=lambda s: s["slot"])
    expected = [1, 2] if record["route"][target]["kind"] == 2 else [0]
    require([s["slot"] for s in slots] == expected, "Physical target roles differ")
    primary = [(target, s["slot"]) for s in slots]
    if any(s["state"] != "OBSERVED" for s in slots):
        return dict(status="MISSING_SEQUENCE_FEATURE", hidden=[], primary=primary), slots
    hidden = masking_closure(record, primary, parents.__getitem__, "independent_sequence")["hidden"]
    hidden_set = set(map(tuple, hidden))
    visible = defaultdict(set)
    for slot in record["model_slots"]:
        if slot["state"] == "OBSERVED" and (slot["object_index"], slot["slot"]) not in hidden_set:
            visible[slot["object_index"]].add(slot["sequence_hash"])
    seen, context = set(), 0
    for j in sorted(visible):
        if j != target and abs(j - target) <= 24 and visible[j] - seen:
            context += 1
            seen.update(visible[j])
    return dict(status="READY" if context >= 2 else "INSUFFICIENT_VISIBLE_CONTEXT",
                hidden=hidden, primary=primary, visible_context_objects=context), slots


def score_objects(model, clean, record, parents, means, mean_map, query_batch=QUERY_BATCH):
    import torch
    from torch.nn import functional as F
    entries, ready = [], []
    for j, obj in enumerate(record["route"]):
        plan, slots = make_plan(record, j, parents)
        entry = dict(object_index=j, kind=int(obj["kind"]), status=plan["status"],
                     mixed=None, raw=None, role_scores=[], hidden_slots=len(plan["hidden"]),
                     visible_context_objects=plan.get("visible_context_objects"))
        entries.append(entry)
        if plan["status"] == "READY":
            ready.append((j, plan, slots))
    for start in range(0, len(ready), query_batch):
        queries = ready[start:start + query_batch]
        batch = {k: v.expand(len(queries), *v.shape[1:]).clone() for k, v in clean.items()}
        for b, (_, plan, _) in enumerate(queries):
            for j, role in plan["hidden"]:
                batch["state"][b, j, role] = 4
                batch["x"][b, j, role] = float("nan")
        with torch.inference_mode():
            pred = model.predict_masked(batch)
            require(bool(torch.isfinite(pred).all()), "Nonfinite masked prediction")
            for b, (j, _, slots) in enumerate(queries):
                roles = [s["slot"] for s in slots]
                target = clean["x"][0, j, roles].float()
                mu = torch.as_tensor(np.stack([mean_for_slot(s, means, mean_map) for s in slots]),
                                     device=target.device)
                p = pred[b, j, roles].float()
                raw = F.cosine_similarity(p, target, dim=-1, eps=1e-6)
                centered = F.cosine_similarity(p - mu, target - mu, dim=-1, eps=1e-6)
                mixed = torch.where((target - mu).norm(dim=-1) > 1e-6,
                                    .25 * raw + .75 * centered, raw)
                require(bool(torch.isfinite(mixed).all()) and bool((mixed.abs() <= 1.00001).all()) and
                        bool(torch.isfinite(raw).all()) and bool((raw.abs() <= 1.00001).all()),
                        "Invalid reconstruction agreement")
                entries[j].update(status="SCORED", mixed=float(mixed.mean()), raw=float(raw.mean()),
                    role_scores=[dict(role=role, mixed=float(m), raw=float(r))
                                 for role, m, r in zip(roles, mixed, raw)])
    return entries


def regions_for_record(record, blocks, seams, donor_codes):
    route = record["route"]
    groups = {"whole": list(range(len(route)))}
    for name, kind in (("domains", 0), ("covalent", 1), ("breaks", 2)):
        groups[name] = [j for j, obj in enumerate(route) if obj["kind"] == kind]
    for i in range(3):
        groups["xut" + str(i + 2)] = np.flatnonzero(blocks == i).tolist() if donor_codes else []
    groups["block_seams"] = list(map(int, seams)) if donor_codes else []
    changed = {i for i, code in enumerate(donor_codes) if code != "native"}
    groups["changed_units"] = [j for j, unit in enumerate(blocks) if unit in changed] if changed else []
    groups["changed_seams"] = [int(j) for p, j in enumerate(seams) if p in changed or p + 1 in changed]
    groups["break_cterm"] = groups["breaks"]
    groups["break_nterm"] = groups["breaks"]
    return groups


def map_summary(objects, groups):
    values, names = [], []
    for region in REGIONS:
        selected = [objects[j] for j in groups[region]]
        if region.startswith("break_"):
            role = 1 if region == "break_cterm" else 2
            selected = [dict(status=o["status"], **next((x for x in o["role_scores"] if x["role"] == role),
                                                       {"mixed": None, "raw": None})) for o in selected]
        n = len(selected)
        scored = sum(o["status"] == "SCORED" and o["mixed"] is not None for o in selected)
        row = []
        for key in ("mixed", "raw"):
            if n and scored == n:
                a = np.array([o[key] for o in selected], dtype=np.float64)
                row.extend([float(a.mean()), float(np.quantile(a, .25)), float(a.min()), float(a.std())])
            else:
                row.extend([float("nan")] * 4)
        row.extend([float(np.log1p(n)), scored / n if n else 0., float(n > 0)])
        values.extend(row)
        names.extend("map__" + region + "__" + name for name in MAP_STATS)
    return np.asarray(values, dtype=np.float32), names


def clean_features(hidden, clean, static, donor_codes):
    """Deterministic pooling only; all reductions learned by the fitter are fold-local."""
    valid = clean["valid"][0].detach().cpu().numpy()
    require(np.array_equal(valid, np.arange(len(valid)) < int(valid.sum())), "Non-contiguous route padding")
    h = np.asarray(hidden, dtype=np.float32)[valid]
    kind = clean["kind"][0].detach().cpu().numpy()[valid]
    state = clean["state"][0].detach().cpu().numpy()[valid]
    blocks = static["blocks"][0].detach().cpu().numpy()[valid]
    seams = static["seams"][0].detach().cpu().numpy()
    context, context_names = [], []
    def add_mean(label, take):
        context.extend(h[take].mean(0).tolist() if np.any(take) else [0.] * h.shape[1])
        context_names.extend(label + "__" + str(i) for i in range(h.shape[1]))
    for label, k in (("domain", 0), ("covalent", 1), ("break", 2)):
        add_mean("context_" + label, kind == k)
    for unit in range(3):
        add_mean("context_xut" + str(unit + 2), (blocks == unit) if donor_codes else np.zeros(len(h), bool))
    for p in range(2):
        context.extend(h[int(seams[p])].tolist() if donor_codes else [0.] * h.shape[1])
        context_names.extend("context_seam" + str(p) + "__" + str(i) for i in range(h.shape[1]))
    aa = static["chemistry"][0].detach().cpu().numpy()
    regional = static["regional"][0].detach().cpu().numpy()
    chem = np.concatenate([aa.ravel(), (aa[:-1] * aa[1:]).ravel(), (aa[1:] - aa[:-1]).ravel(),
                           regional.ravel(), [float(bool(donor_codes))]]).astype(np.float32)
    chem_names = ([f"chem_position{p}_descriptor{d}" for p in range(5) for d in range(aa.shape[-1])] +
                  [f"chem_pair{p}_product{d}" for p in range(4) for d in range(aa.shape[-1])] +
                  [f"chem_pair{p}_delta{d}" for p in range(4) for d in range(aa.shape[-1])] +
                  [f"regional_xut{p+2}_feature{d}" for p in range(3) for d in range(regional.shape[-1])] +
                  ["chemistry_available"])
    actual = state != 0
    total_roles = max(int(actual.sum()), 1)
    chain = clean["chain"][0].detach().cpu().numpy()[valid]
    structure = [np.log1p((kind == k).sum()) for k in range(3)]
    structure += [np.log1p(len(set(chain[chain >= 0]))),
                  float((state == 1).sum()) / total_roles, float((state == 2).sum()) / total_roles,
                  float((state == 3).sum()) / total_roles,
                  *[float(np.any(kind == k)) for k in range(3)], float(bool(donor_codes))]
    structure += [np.log1p((blocks == i).sum()) if donor_codes else 0. for i in range(3)]
    structure += [float(kind[int(seams[p])] == k) if donor_codes else 0. for p in range(2) for k in (1, 2)]
    structure += [np.log1p(sum(d != "native" for d in donor_codes))]
    structure_names = (["log_domains", "log_covalent", "log_breaks", "log_chains", "observed_role_fraction",
                        "empty_role_fraction", "missing_role_fraction", "has_domains", "has_covalent",
                        "has_breaks", "xut_registry_available"] +
                       [f"log_xut{p+2}_objects" for p in range(3)] +
                       [f"seam{p}_kind{k}" for p in range(2) for k in (1, 2)] + ["log_changed_units"])
    return (dict(context=np.asarray(context, np.float32), chemistry=chem,
                 structure=np.asarray(structure, np.float32)),
            dict(context=context_names, chemistry=chem_names, structure=structure_names))


def row_metadata(labelled):
    from supervised import _donors_from_single
    from labelled_backend import _route_fingerprint
    train = set(i for ids in labelled.training.values() for i in ids)
    held = set(labelled.held)
    require(train.isdisjoint(held), "Outer train/holdout overlap")
    rows = []
    for i, (r, rec, cohort) in enumerate(zip(labelled.rows, labelled.records, labelled.cohorts)):
        codes = (_donors_from_single(r) if cohort == "singles" else
                 tuple(rec["donors"]) if cohort in ("doubles", "triples") else ())
        rows.append(dict(index=i, assembly_id=r["assembly_id"], dataset=r["dataset"],
                         cohort=cohort, observed_activity=int(r["observed_activity"]),
                         donor_codes=list(codes),
                         domain_hashes=sorted({s["sequence_hash"] for s in rec["model_slots"]
                                              if s["kind"] == 0 and s["state"] == "OBSERVED"}),
                         route_fingerprint=_route_fingerprint(rec),
                         outer_role="train" if i in train else "held" if i in held else "excluded"))
    require(Counter(r["outer_role"] for r in rows) == {"train": 475, "held": 41, "excluded": 36},
            "Audited outer split changed")
    groups = labelled.runtime.overlap_audit["groups"]
    registry = {g.removeprefix("donor:pIG"): v["donor_specific_primary_domain_hashes"]
                for g, v in groups.items()}
    require(len(registry) == 35, "Donor domain registry changed")
    return dict(schema=SCHEMA, rows=rows, donor_specific_domain_hashes=registry,
                outer_held_donors=labelled.manifest["held_donors"],
                outer_split=labelled.manifest["split"],
                excluded_conflicts=labelled.manifest["excluded_conflicts"],
                exact_overlap_exclusions=labelled.manifest["exact_overlap_exclusions"],
                interpretation="Labels are metadata only; all feature extraction is label-free. Exact-sequence purge is not homology clustering.")


def extract(root, out, device="cuda", threads=8, verified_hashes=None):
    """Write aligned arrays, metadata and raw maps; return the feature manifest."""
    import torch
    from supervised import SupervisedData
    from labelled_multis import load_inputs
    root, out = Path(root).resolve(), Path(out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    require(device in ("cuda", "cpu") and threads > 0, "Invalid extraction runtime")
    if device == "cuda":
        require(torch.cuda.is_available(), "CUDA unavailable; use a compute-node GPU allocation")
    torch.set_num_threads(threads)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.set_float32_matmul_precision("highest")
    started = time.monotonic()
    verified = source_signatures(root, verified_hashes=verified_hashes)
    dependencies = extraction_dependencies()
    cached_path = out / "features.json"
    if cached_path.exists():
        cached = json.loads(cached_path.read_text())
        require(cached["schema"] == SCHEMA and cached["source_code_sha256"] == sha(__file__),
                "Existing feature cache has a different extraction contract")
        require(cached.get("extraction_dependencies") == dependencies,
                "Cached feature dependencies or bundled labels/structures changed")
        require(cached["source_hashes"] == {k: v["sha256"] for k, v in verified.items()},
                "Cached source identities differ")
        for name, expected in cached["payload_sha256"].items():
            require(sha(out / name) == expected, "Feature cache payload changed: " + name)
        emit("FROZEN_FEATURE_CACHE_REUSED", rows=cached["rows"])
        return cached
    model, means, mean_map = load_encoder(root, device)
    before = state_digest(model)
    emit("LOADING_LABELLED_CACHED_INPUTS", encoder_step=26000, encoder_training=False)
    labelled = SupervisedData(root, torch.device(device), threads=threads,
                              verified_hashes={k: v["sha256"] for k, v in verified.items()})
    metadata = row_metadata(labelled)
    _, multi_parents = load_inputs(PACKAGE / "labelled_assets/known_multis_model_inputs.json.gz")
    parents = dict(labelled.runtime.parents)
    for h, sequence in multi_parents.items():
        require(h not in parents or parents[h] == sequence, "Parent sequence namespace conflict")
        parents[h] = sequence
    arrays = {k: [] for k in ("context", "chemistry", "compatibility", "structure")}
    names = None
    maps_tmp = out / "maps.jsonl.gz.tmp"
    statuses = Counter()
    with maps_tmp.open("wb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", compresslevel=6, mtime=0) as stream:
            for i, meta in enumerate(metadata["rows"]):
                clean, static, _ = labelled._batch([i])
                with torch.inference_mode():
                    hidden = model.features(clean)[0].cpu().numpy()
                require(np.isfinite(hidden).all(), "Nonfinite clean context features")
                features, current_names = clean_features(hidden, clean, static, meta["donor_codes"])
                rec = labelled.records[i]
                objects = score_objects(model, clean, rec, parents, means, mean_map)
                blocks = static["blocks"][0].detach().cpu().numpy()
                seams = static["seams"][0].detach().cpu().numpy()
                groups = regions_for_record(rec, blocks, seams, meta["donor_codes"])
                features["compatibility"], current_names["compatibility"] = map_summary(objects, groups)
                if names is None:
                    names = current_names
                require(names == current_names, "Feature columns changed between rows")
                for key, value in features.items():
                    require(not np.isinf(value).any(), "Infinite feature value")
                    if key != "compatibility":
                        require(np.isfinite(value).all(), "Nonfinite clean feature")
                    arrays[key].append(value)
                statuses.update(o["status"] for o in objects)
                rowmap = dict(index=i, assembly_id=meta["assembly_id"], objects=objects,
                              regions=groups, checkpoint_sha256=CHECKPOINT_SHA)
                stream.write((json.dumps(rowmap, sort_keys=True, allow_nan=False) + "\n").encode())
                if i % 10 == 0 or i + 1 == len(metadata["rows"]):
                    emit("EXTRACTING_FROZEN_FEATURES", completed=i + 1, total=len(metadata["rows"]),
                         elapsed_seconds=round(time.monotonic() - started, 2), object_statuses=dict(statuses))
    after = state_digest(model)
    require(before == after and not any(p.requires_grad for p in model.parameters()) and not model.training,
            "Frozen encoder state changed")
    require(not any(p.grad is not None for p in model.parameters()), "Unexpected encoder gradient")
    verify_unchanged(root, verified)
    matrices = {k: np.stack(v).astype(np.float32) for k, v in arrays.items()}
    for key, matrix in matrices.items():
        require(matrix.shape == (552, len(names[key])), "Feature matrix shape mismatch")
    feature_tmp = out / "features.npz.tmp"
    with feature_tmp.open("wb") as stream:
        np.savez_compressed(stream, **matrices)
    feature_tmp.replace(out / "features.npz")
    dump(out / "rows.json", metadata)
    maps_tmp.replace(out / "maps.jsonl.gz")
    manifest = dict(schema=SCHEMA, status="FROZEN_FEATURES_COMPLETE", rows=552,
        source_code_sha256=sha(__file__), checkpoint=CHECKPOINT, checkpoint_sha256=CHECKPOINT_SHA,
        extraction_dependencies=dependencies,
        checkpoint_step=26000, activity_labels_used_by_encoder=False,
        encoder_config=EXPECTED_CONFIG, attention="original_radius6_local_plus_original_global_blocks",
        encoder_state_sha256_before=before, encoder_state_sha256_after=after,
        encoder_training=False, encoder_gradients=False, encoder_optimizer=False,
        arrays={k: dict(shape=list(v.shape), columns=names[k], missing_values=int(np.isnan(v).sum()))
                for k, v in matrices.items()},
        source_hashes={k: v["sha256"] for k, v in verified.items()},
        payload_sha256={n: sha(out / n) for n in ("features.npz", "rows.json", "maps.jsonl.gz")},
        object_statuses=dict(statuses), elapsed_seconds=round(time.monotonic() - started, 2),
        runtime=dict(python=platform.python_version(), numpy=np.__version__, torch=torch.__version__,
                     cuda=torch.version.cuda, device=device, threads=threads, tf32=False),
        contracts=dict(context="No trained activity projection; raw 256-dimensional frozen contextual means and seam states. Dimensionality reduction belongs inside each fitting fold.",
                       chemistry="Audited BODE2 source chemistry, adjacent products/differences, regional similarities; availability flag for other assays. TE similarity retains its original unverified-terminal-span limitation.",
                       maps="Single physical object with exact sequence alias and physical overlap masking closure. Original full model path retains global blocks. Non-covalent terminal roles remain distinct and are averaged for the boundary score.",
                       map_formula="0.25*cos(pred,z)+0.75*cos(pred-mu,z-mu), with raw fallback only when norm(z-mu)<=1e-6",
                       map_mean="Natural-training-only type mean with >=100 support, otherwise audited broad kind/terminal-role mean.",
                       missing="No silent averaging over missing object scores; region summaries are NaN unless coverage is complete. Coverage and existence are explicit features; imputation is training-fold only.",
                       normalization="Raw reconstruction agreements, not activity probabilities; no natural/inactive percentile mapping fitted here.",
                       xut_scope="Verified engineered source blocks (XUT2/3/4 in canonical registry); not antiSMASH module assignments.",
                       label_use="Outcome labels stored only in rows.json; never consumed by encoder, pooling, masking or feature calculation."))
    dump(cached_path, manifest)
    emit("FROZEN_FEATURES_COMPLETE", rows=552, shapes={k: list(v.shape) for k, v in matrices.items()},
         encoder_weights_unchanged=True)
    return manifest
