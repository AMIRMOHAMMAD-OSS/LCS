"""Exact full-library object distributions; no model fitting or inference.

Every physical object maps to exactly one ordered semantic column. Optional
architecture is absent (NaN), never zero. Native donor blocks remain included.
"""
from pathlib import Path
from collections import Counter
import argparse, csv, gzip, hashlib, json, lzma
import numpy as np

HERE=Path(__file__).resolve().parent
EXPECTED={'doubles':3675,'triples':42875}
CHECKPOINTS={26000:'9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f',
27000:'bb78635c63d7a29ba77fc0ff09203ecc92a7938fd216e269716243e5d104a66c',
32000:'ba62c4c3c1d8f6606c14c57fb0770d8ecfd7c9ea8eefc35424d2aa1197923e7a'}
TYPE_SHORT={1:'PCP',2:'A',3:'C',4:'C',5:'E',6:'TIGR',8:'Cstart',9:'C',7:'TE'}
SCORES=('raw','mixed')
cols=[]
def domain(key,label,group,pos=None,core=False):
    cols.append(dict(index=len(cols),key=key,label=label,group=group,position=pos,core=core,object_category='domain',new_seam=False))
def edge(a,b,label,group,pos=None,core=False,new=False):
    cols.append(dict(index=len(cols),key=a+'>'+b,label=label,group=group,position=pos,core=core,object_category='connection',new_seam=new))
domain('up_Cstart','Cst','Upstream');edge('up_Cstart','up_A','Cst-A','Upstream');domain('up_A','A','Upstream')
edge('up_A','XUT2_PCP','A-T','Upstream',2)
for p in (2,3,4):
    g=f'XUT{p}';k=lambda s:f'{g}_{s}'
    domain(k('PCP'),'T',g,p,True)
    edge(k('PCP'),k('C'),'T-C',g,p,True);edge(k('PCP'),k('E'),'T-E',g,p,True)
    domain(k('E'),'E',g,p,True);edge(k('E'),k('C'),'E-C',g,p,True)
    edge(k('E'),k('TIGR'),'E-TIGR',g,p,True);domain(k('TIGR'),'TIGR',g,p,True)
    edge(k('TIGR'),k('C'),'TIGR-C',g,p,True);domain(k('C'),'C',g,p,True)
    edge(k('C'),k('A'),'C-A',g,p,True);domain(k('A'),'A',g,p,True)
    if p<4:edge(k('A'),f'XUT{p+1}_PCP','A-T',f'Seam {p}-{p+1}',new=True)
edge('XUT4_A','down_PCP1','A-T','Downstream',4)
domain('down_PCP1','T','Downstream');edge('down_PCP1','down_C','T-C','Downstream')
domain('down_C','C','Downstream');edge('down_C','down_A','C-A','Downstream')
domain('down_A','A','Downstream');edge('down_A','down_PCP2','A-T','Downstream')
domain('down_PCP2','T','Downstream');edge('down_PCP2','down_TE','T-TE','Downstream');domain('down_TE','TE','Downstream')
COL_INDEX={c['key']:c['index'] for c in cols}
assert len(cols)==49 and len(COL_INDEX)==49

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8<<20),b''):h.update(b)
    return h.hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True,allow_nan=False)+'\n')
def csvout(p,rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def stats(a):
    a=np.asarray(a,dtype=float);a=a[np.isfinite(a)]
    if not len(a):return dict(n=0)
    q=np.quantile(a,[0,.01,.05,.10,.25,.50,.75,.90,.95,.99,1])
    return dict(n=len(a),mean=float(a.mean()),sd_population=float(a.std()),**dict(zip(['min','p01','p05','p10','p25','median','p75','p90','p95','p99','max'],map(float,q))))
def annotate(record,registry):
    codes=record['donor_codes'];obs=record['objects'];keys=[];domain_types=[]
    for p,code in zip((2,3,4),codes):
        block=registry[p-2][code]
        for j,(typ,hsh) in enumerate(block):
            if p==2 and j<2:key=['up_Cstart','up_A'][j]
            elif p==4 and j>=len(block)-5:key=['down_PCP1','down_C','down_A','down_PCP2','down_TE'][j-len(block)+5]
            else:key=f'XUT{p}_{TYPE_SHORT[typ]}'
            keys.append(key);domain_types.append(typ)
    domains=[o for o in obs if o['kind']==0]
    assert len(domains)==len(keys) and len(keys)==len(set(keys))
    assert [o['annotation']['domain_type'] for o in domains]==domain_types
    assert len(obs)==2*len(keys)-1
    objkeys=[]
    for i,key in enumerate(keys):
        objkeys.append(key)
        if i<len(keys)-1:objkeys.append(key+'>'+keys[i+1])
    ix=[COL_INDEX[k] for k in objkeys]
    assert ix==sorted(ix) and len(ix)==len(set(ix))
    return ix

def analyze(map_dir,out,step,registry_path,labels_path):
    out.mkdir(parents=True,exist_ok=True)
    registry=json.loads(registry_path.read_text());labels=json.loads(labels_path.read_text())
    labelby={r['assembly_id']:r for r in labels};colsummary=[];typesummary=[];assemblysummary=[];donorsummary=[];roletable=[]
    info=dict(status='PASS',checkpoint_step=step,checkpoint_sha256=CHECKPOINTS[step],scope='All designs including known designs; no top50 filtering',
       masking='One physical object at a time with physical-overlap and exact-sequence-alias closure',
       score_formula='raw=cos(pred,target); mixed=.25 raw+.75 type-centered cosine; raw fallback for near-zero target residual',
       normalization='None. Percentiles are descriptive score quantiles, not activity probabilities or external reference normalization.',
       alignment='49 ordered semantic columns; optional objects remain NaN. Condensation subtypes share a display C role but remain separate in type tables. Covalent and noncovalent connections retained separately.',
       weighting='Object tables pool all object occurrences. Assembly tables weight each assembly once. Reused sequences across contexts are retained, not independent biological replicates.',
       label_policy='58 nonconflicting known multis only; unknown or conflicting outcomes are never assigned inactive. Outcomes describe assemblies, not individual-object activity.',
       cohorts={},source_sha256={str(registry_path.name):sha(registry_path),str(labels_path.name):sha(labels_path)})
    dump(out/'columns.json',cols)
    for cohort,count in EXPECTED.items():
        path=map_dir/f'{cohort}_maps.jsonl.xz'
        if not path.exists():path=map_dir/f'{cohort}_maps.jsonl.gz'
        opener=lzma.open if path.suffix=='.xz' else gzip.open
        z=np.full((count,len(cols),2),np.nan,dtype=np.float32)
        kind=np.full((count,len(cols)),-1,dtype=np.int8);dtype=np.zeros_like(kind)
        nc=np.full((count,len(cols),2,2),np.nan,dtype=np.float32)
        hidden=np.full((count,len(cols)),-1,dtype=np.int16);visible=hidden.copy()
        annotation=np.zeros_like(kind);status=np.zeros_like(kind)
        ids=[];donors=[];native=[];activities=[];outer=[];seqkeys=[];signatures=[];types={};statuscounts=Counter();labelcounts=Counter()
        with opener(path,'rt') as f:
            for n,line in enumerate(f):
                r=json.loads(line);assert n<count and r['candidate_index']==n and r['cohort']==cohort
                assert r['checkpoint_sha256']==CHECKPOINTS[step]
                aid=r['assembly_id'];ix=annotate(r,registry)
                assert all(o['object_index']==j for j,o in enumerate(r['objects']))
                ids.append(aid);donors.append(r['donor_codes']);seqkeys.append(r['sequence_key']);signatures.append(r['model_signature'])
                native.append(r['donor_codes'].index('native')+2 if 'native' in r['donor_codes'] else 0)
                lab=labelby.get(aid);activities.append(lab['observed_activity'] if lab else -1);outer.append(lab['outer_role'] if lab else 'unknown_or_conflict')
                for j,o in zip(ix,r['objects']):
                    k=o['kind'];kind[n,j]=k;statuscounts[o['status']]+=1
                    ann=o.get('annotation',{});dtype[n,j]=ann.get('domain_type',0)
                    if k==0:types[ann['domain_type']]=ann['canonical_domain_type']
                    if k!=0:
                        label=ann.get('annotation','UNKNOWN');labelcounts[label]+=1
                        annotation[n,j]={'B':1,'J':2,'UNKNOWN':3}.get(label,3)
                    hidden[n,j]=o['hidden_slots'];visible[n,j]=o.get('visible_context_objects',-1) or 0
                    if o['status']=='SCORED':
                        status[n,j]=1;v=np.asarray([o[s] for s in SCORES],float)
                        assert np.isfinite(v).all() and (np.abs(v)<=1.00001).all()
                        z[n,j]=v;rs=o['role_scores'];assert {s['role'] for s in rs}==({1,2} if k==2 else {0})
                        assert np.max(np.abs(v-np.mean([[s[x] for x in SCORES] for s in rs],axis=0)))<1e-6
                        if k==2:
                            for rr in rs:nc[n,j,rr['role']-1]=[rr[s] for s in SCORES]
                if (n+1)%10000==0:print(json.dumps(dict(stage='ANALYSING_OBJECT_MAPS',cohort=cohort,completed=n+1,total=count)),flush=True)
        assert len(ids)==count and len(set(ids))==count and len(set(seqkeys))==count
        assert sum(statuscounts.values())==int((kind>=0).sum())
        ids=np.array(ids);donors=np.array(donors);native=np.array(native);activities=np.array(activities);outer=np.array(outer)
        assert all(sum(native==p)==1225 for p in (2,3,4)) if cohort=='doubles' else all(native==0)
        np.savez_compressed(out/f'{cohort}_aligned_scores.npz',scores=z,kinds=kind,domain_types=dtype,noncovalent_roles=nc,
             hidden_slots=hidden,visible_context_objects=visible,boundary_annotation=annotation,scored=status,assembly_ids=ids,donors=donors,
             retained_native=native,activity=activities,outer_role=outer,sequence_keys=np.array(seqkeys),model_signatures=np.array(signatures))
        subsets={'all':np.ones(count,bool)}
        if cohort=='doubles':subsets.update({f'native_XUT{p}':native==p for p in (2,3,4)})
        subsets.update({'known_active':activities==1,'known_inactive':activities==0})
        for population,mask in subsets.items():
            for si,score in enumerate(SCORES):
                zz=z[mask,:,si];kk=kind[mask];dd=dtype[mask]
                for c in cols:
                    row=dict(cohort=cohort,population=population,score=score,**c,assemblies=int(mask.sum()),present=int((kk[:,c['index']]>=0).sum()))
                    row.update(stats(zz[:,c['index']]));row['absent']=row['assemblies']-row['present'];row['unscored']=row['present']-row['n'];colsummary.append(row)
                typesets={'All objects':kk>=0,'All domains':kk==0,'Covalent connections':kk==1,'Noncovalent connections':kk==2}
                typesets.update({v:(kk==0)&(dd==k) for k,v in types.items()})
                for typ,sel in typesets.items():typesummary.append(dict(cohort=cohort,population=population,score=score,object_type=typ,**stats(zz[sel])))
                for role,name in enumerate(['C_terminal','N_terminal']):roletable.append(dict(cohort=cohort,population=population,score=score,role=name,**stats(nc[mask,:,role,si].ravel())))
                for name,mm in [('whole_object_mean',None),('domain_mean',kk==0),('connection_mean',kk>0)]:
                    values=np.nanmean(zz if mm is None else np.where(mm,zz,np.nan),axis=1)
                    assemblysummary.append(dict(cohort=cohort,population=population,score=score,measure=name,**stats(values)))
                balanced=.5*np.nanmean(np.where(kk==0,zz,np.nan),axis=1)+.5*np.nanmean(np.where(kk>0,zz,np.nan),axis=1)
                assemblysummary.append(dict(cohort=cohort,population=population,score=score,measure='balanced_domain_connection_mean',**stats(balanced)))
                assemblysummary.append(dict(cohort=cohort,population=population,score=score,measure='whole_minimum',**stats(np.nanmin(zz,axis=1))))
        for pos in (2,3,4):
            cc=[c for c in cols if c['position']==pos and c['core']]
            for code in sorted(set(donors[:,pos-2])):
                mask=donors[:,pos-2]==code
                for c in cc:
                    for si,score in enumerate(SCORES):donorsummary.append(dict(cohort=cohort,position=pos,donor=code,column=c['key'],score=score,**stats(z[mask,c['index'],si])))
        info['cohorts'][cohort]=dict(assemblies=count,physical_objects=int((kind>=0).sum()),domains=int((kind==0).sum()),covalent_connections=int((kind==1).sum()),noncovalent_connections=int((kind==2).sum()),
           noncovalent_roles=int(np.isfinite(nc[:,:,:,0]).sum()),scored=int((status==1).sum()),status_counts=dict(statuscounts),boundary_annotations=dict(labelcounts),
           absent_display_cells=int((kind<0).sum()),all_physical_objects_scored=bool(((status==1)==(kind>=0)).all()),
           known_active=int((activities==1).sum()),known_inactive=int((activities==0).sum()),unknown_or_conflict=int((activities<0).sum()),
           score_summary={s:stats(z[:,:,i].ravel()) for i,s in enumerate(SCORES)},domain_types={str(k):v for k,v in types.items()})
        info['source_sha256'][path.name]=sha(path)
        print(json.dumps(dict(stage='COHORT_STATS_COMPLETE',cohort=cohort,objects=info['cohorts'][cohort]['physical_objects'])),flush=True)
    csvout(out/'column_quantiles.csv',colsummary);csvout(out/'object_type_quantiles.csv',typesummary)
    csvout(out/'assembly_summary_quantiles.csv',assemblysummary);csvout(out/'donor_position_quantiles.csv',donorsummary);csvout(out/'noncovalent_role_quantiles.csv',roletable)
    dump(out/'statistics_audit.json',info)
    return info

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--maps',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--step',type=int,choices=CHECKPOINTS,required=True)
    p.add_argument('--registry',type=Path,default=HERE/'source/verified_block_domains.json');p.add_argument('--labels',type=Path,default=HERE/'source/known_labels.json');a=p.parse_args()
    analyze(a.maps,a.out,a.step,a.registry,a.labels)
