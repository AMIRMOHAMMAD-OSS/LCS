"""CPU-only orchestration checks; does not load checkpoints or submit a job."""
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
import copy,json,subprocess,sys,tempfile
import numpy as np
import submit,run,library_features as lib,joint_features as jf

def rejected(fn):
    try:fn()
    except RuntimeError:return
    raise AssertionError('Expected failure was not raised')

def main():
    checks=[]
    probe=subprocess.run([sys.executable,'-S','-B','-c',"import submit,sys; assert 'numpy' not in sys.modules and 'torch' not in sys.modules; print('PASS')"],cwd=submit.PACKAGE,capture_output=True,text=True,check=True)
    assert probe.stdout.strip()=='PASS';checks.append('login_launcher_import_without_numpy_or_torch')
    reply=SimpleNamespace(stdout='1839175_[119-120,129,138,141,14 | unrelated_array\n',returncode=0)
    with patch.object(submit.subprocess,'run',return_value=reply):submit.check_queue('2143849','our_maps_job')
    for line in ['2143849 | a_name','2143849_13 | a_name','123 | our_maps_job','malformed']:
        with patch.object(submit.subprocess,'run',return_value=SimpleNamespace(stdout=line,returncode=0)):
            rejected(lambda:submit.check_queue('2143849','our_maps_job'))
    checks.append('queue_accepts_unrelated_arrays_and_rejects_duplicate_or_malformed_reply')
    role=dict(role=0,raw=.9,mixed=.8)
    row=dict(candidate_index=0,cohort='doubles',assembly_id='sample',objects=[dict(object_index=0,kind=0,status='SCORED',hidden_slots=1,visible_context_objects=12,raw=.9,mixed=.8,role_scores=[role])])
    assert run.compare_reference(row,copy.deepcopy(row),1e-5)==0
    for value in [.81,float('nan')]:
        altered=copy.deepcopy(row);altered['objects'][0]['mixed']=value
        rejected(lambda:run.compare_reference(altered,row,1e-5))
    altered=copy.deepcopy(row);altered['objects'][0]['hidden_slots']=2
    rejected(lambda:run.compare_reference(altered,row,1e-5))
    checks.append('parity_rejects_score_mask_and_nonfinite_differences')
    with tempfile.TemporaryDirectory() as td:
        p=Path(td);ident={'step':27000}
        assert not run.chunk_valid(p,ident,'doubles',[0])
        run.write_maps(p/'maps.jsonl.gz',[row])
        submit.dump(p/'COMPLETE.json',dict(identity=ident,cohort='doubles',indices=[0],maps_sha256=submit.sha(p/'maps.jsonl.gz')))
        assert run.chunk_valid(p,ident,'doubles',[0])
        rejected(lambda:run.chunk_valid(p,{'step':32000},'doubles',[0]))
        with (p/'maps.jsonl.gz').open('ab') as f:f.write(b'changed')
        rejected(lambda:run.chunk_valid(p,ident,'doubles',[0]))
    checks.append('resume_chunk_checksum_and_checkpoint_identity')
    protocol=submit.load(submit.PACKAGE/'protocol.json')
    assert all(protocol['inputs'][k]==v for k,v in lib.required_sources().items())
    for step,spec in protocol['checkpoints'].items():
        assert spec['sha256']==jf.checkpoint_spec(step)['sha256']
        assert spec['path']==jf.checkpoint_spec(step)['path']
    assert submit.sha(submit.PACKAGE/'ssl_changes.py')==jf.ATTENTION_SOURCE_SHA
    checks.append('full_input_and_checkpoint_and_attention_pins_match_existing_sources')
    print(json.dumps(dict(status='PASS',checks=checks,torch_or_checkpoint_execution=False),indent=2))

if __name__=='__main__':main()
