"""Exact complete-library inputs and unchanged frozen-26k feature extraction.

Import is standard-library only: preflight never imports Torch or loads a model.
Runtime uses pinned existing input packages and already-computed sequence banks.
No fitting, embedding extraction, or alternative checkpoint is provided here.
"""
from __future__ import annotations

from collections import Counter
import csv
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent
SCHEMA = "neuralps_complete_library_frozen26_v1"
LIBRARIES = {
    "doubles": {
        "bank": "neuralps_3675_double_score_20261104T163602Z_c06e1765/resolved_feature_bank.npz",
        "bank_sha256": "f19c4a8f760b5e4f86cc986e03190343c58cbbb16685e9eba9bf8013b2ede31d",
        "count": 3675,
        "input_dir": "NeurALPS_3675_Double_Inputs_20261104",
        "input_sha256": {
            "PACKAGE_MANIFEST.json": "90be6b0721c5038429f649e7254706708c4b27606bcf3527d18b318e358717e4",
            "README.txt": "f3da3dd22561208391fa2214d4062e7396ae1330c17f38fbf54513e3f160784c",
            "audit_boundaries.py": "6b6191e7fa5654bca495f7801a0d257e3432e7d9b897483b18687c4d46e1ca2c",
            "boundary_metadata.py": "6a7ac2971cedb3d2fb734f96ae96d64dd01d828bd03e78ceeefefd17e6d3b75b",
            "build_library.py": "3fd23ccc51d09c018e1ef0494ff6b0604deac4ba19f8addb5cfcbb4b7810f68b",
            "data/BOUNDARY_ANNOTATION_AUDIT.json": "cede6da8d04f2dff12570aeb4647d36dcaf7d389b19616d2922dc8663bed3399",
            "data/INDEPENDENT_COMPACT_AUDIT.json": "e9a2fe00d0fb058162f6c303c34282ce5e48e51dfa0454f6647d5ee7f2b61243",
            "data/RECONSTRUCTION_AUDIT.json": "7d8e4be3e310e2f88dfb3e8ec9a70c8d80a3992997a0b2323af5f55e79dd308c",
            "data/assemblies.jsonl.gz": "c17417868023c88fc550e8c0a28f5595026342f6c24e4c63383181a309858a78",
            "data/candidate_inventory.csv.gz": "489d791d5b00e09df25d78cf908fcbf48d97fe2a961cfcc062c3fca8aab65272",
            "data/known60_roundtrip_audit.json": "c7d1dfd97d5aca515959e708fef14d5cd0e3797fe1b61677353f9d56fb919bac",
            "data/mature_parents.fasta.gz": "4a611ebd02d51dbdfaf55c6809dc0b101b90d28ca47a43b35244668e9f916c9d",
            "data/model_indices.npz": "13d54da49c9852dea9c27fa97a2fe1155ea366f5373fb2ec536fadaef6cf0b14",
            "data/sequence_hashes.json": "9ce994f2b58f4b02488d222a46b2e67e29a23558c1bea3f541ed8e2cd78b12b6",
            "data/unique_slot_sequences.json.gz": "a42addd3174b9159bebf21ac963b7354e3e239568a6ccd72ebad4b902aea899a",
            "feature_bank/cached_feature_bank.npz": "a7dc01063b797ef7c34215aa011a59e5c74515c11777d59d3f736dc5facc9c61",
            "feature_bank/feature_bank.json": "fbe5c745447304f18f8d06492a636d3c1956764d113765741830fc83fc3905df",
            "feature_bank/missing_sequences.json": "174c218bd44fb17a571bf6cb328148414a1ac03bc734b27229e5d22588762188",
            "feature_bank/missing_source_evidence.json": "5cbec4d754a47f25c64c7621643eb3617543d89ffe74cda2fc48f178d13329f7",
            "inputs/historical_roundtrip_audit.json": "5a92dbaafc7a51d7635d5408da0f51c57b7732d10526e64b8cc020cc033ca7ca",
            "inputs/historical_source_audit.json": "28f1c9620d9f711aaaceb5bebfcd814283d9698d537e4ee5d68d15bbb3ad8e0a",
            "inputs/known_multis_model_inputs.json.gz": "8c1649dd790f0f590049567df73ec7ec4bda48990ad3b8bbf87a8551db908cd5",
            "inputs/verified_block_registry.json.gz": "5f0221a63d5f769ef10d746b8d63097082438b8e9feb5a92da5ad07db8eefe7d",
            "library_io.py": "f10669b8d5a200c773e93ef2c7aed4ed840be5a3824add647166b375ebf39347",
            "provenance/feature_banks/verified_42875_encoding_bank.json": "3144e7b19c9ddbfe03a94fc72375e90321cb6bfa75f88aa021b71dcd2588776b",
            "provenance/feature_banks/verified_known60_bank.json": "217a2cac4594adca4bf8f05b1cb6f65191c178bcd4cd27ec33436cfeca8e7a2c",
            "provenance/source_audit/INDEPENDENT_SOURCE_AUDIT.json": "aa1cef7d1518bf1d078a1ec7b5934777d40952d64f36fdfd3492c5567d3fa9bf",
            "provenance/source_audit/SOURCE_FAITHFULNESS.txt": "272362974c72f05b13c0e85e9277893f5079144fc6682fa1b62e6e4f753cfb7f",
            "provenance/source_audit/SOURCE_MANIFEST.json": "e856d4c75725479f996d2009a2066a90a0b225b4bb6e3652b85991e34870f490",
            "provenance/source_audit/audit_sources.py": "db977329250aad8abac579b1a167f2e463a055e7122f5b4b604b18d62456704f",
            "provenance/source_audit/source_evidence/known_multi_source_tuples.json": "472a9d8f6f4b6d3ebe345859e3039725fbc0d735c6cdac56739d097c037dfb30",
            "provenance/source_audit/source_evidence/reconstruction_evidence.jsonl.gz": "b335af24e96a3089a6fb590861295578a2d76e465d48ce02f536c6f13cb5c9fd",
            "provenance/source_audit/source_evidence/routes.jsonl.gz": "83b0f2e07adc07c5d53c6d41f387fb50f43ff85f9ef1ba70e241ea13d1005a21",
            "vendor/build_multis.py": "a59df55260e23a7352c069010321140aaa17f2a259454808a8a5c1f0bcb00572",
            "vendor/original_build_library.py": "ada1fbad0a5c9d09ccf329a15cf229f16c80988ecf965afb31051c34fc231c9f",
            "vendor/original_library_io.py": "f91264cad9030848805074c86145bfceba49545edb2d986eb4b379a361d58682"
        },
        "known": 33,
        "unique_sequences": 2750
    },
    "triples": {
        "bank": "neuralps_42875_encode_20261103T204641Z_641ae577/feature_bank/feature_bank.npz",
        "bank_sha256": "6702dc70a5b408b1c13829b2457e08432ed75c683a2c7f3018e8a48ce31dfcfc",
        "count": 42875,
        "input_dir": "NeurALPS_42875_Inputs_20261103",
        "input_sha256": {
            "ENCODING_LOCAL_VALIDATION.json": "606f30b86e5355dddbc723d1ceb5b659933a441738ac8ab9780d07402b65df29",
            "LOCAL_VALIDATION.json": "7b6b2b17a363b62b4d61f946dd665b66c940f7f92fd6269d7d6acdeeadbc8572",
            "PACKAGE_MANIFEST.json": "641ae577a5bbc6d6ec91354808df7654a7faabc097a657b2e3905a10d5dbea9d",
            "PROTOCOL.json": "6264da2b8bf5ee18f50b7da069ff5cc9972693ba95f1ef5f5073a177c5519262",
            "README.txt": "43ad393164da4b8695cefd6655696aaf541407363d52e76fcef2766bae4e7446",
            "batch.sh": "ce01ee272e4b4c85619f3cb7352d77109220904e52f7e83280f0fdffb1b3f10a",
            "build_library.py": "ada1fbad0a5c9d09ccf329a15cf229f16c80988ecf965afb31051c34fc231c9f",
            "builder_tests.py": "bc2a9e758d7edbfaca5534d026ffd8c02cc947fe956b94c13096582fcb22979b",
            "data/RECONSTRUCTION_AUDIT.json": "52403f8a61b2ea91f27bafb66d617f1e369c4282a71b3289232646c818920789",
            "data/assemblies.jsonl.gz": "c9936b4d794335ab4464e96e126928640e1291544642d5e0f1b80a7635a16a11",
            "data/candidate_inventory.csv.gz": "155952bd805e4dd60c26afe3ff53dd80fb8c7df6e9fb4574345b20917ae035f5",
            "data/known60_roundtrip_audit.json": "c7d1dfd97d5aca515959e708fef14d5cd0e3797fe1b61677353f9d56fb919bac",
            "data/mature_parents.fasta.gz": "47925f773364409dd969b25b0407a8dff19b5fadb5b9b768b9687f45150b239b",
            "data/model_indices.npz": "3819f867a910a5ec520e4e7747e793f97cb8b0ba199aae5527f9644f32b41f92",
            "data/sequence_hashes.json": "160ec9f015bd867f567e1132c355dc4d540f151c8832e79df08a32ccf1aa03e8",
            "data/unique_slot_sequences.json.gz": "b71347312e9e479bea1283a8dd144b47349e10b01b8a2f53d625b93563adf189",
            "encode_library.py": "d239fa648ccee69ff8becc4d9e851c120f3f9ad8a0d3cf42e331e9cc1b8796da",
            "encoding_tests.py": "3259ff8a45ee71eebf6af5138dbc2de51478ef1d02f598237ffe87fa4b00b9d5",
            "inputs/historical_roundtrip_audit.json": "5a92dbaafc7a51d7635d5408da0f51c57b7732d10526e64b8cc020cc033ca7ca",
            "inputs/historical_source_audit.json": "28f1c9620d9f711aaaceb5bebfcd814283d9698d537e4ee5d68d15bbb3ad8e0a",
            "inputs/known_multis_model_inputs.json.gz": "8c1649dd790f0f590049567df73ec7ec4bda48990ad3b8bbf87a8551db908cd5",
            "inputs/verified_block_registry.json.gz": "5f0221a63d5f769ef10d746b8d63097082438b8e9feb5a92da5ad07db8eefe7d",
            "library_io.py": "f91264cad9030848805074c86145bfceba49545edb2d986eb4b379a361d58682",
            "provenance/builder_audit/BUILD_LOCAL_VALIDATION.json": "44b227b7fa6d8a6ebb6f681b86158fa9a3cc77bbb9c8eaed75b565a0ab52e7c0",
            "provenance/builder_audit/builder_tests.log": "4c236d13330cfddd3522df1a6955fca82b14824a7debb6f040268beb5e358c7b",
            "provenance/source_audit/INDEPENDENT_SOURCE_AUDIT.json": "aa1cef7d1518bf1d078a1ec7b5934777d40952d64f36fdfd3492c5567d3fa9bf",
            "provenance/source_audit/SOURCE_FAITHFULNESS.txt": "272362974c72f05b13c0e85e9277893f5079144fc6682fa1b62e6e4f753cfb7f",
            "provenance/source_audit/SOURCE_MANIFEST.json": "e856d4c75725479f996d2009a2066a90a0b225b4bb6e3652b85991e34870f490",
            "provenance/source_audit/audit_sources.py": "db977329250aad8abac579b1a167f2e463a055e7122f5b4b604b18d62456704f",
            "provenance/source_audit/source_evidence/known_multi_source_tuples.json": "472a9d8f6f4b6d3ebe345859e3039725fbc0d735c6cdac56739d097c037dfb30",
            "provenance/source_audit/source_evidence/reconstruction_evidence.jsonl.gz": "b335af24e96a3089a6fb590861295578a2d76e465d48ce02f536c6f13cb5c9fd",
            "provenance/source_audit/source_evidence/routes.jsonl.gz": "83b0f2e07adc07c5d53c6d41f387fb50f43ff85f9ef1ba70e241ea13d1005a21",
            "provenance/submission_audit/validation.json": "c64d4fbf7b63ab749b4b0e523bb5ff167fde24fe1c4d9fe9f4a2a844d4043e2d",
            "provenance/submission_audit/verify_submission.py": "bcc023602ee1c7fd1838a1a47a1b076ef9f737cf541f914cf560b1af4be62311",
            "selftest.py": "3b29baf55cef2f68060a0cd56548290dfda5e27aa9463def60a9d327b2d93f43",
            "submit.py": "abf954e0eebfa2d7841440c03a14635864461b78ffda4da185198383a38be12c",
            "vendor/build_multis.py": "a59df55260e23a7352c069010321140aaa17f2a259454808a8a5c1f0bcb00572",
            "vendor_embed/__init__.py": "e554aea6d0ad89a800837fbdb4b79216f979dc3f708ee0d458fc5fe3e57da5f9",
            "vendor_embed/embedding_backend.py": "7f265efe1ac8eafa97d1ad0b4e6b69145dbbd217a6c225a4a637c306a3ba1f4d",
            "vendor_embed/legacy_assembly_model.py": "551772090b00a9bf0d5a44fa85a4014e103079c4dabd1f2b99259ed5441dd2f4"
        },
        "known": 27,
        "unique_sequences": 2602
    }
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for part in iter(lambda: stream.read(8 << 20), b""):
            h.update(part)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def required_sources(cohorts=("doubles", "triples")):
    """Return project-relative exact SHA pins, including untouched input registries."""
    if isinstance(cohorts, str):
        cohorts = (cohorts,)
    result = {}
    for cohort in cohorts:
        require(cohort in LIBRARIES, "Unknown library cohort: " + str(cohort))
        spec = LIBRARIES[cohort]
        for relative, expected in spec["input_sha256"].items():
            result[spec["input_dir"] + "/" + relative] = expected
        result[spec["bank"]] = spec["bank_sha256"]
    # Both libraries use this identical source-supported display overlay.
    double = LIBRARIES["doubles"]
    for relative in ("boundary_metadata.py", "provenance/source_audit/source_evidence/routes.jsonl.gz"):
        result[double["input_dir"] + "/" + relative] = double["input_sha256"][relative]
    return dict(sorted(result.items()))


def validate_sources(root, full=False, cohorts=("doubles", "triples")):
    """Stat all exact sources; full=True additionally hashes every source on compute."""
    root = Path(root).resolve()
    receipt = {}
    for relative, expected in required_sources(cohorts).items():
        path = root / relative
        require(path.is_file() and path.resolve().is_relative_to(root), "Missing/escaped source: " + relative)
        before = path.stat()
        require(before.st_size > 0, "Empty source: " + relative)
        actual = sha(path) if full else None
        after = path.stat()
        require((before.st_size, before.st_mtime_ns, before.st_ino) ==
                (after.st_size, after.st_mtime_ns, after.st_ino), "Source changed during validation: " + relative)
        require(not full or actual == expected, "Pinned source checksum differs: " + relative)
        receipt[relative] = dict(bytes=after.st_size, mtime_ns=after.st_mtime_ns,
                                 inode=after.st_ino, expected_sha256=expected)
        if full:
            receipt[relative]["sha256"] = actual
    return receipt


def canonical_donors(codes):
    codes = tuple("native" if str(c) in ("X", "native") else str(c) for c in codes)
    require(len(codes) == 3, "Expected exactly three donor codes")
    require(all(c == "native" or (len(c) == 3 and c.isdigit()) for c in codes), "Invalid donor code")
    return codes


def physical_identity(record):
    """Chain order and multiplicity are physical identity; design/source names are not."""
    parents = record["parent_sequence_hashes"]
    ordered = sorted(parents, key=lambda uid: int(uid.rsplit("=", 1)[1]))
    ordinals = [int(uid.rsplit("=", 1)[1]) for uid in ordered]
    require(ordinals == list(range(1, len(ordered) + 1)), "Noncontiguous mature-chain ordinals")
    hashes = [parents[uid] for uid in ordered]
    return dict(sequence_key=digest(hashes), parent_sequence_hashes=hashes,
                parent_chain_lengths=[int(record["parent_lengths"][uid]) for uid in ordered])


def _load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _known_registry():
    with gzip.open(PACKAGE / "labelled_assets/known_multis_model_inputs.json.gz", "rt") as stream:
        records = json.load(stream)["records"]
    require(Counter(r["cohort"] for r in records) == {"doubles": 33, "triples": 27}, "Known design inventory differs")
    by_donors = {canonical_donors(r["donors"]): r for r in records}
    require(len(by_donors) == 60, "Duplicate known donor design")
    sequence_keys = {physical_identity(r)["sequence_key"] for r in records}
    return by_donors, sequence_keys


def block_physical_signature(block):
    """Preserve complete residues and internal chain segmentation, not only domains."""
    return tuple(segment["sequence"] for segment in block)


def registry_sequence_key(registry, donor_codes):
    """Same certified splice semantics as compose_blocks; only physical chain hashes."""
    chains = []
    for p, code in enumerate(canonical_donors(donor_codes)):
        for k, segment in enumerate(registry["blocks"][p][code]):
            if chains and k == 0:
                chains[-1] += segment["sequence"]
            else:
                chains.append(segment["sequence"])
    return digest([hashlib.sha256(sequence.encode("ascii")).hexdigest() for sequence in chains])


def known_single_physical_keys(registry):
    """All original native+105 single designs; outcomes are never consulted."""
    donors = sorted(set(registry["blocks"][0]) - {"native"})
    require(len(donors) == 35, "Known single donor registry differs")
    equivalent = []
    keys = {registry_sequence_key(registry, ("native",) * 3)}
    for p in range(3):
        table = registry["blocks"][p]
        require(set(table) == set(donors) | {"native"}, "Known single positions differ")
        native = block_physical_signature(table["native"])
        equivalent.append({d for d in table if block_physical_signature(table[d]) == native})
        for donor in donors:
            choice = ["native"] * 3
            choice[p] = donor
            keys.add(registry_sequence_key(registry, choice))
    return equivalent, keys


class LibrarySource:
    """Read-only adapter for one exact compact candidate library and cached bank."""

    def __init__(self, root, cohort, verify=True):
        import numpy as np
        self.root = Path(root).resolve()
        require(cohort in LIBRARIES, "Unknown library cohort")
        self.cohort, self.spec = cohort, LIBRARIES[cohort]
        self.count = self.spec["count"]
        if verify:
            validate_sources(self.root, full=True, cohorts=(cohort,))
        self.input_dir = self.root / self.spec["input_dir"]
        # Executable source hashes are always checked even if caller already hashed all data.
        for relative, expected in self.spec["input_sha256"].items():
            if relative.endswith(".py"):
                require(sha(self.input_dir / relative) == expected, "Executable input source differs: " + relative)
        self.io = _load_module(self.input_dir / "library_io.py", "final_library_io_" + cohort)
        self.library = self.io.Library()
        self.registry = self.library.registry
        require(len(self.library) == self.spec["count"], "Incomplete library")
        with gzip.open(self.input_dir / "data/candidate_inventory.csv.gz", "rt") as stream:
            self.inventory = list(csv.DictReader(stream))
        self.ids = [str(x) for x in self.library.arrays["assembly_ids"]]
        require(len(self.ids) == len(set(self.ids)) == self.spec["count"], "Duplicate/incomplete candidate IDs")
        require([r["assembly_id"] for r in self.inventory] == self.ids, "Candidate inventory/compact order differs")
        with np.load(self.root / self.spec["bank"], allow_pickle=False) as bank:
            hashes, matrix = bank["hashes"].tolist(), bank["vectors"].copy()
        require(len(hashes) == len(set(hashes)) == self.spec["unique_sequences"], "Cached sequence set differs")
        require(matrix.shape == (len(hashes), 1152) and matrix.dtype == np.float32 and
                np.isfinite(matrix).all() and (np.abs(matrix).sum(1) > 0).all(), "Invalid cached feature vectors")
        expected_hashes = [str(h) for h in self.library.sequence_hashes]
        require(set(hashes) == set(expected_hashes), "Cached feature coverage differs")
        self.vectors = dict(zip(hashes, matrix))
        self.matrix = np.stack([self.vectors[h] for h in expected_hashes])
        self.known, self.known_sequences = _known_registry()
        self.native_equivalent_donors, single_keys = known_single_physical_keys(self.library.registry)
        self.known_sequences.update(single_keys)
        self.known_sequence_keys = sorted(self.known_sequences)
        with (PACKAGE / "labelled_assets/donors.csv").open(newline="") as stream:
            self.donor_table = {r["donor_id"]: r for r in csv.DictReader(stream)}
        double = LIBRARIES["doubles"]
        overlay_path = self.root / double["input_dir"] / "boundary_metadata.py"
        require(sha(overlay_path) == double["input_sha256"]["boundary_metadata.py"], "Boundary overlay source differs")
        overlay = _load_module(overlay_path, "final_boundary_metadata_" + cohort)
        self.annotator = overlay.BoundaryAnnotations(self.input_dir)
        self._last_pairs = {}
        self.index_by_donors = {}
        for i, aid in enumerate(self.ids):
            codes = canonical_donors(aid.removeprefix("BODE2_").split("-"))
            require(codes.count("native") == (1 if cohort == "doubles" else 0), "Wrong exchange count")
            require(all(c == "native" or c in self.donor_table for c in codes), "Unregistered donor")
            require(codes not in self.index_by_donors, "Duplicate donor design")
            self.index_by_donors[codes] = i
        known_count = sum(codes in self.known for codes in self.index_by_donors)
        require(known_count == self.spec["known"], "Known full-library design coverage differs")

    def __len__(self):
        return self.spec["count"]

    def _indices(self, indices):
        import numbers
        indices = list(indices)
        require(indices and all(isinstance(i, numbers.Integral) and not isinstance(i, bool) and
                                0 <= int(i) < len(self) for i in indices), "Invalid library indices")
        return [int(i) for i in indices]

    def pairs(self, indices):
        indices = self._indices(indices)
        result = []
        for i in indices:
            if i in self._last_pairs:
                record, parents = self._last_pairs[i]
            elif self.cohort == "doubles":
                record, parents = self.library.get_pair(i)
            else:
                n = len(self.library.donors)
                donors = [self.library.donors[i // (n*n)], self.library.donors[(i // n) % n], self.library.donors[i % n]]
                record, parents = self.io.reconstruct(donors, self.library.registry, self.library.constructor)
            require(record["assembly_id"] == self.ids[i], "Reconstructed candidate identity differs")
            require(self.io.model_signature(record) == str(self.library.arrays["model_signatures"][i]),
                    "Reconstructed model input signature differs")
            identity = physical_identity(record)
            require(identity["sequence_key"] == self.inventory[i]["physical_sequence_signature"] ==
                    self.io.sequence_signature(record), "Reconstructed physical sequence differs")
            require(canonical_donors(record["donors"]) == canonical_donors(self.ids[i].removeprefix("BODE2_").split("-")),
                    "Reconstructed donor assignments differ")
            result.append((record, parents))
        self._last_pairs = dict(zip(indices, result))
        return result

    def metadata(self, indices, pairs=None):
        indices = self._indices(indices)
        pairs = self.pairs(indices) if pairs is None else pairs
        require(len(pairs) == len(indices), "Pair/index length differs")
        result = []
        for i, (record, _) in zip(indices, pairs):
            require(record["assembly_id"] == self.ids[i], "Metadata pair/index identity differs")
            codes = canonical_donors(record["donors"])
            ident = physical_identity(record)
            native = [p + 2 for p, c in enumerate(codes) if c == "native"]
            donor_sources = []
            for p, code in enumerate(codes):
                source = dict(self.donor_table.get(code, {}))
                source.update(self.library.registry["sources"][p][code])
                source.update(donor_code=code, recipient_position="XUT" + str(p + 2))
                donor_sources.append(source)
            exact_known = codes in self.known
            result.append(dict(assembly_id=record["assembly_id"], cohort=self.cohort, dataset="bode2",
                candidate_index=i, donor_codes=list(codes), retained_native="XUT" + str(native[0]) if native else None,
                is_known=exact_known,
                effective_exchange_count=sum(code not in self.native_equivalent_donors[p] for p, code in enumerate(codes)),
                is_known_design=exact_known, is_known_sequence=ident["sequence_key"] in self.known_sequences,
                donor_sources=donor_sources, plasmid_combination=record["plasmid_combination"],
                input_inventory=dict(self.inventory[i]), **ident))
        return result

    def numpy_batch(self, indices):
        return self.library.numpy_batch(self._indices(indices), self.matrix)

    def torch_batch(self, indices, device="cuda"):
        import torch
        return {k: torch.from_numpy(v).to(device) for k, v in self.numpy_batch(indices).items()}


def load_library(root, cohort, verify=True):
    return LibrarySource(root, cohort, verify=verify)


def compact_parity(source, indices):
    """Exact compact-vs-original collator equality, before model inference."""
    import numpy as np
    from vendor_neural.assembly_model import collate_records
    records = [r for r, _ in source.pairs(indices)]
    direct = collate_records(records, source.vectors.__getitem__)
    compact = source.numpy_batch(indices)
    require(set(compact) == set(direct), "Collator tensor fields differ")
    for key in compact:
        expected = direct[key].cpu().numpy() if hasattr(direct[key], "cpu") else direct[key]
        require(np.array_equal(compact[key], expected), "Compact collator differs: " + key)
    return dict(status="PASS", rows=len(records), fields=sorted(compact))


def extract_chunk(source, indices, model, means, mean_map, design, device="cuda"):
    """Return rows, aligned arrays, column names and full physical-object maps.

    Each forward retains the original singleton layout and exact feature functions;
    chunks only group output commits. Physical break roles remain separate in maps.
    """
    import numpy as np
    import torch
    import frozen_features as ff
    indices = source._indices(indices)
    pairs = source.pairs(indices)
    rows = source.metadata(indices, pairs)
    arrays = {key: [] for key in ("context", "chemistry", "structure", "compatibility")}
    maps, columns = [], None
    require(not model.training and not any(p.requires_grad for p in model.parameters()), "Encoder is not frozen")
    for i, meta, (record, parents) in zip(indices, rows, pairs):
        codes = canonical_donors(record["donors"])
        clean = source.torch_batch([i], device)
        static = design.batch_static([record], [codes], device)
        with torch.inference_mode():
            hidden = model.features(clean)[0].cpu().numpy()
        require(np.isfinite(hidden).all(), "Nonfinite clean context")
        values, names = ff.clean_features(hidden, clean, static, codes)
        objects = ff.score_objects(model, clean, record, parents, means, mean_map)
        groups = ff.regions_for_record(record, static["blocks"][0].cpu().numpy(), static["seams"][0].cpu().numpy(), codes)
        values["compatibility"], names["compatibility"] = ff.map_summary(objects, groups)
        require(columns is None or columns == names, "Feature columns changed")
        columns = names
        for key, value in values.items():
            require(not np.isinf(value).any() and (key == "compatibility" or np.isfinite(value).all()), "Invalid " + key + " feature")
            arrays[key].append(value)
        displayed = source.annotator.annotate_record(record)
        require(source.io.model_signature(displayed) == source.io.model_signature(record), "Map annotation changed model input")
        for j, obj in enumerate(objects):
            annotation = displayed["route"][j]
            # Lean maps preserve physical kind separately from supported B/J labels.
            # Full source provenance is exported only for selected records via pairs().
            obj["annotation"] = {key: annotation[key] for key in (
                "canonical_domain_type", "raw_domain_type", "domain_type", "chain", "annotation",
                "start_aa_0based", "end_aa_0based_exclusive") if key in annotation}
        meta["expected_peptide_aa"] = list(design.features(record, codes)[-1])
        statuses = dict(Counter(o["status"] for o in objects))
        meta["map_coverage"] = dict(total_objects=len(objects), scored_objects=statuses.get("SCORED", 0), statuses=statuses)
        maps.append(dict(candidate_index=i, assembly_id=record["assembly_id"], cohort=source.cohort,
                         donor_codes=list(codes), objects=objects, regions=groups,
                         boundary_annotation_policy=displayed["boundary_annotation_policy"],
                         model_signature=source.io.model_signature(record), sequence_key=meta["sequence_key"],
                         checkpoint_sha256=ff.CHECKPOINT_SHA))
    return dict(rows=rows, features={key: np.stack(values).astype(np.float32) for key, values in arrays.items()},
                columns=columns, maps=maps)


def known_feature_parity(source, model, means, mean_map, design, baseline_features, baseline_rows, device="cuda", atol=1e-4):
    """Gate full-library inference against all available known multis from fixed 552 rows."""
    import numpy as np
    import frozen_features as ff
    if isinstance(baseline_rows, dict):
        baseline_rows = baseline_rows["rows"]
    references = [r for r in baseline_rows if r["cohort"] == source.cohort]
    require(len(references) == (31 if source.cohort == "doubles" else 27), "Baseline multi parity cohort differs")
    feature_error = {key: 0. for key in baseline_features}
    for start in range(0, len(references), 8):
        refs = references[start:start + 8]
        indices = [source.index_by_donors[canonical_donors(r["donor_codes"])] for r in refs]
        compact_parity(source, indices)
        result = extract_chunk(source, indices, model, means, mean_map, design, device)
        for b, ref in enumerate(refs):
            require(result["rows"][b]["assembly_id"] == ref["assembly_id"], "Baseline identity mismatch")
            require(result["maps"][b]["model_signature"] == ref["route_fingerprint"], "Baseline route signature mismatch")
            for key, array in result["features"].items():
                actual, expected = array[b], baseline_features[key][ref["index"]]
                require(np.array_equal(np.isnan(actual), np.isnan(expected)), "Baseline missingness differs: " + key)
                finite = np.isfinite(expected)
                error = float(np.max(np.abs(actual[finite] - expected[finite]), initial=0.))
                feature_error[key] = max(feature_error[key], error)
                if key in ("chemistry", "structure"):
                    require(np.array_equal(actual, expected), "Static feature parity failed: " + key)
                else:
                    require(np.allclose(actual, expected, atol=atol, rtol=0., equal_nan=True),
                            "Frozen feature parity failed: " + key + " max_abs=" + str(error))
    return dict(status="PASS", cohort=source.cohort, known_rows=len(references),
                checkpoint_sha256=ff.CHECKPOINT_SHA, max_abs_error=feature_error, tolerance=atol,
                static_features_exact=True, activity_labels_used=False)
