"""Resumable inference-only full-library maps with matched reference checks."""
from pathlib import Path
from collections import Counter
import gzip,json,os,signal,time,zipfile
import numpy as np
import submit
from submit import require,load,sha,dump
PACKAGE=Path(__file__).resolve().parent
STOP=False
def stop(*_):
    global STOP
    STOP=True
def lines(path):
    with gzip.open(path,'rt') as f:
        for x in f:yield json.loads(x)
def write_maps(p,rows):
    tmp=p.with_suffix(p.suffix+'.tmp')
    with tmp.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,compresslevel=4) as f:
            for r in rows:f.write((json.dumps(r,sort_keys=True,allow_nan=False,separators=(',',':'))+'\n').encode())
        raw.flush();os.fsync(raw.fileno())
    tmp.replace(p)
def chunk_valid(folder,identity,cohort,indices):
    p=folder/'COMPLETE.json'
    if not p.exists():return False
    r=load(p);require(r['identity']==identity and r['cohort']==cohort and r['indices']==indices,'Chunk identity differs')
    require(sha(folder/'maps.jsonl.gz')==r['maps_sha256'],'Committed chunk changed')
    rows=list(lines(folder/'maps.jsonl.gz'))
    require([r['candidate_index'] for r in rows]==indices and all(r['cohort']==cohort for r in rows),'Chunk rows differ')
    return True
def compare_reference(a,b,tol):
    require(a['assembly_id']==b['assembly_id'],'Parity identity differs')
    require(len(a['objects'])==len(b['objects']),'Parity object count differs')
    error=0.
    for x,y in zip(a['objects'],b['objects']):
        for key in ['object_index','kind','status','hidden_slots','visible_context_objects']:require(x.get(key)==y.get(key),'Parity object contract differs: '+key)
        require(len(x['role_scores'])==len(y['role_scores']),'Parity role count differs')
        if x['status']=='SCORED':
            for key in ['raw','mixed']:
                require(np.isfinite(x[key]) and np.isfinite(y[key]),'Nonfinite parity score')
                error=max(error,abs(x[key]-y[key]))
            for u,v in zip(x['role_scores'],y['role_scores']):
                require(u['role']==v['role'],'Parity terminal role differs')
                for key in ['raw','mixed']:
                    require(np.isfinite(u[key]) and np.isfinite(v[key]),'Nonfinite parity role score')
                    error=max(error,abs(u[key]-v[key]))
    require(error<=tol,'Known construct map differs from previous checkpoint scoring')
    return error
def score_one(source,index,model,means,mean_map,step):
    import frozen_features as ff
    import library_features as lib
    record,parents=source.pairs([index])[0];clean=source.torch_batch([index],'cuda')
    objects=ff.score_objects(model,clean,record,parents,means,mean_map)
    displayed=source.annotator.annotate_record(record)
    require(source.io.model_signature(displayed)==source.io.model_signature(record),'Annotation changed model input')
    for obj,ann in zip(objects,displayed['route'],strict=True):
        obj['annotation']={k:ann[k] for k in ['canonical_domain_type','raw_domain_type','domain_type','chain','annotation','start_aa_0based','end_aa_0based_exclusive'] if k in ann}
    ident=lib.physical_identity(record)
    return dict(candidate_index=index,assembly_id=record['assembly_id'],cohort=source.cohort,donor_codes=list(lib.canonical_donors(record['donors'])),
        objects=objects,model_signature=source.io.model_signature(record),sequence_key=ident['sequence_key'],
        boundary_annotation_policy=displayed['boundary_annotation_policy'],checkpoint_sha256=step['sha256'])
def paired_summary(base,other,out):
    from analyze_all_maps import cols,stats,csvout
    rows=[]
    for cohort in ['doubles','triples']:
        a=dict(np.load(base/f'{cohort}_aligned_scores.npz',allow_pickle=False));b=dict(np.load(other/f'{cohort}_aligned_scores.npz',allow_pickle=False))
        for key in ['assembly_ids','donors','retained_native','sequence_keys','model_signatures','kinds','domain_types','boundary_annotation','hidden_slots','visible_context_objects','scored']:
            require(np.array_equal(a[key],b[key]),'Matched object/mask identities differ across checkpoints: '+key)
        for si,score in enumerate(['raw','mixed']):
            d=b['scores'][:,:,si].astype(np.float64)-a['scores'][:,:,si].astype(np.float64)
            for c in cols:
                v=d[:,c['index']];finite=v[np.isfinite(v)]
                rows.append(dict(cohort=cohort,column=c['key'],score=score,**stats(v),fraction_increased=float(np.mean(finite>0)) if len(finite) else None))
    csvout(out,rows)
def export(out):
    files={}
    for folder in ['step_26000','step_27000','step_32000']:
        for p in (out/folder).rglob('*'):
            if p.is_file() and ('statistics' in p.parts or p.name in ['COMPLETE.json','known58_parity.json']):files[str(p.relative_to(out))]=p
    for p in out.glob('*_minus_*.csv'):files[p.name]=p
    for name in ['REQUEST.json','SUBMISSION.json','COMPLETE.json','verified_inputs.json']:files[name]=out/name
    for name in load(PACKAGE/'PACKAGE_MANIFEST.json')['files']:files['reproduce/'+name]=PACKAGE/name
    files['reproduce/PACKAGE_MANIFEST.json']=PACKAGE/'PACKAGE_MANIFEST.json'
    manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
    tmp=out/'inspection.zip.tmp'
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,p in sorted(files.items()):z.write(p,n)
        z.writestr('REVIEW_MANIFEST.json',json.dumps(dict(schema='all_library_object_maps_review_v1',files=manifest,
            all_scores='step_*/statistics/*_aligned_scores.npz; all physical objects and noncovalent roles',raw_json_maps='retained on HPC; same values in compact arrays'),indent=2))
    require(tmp.stat().st_size<95_000_000,'Review archive exceeds transfer limit; files retained on HPC')
    with zipfile.ZipFile(tmp) as z:require(z.testzip() is None,'Review archive CRC failed')
    tmp.replace(out/'inspection.zip');h=sha(out/'inspection.zip');(out/'inspection.sha256').write_text(h+'\n')
    print('RESULT_ZIP:',out/'inspection.zip','\nRESULT_SHA256:',h,flush=True)
def execute(root,out,request):
    import torch
    import frozen_features as ff
    import joint_features as jf
    import library_features as lib
    import analyze_all_maps as analysis
    require(torch.cuda.is_available(),'CUDA required; use the Slurm allocation')
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True;torch.set_float32_matmul_precision('highest')
    signal.signal(signal.SIGUSR1,stop);signal.signal(signal.SIGTERM,stop)
    started=time.monotonic();deadline=started+load(out/'SUBMISSION.json').get('hours',request['hours'])*3600-360
    protocol=load(PACKAGE/'protocol.json')
    def emit(stage,**kw):
        r=dict(stage=stage,elapsed_seconds=round(time.monotonic()-started,2),**kw);dump(out/'progress.json',r);print(json.dumps(r),flush=True)
    def pause():
        if STOP or time.monotonic()>deadline:
            dump(out/'PAUSED.json',dict(status='PAUSED_RESUMABLE',reason='allocation signal or time reserve'));emit('PAUSED_RESUMABLE');return True
        return False
    try:
        emit('VERIFYING_PINNED_INPUTS');verified=submit.check_inputs(root,full=True);require(verified==request['inputs'],'Sources changed');dump(out/'verified_inputs.json',verified)
        for p in ['PAUSED.json','fatal_error.json']:
            if (out/p).exists():(out/p).unlink()
        baseline=root/protocol['baseline26'];done=load(baseline/'COMPLETE.json')
        require(done['status']=='PATRICK_FINAL_SCORING_COMPLETE' and done['checkpoint_step']==26000,'Wrong baseline26 run')
        stats26=out/'step_26000/statistics'
        base_receipt=out/'step_26000/COMPLETE.json'
        if base_receipt.exists():
            old=load(base_receipt);require(old['package_sha256']==request['package_sha256'],'Baseline stats package differs')
            for n,h in old['payloads'].items():require(sha(stats26/n)==h,'Baseline statistics payload changed: '+n)
        else:
            emit('SUMMARIZING_EXISTING_26000_MAPS');analysis.analyze(baseline,stats26,26000,PACKAGE/'source/verified_block_domains.json',PACKAGE/'source/known_labels.json')
            dump(base_receipt,dict(status='EXISTING_26000_MAPS_SUMMARIZED',package_sha256=request['package_sha256'],payloads={p.name:sha(p) for p in stats26.iterdir() if p.is_file()}))
        sources={c:lib.load_library(root,c,verify=False) for c in ['doubles','triples']}
        for c,s in sources.items():lib.compact_parity(s,[0,len(s)//2,len(s)-1])
        for stepkey,spec in protocol['checkpoints'].items():
            step=int(stepkey);dest=out/f'step_{step}';dest.mkdir(exist_ok=True)
            identity=dict(package_sha256=request['package_sha256'],protocol_sha256=request['protocol_sha256'],checkpoint_sha256=spec['sha256'],step=step)
            if (dest/'COMPLETE.json').exists():
                saved=load(dest/'COMPLETE.json');require(saved['identity']==identity,'Completed step identity changed')
                for n,h in saved['payloads'].items():require(sha(dest/n)==h,'Completed step payload changed: '+n)
                emit('REUSING_COMPLETE_STEP',checkpoint_step=step);continue
            if pause():return
            model,means,mean_map,labelled_manifest=jf.load_encoder(root,stepkey,'cuda');before=ff.state_digest(model)
            references={r['assembly_id']:r for r in lines(root/spec['reference_maps']) if r['assembly_id'].startswith('BODE2_') and len(r['objects'])>0}
            known_ids={r['assembly_id'] for r in load(PACKAGE/'source/known_labels.json')};references={k:v for k,v in references.items() if k in known_ids}
            require(len(references)==58,'Expected58 known map parity rows');parity={}
            emit('VERIFYING_KNOWN58_MAP_PARITY',checkpoint_step=step)
            for aid,ref in references.items():
                if pause():return
                codes=lib.canonical_donors(aid.removeprefix('BODE2_').split('-'))
                src=sources['doubles' if 'native' in codes else 'triples']
                actual=score_one(src,src.index_by_donors[codes],model,means,mean_map,spec)
                compare_reference(actual,ref,protocol['known_parity_atol'])
            emit('KNOWN58_MAP_PARITY_PASS',checkpoint_step=step)
            for cohort,source in sources.items():
                for start in range(0,len(source),protocol['chunk_size']):
                    if pause():return
                    indices=list(range(start,min(start+protocol['chunk_size'],len(source))));folder=dest/'chunks'/cohort/f'{start:06d}';folder.mkdir(parents=True,exist_ok=True)
                    if not chunk_valid(folder,identity,cohort,indices):
                        rows=[score_one(source,i,model,means,mean_map,spec) for i in indices]
                        for r in rows:
                            if r['assembly_id'] in references:compare_reference(r,references[r['assembly_id']],protocol['known_parity_atol'])
                        write_maps(folder/'maps.jsonl.gz',rows)
                        dump(folder/'COMPLETE.json',dict(identity=identity,cohort=cohort,indices=indices,maps_sha256=sha(folder/'maps.jsonl.gz')))
                    for r in lines(folder/'maps.jsonl.gz'):
                        if r['assembly_id'] in references:parity[r['assembly_id']]=compare_reference(r,references[r['assembly_id']],protocol['known_parity_atol'])
                    if start%1024==0 or indices[-1]+1==len(source):emit('LIBRARY_OBJECT_SCORING',checkpoint_step=step,cohort=cohort,completed=indices[-1]+1,total=len(source))
                paths=sorted((dest/'chunks'/cohort).glob('*/maps.jsonl.gz'))
                write_maps(dest/f'{cohort}_maps.jsonl.gz',(r for p in paths for r in lines(p)))
            require(len(parity)==58,'Known parity coverage incomplete');dump(dest/'known58_parity.json',dict(status='PASS',max_absolute_error=max(parity.values()),rows=parity))
            after=ff.state_digest(model);require(before==after and not model.training and not any(p.requires_grad or p.grad is not None for p in model.parameters()),'Frozen model changed')
            del model;torch.cuda.empty_cache()
            emit('SUMMARIZING_COMPLETE_MAPS',checkpoint_step=step)
            analysis.analyze(dest,dest/'statistics',step,PACKAGE/'source/verified_block_domains.json',PACKAGE/'source/known_labels.json')
            paired_summary(stats26,dest/'statistics',out/f'{step}_minus_26000.csv')
            payloads={str(p.relative_to(dest)):sha(p) for p in (dest/'statistics').iterdir() if p.is_file()}
            payloads['known58_parity.json']=sha(dest/'known58_parity.json')
            dump(dest/'COMPLETE.json',dict(status='LIBRARY_OBJECT_MAPS_COMPLETE',identity=identity,encoder_state_before=before,encoder_state_after=after,payloads=payloads,encoder_training=False))
        paired_summary(out/'step_27000/statistics',out/'step_32000/statistics',out/'32000_minus_27000.csv')
        require(submit.check_inputs(root)==request['inputs'],'Input files changed during inference')
        dump(out/'COMPLETE.json',dict(status='ALL_LIBRARY_MAPS_2732_COMPLETE',checkpoints=[26000,27000,32000],new_inference_steps=[27000,32000],designs_per_checkpoint=46550,encoder_updates=0,classifier_training=False,embedding_extraction=False,elapsed_seconds=round(time.monotonic()-started,2)))
        export(out);emit('ALL_LIBRARY_MAPS_2732_COMPLETE')
    except Exception as exc:
        dump(out/'fatal_error.json',dict(type=type(exc).__name__,message=str(exc)));raise
