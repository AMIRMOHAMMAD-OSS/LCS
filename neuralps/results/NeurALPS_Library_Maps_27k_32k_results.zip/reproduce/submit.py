#!/usr/bin/env python3
"""Submit frozen object-map inference for every doublet/triplet at27k and32k.

Login commands use only the standard library. Full file hashing and all model
operations occur inside the compute allocation. Repeated run does not resubmit.
"""
import argparse,fcntl,getpass,hashlib,json,os,re,subprocess,sys,time
from collections import deque
from pathlib import Path
PACKAGE=Path(__file__).resolve().parent
PREFIX='neuralps_library_maps2732_'
RECEIPT='neuralps_library_maps2732_submission.json'
LOCK='neuralps_library_maps2732_submission.lock'
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def load(p):return json.loads(Path(p).read_text())
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8<<20),b''):h.update(b)
    return h.hexdigest()
def dump(p,v):
    p=Path(p);tmp=p.with_name(p.name+'.tmp')
    with tmp.open('w') as f:f.write(json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
    tmp.replace(p)
def package_digest():
    p=PACKAGE/'PACKAGE_MANIFEST.json';manifest=load(p)
    require(all(n in manifest['files'] for n in ['submit.py','run.py','batch.sh','protocol.json','analyze_all_maps.py','joint_features.py','frozen_features.py','library_features.py','ssl_changes.py']),'Incomplete package manifest')
    for n,h in manifest['files'].items():
        q=(PACKAGE/n).resolve();require(q.is_relative_to(PACKAGE) and q.is_file() and sha(q)==h,'Package changed: '+n)
    return sha(p)
def check_inputs(root,full=False):
    protocol=load(PACKAGE/'protocol.json');result={}
    require(all(protocol[k] is False for k in ['encoder_training','classifier_training','embedding_extraction']),'Inference-only contract changed')
    for n,h in protocol['inputs'].items():
        p=(root/n).resolve();require(p.is_relative_to(root) and p.is_file(),'Missing project input: '+n)
        st=p.stat();require(st.st_size>0,'Empty input: '+n)
        if full:require(sha(p)==h,'Input checksum differs: '+n)
        after=p.stat();require((st.st_ino,st.st_size,st.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns),'Input changed while checking: '+n)
        result[n]=dict(bytes=st.st_size,mtime_ns=st.st_mtime_ns,sha256=h)
    return result
def checked_output(root,p):
    p=Path(p).resolve();require(p.is_relative_to(root) and p.parent==root and p.name.startswith(PREFIX),'Unexpected output directory');return p
def read_request(root,out):
    r=load(out/'REQUEST.json');require((out/'REQUEST.sha256').read_text().strip()==sha(out/'REQUEST.json'),'Request checksum differs')
    require(r['root']==str(root) and r['output']==str(out) and r['package']==str(PACKAGE),'Request location differs')
    require(r['package_sha256']==package_digest() and r['protocol_sha256']==sha(PACKAGE/'protocol.json'),'Request package changed')
    require(r['inputs']==check_inputs(root),'Project inputs changed since submission')
    return r
def check_queue(job_id,job_name):
    r=subprocess.run(['squeue','-h','-u',getpass.getuser(),'-o','%64i|%128j'],capture_output=True,text=True,timeout=30,check=True)
    for line in r.stdout.splitlines():
        if not line.strip():continue
        jid,sep,name=line.partition('|');jid=jid.strip();name=name.strip()
        require(sep and jid and name and '|' not in name,'Unrecognized scheduler reply: '+line)
        same=bool(job_id) and (jid==job_id or jid.startswith(job_id+'_') or jid.startswith(job_id+'.'))
        require(not same and name!=job_name,'Allocation already queued/running: '+line)
def complete(out):
    return (out/'COMPLETE.json').is_file() and (out/'inspection.zip').is_file() and (out/'inspection.sha256').is_file()
def status(receipt):
    r=load(receipt);out=Path(r['output']);print('Submission:',r['status'],'\nOutput:',out,flush=True)
    jid=r.get('job_id','')
    if jid.isdigit():
        a=subprocess.run(['sacct','-j',jid,'--format=JobID,State,ExitCode,Elapsed'],capture_output=True,text=True,timeout=30)
        print(a.stdout.strip() or a.stderr.strip());print('Log:',out/f'slurm_{jid}.log')
    if (out/'progress.json').is_file():print('Progress:',json.dumps(load(out/'progress.json')))
    for n in ['PAUSED.json','fatal_error.json','COMPLETE.json']:
        if (out/n).is_file():print(n+':',json.dumps(load(out/n)))
    if complete(out):print('RESULT_ZIP:',out/'inspection.zip','\nRESULT_SHA256:',(out/'inspection.sha256').read_text().strip())
def submit(root,out,request,hours,previous=None):
    name='nrps_maps2732_'+sha(out/'REQUEST.json')[:10];old=previous.get('job_id','') if previous else ''
    check_queue(old,name)
    cmd=['sbatch','--parsable','--job-name='+name,'--account=nef@a100','--partition=gpu_p5','--qos=qos_gpu_a100-t3','--nodes=1','--ntasks=1','--cpus-per-task=8','--hint=nomultithread','--gres=gpu:1','--constraint=a100',f'--time={hours:02d}:00:00','--signal=USR1@300','--no-requeue','--propagate=NONE',f'--chdir={root}',f'--output={out}/slurm_%j.log',f'--error={out}/slurm_%j.log',str(PACKAGE/'batch.sh'),str(PACKAGE),str(root),str(out)]
    receipt=dict(output=str(out),status='SUBMITTING',hours=hours,command=cmd,previous_jobs=(previous.get('previous_jobs',[])+[old]) if previous else [])
    def persist():dump(out/'SUBMISSION.json',receipt);dump(root/RECEIPT,receipt)
    persist()
    try:r=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
    except (OSError,subprocess.TimeoutExpired) as exc:
        receipt.update(status='SUBMISSION_UNCERTAIN',error=str(exc));persist();raise RuntimeError('Submission uncertain; inspect squeue before any retry') from exc
    jid=r.stdout.strip().split(';')[0]
    if r.returncode!=0 or not jid.isdigit():
        receipt.update(status='REJECTED_OR_UNCERTAIN',stdout=r.stdout,stderr=r.stderr);persist();raise RuntimeError('Scheduler did not confirm submission: '+r.stderr)
    receipt.update(status='SUBMITTED',job_id=jid);persist()
    print('SUBMITTED_JOB:',jid,'\nOutput:',out)
    print(f'Resources: 1 A100, 8 CPUs, maximum {hours} hours; 46,550 designs at each checkpoint; no training')
    print('Log:',out/f'slurm_{jid}.log');print('Status: python3 -B',PACKAGE/'submit.py','status')
    print('Resume: python3 -B',PACKAGE/'submit.py','resume',out)
def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['preflight','run','status','resume','worker']);p.add_argument('output',nargs='?',type=Path);p.add_argument('--root',type=Path,default=PACKAGE.parent);p.add_argument('--hours',type=int,choices=[2,4],default=4);a=p.parse_intermixed_args(argv)
    root=a.root.resolve();require(root.is_dir(),'Missing project root')
    if a.action=='status':status((checked_output(root,a.output)/'SUBMISSION.json') if a.output else root/RECEIPT);return
    if a.action=='worker':
        require(os.environ.get('SLURM_JOB_ID','').isdigit(),'Worker requires a compute allocation');require(a.output is not None,'Worker needs output')
        out=checked_output(root,a.output)
        with (out/'run.lock').open('a') as lock:
            fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);request=read_request(root,out)
            require(not complete(out),'Already complete')
            import run
            run.execute(root,out,request)
        return
    digest=package_digest()
    if a.action=='preflight':
        inputs=check_inputs(root);print(json.dumps(dict(status='PREFLIGHT_OK',checkpoints=[27000,32000],designs_per_checkpoint=46550,pinned_input_files=len(inputs),package_sha256=digest,encoder_training=False,classifier_training=False,embedding_extraction=False,login_node_model_work=False,hash_validation='large inputs and checkpoint state checked on compute'),indent=2));return
    with (root/LOCK).open('a') as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        if a.action=='run':
            require(a.output is None,'New output is assigned automatically')
            if (root/RECEIPT).exists():
                r=load(root/RECEIPT);require(r['status']=='SUBMITTED','Existing submission uncertain; inspect receipt/squeue');print('Existing submission retained; use status or resume.');status(root/RECEIPT);return
            inputs=check_inputs(root);out=root/(PREFIX+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'_'+digest[:8]);out.mkdir()
            request=dict(root=str(root),output=str(out),package=str(PACKAGE),package_sha256=digest,protocol_sha256=sha(PACKAGE/'protocol.json'),inputs=inputs,hours=a.hours)
            dump(out/'REQUEST.json',request);(out/'REQUEST.sha256').write_text(sha(out/'REQUEST.json')+'\n');submit(root,out,request,a.hours)
        else:
            out=checked_output(root,a.output or load(root/RECEIPT)['output']);old=load(out/'SUBMISSION.json')
            require(old['status']=='SUBMITTED' and old['job_id'].isdigit(),'Previous submission unconfirmed')
            if complete(out):status(out/'SUBMISSION.json');return
            request=read_request(root,out)
            with (out/'run.lock').open('a') as lock2:fcntl.flock(lock2.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            submit(root,out,request,a.hours,old)
if __name__=='__main__':
    try:main()
    except (RuntimeError,OSError,ValueError,KeyError,subprocess.SubprocessError) as e:sys.exit('ERROR: '+str(e))
