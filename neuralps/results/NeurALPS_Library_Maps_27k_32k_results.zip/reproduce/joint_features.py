"""Frozen 27k/32k feature extraction with their trained full-attention policy.

This module deliberately reuses the unchanged 26k feature and map definitions.
The extraction performs no learning, but the joint encoder weights previously
received activity supervision. Their inner-fold predictions are not independent
validation of a new readout; downstream settings must therefore be fixed.
"""
from __future__ import annotations

from collections import Counter
import gzip
import json
from pathlib import Path
import platform
import time

import numpy as np

import frozen_features as base

PACKAGE = Path(__file__).resolve().parent
SCHEMA = 'neuralps_frozen_joint_comparison_features_v1'
ATTENTION = 'full_distance_with_radius6_clipped_bias'
ATTENTION_SOURCE_SHA = '2fadc2af85762a6e5ef0d21243863c125b5a919daae7753fd34372d51e264f61'
CHECKPOINTS = {
    '27000': dict(step=27000,
        path='neuralps_xut_continue_20261107T172538Z_976745e6/latest.pt',
        sha256='bb78635c63d7a29ba77fc0ff09203ecc92a7938fd216e269716243e5d104a66c',
        parent_step=26000, parent_sha256=base.CHECKPOINT_SHA, steps=1000,
        version='neuralps_joint_xut_continuation_20261107_v2'),
    '32000': dict(step=32000,
        path='neuralps_xut_5k_20261107T181244Z_82debe20/latest.pt',
        sha256='ba62c4c3c1d8f6606c14c57fb0770d8ecfd7c9ea8eefc35424d2aa1197923e7a',
        parent_step=27000,
        parent_sha256='bb78635c63d7a29ba77fc0ff09203ecc92a7938fd216e269716243e5d104a66c',
        steps=5000, version='neuralps_joint_xut_extension_27000_32000_20261107_v1'),
}

require, sha, dump, emit = base.require, base.sha, base.dump, base.emit


def checkpoint_spec(key):
    key = {'27k':'27000', '32k':'32000'}.get(str(key), str(key))
    require(key in CHECKPOINTS, 'Only the pinned 27k and 32k checkpoints are supported')
    return CHECKPOINTS[key]


def validate_checkpoint_metadata(state, config, completion, checkpoint_key):
    spec = checkpoint_spec(checkpoint_key)
    require(state.get('step') == spec['step'] and state.get('config') == config,
            'Embedded joint step or configuration differs from its receipt')
    require(isinstance(state.get('encoder_state'), dict) and state['encoder_state'],
            'Joint checkpoint has no encoder state')
    require(config.get('version') == spec['version'] and config.get('final_step') == spec['step']
            and config.get('parent_step') == spec['parent_step']
            and config.get('parent_sha256') == spec['parent_sha256']
            and config.get('steps') == spec['steps'], 'Joint checkpoint lineage differs')
    require(config.get('attention') == ATTENTION, 'Joint checkpoint requires its original full-attention policy')
    require(config.get('settings', {}).get('encoder') == base.EXPECTED_CONFIG,
            'Joint encoder architecture differs from the original checkpoint-compatible structure')
    require(config.get('natural_target_manifest_sha256') == base.TARGET_MANIFEST_SHA,
            'Joint natural target means have a different lineage')
    require(isinstance(config.get('labelled'), dict), 'Joint activity-supervision provenance missing')
    require(completion.get('status') == 'JOINT_CONTINUATION_COMPLETE'
            and completion.get('step') == spec['step']
            and completion.get('candidate_checkpoint') == 'latest.pt'
            and completion.get('candidate_sha256') == spec['sha256']
            and completion.get('parent_sha256') == spec['parent_sha256'],
            'Joint completion receipt differs from the pinned checkpoint')


def source_signatures(root, checkpoint_key, verified_hashes=None):
    """Verify original data/mean identities and the selected joint checkpoint."""
    verified = base.source_signatures(root, verified_hashes)
    spec = checkpoint_spec(checkpoint_key)
    folder = Path(spec['path']).parent
    for relative in (spec['path'], str(folder/'config.json'), str(folder/'COMPLETE.json')):
        path = root / relative
        require(path.is_file() and path.resolve().is_relative_to(root),
                'Missing or external joint source: ' + relative)
        before = path.stat()
        actual = (verified_hashes or {}).get(relative) or sha(path)
        after = path.stat()
        require((before.st_size,before.st_mtime_ns,before.st_ino) ==
                (after.st_size,after.st_mtime_ns,after.st_ino), 'Joint source changed during verification')
        if relative == spec['path']:
            require(actual == spec['sha256'], 'Pinned joint checkpoint checksum differs')
        verified[relative] = dict(sha256=actual,bytes=after.st_size,
                                  mtime_ns=after.st_mtime_ns,inode=after.st_ino)
    return verified


def extraction_dependencies():
    dependencies = base.extraction_dependencies()
    dependencies.update({name:sha(PACKAGE/name) for name in ('joint_features.py','ssl_changes.py')})
    require(dependencies['ssl_changes.py'] == ATTENTION_SOURCE_SHA,
            'Full-attention implementation differs from the trained implementation')
    return dependencies


def load_encoder(root, checkpoint_key, device):
    """Use unchanged natural means and joint encoder weights; ignore activity head."""
    import torch
    from ssl_changes import enable_full_attention
    spec = checkpoint_spec(checkpoint_key)
    # This validates original26 target means against the pinned natural manifest.
    model, means, mean_map = base.load_encoder(root, device)
    path = root/spec['path']
    require(sha(path) == spec['sha256'], 'Wrong joint checkpoint before deserialization')
    require(sha(PACKAGE/'ssl_changes.py') == ATTENTION_SOURCE_SHA,
            'Full-attention source differs')
    state = torch.load(path,map_location='cpu',weights_only=True)
    config = json.loads((path.parent/'config.json').read_text())
    completion = json.loads((path.parent/'COMPLETE.json').read_text())
    validate_checkpoint_metadata(state,config,completion,checkpoint_key)
    require(all(bool(torch.isfinite(v).all()) for v in state['encoder_state'].values()),
            'Nonfinite joint encoder weights')
    model.load_state_dict(state['encoder_state'],strict=True)
    enable_full_attention(model)
    model.to(device).eval().requires_grad_(False)
    require(all(block.radius == 6 and block.relative.num_embeddings == 13 for block in model.local)
            and len(model.global_blocks) == 2,
            'Joint full-attention architecture changed')
    labelled_manifest = config['labelled']
    del state
    return model,means,mean_map,labelled_manifest


def extract(root,out,checkpoint_key,device='cuda',threads=8,verified_hashes=None):
    """Write the same aligned feature columns as26k, without updating joint weights."""
    import torch
    from supervised import SupervisedData
    from labelled_multis import load_inputs
    root,out = Path(root).resolve(),Path(out).resolve()
    out.mkdir(parents=True,exist_ok=True)
    spec = checkpoint_spec(checkpoint_key)
    require(device in ('cuda','cpu') and threads > 0,'Invalid extraction runtime')
    if device == 'cuda':
        require(torch.cuda.is_available(),'CUDA unavailable; use a GPU allocation')
    torch.set_num_threads(threads)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.set_float32_matmul_precision('highest')
    started = time.monotonic()
    verified = source_signatures(root,checkpoint_key,verified_hashes)
    dependencies = extraction_dependencies()
    cached_path = out/'features.json'
    if cached_path.exists():
        cached=json.loads(cached_path.read_text())
        require(cached['schema'] == SCHEMA and cached['source_code_sha256'] == sha(__file__)
                and cached['checkpoint_sha256'] == spec['sha256']
                and cached['checkpoint_step'] == spec['step']
                and cached['attention'] == ATTENTION
                and cached['activity_labels_used_by_encoder'] is True,
                'Existing joint cache has a different extraction contract')
        require(cached.get('extraction_dependencies') == dependencies,
                'Joint cache dependencies changed')
        require(cached['source_hashes'] == {k:v['sha256'] for k,v in verified.items()},
                'Joint cache source identities differ')
        for name,expected in cached['payload_sha256'].items():
            require(sha(out/name) == expected,'Joint cache payload changed: '+name)
        emit('JOINT_FROZEN_FEATURE_CACHE_REUSED',step=spec['step'],rows=cached['rows'])
        return cached
    model,means,mean_map,trained_labels = load_encoder(root,checkpoint_key,device)
    before=base.state_digest(model)
    emit('LOADING_LABELLED_CACHED_INPUTS',encoder_step=spec['step'],encoder_training=False,
         activity_labels_used_by_encoder=True)
    labelled=SupervisedData(root,torch.device(device),threads=threads,
                           verified_hashes={k:v['sha256'] for k,v in verified.items()})
    require(json.loads(json.dumps(labelled.manifest)) == trained_labels,
            'Joint encoder supervision split/inputs differ from this comparison')
    metadata=base.row_metadata(labelled)
    _,multi_parents=load_inputs(PACKAGE/'labelled_assets/known_multis_model_inputs.json.gz')
    parents=dict(labelled.runtime.parents)
    for h,sequence in multi_parents.items():
        require(h not in parents or parents[h] == sequence,'Parent sequence namespace conflict')
        parents[h]=sequence
    arrays={k:[] for k in ('context','chemistry','compatibility','structure')}
    names=None
    maps_tmp=out/'maps.jsonl.gz.tmp'
    statuses=Counter()
    with maps_tmp.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=6,mtime=0) as stream:
            for i,meta in enumerate(metadata['rows']):
                clean,static,_=labelled._batch([i])
                with torch.inference_mode():
                    hidden=model.features(clean)[0].cpu().numpy()
                require(np.isfinite(hidden).all(),'Nonfinite joint context features')
                features,current_names=base.clean_features(hidden,clean,static,meta['donor_codes'])
                record=labelled.records[i]
                objects=base.score_objects(model,clean,record,parents,means,mean_map)
                blocks=static['blocks'][0].detach().cpu().numpy()
                seams=static['seams'][0].detach().cpu().numpy()
                groups=base.regions_for_record(record,blocks,seams,meta['donor_codes'])
                features['compatibility'],current_names['compatibility']=base.map_summary(objects,groups)
                if names is None:
                    names=current_names
                require(names == current_names,'Feature columns changed between rows')
                for key,value in features.items():
                    require(not np.isinf(value).any(),'Infinite joint feature')
                    if key != 'compatibility':
                        require(np.isfinite(value).all(),'Nonfinite joint clean feature')
                    arrays[key].append(value)
                statuses.update(o['status'] for o in objects)
                stream.write((json.dumps(dict(index=i,assembly_id=meta['assembly_id'],objects=objects,
                    regions=groups,checkpoint_sha256=spec['sha256']),sort_keys=True,allow_nan=False)+'\n').encode())
                if i%10 == 0 or i+1 == len(metadata['rows']):
                    emit('EXTRACTING_JOINT_FROZEN_FEATURES',step=spec['step'],completed=i+1,
                         total=len(metadata['rows']),elapsed_seconds=round(time.monotonic()-started,2),
                         object_statuses=dict(statuses))
    after=base.state_digest(model)
    require(before == after and not any(p.requires_grad for p in model.parameters()) and not model.training,
            'Frozen joint encoder state changed')
    require(not any(p.grad is not None for p in model.parameters()),'Unexpected joint encoder gradient')
    base.verify_unchanged(root,verified)
    matrices={k:np.stack(v).astype(np.float32) for k,v in arrays.items()}
    for key,matrix in matrices.items():
        require(matrix.shape == (552,len(names[key])),'Joint feature matrix shape differs')
    feature_tmp=out/'features.npz.tmp'
    with feature_tmp.open('wb') as stream:
        np.savez_compressed(stream,**matrices)
    feature_tmp.replace(out/'features.npz')
    dump(out/'rows.json',metadata)
    maps_tmp.replace(out/'maps.jsonl.gz')
    manifest=dict(schema=SCHEMA,status='FROZEN_FEATURES_COMPLETE',rows=552,
        source_code_sha256=sha(__file__),extraction_dependencies=dependencies,
        checkpoint=spec['path'],checkpoint_sha256=spec['sha256'],checkpoint_step=spec['step'],
        activity_labels_used_by_encoder=True,encoder_config=base.EXPECTED_CONFIG,attention=ATTENTION,
        encoder_state_sha256_before=before,encoder_state_sha256_after=after,
        encoder_training=False,encoder_gradients=False,encoder_optimizer=False,
        extraction_uses_activity_labels=False,
        arrays={k:dict(shape=list(v.shape),columns=names[k],missing_values=int(np.isnan(v).sum()))
                for k,v in matrices.items()},
        source_hashes={k:v['sha256'] for k,v in verified.items()},
        payload_sha256={n:sha(out/n) for n in ('features.npz','rows.json','maps.jsonl.gz')},
        object_statuses=dict(statuses),elapsed_seconds=round(time.monotonic()-started,2),
        runtime=dict(python=platform.python_version(),numpy=np.__version__,torch=torch.__version__,
                     cuda=torch.version.cuda,device=device,threads=threads,tf32=False),
        contracts=dict(
            context='Same feature pooling and column definitions as26k; no activity projection/readout is used.',
            attention='Trained full-distance attention, with original radius-six clipped relative bias and original global blocks.',
            masking='Same exact alias/overlap single-object masking closure, eligibility, and separate C/N roles as26k.',
            maps='Same 0.25 raw +0.75 type-centered cosine and raw fallback as26k; all query definitions unchanged.',
            means='Exact original26 natural-training target means retained by both continuation runs.',
            missing='Same strict complete-coverage summaries as26k; no partial-region averaging.',
            supervision='Encoder was jointly trained on outer-training activity labels. No activity labels are consumed by this extraction.',
            validation='No inner-CV retuning with these supervised encoders. Classifier settings are inherited from26k; fixed outer holdout remains retrospective.',
            normalization='Raw map agreements; no new percentile normalization or probability calibration.'))
    dump(cached_path,manifest)
    emit('JOINT_FROZEN_FEATURES_COMPLETE',step=spec['step'],rows=552,
         shapes={k:list(v.shape) for k,v in matrices.items()},encoder_weights_unchanged=True)
    return manifest
