#!/usr/bin/env python3
"""Numerical and missingness checks; no project assets or third-party packages."""
import importlib.util
import math
import random
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location('maptest', Path(__file__).with_name('run_test.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def piece(index, kind, raw, reference):
    return dict(assembly_id='example', dataset='example', object_index=index, kind=kind,
                raw=raw, reference=reference, reference_audit_status='TEST')


class NumericalTests(unittest.TestCase):
    def test_auc_against_pair_definition(self):
        rng = random.Random(7)
        for _ in range(100):
            cases = [(rng.randrange(2), rng.randrange(5)) for _ in range(20)]
            weights = [rng.randrange(4) for _ in cases]
            positives = [(s, w) for (y, s), w in zip(cases, weights) if y == 1]
            negatives = [(s, w) for (y, s), w in zip(cases, weights) if y == 0]
            den = sum(w for s, w in positives) * sum(w for s, w in negatives)
            expected = sum(w * v * (1 if a > b else .5 if a == b else 0)
                           for a, w in positives for b, v in negatives) / den if den else None
            actual = m.auc(cases, weights)
            if expected is None:
                self.assertIsNone(actual)
            else:
                self.assertAlmostEqual(actual, expected, places=14)

    def test_tie_metrics(self):
        result = m.metrics([(1, .5), (0, .5), (1, .5), (0, .5)])
        self.assertEqual(result['auroc'], .5)
        self.assertEqual(result['average_precision'], .5)
        self.assertEqual(result['top20_precision'], .5)
        result = m.metrics([(1, 3), (0, 2), (1, 1)])
        self.assertAlmostEqual(result['average_precision'], 5 / 6)
        self.assertEqual(result['top20_precision'], 1)

    def test_single_class(self):
        self.assertIsNone(m.auc([(1, .1), (1, .9)]))
        self.assertIsNone(m.metrics([])['auroc'])

    def test_balancing_and_lower_tail(self):
        data = [piece(0, 0, .9, .7), piece(1, 1, .8, .1), piece(2, 0, .3, .2)]
        self.assertAlmostEqual(m.aggregate(data, 'raw', 'mean'), 2 / 3)
        self.assertAlmostEqual(m.aggregate(data, 'raw', 'balanced_mean'), .7)
        self.assertAlmostEqual(m.aggregate(data, 'raw', 'balanced_lower_quartile_mean'), .55)
        self.assertEqual(m.aggregate(data, 'raw', 'minimum'), .3)

    def test_missing_reference_is_not_imputed(self):
        data = [piece(0, 0, .9, .7), piece(1, 1, .8, .1), piece(2, 0, .3, None)]
        result = m.score_map(data)
        self.assertIsNone(result['scores']['whole_reference:mean'])
        self.assertAlmostEqual(result['scores']['supported_raw:mean'], .85)
        self.assertAlmostEqual(result['scores']['supported_reference:mean'], .4)
        self.assertEqual(result['reference_objects'], 2)
        self.assertAlmostEqual(result['reference_coverage'], 2 / 3)

    def test_missing_group_refuses_partial_score(self):
        data = [piece(0, 0, .9, .7), piece(1, 1, .8, None), piece(2, 0, .3, .2)]
        self.assertIsNone(m.score_map(data)['scores']['supported_raw:mean'])

    def test_missing_raw_refuses_whole_score(self):
        data = [piece(0, 0, .9, .7), piece(1, 1, None, None), piece(2, 0, .3, .2)]
        self.assertIsNone(m.score_map(data)['scores']['whole_raw:mean'])

    def test_activity_fields_cannot_change_scores(self):
        data = [piece(0, 0, .9, .7), piece(1, 2, .8, .1), piece(2, 0, .3, .2)]
        before = m.score_map(data)
        for x in data:
            x['observed_activity'] = 1
            x['label'] = 'ACTIVE'
        after = m.score_map(data)
        self.assertEqual(before, after)
        for x in data:
            x['observed_activity'] = 0
            x['label'] = 'INACTIVE'
        self.assertEqual(before, m.score_map(data))

    def test_monotonicity(self):
        data = [piece(0, 0, .9, .7), piece(1, 1, .8, .1), piece(2, 0, .3, .2)]
        before = m.score_map(data)['scores']
        data[2]['raw'] = .5
        after = m.score_map(data)['scores']
        for method in m.AGGREGATIONS:
            self.assertGreaterEqual(after['whole_raw:' + method], before['whole_raw:' + method])

    def test_rank_correlation(self):
        self.assertAlmostEqual(m.spearman([1, 2, 3], [9, 8, 7]), -1.)
        self.assertAlmostEqual(m.spearman([1, 2, 2], [1, 2, 2]), 1.)
        self.assertIsNone(m.spearman([1, 1, 1], [1, 2, 3]))


if __name__ == '__main__':
    unittest.main()
