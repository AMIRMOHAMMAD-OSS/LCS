NeurALPS frozen compatibility-map test | 3 November 2026

This first experiment evaluates the existing unsupervised map at whole-line
resolution. It reads previously computed, sealed E8/E11 maps from Jean Zay and
E12 regional scores. It performs no new GPU inference, no training, no activity
calibration, no sequence edits, and no change to a previous experiment.

The scorer uses no engineered activity labels. Labels enter only after all
assembly scores have been written and hashed, for retrospective evaluation.

COMPARISONS

1. Four fixed aggregations of the original full-context map:
   - mean of all physical pieces;
   - equal mean of domain mean and connection mean;
   - mean of the lowest ceil(25% of n) scores within each group, then equal
     group mean;
   - minimum over the whole map.
   Covalent boundaries and protein breaks form the connection group. A break
   with two terminal roles is counted once, as in the source map.

2. The same aggregations after applying the existing E8 natural-reference
   percentiles. Those percentiles are already present in the source files.
   Complete-route scores require every object. Partial reference coverage is
   never silently filled. A separate SUPPORTED diagnostic compares raw and
   reference scores on exactly the same supported physical pieces; that is
   explicitly a partial map and cannot be called whole-line compatibility.

3. Existing E12 single/full, single/local, joint/full, joint/local and type-mean
   regional scores as comparators. The E8 reference is never applied to local
   or joint masks. Region scores and complete-line scores remain distinguished.

4. Association between the assembly score and number of physical objects on
   the existing natural audit subset, one hash-selected assembly per connected
   component. This is descriptive and does not remove composition confounding.

EVALUATION

All 494 primary experimental labels: BODE1 324 (173 positive), BODE2 105 (63),
T-domain 65 (50). Native/hybrid maps remain available but are not assigned
invented binary labels. AUROC, average precision, top-20% precision and coverage
are reported. BODE1 includes pooled, donor-panel and matched-background-panel
metrics. BODE2 includes swap-position metrics. Paired bootstrap intervals use
the existing BODE2 donor-triplet and T-domain minimum ancestry groups.

The groups do not prove homology independence. BODE1 panels overlap and receive
no IID confidence interval. The three datasets are retrospective development
data, not a fresh external test. No maximum-AUROC winner is automatically chosen.
Scores and their percentiles are not activity probabilities. No log loss,
Brier score, 0.5 activity threshold or causal fault-localization claim is made.

RUN

Download NeurALPS_MapScore_Test_20261103.zip into /Users/amir/Downloads on the Mac.
In a LOCAL MAC terminal, transfer it:

  scp -J apandi@gate.lcqb.hosted.lip6.fr \
    /Users/amir/Downloads/NeurALPS_MapScore_Test_20261103.zip \
    unh87ms@jean-zay.idris.fr:/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/

If downloaded on Windows, first transfer from WINDOWS POWERSHELL:

  scp "$env:USERPROFILE\Downloads\NeurALPS_MapScore_Test_20261103.zip" amir@100.72.70.1:/Users/amir/Downloads/

Then on JEAN ZAY:

  cd /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2
  unzip -n NeurALPS_MapScore_Test_20261103.zip
  python3 -B NeurALPS_MapScore_Test_20261103/selftest.py
  python3 -B NeurALPS_MapScore_Test_20261103/submit.py preflight
  python3 -B NeurALPS_MapScore_Test_20261103/submit.py run

The launcher requests 1 CPU on nef@cpu/cpu_p1/qos_cpu-t3 for at most 20 minutes,
following your existing CPU-job setup. It requests no GPU or explicit memory.
Python 3.8+ standard library is sufficient; no module installation is needed.
If the scheduler configuration has changed, return the rejection text. Do not
switch partitions or accounts by guessing. The launcher refuses duplicate
submission after a recorded attempt, including uncertain/rejected attempts.

The login-node preflight reads only six small sealed files (~13 MiB total),
checks their hashes and the package manifest, and does not load any model,
feature cache, training database, or large checkpoint.

Status:

  python3 -B NeurALPS_MapScore_Test_20261103/submit.py status

Result directory: neuralps_mapscore_JOBID
Key outputs: REPORT.txt, metrics.csv, paired_contrasts.json, coverage.csv,
natural_length_audit.json, experimental_map_values.jsonl.gz,
predictions_without_activity_labels.jsonl.gz, and inspection.zip.

RETURN RESULTS THROUGH LCS

After completion, the status command prints RESULT_ZIP with an exact path.
Copy that exact path from Jean Zay to the Mac with the same scp -J route, then
commit only that ZIP to your existing LCS checkout under neuralps/results/.
Do not add all project files or create a new LCS clone. Return the printed
RESULT_ZIP line first if you want an exact transfer/upload command.

VERIFICATION AND LIMITS

See LOCAL_VALIDATION.json for checks actually performed before packaging.
The complete 494-label run must execute on Jean Zay because the exported
Windows/live packets did not include the full E11 T-domain object-score file.
The local checks do not constitute a completed production result for that arm.
Input hash mismatches fail closed and do not silently use different versions.
New results are written to a new job-specific directory; previous outputs are
not overwritten. Run scripts are included in the returned inspection archive.

PROTOCOL.json fixes all choices and limitations. evaluation_labels.json is used
only by the evaluator. expected_inputs.json pins source file identities.

This test assesses aggregation/reference scaling of the CURRENT map. It does
not test a newly trained contrastive scorer, new architecture, new masking
geometry, or new feature extraction. Those would be separate experiments.
