#!/usr/bin/env python3
"""Submit once, preflight, or inspect the CPU-only frozen-map benchmark."""
import argparse
import fcntl
import importlib.util
import json
import os
import shlex
import subprocess
import sys
import time
from collections import deque
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('nrps_mapscore_runner', PACKAGE / 'run_test.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


def command(root, request, python):
    return ['sbatch', '--parsable', '--job-name=nrps_mapscore', '--account=nef@cpu',
            '--partition=cpu_p1', '--qos=qos_cpu-t3', '--nodes=1', '--ntasks=1',
            '--cpus-per-task=1', '--hint=nomultithread', '--time=00:20:00',
            '--no-requeue', '--propagate=NONE', '--chdir=' + str(root),
            '--output=' + str(root / 'neuralps_mapscore_%j.log'),
            '--error=' + str(root / 'neuralps_mapscore_%j.log'),
            str(PACKAGE / 'batch.sh'), python, str(PACKAGE), str(root), str(request)]


def show_status(info, root):
    if info.get('job_id'):
        job = info['job_id']
        for cmd in [['squeue', '-j', job, '-o', '%.18i %.12P %.20j %.10T %.10M %.30R'],
                    ['sacct', '-j', job, '--format=JobID,State,ExitCode,Elapsed']]:
            try:
                p = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
                print(p.stdout.strip() or p.stderr.strip(), flush=True)
            except (OSError, subprocess.TimeoutExpired) as e:
                print('Scheduler status unavailable:', e, flush=True)
        out = root / ('neuralps_mapscore_' + job)
        print('Output:', out, flush=True)
        if (out / 'summary.json').exists():
            print((out / 'summary.json').read_text(), flush=True)
        if (out / 'fatal_error.json').exists():
            print((out / 'fatal_error.json').read_text(), flush=True)
        if (out / 'inspection.zip').exists():
            print('RESULT_ZIP:', out / 'inspection.zip', flush=True)
        log = root / ('neuralps_mapscore_' + job + '.log')
        if log.exists():
            with log.open(errors='replace') as f:
                print(''.join(deque(f, maxlen=18)), flush=True)
    else:
        print(json.dumps(info, indent=2), flush=True)
        print('A submission attempt is already recorded. No duplicate job was submitted.', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('preflight', 'run', 'status'))
    parser.add_argument('--root', type=Path, default=PACKAGE.parent)
    args = parser.parse_args()
    root = args.root.resolve()
    receipt = PACKAGE / 'SUBMISSION.json'
    if args.action == 'status':
        runner.require(receipt.is_file(), 'No submission recorded yet')
        show_status(runner.load(receipt), root)
        return
    check = runner.preflight(root)
    print('PREFLIGHT_OK:', len(check['files']), 'sealed inputs; CPU only, no training', flush=True)
    cmd = command(root, PACKAGE / 'REQUEST.json', sys.executable)
    if args.action == 'preflight':
        print('Planned command:', shlex.join(cmd) if hasattr(shlex, 'join') else ' '.join(map(shlex.quote, cmd)), flush=True)
        return
    with (PACKAGE / 'submission.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        if receipt.exists():
            show_status(runner.load(receipt), root)
            return
        runner.require(not (PACKAGE / 'REQUEST.json').exists(), 'An earlier request exists without a receipt; inspect before submitting')
        request = dict(root=str(root), package=str(PACKAGE), source_check=check,
                       package_manifest_sha256=runner.sha(PACKAGE / 'PACKAGE_MANIFEST.json'))
        runner.dump(PACKAGE / 'REQUEST.json', request)
        digest = runner.sha(PACKAGE / 'REQUEST.json')
        (PACKAGE / 'REQUEST.sha256').write_text(digest + '\n')
        info = dict(status='SUBMITTING', created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                    command=cmd, request_sha256=digest, root=str(root))
        runner.dump(receipt, info)
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        except (OSError, subprocess.TimeoutExpired) as exc:
            info.update(status='SUBMISSION_UNCERTAIN', error=str(exc))
            runner.dump(receipt, info)
            raise RuntimeError('Submission result uncertain; inspect SUBMISSION.json and squeue before any retry') from exc
        info.update(stdout=result.stdout.strip(), stderr=result.stderr.strip(), returncode=result.returncode)
        job = result.stdout.strip().split(';')[0]
        if result.returncode != 0 or not job.isdigit():
            info['status'] = 'REJECTED_OR_UNCERTAIN'
            runner.dump(receipt, info)
            raise RuntimeError('Slurm did not confirm a job. Return this output:\n' + result.stdout + result.stderr)
        info.update(status='SUBMITTED', job_id=job)
        runner.dump(receipt, info)
        print('SUBMITTED_JOB:', job, flush=True)
        print('Resources: 1 CPU, 20-minute maximum, no GPU, no extra Python dependencies', flush=True)
        print('Log:', root / ('neuralps_mapscore_' + job + '.log'), flush=True)
        print('Status: python3', PACKAGE / 'submit.py', 'status', flush=True)


if __name__ == '__main__':
    main()
