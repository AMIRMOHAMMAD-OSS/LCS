#!/usr/bin/env bash
set -euo pipefail
MAPTEST_PYTHON="$1"
MAPTEST_PACKAGE="$2"
MAPTEST_ROOT="$3"
MAPTEST_REQUEST="$4"
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
"$MAPTEST_PYTHON" -I -B - "$MAPTEST_REQUEST" "$MAPTEST_PACKAGE" <<'PY'
import hashlib, json, sys
from pathlib import Path
request, package = map(Path, sys.argv[1:])
actual = hashlib.sha256(request.read_bytes()).hexdigest()
if actual != (package / 'REQUEST.sha256').read_text().strip():
    raise SystemExit('Request hash changed; refusing job')
payload = json.loads(request.read_text())
manifest = hashlib.sha256((package / 'PACKAGE_MANIFEST.json').read_bytes()).hexdigest()
if payload['package_manifest_sha256'] != manifest:
    raise SystemExit('Package manifest changed after submission')
print('REQUEST_HASH_OK:', actual, flush=True)
PY
srun --ntasks=1 "$MAPTEST_PYTHON" -I -B "$MAPTEST_PACKAGE/run_test.py" \
    --root "$MAPTEST_ROOT" --out "$MAPTEST_ROOT/neuralps_mapscore_$SLURM_JOB_ID"
