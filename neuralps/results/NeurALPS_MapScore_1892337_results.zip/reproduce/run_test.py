#!/usr/bin/env python3
"""Frozen-map aggregation audit. Python standard library only; no model fitting."""
import argparse
import csv
import gzip
import hashlib
import json
import math
import os
import random
import shutil
import socket
import statistics
import sys
import time
import traceback
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent
CHECKPOINT = '9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f'
E8 = 'e8_reference_scale_652486'
E11 = 'e11_tdomain_transfer_699466'
E12 = 'e12_context_audit_749149'
AGGREGATIONS = ('mean', 'balanced_mean', 'balanced_lower_quartile_mean', 'minimum')
MAP_SETS = ('whole_raw', 'whole_reference', 'supported_raw', 'supported_reference')


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def load(path):
    with Path(path).open() as f:
        return json.load(f)


def dump(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
    temporary.replace(path)


def rows(path):
    with gzip.open(path, 'rt') as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


def write_rows(path, data):
    with gzip.GzipFile(filename=str(path), mode='wb', mtime=0) as f:
        for row in data:
            f.write((json.dumps(row, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode())


def write_csv(path, data):
    if not data:
        Path(path).write_text('')
        return
    fields = list(dict.fromkeys(k for row in data for k in row))
    with Path(path).open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for row in data:
            w.writerow({k: json.dumps(v, sort_keys=True) if isinstance(v, (list, dict)) else v for k, v in row.items()})


def verify_package():
    manifest = load(PACKAGE / 'PACKAGE_MANIFEST.json')
    for name, expected in manifest.items():
        p = PACKAGE / name
        require(p.is_file() and sha(p) == expected, 'Package file changed or missing: ' + name)
    return sha(PACKAGE / 'PACKAGE_MANIFEST.json')


def preflight(root):
    require(sys.version_info >= (3, 8), 'Python 3.8 or newer is required')
    package_sha = verify_package()
    expected = load(PACKAGE / 'expected_inputs.json')
    checks, errors = [], []
    for name, digest in expected.items():
        p = root / name
        if not p.is_file():
            errors.append('MISSING: ' + str(p))
            continue
        observed = sha(p)
        if observed != digest:
            errors.append('CHANGED: ' + str(p))
        checks.append(dict(path=name, bytes=p.stat().st_size, sha256=observed))
    require(not errors, '\n'.join(errors) + '\nNo experiment was run. Keep the original inputs; return this output for review.')
    protocol = load(PACKAGE / 'PROTOCOL.json')
    require(protocol['aggregations'] == list(AGGREGATIONS), 'Aggregation protocol changed')
    return dict(status='PREFLIGHT_OK', files=checks, package_manifest_sha256=package_sha,
                protocol_sha256=sha(PACKAGE / 'PROTOCOL.json'), python=sys.version,
                root=str(root), training_updates=0, classifier_fits=0, gpu_required=False)


def compact_object(row):
    require(row['source_checkpoint_sha256'] == CHECKPOINT and row['selected_step'] == 26000,
            'Wrong checkpoint in object score')
    require(row['kind'] in (0, 1, 2), 'Unrecognized physical object kind')
    expected_mode = 'joint_terminal_recovery' if row['kind'] == 2 else 'object_recovery'
    require(row['mode'] == expected_mode, 'Reference is valid only for inherited single-physical-object masks')
    raw = row.get('native_score') if row['status'] == 'SCORED' else None
    if raw is not None:
        require(math.isfinite(raw) and -1.00001 <= raw <= 1.00001, 'Invalid raw agreement')
    ref = row.get('natural_percentile_0_to_100')
    if ref is not None:
        require(raw is not None and math.isfinite(ref) and 0 <= ref <= 100, 'Invalid natural percentile')
        require(row['scale_status'] in ('SCALED', 'SCALED_LENGTH_UNMATCHED') and
                row['reference_components'] >= 100, 'Invalid reference support')
        ref = ref / 100.0
    else:
        require(row['scale_status'] not in ('SCALED', 'SCALED_LENGTH_UNMATCHED'), 'Scaled row lacks a percentile')
    return dict(assembly_id=row['assembly_id'], dataset=row['dataset'], object_index=row['object_index'],
                kind=row['kind'], label=row.get('label', ''), raw=raw, reference=ref,
                status=row['status'], scale_status=row['scale_status'],
                reference_components=row.get('reference_components', 0),
                reference_audit_status=row.get('reference_audit_status'),
                reference_level=row.get('reference_level'))


def load_maps(paths):
    maps = defaultdict(list)
    seen = set()
    for path in paths:
        for row in rows(path):
            piece = compact_object(row)
            key = (piece['dataset'], piece['assembly_id'])
            unique = key + (piece['object_index'],)
            require(unique not in seen, 'Duplicate physical object: ' + str(unique))
            seen.add(unique)
            maps[key].append(piece)
    for key, pieces in maps.items():
        pieces.sort(key=lambda x: x['object_index'])
        require([p['object_index'] for p in pieces] == list(range(len(pieces))), 'Incomplete physical map: ' + str(key))
        require(len(pieces) % 2 == 1 and all(p['kind'] == 0 if i % 2 == 0 else p['kind'] in (1, 2)
                                          for i, p in enumerate(pieces)), 'Route ordering changed: ' + str(key))
    return dict(maps)


def aggregate(pieces, field, name):
    values = [p[field] for p in pieces]
    require(values and all(v is not None and math.isfinite(v) for v in values), 'Incomplete aggregation input')
    if name == 'mean':
        return statistics.mean(values)
    if name == 'minimum':
        return min(values)
    groups = [[p[field] for p in pieces if (p['kind'] == 0) == domain] for domain in (True, False)]
    groups = [g for g in groups if g]
    if name == 'balanced_mean':
        return statistics.mean(statistics.mean(g) for g in groups)
    if name == 'balanced_lower_quartile_mean':
        return statistics.mean(statistics.mean(sorted(g)[:max(1, math.ceil(0.25 * len(g)))]) for g in groups)
    raise ValueError(name)


def score_map(pieces):
    physical_groups = {p['kind'] == 0 for p in pieces}
    supported = [p for p in pieces if p['reference'] is not None]
    covered_groups = {p['kind'] == 0 for p in supported}
    complete_raw = all(p['raw'] is not None for p in pieces)
    complete_reference = len(supported) == len(pieces)
    scores = {}
    for scope in MAP_SETS:
        chosen = supported if scope.startswith('supported_') else pieces
        field = 'raw' if scope.endswith('_raw') else 'reference'
        available = (complete_raw if scope == 'whole_raw' else
                     complete_reference if scope == 'whole_reference' else
                     bool(supported) and covered_groups == physical_groups)
        for name in AGGREGATIONS:
            scores[scope + ':' + name] = aggregate(chosen, field, name) if available else None
    return dict(assembly_id=pieces[0]['assembly_id'], dataset=pieces[0]['dataset'],
                objects=len(pieces), domains=sum(p['kind'] == 0 for p in pieces),
                raw_objects=sum(p['raw'] is not None for p in pieces),
                reference_objects=len(supported), reference_coverage=len(supported) / len(pieces),
                audit_status_counts=dict(Counter(p['reference_audit_status'] or 'UNAVAILABLE' for p in supported)),
                scores=scores)


def attach_region_controls(predictions, path):
    rr = defaultdict(list)
    methods = ('single_full', 'single_local', 'joint_full', 'joint_local', 'type_mean')
    for row in rows(path):
        if row['method'] in methods:
            rr[(row['dataset'], row['assembly_id'], row['method'])].append(row)
    for p in predictions:
        if p['dataset'] == 'natural':
            continue
        for method in methods:
            selected = rr[(p['dataset'], p['assembly_id'], method)]
            # Native/hybrid controls are not part of the activity benchmark.
            count = 3 if p['dataset'] == 'bode1' else 1
            field = 'domains' if p['dataset'] == 'tdomain' else 'balanced'
            values = [r[field] for r in selected]
            ok = len(values) == count and all(v is not None and math.isfinite(v) for v in values)
            p['scores']['region:' + method] = statistics.mean(values) if ok else None


def auc(cases, weights=None):
    if not cases:
        return None
    weights = weights if weights is not None else [1] * len(cases)
    require(len(weights) == len(cases), 'Weight length mismatch')
    groups = defaultdict(lambda: [0, 0])
    for (y, s), w in zip(cases, weights):
        groups[s][y] += w
    positives = sum(v[1] for v in groups.values())
    negatives = sum(v[0] for v in groups.values())
    if not positives or not negatives:
        return None
    numerator = below = 0.0
    for s in sorted(groups):
        n, p = groups[s]
        numerator += p * (below + 0.5 * n)
        below += n
    return numerator / (positives * negatives)


def metrics(cases):
    n = len(cases)
    positives = sum(y for y, _ in cases)
    result = dict(n=n, positives=positives, negatives=n - positives, auroc=auc(cases),
                  average_precision=None, top20_precision=None)
    if not n:
        return result
    groups = defaultdict(lambda: [0, 0])
    for y, s in cases:
        groups[s][0] += 1
        groups[s][1] += y
    tp = taken = top_positive = 0.0
    k = max(1, math.ceil(0.2 * n))
    ap = 0.0
    for s in sorted(groups, reverse=True):
        count, pos = groups[s]
        if taken < k:
            top_positive += pos * min(1.0, (k - taken) / count)
        taken += count
        tp += pos
        if positives:
            ap += (pos / positives) * (tp / taken)
    result.update(average_precision=ap if positives else None, top20_precision=top_positive / k)
    return result


def panel_metrics(dataset, selected):
    result = {}
    if dataset == 'bode1':
        donor, background = defaultdict(list), defaultdict(list)
        for label, score in selected:
            parts = label['group']
            require(isinstance(parts, list) and len(parts) == 3, 'Invalid BODE1 donors')
            for axis in range(3):
                donor[(axis, parts[axis])].append((label['observed_activity'], score))
                bg = tuple(p for i, p in enumerate(parts) if i != axis)
                background[(axis, bg)].append((label['observed_activity'], score))
        for name, panels, total in [('donor', donor, 21), ('background', background, 144)]:
            values = [auc(cases) for cases in panels.values()]
            valid = [v for v in values if v is not None]
            result[name + '_macro_auroc'] = statistics.mean(valid) if valid else None
            result[name + '_mixed_panels'] = len(valid)
            result[name + '_present_panels'] = len(panels)
            result[name + '_expected_panels'] = total
    if dataset == 'bode2':
        positions = defaultdict(list)
        for label, score in selected:
            positions[label['metadata']['position']].append((label['observed_activity'], score))
        result['position_metrics'] = {key: metrics(value) for key, value in sorted(positions.items())}
    return result


def quantile(values, q):
    values = sorted(values)
    if not values:
        return None
    index = (len(values) - 1) * q
    lower = int(index)
    upper = min(lower + 1, len(values) - 1)
    return values[lower] + (index - lower) * (values[upper] - values[lower])


def paired(labels, by_id, dataset, first, second, repeats, seed):
    selected = [(r, by_id[r['assembly_id']]['scores'].get(first), by_id[r['assembly_id']]['scores'].get(second))
                for r in labels if r['dataset'] == dataset]
    selected = [(r, a, b) for r, a, b in selected if a is not None and b is not None]
    a = [(r['observed_activity'], v) for r, v, _ in selected]
    b = [(r['observed_activity'], v) for r, _, v in selected]
    va, vb = auc(a), auc(b)
    out = dict(dataset=dataset, first=first, second=second, shared_constructs=len(selected),
               first_auroc=va, second_auroc=vb, delta_second_minus_first=vb - va if va is not None and vb is not None else None)
    if dataset == 'bode1':
        out['first_panels'] = panel_metrics(dataset, [(r, v) for r, v, _ in selected])
        out['second_panels'] = panel_metrics(dataset, [(r, v) for r, _, v in selected])
        out['interval'] = 'NOT_COMPUTED: crossed donor panels overlap'
        return out
    if va is None or vb is None:
        out['bootstrap_valid_replicates'] = 0
        return out
    group_names = sorted({r['group'] for r, _, _ in selected})
    rng = random.Random(seed)
    deltas = []
    for _ in range(repeats):
        counts = Counter(rng.choices(group_names, k=len(group_names)))
        weights = [counts[r['group']] for r, _, _ in selected]
        x, y = auc(a, weights), auc(b, weights)
        if x is not None and y is not None:
            deltas.append(y - x)
    out.update(bootstrap_groups=len(group_names), bootstrap_valid_replicates=len(deltas),
               bootstrap_invalid_replicates=repeats - len(deltas),
               delta_percentile95=[quantile(deltas, 0.025), quantile(deltas, 0.975)],
               interval_interpretation='Descriptive paired fixed-prediction cluster bootstrap; no multiple-comparison adjustment')
    return out


def evaluate(predictions, labels, protocol):
    require(len(labels) == len({r['assembly_id'] for r in labels}) == 494, 'Wrong label identity/count')
    for ds, n, positive in [('bode1', 324, 173), ('bode2', 105, 63), ('tdomain', 65, 50)]:
        chosen = [r for r in labels if r['dataset'] == ds]
        require(len(chosen) == n and all(r['observed_activity'] in (0, 1) for r in chosen) and
                sum(r['observed_activity'] for r in chosen) == positive, 'Wrong label cohort: ' + ds)
    by_id = {p['assembly_id']: p for p in predictions}
    require(all(r['assembly_id'] in by_id and by_id[r['assembly_id']]['dataset'] == r['dataset'] for r in labels),
            'An experimental label lacks its complete input map')
    methods = list(next(p for p in predictions if p['dataset'] == 'bode1')['scores'])
    output = []
    for ds in ('bode1', 'bode2', 'tdomain'):
        cohort = [r for r in labels if r['dataset'] == ds]
        for method in methods:
            selected = [(r, by_id[r['assembly_id']]['scores'].get(method)) for r in cohort]
            selected = [(r, s) for r, s in selected if s is not None]
            value = dict(dataset=ds, method=method, expected_constructs=len(cohort),
                         **metrics([(r['observed_activity'], s) for r, s in selected]))
            value.update(panel_metrics(ds, selected))
            output.append(value)
    comparisons = []
    for scope in MAP_SETS:
        comparisons.extend((scope + ':balanced_mean', scope + ':' + a) for a in AGGREGATIONS if a != 'balanced_mean')
    for scope in ('whole', 'supported'):
        comparisons.extend((scope + '_raw:' + a, scope + '_reference:' + a) for a in AGGREGATIONS)
    comparisons.extend(('whole_raw:balanced_mean', 'region:' + m)
                       for m in ('single_full', 'single_local', 'joint_full', 'joint_local', 'type_mean'))
    contrasts = []
    for ds in ('bode1', 'bode2', 'tdomain'):
        for first, second in comparisons:
            contrasts.append(paired(labels, by_id, ds, first, second,
                                    protocol['bootstrap']['replicates'], protocol['bootstrap']['seed']))
        print('EVALUATED:', ds, flush=True)
    return output, contrasts


def ranks(values):
    order = sorted(range(len(values)), key=lambda i: values[i])
    result = [0.] * len(values)
    start = 0
    while start < len(order):
        stop = start + 1
        while stop < len(order) and values[order[stop]] == values[order[start]]:
            stop += 1
        for j in range(start, stop):
            result[order[j]] = (start + stop - 1) / 2.0
        start = stop
    return result


def spearman(x, y):
    if len(x) < 2:
        return None
    a, b = ranks(x), ranks(y)
    am, bm = statistics.mean(a), statistics.mean(b)
    ab = sum((u - am) * (v - bm) for u, v in zip(a, b))
    den = math.sqrt(sum((u - am)**2 for u in a) * sum((v - bm)**2 for v in b))
    return ab / den if den else None


def natural_audit(predictions, metadata):
    representatives = {}
    for p in predictions:
        if p['dataset'] != 'natural':
            continue
        m = metadata[p['assembly_id']]
        require(m['role'] == 'audit', 'Unexpected natural role; calibration rows cannot enter audit')
        key = m['component_id']
        choice = hashlib.sha256(('20261103|maptest|' + key + '|' + p['assembly_id']).encode()).hexdigest()
        if key not in representatives or choice < representatives[key][0]:
            representatives[key] = (choice, p)
    selected = [p for _, p in representatives.values()]
    output = []
    if not selected:
        return output
    for method in selected[0]['scores']:
        valid = [p for p in selected if p['scores'][method] is not None]
        bins = defaultdict(list)
        for p in valid:
            n = p['objects']
            bins['1-15' if n <= 15 else '16-31' if n <= 31 else '32-63' if n <= 63 else '64+'].append(p['scores'][method])
        output.append(dict(method=method, total_components=len(selected), scored_components=len(valid),
                           score_vs_object_count_spearman=spearman([p['objects'] for p in valid], [p['scores'][method] for p in valid]),
                           length_bins={k: dict(n=len(v), mean=statistics.mean(v), median=statistics.median(v)) for k, v in bins.items()}))
    return output


def package_results(out):
    files = [p for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ('inspection.zip', 'artifact_manifest.json')]
    dump(out / 'artifact_manifest.json', {str(p.relative_to(out)): sha(p) for p in files})
    with zipfile.ZipFile(out / 'inspection.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        for p in files + [out / 'artifact_manifest.json']:
            z.write(p, str(p.relative_to(out)))


def execute(root, out):
    started = time.monotonic()
    checked = preflight(root)
    require(not out.exists(), 'Output already exists; refusing to overwrite: ' + str(out))
    out.mkdir(parents=False)
    try:
        protocol = load(PACKAGE / 'PROTOCOL.json')
        dump(out / 'input_verification.json', checked)
        shutil.copy2(PACKAGE / 'PROTOCOL.json', out / 'PROTOCOL.json')
        maps = load_maps([root / E8 / 'scaled_objects.jsonl.gz', root / E11 / 'scores/scaled_objects.jsonl.gz'])
        counts = Counter(ds for ds, _ in maps)
        require(all(counts[ds] == n for ds, n in [('bode1', 324), ('bode2', 106), ('tdomain', 88)]),
                'Expected complete maps for 324 BODE1, 106 BODE2 and 88 T-domain assemblies: ' + str(counts))
        predictions = [score_map(maps[key]) for key in sorted(maps)]
        attach_region_controls(predictions, root / E12 / 'region_scores.jsonl.gz')
        write_rows(out / 'predictions_without_activity_labels.jsonl.gz', predictions)
        write_rows(out / 'experimental_map_values.jsonl.gz', (piece for key in sorted(maps) if key[0] != 'natural' for piece in maps[key]))
        dump(out / 'prediction_seal.json', dict(predictions_sha256=sha(out / 'predictions_without_activity_labels.jsonl.gz'),
             protocol_sha256=checked['protocol_sha256'], input_files=checked['files'],
             activity_labels_loaded_for_prediction=False, training_updates=0, supervised_fits=0))
        print('PREDICTIONS_SEALED: no activity labels read by scoring stage', flush=True)
        # Experimental outcomes first enter here, after every score is written and sealed.
        labels = load(PACKAGE / 'evaluation_labels.json')
        result, contrasts = evaluate(predictions, labels, protocol)
        write_csv(out / 'metrics.csv', result)
        dump(out / 'metrics.json', result)
        dump(out / 'paired_contrasts.json', contrasts)
        audit = natural_audit(predictions, load(root / E8 / 'split_manifest.json')['metadata'])
        dump(out / 'natural_length_audit.json', audit)
        coverage = [{k: v for k, v in p.items() if k != 'scores'} for p in predictions]
        write_csv(out / 'coverage.csv', coverage)
        summary = dict(status='COMPLETE', study_role=protocol['study_role'],
                       physical_maps_by_dataset=dict(counts), labeled_constructs=len(labels),
                       methods_per_dataset=len(result) // 3, metrics_rows=len(result),
                       classifier_fits=0, training_updates=0, new_gpu_inference=False,
                       seconds=round(time.monotonic() - started, 3), hostname=socket.gethostname(),
                       bootstrap_replicates=protocol['bootstrap']['replicates'],
                       input_and_protocol_verification='PASS',
                       limitations=protocol['limitations'])
        dump(out / 'summary.json', summary)
        lines = ['NeurALPS frozen map aggregation test', '', protocol['study_role'],
                 'Scores are not activity probabilities. No weights fitted or changed.',
                 'WHOLE requires every physical object. SUPPORTED is an explicitly partial map.',
                 'Natural reference applies only to the full-context single-object score.', '',
                 'Dataset   Method                                      N    AUROC   B1 donor   B1 background']
        def fmt(x):
            return '--' if x is None else format(x, '.4f')
        for r in result:
            lines.append('{:9} {:42} {:4} {:>8} {:>10} {:>13}'.format(r['dataset'], r['method'], r['n'],
                         fmt(r['auroc']), fmt(r.get('donor_macro_auroc')), fmt(r.get('background_macro_auroc'))))
        lines += ['', 'No winner is selected automatically. Compare paired coverage and contrasts.',
                  'Natural length associations are descriptive and include composition differences.',
                  'Return inspection.zip for independent checking.']
        (out / 'REPORT.txt').write_text('\n'.join(lines) + '\n')
        repro = out / 'reproduce'
        repro.mkdir()
        for name in load(PACKAGE / 'PACKAGE_MANIFEST.json'):
            shutil.copy2(PACKAGE / name, repro / name)
        shutil.copy2(PACKAGE / 'PACKAGE_MANIFEST.json', repro / 'PACKAGE_MANIFEST.json')
        (out / 'COMPLETE').write_text(protocol['version'] + '\n')
        package_results(out)
        print((out / 'REPORT.txt').read_text(), flush=True)
        print('RESULT_ZIP:', out / 'inspection.zip', flush=True)
        print('RESULT_SHA256:', sha(out / 'inspection.zip'), flush=True)
    except BaseException:
        if (out / 'COMPLETE').exists():
            (out / 'COMPLETE').unlink()
        if (out / 'summary.json').exists():
            failed_summary = load(out / 'summary.json')
            failed_summary['status'] = 'FAILED'
            dump(out / 'summary.json', failed_summary)
        dump(out / 'fatal_error.json', dict(status='FAILED', traceback=traceback.format_exc()))
        package_results(out)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=PACKAGE.parent)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--preflight', action='store_true')
    args = parser.parse_args()
    root = args.root.resolve()
    if args.preflight:
        print(json.dumps(preflight(root), indent=2), flush=True)
    else:
        require(args.out is not None, '--out is required')
        execute(root, args.out.resolve())


if __name__ == '__main__':
    main()
