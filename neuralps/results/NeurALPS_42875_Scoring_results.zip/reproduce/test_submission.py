#!/usr/bin/env python3
"""Read-only launcher tests; no live scheduler, model loading or GPU work."""
from __future__ import annotations

import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch


def _read(path):
    return json.loads(Path(path).read_text())


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _write(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")
    temporary.replace(path)


class LauncherTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name).resolve()
        self.package = self.root / "package"
        self.package.mkdir()
        _write(self.package / "PACKAGE_MANIFEST.json", {"files": {}})
        source = Path(__file__).resolve().parent / "submit.py"
        fake = types.ModuleType("common")
        fake.read, fake.sha, fake.write = _read, _sha, _write
        fake.validate = lambda root, full=False: {"status": "PASS", "full": full}
        with patch.dict(sys.modules, {"common": fake}):
            spec = importlib.util.spec_from_file_location("scoring_submit_tested", source)
            self.launcher = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(self.launcher)
        self.launcher.HERE = self.package
        self.out = self.root / (self.launcher.PREFIX + "test")
        self.out.mkdir()
        self.request = self.out / "REQUEST.json"
        self.receipt = self.package / "SUBMISSION.json"
        self.body = dict(root=str(self.root), package=str(self.package), output=str(self.out),
                         package_sha256=_sha(self.package / "PACKAGE_MANIFEST.json"),
                         **self.launcher.SETTINGS)
        self.seal(self.body)
        self.info = dict(root=str(self.root), output=str(self.out), status="SUBMITTED", job_id="12345",
                         package_sha256=self.body["package_sha256"], previous_jobs=[])
        _write(self.receipt, self.info)
        _write(self.out / "SUBMISSION.json", self.info)

    def tearDown(self):
        self.tmp.cleanup()

    def seal(self, body):
        _write(self.request, body)
        (self.out / "REQUEST.sha256").write_text(_sha(self.request) + "\n")

    @staticmethod
    def result(stdout="", returncode=0, stderr=""):
        return subprocess.CompletedProcess([], returncode, stdout, stderr)

    def test_one_bounded_allocation_without_requeue(self):
        command = self.launcher.command(self.root, self.out, self.request)
        self.assertEqual(command[0], "sbatch")
        for item in ("--gres=gpu:1", "--nodes=1", "--ntasks=1", "--cpus-per-task=8",
                     "--time=02:00:00", "--no-requeue", "--partition=gpu_p5",
                     "--account=nef@a100", "--qos=qos_gpu_a100-t3"):
            self.assertIn(item, command)
        self.assertFalse(any("dependency" in value for value in command))

    def test_sealed_request_accepted(self):
        self.assertEqual(self.launcher.check_request(self.package, self.root, self.out, self.request), self.body)

    def test_changed_request_rejected_even_with_valid_json(self):
        _write(self.request, dict(self.body, batch_size=16))
        with self.assertRaisesRegex(ValueError, "checksum"):
            self.launcher.check_request(self.package, self.root, self.out, self.request)

    def test_resealed_settings_change_is_rejected(self):
        self.seal(dict(self.body, batch_size=16))
        with self.assertRaisesRegex(ValueError, "settings"):
            self.launcher.check_request(self.package, self.root, self.out, self.request)

    def test_float_setting_is_rejected(self):
        self.seal(dict(self.body, query_batch=64.0))
        with self.assertRaisesRegex(ValueError, "settings"):
            self.launcher.check_request(self.package, self.root, self.out, self.request)

    def test_request_path_change_is_rejected(self):
        self.seal(dict(self.body, output=str(self.root / "other")))
        with self.assertRaisesRegex(ValueError, "path identity"):
            self.launcher.check_request(self.package, self.root, self.out, self.request)

    def test_finished_allocation_can_resume(self):
        with patch.object(self.launcher.subprocess, "run", return_value=self.result()) as run:
            info, out = self.launcher.resolve_resume(self.root, None, self.receipt)
        self.assertEqual(info, self.info)
        self.assertEqual(out, self.out)
        self.assertEqual(run.call_args.args[0][0], "squeue")
        self.assertTrue(run.call_args.kwargs["check"])

    def test_active_allocation_cannot_resume(self):
        with patch.object(self.launcher.subprocess, "run", return_value=self.result("12345 RUNNING\n")):
            with self.assertRaisesRegex(ValueError, "still queued/running"):
                self.launcher.resolve_resume(self.root, None, self.receipt)

    def test_scheduler_query_failure_does_not_allow_resume(self):
        error = subprocess.CalledProcessError(1, ["squeue"])
        with patch.object(self.launcher.subprocess, "run", side_effect=error):
            with self.assertRaises(subprocess.CalledProcessError):
                self.launcher.resolve_resume(self.root, None, self.receipt)

    def test_integrity_failure_blocks_resume(self):
        _write(self.out / "INTEGRITY_FAILURE.json", {"error": "historical parity differs"})
        with patch.object(self.launcher.subprocess, "run") as run:
            with self.assertRaisesRegex(RuntimeError, "integrity/parity"):
                self.launcher.resolve_resume(self.root, None, self.receipt)
        run.assert_not_called()

    def test_plain_batch_failure_is_repairable(self):
        _write(self.out / "BATCH_FAILURE.json", {"stage": "environment_setup", "exit_code": 1})
        with patch.object(self.launcher.subprocess, "run", return_value=self.result()):
            self.launcher.resolve_resume(self.root, None, self.receipt)

    def test_changed_package_blocks_resume(self):
        _write(self.package / "PACKAGE_MANIFEST.json", {"files": {"different": "hash"}})
        with self.assertRaisesRegex(ValueError, "package checksum"):
            self.launcher.resolve_resume(self.root, None, self.receipt)

    def test_unconfirmed_submission_never_auto_resumes(self):
        _write(self.receipt, {"status": "SUBMISSION_UNCERTAIN", "output": str(self.out)})
        with patch.object(self.launcher.subprocess, "run") as run:
            with self.assertRaisesRegex(ValueError, "No confirmed prior job"):
                self.launcher.resolve_resume(self.root, None, self.receipt)
        run.assert_not_called()

    def test_explicit_output_cannot_escape_root(self):
        with self.assertRaisesRegex(ValueError, "directly under project root"):
            self.launcher.resolve_resume(self.root, self.root.parent / (self.launcher.PREFIX + "outside"), self.receipt)

    def test_confirmation_records_history_and_job(self):
        with patch.object(self.launcher.subprocess, "run", return_value=self.result("23456;jeanzay\n")) as run:
            info = self.launcher.submit_once(self.root, self.out, self.request, self.receipt, self.info)
        self.assertEqual(info["job_id"], "23456")
        self.assertEqual(info["previous_jobs"], ["12345"])
        self.assertEqual(_read(self.receipt), _read(self.out / "SUBMISSION.json"))
        self.assertEqual(run.call_count, 1)

    def test_sbatch_timeout_records_uncertainty_without_retry(self):
        with patch.object(self.launcher.subprocess, "run", side_effect=subprocess.TimeoutExpired("sbatch", 60)) as run:
            with self.assertRaisesRegex(RuntimeError, "uncertain"):
                self.launcher.submit_once(self.root, self.out, self.request, self.receipt)
        self.assertEqual(_read(self.receipt)["status"], "SUBMISSION_UNCERTAIN")
        self.assertNotIn("job_id", _read(self.receipt))
        self.assertEqual(run.call_count, 1)

    def test_sbatch_unparseable_output_records_uncertainty(self):
        with patch.object(self.launcher.subprocess, "run", return_value=self.result("unexpected success\n")):
            with self.assertRaisesRegex(RuntimeError, "did not confirm"):
                self.launcher.submit_once(self.root, self.out, self.request, self.receipt)
        self.assertEqual(_read(self.receipt)["status"], "REJECTED_OR_UNCERTAIN")

    def test_run_does_not_duplicate_existing_receipt(self):
        with patch.object(self.launcher, "submit_once") as submit, patch.object(self.launcher, "status") as status:
            with contextlib.redirect_stdout(io.StringIO()):
                self.launcher.main(["--root", str(self.root), "run"])
        submit.assert_not_called()
        status.assert_called_once_with(self.info)

    def test_completed_run_is_not_resubmitted(self):
        _write(self.out / "COMPLETE.json", {"status": "COMPLETE"})
        with patch.object(self.launcher.subprocess, "run", return_value=self.result()):
            with patch.object(self.launcher, "submit_once") as submit, patch.object(self.launcher, "status"):
                with contextlib.redirect_stdout(io.StringIO()):
                    self.launcher.main(["--root", str(self.root), "resume"])
        submit.assert_not_called()

    def test_status_does_not_require_live_model_assets(self):
        with patch.object(self.launcher, "validate", side_effect=AssertionError("must not preflight")):
            with patch.object(self.launcher, "status") as status:
                self.launcher.main(["--root", str(self.root), "status"])
        status.assert_called_once_with(self.info)


if __name__ == "__main__":
    unittest.main(verbosity=2)
