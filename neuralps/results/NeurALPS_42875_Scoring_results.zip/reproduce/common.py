"""Standard-library integrity checks shared by submission and allocated scoring."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
INPUT_NAME = 'NeurALPS_42875_Inputs_20261103'
ENCODING_NAME = 'neuralps_42875_encode_20261103T204641Z_641ae577'
INPUT_MANIFEST_SHA = '641ae577a5bbc6d6ec91354808df7654a7faabc097a657b2e3905a10d5dbea9d'
BANK_SHA = {
    'feature_bank.json': '3144e7b19c9ddbfe03a94fc72375e90321cb6bfa75f88aa021b71dcd2588776b',
    'feature_bank.npz': '6702dc70a5b408b1c13829b2457e08432ed75c683a2c7f3018e8a48ce31dfcfc',
    'progress.json': '129eea4faa492a26e1af54150d8f69b1898daef09f0720b74ce5017c4419e8d5',
    'row_provenance.json': 'c9746157c5347843ff7fa48efa635c67c34fbf82f5e0512d19e9d3a599ba5114',
}


class IntegrityError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise IntegrityError(message)


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
    tmp.replace(path)


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            result.update(block)
    return result.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def _check(root, relative, expected, full, deferred):
    relative = Path(relative)
    require(not relative.is_absolute() and '..' not in relative.parts, 'Unsafe asset path')
    path = root / relative
    require(path.is_file() and not path.is_symlink(), 'Missing/linked asset: ' + str(path))
    if full or path.stat().st_size <= 4 << 20:
        before = path.stat()
        require(sha(path) == expected, 'Checksum differs: ' + str(path))
        after = path.stat()
        require((before.st_size, before.st_mtime_ns, before.st_ino) ==
                (after.st_size, after.st_mtime_ns, after.st_ino), 'Asset changed while hashing')
    else:
        deferred.append(str(path))


def validate(root, full=False):
    root = Path(root).resolve()
    deferred = []
    manifest = read(HERE / 'PACKAGE_MANIFEST.json')
    require(manifest['schema'] == 'neuralps_42875_scoring_package_v1', 'Wrong scoring package schema')
    for relative, expected in manifest['files'].items():
        _check(HERE, relative, expected, True, deferred)
    inputs = root / INPUT_NAME
    _check(inputs, 'PACKAGE_MANIFEST.json', INPUT_MANIFEST_SHA, True, deferred)
    # Load only the verified original stdlib selftest, never a model on login.
    source = inputs / 'selftest.py'
    _check(inputs, 'selftest.py', read(inputs / 'PACKAGE_MANIFEST.json')['files']['selftest.py'], True, deferred)
    spec = importlib.util.spec_from_file_location('verified_input_selftest', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    input_check = module.validate_package(full=full)
    encoding = root / ENCODING_NAME
    complete = read(encoding / 'COMPLETE.json')
    require(complete['status'] == 'MODEL_INPUTS_READY_NO_SCORES' and
            complete['assemblies'] == 42875 and complete['unique_model_sequences'] == 2602 and
            complete['package_sha256'] == INPUT_MANIFEST_SHA,
            'Encoding completion/input identity differs')
    require(complete['model_indices_sha256'] == read(inputs / 'PACKAGE_MANIFEST.json')['files']['data/model_indices.npz'],
            'Encoding compact-input identity differs')
    for name, expected in BANK_SHA.items():
        require(complete['feature_bank_artifacts_sha256']['feature_bank/' + name] == expected,
                'Encoding bank completion seal differs')
        _check(encoding / 'feature_bank', name, expected, full, deferred)
    assets = read(HERE / 'ASSETS.json')
    for relative, expected in assets['project_files_sha256'].items():
        _check(root, relative, expected, full, deferred)
    return dict(status='SCORING_FULL_INPUTS_OK' if full else 'SCORING_PREFLIGHT_OK',
                package_sha256=sha(HERE / 'PACKAGE_MANIFEST.json'),
                input_package=str(inputs), feature_bank=str(encoding / 'feature_bank'),
                input_check=input_check, project_assets=len(assets['project_files_sha256']),
                deferred_large_hashes=deferred,
                embedding_extraction=False, training=False, candidate_count=42875)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--full', action='store_true')
    args = parser.parse_args()
    print(json.dumps(validate(args.root, full=args.full), indent=2))
