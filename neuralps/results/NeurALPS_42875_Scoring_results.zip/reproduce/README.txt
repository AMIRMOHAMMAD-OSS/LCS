NeurALPS: complete 42,875-assembly scoring
=======================================

This package performs inference with the already fitted comparison models and
the verified 2,602-vector ESM-C bank. It does not train, install software, access
the network, or extract embeddings. Actual inference runs on Jean Zay.

On Jean Zay, from /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2:

  unzip NeurALPS_42875_Scoring_20261104.zip
  python3 -B NeurALPS_42875_Scoring_20261104/submit.py preflight
  python3 -B NeurALPS_42875_Scoring_20261104/submit.py run
  python3 -B NeurALPS_42875_Scoring_20261104/submit.py status

The launcher submits one A100, eight CPUs, maximum two hours. Preflight is
standard-library-only; all model work stays in the allocation. Repeat `run`
does not submit a duplicate. If paused or interrupted, use:

  python3 -B NeurALPS_42875_Scoring_20261104/submit.py resume

Only explicit resume submits another allocation, continuing the same sealed
chunks. No automatic job chain. A numerical/integrity failure blocks resume
until reviewed; do not bypass that check. Results are written to a new
neuralps_42875_score_* directory. Existing inputs, embeddings and fits are read
only. Fixed required paths and SHA256 values are in ASSETS.json and common.py.

SCORING CONTENT

Ten inherited supervised candidates, each retaining its own score/rank:
  1. typed__bode2_only
  2. typed__bode2_bode1_w025
  3. typed__bode2_tdomain_w025
  4. typed__all3_w025
  5. typed_chemistry__bode2_only
  6. raw_mlp__bode2_only (three-seed probability mean)
  7. ssl10_finetune__bode2_only (three-seed probability mean)
  8. ssl26_finetune__bode2_only (three-seed probability mean)
  9. blend50_typed_ssl10_finetune
 10. blend50_typed_ssl26_finetune

All nine individual neural seed predictions/logits are retained, alongside
ensemble seed standard deviations. Seed variability is not a confidence
interval. The two blends use the previously fixed 50/50 weights. There is no
newly optimized blend, selected winner, or fitted probability calibration.
No observed combination outcome enters inference or selects a candidate.

The chemistry head is the previous 105-single-trained model, using source-
expected substrate identities at peptide positions and ordered adjacent pairs.
These amino acids are substrates selected by A domains, not the amino-acid
residues of the A-domain proteins. Protein features remain in the model.
All identities are covered. Unseen adjacent-pair terms retain zero coefficients
under the fixed training vocabulary; the CSV lists them per assembly. No
stereochemistry, measured product identity, epimerization success, or TE kinetic
measurement is invented. See chemistry/CHEMISTRY_NOTES.txt for evidence/limits.

Full compatibility maps use frozen natural-data SSL26 with its original local
and global context. Every physical domain and connection is independently
masked. Overlapping sequence features and exact sequence copies are also
hidden. Both roles of a protein break are hidden together, averaged and counted
as one connection. The score is the unchanged mixture of raw and centered
cosine reconstruction agreement, in [-1,1], higher = stronger agreement.

Unsupervised assembly summaries include domain/connection-balanced mean and
balanced lower quartile, plus mean, lower quartile, minimum, and separate domain
and connection means. Raw-cosine summaries are diagnostics from the same masked
predictions. These values are not activity probabilities or explanations of
the supervised classifier. Incomplete coverage produces NaN/blank aggregates
with an explicit availability flag, never a zero-valued score.

All maps preserve physical junction kinds and corrected B/J/UNKNOWN display
annotations. Exact source adjacency recovers source labels; newly assembled
adjacencies remain UNKNOWN. This overlay does not change any model tensor.

OUTPUTS

  scores.csv                   All 42,875 IDs, donors, expected amino acids,
                               chemistry coverage, scores and descending ranks.
                               The previously measured 27 triples are flagged.
  scores.npz                   Aligned numeric score arrays and IDs.
  compatibility_maps.npz       Every object score, exact hidden-slot mask,
                               status, physical kind, corrected boundary label,
                               context count, and compact model input indices.
  full_maps.jsonl.gz           Full annotated records, object slots, masks and
                               aggregates, one assembly per JSON line.
  NUMERICAL_GATES.json          Actual GPU regression results, including the
                               previous 27 triples and 1/2/3/4-chain cases.
  SUPERVISED_METADATA.json      Model identities, coefficients' provenance,
                               ensemble and score interpretation.
  MAP_CONTRACT.json             Frozen physical-map definition.
  RESULTS_MANIFEST.json         Output hashes and sizes.
  COMPLETE.json                 Written only after all scores/maps and the
                               inspection archive have been committed.
  inspection.zip               Compact scores, ALL numeric object maps/masks,
                               gates, metadata, log snapshots and source code.

Verbose full_maps.jsonl.gz remains on Jean Zay and is not duplicated inside
inspection.zip. The compact archive retains all map scores and hidden slots.
Use inspect_map.py to retrieve one verbose map without loading the whole file:

  python3 NeurALPS_42875_Scoring_20261104/inspect_map.py \
    --output neuralps_42875_score_<actual_output_name> \
    --assembly BODE2_045-047-059 --save example_map.json

Read EXPORT_SCHEMA.json before directly using the compact NPZ arrays.

VALIDATION AND INTERPRETATION

Before bulk scoring, the allocated job must pass mandatory PyTorch batching
tests; all ten predictions and nine seed members against the previous 27
triples; frozen typed features; all 927 historical triple object maps; exact
compact-vs-original tensors for one through four physical chains; and optimized
vs-original map inference for those chain examples. Chemistry reproduces all
105 single and 60 combination feature dictionaries. Pinned package, input bank,
weights, target means and source code are checked before use.

The package's local audit is not a claim that these GPU gates have already run.
No new scores exist until Jean Zay reports SCORING_COMPLETE. Prior BODE1
chemistry improvements do not establish improved BODE2 triple prediction. The
earlier triples were a small selected grid, and their activity ranking remains
weak. All full-library activity scores are exploratory prospective rankings.
The reconstructed mature assemblies are conditional on successful splicing;
these computations do not verify expression, splicing or biochemical activity.
