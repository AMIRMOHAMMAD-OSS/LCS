"""Resume sealed chunks of full-library inference; never train or extract ESM."""
from __future__ import annotations
import argparse
import csv
import fcntl
import gzip
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import sys
import time
import zipfile

import numpy as np
from common import (HERE, INPUT_NAME, ENCODING_NAME, BANK_SHA, IntegrityError,
                    digest, read, require, sha, write)

STOP = False
EXPECTED_CANDIDATES = 42875
EXPECTED_OBJECTS = 1454075
EXPECTED_BOUNDARY_COUNTS = {'B': 322175, 'J': 254800, 'UNKNOWN': 128625}


def request_stop(*_):
    global STOP
    STOP = True


def load_library(root):
    path = Path(root) / INPUT_NAME / 'library_io.py'
    spec = importlib.util.spec_from_file_location('scoring_verified_library_io', path)
    io = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(io)
    library = io.Library()
    with gzip.open(path.parent / 'data/candidate_inventory.csv.gz', 'rt') as handle:
        library.inventory = list(csv.DictReader(handle))
    require([row['assembly_id'] for row in library.inventory] == library.arrays['assembly_ids'].tolist(),
            'Candidate inventory order differs')
    bank_path = Path(root) / ENCODING_NAME / 'feature_bank/feature_bank.npz'
    require(sha(bank_path) == BANK_SHA['feature_bank.npz'], 'Encoded bank differs')
    with np.load(bank_path, allow_pickle=False) as data:
        hashes, matrix = data['hashes'].tolist(), data['vectors'].copy()
    require(hashes == library.sequence_hashes.tolist(), 'Feature-bank order differs from compact inputs')
    require(matrix.dtype == np.float32 and matrix.shape == (2602, 1152) and
            np.isfinite(matrix).all() and (np.abs(matrix).sum(1) > 0).all(), 'Invalid feature bank')
    return io, library, matrix, dict(zip(hashes, matrix))


def reconstruct_chunk(io, library, indices):
    pairs = []
    for i in indices:
        i = int(i); n = len(library.donors)
        ds = [library.donors[i // n**2], library.donors[i // n % n], library.donors[i % n]]
        record, parents = io.reconstruct(ds, library.registry, library.constructor)
        require(record['assembly_id'] == str(library.arrays['assembly_ids'][i]) and
                io.model_signature(record) == str(library.arrays['model_signatures'][i]),
                'Reconstructed/compact model input mismatch')
        require(io.sequence_signature(record) == library.inventory[i]['physical_sequence_signature'],
                'Reconstructed physical-chain identity mismatch')
        pairs.append((record, parents))
    return pairs


def settings_identity(request, supervised, mapper):
    import torch
    import scipy
    import sklearn
    return dict(package_sha256=request['package_sha256'],
                input_package_sha256=request['preflight']['input_check'].get('package_sha256',
                    '641ae577a5bbc6d6ec91354808df7654a7faabc097a657b2e3905a10d5dbea9d'),
                bank_sha256=BANK_SHA['feature_bank.npz'],
                settings={k: request[k] for k in ('chunk_size', 'query_batch', 'batch_size')},
                environment=dict(torch=torch.__version__, cuda=torch.version.cuda,
                                 numpy=np.__version__, scipy=scipy.__version__, sklearn=sklearn.__version__,
                                 gpu=torch.cuda.get_device_name(0), float32=True, tf32=False),
                map_contract=mapper.summary(),
                assets_sha256=sha(HERE / 'ASSETS.json'))


def known27_pairs(root):
    with gzip.open(Path(root) / INPUT_NAME / 'inputs/known_multis_model_inputs.json.gz', 'rt') as handle:
        data = json.load(handle)
    records = [r for r in data['records'] if all(d not in ('X', 'native') for d in r['donors'])]
    require(len(records) == 27, 'Known-triple parity cohort differs')
    return [(r, data['parents']) for r in records]


def gates(root, io, library, matrix, vectors, supervised, mapper, out):
    """Old predictions/maps are regression references, never fitting targets."""
    import chemistry
    from maps.scorer import compare_results
    from supervised.runner import load_parity_fixture
    import numerical_tests
    numerical = numerical_tests.run()
    pairs = known27_pairs(root)
    records = [r for r, _ in pairs]
    supervised_check = supervised.parity(records, vectors, load_parity_fixture(),
        chemistry=[chemistry.features_for_record(r) for r in records], tolerance=1e-4)
    reference_maps = read(HERE / 'references/known27_maps.json')
    expected = {r['assembly_id']: r for r in reference_maps['assemblies']}
    actual = mapper.score_records(pairs)
    map_checks = [compare_results(item, expected[item['assembly_id']]) for item in actual]
    # Exercise physical breaks through four-chain constructs and exact compact parity.
    counts = np.array([int(row['n_chains']) for row in library.inventory])
    representatives = [int(np.flatnonzero(counts == k)[0]) for k in (1, 2, 3, 4)]
    new_pairs = reconstruct_chunk(io, library, representatives)
    compact = library.numpy_batch(representatives, matrix)
    direct = supervised.am.collate_records([r for r, _ in new_pairs], vectors.__getitem__)
    for name, tensor in direct.items():
        require(np.array_equal(tensor.cpu().numpy(), compact[name]), 'Compact tensor differs: ' + name)
    fast = mapper.score_records(new_pairs)
    slow = mapper.score_records_reference(new_pairs)
    new_checks = [compare_results(a, b) for a, b in zip(fast, slow)]
    check = dict(status='PASS', numerical_tests=numerical, supervised=supervised_check,
                 historical_map_assemblies=27, historical_map_checks=map_checks,
                 physical_chain_counts=[len(r['parent_sequence_hashes']) for r, _ in new_pairs],
                 batched_vs_original_map_checks=new_checks,
                 compact_tensor_fields_exact=sorted(compact), chemistry=chemistry.audit(Path(root) / INPUT_NAME),
                 evaluation_labels_read=False, training_performed=False)
    write(out / 'NUMERICAL_GATES.json', check)
    return check


def decorate_maps(items, records, annotator, io, indices):
    indices = list(indices)
    require(len(items) == len(records) == len(indices), 'Map/record/index lengths differ')
    for i, item, record in zip(indices, items, records):
        require(item['assembly_id'] == record['assembly_id'], 'Map/record identity differs')
        displayed = annotator.annotate_record(record)
        require(io.model_signature(displayed) == io.model_signature(record), 'Display annotation changed inputs')
        require(len(item['objects']) == len(record['route']), 'Map object count mismatch')
        item.update(library_index=int(i), donors=record['donors'],
                    physical_chain_count=len(record['parent_sequence_hashes']),
                    model_signature=io.model_signature(record),
                    boundary_annotation_policy=displayed['boundary_annotation_policy'])
        for j, obj in enumerate(item['objects']):
            require(obj['object_index'] == j and obj['kind'] == record['route'][j]['kind'], 'Map object order mismatch')
            obj['annotation'] = displayed['route'][j]
        # Inference hash above deliberately identifies the original input record.
        item['display_record_sha256'] = digest(displayed)
    return items


def commit_chunk(out, start, stop, identity, records, columns, maps):
    """A seal is committed last; interrupted files without a seal are replaceable."""
    prefix = out / 'chunks' / f'{start:05d}_{stop:05d}'
    prefix.parent.mkdir(exist_ok=True)
    require(len(records) == len(maps) == stop-start, 'Chunk record/map count differs')
    require([m['library_index'] for m in maps] == list(range(start,stop)) and
            [m['assembly_id'] for m in maps] == [r['assembly_id'] for r in records], 'Chunk map alignment differs')
    valid = np.asarray(columns['map_complete'], dtype=bool)
    for key, value in columns.items():
        value = np.asarray(value)
        require(value.shape == (stop-start,), 'Wrong-shaped scalar output: ' + key)
        if key.startswith(('unsupervised__', 'rawcos_diagnostic__')):
            require(np.isfinite(value[valid]).all() and np.isnan(value[~valid]).all(),
                    'Invalid or unmarked missing map aggregate: ' + key)
        else:
            require(np.isfinite(value).all(), 'Nonfinite scalar output: ' + key)
    scores_path = prefix.with_suffix('.npz')
    maps_path = prefix.with_suffix('.jsonl.gz')
    temporary = scores_path.with_name(scores_path.name + '.tmp')
    with temporary.open('wb') as handle:
        np.savez_compressed(handle, assembly_ids=np.array([r['assembly_id'] for r in records]), **columns)
    temporary.replace(scores_path)
    temporary = maps_path.with_name(maps_path.name + '.tmp')
    with gzip.open(temporary, 'wt', compresslevel=6) as handle:
        for item in maps:
            handle.write(json.dumps(item, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n')
    temporary.replace(maps_path)
    seal = dict(start=start, stop=stop, run_identity=identity,
                assembly_ids=[r['assembly_id'] for r in records],
                files={p.name: sha(p) for p in (scores_path, maps_path)},
                map_objects=sum(len(m['objects']) for m in maps),
                all_maps_complete=all(m['independent_aggregate']['full']['complete'] for m in maps))
    write(prefix.with_suffix('.seal.json'), seal)
    return seal


def validate_chunk(out, start, stop, identity, expected_ids):
    path = out / 'chunks' / f'{start:05d}_{stop:05d}.seal.json'
    if not path.exists():
        return None
    seal = read(path)
    require(seal['start'] == start and seal['stop'] == stop and seal['run_identity'] == identity and
            seal['assembly_ids'] == list(expected_ids), 'Resume chunk identity differs')
    expected_files = {f'{start:05d}_{stop:05d}.npz', f'{start:05d}_{stop:05d}.jsonl.gz'}
    require(set(seal['files']) == expected_files, 'Resume chunk artifact set differs')
    for name, expected in seal['files'].items():
        require(sha(out / 'chunks' / name) == expected, 'Resume chunk checksum differs: ' + name)
    return seal


def map_scalars(items):
    columns = {}
    for field, prefix in (('independent_aggregate', 'unsupervised'), ('rawcos_aggregate', 'rawcos_diagnostic')):
        for key in ('balanced_mean', 'balanced_q25', 'mean', 'q25', 'minimum', 'domains_mean', 'boundaries_mean'):
            columns[prefix + '__' + key] = np.array([
                m[field]['full'][key] if m[field]['full'][key] is not None else np.nan for m in items])
    # Missing maps are represented explicitly. Their aggregate columns become blank on CSV export.
    columns['map_complete'] = np.array([m['independent_aggregate']['full']['complete'] for m in items], dtype=np.uint8)
    columns['map_scored_objects'] = np.array([m['independent_aggregate']['full']['scored'] for m in items], dtype=np.int32)
    columns['map_total_objects'] = np.array([len(m['objects']) for m in items], dtype=np.int32)
    return columns


def rank_descending(values, valid):
    """Competition ranks: ties share their smallest descending rank; invalid=0."""
    values = np.asarray(values)
    out = np.zeros(len(values), dtype=np.int32)
    ids = np.flatnonzero(valid)
    order = ids[np.argsort(-values[ids], kind='stable')]
    last, rank = None, 0
    for position, i in enumerate(order, 1):
        if last is None or values[i] != last:
            rank = position; last = values[i]
        out[i] = rank
    return out


def consolidate(out, library, identity, request, chemistry_names):
    import chemistry
    n, width = len(library), int(max(library.arrays['lengths']))
    require(n == EXPECTED_CANDIDATES, 'Incomplete full-library candidate scope')
    arrays, ids = {}, []
    maps_out = out / 'full_maps.jsonl.gz'
    map_arrays = dict(mixed_score=np.full((n, width), np.nan, np.float64),
                      rawcos_score=np.full((n, width), np.nan, np.float64),
                      present=np.zeros((n, width), bool), scored=np.zeros((n, width), bool),
                      kind=np.full((n, width), -1, np.int8),
                      boundary_label=np.full((n, width), -1, np.int8),
                      status_code=np.zeros((n, width), np.uint8),
                      remaining_context_count=np.full((n, width), -1, np.int16),
                      masked_fraction=np.full((n, width), np.nan, np.float64),
                      hidden_slot_bits=np.zeros((n, width, (width*3+63)//64), np.uint64))
    annotation_counts = {k: 0 for k in ('B', 'J', 'UNKNOWN')}
    total_objects, completed_maps = 0, 0
    with maps_out.with_suffix('.tmp').open('wb') as stream:
        for start in range(0, n, request['chunk_size']):
            stop = min(n, start+request['chunk_size'])
            seal = validate_chunk(out, start, stop, identity, library.arrays['assembly_ids'][start:stop].tolist())
            require(seal is not None, 'Missing chunk at finalization')
            base = out / 'chunks' / f'{start:05d}_{stop:05d}'
            with np.load(base.with_suffix('.npz'), allow_pickle=False) as values:
                ids.extend(values['assembly_ids'].tolist())
                for key in values.files:
                    if key != 'assembly_ids':
                        arrays.setdefault(key, []).append(values[key].copy())
            with base.with_suffix('.jsonl.gz').open('rb') as source:
                shutil.copyfileobj(source, stream)
            next_index = start
            with gzip.open(base.with_suffix('.jsonl.gz'), 'rt') as source:
                for line in source:
                    result = json.loads(line); i = result['library_index']
                    require(i == next_index and i < stop and result['assembly_id'] == str(library.arrays['assembly_ids'][i]), 'Map export alignment differs')
                    next_index += 1
                    require([o['object_index'] for o in result['objects']] == list(range(int(library.arrays['lengths'][i]))),
                            'Incomplete/duplicate map objects in export')
                    completed_maps += int(result['independent_aggregate']['full']['complete'])
                    for obj in result['objects']:
                        j = obj['object_index']; total_objects += 1
                        require(obj['kind'] == int(library.arrays['kind'][i,j]), 'Map object kind differs')
                        map_arrays['present'][i, j] = True
                        map_arrays['kind'][i, j] = obj['kind']
                        codes = {'SCORED': 1, 'INSUFFICIENT_VISIBLE_CONTEXT': 2, 'MISSING_SEQUENCE_FEATURE': 3}
                        require(obj['status'] in codes, 'Unexpected map status at export')
                        map_arrays['status_code'][i,j] = codes[obj['status']]
                        context_count = obj['mask'].get('remaining_context_by_target', {}).get(str(j), -1)
                        map_arrays['remaining_context_count'][i,j] = context_count
                        map_arrays['masked_fraction'][i,j] = obj['mask'].get('masked_fraction', np.nan)
                        if obj['kind']:
                            tag = obj['annotation']['annotation']; annotation_counts[tag] += 1
                            map_arrays['boundary_label'][i, j] = {'B': 0, 'J': 1, 'UNKNOWN': 2}[tag]
                        if obj['status'] == 'SCORED':
                            map_arrays['scored'][i, j] = True
                            map_arrays['mixed_score'][i, j] = obj['scores']['full']
                            map_arrays['rawcos_score'][i, j] = obj['rawcos']['full']
                        for target, role in obj['mask']['hidden']:
                            require(0 <= target < int(library.arrays['lengths'][i]) and 0 <= role < 3 and
                                    library.arrays['state'][i,target,role] == 1, 'Invalid hidden physical slot')
                            bit = target*3+role
                            map_arrays['hidden_slot_bits'][i, j, bit//64] |= np.uint64(1) << np.uint64(bit%64)
            require(next_index == stop, 'Missing assembly map in export chunk')
    maps_out.with_suffix('.tmp').replace(maps_out)
    require(ids == library.arrays['assembly_ids'].tolist() and total_objects == EXPECTED_OBJECTS,
            'Incomplete final candidate/object coverage')
    require(annotation_counts == EXPECTED_BOUNDARY_COUNTS, 'Boundary metadata counts differ')
    arrays = {k: np.concatenate(v) for k, v in arrays.items()}
    rank_fields = [k for k in arrays if k.endswith('__probability') and '__seed' not in k]
    rank_fields += ['unsupervised__balanced_mean', 'unsupervised__balanced_q25']
    for key in rank_fields:
        valid = arrays['map_complete'].astype(bool) if key.startswith('unsupervised') else np.ones(n, bool)
        arrays[key + '__rank'] = rank_descending(arrays[key], valid)
    with (out / 'scores.npz').open('wb') as handle:
        np.savez_compressed(handle, assembly_ids=np.array(ids), **arrays)
    with (out / 'compatibility_maps.npz').open('wb') as handle:
        np.savez_compressed(handle, assembly_ids=np.array(ids), **map_arrays,
                            **{key: library.arrays[key] for key in
                               ('domain_type','chain','state','feature_row','lengths','sequence_hashes')})
    known = {r['assembly_id'] for r, _ in known27_pairs(Path(request['root']))}
    metadata_keys = ['library_index','assembly_id','donor_xut2','donor_xut3','donor_xut4',
                     'expected_peptide_aa','known_27_triple','chemistry_unseen_pair_count','chemistry_unseen_terms']
    with (out / 'scores.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=metadata_keys + sorted(arrays))
        writer.writeheader()
        for i, aid in enumerate(ids):
            ds = aid.removeprefix('BODE2_').split('-')
            chem = chemistry.coverage(chemistry.expected_features(ds), chemistry_names)
            row = dict(library_index=i, assembly_id=aid, donor_xut2=ds[0], donor_xut3=ds[1], donor_xut4=ds[2],
                       expected_peptide_aa='>'.join(chemistry.expected_amino_acids(ds)), known_27_triple=int(aid in known),
                       chemistry_unseen_pair_count=chem['unseen_pair_count'], chemistry_unseen_terms=';'.join(chem['unseen_features']))
            for key, values in arrays.items():
                row[key] = values[i].item()
                if not arrays['map_complete'][i] and key.startswith(('unsupervised__','rawcos_diagnostic__')):
                    row[key] = ''
            writer.writerow(row)
    summary = dict(status='SCORING_COMPLETE', assemblies=n, physical_map_objects=total_objects,
                   complete_assembly_maps=completed_maps, corrected_boundary_labels=annotation_counts,
                   supervised_candidates=10, training_performed=False, embedding_extraction=False,
                   scores_are_prospectively_unvalidated=True, primary_map_path='full',
                   run_identity=identity, final_score_columns=rank_fields,
                   full_json_maps='full_maps.jsonl.gz', compact_full_maps='compatibility_maps.npz',
                   known_triples_flagged=27)
    write(out / 'SUMMARY.json', summary)
    files = ['scores.csv','scores.npz','compatibility_maps.npz','full_maps.jsonl.gz','SUMMARY.json',
             'NUMERICAL_GATES.json','RUN_IDENTITY.json','REQUEST.json','REQUEST.sha256',
             'SUPERVISED_METADATA.json','MAP_CONTRACT.json']
    if (out/'SUBMISSION.json').is_file():
        files.append('SUBMISSION.json')
    for name in ('validation.log', 'scoring.log'):
        if (out/name).is_file():
            snapshot = name + '.snapshot.txt'
            shutil.copyfile(out/name, out/snapshot)
            files.append(snapshot)
    write(out / 'RESULTS_MANIFEST.json', {p: dict(sha256=sha(out/p), bytes=(out/p).stat().st_size) for p in files})
    completion = dict(**summary, results_manifest_sha256=sha(out / 'RESULTS_MANIFEST.json'),
                      job_id=os.environ.get('SLURM_JOB_ID'), completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    # The compact archive contains every per-object score and exact hidden-slot mask.
    # Repeated verbose source annotations remain available in the full JSONL on Jean Zay.
    with zipfile.ZipFile(out / 'inspection.zip.tmp', 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name in files + ['RESULTS_MANIFEST.json']:
            if name != 'full_maps.jsonl.gz':
                archive.write(out/name, name)
        archive.writestr('COMPLETE.json', json.dumps(completion, indent=2, sort_keys=True) + '\n')
        for path in sorted(HERE.rglob('*')):
            if path.is_file() and path.suffix != '.pyc' and path.name not in ('SUBMISSION.json','submission.lock'):
                archive.write(path, 'reproduce/' + str(path.relative_to(HERE)))
    (out / 'inspection.zip.tmp').replace(out / 'inspection.zip')
    write(out / 'progress.json', summary)
    write(out / 'COMPLETE.json', completion)
    return summary


def run(args):
    import chemistry
    from boundary_metadata import BoundaryAnnotations
    from maps.scorer import MapScorer
    from supervised.runner import SupervisedScorer
    from submit import check_request
    out, root = args.out.resolve(), args.root.resolve()
    request = check_request(HERE, root, out, args.request)
    deadline = time.monotonic() + args.seconds
    io, library, matrix, vectors = load_library(root)
    supervised = SupervisedScorer(root, device='cuda', batch_size=request['batch_size'])
    mapper = MapScorer(root, vectors, device='cuda', threads=8, query_batch=request['query_batch'])
    write(out / 'SUPERVISED_METADATA.json', supervised.metadata)
    from maps.scorer import CONTRACT
    write(out / 'MAP_CONTRACT.json', CONTRACT)
    body = settings_identity(request, supervised, mapper)
    identity = digest(body)
    if (out / 'RUN_IDENTITY.json').exists():
        require(read(out / 'RUN_IDENTITY.json')['run_identity'] == identity, 'Resume environment/settings differ')
    else:
        write(out / 'RUN_IDENTITY.json', dict(run_identity=identity, identity=body))
    write(out / 'progress.json', dict(stage='NUMERICAL_GATES', run_identity=identity))
    gates(root, io, library, matrix, vectors, supervised, mapper, out)
    annotator = BoundaryAnnotations(root / INPUT_NAME)
    chemistry_names = supervised.chemistry_feature_names
    for marker in ('PAUSED.json','BATCH_FAILURE.json','failure_inspection.zip'):
        (out / marker).unlink(missing_ok=True)
    for start in range(0, len(library), request['chunk_size']):
        stop = min(len(library), start+request['chunk_size'])
        if validate_chunk(out, start, stop, identity, library.arrays['assembly_ids'][start:stop].tolist()):
            continue
        if STOP or time.monotonic() > deadline - 180:
            write(out / 'PAUSED.json', dict(status='PAUSED', next_index=start, reason='Allocation budget or signal; sealed chunks retained'))
            return
        began = time.monotonic()
        pairs = reconstruct_chunk(io, library, range(start, stop)); records = [r for r, _ in pairs]
        columns = supervised.score_records(records, vectors, chemistry=[chemistry.features_for_record(r) for r in records])
        maps = mapper.score_records(pairs)
        maps = decorate_maps(maps, records, annotator, io, range(start, stop))
        columns.update(map_scalars(maps))
        commit_chunk(out, start, stop, identity, records, columns, maps)
        event = dict(stage='SCORING', completed=stop, total=len(library), chunk_seconds=round(time.monotonic()-began, 3),
                     run_identity=identity, seconds_remaining=round(deadline-time.monotonic()))
        write(out / 'progress.json', event); print(json.dumps(event), flush=True)
    if STOP or time.monotonic() > deadline - 180:
        write(out / 'PAUSED.json', dict(status='PAUSED', next_index=len(library), reason='All chunks saved; resume for final export'))
        return
    mapper.verify_sources_unchanged()
    supervised.verify_sources_unchanged()
    write(out / 'progress.json', dict(stage='FINAL_EXPORT', assemblies=len(library)))
    print(json.dumps(consolidate(out, library, identity, request, chemistry_names)), flush=True)
    print('RESULT_ZIP:', out / 'inspection.zip', flush=True)
    print('RESULT_SHA256:', sha(out / 'inspection.zip'), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--request', required=True, type=Path)
    parser.add_argument('--seconds', type=int, default=6600)
    args = parser.parse_args()
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGUSR1, request_stop)
    args.out.mkdir(parents=True, exist_ok=True)
    try:
        with (args.out / 'run.lock').open('a') as handle:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            run(args)
    except (ValueError, AssertionError) as exc:
        write(args.out / 'INTEGRITY_FAILURE.json', dict(error=str(exc), type=type(exc).__name__))
        raise


if __name__ == '__main__':
    main()
