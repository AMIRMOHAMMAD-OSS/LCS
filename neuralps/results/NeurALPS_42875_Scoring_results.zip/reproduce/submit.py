#!/usr/bin/env python3
"""Submit or resume one bounded allocation for the complete 42,875 score library.

This launcher reuses the verified embeddings and fitted checkpoints. It never
trains, extracts ESM embeddings, installs packages, or submits follow-up jobs.
Login-node preflight imports only the Python standard library.
"""
from __future__ import annotations

import argparse
from collections import deque
import fcntl
import json
from pathlib import Path
import subprocess
import time

from common import read, sha, validate, write


HERE = Path(__file__).resolve().parent
PREFIX = "neuralps_42875_score_"
SETTINGS = {"chunk_size": 64, "query_batch": 64, "batch_size": 32}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def command(root, out, request):
    return [
        "sbatch", "--parsable", "--job-name=nrps_42875_score",
        "--account=nef@a100", "--partition=gpu_p5", "--qos=qos_gpu_a100-t3",
        "--nodes=1", "--ntasks=1", "--cpus-per-task=8", "--hint=nomultithread",
        "--gres=gpu:1", "--constraint=a100", "--time=02:00:00",
        "--no-requeue", "--propagate=NONE", "--chdir=" + str(root),
        "--output=" + str(out / "slurm_%j.log"),
        "--error=" + str(out / "slurm_%j.log"), str(HERE / "batch.sh"),
        str(HERE), str(root), str(out), str(request),
    ]


def check_request(package, root, out, request):
    """Validate immutable request bytes, paths, settings and package identity."""
    package, root, out, request = (Path(p).resolve() for p in (package, root, out, request))
    require(out.parent == root and out.name.startswith(PREFIX), "Unexpected scoring output path")
    require(request == out / "REQUEST.json", "Unexpected request path")
    require(sha(request) == read_request_hash(out), "Request checksum differs")
    body = read(request)
    require(body.get("root") == str(root) and body.get("output") == str(out)
            and body.get("package") == str(package), "Request path identity differs")
    require(body.get("package_sha256") == sha(package / "PACKAGE_MANIFEST.json"),
            "Request package checksum differs")
    require(all(body.get(key) == value and type(body.get(key)) is int
                for key, value in SETTINGS.items()), "Request scoring settings differ")
    return body


def read_request_hash(out):
    value = (Path(out) / "REQUEST.sha256").read_text().strip()
    require(len(value) == 64 and all(c in "0123456789abcdef" for c in value),
            "Invalid request checksum record")
    return value


def check_failures(out):
    """Data/parity failures require review; scheduler/environment failures can resume."""
    for name in ("INTEGRITY_FAILURE.json", "fatal_error.json"):
        if (out / name).exists():
            raise RuntimeError("An integrity/parity failure was recorded: " + str(out / name)
                               + ". Inspect and resolve that failure before resuming.")


def status(info):
    job = str(info.get("job_id", ""))
    if job.isdigit():
        for cmd in (
            ["squeue", "-j", job, "-o", "%.18i %.12P %.20j %.12T %.10M %.30R"],
            ["sacct", "-j", job, "--format=JobID,State,ExitCode,Elapsed"],
        ):
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                print(result.stdout.strip() or result.stderr.strip(), flush=True)
            except (OSError, subprocess.TimeoutExpired) as exc:
                print("Scheduler status unavailable:", exc, flush=True)
    out = Path(info["output"])
    print("Submission:", info.get("status", "UNKNOWN"), flush=True)
    print("Output:", out, flush=True)
    for name in ("progress.json", "COMPLETE.json", "PAUSED.json", "INTEGRITY_FAILURE.json",
                 "BATCH_FAILURE.json"):
        path = out / name
        if path.is_file():
            print(name + ":", path.read_text(), flush=True)
    log = out / ("slurm_" + job + ".log")
    if job.isdigit() and log.is_file():
        with log.open(errors="replace") as stream:
            print("".join(deque(stream, maxlen=16)), flush=True)
    for name in ("inspection.zip", "failure_inspection.zip"):
        path = out / name
        if path.is_file():
            print("RESULT_ZIP:", path, flush=True)
            print("RESULT_SHA256:", sha(path), flush=True)


def resolve_resume(root, output, receipt):
    root = Path(root).resolve()
    info = read(receipt) if Path(receipt).is_file() else None
    if output is not None:
        out = Path(output).resolve()
        require(out.parent == root and out.name.startswith(PREFIX),
                "Resume output must be a scoring directory directly under project root")
        if info is None or info.get("output") != str(out):
            local = out / "SUBMISSION.json"
            require(local.is_file(), "No confirmed submission receipt in requested output")
            info = read(local)
    require(info is not None and str(info.get("job_id", "")).isdigit(),
            "No confirmed prior job. Inspect SUBMISSION.json and squeue before another submission.")
    out = Path(info["output"]).resolve()
    require(out.parent == root and out.name.startswith(PREFIX), "Resume receipt output is outside project root")
    require(info.get("root") == str(root), "Resume project root differs")
    require(info.get("package_sha256") == sha(HERE / "PACKAGE_MANIFEST.json"), "Resume package checksum differs")
    body = check_request(HERE, root, out, out / "REQUEST.json")
    require(body["package_sha256"] == info["package_sha256"], "Request and receipt package identities differ")
    check_failures(out)
    result = subprocess.run(
        ["squeue", "-h", "-j", str(info["job_id"]), "-o", "%i %T"],
        capture_output=True, text=True, timeout=30, check=True,
    )
    require(not result.stdout.strip(), "Previous allocation is still queued/running: " + result.stdout.strip())
    return info, out


def submit_once(root, out, request, receipt, old=None):
    """Record uncertainty before invoking sbatch; never retry an unconfirmed call."""
    cmd = command(root, out, request)
    history = list(old.get("previous_jobs", [])) + [str(old["job_id"])] if old else []
    info = dict(status="SUBMITTING", root=str(root), output=str(out),
                package_sha256=sha(HERE / "PACKAGE_MANIFEST.json"), command=cmd,
                previous_jobs=history)
    write(receipt, info)
    write(out / "SUBMISSION.json", info)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired) as exc:
        info.update(status="SUBMISSION_UNCERTAIN", error=str(exc))
        write(receipt, info)
        write(out / "SUBMISSION.json", info)
        raise RuntimeError("Submission outcome is uncertain; inspect squeue before another submission") from exc
    job = result.stdout.strip().split(";")[0]
    info.update(stdout=result.stdout.strip(), stderr=result.stderr.strip(), returncode=result.returncode)
    if result.returncode != 0 or not job.isdigit():
        info["status"] = "REJECTED_OR_UNCERTAIN"
        write(receipt, info)
        write(out / "SUBMISSION.json", info)
        raise RuntimeError("Slurm did not confirm a job:\n" + result.stdout + result.stderr)
    info.update(status="SUBMITTED", job_id=job)
    write(receipt, info)
    write(out / "SUBMISSION.json", info)
    return info


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=HERE.parent)
    parser.add_argument("action", choices=("preflight", "run", "resume", "status"))
    parser.add_argument("output", type=Path, nargs="?", help="Existing output for resume/status")
    args = parser.parse_args(argv)
    root = args.root.resolve()
    receipt = HERE / "SUBMISSION.json"
    if args.action == "status":
        source = args.output.resolve() / "SUBMISSION.json" if args.output else receipt
        require(source.is_file(), "No submission recorded yet")
        status(read(source))
        return
    if args.output and args.action != "resume":
        parser.error("An output directory is accepted only for resume/status")
    checked = validate(root, full=False)
    print("PREFLIGHT_OK: existing inputs, embeddings and fitted checkpoints; no login-node model work", flush=True)
    if args.action == "preflight":
        print(json.dumps(checked, indent=2, sort_keys=True), flush=True)
        return
    with (HERE / "submission.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        old = read(receipt) if receipt.exists() else None
        if args.action == "run" and old:
            print("Already submitted; no duplicate allocation created. Use status or resume.", flush=True)
            status(old)
            return
        if args.action == "resume":
            old, out = resolve_resume(root, args.output, receipt)
            if (out / "COMPLETE.json").is_file():
                print("Scoring already complete; no new allocation created.", flush=True)
                status(old)
                return
        else:
            stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
            out = root / (PREFIX + stamp + "_" + sha(HERE / "PACKAGE_MANIFEST.json")[:8])
            out.mkdir(exist_ok=False)
        request = out / "REQUEST.json"
        if not request.exists():
            write(request, dict(root=str(root), output=str(out), package=str(HERE),
                                package_sha256=sha(HERE / "PACKAGE_MANIFEST.json"),
                                preflight=checked, **SETTINGS))
            (out / "REQUEST.sha256").write_text(sha(request) + "\n")
        check_request(HERE, root, out, request)
        info = submit_once(root, out, request, receipt, old)
        print("SUBMITTED_JOB:", info["job_id"], flush=True)
        print("Resources: 1 A100, 8 CPUs, maximum 2 hours; existing embeddings and fitted models", flush=True)
        print("Output:", out, flush=True)
        print("Status: python3 -B", HERE / "submit.py", "status", flush=True)
        print("Resume an interrupted allocation: python3 -B", HERE / "submit.py", "resume", out, flush=True)


if __name__ == "__main__":
    main()
