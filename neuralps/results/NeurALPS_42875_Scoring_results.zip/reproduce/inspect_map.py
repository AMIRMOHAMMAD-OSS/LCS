#!/usr/bin/env python3
"""Print one full annotated compatibility map from a completed/scoring output."""
import argparse
import gzip
import json
from pathlib import Path
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--assembly', required=True, help='Example: BODE2_045-047-059')
    parser.add_argument('--save', type=Path, help='Optional new JSON destination')
    args = parser.parse_args()
    out = args.output.resolve()
    # Completed compact export supplies the canonical row index. During a run,
    # the sealed request's verified library supplies it instead.
    if (out/'compatibility_maps.npz').is_file():
        with np.load(out/'compatibility_maps.npz', allow_pickle=False) as values:
            ids = values['assembly_ids'].tolist()
    else:
        request = json.loads((out/'REQUEST.json').read_text())
        source = Path(request['root'])/'NeurALPS_42875_Inputs_20261103/data/model_indices.npz'
        with np.load(source, allow_pickle=False) as values:
            ids = values['assembly_ids'].tolist()
    if args.assembly not in ids:
        raise ValueError('Assembly is outside the 35-cubed library')
    i = ids.index(args.assembly)
    request = json.loads((out/'REQUEST.json').read_text())
    step = request['chunk_size']; start = i//step*step; stop = min(len(ids),start+step)
    source = out/'chunks'/f'{start:05d}_{stop:05d}.jsonl.gz'
    if not source.is_file():
        source = out/'full_maps.jsonl.gz'
    if not source.is_file():
        raise FileNotFoundError('Verbose map is not available here. Run this command in the Jean Zay output directory; the inspection archive contains compact numeric maps.')
    with gzip.open(source,'rt') as handle:
        for line in handle:
            item = json.loads(line)
            if item['assembly_id'] == args.assembly:
                text = json.dumps(item,indent=2,sort_keys=True,allow_nan=False)+'\n'
                if args.save:
                    with args.save.open('x') as dest: dest.write(text)
                else:
                    print(text,end='')
                return
    raise ValueError('Assembly map has not been committed in this output')


if __name__ == '__main__': main()
