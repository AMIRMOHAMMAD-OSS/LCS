"""Controller integration tests with real inputs/bank and mocked model scores.

The synthetic values below are deliberately not predictions. Real reconstructed
routes, physical masks, source-boundary decorations, and the encoded bank are
used to exercise exports and resume integrity without model checkpoints.
"""
from __future__ import annotations

import copy
import csv
import gzip
import json
import os
from pathlib import Path
import tempfile
import types
import unittest
from unittest import mock
from collections import Counter
from contextlib import ExitStack

import numpy as np

import chemistry
from boundary_metadata import BoundaryAnnotations
import run_scoring as controller
from common import IntegrityError, read, write
from maps.scorer import result_shell, finish_result
from maps.vendor_map.neuralps.scoring import make_plan, slots_by_object


def test_asset(environment, project_relative, local_fallback):
    if environment in os.environ:
        return Path(os.environ[environment])
    project_asset = Path(__file__).resolve().parent.parent / project_relative
    return project_asset if project_asset.is_dir() else Path(local_fallback)


INPUT_PACKAGE = test_asset("NEURALPS_TEST_INPUT_PACKAGE", controller.INPUT_NAME,
    "/workspace/scratch/80ee4284b71d/output/NeurALPS_42875_Inputs_20261103")
ENCODING_OUTPUT = test_asset("NEURALPS_TEST_ENCODING_OUTPUT", controller.ENCODING_NAME,
    "/workspace/scratch/8733060e8b20/encoding_review_20261104/extracted")


def mock_maps(pairs):
    results = []
    for record, parents in pairs:
        result = result_shell(record, slots_by_object(record))
        for obj in result["objects"]:
            j = obj["object_index"]
            plan = make_plan(record, [j], parents)
            if plan["status"] == "READY":
                obj.update(status="SCORED", scores={"full": 0.3 + j / 100},
                           rawcos={"full": 0.2 + j / 100},
                           mask=dict(plan, status="SCORED"))
            else:
                obj.update(status=plan["status"], mask=plan)
        results.append(finish_result(result))
    return results


class ControllerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not INPUT_PACKAGE.is_dir() or not ENCODING_OUTPUT.is_dir():
            raise unittest.SkipTest("Set NEURALPS_TEST_INPUT_PACKAGE and NEURALPS_TEST_ENCODING_OUTPUT")
        cls.context = tempfile.TemporaryDirectory(prefix="neuralps_controller_")
        cls.root = Path(cls.context.name)
        (cls.root / controller.INPUT_NAME).symlink_to(INPUT_PACKAGE, target_is_directory=True)
        (cls.root / controller.ENCODING_NAME).symlink_to(ENCODING_OUTPUT, target_is_directory=True)
        cls.io, cls.library, cls.matrix, cls.vectors = controller.load_library(cls.root)
        with gzip.open(INPUT_PACKAGE / "data/candidate_inventory.csv.gz", "rt") as handle:
            inventory = list(csv.DictReader(handle))
        cls.representatives = [next(int(r["index"]) for r in inventory if int(r["n_chains"]) == n)
                               for n in (1, 2, 3, 4)]
        cls.pairs = controller.reconstruct_chunk(cls.io, cls.library, cls.representatives)
        cls.records = [r for r, _ in cls.pairs]
        cls.annotator = BoundaryAnnotations(INPUT_PACKAGE)
        cls.maps = controller.decorate_maps(mock_maps(cls.pairs), cls.records, cls.annotator,
                                            cls.io, cls.representatives)
        cls.chemistry_names = sorted({key for row in
            read(Path(chemistry.__file__).parent / "chemistry_reference_fixtures.json")["single105"]
            for key in row["features"]})

    @classmethod
    def tearDownClass(cls):
        if hasattr(cls, "context"):
            cls.context.cleanup()

    def test_real_bank_reconstruction_and_source_decorations(self):
        self.assertEqual(self.matrix.shape, (2602, 1152))
        self.assertEqual([len(r["parent_sequence_hashes"]) for r in self.records], [1, 2, 3, 4])
        compact = self.library.numpy_batch(self.representatives, self.matrix)
        direct = self.io.compact_records(self.records, self.library.sequence_hashes)
        for key in ("state", "kind", "domain_type", "chain", "valid"):
            self.assertTrue(np.array_equal(compact[key], direct[key]), key)
        for index, record, result in zip(self.representatives, self.records, self.maps):
            self.assertEqual(result["library_index"], index)
            self.assertEqual(result["assembly_id"], record["assembly_id"])
            self.assertEqual(result["model_signature"], self.io.model_signature(record))
            self.assertEqual(len(result["objects"]), len(record["route"]))
            self.assertEqual(chemistry.features_for_record(record), chemistry.expected_features(record["donors"]))
            for obj, route in zip(result["objects"], record["route"]):
                self.assertEqual(obj["kind"], route["kind"])
                if obj["kind"]:
                    self.assertIn(obj["annotation"]["annotation"], ("B", "J", "UNKNOWN"))
                self.assertIn("hidden", obj["mask"])

    def test_map_cardinality_and_identity_cannot_be_silently_zipped(self):
        with self.assertRaises((IntegrityError, ValueError)):
            controller.decorate_maps(copy.deepcopy(self.maps[:-1]), self.records, self.annotator,
                                     self.io, self.representatives)
        wrong = copy.deepcopy(self.maps)
        wrong[0]["assembly_id"] = "BODE2_wrong"
        with self.assertRaises((IntegrityError, ValueError)):
            controller.decorate_maps(wrong, self.records, self.annotator, self.io, self.representatives)

    def test_resume_seal_accepts_identical_and_rejects_changed_or_corrupted(self):
        maps = copy.deepcopy(self.maps[:2]); records = self.records[:2]
        for i, item in enumerate(maps):
            item["library_index"] = i
        columns = dict(mock__probability=np.array([0.25, 0.75]), **controller.map_scalars(maps))
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory)
            self.assertIsNone(controller.validate_chunk(out, 0, 2, "identity", [r["assembly_id"] for r in records]))
            controller.commit_chunk(out, 0, 2, "identity", records, columns, maps)
            seal = controller.validate_chunk(out, 0, 2, "identity", [r["assembly_id"] for r in records])
            self.assertEqual(seal["map_objects"], sum(len(r["route"]) for r in records))
            with self.assertRaises(IntegrityError):
                controller.validate_chunk(out, 0, 2, "changed", [r["assembly_id"] for r in records])
            with self.assertRaises(IntegrityError):
                controller.validate_chunk(out, 0, 2, "identity", list(reversed(seal["assembly_ids"])))
            path = out / "chunks/00000_00002.npz"
            with path.open("ab") as handle:
                handle.write(b"corrupted")
            with self.assertRaises(IntegrityError):
                controller.validate_chunk(out, 0, 2, "identity", seal["assembly_ids"])

    def test_missing_map_scalar_is_nan_and_unranked_not_zero(self):
        maps = copy.deepcopy(self.maps[:2])
        maps[0]["objects"][0].update(status="INSUFFICIENT_VISIBLE_CONTEXT", scores={}, rawcos={})
        finish_result(maps[0])
        columns = controller.map_scalars(maps)
        self.assertEqual(columns["map_complete"].tolist(), [0, 1])
        self.assertTrue(np.isnan(columns["unsupervised__balanced_mean"][0]))
        self.assertTrue(np.isnan(columns["rawcos_diagnostic__balanced_mean"][0]))
        self.assertTrue(np.isfinite(columns["unsupervised__balanced_mean"][1]))
        ranks = controller.rank_descending(columns["unsupervised__balanced_mean"], columns["map_complete"].astype(bool))
        self.assertEqual(ranks.tolist(), [0, 1])
        for i, item in enumerate(maps):
            item["library_index"] = i
        with tempfile.TemporaryDirectory() as directory:
            columns["mock__probability"] = np.array([0.4, 0.6])
            controller.commit_chunk(Path(directory), 0, 2, "identity", self.records[:2], columns, maps)
            columns["mock__probability"][0] = np.nan
            with self.assertRaises(IntegrityError):
                controller.commit_chunk(Path(directory), 0, 2, "identity", self.records[:2], columns, maps)

    def test_rank_ties_use_competition_ranks_and_mask_missing(self):
        result = controller.rank_descending([.9, .8, .9, .1, np.nan], [1, 1, 1, 1, 0])
        self.assertEqual(result.tolist(), [1, 3, 1, 4, 0])

    def _fixture_library(self):
        class SmallLibrary:
            def __len__(self):
                return len(self.arrays["assembly_ids"])
        library = SmallLibrary()
        library.arrays = self.io.compact_records(self.records, self.library.sequence_hashes)
        library.arrays['sequence_hashes'] = self.library.sequence_hashes
        library.inventory = [self.library.inventory[i] for i in self.representatives]
        return library

    def _write_fixture_chunks(self, out, *, incomplete_first=False):
        maps = copy.deepcopy(self.maps)
        for i, item in enumerate(maps):
            item["library_index"] = i
        if incomplete_first:
            maps[0]["objects"][0].update(status="INSUFFICIENT_VISIBLE_CONTEXT", scores={}, rawcos={})
            finish_result(maps[0])
        for start in (0, 2):
            columns = dict(mock__probability=np.array([.4, .8, .8, .1])[start:start+2],
                           **controller.map_scalars(maps[start:start+2]))
            controller.commit_chunk(out, start, start+2, "fixture", self.records[start:start+2],
                                    columns, maps[start:start+2])
        for name in ("REQUEST.json", "NUMERICAL_GATES.json", "RUN_IDENTITY.json",
                     "SUPERVISED_METADATA.json", "MAP_CONTRACT.json"):
            write(out / name, {"mocked_for_controller_test": True})
        (out / 'REQUEST.sha256').write_text(controller.sha(out / 'REQUEST.json') + '\n')
        return maps

    def _small_scope(self, stack, maps, package):
        counts = dict.fromkeys(("B", "J", "UNKNOWN"), 0)
        for item in maps:
            for obj in item["objects"]:
                if obj["kind"]:
                    counts[obj["annotation"]["annotation"]] += 1
        stack.enter_context(mock.patch.multiple(controller,
            EXPECTED_CANDIDATES=4,
            EXPECTED_OBJECTS=sum(len(r["route"]) for r in self.records),
            EXPECTED_BOUNDARY_COUNTS=counts,
            HERE=package))
        stack.enter_context(mock.patch.object(controller, "known27_pairs", return_value=[self.pairs[0]]))

    def test_mandatory_full_scope_guard_rejects_small_library(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(IntegrityError, "Incomplete full-library candidate scope"):
                controller.consolidate(Path(directory), self._fixture_library(), "fixture",
                    {"root": str(self.root), "chunk_size": 2}, self.chemistry_names)

    def test_tiny_export_chemistry_rank_missing_map_and_exact_mask_bits(self):
        with tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
            out = Path(directory)
            maps = self._write_fixture_chunks(out, incomplete_first=True)
            # Constants are changed only inside this test. The production scope
            # guard above independently rejects any smaller library.
            package = out / "mock_package"; package.mkdir()
            (package / "README.txt").write_text("Mocked model outputs for controller test only.\n")
            self._small_scope(stack, maps, package)
            summary = controller.consolidate(out, self._fixture_library(), "fixture",
                {"root": str(self.root), "chunk_size": 2}, self.chemistry_names)
            self.assertEqual(summary["assemblies"], 4)
            self.assertEqual(summary["physical_map_objects"], sum(len(r["route"]) for r in self.records))
            self.assertEqual(summary["complete_assembly_maps"], 3)
            with gzip.open(out / "full_maps.jsonl.gz", "rt") as handle:
                exported_maps = [json.loads(line) for line in handle]
            self.assertEqual([r["assembly_id"] for r in exported_maps], [r["assembly_id"] for r in self.records])
            with np.load(out / "scores.npz", allow_pickle=False) as data:
                self.assertTrue(np.isnan(data["unsupervised__balanced_mean"][0]))
                self.assertEqual(data["mock__probability__rank"].tolist(), [3, 1, 1, 4])
                self.assertEqual(data["unsupervised__balanced_mean__rank"][0], 0)
            with np.load(out / "compatibility_maps.npz", allow_pickle=False) as data:
                for i, item in enumerate(maps):
                    count = len(item["objects"])
                    self.assertTrue(data["present"][i, :count].all())
                    self.assertFalse(data["present"][i, count:].any())
                    self.assertTrue(np.isnan(data["mixed_score"][i, count:]).all())
                    for j, obj in enumerate(item["objects"]):
                        bits = data["hidden_slot_bits"][i, j]
                        actual = {(target, role) for target in range(count) for role in range(3)
                                  if int(bits[(target*3+role)//64]) & (1 << ((target*3+role) % 64))}
                        self.assertEqual(actual, {tuple(slot) for slot in obj["mask"]["hidden"]})
                        if obj["status"] == "SCORED":
                            self.assertEqual(data["mixed_score"][i, j], obj["scores"]["full"])
                        else:
                            self.assertFalse(data["scored"][i, j])
                            self.assertTrue(np.isnan(data["mixed_score"][i, j]))
            with (out / "scores.csv").open() as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 4)
            for row, record in zip(rows, self.records):
                expected = chemistry.expected_amino_acids(record["donors"])
                self.assertEqual(row["expected_peptide_aa"], ">".join(expected))
                cov = chemistry.coverage(chemistry.features_for_record(record), self.chemistry_names)
                self.assertEqual(int(row["chemistry_unseen_pair_count"]), cov["unseen_pair_count"])
                self.assertEqual(row["chemistry_unseen_terms"], ";".join(cov["unseen_features"]))
            self.assertEqual(rows[0]["unsupervised__balanced_mean"], "")
            self.assertEqual(rows[0]["unsupervised__balanced_mean__rank"], "")
            self.assertEqual([r["known_27_triple"] for r in rows], ["1", "0", "0", "0"])
            self.assertTrue((out / "inspection.zip").is_file())
            self.assertEqual(read(out / "COMPLETE.json")["training_performed"], False)

    def test_export_rejects_resealed_duplicate_map_rows_and_invalid_mask(self):
        for defect in ("duplicate", "invalid_hidden_slot"):
            with self.subTest(defect=defect), tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
                out = Path(directory)
                maps = self._write_fixture_chunks(out)
                base = out / "chunks/00000_00002"
                changed = copy.deepcopy(maps[:2])
                if defect == "duplicate":
                    changed[1] = copy.deepcopy(changed[0])
                else:
                    changed[0]["objects"][0]["mask"]["hidden"].append([len(changed[0]["objects"]), 0])
                with gzip.open(base.with_suffix(".jsonl.gz"), "wt") as handle:
                    for item in changed:
                        handle.write(json.dumps(item) + "\n")
                seal = read(base.with_suffix(".seal.json"))
                seal["files"][base.with_suffix(".jsonl.gz").name] = controller.sha(base.with_suffix(".jsonl.gz"))
                write(base.with_suffix(".seal.json"), seal)
                package = out / "mock_package"; package.mkdir()
                self._small_scope(stack, maps, package)
                with self.assertRaises(IntegrityError):
                    controller.consolidate(out, self._fixture_library(), "fixture",
                        {"root": str(self.root), "chunk_size": 2}, self.chemistry_names)


if __name__ == "__main__":
    unittest.main()
