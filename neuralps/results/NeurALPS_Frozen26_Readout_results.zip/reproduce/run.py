#!/usr/bin/env python3
"""Compute-only frozen-encoder evaluation; no optimizer touches the encoder."""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

PACKAGE = Path(__file__).resolve().parent


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def dump(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
    tmp.replace(path)


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


class Paused(Exception):
    pass


def run(args):
    import submit
    out, root = args.out.resolve(), args.root.resolve()
    require(os.environ.get('SLURM_JOB_ID', '').isdigit(), 'Use submit.py inside a Slurm allocation')
    require(out.parent == root and out.name.startswith(submit.PREFIX), 'Unexpected output directory')
    descriptor = os.environ.get('NEURALPS_RUN_LOCK_FD', '')
    require(descriptor.isdigit(), 'Launch through submit.py worker to hold the output lock')
    descriptor = int(descriptor)
    actual, expected = os.fstat(descriptor), (out / 'run.lock').stat()
    require((actual.st_dev, actual.st_ino) == (expected.st_dev, expected.st_ino),
            'Inherited worker lock does not belong to this output')
    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
    digest = submit.package_digest()
    request = submit.read_request(root, out, digest)
    protocol = json.loads((PACKAGE / 'protocol.json').read_text())
    require(sha(PACKAGE / 'protocol.json') == request['protocol_sha256'], 'Protocol changed after submission')

    def emit(stage, **data):
        event = dict(stage=stage, **data)
        line = json.dumps(event, allow_nan=False)
        print(line, flush=True)
        with (out / 'progress.jsonl').open('a') as f:
            f.write(line + '\n')

    def interrupted(signum, frame):
        raise Paused(f'Allocation received signal {signum}; completed stages are reusable')

    for sig in (signal.SIGTERM, signal.SIGUSR1, signal.SIGINT):
        signal.signal(sig, interrupted)
    started = time.monotonic()
    try:
        emit('VERIFYING_PINNED_INPUTS', encoder_step=26000, encoder_updates=0)
        current = submit.check_inputs(root, verify_hashes=True)
        require(current == request['inputs'], 'Inputs changed after submission')
        import numpy as np
        import torch
        import sklearn
        require(torch.__version__.split('+')[0] == '2.8.0', 'Use pytorch-gpu/py3/2.8.0')
        require(torch.cuda.is_available() and torch.cuda.device_count() == 1, 'Allocate exactly one CUDA GPU')
        torch.set_num_threads(8)
        torch.manual_seed(protocol['seed'])
        np.random.seed(protocol['seed'])
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.use_deterministic_algorithms(True)
        identity = dict(schema=protocol['schema'], package_manifest_sha256=digest,
                        request_sha256=sha(out / 'REQUEST.json'), protocol_sha256=sha(PACKAGE / 'protocol.json'),
                        checkpoint_sha256=request['checkpoint_sha256'])
        run_config = dict(identity=identity, protocol=protocol,
                          runtime={'python':sys.version, 'numpy':np.__version__, 'torch':torch.__version__,
                                   'sklearn':sklearn.__version__, 'gpu':torch.cuda.get_device_name(0)},
                          encoder_training=False, classifier_training=True, embedding_extraction=False)
        old_config = out / 'run_config.json'
        if old_config.exists():
            require(json.loads(old_config.read_text())['identity'] == identity, 'Existing run identity differs')
        else:
            dump(old_config, run_config)

        def valid_stage(name):
            marker = out / name
            if not marker.exists():
                return False
            saved = json.loads(marker.read_text())
            require(saved['identity'] == identity, f'{name}: identity differs')
            for rel, expected in saved['files'].items():
                path = (out / rel).resolve()
                require(path.is_relative_to(out) and path.is_file() and sha(path) == expected,
                        f'{name}: completed output changed or missing: {rel}')
            return True

        def save_stage(name, paths):
            dump(out / name, dict(identity=identity, files={str(p.relative_to(out)):sha(p) for p in paths}))

        if not valid_stage('FEATURE_STAGE.json'):
            emit('EXTRACTING_FROZEN26_FEATURES', attention='original local radius6 plus original global blocks')
            from frozen_features import extract
            from labelled_backend import PINNED_INPUTS
            extract(root, out, device='cuda', threads=8, verified_hashes=dict(PINNED_INPUTS))
            paths = [out / n for n in ('features.npz', 'features.json', 'rows.json', 'maps.jsonl.gz')]
            require(all(p.is_file() for p in paths), 'Feature extraction did not commit its three outputs')
            save_stage('FEATURE_STAGE.json', paths)
            emit('FROZEN26_FEATURE_CACHE_COMPLETE')
        else:
            emit('REUSING_VERIFIED_FEATURE_CACHE')

        if not valid_stage('FIT_STAGE.json'):
            emit('FITTING_REGULARIZED_READOUTS', primary_panel=protocol['primary_panel'],
                 C_grid=protocol['C_grid'], inner_folds=protocol['inner_folds'])
            from fit_readout import fit
            fit(out, protocol, PACKAGE)
            paths = [out / n for n in ('readout_selection.json', 'activity_holdout.json',
                                       'inner_splits.json', 'inner_predictions.json',
                                       'inner_predictions.csv', 'readout_summary.json')]
            require(all(p.is_file() for p in paths), 'Readout fitting did not commit its required outputs')
            paths.extend(sorted(p for p in (out / 'models').rglob('*') if p.is_file()) if (out / 'models').exists() else [])
            save_stage('FIT_STAGE.json', paths)
        else:
            emit('REUSING_VERIFIED_READOUT_RESULTS')
        dump(out / 'COMPLETE.json', dict(status='FROZEN26_READOUT_COMPLETE', **identity,
             checkpoint_step=26000, encoder_updates=0, classifier_training=True, embedding_extraction=False,
             primary_panel=protocol['primary_panel'], expected_counts=protocol['expected_counts'],
             heldout='activity_holdout.json', selection='readout_selection.json',
             calibrated=False, prospective_validation=False,
             elapsed_seconds=round(time.monotonic()-started,2),
             completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())))
        for name in ('pause.json', 'fatal_error.json'):
            (out / name).unlink(missing_ok=True)
        emit('FROZEN26_READOUT_COMPLETE', encoder_updates=0, primary_panel=protocol['primary_panel'])
        from export_review import export
        archive, checksum = export(out, PACKAGE)
        print('RESULT_ZIP:', archive, flush=True)
        print('RESULT_SHA256:', checksum, flush=True)
        return 0
    except Paused as exc:
        dump(out / 'pause.json', dict(status='PAUSED', reason=str(exc),
                                     resume='submit.py resume ' + str(out)))
        emit('PAUSED', reason=str(exc))
        return 75
    except Exception as exc:
        dump(out / 'fatal_error.json', dict(status='FAILED', error=str(exc), traceback=traceback.format_exc()))
        raise


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    return run(p.parse_args())


if __name__ == '__main__':
    sys.exit(main())
