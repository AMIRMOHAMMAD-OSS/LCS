#!/usr/bin/env bash
set -euo pipefail

nrps_package="${1:?package directory}"
nrps_root="${2:?project root}"
nrps_out="${3:?continuation output directory}"
: "${SLURM_JOB_ID:?Submit through submit.py}"

module purge
module load arch/a100
module load pytorch-gpu/py3/2.8.0
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1

exec srun --ntasks=1 python3 -B "$nrps_package/submit.py" --root "$nrps_root" worker "$nrps_out"
