"""Read-only labelled structure loader adapted from Patrick neural_backend.py.

Source snapshot is the Patrick 20261103 multi-exchange result archive.
The legacy supervised fitting and checkpoint methods are intentionally omitted.
"""
from __future__ import annotations

from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path
import sqlite3

import numpy as np

PACKAGE = Path(__file__).resolve().parent
FEATURE_SHAPE = (548713, 1152)
MAIN_DB = "e0_training_prep_461027/training_data.sqlite3"
MAIN_CACHE = "e0_cache_final_491894"
TD_RUN = "e10_tdomain_embed_696333"
TD_RECORDS = "e11_tdomain_transfer_699466/scores/records.json.gz"
PINNED_INPUTS = {
    MAIN_DB: "6c273f05a6bcde4fec6fc57a26d0a35a9461f9831656248bee3ca21de1c14287",
    MAIN_CACHE + "/features.f32": "5a7c2f3afd527785ce3c12eaa3b97138034f4dfc811d840b5b44cf1534b9ef90",
    MAIN_CACHE + "/feature_index.sqlite3": "09a6bde676c2e22bcba78879cf53c1d1979d672bcc1763a9eb49e218f387735b",
    TD_RUN + "/feature_index.sqlite3": "41d81778fc2d2c015cbe28d429ed2bccc7ea8940142106a02ef98eceeac06bfe",
    TD_RUN + "/features.f32": "1134819306754396634ee0f1c00a0bfffb2cb15cd4a20daca08b22243f1ee77d",
    TD_RUN + "/inputs/parents.fasta.gz": "15f9181a74d4bb42325bfa2af5900dcd6a2a967a0d6be1c6428b1187f34a08c9",
    TD_RECORDS: "fa79f3e0f8618f004bb6b157dae9235ff9580bf4bc3a0a49c2d2b167e570e2d0",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def _torch():
    import torch
    return torch


def _readonly(path):
    db = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)
    db.execute("PRAGMA query_only=ON")
    return db


def _fasta(path):
    result, name = {}, None
    with gzip.open(path, "rt", encoding="ascii") as stream:
        for line in stream:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                name = line[1:]
                require(name not in result, "Duplicate parent FASTA identity")
                result[name] = ""
            else:
                require(name is not None, "Sequence before FASTA header")
                result[name] += line
    for h, sequence in result.items():
        require(sequence and set(sequence) <= set("ACDEFGHIKLMNPQRSTVWY") and
                hashlib.sha256(sequence.encode()).hexdigest() == h,
                "Parent FASTA sequence/hash mismatch")
    return result


def clean_record(source, dataset):
    fields = ("assembly_id", "route", "model_slots", "parent_sequence_hashes",
              "parent_lengths", "boundary_window_policy")
    rec = {key: source[key] for key in fields if key in source}
    require(all(k in rec for k in fields[:4]), "Incomplete physical route record")
    require(rec.get("boundary_window_policy") == "physical_end_extradomain_tail64_v1",
            "Physical connection-window policy differs")
    rec["dataset"] = dataset
    return rec


def _route_fingerprint(record):
    """Label/ID-free exact model input signature; no claim of homology purging."""
    tokens = [(o["kind"], o["domain_type"] if o["kind"] == 0 else 0,
               o["chain"] if o["kind"] != 2 else -1) for o in record["route"]]
    slots = sorted((s["object_index"], s["slot"], s["state"],
                    s["sequence_hash"] if s["state"] == "OBSERVED" else None)
                   for s in record["model_slots"])
    return digest(dict(tokens=tokens, slots=slots))


def source_overlap_audit(records, rows, native_record):
    """Exclude auxiliary rows sharing held-donor primary domain hashes.

    Primary regional object indices are copied from the sealed E12 query, not
    inferred from scaffold overlap. Exact route duplicates are also excluded.
    This is deliberately conservative exact-sequence exclusion, not homology CV.
    """
    targets = json.loads((PACKAGE / "vendor_neural/bode2_target_objects.json").read_text())
    aux = [i for i, r in enumerate(rows) if r["dataset"] != "bode2"]
    domains = [{s["sequence_hash"] for s in rec["model_slots"]
                if s["state"] == "OBSERVED" and rec["route"][s["object_index"]]["kind"] == 0}
               for rec in records]
    exact = [_route_fingerprint(rec) for rec in records]
    native_domain_hashes = {s["sequence_hash"] for s in native_record["model_slots"]
                            if s["state"] == "OBSERVED" and
                            native_record["route"][s["object_index"]]["kind"] == 0}
    require(native_domain_hashes, "No verified native recipient domain hashes")
    grouped = {}
    for i, row in enumerate(rows):
        if row["dataset"] != "bode2":
            continue
        aid, group = row["assembly_id"], row["group"]
        require(isinstance(group, str), "BODE2 donor group must be a string")
        require(aid in targets["targets"], "Missing verified BODE2 regional targets")
        primary = targets["targets"][aid]
        require(primary and all(type(j) is int and 0 <= j < len(records[i]["route"]) for j in primary),
                "Invalid verified regional object indices")
        ds = {j for j in primary if records[i]["route"][j]["kind"] == 0}
        hh = {s["sequence_hash"] for s in records[i]["model_slots"]
              if s["state"] == "OBSERVED" and s["object_index"] in ds}
        require(ds and len(hh) >= 2, "No verified multi-domain donor region")
        entry = grouped.setdefault(group, dict(indices=[], target_domain_hashes=set(), exact_routes=set()))
        entry["indices"].append(i)
        entry["target_domain_hashes"].update(hh)
        entry["exact_routes"].add(exact[i])
    require(len(grouped) == 35 and all(len(v["indices"]) == 3 for v in grouped.values()),
            "Expected 35 complete BODE2 donor triplets")
    exclusions, detail = {}, {}
    for group, entry in sorted(grouped.items()):
        donor_specific = entry["target_domain_hashes"] - native_domain_hashes
        domain_hits = [i for i in aux if domains[i] & donor_specific]
        route_hits = [i for i in aux if exact[i] in entry["exact_routes"]]
        exclusions[group] = sorted(set(domain_hits + route_hits))
        detail[group] = dict(target_rows=entry["indices"],
                             primary_domain_hashes=sorted(entry["target_domain_hashes"]),
                             native_recipient_identical_domain_hashes=sorted(entry["target_domain_hashes"] & native_domain_hashes),
                             donor_specific_primary_domain_hashes=sorted(donor_specific),
                             novel_domain_sequence_claim_supported=bool(donor_specific),
                             auxiliary_domain_hash_hits=domain_hits, exact_route_duplicates=route_hits,
                             excluded_counts_by_dataset=dict(Counter(rows[i]["dataset"] for i in exclusions[group])))
    return dict(schema="exact_primary_donor_domain_exclusion_v1", auxiliary_exclusions=exclusions,
                groups=detail, target_source=targets["source"], target_source_sha256=targets["source_sha256"],
                biological_homology_purged=False,
                native_recipient_identity=native_record["assembly_id"],
                limitations="Exact donor-specific primary-domain and whole-input exclusion only; native recipient domains removed before auxiliary purge; no sequence-identity clustering")


class NeuralRuntime:
    """Read-only pinned assets, label-free records, and batches in metadata order."""
    def __init__(self, root, rows, device="cuda", threads=8, verified_hashes=None):
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        torch = _torch()
        from vendor_neural.assembly_model import collate_records
        self.root = Path(root).resolve()
        self.rows = [{k: r[k] for k in ("index", "dataset", "assembly_id", "group") if k in r} for r in rows]
        self.device = str(device)
        require(len(self.rows) == 494 and len({(r["dataset"], r["assembly_id"]) for r in rows}) == 494,
                "Expected exact 494-row primary cohort")
        require(dict(Counter(r["dataset"] for r in rows)) == {"bode1": 324, "bode2": 105, "tdomain": 65},
                "Wrong primary cohort counts")
        require(all(r.get("index", i) == i for i, r in enumerate(rows)), "Metadata indices must be ordered")
        if self.device.startswith("cuda"):
            require(torch.cuda.is_available(), "CUDA unavailable; run in the GPU allocation")
        torch.set_num_threads(threads)
        verified_hashes = verified_hashes or {}
        source_proof = {}
        for relative, expected in sorted(PINNED_INPUTS.items()):
            path = self.root / relative
            require(path.is_file(), "Required pinned input absent: " + relative)
            if path.suffix == ".sqlite3":
                require(not Path(str(path) + "-wal").exists(), "Unexpected WAL on pinned source: " + relative)
            before = path.stat()
            actual = verified_hashes.get(relative) or verified_hashes.get(str(path.resolve())) or sha(path)
            after = path.stat()
            require((before.st_size, before.st_mtime_ns, before.st_ino) ==
                    (after.st_size, after.st_mtime_ns, after.st_ino), "Source changed during verification")
            require(actual == expected, "Pinned source hash changed: " + relative)
            source_proof[relative] = dict(sha256=actual, bytes=after.st_size)
        require((self.root / MAIN_CACHE / "features.f32").stat().st_size == np.prod(FEATURE_SHAPE) * 4,
                "Main feature matrix byte count differs")
        db = _readonly(self.root / MAIN_DB)
        reviewed_bode2 = {r["assembly_id"] for r in rows if r["dataset"] == "bode2"}
        extra_bode2 = [json.loads(payload) for aid, payload in db.execute(
            "SELECT assembly_id,payload FROM assemblies WHERE dataset='bode2'") if aid not in reviewed_bode2]
        require(len(extra_bode2) == 1, "Expected the single excluded BODE2 native control")
        self.native_record = clean_record(extra_bode2[0], "bode2")
        index = _readonly(self.root / MAIN_CACHE / "feature_index.sqlite3")
        main_z = np.memmap(self.root / MAIN_CACHE / "features.f32", dtype="<f4", mode="r", shape=FEATURE_SHAPE)
        td_index = _readonly(self.root / TD_RUN / "feature_index.sqlite3")
        td_entries = list(td_index.execute("SELECT hash,feature_row,status FROM features ORDER BY feature_row"))
        require(len(td_entries) == 290 and all(row == i and status == "covered"
                for i, (_, row, status) in enumerate(td_entries)), "Invalid sealed T-domain cache index")
        td_rows = {h: i for h, i, _ in td_entries}
        td_z = np.memmap(self.root / TD_RUN / "features.f32", dtype="<f4", mode="r", shape=(len(td_rows), 1152))
        td_parents = _fasta(self.root / TD_RUN / "inputs/parents.fasta.gz")
        with gzip.open(self.root / TD_RECORDS, "rt") as stream:
            td_records = json.load(stream)
        if isinstance(td_records, dict) and "records" in td_records:
            td_records = td_records["records"]
        if isinstance(td_records, list):
            td_records = {r["assembly_id"]: r for r in td_records}
        require(isinstance(td_records, dict) and len(td_records) == 88, "Expected 88 sealed T-domain input routes")
        self.records, self.parents, self.vectors = [], {}, {}
        try:
            for row in rows:
                dataset, aid = row["dataset"], row["assembly_id"]
                if dataset == "tdomain":
                    require(aid in td_records, "Reviewed T-domain construct not in sealed input")
                    source = td_records[aid]
                else:
                    found = db.execute("SELECT payload FROM assemblies WHERE dataset=? AND assembly_id=?", (dataset, aid)).fetchall()
                    require(len(found) == 1, "Missing/duplicate structural record: " + aid)
                    source = json.loads(found[0][0])
                require(source["assembly_id"] == aid, "Structural identity differs")
                record = clean_record(source, dataset)
                parent_by_hash = {}
                for ph in set(record["parent_sequence_hashes"].values()):
                    if dataset == "tdomain":
                        require(ph in td_parents, "Missing T-domain parent sequence")
                        sequence = td_parents[ph]
                    else:
                        match = db.execute("SELECT sequence FROM proteins WHERE hash=?", (ph,)).fetchall()
                        require(len(match) == 1, "Missing/duplicated parent sequence")
                        sequence = match[0][0]
                    require(hashlib.sha256(sequence.encode()).hexdigest() == ph, "Parent sequence hash differs")
                    parent_by_hash[ph] = sequence
                    self.parents[ph] = sequence
                vectors = {}
                for slot in record["model_slots"]:
                    j, k = slot["object_index"], slot["slot"]
                    require(0 <= j < len(record["route"]) and k in (0, 1, 2), "Invalid slot index")
                    require(slot["kind"] == record["route"][j]["kind"], "Slot/route kind differs")
                    parent = parent_by_hash[slot["parent_sequence_hash"]]
                    require(0 <= slot["start"] <= slot["end"] <= len(parent), "Invalid slot interval")
                    sequence = parent[slot["start"]:slot["end"]]
                    require(len(sequence) == slot["length"], "Slot length differs")
                    if slot["state"] != "OBSERVED":
                        continue
                    h = slot["sequence_hash"]
                    require(hashlib.sha256(sequence.encode()).hexdigest() == h, "Observed slot hash differs")
                    if dataset == "tdomain":
                        require(h in td_rows, "T-domain input absent from its sealed sidecar")
                        vector = np.array(td_z[td_rows[h]], copy=True)
                    else:
                        match = index.execute("SELECT feature_row FROM features WHERE hash=? AND status='covered'", (h,)).fetchall()
                        require(len(match) == 1 and 0 <= match[0][0] < FEATURE_SHAPE[0], "Observed main feature missing")
                        vector = np.array(main_z[match[0][0]], copy=True)
                    require(np.isfinite(vector).all() and np.linalg.norm(vector) > 0, "Invalid feature vector")
                    vectors[h] = vector
                # Keep per-dataset extraction namespaces; identical hash can have a
                # separately extracted T-domain vector with tiny numerical differences.
                self.vectors[(dataset, aid)] = vectors
                self.records.append(record)
        finally:
            db.close(); index.close(); td_index.close()
            del main_z, td_z
        self._collate = collate_records
        # Keep a single padded master tensor on the allocated device. This avoids
        # repeating sequence-feature lookup/collation for every training epoch.
        self._master = self._collate_indices(range(len(self.records)))
        self.identity = dict(schema="patrick_neural_inputs_v1", sources=source_proof,
                             rows=[dict(dataset=r["dataset"], assembly_id=r["assembly_id"]) for r in rows],
                             structural_records_sha256=digest(self.records),
                             label_source="explicit fit arguments; source database labels ignored",
                             encoder_source_sha256=sha(PACKAGE / "vendor_neural/assembly_model.py"))
        self.identity_sha256 = digest(self.identity)
        self.overlap_audit = source_overlap_audit(self.records, rows, self.native_record)

    def _collate_indices(self, indices):
        # Collate each row independently to preserve the T-domain sidecar namespace,
        # then pad to this batch's maximum route length. Padding has no model inputs.
        torch = _torch()
        prepared = [self._collate([self.records[int(i)]],
                    self.vectors[(self.records[int(i)]["dataset"], self.records[int(i)]["assembly_id"])].__getitem__)
                    for i in indices]
        require(prepared, "Empty prediction/training batch")
        length = max(b["valid"].shape[1] for b in prepared)
        output = {}
        for key in prepared[0]:
            parts = []
            for b in prepared:
                value = b[key]
                shape = list(value.shape); shape[1] = length
                padded = torch.zeros(shape, dtype=value.dtype)
                if key == "chain":
                    padded.fill_(-1)
                padded[:, :value.shape[1]] = value
                parts.append(padded)
            output[key] = torch.cat(parts).to(self.device)
        return output

    def batch(self, indices):
        torch = _torch()
        ix = torch.tensor(list(indices), dtype=torch.long, device=self.device)
        require(ix.numel() > 0, "Empty prediction/training batch")
        length = int(self._master["valid"].index_select(0, ix).sum(1).max().item())
        return {key: value[:, :length].index_select(0, ix) for key, value in self._master.items()}

