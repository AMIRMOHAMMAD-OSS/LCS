#!/usr/bin/env python3
"""One continued run with natural reconstruction and construct activity supervision."""
import argparse
from collections import Counter
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import signal
import sys
import time
import traceback
from types import SimpleNamespace

PACKAGE = Path(__file__).resolve().parent
VERSION = "neuralps_joint_xut_extension_27000_32000_20261107_v1"
BASE = "NeurALPS_Assembly_v1_20261002"
RAM = "NeurALPS_RAM_20261002/ram_io.py"
TARGETS = "e1_ssl_targets_497189"
TARGET_MANIFEST_SHA = "d4571217575bba57d0ee20cd9e2511d5b1a0a792bac7b2caf33033b67816e9db"
BASE_HASHES = {
    BASE + "/run_ssl.py": "13fc8f1183b1af2eb5b97147c3b2b66f7be8db48d5b7fd4a0998c8c62ba2d49b",
    BASE + "/src/assembly_model.py": "551772090b00a9bf0d5a44fa85a4014e103079c4dabd1f2b99259ed5441dd2f4",
    BASE + "/src/masking_contract.py": "a9a4e94fec9d07882e6e7527bcd57298cb8d79f7f2362c4c47c165545024bc2a",
    BASE + "/src/run_state.py": "a09cad10627326bb62aeb89f84b47cc279488732ca6018aff9c8c218eeb6c461",
    RAM: "c479ecfa2697856c6b393337a4ccbd50e290c3a0bdb0e98b17bcc9f5dac1061f",
}
POLICY = dict(encoder_lr=2.5e-6, head_lr=7.5e-5, learning_rate_floor_fraction=.4,
              head_warmup_updates=0, supervised_ramp_updates=0, supervised_weight=.15,
              relative_anchor_weight=.005, anchor_step=26000, grad_clip=1., save_every=50,
              checkpoint_every=500, natural_dev_limit=192, reference_limit=192,
              checkpoint_selection="fixed endpoint; no activity-holdout selection")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def dump(path, content):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(content, indent=2, sort_keys=True, allow_nan=False) + "\n")
    os.replace(temporary, path)


def emit(stage, **data):
    print(json.dumps(dict(stage=stage, **data), allow_nan=False), flush=True)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, "Cannot import " + str(path))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def pinned_modules(root):
    for rel, expected in BASE_HASHES.items():
        require(sha(root / rel) == expected, "Original source differs: " + rel)
    ssl = load_module("neuralps_joint_base_ssl", root / BASE / "run_ssl.py")
    ram = load_module("neuralps_joint_base_ram", root / RAM)
    import assembly_model
    from masking_contract import masking_closure
    return ssl, ram, assembly_model, masking_closure


def checkpoint_parent(path, digest, expected_step, torch):
    require(sha(path) == digest, "Parent SHA-256 differs from the launch receipt")
    state = torch.load(path, map_location="cpu", weights_only=True)
    require(state.get("step") == expected_step, "Embedded checkpoint step differs from the requested parent")
    fields = {"config", "model", "optimizer", "sampler", "torch_rng", "cuda_rng",
              "targets_manifest", "target_means"}
    require(fields <= state.keys(), "Parent lacks original SSL state, optimizer, or sampler")
    config = state["config"]
    require(config.get("activity_labels_used") is False, "Expected label-free SSL parent lineage")
    require(config.get("targets_manifest_sha256") == TARGET_MANIFEST_SHA,
            "Parent was trained with a different natural target bank")
    expected_encoder = dict(feature_dim=1152, width=256, heads=8, local_layers=4, radius=6,
                            global_layers=2, global_slots=4, vocabulary_size=32, dropout=.1)
    cfg = config["settings"]
    require(cfg["encoder"] == expected_encoder and cfg["object_loss"] == "centered"
            and cfg["rank_weight"] == .05 and cfg["batch"] == 32 and cfg["micro"] == 8,
            "Parent settings differ from the audited architecture/objective")
    sampler = state["sampler"]
    require(sampler["attempted"] - sampler["skipped"] == expected_step * cfg["batch"],
            "Parent sampler does not agree with the update counter")
    require(bool(state["optimizer"]["state"]) and len(state["cuda_rng"]) == 1,
            "Parent optimizer/RNG is incomplete")
    return state


def natural_inputs(root, ssl, ram, cfg, parent, torch):
    assets = root / TARGETS
    require(sha(assets / "manifest.json") == TARGET_MANIFEST_SHA, "Natural target manifest changed")
    manifest = json.loads((assets / "manifest.json").read_text())
    require(parent["targets_manifest"] == manifest, "Parent target manifest differs")
    verified = {}
    for item in manifest["fingerprints"]:
        path = Path(item["path"])
        require(path.is_relative_to(root), "Natural assets must use the original project location")
        if path.name == "features.f32":
            continue
        require(sha(path) == item["sha256"], "Natural input checksum differs: " + str(path))
        verified[str(path.resolve().relative_to(root))] = item["sha256"]
    store = ssl.Store(root)
    emit("LOADING_AUDITED_NATURAL_FEATURES", path=str(store.cache / "features.f32"))
    store.z = ram.load_checked_f32(store.cache / "features.f32", ram.SHAPE, ram.FEATURE_SHA)
    verified[str((store.cache / "features.f32").resolve().relative_to(root))] = ram.FEATURE_SHA
    targets = ssl.Targets(SimpleNamespace(assets=assets, settings=cfg), store)
    for key, (array, _) in manifest["means"].items():
        require(torch.equal(parent["target_means"][key], torch.from_numpy(targets.arrays[array])),
                "Parent target center differs: " + key)
    return store, targets, verified


def encoder_optimizer(model, torch):
    exempt = {id(p) for m in model.modules() if isinstance(m, (torch.nn.Embedding, torch.nn.LayerNorm))
              for p in m.parameters(recurse=False)} | {id(model.global_tokens)}
    decay, no_decay = [], []
    for param in model.parameters():
        if param.requires_grad:
            (decay if param.ndim > 1 and id(param) not in exempt else no_decay).append(param)
    return torch.optim.AdamW([dict(params=decay, weight_decay=.01),
                              dict(params=no_decay, weight_decay=0)],
                             lr=POLICY["encoder_lr"], betas=(.9, .999), eps=1e-8)


def atomic_checkpoint(torch, out, state):
    temp = out / "latest.pt.tmp"
    with temp.open("wb") as f:
        torch.save(state, f)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, out / "latest.pt")


def bundle_identity():
    files = [p for p in PACKAGE.rglob("*") if p.is_file() and "__pycache__" not in p.parts
             and p.suffix in {".py", ".json", ".npz", ".csv", ".sh", ".sbatch", ".gz", ".txt"}]
    return {str(p.relative_to(PACKAGE)): sha(p) for p in sorted(files)}


def run(args, stopping):
    import torch
    from joint_extension import (ANCHOR_PATH, ANCHOR_SHA, END_STEP, PARENT_STEP, UPDATES,
                                 learning_rates, restore_training_state,
                                 validate_joint_state, verify_joint_parent_files)
    from evaluation import NaturalEvaluation
    from ssl_changes import (MASK_POLICY_VERSION, MASK_WEIGHTS, STRUCTURED_MASK_POLICIES,
                             STRUCTURED_MAX_HIDDEN, choose_mixed_view, choose_structured_view,
                             enable_full_attention, selftest)
    from supervised import SupervisedData

    require(torch.__version__.split("+")[0] == "2.8.0", "Use pytorch-gpu/py3/2.8.0")
    require(torch.cuda.is_available() and torch.cuda.device_count() == 1,
            "Run inside a Slurm allocation with exactly one CUDA GPU")
    torch.set_num_threads(int(os.environ.get("SLURM_CPUS_PER_TASK", 8)))
    torch.backends.cuda.matmul.allow_tf32 = False
    ssl, ram, assembly_model, closure = pinned_modules(args.root)
    require(args.parent_step == PARENT_STEP and args.steps == UPDATES,
            "This extension is pinned to 27000 -> 32000")
    lineage = verify_joint_parent_files(args.root, args.parent)
    require(lineage["parent_sha256"] == args.parent_sha256, "Launch parent digest differs")
    joint = torch.load(args.parent, map_location="cpu", weights_only=True)
    parent_config = json.loads((args.parent.parent / "config.json").read_text())
    validate_joint_state(joint, parent_config, PARENT_STEP, torch)
    parent = checkpoint_parent(args.root / ANCHOR_PATH, ANCHOR_SHA, 26000, torch)
    cfg = parent["config"]["settings"]
    require(parent_config["settings"] == cfg, "Joint and original natural settings differ")
    ssl.check_loss_math()
    selftest(assembly_model, closure, ssl.choose_view)
    emit("SOURCE_AND_MASK_SELFTEST_PASS", parent_step=args.parent_step)
    store, targets, verified = natural_inputs(args.root, ssl, ram, cfg, parent, torch)
    device = torch.device("cuda")
    labelled = SupervisedData(args.root, device, threads=torch.get_num_threads(),
                              verified_hashes=verified)
    require(json.loads(json.dumps(labelled.manifest)) == parent_config["labelled"],
            "Labelled feature identities or train/holdout split differ from 27000")
    config = dict(version=VERSION, parent_path=str(args.parent), parent_sha256=args.parent_sha256,
                  parent_step=args.parent_step, steps=args.steps,
                  final_step=args.parent_step + args.steps, settings=cfg,
                  policy=POLICY, attention="full_distance_with_radius6_clipped_bias",
                  lineage=lineage, anchor_path=str(args.root / ANCHOR_PATH), anchor_sha256=ANCHOR_SHA,
                  extension_start_mask_counts=joint["counts"],
                  inherited_training_state=["encoder", "activity_head", "both_optimizers", "sampler", "CPU_CUDA_RNG"],
                  natural_mask_policy=dict(version=MASK_POLICY_VERSION, requested_percent=MASK_WEIGHTS,
                                           structured_max_hidden_fraction=STRUCTURED_MAX_HIDDEN,
                                           xut_scope="cached XUT-I object projection between A-to-PCP covalent seams",
                                           substrate_annotations_used=False,
                                           physical_break_roles="C-terminal and N-terminal features remain distinct"),
                  natural_target_manifest_sha256=TARGET_MANIFEST_SHA,
                  sources=bundle_identity(), labelled=labelled.manifest)
    config = json.loads(json.dumps(config, allow_nan=False))
    require(config["natural_mask_policy"] == parent_config["natural_mask_policy"],
            "Natural masking policy differs from completed XUT run")
    if args.resume:
        saved = torch.load(args.out / "latest.pt", map_location="cpu", weights_only=True)
        validate_joint_state(saved, config, saved["step"], torch)
    else:
        require(not (args.out / "latest.pt").exists(), "Use resume for the existing checkpoint")
        saved = None
    model = ssl.build_model(cfg["encoder"]).to(device)
    model.load_state_dict(parent["model"], strict=True)
    encoder_opt = encoder_optimizer(model, torch)
    torch.manual_seed(20261107)
    head = labelled.head(cfg["encoder"]["width"]).to(device)
    head_opt = torch.optim.AdamW(head.parameters(), lr=POLICY["head_lr"], weight_decay=.02)
    sampler = ssl.AssemblyOrder(targets.manifest["ids"]["train"], cfg["data_seed"])
    natural_eval = NaturalEvaluation(ssl, store, targets, cfg, choose_structured_view,
                                     device, limit=POLICY["natural_dev_limit"],
                                     structured_policies=STRUCTURED_MASK_POLICIES)
    require(natural_eval.views["xut"], "No eligible projected XUT-I view in natural dev")
    emit("NATURAL_DEV_MASK_COVERAGE", eligible={k: len(v) for k, v in natural_eval.views.items()})
    fixed_views = json.loads(json.dumps(natural_eval.manifest()))
    require(fixed_views == json.loads((args.parent.parent / "fixed_natural_views.json").read_text()),
            "Natural development views differ from the completed 27000 run")
    # The anchor remains the original 26k model, even though updates start from 27k.
    anchor = [(p, p.detach().clone(), p.detach().square().mean().clamp_min(1e-6))
              for p in model.parameters() if p.requires_grad]
    if not args.resume:
        dump(args.out / "config.json", config)
        dump(args.out / "fixed_natural_views.json", fixed_views)
        emit("EVALUATING_ORIGINAL_LOCAL_26000", step=26000)
        local26 = natural_eval.evaluate(model)
        enable_full_attention(model)
        emit("EVALUATING_ZERO_UPDATE_FULL_ATTENTION_26000", step=26000)
        full26 = natural_eval.evaluate(model)
        dump(args.out / "attention_baseline.json",
             dict(local_26000=local26, full_26000_zero_updates=full26,
                  fixed_views_sha256=sha(args.out / "fixed_natural_views.json"),
                  interpretation="Same 26k weights, same views; only the local radius cutoff changes"))
    else:
        enable_full_attention(model)
        require((args.out / "attention_baseline.json").is_file()
                and (args.out / "parent_natural.json").is_file(), "Resume baseline files missing")
    state = joint if saved is None else saved
    start = state["step"]
    require(PARENT_STEP <= start <= END_STEP, "Resume step is out of range")
    restore_training_state(state, model, head, encoder_opt, head_opt, sampler, torch)
    metrics = Counter(state["counts"])
    rng = state
    if not args.resume:
        emit("EVALUATING_FULL_ATTENTION_PARENT_27000", step=PARENT_STEP)
        dump(args.out / "parent_natural.json", natural_eval.evaluate(model))
        emit("RESTORED_JOINT_TRAINING_STATE", step=start, anchor_step=26000,
             encoder_lr=encoder_opt.param_groups[0]["lr"], head_lr=head_opt.param_groups[0]["lr"],
             supervised_encoder_weight=POLICY["supervised_weight"], warmup_repeated=False)
    require(sampler.attempted - sampler.skipped == start * cfg["batch"],
            "Resume sampler and update counter disagree")

    def make(aid, split, tag):
        record = store.record(aid, split)
        seed = ssl.seed(cfg["data_seed"], tag, aid)
        rng = random.Random(seed)
        policy_rng = random.Random(ssl.seed(cfg["data_seed"], tag, aid, "corruption-policy"))
        plan = choose_mixed_view(record, store.parent, rng, closure, ssl.choose_view,
                                 policy_rng=policy_rng)
        return (record, plan) if plan is not None else None

    def tensors(plans):
        return ssl.tensors(plans, store, assembly_model.collate_records,
                           assembly_model.MASKED, device)

    def save(step):
        atomic_checkpoint(torch, args.out, dict(
            config=config, step=step, encoder_state=model.state_dict(),
            activity_state=head.state_dict(), encoder_optimizer=encoder_opt.state_dict(),
            activity_optimizer=head_opt.state_dict(), sampler=sampler.state_dict(),
            torch_rng=torch.get_rng_state(), cuda_rng=torch.cuda.get_rng_state_all(),
            counts=dict(metrics)))

    if start < config["final_step"]:
        long_ids = sorted(targets.manifest["ids"]["train"], key=lambda row: (-row[1], row[0]))
        probe = [x for aid, _ in long_ids[:32] if (x := make(aid, "train", "long_check"))]
        require(len(probe) >= cfg["micro"], "No eligible long-route check")
        probe = probe[:cfg["micro"]]
        batch = tensors(probe)
        model.eval()
        with torch.no_grad():
            original = model.predict_masked(batch)
            require(bool(torch.isfinite(original).all()), "Nonfinite loaded prediction")
            poison = dict(batch)
            poison["x"] = batch["x"].clone()
            poison["x"][batch["state"] == assembly_model.MASKED] = 1e8
            torch.testing.assert_close(original, model.predict_masked(poison), rtol=0, atol=0)
        model.train()
        head.train()
        loss, _ = ssl.losses(model.predict_masked(batch), probe, targets, ("check", start),
                             cfg["rank_weight"])
        sup = labelled.loss(model, head, start + 1, detach_encoder=False)
        (loss.mean() + POLICY["supervised_weight"] * sup).backward()
        params = [p for p in list(model.parameters()) + list(head.parameters()) if p.requires_grad]
        require(all(p.grad is None or bool(torch.isfinite(p.grad).all()) for p in params),
                "Nonfinite gradient in combined readiness check")
        require(any(p.grad is not None and bool(p.grad.abs().sum() > 0) for p in head.parameters()),
                "Activity head has no training gradient")
        encoder_opt.zero_grad(set_to_none=True)
        head_opt.zero_grad(set_to_none=True)
        del batch, poison, original, loss, sup
        emit("REAL_LONG_ROUTE_AND_ACTIVITY_GRADIENT_CHECK_PASS",
             route_lengths=[len(r["route"]) for r, _ in probe])
    torch.set_rng_state(rng["torch_rng"])
    torch.cuda.set_rng_state_all(rng["cuda_rng"])
    del parent, joint, saved, state, rng
    if not args.resume:
        save(start)

    def milestone(step):
        # Hard links preserve immutable snapshots when atomic latest.pt is replaced.
        # No evaluation changes the training RNG or chooses the next checkpoint.
        folder = args.out / "checkpoints"
        folder.mkdir(exist_ok=True)
        name = f"step_{step:05d}.pt"
        snapshot = folder / name
        if not snapshot.exists():
            os.link(args.out / "latest.pt", snapshot)
        meta_path = folder / f"step_{step:05d}.json"
        digest = sha(snapshot)
        if meta_path.exists():
            record = json.loads(meta_path.read_text())
            require(record["checkpoint_sha256"] == digest and record["step"] == step,
                    "Archived milestone checksum or step differs")
            require(sha(folder / record["natural_diagnostics"]) == record["natural_diagnostics_sha256"],
                    "Archived natural diagnostics changed")
            return
        cpu_rng, cuda_rng = torch.get_rng_state(), torch.cuda.get_rng_state_all()
        try:
            emit("MILESTONE_NATURAL_EVALUATION", step=step)
            natural = (json.loads((args.out / "parent_natural.json").read_text())
                       if step == PARENT_STEP else natural_eval.evaluate(model))
            diagnostic = folder / f"step_{step:05d}_natural.json"
            dump(diagnostic, natural)
            record = dict(step=step, checkpoint=name, checkpoint_sha256=digest,
                          natural_diagnostics=diagnostic.name,
                          natural_diagnostics_sha256=sha(diagnostic),
                          activity_holdout_evaluated=False,
                          selection="fixed schedule; never selected by held-out activity")
            dump(meta_path, record)
            emit("MILESTONE_SAVED", **record,
                 object_losses={k: v["metrics"]["object"] for k, v in natural.items() if v["metrics"]})
        finally:
            torch.set_rng_state(cpu_rng)
            torch.cuda.set_rng_state_all(cuda_rng)

    if (start - PARENT_STEP) % POLICY["checkpoint_every"] == 0:
        milestone(start)
    started = time.monotonic()
    step = start
    for next_step in range(start + 1, config["final_step"] + 1):
        if stopping["signal"] is not None:
            break
        plans = []
        for _ in range(cfg["batch"] * 200):
            aid, epoch = sampler.next()
            item = make(aid, "train", ("train_mask", epoch))
            if item is None:
                sampler.skipped += 1
                continue
            plans.append(item)
            if len(plans) == cfg["batch"]:
                break
        require(len(plans) == cfg["batch"], "Too few eligible natural masking views")
        model.train()
        head.train()
        encoder_opt.zero_grad(set_to_none=True)
        head_opt.zero_grad(set_to_none=True)
        update = next_step - args.parent_step
        encoder_lr, head_lr = learning_rates(update)
        for group in encoder_opt.param_groups:
            group["lr"] = encoder_lr
        for group in head_opt.param_groups:
            group["lr"] = head_lr
        natural = Counter()
        for offset in range(0, len(plans), cfg["micro"]):
            micro = plans[offset:offset + cfg["micro"]]
            objective, report = ssl.losses(model.predict_masked(tensors(micro)), micro, targets,
                                           ("joint_train_panel", cfg["data_seed"], next_step),
                                           cfg["rank_weight"])
            require(bool(torch.isfinite(objective).all()), "Nonfinite natural loss")
            (objective.sum() / len(plans)).backward()
            natural.update(report)
        weight = POLICY["supervised_weight"]
        supervised_loss = labelled.loss(model, head, next_step, detach_encoder=False)
        require(bool(torch.isfinite(supervised_loss)), "Nonfinite activity loss")
        (supervised_loss * weight).backward()
        penalty = torch.stack([(p - origin).square().mean() / scale
                               for p, origin, scale in anchor]).mean()
        (POLICY["relative_anchor_weight"] * penalty).backward()
        encoder_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), POLICY["grad_clip"],
                                                       error_if_nonfinite=True)
        head_norm = torch.nn.utils.clip_grad_norm_(head.parameters(), POLICY["grad_clip"],
                                                    error_if_nonfinite=True)
        encoder_opt.step()
        head_opt.step()
        step = next_step
        metrics.update("mask_" + p["view_kind"] for _, p in plans)
        metrics.update("requested_" + p["view_requested"] for _, p in plans)
        metrics["natural_target_objects"] += sum(len(p["primary"]) for _, p in plans)
        for _, plan in plans:
            metrics["target_objects_" + plan["view_kind"]] += len(plan["primary"])
            metrics["hidden_slots_" + plan["view_kind"]] += len(plan["hidden"])
            if plan["view_kind"] == "break_side":
                role = next(iter(plan["primary"].values()))[0]["slot"]
                metrics["directional_break_target_role_" + str(role)] += 1
        if update % 10 == 0 or step == start + 1:
            event = dict(step=step, continuation_update=update,
                         elapsed_seconds=round(time.monotonic() - started, 2),
                         natural=ssl.clean_metrics(natural), supervised=float(supervised_loss.detach()),
                         supervised_encoder_weight=weight, encoder_lr=encoder_lr, head_lr=head_lr,
                         anchor=float(penalty.detach()),
                         encoder_grad_norm=float(encoder_norm), head_grad_norm=float(head_norm),
                         mask_counts=dict(metrics))
            emit("TRAINING", **event)
            with (args.out / "progress.jsonl").open("a") as f:
                f.write(json.dumps(event, allow_nan=False) + "\n")
        if update % POLICY["save_every"] == 0 or step == config["final_step"]:
            save(step)
        if update % POLICY["checkpoint_every"] == 0 and stopping["signal"] is None:
            milestone(step)

    if stopping["signal"] is not None:
        save(step)
        dump(args.out / "pause.json", dict(step=step, signal=stopping["signal"]))
        emit("PAUSED_WITH_CHECKPOINT", step=step)
        return 75
    require(step == config["final_step"], "Update budget did not complete")
    require(all(metrics["mask_" + kind] > 0 for kind in ("original", "xut")),
            "The run did not train on both the original and projected XUT-I policies")
    for kind, count in metrics.items():
        if kind.startswith("mask_"):
            emit("REALIZED_MASK_COUNT", kind=kind, count=count)
    emit("FINAL_EVALUATION", step=step)
    candidate = args.out / "latest.pt"
    candidate_sha = sha(candidate)
    final_natural = args.out / "checkpoints" / f"step_{step:05d}_natural.json"
    natural = json.loads(final_natural.read_text()) if final_natural.exists() else natural_eval.evaluate(model)
    activity = labelled.evaluate(model, head)
    dump(args.out / "natural_comparison.json",
         dict(parent=json.loads((args.out / "parent_natural.json").read_text()), candidate=natural,
              parent_step=PARENT_STEP, candidate_step=step,
              attention_baseline="attention_baseline.json", comparison="full attention at both checkpoints"))
    dump(args.out / "activity_holdout.json", activity)
    reference = natural_eval.write_reference(
        model, args.root, args.out, candidate_sha,
        stopping=lambda: stopping["signal"] is not None, limit=POLICY["reference_limit"])
    if stopping["signal"] is not None:
        dump(args.out / "pause.json", dict(step=step, signal=stopping["signal"]))
        return 75
    result = dict(status="JOINT_CONTINUATION_COMPLETE", step=step,
                  parent_step=args.parent_step, parent_sha256=args.parent_sha256,
                  additional_updates=args.steps, candidate_checkpoint=candidate.name,
                  anchor_step=26000, anchor_sha256=ANCHOR_SHA,
                  intermediate_checkpoints="checkpoints/", selection="fixed final step 32000",
                  additional_natural_views=sum(metrics[k] - config["extension_start_mask_counts"].get(k, 0)
                                               for k in metrics if k.startswith("mask_")),
                  extension_mask_counts={k: metrics[k] - config["extension_start_mask_counts"].get(k, 0)
                                         for k in metrics},
                  candidate_sha256=candidate_sha, mask_counts=dict(metrics),
                  realized_mask_views={k: metrics["mask_" + k] for k in MASK_WEIGHTS},
                  requested_mask_views={k: metrics["requested_" + k] for k in MASK_WEIGHTS},
                  reference=reference, heldout="activity_holdout.json",
                  diagnostics="natural_comparison.json", training_configuration="config.json")
    dump(args.out / "COMPLETE.json", result)
    emit("JOINT_CONTINUATION_COMPLETE", step=step, candidate_sha256=candidate_sha,
         additional_updates=args.steps, additional_natural_views=result["additional_natural_views"],
         reference_status=reference["status"], output=str(args.out))
    try:
        from export_review import export_review
        review = export_review(args.root, args.out)
        print("RESULT_ZIP:", review["path"], flush=True)
        print("RESULT_SHA256:", review["sha256"], flush=True)
    except Exception as exc:
        emit("REVIEW_EXPORT_UNAVAILABLE", reason=str(exc),
             action="Training is complete. Rerun export_review.py to export the diagnostics.")
    return 0


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("root", "parent", "out"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--parent-sha256", required=True)
    p.add_argument("--parent-step", type=int, choices=(27000,), required=True)
    p.add_argument("--steps", type=int, required=True)
    p.add_argument("--resume", action="store_true")
    args = p.parse_args()
    for name in ("root", "parent", "out"):
        setattr(args, name, getattr(args, name).resolve())
    require(args.steps == 5000, "This package requires exactly 5000 additional updates")
    require(args.out.is_relative_to(args.root) and args.out != args.root,
            "Output must be a dedicated directory within the project")
    require(not args.parent.is_relative_to(args.out), "Output cannot contain the parent checkpoint")
    args.out.mkdir(parents=True, exist_ok=True)
    stopping = {"signal": None}

    def request_stop(signum, _frame):
        stopping["signal"] = signum

    signal.signal(signal.SIGUSR1, request_stop)
    signal.signal(signal.SIGTERM, request_stop)
    with (args.out / ".training.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        require(not (args.out / "COMPLETE.json").exists(), "This continuation is already complete")
        try:
            return run(args, stopping)
        except Exception:
            dump(args.out / "fatal_error.json", dict(traceback=traceback.format_exc(),
                                                   job_id=os.environ.get("SLURM_JOB_ID")))
            raise


if __name__ == "__main__":
    raise SystemExit(main())
