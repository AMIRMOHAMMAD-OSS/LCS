"""Pinned lineage and state restoration for the completed 27k XUT run."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

PARENT_RUN = 'neuralps_xut_continue_20261107T172538Z_976745e6'
PARENT_SHA = 'bb78635c63d7a29ba77fc0ff09203ecc92a7938fd216e269716243e5d104a66c'
PARENT_STEP = 27000
END_STEP = 32000
UPDATES = END_STEP - PARENT_STEP
OLD_PACKAGE = 'NeurALPS_XUT_Continuation_20261107'
OLD_MANIFEST_SHA = '976745e620a3ed46302986054a870302a5644f324d4799b285a20e89f8fb3a35'
OLD_VERSION = 'neuralps_joint_xut_continuation_20261107_v2'
ANCHOR_PATH = 'e1_ssl_continue30_v1_530757/best.pt'
ANCHOR_SHA = '9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f'
ATTENTION = 'full_distance_with_radius6_clipped_bias'
TARGET_SHA = 'd4571217575bba57d0ee20cd9e2511d5b1a0a792bac7b2caf33033b67816e9db'
START_ENCODER_LR = 2.5e-6
START_HEAD_LR = 7.5e-5
LR_FLOOR = .4


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def verify_joint_parent_files(root, path=None):
    """Hash and inspect JSON only; safe on the login node without Torch."""
    root = Path(root).resolve()
    path = Path(path).resolve() if path is not None else root / PARENT_RUN / 'latest.pt'
    require(path.is_relative_to(root) and path.name == 'latest.pt' and path.is_file(),
            'Expected the completed joint latest.pt within the project')
    out = path.parent
    completion = load(out / 'COMPLETE.json')
    config = load(out / 'config.json')
    require(completion.get('status') == 'JOINT_CONTINUATION_COMPLETE'
            and completion.get('step') == PARENT_STEP
            and completion.get('candidate_checkpoint') == 'latest.pt'
            and completion.get('candidate_sha256') == PARENT_SHA,
            'Parent must be the verified completed XUT step 27000')
    require(sha(path) == PARENT_SHA, 'Joint parent checkpoint SHA-256 differs')
    require(config.get('version') == OLD_VERSION and config.get('final_step') == PARENT_STEP
            and config.get('parent_step') == 26000 and config.get('steps') == 1000
            and config.get('parent_sha256') == ANCHOR_SHA
            and config.get('attention') == ATTENTION
            and config.get('natural_target_manifest_sha256') == TARGET_SHA,
            'Parent lineage, attention, or target bank differs')
    require(Path(config['parent_path']).resolve() == (root / ANCHOR_PATH).resolve(),
            'Parent original anchor path differs')
    old_package = root / OLD_PACKAGE
    manifest = old_package / 'PACKAGE_MANIFEST.json'
    require(sha(manifest) == OLD_MANIFEST_SHA, 'Original XUT package manifest changed')
    entries = load(manifest)['files']
    expected_sources = dict(entries, **{'PACKAGE_MANIFEST.json': OLD_MANIFEST_SHA})
    require(config.get('sources') == expected_sources, 'Parent source identity differs from pinned package')
    for relative, digest in expected_sources.items():
        item = (old_package / relative).resolve()
        require(item.is_relative_to(old_package.resolve()) and sha(item) == digest,
                'Original XUT source changed: ' + relative)
    require(sha(root / ANCHOR_PATH) == ANCHOR_SHA, 'Original 26k anchor checkpoint changed')
    require((out / 'fixed_natural_views.json').is_file(), 'Parent fixed development views missing')
    return dict(parent=str(path), parent_step=PARENT_STEP, parent_sha256=PARENT_SHA,
                selection_reason='exact completed full-attention XUT joint checkpoint; no fallback',
                parent_config_sha256=sha(out / 'config.json'),
                parent_completion_sha256=sha(out / 'COMPLETE.json'),
                parent_source_manifest_sha256=OLD_MANIFEST_SHA,
                parent_fixed_views_sha256=sha(out / 'fixed_natural_views.json'))


def validate_joint_state(state, config, expected_step, torch):
    fields = {'config', 'step', 'encoder_state', 'activity_state', 'encoder_optimizer',
              'activity_optimizer', 'sampler', 'torch_rng', 'cuda_rng', 'counts'}
    require(fields <= state.keys(), 'Joint checkpoint lacks a required training-state field')
    require(state['config'] == config and state['step'] == expected_step,
            'Joint checkpoint embedded config or step differs')
    sampler = state['sampler']
    require(sampler['attempted'] - sampler['skipped'] == expected_step * config['settings']['batch'],
            'Joint checkpoint sampler and optimizer-step count disagree')
    require(isinstance(state['counts'], dict), 'Joint mask counts are missing')
    require(sum(v for k, v in state['counts'].items() if k.startswith('mask_'))
            == (expected_step - 26000) * config['settings']['batch'],
            'Cumulative realized natural mask counts disagree with the joint update count')
    require(torch.is_tensor(state['torch_rng']) and len(state['cuda_rng']) == 1,
            'Joint RNG state must contain CPU and one CUDA stream')
    for key in ('encoder_optimizer', 'activity_optimizer'):
        require(bool(state[key]['state']) and bool(state[key]['param_groups']),
                'Joint checkpoint has empty optimizer state: ' + key)
    if expected_step == PARENT_STEP:
        for key, expected in (('encoder_optimizer', START_ENCODER_LR),
                              ('activity_optimizer', START_HEAD_LR)):
            require(all(math.isclose(g['lr'], expected, rel_tol=1e-9, abs_tol=0.)
                        for g in state[key]['param_groups']),
                    'Joint checkpoint ending learning rate differs: ' + key)


def restore_training_state(state, model, head, encoder_opt, head_opt, sampler, torch):
    model.load_state_dict(state['encoder_state'], strict=True)
    head.load_state_dict(state['activity_state'], strict=True)
    encoder_opt.load_state_dict(state['encoder_optimizer'])
    head_opt.load_state_dict(state['activity_optimizer'])
    sampler.load_state_dict(state['sampler'])
    torch.set_rng_state(state['torch_rng'])
    torch.cuda.set_rng_state_all(state['cuda_rng'])


def learning_rates(update):
    require(1 <= update <= UPDATES, 'Extension learning-rate index is out of range')
    decay = LR_FLOOR + (1. - LR_FLOOR) * .5 * (1. + math.cos(math.pi * (update - 1) / (UPDATES - 1)))
    return START_ENCODER_LR * decay, START_HEAD_LR * decay
