#!/usr/bin/env python3
"""Export completed diagnostics for the Jean Zay -> Mac -> LCS handoff."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import os
import zipfile

PACKAGE = Path(__file__).resolve().parent


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            value.update(block)
    return value.hexdigest()


def export_review(root, out):
    root, out = Path(root).resolve(), Path(out).resolve()
    if out.parent != root or not out.name.startswith('neuralps_xut_5k_'):
        raise ValueError('Expected a dedicated 5k extension output in the project')
    done = json.loads((out / 'COMPLETE.json').read_text())
    if (done.get('status') != 'JOINT_CONTINUATION_COMPLETE' or done.get('step') != 32000
            or done.get('candidate_checkpoint') != 'latest.pt'
            or done.get('candidate_sha256') != sha(out / 'latest.pt')):
        raise ValueError('Expected the verified completed 32000 checkpoint')
    config = json.loads((out / 'config.json').read_text())
    parent = Path(config['parent_path']).resolve().parent
    if not parent.is_relative_to(root):
        raise ValueError('Parent diagnostics must be within the project')
    entries = []
    required = ('COMPLETE.json', 'config.json', 'fixed_natural_views.json',
                'attention_baseline.json', 'parent_natural.json', 'natural_comparison.json',
                'activity_holdout.json', 'natural_reference.json', 'progress.jsonl')
    for name in required:
        if not (out / name).is_file():
            raise ValueError('Missing completed diagnostic: ' + name)
        entries.append((out / name, name))
    for name in ('REQUEST.json', 'REQUEST.sha256', 'SUBMISSION.json'):
        if (out / name).is_file():
            entries.append((out / name, name))
    ref = json.loads((out / 'natural_reference.json').read_text())
    if ref.get('status') == 'COMPLETE':
        rows = out / 'natural_reference.jsonl.gz'
        if ref.get('rows') != rows.name or sha(rows) != ref.get('rows_sha256'):
            raise ValueError('Natural reference row checksum differs')
        entries.append((rows, rows.name))
    entries.extend((path, str(path.relative_to(out))) for path in sorted((out / 'checkpoints').glob('*.json')))
    for name in ('COMPLETE.json', 'config.json', 'activity_holdout.json', 'natural_comparison.json'):
        entries.append((parent / name, 'parent_27000/' + name))
    for path in sorted(PACKAGE.rglob('*')):
        if (path.is_file() and '__pycache__' not in path.parts
                and path.suffix in {'.py', '.json', '.npz', '.csv', '.sh', '.gz', '.txt'}):
            entries.append((path, 'reproduce/' + str(path.relative_to(PACKAGE))))
    output = out / 'inspection.zip'
    temp = out / 'inspection.zip.tmp'
    manifest = {}
    try:
        with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path, relative in entries:
                if path.is_symlink() or relative in manifest:
                    raise ValueError('Unexpected symbolic link or duplicate archive path: ' + relative)
                data = path.read_bytes()
                manifest[relative] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
                archive.writestr(relative, data)
            archive.writestr('REVIEW_MANIFEST.json', json.dumps(dict(
                schema='neuralps_xut_5k_review_v1', run=out.name,
                checkpoint_included=False, candidate_sha256=done['candidate_sha256'],
                files=manifest), indent=2, sort_keys=True) + '\n')
        if temp.stat().st_size >= 95_000_000:
            raise ValueError('Review archive exceeds the 95 MB transfer limit; checkpoint remains complete')
        with zipfile.ZipFile(temp) as archive:
            if archive.testzip() is not None:
                raise ValueError('Review ZIP integrity check failed')
        os.replace(temp, output)
        digest = sha(output)
        (out / 'inspection.sha256').write_text(digest + '  inspection.zip\n')
        return dict(path=str(output), sha256=digest, bytes=output.stat().st_size)
    finally:
        temp.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', nargs='?', type=Path)
    parser.add_argument('--root', type=Path, default=PACKAGE.parent)
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output
    if output is None:
        output = Path(json.loads((root / 'neuralps_xut_5k_submission.json').read_text())['output'])
    result = export_review(root, output)
    print('RESULT_ZIP:', result['path'])
    print('RESULT_SHA256:', result['sha256'])


if __name__ == '__main__':
    main()
