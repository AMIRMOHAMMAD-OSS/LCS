"""Physical record and frozen feature-bank validation from Patrick multis runtime."""
from __future__ import annotations
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np

DIM = 1152
AA = frozenset("ACDEFGHIKLMNPQRSTVWY")
FORBIDDEN_KEYS = frozenset(("label", "labels", "activity", "observed_activity", "yield", "titer", "outcome", "outcomes", "assay"))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            result.update(block)
    return result.hexdigest()


def seqsha(sequence):
    return hashlib.sha256(sequence.encode("ascii")).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def reject_labels(value):
    if isinstance(value, dict):
        require(not (FORBIDDEN_KEYS & {str(k).lower() for k in value}), "Activity labels are forbidden in structural inputs")
        for v in value.values():
            reject_labels(v)
    elif isinstance(value, list):
        for v in value:
            reject_labels(v)


def load_inputs(path):
    path = Path(path)
    with (gzip.open(path, "rt") if path.suffix == ".gz" else path.open()) as stream:
        payload = json.load(stream)
    require(set(payload) == {"records", "parents"}, "Unexpected multi-route input schema")
    validate_records(payload["records"], payload["parents"])
    return payload["records"], payload["parents"]


def validate_records(records, parents):
    """Recheck all physical sequences and model slots without evaluating labels."""
    reject_labels(records)
    require(records and isinstance(parents, dict), "Empty routes/parents")
    require(len({r["assembly_id"] for r in records}) == len(records), "Duplicate assembly identity")
    for h, sequence in parents.items():
        require(isinstance(sequence, str) and sequence and set(sequence) <= AA and seqsha(sequence) == h,
                "Parent sequence/hash mismatch")
    sequences = {}
    for record in records:
        require(record["boundary_window_policy"] == "physical_end_extradomain_tail64_v1", "Wrong boundary policy")
        require(record.get("cache_dependency_policy", "independent_sequence") == "independent_sequence", "Wrong embedding policy")
        route, slots = record["route"], record["model_slots"]
        require(route and len(route) % 2 == 1, "Route must alternate domains and connections")
        for j, obj in enumerate(route):
            require(obj["kind"] == 0 if j % 2 == 0 else obj["kind"] in (1, 2), "Invalid object ordering")
            if obj["kind"] == 0:
                require(type(obj["domain_type"]) is int and 0 <= obj["domain_type"] < 32, "Invalid domain vocabulary")
        seen = set()
        for slot in slots:
            j, k = slot["object_index"], slot["slot"]
            require(type(j) is int and 0 <= j < len(route) and k in (0, 1, 2), "Invalid slot index")
            require((j, k) not in seen, "Duplicate model slot")
            seen.add((j, k))
            kind = route[j]["kind"]
            require(slot["kind"] == kind and (k == 0 if kind != 2 else k in (1, 2)), "Wrong object/role slot")
            require(slot["state"] in ("OBSERVED", "EMPTY", "MISSING", "NA"), "Masked/unknown inference slot")
            ph, uid = slot["parent_sequence_hash"], slot["protein_uid"]
            require(record["parent_sequence_hashes"].get(uid) == ph and ph in parents, "Slot parent identity mismatch")
            parent = parents[ph]
            require(record["parent_lengths"][uid] == len(parent), "Parent length mismatch")
            a, b = slot["start"], slot["end"]
            require(type(a) is int and type(b) is int and 0 <= a <= b <= len(parent), "Invalid physical slot interval")
            sequence = parent[a:b]
            require(len(sequence) == slot["length"], "Slot length mismatch")
            if slot["state"] == "OBSERVED":
                h = slot["sequence_hash"]
                require(0 < len(sequence) <= 2046 and seqsha(sequence) == h, "Slot sequence/hash mismatch")
                object_hash = (route[j].get("seq_hash") if kind != 2 else
                               route[j].get("cterm_hash" if k == 1 else "nterm_hash"))
                require(object_hash == h, "Route object and model-slot hashes differ")
                if kind == 0:
                    require(route[j]["protein_uid"] == uid and route[j]["start_aa_0based"] == a and
                            route[j]["end_aa_0based_exclusive"] == b, "Domain object and slot coordinates differ")
                require(h not in sequences or sequences[h] == sequence, "Sequence hash collision")
                sequences[h] = sequence
        expected = {(j, k) for j, obj in enumerate(route) for k in ((1, 2) if obj["kind"] == 2 else (0,))}
        require(seen == expected, "Missing or unexpected model slot")
    return sequences


def load_feature_bank(path, records=None, parents=None):
    path = Path(path)
    report = json.loads((path / "feature_bank.json").read_text())
    require(sha(path / "feature_bank.npz") == report["feature_bank_sha256"], "Saved bank checksum mismatch")
    with np.load(path / "feature_bank.npz", allow_pickle=False) as z:
        hashes, matrix = z["hashes"].tolist(), z["vectors"].copy()
    require(len(set(hashes)) == len(hashes) and matrix.shape == (len(hashes), DIM), "Invalid saved bank dimensions")
    require(np.isfinite(matrix).all() and (np.linalg.norm(matrix.astype(np.float64), axis=1) > 0).all(), "Invalid bank vectors")
    if records is not None:
        sequences = validate_records(records, parents)
        require(set(hashes) == set(sequences), "Saved bank sequence set differs")
        require(report["structural_sha256"] == digest(records) and report["parents_sha256"] == digest(parents), "Saved bank input identity differs")
    return dict(zip(hashes, matrix)), report


