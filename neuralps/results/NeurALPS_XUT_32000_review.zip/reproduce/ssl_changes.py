"""Checkpoint-compatible direct attention and annotation-guided corruption."""

from collections import defaultdict
import math
from types import MethodType


def _full_forward(block, h, batch):
    # This matches the frozen LocalBlock implementation except for the
    # distance cutoff. The checkpoint's learned bias tables retain their shape.
    import torch
    from torch.nn import functional as F

    b, t, d = h.shape
    valid = batch["valid"]
    head_dim = d // block.heads
    q, k, v = (
        block.qkv(block.norm1(h)).reshape(b, t, 3, block.heads, head_dim)
        .permute(2, 0, 3, 1, 4).unbind(0)
    )
    pos = torch.arange(t, device=h.device)
    offset = pos[None, :] - pos[:, None]
    buckets = offset.clamp(-block.radius, block.radius) + block.radius
    relative = block.relative(buckets).permute(2, 0, 1)
    chain = batch["chain"]
    relation = (chain[:, :, None] != chain[:, None, :]).long()
    breaks = batch["kind"] == 2
    relation = torch.where(breaks[:, :, None] | breaks[:, None, :], 2, relation)
    bias = block.relation(relation).permute(0, 3, 1, 2) + relative.unsqueeze(0)

    diagonal = torch.eye(t, device=h.device, dtype=torch.bool)[None]
    allowed = valid[:, None, :] | (~valid[:, :, None] & diagonal)
    logits = q.float() @ k.float().transpose(-2, -1) / math.sqrt(head_dim) + bias.float()
    logits = logits.masked_fill(~allowed[:, None], float("-inf"))
    attention = F.dropout(logits.softmax(-1), block.dropout, training=block.training)
    update = (attention.to(v.dtype) @ v).transpose(1, 2).reshape(b, t, d)
    h = h + F.dropout(block.output(update), block.dropout, training=block.training)
    h = torch.where(valid.unsqueeze(-1), h, torch.zeros_like(h))
    h = h + block.ff(block.norm2(h))
    return torch.where(valid.unsqueeze(-1), h, torch.zeros_like(h))


def enable_full_attention(model):
    """Enable direct full-route attention while keeping model state keys intact."""
    for block in model.local:
        if block.relative.num_embeddings != 2 * block.radius + 1:
            raise ValueError("Unexpected relative-position bias table")
        block.forward = MethodType(_full_forward, block)
    return model


def _observed(record):
    by_object = defaultdict(list)
    for slot in record["model_slots"]:
        if slot["state"] == "OBSERVED":
            by_object[slot["object_index"]].append(slot)
    return {j: sorted(slots, key=lambda slot: slot["slot"]) for j, slots in by_object.items()}


# XUT-I ordered domain cores in the frozen vocabulary, verified against all
# donor-position blocks after stripping their invariant scaffold flanks.
XUT_I_CORES = frozenset(((1, 3, 2), (1, 9, 2), (1, 5, 4, 2), (1, 5, 6, 4, 2)))
PCP, ADENYLATION = 1, 2
MASK_WEIGHTS = {
    "original": 25,
    "xut": 20,
    "xut_with_seams": 10,
    "xut_pair": 8,
    "xut_interface": 7,
    "medium_span": 5,
    "long_span": 5,
    "dispersed": 5,
    "break_side": 5,
    "break_pair": 5,
    "break_flanks": 5,
}
STRUCTURED_MASK_POLICIES = tuple(k for k in MASK_WEIGHTS if k != "original")
MASK_POLICY_VERSION = "xut_i_cached_objects_and_physical_breaks_v2"
STRUCTURED_MAX_HIDDEN = .8


def _plan(record, parent, closure, obs, primary, context_radius, max_hidden):
    keys = [(j, slot["slot"]) for j, slots in primary.items() for slot in slots]
    hidden = set(map(tuple, closure(record, keys, parent, "independent_sequence")["hidden"]))
    fraction = len(hidden) / sum(map(len, obs.values()))
    if fraction > max_hidden:
        return None
    for j in primary:
        seen = set()
        independent = 0
        for k, slots in obs.items():
            if k == j or abs(k - j) > context_radius:
                continue
            hashes = {slot["sequence_hash"] for slot in slots if (k, slot["slot"]) not in hidden}
            if hashes - seen:
                independent += 1
                seen.update(hashes)
                if independent == 2:
                    break
        if independent < 2:
            return None
    return dict(primary=primary, hidden=sorted(hidden), fraction=fraction)


def _make_plan(record, parent, closure, obs, indices, context_radius, max_hidden=1.):
    if not indices or any(j not in obs for j in indices):
        return None
    return _plan(record, parent, closure, obs, {j: obs[j] for j in indices},
                 context_radius, max_hidden)


def plan_from_targets(record, parent, closure, object_indices, *, context_radius=24):
    """Select all observed roles at explicit object indices, or fail eligibility."""
    return _make_plan(record, parent, closure, _observed(record), sorted(set(object_indices)), context_radius)


def _is_covalent_xut_seam(route, j):
    if not 0 < j < len(route) - 1:
        return False
    left, connector, right = route[j - 1:j + 2]
    return (connector["kind"] == 1 and left["kind"] == right["kind"] == 0
            and left["domain_type"] == ADENYLATION and right["domain_type"] == PCP
            and left["chain"] == connector["chain"] == right["chain"])


def xut_core_spans(route):
    """Project verified XUT-I cores onto cached route objects between A-to-PCP seams."""
    spans = []
    for start, obj in enumerate(route):
        if obj["kind"] != 0 or obj["domain_type"] != PCP or not _is_covalent_xut_seam(route, start - 1):
            continue
        domains = []
        for stop in range(start, min(len(route), start + 9), 2):
            if route[stop]["kind"] != 0 or (stop > start and route[stop - 1]["kind"] not in (1, 2)):
                break
            domains.append(route[stop]["domain_type"])
            if tuple(domains) in XUT_I_CORES and _is_covalent_xut_seam(route, stop + 1):
                spans.append((start, stop))
                break
    return spans


def _complete_objects(route, obs, indices):
    # A complete physical break always has its two distinct terminal roles.
    return all(j in obs and [s["slot"] for s in obs[j]] == ([1, 2] if route[j]["kind"] == 2 else [0])
               for j in indices)


def choose_structured_view(record, parent, rng, closure, kind):
    """Use the physical route and observed feature roles to draw one structured mask."""
    route = record["route"]
    obs = _observed(record)
    candidates = []
    if kind in ("xut", "xut_with_seams", "xut_pair", "xut_interface"):
        spans = xut_core_spans(route)
        if kind == "xut":
            candidates = [range(start, stop + 1) for start, stop in spans]
        elif kind == "xut_with_seams":
            candidates = [range(start - 1, stop + 2) for start, stop in spans]
        elif kind == "xut_pair":
            ends = dict(spans)
            candidates = [range(start, ends[stop + 2] + 1)
                          for start, stop in spans if stop + 2 in ends]
        else:
            seams = sorted({j for start, stop in spans for j in (start - 1, stop + 1)})
            candidates = [range(j - 1, j + 2) for j in seams]
    elif kind in ("medium_span", "long_span"):
        lengths = range(4, 7) if kind == "medium_span" else range(7, 13)
        # Draw a length first, so short lengths do not get extra mass merely
        # because more start positions fit them.
        lengths = list(lengths)
        rng.shuffle(lengths)
        for n in lengths:
            starts = list(range(len(route) - n + 1))
            rng.shuffle(starts)
            candidates.extend(range(j, j + n) for j in starts)
    elif kind == "dispersed":
        available = sorted(obs)
        for _ in range(16):
            n = rng.randrange(2, 5)
            if n > len(available):
                continue
            indices = sorted(rng.sample(available, n))
            if all(b - a >= 3 for a, b in zip(indices, indices[1:])):
                candidates.append(indices)
    elif kind in ("break_side", "break_pair", "break_flanks"):
        breaks = [j for j, obj in enumerate(route) if obj["kind"] == 2
                  and _complete_objects(route, obs, [j])]
        if kind == "break_side":
            directions = [(j, s, partner) for j in breaks
                          for s, partner in (tuple(obs[j]), tuple(reversed(obs[j])))]
            rng.shuffle(directions)
            for j, slot, partner in directions:
                plan = _plan(record, parent, closure, obs, {j: [slot]}, 24, STRUCTURED_MAX_HIDDEN)
                if plan is not None and (j, partner["slot"]) not in plan["hidden"]:
                    return dict(plan, view_requested=kind, view_kind=kind)
            return None
        if kind == "break_pair":
            candidates = [[j] for j in breaks]
        else:
            candidates = [range(j - 1, j + 2) for j in breaks
                          if 0 < j < len(route) - 1 and route[j - 1]["kind"] == route[j + 1]["kind"] == 0]
    else:
        raise ValueError(f"Unknown structured mask kind: {kind}")
    if kind not in ("medium_span", "long_span"):
        rng.shuffle(candidates)
    for indices in candidates:
        if not _complete_objects(route, obs, indices):
            continue
        plan = _make_plan(record, parent, closure, obs, indices, 24, STRUCTURED_MAX_HIDDEN)
        if plan is not None:
            return dict(plan, view_requested=kind, view_kind=kind)
    return None


def choose_mixed_view(record, parent, rng, closure, legacy_choose_view, *, policy_rng=None):
    """Draw the declared mixture, falling back to the original RNG stream."""
    draw = 100 * (rng if policy_rng is None else policy_rng).random()
    for requested, weight in MASK_WEIGHTS.items():
        draw -= weight
        if draw < 0:
            break
    if requested != "original":
        before_structured = rng.getstate()
        plan = choose_structured_view(record, parent, rng, closure, requested)
        if plan is not None:
            return plan
        rng.setstate(before_structured)
    plan = legacy_choose_view(record, parent, rng, closure)
    if plan is not None:
        return dict(plan, view_requested=requested, view_kind="original")
    return None


def mask_selftest(closure, legacy_choose_view):
    """Check XUT boundaries, physical breaks, coverage, and metadata independence."""
    import copy
    import hashlib
    import random

    def sha(sequence):
        return hashlib.sha256(sequence.encode()).hexdigest()

    rng = random.Random(89)
    domains = (8, 2, 1, 3, 2, 1, 5, 4, 2, 1, 9, 2, 1, 7)
    chain_cut = 6  # A true inter-protein break inside the second XUT.
    sequences = ["".join(rng.choices("ACDEFGHIKLMNPQRSTVWY", k=140)) for _ in range(2)]
    parents = {sha(seq): seq for seq in sequences}
    hashes = list(parents)
    route, slots = [], []
    for j in range(2 * len(domains) - 1):
        d = j // 2
        c = int(d >= chain_cut)
        kind = 0 if j % 2 == 0 else 2 if d == chain_cut - 1 else 1
        obj = dict(kind=kind, chain=c if kind != 2 else -1, domain_type=domains[d] if kind == 0 else 0)
        if kind == 0:
            dependencies = [(0, c, 10*d, 10*d + 8)]
        elif kind == 1:
            dependencies = [(0, c, 10*d + 6, 10*d + 12)]
        else:
            dependencies = [(1, 0, 10*d + 4, 10*d + 8), (2, 1, 10*(d + 1), 10*(d + 1) + 4)]
        route.append(obj)
        for slot, chain, start, end in dependencies:
            slots.append(dict(object_index=j, slot=slot, kind=kind, state="OBSERVED", start=start,
                              end=end, parent_sequence_hash=hashes[chain],
                              sequence_hash=sha(sequences[chain][start:end])))
    record = dict(route=route, model_slots=slots, parent_sequence_hashes={"left": hashes[0], "right": hashes[1]})
    renamed = copy.deepcopy(record)
    for j, obj in enumerate(renamed["route"]):
        obj.update(module_uid=f"unrelated-{j}", annotation="J" if j % 2 else "B")
    if xut_core_spans(route) != [(4, 8), (10, 16), (18, 22)]:
        raise AssertionError("Incorrect XUT-I span projection")
    plans = {}
    for kind in STRUCTURED_MASK_POLICIES:
        args = (parents.__getitem__, random.Random(42), closure, kind)
        plan = choose_structured_view(record, *args)
        if plan is None or plan != choose_structured_view(renamed, parents.__getitem__, random.Random(42), closure, kind):
            raise AssertionError("Mask unavailable or depends on module metadata: " + kind)
        plans[kind] = plan
    b = 2 * chain_cut - 1
    if [s["slot"] for s in plans["break_pair"]["primary"][b]] != [1, 2]:
        raise AssertionError("Physical break pair must retain both terminal roles")
    side = plans["break_side"]
    target, = side["primary"][b]
    if (b, 3 - target["slot"]) in side["hidden"]:
        raise AssertionError("Directional break masking hid the observed partner")
    if set(plans["break_flanks"]["primary"]) != {b - 1, b, b + 1}:
        raise AssertionError("Physical break flank mask altered the requested region")
    if len(plans["xut_pair"]["primary"]) not in (13,):
        raise AssertionError("Adjacent XUT masks must include both units and their seam")
    partial = dict(record, model_slots=[s for s in slots if (s["object_index"], s["slot"]) != (b, 2)])
    for kind in ("break_side", "break_pair", "break_flanks"):
        if choose_structured_view(partial, parents.__getitem__, random.Random(42), closure, kind) is not None:
            raise AssertionError("Missing terminal role admitted as a complete break pair")
    single = plan_from_targets(record, parents.__getitem__, closure, [0])
    if set(single["primary"]) != {0} or (1, 0) not in single["hidden"]:
        raise AssertionError("Physical overlap closure changed")

    def no_multi_context(record_arg, keys, parent_arg, mode):
        if len(keys) >= 4:
            return dict(hidden=[(s["object_index"], s["slot"]) for s in slots])
        return closure(record_arg, keys, parent_arg, mode)

    for policy_seed, requested, active_closure in (
        (1, "original", closure), (7, "xut", no_multi_context),
    ):
        rng, legacy_rng = random.Random(1), random.Random(1)
        mixed = choose_mixed_view(record, parents.__getitem__, rng, active_closure,
                                  legacy_choose_view, policy_rng=random.Random(policy_seed))
        legacy = legacy_choose_view(record, parents.__getitem__, legacy_rng, active_closure)
        if legacy is None or mixed != dict(legacy, view_requested=requested, view_kind="original"):
            raise AssertionError("Original/fallback mask differs from legacy sampler")
        if rng.getstate() != legacy_rng.getstate():
            raise AssertionError("Original/fallback mask changed legacy RNG stream")
    return {"mask_mixture": "PASS", "xut_projection": "PASS", "physical_breaks": "PASS"}


def selftest(assembly_model, closure, legacy_choose_view):
    """Check the real model contract with small synthetic CPU inputs."""
    import torch

    checks = mask_selftest(closure, legacy_choose_view)
    with torch.random.fork_rng(devices=[]), torch.no_grad():
        torch.manual_seed(17)
        cfg = assembly_model.Config(feature_dim=8, width=16, heads=4, local_layers=1, dropout=0)
        parent = assembly_model.AssemblyEncoder(cfg).eval()
        candidate = enable_full_attention(assembly_model.AssemblyEncoder(cfg).eval())
        candidate.load_state_dict(parent.state_dict(), strict=True)

        short_len = cfg.radius + 1
        long_len = short_len + 2
        batch = dict(
            x=torch.randn(2, long_len, 3, cfg.feature_dim),
            state=torch.zeros(2, long_len, 3, dtype=torch.long),
            kind=torch.zeros(2, long_len, dtype=torch.long),
            domain_type=torch.zeros(2, long_len, dtype=torch.long),
            chain=torch.zeros(2, long_len, dtype=torch.long),
            valid=torch.ones(2, long_len, dtype=torch.bool),
        )
        batch["state"][:, :, 0] = assembly_model.OBSERVED
        batch["state"][:, 2, 0] = assembly_model.MASKED
        batch["valid"][1, short_len:] = False
        batch["state"][1, short_len:] = assembly_model.NA
        short = {key: value[1:, :short_len] for key, value in batch.items()}
        original = parent.predict_masked(short)
        torch.testing.assert_close(candidate.predict_masked(short), original, atol=0, rtol=0)
        prediction = candidate.predict_masked(batch)
        torch.testing.assert_close(prediction[1, :short_len], original[0], atol=1e-5, rtol=1e-5)
        torch.testing.assert_close(prediction[1, short_len:], torch.zeros_like(prediction[1, short_len:]), atol=0, rtol=0)
        poison = {key: value.clone() for key, value in batch.items()}
        poison["x"][poison["state"] != assembly_model.OBSERVED] = float("nan")
        torch.testing.assert_close(candidate.predict_masked(poison), prediction, atol=0, rtol=0)

        # Global relay is bypassed here to isolate direct attention. A last-token
        # change lies beyond radius 6 in a single local layer.
        far = {key: value.clone() for key, value in batch.items()}
        far["x"][0, -1, 0] = torch.randn(cfg.feature_dim)
        old_h = parent.features(batch, context=False)[0, 0]
        new_h = candidate.features(batch, context=False)[0, 0]
        torch.testing.assert_close(parent.features(far, context=False)[0, 0], old_h, atol=0, rtol=0)
        if torch.allclose(candidate.features(far, context=False)[0, 0], new_h):
            raise AssertionError("Full attention did not expose distant observed object")
    return dict(checks, strict_state_load="PASS", short_route_equivalence="PASS",
                long_route_direct_context="PASS", padding_mask_invariance="PASS")
