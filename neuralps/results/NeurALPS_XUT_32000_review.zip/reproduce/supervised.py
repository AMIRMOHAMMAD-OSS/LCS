"""Construct-level supervision for the combined continuation.

The seven fixed Patrick fold00 donor groups, and multis containing any of
them, never contribute activity gradients. DNA/plasmid/part identities and
observed products are excluded from model features.
"""
from __future__ import annotations

from collections import Counter
import csv
import json
import random
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from labelled_backend import NeuralRuntime, _route_fingerprint, require
from labelled_multis import load_inputs, load_feature_bank
from vendor_neural.assembly_model import collate_records


ASSETS = Path(__file__).resolve().parent / "labelled_assets"
ASSAYS = {"bode2": 0, "bode1": 1, "tdomain": 2}
# (examples per update, relative weight of mean cohort BCE)
COHORT_BATCHES = {
    "singles": (4, .65),
    "multis": (2, .35),
    "bode1": (2, .25),
    "tdomain": (2, .25),
}
ARCHITECTURES = ("LCL", "E-DCL", "CE")
NATIVE_ARCH = ("LCL", "E-DCL", "E-DCL")
NATIVE_AA = ("Thr", "Phe", "Ala", "Pro", "Trp")
# Molecular carbon counts of the free amino acid, including backbone.
CARBONS = {
    "Ala": 3, "Arg": 6, "Asn": 4, "Asp": 4, "Cys": 3, "Dab": 4,
    "Gln": 5, "Glu": 5, "Gly": 2, "His": 6, "Ile": 6, "Leu": 6,
    "Lys": 6, "Met": 5, "Phe": 9, "Pro": 5, "Ser": 3, "Thr": 4,
    "Trp": 11, "Tyr": 9, "Val": 5, "beta-Ala": 3,
}
AA_DIM = 9
REGIONAL_DIM = 9


def _read(path):
    return json.loads(Path(path).read_text())


def _aa_descriptor(aa, inferred_d):
    return (
        CARBONS[aa] / 11,
        float(aa in {"Arg", "Lys", "Dab"}),
        float(aa in {"Asp", "Glu"}),
        float(aa in {"Arg", "Asn", "Asp", "Cys", "Dab", "Gln", "Glu", "His", "Lys", "Ser", "Thr", "Tyr"}),
        float(aa in {"His", "Phe", "Trp", "Tyr"}),
        float(aa in {"His", "Phe", "Pro", "Trp", "Tyr"}),
        float(aa in {"Ile", "Thr", "Val"}),
        float(aa == "beta-Ala"),
        float(inferred_d and aa not in {"Gly", "beta-Ala"}),
    )


class Bode2Design:
    """Static model inputs from verified donor blocks and pre-assay metadata."""

    def __init__(self, assets=ASSETS):
        with (assets / "donors.csv").open(newline="") as stream:
            rows = list(csv.DictReader(stream))
        self.donors = {r["donor_id"]: r for r in rows}
        self.blocks = _read(assets / "verified_block_domains.json")
        require(len(self.donors) == len(rows) == 35 and len(self.blocks) == 3 and
                all(set(table) == set(self.donors) | {"native"} for table in self.blocks),
                "BODE2 design registry has an unexpected donor/position set")

    def features(self, record, donor_codes):
        """Return verified block assignments, seam indices, and chemistry.

        Each source block may include fixed terminal flanks. Both identified
        block seams are adjacent to the verified domain sequences. Chemistry is
        inferred from source A specificity and C/E architecture before assays.
        """
        require(len(donor_codes) == 3, "Expected donors for XUT2/3/4")
        route = record["route"]
        require(len(route) % 2 == 1 and all(
            (obj["kind"] == 0 if j % 2 == 0 else obj["kind"] in (1, 2))
            for j, obj in enumerate(route)
        ), "Expected an alternating domain/connection BODE2 route")
        blocks = [table[donor] for table, donor in zip(self.blocks, donor_codes)]
        actual = [[o["domain_type"], o["seq_hash"]] for o in route if o["kind"] == 0]
        require(actual == [domain for block in blocks for domain in block],
                "Live route domains differ from verified BODE2 block registry: " + record["assembly_id"])
        assignments = np.full(len(route), -1, dtype=np.int64)
        seams = []
        offset = 0
        for position, block in enumerate(blocks):
            next_offset = offset + len(block) * 2
            assignments[offset:next_offset - 1] = position
            if position < 2:
                seams.append(next_offset - 1)
            offset = next_offset

        expected = list(NATIVE_AA)
        architectures = list(NATIVE_ARCH)
        regional = []
        for i, code in enumerate(donor_codes):
            p = i + 2
            if code == "native":
                similarity = [1.] * 5
            else:
                donor = self.donors[code]
                expected[i + 1] = donor["aa"]
                architectures[i] = donor["architecture"]
                similarity = [float(donor["source_te_similarity"])]
                similarity.extend(float(donor[f"{kind}_identity_xut{p}"]) for kind in ("t", "c", "a", "tca"))
            require(architectures[i] in ARCHITECTURES and all(0 <= val <= 1 for val in similarity),
                    "Invalid BODE2 regional identity or C/E annotation")
            regional.append([float(code != "native"), *similarity,
                             *(float(architectures[i] == label) for label in ARCHITECTURES)])
        d = [a in ("E-DCL", "CE") for a in architectures] + [False, False]
        chemistry = [_aa_descriptor(a, epimerized) for a, epimerized in zip(expected, d)]
        return assignments, seams, chemistry, regional, tuple(expected)

    def batch_static(self, records, donor_codes, device):
        """Build the trained readout's static inputs for BODE2 design inference."""
        require(records, "Empty BODE2 design batch")
        width = max(len(rec["route"]) for rec in records)
        blocks = np.full((len(records), width), -1, dtype=np.int64)
        seams, chemistry, regional = [], [], []
        for i, (record, codes) in enumerate(zip(records, donor_codes, strict=True)):
            assignments, seam_indices, aa, similarity, _ = self.features(record, codes)
            blocks[i, :len(assignments)] = assignments
            seams.append(seam_indices)
            chemistry.append(aa)
            regional.append(similarity)
        return dict(blocks=torch.as_tensor(blocks, device=device),
                    assay=torch.full((len(records),), ASSAYS["bode2"], dtype=torch.long, device=device),
                    seams=torch.tensor(seams, dtype=torch.long, device=device),
                    chemistry=torch.tensor(chemistry, dtype=torch.float32, device=device),
                    regional=torch.tensor(regional, dtype=torch.float32, device=device))


def _donors_from_single(row):
    position = row["metadata"]["exchange_position"]
    group = row["group"]
    require(position in (2, 3, 4) and group.startswith("donor:pIG"), "Malformed BODE2 donor grouping")
    return tuple(group.removeprefix("donor:pIG") if p == position else "native" for p in (2, 3, 4))


def _mean(hidden, mask):
    return (hidden * mask.unsqueeze(-1)).sum(dim=1) / mask.sum(dim=1, keepdim=True).clamp_min(1)


class ActivityHead(nn.Module):
    """Assay-specific linear readout over a small shared sequence projection."""

    def __init__(self, width, latent=12):
        super().__init__()
        self.project = nn.Linear(width, latent, bias=False)
        self.dropout = nn.Dropout(.2)
        # Domain/connection representations and directed triplets at both connection kinds.
        self.global_logits = nn.Linear(13 * latent + 3, len(ASSAYS))
        # Per-block representations, adjacent block product/delta and real interface features,
        # and ordered chemistry and regional similarity features.
        self.bode2_logits = nn.Linear(17 * latent + 5 * AA_DIM + 8 * AA_DIM + 3 * REGIONAL_DIM, 1)

    def forward(self, hidden, batch, static):
        h = self.project(hidden).tanh()
        valid, kind = batch["valid"], batch["kind"]
        kind_masks = [valid & (kind == k) for k in range(3)]
        pooled = [_mean(h, mask) for mask in kind_masks]
        left, mid, right = h[:, :-2], h[:, 1:-1], h[:, 2:]
        directed = torch.cat([left, mid, right, left * right, right - left], dim=-1)
        edges = [
            _mean(directed, mask[:, 1:-1] & kind_masks[0][:, :-2] & kind_masks[0][:, 2:])
            for mask in kind_masks[1:]
        ]
        counts = torch.stack([mask.sum(dim=1).float().log1p() for mask in kind_masks], dim=1)
        logits = self.global_logits(self.dropout(torch.cat([*pooled, *edges, counts], dim=1)))
        assay = static["assay"]
        logit = logits.gather(1, assay.unsqueeze(1)).squeeze(1)

        units = torch.stack([_mean(h, valid & (static["blocks"] == i)) for i in range(3)], dim=1)
        uleft, uright = units[:, :-1], units[:, 1:]
        # The clamped gather supplies a placeholder only. The BODE2 branch is gated
        # off for other assays, which lack audited XUT positions.
        s = static["seams"].clamp_min(1)
        n = torch.arange(h.shape[0], device=h.device).unsqueeze(1)
        a, b, c = h[n, s - 1], h[n, s], h[n, s + 1]
        pair = torch.cat([uleft * uright, uright - uleft, a, b, c, a * c, c - a], dim=-1)
        aa = static["chemistry"]
        aa_left, aa_right = aa[:, :-1], aa[:, 1:]
        composition = torch.cat([aa_left * aa_right, aa_right - aa_left], dim=-1)
        inputs = [x.flatten(1) for x in (units, pair, aa, composition, static["regional"])]
        position_logit = self.bode2_logits(self.dropout(torch.cat(inputs, dim=1))).squeeze(1)
        return logit + position_logit * (assay == ASSAYS["bode2"])


class SupervisedData:
    def __init__(self, root, device, threads=8, verified_hashes=None):
        self.device = torch.device(device)
        metadata = _read(ASSETS / "reviewed_labels.json")
        original = metadata["rows"]
        require(metadata["patrick_label_revision"]["corrected_bode1_labels"] == 22 and
                sum(r["observed_activity"] != r["archived_activity"] for r in original
                    if r["dataset"] == "bode1") == 22 and
                all(r["label_source"] == "BODE1_Figure3_verified_D_pIN264_E_pIN244"
                    for r in original if r["dataset"] == "bode1"),
                "Corrected BODE1 label provenance differs")
        require(all(type(r["observed_activity"]) is int and r["observed_activity"] in (0, 1)
                    for r in original), "Non-binary construct activity label")
        self.runtime = NeuralRuntime(root, original, device=str(self.device),
                                     threads=threads, verified_hashes=verified_hashes)
        self.design = Bode2Design()
        self.rows = [dict(r) for r in original]
        donor_codes = [
            _donors_from_single(row) if row["dataset"] == "bode2" else None
            for row in self.rows
        ]
        self.records = list(self.runtime.records)
        self.cohorts = [
            "singles" if row["dataset"] == "bode2" else row["dataset"]
            for row in self.rows
        ]
        records, parents = load_inputs(ASSETS / "known_multis_model_inputs.json.gz")
        vectors, bank_report = load_feature_bank(ASSETS, records, parents)
        labels = _read(ASSETS / "multi_labels.json")
        require(len(records) == len(labels) == 60, "Wrong multi-source cohort size")
        self.multi_records = []
        conflicts = []
        for rec, row in zip(records, labels, strict=True):
            donors = tuple(row[f"donor_xut{i}"] for i in (2, 3, 4))
            require(rec["assembly_id"] == row["assembly_id"] and tuple(rec["donors"]) == donors
                    and rec["dataset"] == "bode2" and rec["cohort"] == row["dataset"],
                    "Multi label/design identity differs")
            if row["source_conflict"] == "1":
                conflicts.append(row["assembly_id"])
                continue
            require(row["source_conflict"] == "0" and row["produced"] in ("0", "1") and
                    row["dataset"] in ("doubles", "triples") and
                    sum(d != "native" for d in donors) == {"doubles": 2, "triples": 3}[row["dataset"]],
                    "Invalid resolved multi label")
            self.multi_records.append(rec)
            self.records.append(rec)
            self.rows.append(dict(dataset="bode2", assembly_id=row["assembly_id"],
                                  observed_activity=int(row["produced"])))
            self.cohorts.append(row["dataset"])
            donor_codes.append(donors)
        require(len(conflicts) == 2 and len(self.rows) == 552, "Wrong resolved labelled cohort")
        self.multi_master = {
            key: tensor.to(self.device)
            for key, tensor in collate_records(self.multi_records, vectors.__getitem__).items()
        }

        split = _read(ASSETS / "donor_fold00.json")
        held_groups = set(split["test_groups"])
        held_donors = {g.removeprefix("donor:pIG") for g in held_groups}
        singles = [i for i, c in enumerate(self.cohorts) if c == "singles"]
        require(len(held_donors) == 7 and split["fold"] == "fold00" and
                sorted(i for i in singles if self.rows[i]["group"] in held_groups) == split["test_indices"] and
                sorted(i for i in singles if self.rows[i]["group"] not in held_groups) == split["train_indices"],
                "BODE2 single-fold holdout changed")
        held = [i for i, codes in enumerate(donor_codes) if codes and held_donors.intersection(codes)]
        require(Counter(self.cohorts[i] for i in held) == {"singles": 21, "doubles": 5, "triples": 15},
                "BODE2 multi holdout coverage differs")
        held_fingerprints = {_route_fingerprint(self.records[i]) for i in held}
        require(len(held_fingerprints) == len(held), "Duplicate protected BODE2 routes")
        donor_hashes = set().union(*(set(self.runtime.overlap_audit["groups"][g]["donor_specific_primary_domain_hashes"])
                                    for g in held_groups))
        require(donor_hashes, "No held-donor exact domain evidence")
        exclusions = set().union(*(set(self.runtime.overlap_audit["auxiliary_exclusions"][g])
                                   for g in held_groups))
        self.training = {k: [] for k in COHORT_BATCHES}
        fingerprints = set(held_fingerprints)
        excluded = []
        # Prefer BODE2 if an exact duplicate appears in an auxiliary cohort.
        ordered = sorted(set(range(len(self.rows))) - set(held),
                         key=lambda i: (ASSAYS[self.rows[i]["dataset"]], i))
        for i in ordered:
            row = self.rows[i]
            fingerprint = _route_fingerprint(self.records[i])
            shares_held_domain = any(s["state"] == "OBSERVED" and s["kind"] == 0 and
                                     s["sequence_hash"] in donor_hashes
                                     for s in self.records[i]["model_slots"])
            if i in exclusions or shares_held_domain or fingerprint in fingerprints:
                excluded.append(dict(assembly_id=row["assembly_id"], dataset=row["dataset"],
                                     exact_donor_domain=shares_held_domain,
                                     archived_auxiliary_exclusion=i in exclusions,
                                     duplicate_route=fingerprint in fingerprints))
                continue
            fingerprints.add(fingerprint)
            cohort = self.cohorts[i]
            self.training["multis" if cohort in ("doubles", "triples") else cohort].append(i)
        require(all(len(self.training[c]) >= n for c, (n, _) in COHORT_BATCHES.items()),
                "Insufficient protected training rows in one assay")
        self.held = held
        width = max(len(r["route"]) for r in self.records)
        static = dict(
            blocks=np.full((len(self.rows), width), -1, dtype=np.int64),
            seams=np.zeros((len(self.rows), 2), dtype=np.int64),
            chemistry=np.zeros((len(self.rows), 5, AA_DIM), dtype=np.float32),
            regional=np.zeros((len(self.rows), 3, REGIONAL_DIM), dtype=np.float32),
            assay=np.array([ASSAYS[r["dataset"]] for r in self.rows], dtype=np.int64),
        )
        for i, codes in enumerate(donor_codes):
            if codes is None:
                continue
            assignments, seams, chemistry, regional, expected = self.design.features(self.records[i], codes)
            if self.cohorts[i] == "singles":
                require(expected == tuple(self.rows[i]["metadata"]["expected_aa"]),
                        "BODE2 expected substrate annotation differs from Patrick input")
            static["blocks"][i, :len(assignments)] = assignments
            static["seams"][i] = seams
            static["chemistry"][i] = chemistry
            static["regional"][i] = regional
        self.static = {k: torch.as_tensor(v, device=self.device) for k, v in static.items()}
        self.labels = torch.tensor([r["observed_activity"] for r in self.rows],
                                   device=self.device, dtype=torch.float32)
        self.manifest = dict(
            schema="joint_assay_supervision_v1",
            labelled_cache=self.runtime.identity,
            known_multi_feature_bank_sha256=bank_report["feature_bank_sha256"],
            head_schema=dict(sequence_projection_width=12, dropout=.2, assays=ASSAYS,
                             input="clean sequence context, covalent/break topology, exact BODE2 blocks/seams, "
                                   "intended chemistry, inferred epimerization and source T/C/A/TCA/TE identity"),
            split="Patrick outer fold00 and all known multis containing any held donor",
            held_donors=sorted(held_donors),
            held_ids=[self.rows[i]["assembly_id"] for i in held],
            excluded_conflicts=conflicts,
            exact_overlap_exclusions=excluded,
            train_ids={c: [self.rows[i]["assembly_id"] for i in ix] for c, ix in self.training.items()},
            train_by_cohort=dict(Counter(self.cohorts[i] for ix in self.training.values() for i in ix)),
            held_by_cohort=dict(Counter(self.cohorts[i] for i in held)),
            sample_counts_and_weights=COHORT_BATCHES,
            evaluation="Fixed retrospective BODE2 donor holdout; no homology purge or prospective evidence",
            calibration="Uncalibrated activity scores; the protected holdout is not used to fit calibration",
            chemistry="Only verified BODE2 donor inputs. BODE1 and T-domain supply structural supervision.",
            source_te_similarity="Source workbook TE similarity; terminal span unverified",
        )

    def head(self, width):
        return ActivityHead(width).to(self.device)

    def _batch(self, indices):
        old = len(self.runtime.records)
        take = [i for i in indices if i < old]
        multi = [i - old for i in indices if i >= old]
        length = max(3, max(len(self.records[i]["route"]) for i in indices))
        parts = []
        if take:
            parts.append(self.runtime.batch(take))
        if multi:
            index = torch.tensor(multi, device=self.device)
            parts.append({key: value[:, :length].index_select(0, index)
                          for key, value in self.multi_master.items()})
        batch = {}
        for key in parts[0]:
            values = []
            for part in parts:
                v = part[key]
                shape = (v.shape[0], length - v.shape[1], *v.shape[2:])
                values.append(torch.cat([v, v.new_full(shape, -1 if key == "chain" else 0)], dim=1))
            batch[key] = torch.cat(values, dim=0)
        # Restore caller order after gathering separately from the two cached pools.
        ordered = take + [i + old for i in multi]
        inverse = {i: p for p, i in enumerate(ordered)}
        permute = torch.tensor([inverse[i] for i in indices], device=self.device)
        batch = {k: v.index_select(0, permute) for k, v in batch.items()}
        index = torch.tensor(indices, device=self.device)
        static = {k: v.index_select(0, index) for k, v in self.static.items()}
        static["blocks"] = static["blocks"][:, :length]
        return batch, static, self.labels.index_select(0, index)

    def loss(self, encoder, head, step, detach_encoder=False):
        rng = random.Random(20261107 + step)
        indices = [i for cohort, (n, _) in COHORT_BATCHES.items()
                   for i in rng.sample(self.training[cohort], n)]
        batch, static, y = self._batch(indices)
        if detach_encoder:
            with torch.no_grad():
                hidden = encoder.features(batch)
        else:
            hidden = encoder.features(batch)
        scores = head(hidden, batch, static)
        losses = F.binary_cross_entropy_with_logits(scores, y, reduction="none")
        offset = 0
        total = losses.new_zeros(())
        for n, weight in COHORT_BATCHES.values():
            total = total + weight * losses[offset:offset + n].mean()
            offset += n
        return total / sum(w for _, w in COHORT_BATCHES.values())

    @torch.no_grad()
    def evaluate(self, encoder, head):
        previous_encoder_mode, previous_head_mode = encoder.training, head.training
        encoder.eval()
        head.eval()
        predictions = []
        try:
            for start in range(0, len(self.held), 8):
                ix = self.held[start:start + 8]
                batch, static, y = self._batch(ix)
                score = head(encoder.features(batch), batch, static).double()
                require(bool(torch.isfinite(score).all()), "Non-finite held-out activity logits")
                for i, label, logit in zip(ix, y.tolist(), score.tolist()):
                    predictions.append(dict(assembly_id=self.rows[i]["assembly_id"],
                                            cohort=self.cohorts[i], observed_activity=int(label),
                                            logit=logit))
        finally:
            encoder.train(previous_encoder_mode)
            head.train(previous_head_mode)
        metrics = {}
        for cohort in ("singles", "doubles", "triples"):
            chosen = [r for r in predictions if r["cohort"] == cohort]
            y = np.array([r["observed_activity"] for r in chosen], dtype=np.float64)
            logit = np.array([r["logit"] for r in chosen], dtype=np.float64)
            p = np.exp(-np.logaddexp(0., -logit))
            train = self.training["singles"] if cohort == "singles" else [
                i for i in self.training["multis"] if self.cohorts[i] == cohort]
            require(train, "Empty reference training cohort")
            # Jeffreys smoothing keeps a well-defined loss in a tiny one-class sample.
            prevalence = (sum(self.rows[i]["observed_activity"] for i in train) + .5) / (len(train) + 1)
            positives, negatives = p[y == 1], p[y == 0]
            diff = positives[:, None] - negatives
            auroc = float(((diff > 0) + .5 * (diff == 0)).mean()) if diff.size else None
            ap = 0.
            if len(positives):
                for threshold in np.unique(p):
                    selected = p >= threshold
                    ap += (y[p == threshold].sum() / len(positives)) * y[selected].mean()
            metrics[cohort] = dict(
                n=len(y), positives=int(y.sum()), auroc=auroc,
                average_precision=float(ap) if len(positives) else None,
                log_loss=float(np.logaddexp(0., (1. - 2. * y) * logit).mean()),
                brier=float(((p - y) ** 2).mean()),
                training_prevalence=float(prevalence),
                prevalence_log_loss=float(-(y * np.log(prevalence) +
                                            (1. - y) * np.log1p(-prevalence)).mean()),
                prevalence_brier=float(((prevalence - y) ** 2).mean()),
            )
        historical = _read(ASSETS / "historical_fold00.json")
        prior = {r["assembly_id"]: r["label"]
                 for panel in historical["panels"].values() for r in panel["rows"]}
        observed = {r["assembly_id"]: r["observed_activity"] for r in predictions}
        require(prior == observed and historical["held_donors"] == self.manifest["held_donors"],
                "Historical fold baseline IDs/labels differ from this holdout")
        return dict(metrics=metrics, predictions=predictions, held_donors=self.manifest["held_donors"],
                    interpretation=self.manifest["evaluation"], calibrated=False,
                    historical_comparison=dict(
                        metrics={k: v["metrics"] for k, v in historical["panels"].items()},
                        limits=historical["limits"]))
