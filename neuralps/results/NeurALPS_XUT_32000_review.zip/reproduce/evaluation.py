"""Fixed natural dev comparisons and a checkpoint-specific diagnostic reference."""
from __future__ import annotations

from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import random

import numpy as np
import torch


REFERENCE_MANIFEST = 'e8_reference_scale_652486/split_manifest.json'
REFERENCE_MANIFEST_SHA256 = 'c478cc17d551321975d8a1b546759212ff0d1c4ad05260645dba9fc5439b9d8b'
REFERENCE_VERSION = 'nrps_combined_xut_natural_diagnostics_v2'


def _sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def _write_json(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


class NaturalEvaluation:
    """Build dev masks once and reuse the identical records, targets and panels.

    Use the original sampler and panel rules for the original-view row. The
    structured rows have their own eligibility and denominator. Comparisons
    between checkpoints are meaningful within each policy on this dev subset.
    """

    def __init__(self, ssl, store, targets, cfg, choose_plan, device, limit=192, *, structured_policies):
        from assembly_model import collate_records, MASKED
        from masking_contract import masking_closure
        from ssl_changes import plan_from_targets

        if limit < 1:
            raise ValueError('Natural evaluation requires a positive dev limit')
        self.structured_policies = tuple(structured_policies)
        if (not self.structured_policies or len(set(self.structured_policies)) != len(self.structured_policies)
                or {'original', 'single_object'}.intersection(self.structured_policies)):
            raise ValueError('Expected distinct structured mask policies')
        self.ssl, self.store, self.targets = ssl, store, targets
        self.cfg, self.device, self.choose_plan = cfg, device, choose_plan
        self.collate, self.masked = collate_records, MASKED
        self.closure, self.plan_from_targets = masking_closure, plan_from_targets
        self.micro = cfg['micro']
        data_seed = cfg['data_seed']
        ids = targets.manifest['ids']['dev']
        self.dev_ids = [aid for aid, _ in sorted(
            ids, key=lambda row: ssl.seed(data_seed, 'dev_subset', row[0]))[:limit]]
        self.views = {kind: [] for kind in ('original', *self.structured_policies)}
        for aid in self.dev_ids:
            record = store.record(aid, 'dev')
            for kind in self.views:
                seed = ssl.seed(data_seed, 'dev_mask' if kind == 'original' else 'fixed_dev_' + kind, aid)
                plan = self._plan(record, kind, seed)
                if plan is not None:
                    self.views[kind].append((record, plan))
        if not self.views['original']:
            raise RuntimeError('No eligible original natural dev views')

    def _plan(self, record, kind, seed):
        rng = random.Random(seed)
        if kind == 'original':
            return self.ssl.choose_view(record, self.store.parent, rng, self.closure)
        return self.choose_plan(record, self.store.parent, rng, self.closure, kind)

    def manifest(self):
        return {
            'split': 'natural_dev',
            'interpretation': 'Checkpoint comparison within fixed mask policies on the existing development split',
            'activity_labels_used': False,
            'pretraining_family_independence_verified': False,
            'sampled_assembly_ids': self.dev_ids,
            'structured_mask_policies': list(self.structured_policies),
            'policies': {kind: [
                {'assembly_id': record['assembly_id'],
                 'primary': {j: [s['slot'] for s in slots] for j, slots in plan['primary'].items()},
                 'hidden': plan['hidden']} for record, plan in views
            ] for kind, views in self.views.items()},
        }

    def _predict(self, model, plans):
        batch = self.ssl.tensors(plans, self.store, self.collate, self.masked, self.device)
        prediction = model.predict_masked(batch)
        if not torch.isfinite(prediction).all().item():
            raise RuntimeError('Nonfinite natural reconstruction prediction')
        return prediction

    def _scores(self, prediction, plans):
        """Evaluate native targets without drawing candidate negatives."""
        indices, slots, relations = [], [], []
        for b, (record, plan) in enumerate(plans):
            for j, roles in plan['primary'].items():
                start = len(slots)
                for s in roles:
                    indices.append((b, j, s['slot']))
                    slots.append(s)
                relations.append((record, j, roles, start, len(slots), plan['fraction'],
                                  len(plan['primary'])))
        if not slots:
            return
        selector = tuple(torch.as_tensor(v, device=prediction.device) for v in zip(*indices))
        z = torch.as_tensor(np.stack([self.store.vector(s['sequence_hash']) for s in slots]),
                            device=prediction.device)
        mu = torch.as_tensor(np.stack([self.targets.mean(s) for s in slots]), device=prediction.device)
        mixed, raw = self.ssl.slot_loss(prediction[selector], z, mu, self.targets.loss_variant)
        scores = torch.stack((1 - mixed, 1 - raw), dim=-1).detach().cpu().numpy()
        if not np.isfinite(scores).all() or np.abs(scores).max() > 1.00001:
            raise RuntimeError('Invalid cosine reconstruction similarity')
        for record, j, roles, start, stop, fraction, primary_count in relations:
            yield record, j, roles, fraction, primary_count, scores[start:stop].mean(axis=0)

    def evaluate(self, model):
        result = {}
        was_training = model.training
        model.eval()
        try:
            with torch.no_grad():
                for kind, plans in self.views.items():
                    totals = Counter()
                    by_kind = defaultdict(lambda: [0, 0., 0.])
                    for start in range(0, len(plans), self.micro):
                        batch = plans[start:start + self.micro]
                        pred = self._predict(model, batch)
                        _, metrics = self.ssl.losses(pred, batch, self.targets,
                            ('dev_panel', self.cfg['data_seed']), self.cfg['rank_weight'])
                        totals.update(metrics)
                        for _, _, roles, _, _, (mixed, raw) in self._scores(pred, batch):
                            accum = by_kind[roles[0]['kind']]
                            accum[0] += 1
                            accum[1] += float(mixed)
                            accum[2] += float(raw)
                    counts = {
                        'attempted': len(self.dev_ids),
                        'eligible': len(plans),
                        'views_by_primary_object_count': dict(sorted(Counter(
                            len(plan['primary']) for _, plan in plans).items())),
                    }
                    result[kind] = dict(counts, metrics=None, per_object_kind={})
                    if plans:
                        result[kind]['metrics'] = self.ssl.clean_metrics(totals)
                        result[kind]['per_object_kind'] = {
                            str(k): {'objects': n, 'mixed_similarity_mean': mixed / n,
                                     'raw_cosine_mean': raw / n}
                            for k, (n, mixed, raw) in sorted(by_kind.items())
                        }
        finally:
            model.train(was_training)
        return result

    def _reference_plans(self, record):
        for j, slots in self.ssl.observed(record).items():
            required = [1, 2] if record['route'][j]['kind'] == 2 else [0]
            if [s['slot'] for s in slots] != required:
                continue
            plan = self.plan_from_targets(record, self.store.parent, self.closure, [j])
            if plan is not None:
                yield 'single_object', plan
        for kind in self.structured_policies:
            seed = self.ssl.seed(20261107, 'reference', kind, record['assembly_id'])
            plan = self._plan(record, kind, seed)
            if plan is not None:
                yield kind, plan

    def write_reference(self, model, root, out, checkpoint_sha256, stopping=None, limit=192):
        """Export bounded native-score samples from the declared E8 calibration role.

        The raw rows retain grouping variables and support. They are available
        for checkpoint/mask-matched empirical comparisons, not an activity scale.
        A missing, changed or interrupted source never falls back to old scores.
        """
        out = Path(out)
        meta_file = out / 'natural_reference.json'
        source = Path(root) / REFERENCE_MANIFEST
        meta = {
            'schema': REFERENCE_VERSION,
            'checkpoint_sha256': checkpoint_sha256,
            'source_split_manifest': REFERENCE_MANIFEST,
            'source_split_manifest_sha256': REFERENCE_MANIFEST_SHA256,
            'source_role': 'calibration',
            'source_split': 'natural_internal_test_repurposed_for_calibration_and_audit',
            'scale': '1 minus the mean role reconstruction loss in each queried object',
            'loss_variant': self.targets.loss_variant,
            'interpretation': 'Natural diagnostic similarity conditional on mask policy; raw samples with support, not activity probability',
            'pretraining_family_independence_verified': False,
            'structured_mask_policies': list(self.structured_policies),
            'xut_scope': 'Natural XUT views are projections onto cached physical objects. Exact engineered residue cuts require their own matching reference.',
        }

        def finish(status, reason=None):
            meta['status'] = status
            if reason is not None:
                meta['reason'] = reason
            _write_json(meta_file, meta)
            return meta

        if stopping is not None and stopping():
            return finish('UNAVAILABLE', 'Training stop requested before reference scoring')
        if limit < 1:
            return finish('UNAVAILABLE', 'Reference scoring disabled by its sample limit')
        if not source.is_file():
            return finish('UNAVAILABLE', 'Pinned E8 calibration assignment is absent')
        if _sha(source) != REFERENCE_MANIFEST_SHA256:
            return finish('UNAVAILABLE', 'Pinned E8 calibration assignment has changed')
        split = json.loads(source.read_text())
        ids = [aid for aid, row in split['metadata'].items()
               if row['dataset'] == 'natural' and row['source_split'] == 'internal_test'
               and row['role'] == 'calibration']
        source_ids = {row[0] for key in ('train', 'dev') for row in self.targets.manifest['ids'][key]}
        if len(ids) != split['role_assembly_counts']['calibration'] or source_ids.intersection(ids):
            raise RuntimeError('Invalid or overlapping natural reference cohort')
        chosen = sorted(ids, key=lambda aid: self.ssl.seed(20261107, 'reference_subset', aid))[:limit]
        payload = out / 'natural_reference.jsonl.gz'
        tmp = payload.with_suffix('.gz.tmp')
        coverage = Counter()
        groups = Counter()
        skipped_missing = 0
        was_training = model.training
        model.eval()
        try:
            with torch.no_grad(), gzip.open(tmp, 'wt') as stream:
                for aid in chosen:
                    if stopping is not None and stopping():
                        return finish('UNAVAILABLE', 'Training stop requested during reference scoring')
                    record = self.store.record(aid, 'internal_test')
                    if any(s['sequence_hash'] not in self.store.rows for s in record['model_slots']
                           if s['state'] == 'OBSERVED'):
                        skipped_missing += 1
                        continue
                    by_policy = defaultdict(list)
                    for kind, plan in self._reference_plans(record):
                        by_policy[kind].append((record, plan))
                    for kind, plans in by_policy.items():
                        coverage[(kind, 'assemblies')] += 1
                        coverage[(kind, 'views')] += len(plans)
                        for start in range(0, len(plans), self.micro):
                            batch = plans[start:start + self.micro]
                            prediction = self._predict(model, batch)
                            for _, j, slots, fraction, primary_count, (mixed, raw) in self._scores(prediction, batch):
                                key = [kind, primary_count, slots[0]['kind'],
                                       [[s['slot'], s['group'], self.ssl.length_bin(s)] for s in slots]]
                                groups[json.dumps(key, separators=(',', ':'))] += 1
                                coverage[(kind, 'objects')] += 1
                                row = dict(assembly_id=aid, object_index=j, grouping_key=key,
                                    hidden_fraction=fraction, mixed_similarity=float(mixed), raw_cosine=float(raw))
                                stream.write(json.dumps(row, separators=(',', ':'), allow_nan=False) + '\n')
            meta.update(sampled_assembly_ids=chosen, available_source_assemblies=len(ids),
                skipped_missing_cache_assemblies=skipped_missing,
                coverage={kind: {k: coverage[(kind, k)] for k in ('assemblies', 'views', 'objects')}
                          for kind in ('single_object', *self.structured_policies)},
                grouping_key=['mask_policy', 'primary_object_count', 'object_kind',
                              '[role_index,target_group,log2_length_bin] per role'],
                group_support=dict(sorted(groups.items())))
            if not groups:
                return finish('UNAVAILABLE', 'No eligible cached reference views')
            tmp.replace(payload)
            meta.update(rows=payload.name, rows_sha256=_sha(payload))
            return finish('COMPLETE')
        finally:
            model.train(was_training)
            tmp.unlink(missing_ok=True)


def load_joint_candidate(root, out, device, *, load_activity=True):
    """Load the completed candidate for a separate, versioned inference entry point.

    The activity head's feature builder must follow the saved labelled manifest.
    An encoder-only caller can use the same masking and target-center contracts.
    """
    from train import VERSION, TARGET_MANIFEST_SHA, bundle_identity, pinned_modules
    from ssl_changes import enable_full_attention

    root, out = Path(root).resolve(), Path(out).resolve()
    completion = json.loads((out / 'COMPLETE.json').read_text())
    if (completion.get('status') != 'JOINT_CONTINUATION_COMPLETE' or
            completion.get('candidate_checkpoint') != 'latest.pt'):
        raise ValueError('Expected the completed joint continuation receipt')
    path = out / 'latest.pt'
    digest = _sha(path)
    if digest != completion['candidate_sha256']:
        raise ValueError('Candidate checkpoint differs from its completion receipt')
    saved = torch.load(path, map_location='cpu', weights_only=True)
    config = saved['config']
    if (config != json.loads((out / 'config.json').read_text()) or
            config.get('version') != VERSION or
            config.get('attention') != 'full_distance_with_radius6_clipped_bias' or
            config.get('natural_target_manifest_sha256') != TARGET_MANIFEST_SHA or
            config.get('sources') != bundle_identity() or
            saved.get('step') != config.get('final_step') or saved['step'] != completion.get('step')):
        raise ValueError('Unexpected checkpoint schema, architecture, provenance or step')
    ssl, _, _, _ = pinned_modules(root)
    encoder_cfg = config['settings']['encoder']
    model = ssl.build_model(encoder_cfg)
    model.load_state_dict(saved['encoder_state'], strict=True)
    enable_full_attention(model)
    model = model.to(device).eval().requires_grad_(False)
    head = None
    if load_activity:
        from supervised import ActivityHead
        head = ActivityHead(encoder_cfg['width'])
        head.load_state_dict(saved['activity_state'], strict=True)
        head = head.to(device).eval().requires_grad_(False)
    reference_path = out / 'natural_reference.json'
    reference = json.loads(reference_path.read_text())
    if reference.get('checkpoint_sha256') != digest:
        raise ValueError('Natural diagnostic reference belongs to another checkpoint')
    if reference.get('status') == 'COMPLETE':
        expected_name = 'natural_reference.jsonl.gz'
        if reference.get('rows') != expected_name or _sha(out / expected_name) != reference.get('rows_sha256'):
            raise ValueError('Natural diagnostic reference row file changed')
    return dict(model=model, head=head, config=config, checkpoint_sha256=digest,
                checkpoint_step=saved['step'], natural_reference=reference)
