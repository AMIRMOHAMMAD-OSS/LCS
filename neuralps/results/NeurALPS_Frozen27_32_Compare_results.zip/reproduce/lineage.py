"""Compute-side lineage checks for matched frozen checkpoint comparisons."""
from pathlib import Path
import json

BASELINE_REL='neuralps_frozen26_readout_20261107T211500Z_c4d6084d'
BASELINE_ZIP_SHA='2d607400ca29c4f4217399d881e790344c1571ef687d650ffb6b9fecc041113d'


def verify(root, protocol):
    from compare_readouts import validate_baseline
    root=Path(root).resolve()
    baseline=root/BASELINE_REL
    proof=validate_baseline(baseline)
    rows=json.loads((baseline/'rows.json').read_text())
    train={r['assembly_id'] for r in rows['rows'] if r['outer_role']=='train'}
    held={r['assembly_id'] for r in rows['rows'] if r['outer_role']=='held'}
    for key,cp in protocol['checkpoints'].items():
        folder=(root/cp['path']).parent
        config=json.loads((folder/'config.json').read_text())
        done=json.loads((folder/'COMPLETE.json').read_text())
        if not (done['status']=='JOINT_CONTINUATION_COMPLETE' and done['step']==cp['step']
                and done['candidate_sha256']==cp['sha256']):
            raise RuntimeError('Joint completion receipt differs: '+key)
        if config['attention']!='full_distance_with_radius6_clipped_bias':
            raise RuntimeError('Joint attention contract differs: '+key)
        labels=config['labelled']
        joint_train={x for ids in labels['train_ids'].values() for x in ids}
        if joint_train!=train or set(labels['held_ids'])!=held or set(labels['held_donors'])!=set(rows['outer_held_donors']):
            raise RuntimeError('Joint encoder and frozen26 readout outer splits differ: '+key)
    return dict(baseline=str(baseline), baseline_validation=proof,
                checkpoint_outer_split_match=True, outer_train_rows=len(train), outer_held_rows=len(held))
