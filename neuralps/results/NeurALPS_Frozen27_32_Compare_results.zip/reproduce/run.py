#!/usr/bin/env python3
"""Frozen27/32 comparison using the completed26-selected readout settings."""
from __future__ import annotations
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import sys
import time
import traceback

PACKAGE=Path(__file__).resolve().parent

def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def dump(p,x):
    p=Path(p);tmp=p.with_name(p.name+'.tmp')
    tmp.write_text(json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n');tmp.replace(p)

def require(ok,msg):
    if not ok:raise RuntimeError(msg)

class Paused(Exception):pass

def run(args):
    import submit
    root,out=args.root.resolve(),args.out.resolve()
    require(os.environ.get('SLURM_JOB_ID','').isdigit(),'Use submit.py in a Slurm allocation')
    require(out.parent==root and out.name.startswith(submit.PREFIX),'Unexpected output directory')
    fd=os.environ.get('NEURALPS_RUN_LOCK_FD','')
    require(fd.isdigit(),'Launch through submit.py worker to hold the output lock')
    fd=int(fd);a,b=os.fstat(fd),(out/'run.lock').stat()
    require((a.st_dev,a.st_ino)==(b.st_dev,b.st_ino),'Wrong inherited output lock')
    fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    digest=submit.package_digest();request=submit.read_request(root,out,digest)
    protocol=json.loads((PACKAGE/'protocol.json').read_text())
    identity=dict(package_manifest_sha256=digest,request_sha256=sha(out/'REQUEST.json'),
                  protocol_sha256=sha(PACKAGE/'protocol.json'))
    def emit(stage,**data):
        line=json.dumps(dict(stage=stage,**data),allow_nan=False)
        print(line,flush=True)
        with (out/'progress.jsonl').open('a') as f:f.write(line+'\n')
    def stop(signum,frame):raise Paused('Allocation received signal '+str(signum))
    for sig in (signal.SIGTERM,signal.SIGUSR1,signal.SIGINT):signal.signal(sig,stop)
    started=time.monotonic()
    try:
        emit('VERIFYING_COMPARISON_INPUTS',encoder_updates=0)
        current=submit.check_inputs(root,verify_hashes=True)
        require(current==request['inputs'],'Inputs changed after submission')
        import numpy as np
        import torch
        import sklearn
        require(torch.__version__.split('+')[0]=='2.8.0','Use pytorch-gpu/py3/2.8.0')
        require(torch.cuda.is_available() and torch.cuda.device_count()==1,'Allocate exactly one CUDA GPU')
        torch.set_num_threads(8);torch.manual_seed(20261108);np.random.seed(20261108)
        torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
        torch.use_deterministic_algorithms(True)
        from lineage import verify
        evidence=verify(root,protocol)
        baseline=Path(evidence['baseline'])
        dump(out/'lineage_check.json',evidence)
        if (out/'run_config.json').exists():
            require(json.loads((out/'run_config.json').read_text())['identity']==identity,'Run identity changed')
        else:
            dump(out/'run_config.json',dict(identity=identity,protocol=protocol,
                runtime=dict(python=sys.version,numpy=np.__version__,torch=torch.__version__,sklearn=sklearn.__version__),
                encoder_training=False,classifier_training=True,new_hyperparameter_search=False))
        def valid_stage(folder,name):
            p=folder/name
            if not p.exists():return False
            saved=json.loads(p.read_text())
            require(saved['identity']==identity,'Completed stage identity differs: '+str(p))
            for rel,d in saved['files'].items():
                target=(folder/rel).resolve()
                require(target.is_relative_to(folder) and target.is_file() and sha(target)==d,
                        'Completed stage payload changed: '+str(target))
            return True
        def commit(folder,name,paths):
            dump(folder/name,dict(identity=identity,files={str(p.relative_to(folder)):sha(p) for p in paths}))
        from joint_features import extract
        from compare_readouts import fit_checkpoint,compare
        from labelled_backend import PINNED_INPUTS
        for key in ('27000','32000'):
            folder=out/('step_'+key);folder.mkdir(exist_ok=True)
            if not valid_stage(folder,'FEATURE_STAGE.json'):
                emit('EXTRACTING_FROZEN_JOINT_FEATURES',step=int(key),attention='native full attention')
                extract(root,folder,key,device='cuda',threads=8,verified_hashes=dict(PINNED_INPUTS))
                paths=[folder/n for n in ('features.npz','features.json','rows.json','maps.jsonl.gz')]
                require(all(p.is_file() for p in paths),'Feature stage incomplete')
                commit(folder,'FEATURE_STAGE.json',paths)
            else:emit('REUSING_VERIFIED_FEATURE_CACHE',step=int(key))
            if not valid_stage(folder,'FIT_STAGE.json'):
                emit('REFITTING_FIXED_READOUTS',step=int(key),C_source='sealed26k internal selection',new_C_search=False)
                fit_checkpoint(folder,baseline,protocol,PACKAGE)
                paths=[folder/n for n in ('readout_transfer.json','activity_holdout.json','readout_summary.json')]
                paths.extend(sorted(p for p in (folder/'models').rglob('*') if p.is_file()))
                require(all(p.is_file() for p in paths),'Readout stage incomplete')
                commit(folder,'FIT_STAGE.json',paths)
            else:emit('REUSING_VERIFIED_READOUT_RESULTS',step=int(key))
        # Retain the original sealed26 review as a nested archive for independent reanalysis.
        target=out/'baseline26_inspection.zip'
        if not target.exists():
            tmp=out/'baseline26_inspection.zip.tmp';shutil.copyfile(baseline/'inspection.zip',tmp);tmp.replace(target)
        require(sha(target)==protocol['baseline26']['inspection_sha256'],'Copied baseline archive differs')
        originals=out/'original_joint_heads';originals.mkdir(exist_ok=True)
        for key,cp in protocol['checkpoints'].items():
            shutil.copyfile((root/cp['path']).parent/'activity_holdout.json',originals/('step_'+key+'_activity.json'))
        compare(out,baseline,protocol,PACKAGE)
        dump(out/'COMPLETE.json',dict(status='FROZEN2732_COMPARISON_COMPLETE',**identity,
            checkpoint_steps=[26000,27000,32000],encoder_updates=0,classifier_training=True,
            new_hyperparameter_search=False,primary_panel=protocol['primary_panel'],
            baseline26_inspection_sha256=protocol['baseline26']['inspection_sha256'],
            retrospective=True,calibrated=False,elapsed_seconds=round(time.monotonic()-started,2),
            completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())))
        for n in ('pause.json','fatal_error.json'):(out/n).unlink(missing_ok=True)
        emit('FROZEN2732_COMPARISON_COMPLETE',encoder_updates=0,new_C_search=False)
        from export_review import export
        archive,checksum=export(out,PACKAGE)
        print('RESULT_ZIP:',archive,flush=True);print('RESULT_SHA256:',checksum,flush=True)
        return 0
    except Paused as exc:
        dump(out/'pause.json',dict(status='PAUSED',reason=str(exc),resume='submit.py resume '+str(out)))
        emit('PAUSED',reason=str(exc));return 75
    except Exception as exc:
        dump(out/'fatal_error.json',dict(status='FAILED',error=str(exc),traceback=traceback.format_exc()));raise

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    return run(p.parse_args())

if __name__=='__main__':sys.exit(main())
