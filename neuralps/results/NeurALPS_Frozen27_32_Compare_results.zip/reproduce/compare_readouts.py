#!/usr/bin/env python3
"""Refit identical small readouts on frozen 27k/32k features with 26k-selected C.

This deliberately performs no new internal CV: the joint encoders already saw
the outer-training activity labels. The fixed outer holdout remains retrospective.
"""
from __future__ import annotations

import json
from pathlib import Path
import zipfile

import numpy as np

import fit_readout as base

VERSION = 'frozen2732_readout_comparison_v1'
BASELINE_ZIP_SHA = '2d607400ca29c4f4217399d881e790344c1571ef687d650ffb6b9fecc041113d'
BASELINE_MANIFEST_SHA = 'c4d6084d4efd79134f4aa7afe39f7afa3e37e1da75eb043f76eb1bdf738e13ba'
BASELINE_PROTOCOL_SHA = '66aaab6b3e48df79b332a31c05ffb8c3439392550f21bd5d4e05fe4b6cbdc030'
BASELINE_FEATURE_SOURCE_SHA = '2130632ff51639a26f2269e3294e0a44b666aa963871f3803382f891310cbfaa'
BASELINE_READOUT_SOURCE_SHA = '4aa8492d12193399ffcc9624e46be926bdf78560173ccc0cf2e03b2757fbacc7'
CHECKPOINTS = {
    26000:'9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f',
    27000:'bb78635c63d7a29ba77fc0ff09203ecc92a7938fd216e269716243e5d104a66c',
    32000:'ba62c4c3c1d8f6606c14c57fb0770d8ecfd7c9ea8eefc35424d2aa1197923e7a',
}
BLOCKS = ('context','chemistry','compatibility','structure')
BASE_FILES = ('COMPLETE.json','features.json','features.npz','rows.json',
              'readout_selection.json','activity_holdout.json')
METRICS = ('auroc','average_precision','brier','log_loss')


def load(path):
    return json.loads(Path(path).read_text())


def panel_names():
    return [f'{panel}_{source}' for panel in base.PANELS for source in base.SOURCES]


def validate_baseline(directory):
    """Authenticate the live reused files against the exact completed review ZIP."""
    directory=Path(directory)
    base.require(base.sha(base.__file__)==BASELINE_READOUT_SOURCE_SHA,
                 'The inherited frozen26 readout implementation changed')
    archive=directory/'inspection.zip'
    base.require(base.sha(archive)==BASELINE_ZIP_SHA, 'The completed 26k result archive differs')
    with zipfile.ZipFile(archive) as z:
        manifest=json.loads(z.read('REVIEW_MANIFEST.json'))
        for name in BASE_FILES:
            entry=manifest['files'][name]
            expected=entry['sha256'] if isinstance(entry,dict) else entry
            base.require(base.sha(directory/name)==expected,
                         'Live 26k result differs from its sealed review archive: '+name)
    done=load(directory/'COMPLETE.json')
    base.require(done['status']=='FROZEN26_READOUT_COMPLETE' and
                 done['package_manifest_sha256']==BASELINE_MANIFEST_SHA and
                 done['protocol_sha256']==BASELINE_PROTOCOL_SHA and
                 done['checkpoint_sha256']==CHECKPOINTS[26000] and
                 done['encoder_updates']==0 and done['checkpoint_step']==26000,
                 'The baseline is not the completed original frozen26 readout run')
    feature=load(directory/'features.json')
    base.require(feature['status']=='FROZEN_FEATURES_COMPLETE' and
                 feature['checkpoint_step']==26000 and
                 feature['checkpoint_sha256']==CHECKPOINTS[26000] and
                 feature['activity_labels_used_by_encoder'] is False and
                 feature['source_code_sha256']==BASELINE_FEATURE_SOURCE_SHA and
                 feature['encoder_state_sha256_before']==feature['encoder_state_sha256_after'],
                 'The baseline feature cache does not prove unchanged pre-label 26k weights')
    for name in ('features.npz','rows.json'):
        base.require(base.sha(directory/name)==feature['payload_sha256'][name],
                     'Baseline feature payload changed: '+name)
    selected=load(directory/'readout_selection.json')
    base.require(selected['primary_model']==base.PRIMARY and
                 selected['outer_holdout_used_for_selection'] is False and
                 set(selected['models'])==set(panel_names()) and
                 selected['feature_file_sha256']==base.sha(directory/'features.npz') and
                 selected['rows_file_sha256']==base.sha(directory/'rows.json'),
                 'Baseline selection protocol or source cache differs')
    for name,entry in selected['models'].items():
        base.require(entry['C'] in base.C_GRID, 'Invalid inherited regularization value: '+name)
    metadata=load(directory/'rows.json')
    rows=base.validate_rows(metadata)
    activity=load(directory/'activity_holdout.json')
    base.require(activity['primary_model']==base.PRIMARY and
                 set(activity['models'])==set(panel_names()), 'Baseline activity panels differ')
    expected_labels={r['assembly_id']:r['observed_activity'] for r in rows if r['outer_role']=='held'}
    for name,model in activity['models'].items():
        base.require(model['C']==selected['models'][name]['C'] and
                     {r['assembly_id']:r['observed_activity'] for r in model['predictions']}==expected_labels,
                     'Baseline activity/selection alignment differs: '+name)
    return dict(metadata=metadata,feature=feature,selection=selected,activity=activity,
                proof={name:base.sha(directory/name) for name in BASE_FILES},
                archive_sha256=BASELINE_ZIP_SHA)


def load_features(directory):
    with np.load(Path(directory)/'features.npz',allow_pickle=False) as z:
        return {name:np.asarray(z[name],dtype=np.float64) for name in BLOCKS}


def validate_joint_features(directory, baseline):
    directory=Path(directory)
    feature=load(directory/'features.json')
    step=feature['checkpoint_step']
    base.require(step in (27000,32000) and feature['checkpoint_sha256']==CHECKPOINTS[step],
                 'Wrong joint checkpoint identity')
    base.require(feature['status']=='FROZEN_FEATURES_COMPLETE' and
                 feature['activity_labels_used_by_encoder'] is True and
                 feature['encoder_state_sha256_before']==feature['encoder_state_sha256_after'] and
                 feature['encoder_training'] is False,
                 'Joint feature cache must prove a frozen, previously label-trained encoder')
    for name in ('features.npz','rows.json'):
        base.require(base.sha(directory/name)==feature['payload_sha256'][name],
                     'Joint feature payload changed: '+name)
    metadata=load(directory/'rows.json')
    rows=base.validate_rows(metadata)
    for key in ('rows','donor_specific_domain_hashes','outer_held_donors','outer_split',
                'excluded_conflicts','exact_overlap_exclusions'):
        base.require(metadata[key]==baseline['metadata'][key],
                     'Joint/26k metadata, labels or split alignment differs: '+key)
    for name in BLOCKS:
        for key in ('shape','columns'):
            base.require(feature['arrays'][name][key]==baseline['feature']['arrays'][name][key],
                         'Joint/26k feature definition differs: '+name+'/'+key)
    features=load_features(directory)
    base.require(all(x.ndim==2 and len(x)==len(rows) and
                     list(x.shape)==feature['arrays'][name]['shape'] and
                     x.shape[1]==len(feature['arrays'][name]['columns']) and not np.isinf(x).any()
                     for name,x in features.items()), 'Invalid joint feature arrays')
    return step,metadata,features,feature


def fit_fixed_models(features, rows, selected, output_models):
    """Fitting-only helper. Outer labels and features cannot affect coefficients."""
    outer=[i for i,r in enumerate(rows) if r['outer_role']=='train']
    y=np.asarray([r['observed_activity'] for r in rows],dtype=int)
    fitted,decisions={},{}
    for panel,blocks in base.PANELS.items():
        for source in base.SOURCES:
            name=f'{panel}_{source}'
            c=selected['models'][name]['C']
            base.require(c in base.C_GRID, 'Inherited C outside the sealed26 grid')
            train=base.training_indices(rows,outer,source)
            transform=base.FeatureTransform(blocks).fit(features,rows,train)
            x=transform.transform(features,rows,train)
            model=base.fit_model(x,y[train],base.sample_weights(rows,train,source),c)
            saved=base.save_model(Path(output_models),name,transform,model,c,source)
            fitted[name]=(model,transform,train,blocks,source,saved)
            decisions[name]=dict(C=c,source=source,feature_blocks=list(blocks),
                                  role='primary' if name==base.PRIMARY else 'secondary_exploratory',
                                  n_train=len(train),train_index_sha256=base.digest(train),
                                  preprocessing=transform.metadata())
            print(json.dumps(dict(stage='FIXED_READOUT_FITTED',model=name,inherited_C=c,
                                  n_train=len(train),new_C_search=False)),flush=True)
    return fitted,decisions


def fit_checkpoint(out_checkpoint, baseline26_dir, protocol, package_dir):
    out,baseline_dir=Path(out_checkpoint),Path(baseline26_dir)
    base.require(protocol.get('primary_panel')==base.PRIMARY,'Primary panel must remain fixed')
    baseline=validate_baseline(baseline_dir)
    step,metadata,features,feature=validate_joint_features(out,baseline)
    baseline_arrays=load_features(baseline_dir)
    for name in ('chemistry','structure'):
        base.require(np.array_equal(features[name],baseline_arrays[name],equal_nan=True),
                     'Checkpoint-independent design features changed: '+name)
    rows=metadata['rows']
    fitted,decisions=fit_fixed_models(features,rows,baseline['selection'],out/'models')
    transfer=dict(version=VERSION,checkpoint_step=step,checkpoint_sha256=CHECKPOINTS[step],
                  primary_model=base.PRIMARY,models=decisions,
                  baseline_archive_sha256=BASELINE_ZIP_SHA,baseline_file_sha256=baseline['proof'],
                  inherited_selection_file='readout_selection.json',
                  new_C_search=False,outer_holdout_used_for_selection=False,
                  encoder_updates=0,activity_labels_previously_used_by_encoder=True,
                  preprocessing='Same algorithm refitted to outer-training rows for this fixed representation.',
                  reason='27k/32k encoders previously saw outer-training activity labels, so their internal head CV would not be an independent pipeline test.',
                  interpretation='Fixed-C comparison, not independently optimized best performance for each checkpoint.')
    # All eight model coefficients/transforms and C choices commit before evaluation.
    base.dump(out/'readout_transfer.json',transfer)
    held=[i for i,r in enumerate(rows) if r['outer_role']=='held']
    outer=[i for i,r in enumerate(rows) if r['outer_role']=='train']
    y=np.asarray([r['observed_activity'] for r in rows],dtype=int)
    models={}
    for name,(model,transform,train,blocks,source,saved) in fitted.items():
        logits=model.decision_function(transform.transform(features,rows,held))
        replay=base.predict_saved(out/'models'/(name+'.json'),features,rows,held)
        base.require(np.allclose(logits,replay,atol=1e-10,rtol=1e-10),'Saved readout replay differs')
        predictions=[dict(index=i,assembly_id=rows[i]['assembly_id'],cohort=rows[i]['cohort'],
                          observed_activity=int(y[i]),logit=float(z),sigmoid=float(base.sigmoid(z)))
                     for i,z in zip(held,logits,strict=True)]
        scores={}
        for cohort in base.COHORTS:
            chosen=[r for r in predictions if r['cohort']==cohort]
            tr=[i for i in outer if rows[i]['cohort']==cohort]
            prevalence=float((y[tr].sum()+.5)/(len(tr)+1))
            scores[cohort]=base.metrics([r['observed_activity'] for r in chosen],
                                        [r['logit'] for r in chosen],prevalence)
        models[name]=dict(role=decisions[name]['role'],C=decisions[name]['C'],source=source,
                         feature_blocks=list(blocks),metrics=scores,predictions=predictions,
                         portable_model=saved['coefficients_file'],n_train=len(train),
                         train_index_sha256=base.digest(train),calibrated=False)
    activity=dict(version=VERSION,checkpoint_step=step,checkpoint_sha256=CHECKPOINTS[step],
                  primary_model=base.PRIMARY,metrics=models[base.PRIMARY]['metrics'],
                  predictions=models[base.PRIMARY]['predictions'],models=models,
                  held_donors=metadata['outer_held_donors'],calibrated=False,
                  new_C_search=False,baseline_archive_sha256=BASELINE_ZIP_SHA,
                  interpretation='Previously inspected fixed outer donor holdout; no prospective or independent internal-CV claim for these label-trained encoders.')
    base.dump(out/'activity_holdout.json',activity)
    summary=dict(status='FROZEN_CHECKPOINT_READOUT_COMPLETE',checkpoint_step=step,
                 primary_model=base.PRIMARY,encoder_updates=0,classifier_count=len(models),
                 new_C_search=False,heldout_count=len(held),primary_metrics=activity['metrics'])
    base.dump(out/'readout_summary.json',summary)
    return summary


def _index_predictions(panel):
    result={r['assembly_id']:r for r in panel['predictions']}
    base.require(len(result)==len(panel['predictions']),'Duplicate prediction identity')
    return result


def compare(out, baseline26_dir, protocol, package_dir=None):
    """Side-by-side fixed-head protocol comparison; never selects a winner."""
    out=Path(out)
    base.require(protocol.get('primary_panel')==base.PRIMARY,'Primary panel changed')
    baseline=validate_baseline(baseline26_dir)
    reports={26000:baseline['activity']}
    for step in (27000,32000):
        report=load(out/f'step_{step}'/'activity_holdout.json')
        base.require(report['checkpoint_step']==step and report['checkpoint_sha256']==CHECKPOINTS[step] and
                     report['baseline_archive_sha256']==BASELINE_ZIP_SHA and report['new_C_search'] is False and
                     report['primary_model']==base.PRIMARY and set(report['models'])==set(panel_names()),
                     'Checkpoint comparison report lineage differs')
        reports[step]=report
    metric_rows,prediction_rows,deltas=[],[],[]
    static_controls={}
    for name in panel_names():
        baseline_predictions=_index_predictions(reports[26000]['models'][name])
        for step,report in reports.items():
            panel=report['models'][name]
            base.require(panel['C']==baseline['selection']['models'][name]['C'],'C changed across encoders')
            preds=_index_predictions(panel)
            base.require(set(preds)==set(baseline_predictions),'Held-out IDs differ across encoders')
            for aid,r in preds.items():
                origin=baseline_predictions[aid]
                base.require((r['observed_activity'],r['cohort'])==(origin['observed_activity'],origin['cohort']),
                             'Held-out label/cohort mismatch')
                prediction_rows.append(dict(model=name,checkpoint_step=step,**r))
            for cohort,scores in panel['metrics'].items():
                selected=[r for r in preds.values() if r['cohort']==cohort]
                check=base.metrics([r['observed_activity'] for r in selected],[r['logit'] for r in selected])
                base.require(scores['n']==check['n'] and scores['positives']==check['positives'],
                             'Stored metric sample counts differ')
                for metric in METRICS:
                    base.require((check[metric] is None and scores[metric] is None) or
                                 (check[metric] is not None and scores[metric] is not None and
                                  abs(check[metric]-scores[metric])<1e-10),
                                 'Stored metric does not match logits')
                metric_rows.append(dict(model=name,checkpoint_step=step,cohort=cohort,
                                        C=panel['C'],role='primary' if name==base.PRIMARY else 'secondary_exploratory',
                                        **scores))
            if name.startswith('static_design_') and step!=26000:
                difference=max(abs(preds[aid]['logit']-baseline_predictions[aid]['logit']) for aid in preds)
                base.require(difference<=1e-10,'Static-design negative control changed across encoders')
                static_controls[f'{name}_{step}']=dict(max_absolute_logit_difference=difference,pass_check=True)
        for lower,upper in ((26000,27000),(26000,32000),(27000,32000)):
            for cohort in base.COHORTS:
                a=reports[lower]['models'][name]['metrics'][cohort]
                b=reports[upper]['models'][name]['metrics'][cohort]
                deltas.append(dict(model=name,cohort=cohort,from_step=lower,to_step=upper,
                                   **{metric:None if a[metric] is None or b[metric] is None else b[metric]-a[metric]
                                      for metric in METRICS}))
    original_heads={}
    expected=_index_predictions(reports[26000]['models'][base.PRIMARY])
    for step in (27000,32000):
        path=out/'original_joint_heads'/f'step_{step}_activity.json'
        if not path.exists():continue
        archived=load(path)
        predictions=_index_predictions(archived)
        base.require(set(predictions)==set(expected),'Archived joint head held IDs differ')
        for aid,r in predictions.items():
            base.require((r['cohort'],r['observed_activity'])==
                         (expected[aid]['cohort'],expected[aid]['observed_activity']),
                         'Archived joint head labels/cohorts differ')
        for cohort,scores in archived['metrics'].items():
            chosen=[r for r in predictions.values() if r['cohort']==cohort]
            checked=base.metrics([r['observed_activity'] for r in chosen],[r['logit'] for r in chosen])
            for metric in METRICS:
                base.require((scores[metric] is None and checked[metric] is None) or
                             (scores[metric] is not None and checked[metric] is not None and
                              abs(scores[metric]-checked[metric])<1e-7),
                             'Archived joint metric differs from predictions')
        original_heads[str(step)]=dict(file=str(path.relative_to(out)),sha256=base.sha(path),
            metrics=archived['metrics'],predictions=archived['predictions'],
            comparison_to_refit_primary={cohort:{metric:
                None if scores[metric] is None or reports[step]['metrics'][cohort][metric] is None else
                reports[step]['metrics'][cohort][metric]-scores[metric]
                for metric in METRICS} for cohort,scores in archived['metrics'].items()},
            interpretation='Descriptive original joint-head versus replacement readout comparison on the same previously inspected holdout; this does not isolate head overfitting.')
    result=dict(version=VERSION,status='FROZEN26_27_32_COMPARISON_COMPLETE',
                primary_model=base.PRIMARY,checkpoint_steps=[26000,27000,32000],
                metrics=metric_rows,deltas=deltas,static_design_controls=static_controls,
                original_joint_heads=original_heads,
                baseline_archive_sha256=BASELINE_ZIP_SHA,encoder_updates=0,new_C_search=False,
                winner_selected=False,calibrated=False,
                interpretation=['Same rows, feature definitions, classifier family, C values and outer split.',
                                'Preprocessing is refitted only on outer-training rows at each checkpoint.',
                                '26k uses original local/global attention; 27k/32k use their trained full attention.',
                                'Thus checkpoint contrasts do not isolate attention, supervised adaptation or extra steps.',
                                'C was selected using26k; this is not a search for the optimum C for27k/32k.',
                                'Previously inspected holdout; no prospective validation or best-model selection.'])
    base.dump(out/'checkpoint_comparison.json',result)
    base.dump(out/'matched_predictions.json',dict(predictions=prediction_rows))
    base.write_csv(out/'checkpoint_metrics.csv',metric_rows,
                   ('model','role','checkpoint_step','cohort','C','n','positives',*METRICS,
                    'training_prevalence','prevalence_brier','prevalence_log_loss'))
    base.write_csv(out/'matched_predictions.csv',prediction_rows,
                   ('model','checkpoint_step','index','assembly_id','cohort','observed_activity','logit','sigmoid'))
    return result
