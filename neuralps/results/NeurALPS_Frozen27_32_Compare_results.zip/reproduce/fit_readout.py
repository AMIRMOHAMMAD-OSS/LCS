#!/usr/bin/env python3
"""Frozen 26k features, training-only donor CV, and a fixed outer activity holdout.

No encoder is imported or updated here. Every imputation, scale and PCA is fit
on the training rows of its own donor-purged fold. The primary model is declared
before looking at outer labels; other panels are explanatory secondary analyses.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import warnings

import numpy as np
from sklearn.decomposition import PCA
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression

VERSION = "frozen26_readout_v1"
PRIMARY = "combined_bode2"
C_GRID = (0.01, 0.1, 1.0, 10.0)
COHORTS = ("singles", "doubles", "triples")
PANELS = {
    "maps_chemistry": ("compatibility", "chemistry", "structure"),
    "context_chemistry": ("context", "chemistry", "structure"),
    "combined": ("context", "compatibility", "chemistry", "structure"),
    "static_design": ("chemistry", "structure"),
}
SOURCES = ("bode2", "all3w025")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def dump(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    tmp.replace(path)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def sigmoid(x):
    return np.exp(-np.logaddexp(0.0, -np.asarray(x, dtype=np.float64)))


def donors(row):
    return {str(d) for d in row.get("donor_codes", []) if d not in (None, "", "native")}


def validate_rows(metadata, strict=True):
    rows = metadata["rows"]
    require(rows and [r["index"] for r in rows] == list(range(len(rows))),
            "Feature metadata indices must be contiguous and ordered")
    require(len({r["assembly_id"] for r in rows}) == len(rows), "Duplicate assembly IDs")
    require(all(type(r["observed_activity"]) is int and r["observed_activity"] in (0, 1)
                for r in rows), "Only reviewed binary activity labels are permitted")
    require(all(r["outer_role"] in {"train", "held", "excluded"} for r in rows),
            "Unrecognized outer split role")
    require(all(r["dataset"] in {"bode1", "bode2", "tdomain"} for r in rows),
            "Unrecognized assay")
    held = set(metadata["outer_held_donors"])
    require(all(not donors(r) & held for r in rows if r["outer_role"] == "train"),
            "An outer training row contains a protected donor")
    if strict:
        require(len(rows) == 552, "Expected all 552 audited structural rows")
        require(Counter(r["cohort"] for r in rows if r["outer_role"] == "train") ==
                dict(bode1=288, singles=84, doubles=26, triples=12, tdomain=65),
                "Original protected outer training cohort has changed")
        require(Counter(r["cohort"] for r in rows if r["outer_role"] == "held") ==
                dict(singles=21, doubles=5, triples=15),
                "Original protected outer holdout has changed")
        require(len(held) == 7, "Expected seven protected outer donor identities")
    return rows


def build_inner_splits(metadata, n_folds=4):
    """Hash-sort donors without labels; purge every validation donor from training.

    A multi-exchange row can occur in more than one validation fold. It never
    trains a model that validates any of its donors. OOF aggregation subsequently
    gives each physical construct one prediction and one metric contribution.
    """
    rows = metadata["rows"]
    outer = [i for i, r in enumerate(rows) if r["outer_role"] == "train"]
    single_donors = sorted(set().union(*(donors(rows[i]) for i in outer
                                        if rows[i]["cohort"] == "singles")))
    require(len(single_donors) >= n_folds, "Too few outer-training donor groups")
    require(not set(single_donors) & set(metadata["outer_held_donors"]),
            "Protected outer donor entered internal validation")
    require(all(donors(rows[i]) <= set(single_donors) for i in outer
                if rows[i]["dataset"] == "bode2"),
            "Training multis contain donor(s) absent from training singles")
    ordered = sorted(single_donors,
                     key=lambda d: hashlib.sha256(("frozen26_inner_v1:" + d).encode()).hexdigest())
    registry = metadata["donor_specific_domain_hashes"]
    require(all(d in registry for d in ordered), "Missing exact donor-domain purge registry")
    splits = []
    for fold in range(n_folds):
        held_donors = set(ordered[fold::n_folds])
        validation = [i for i in outer if rows[i]["dataset"] == "bode2"
                      and donors(rows[i]) & held_donors]
        require(validation, "Empty internal validation fold")
        prohibited_hashes = set().union(*(set(registry[d]) for d in held_donors))
        prohibited_routes = {rows[i]["route_fingerprint"] for i in validation}
        train, excluded = [], []
        for i in outer:
            reasons = []
            if donors(rows[i]) & held_donors:
                reasons.append("validation_donor")
            if set(rows[i]["domain_hashes"]) & prohibited_hashes:
                reasons.append("exact_donor_domain")
            if rows[i]["route_fingerprint"] in prohibited_routes:
                reasons.append("validation_route_duplicate")
            if reasons:
                excluded.append(dict(index=i, assembly_id=rows[i]["assembly_id"], reasons=reasons))
            else:
                train.append(i)
        require(not set(train) & set(validation), "Internal train/validation overlap")
        require(all(not donors(rows[i]) & held_donors for i in train), "Donor purge failed")
        splits.append(dict(fold=f"inner{fold:02d}", held_donors=sorted(held_donors),
                           train_indices=train, validation_indices=validation,
                           train_ids=[rows[i]["assembly_id"] for i in train],
                           validation_ids=[rows[i]["assembly_id"] for i in validation],
                           train_index_sha256=digest(train),
                           validation_index_sha256=digest(validation),
                           excluded=excluded,
                           exact_purge_domain_hash_count=len(prohibited_hashes),
                           validation_cohort_counts=dict(Counter(rows[i]["cohort"] for i in validation))))
    expected = {i for i in outer if rows[i]["dataset"] == "bode2"}
    require(set().union(*(set(s["validation_indices"]) for s in splits)) == expected,
            "Internal validation does not cover each outer-training BODE2 construct")
    return splits


class BlockTransform:
    """Serializable train-only imputation/scaling and optional context PCA."""
    def __init__(self, block, pca_components=16):
        self.block = block
        self.pca_components = pca_components
        self.arrays = {}

    def fit(self, values, train_indices):
        x = np.asarray(values, dtype=np.float64)[train_indices]
        require(x.ndim == 2 and x.shape[1] > 0 and len(x) > 1, "Invalid feature block")
        require(not np.isinf(x).any(), "Infinite feature value")
        observed = np.isfinite(x)
        counts = observed.sum(0)
        means = np.divide(np.where(observed, x, 0).sum(0), counts,
                          out=np.zeros(x.shape[1], dtype=float), where=counts > 0)
        imputed = np.where(observed, x, means)
        # Missingness indicators are fitted using training rows only. Indicators
        # constant in training are removed; unseen missingness is mean-imputed
        # but cannot have a learned missingness coefficient in this fold.
        expanded = np.concatenate([imputed, (~observed).astype(float)], axis=1)
        center = expanded.mean(0)
        scale = expanded.std(0)
        active = scale > 1e-12
        scale = np.where(active, scale, 1.0)
        self.arrays = dict(impute=means, center=center, scale=scale,
                           active=active, missing_train_counts=(~observed).sum(0))
        z = ((expanded - center) / scale)[:, active]
        self.used_pca = self.block == "context" and z.shape[1] > 0
        if self.used_pca:
            k = min(self.pca_components, len(x) - 1, z.shape[1])
            # Exact SVD is deterministic and fitted only to this training fold.
            pca = PCA(n_components=k, svd_solver="full")
            z = pca.fit_transform(z)
            self.arrays["pca_components"] = pca.components_
            self.arrays["pca_mean"] = pca.mean_
            pca_scale = z.std(0)
            pca_scale = np.where(pca_scale > 1e-12, pca_scale, 1.0)
            self.arrays["pca_scale"] = pca_scale
            z = z / pca_scale
        self.width = z.shape[1]
        self.divisor = float(np.sqrt(max(1, self.width)))
        self.train_index_sha256 = digest([int(i) for i in train_indices])
        self.input_width = x.shape[1]
        self.all_missing_columns = np.flatnonzero(counts == 0).tolist()
        return self

    def transform(self, values):
        x = np.asarray(values, dtype=np.float64)
        require(x.ndim == 2 and x.shape[1] == self.input_width and not np.isinf(x).any(),
                "Prediction feature schema differs")
        observed = np.isfinite(x)
        expanded = np.concatenate([np.where(observed, x, self.arrays["impute"]),
                                   (~observed).astype(float)], axis=1)
        z = ((expanded - self.arrays["center"]) / self.arrays["scale"])[:, self.arrays["active"]]
        if self.used_pca:
            z = ((z - self.arrays["pca_mean"]) @ self.arrays["pca_components"].T)
            z = z / self.arrays["pca_scale"]
        result = z / self.divisor
        require(np.isfinite(result).all(), "Nonfinite transformed features")
        return result

    def metadata(self):
        return dict(block=self.block, input_width=self.input_width, output_width=self.width,
                    divisor=self.divisor, used_pca=self.used_pca,
                    train_index_sha256=self.train_index_sha256,
                    all_missing_training_columns=self.all_missing_columns,
                    imputation="training mean; zero if entirely missing in training",
                    missingness="per-column indicators; training-constant columns removed",
                    context_pca="training-only exact SVD, at most 16 components")


class FeatureTransform:
    def __init__(self, blocks):
        self.blocks = tuple(blocks)
        self.transforms = {}

    def fit(self, features, rows, train_indices):
        self.train_indices = [int(i) for i in train_indices]
        self.transforms = {block: BlockTransform(block).fit(features[block], self.train_indices)
                           for block in self.blocks}
        return self

    def transform(self, features, rows, indices):
        ix = np.asarray(indices, dtype=int)
        blocks = [self.transforms[b].transform(features[b][ix]) for b in self.blocks]
        # BODE2 reference intercept plus separate offsets for the other assays.
        offsets = np.asarray([[float(rows[i]["dataset"] == "bode1"),
                               float(rows[i]["dataset"] == "tdomain")] for i in ix])
        return np.concatenate([*blocks, offsets], axis=1)

    def metadata(self):
        return dict(blocks=list(self.blocks), transformations={b:t.metadata() for b,t in self.transforms.items()},
                    assay_offsets=["bode1", "tdomain"], reference_assay="bode2",
                    train_indices=self.train_indices,
                    train_index_sha256=digest(self.train_indices),
                    block_scaling="divide each transformed block by sqrt(nonconstant output width)")


def training_indices(rows, indices, source):
    require(source in SOURCES, "Unsupported source policy")
    return [i for i in indices if source == "all3w025" or rows[i]["dataset"] == "bode2"]


def sample_weights(rows, indices, source):
    weight = np.asarray([1.0 if rows[i]["dataset"] == "bode2" else .25 for i in indices])
    if source == "bode2":
        require(all(rows[i]["dataset"] == "bode2" for i in indices), "Auxiliary source in primary fit")
    return weight / weight.mean()


def fit_model(x, y, weights, c):
    require(set(np.unique(y)) == {0, 1}, "A training fold has only one activity class")
    model = LogisticRegression(C=float(c), penalty="l2", solver="lbfgs", max_iter=5000,
                               tol=1e-8, fit_intercept=True, random_state=20261108)
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always", ConvergenceWarning)
        model.fit(x, y, sample_weight=weights)
    require(not any(issubclass(w.category, ConvergenceWarning) for w in captured),
            "Logistic regression did not converge; result is not eligible for selection")
    require(np.isfinite(model.coef_).all() and np.isfinite(model.intercept_).all(),
            "Nonfinite fitted coefficients")
    return model


def metrics(y, logit, prevalence=None):
    y = np.asarray(y, dtype=float)
    logit = np.asarray(logit, dtype=float)
    require(len(y) == len(logit) and len(y) > 0 and np.isfinite(logit).all(), "Invalid metric inputs")
    p = sigmoid(logit)
    pos, neg = p[y == 1], p[y == 0]
    differences = pos[:, None] - neg
    auc = float(((differences > 0) + .5 * (differences == 0)).mean()) if differences.size else None
    ap = None
    if len(pos):
        ap = float(sum(y[p == t].sum() / len(pos) * y[p >= t].mean() for t in np.unique(p)))
    result = dict(n=len(y), positives=int(y.sum()), auroc=auc, average_precision=ap,
                  brier=float(((p-y)**2).mean()),
                  log_loss=float(np.logaddexp(0., (1 - 2*y) * logit).mean()))
    if prevalence is not None:
        require(0 < prevalence < 1, "Invalid training prevalence baseline")
        result.update(training_prevalence=prevalence,
                      prevalence_brier=float(((y-prevalence)**2).mean()),
                      prevalence_log_loss=float(-(y*np.log(prevalence)+(1-y)*np.log1p(-prevalence)).mean()))
    return result


def aggregate_inner(records, rows):
    grouped = defaultdict(list)
    for record in records:
        grouped[record["index"]].append(record)
    output = []
    for i in sorted(grouped):
        values = grouped[i]
        require(len({v["fold"] for v in values}) == len(values), "Duplicate within-fold OOF prediction")
        probability = float(np.mean([r["sigmoid"] for r in values]))
        # Stable inverse of averaging probabilities; this is an OOF aggregation,
        # not post-hoc probability calibration or an inference ensemble.
        probability = float(np.clip(probability, 1e-15, 1-1e-15))
        logit = float(np.log(probability) - np.log1p(-probability))
        output.append(dict(index=i, assembly_id=rows[i]["assembly_id"], cohort=rows[i]["cohort"],
                           observed_activity=rows[i]["observed_activity"], logit=logit,
                           sigmoid=probability, validation_count=len(values),
                           folds=[r["fold"] for r in values]))
    scores = {}
    for cohort in COHORTS:
        chosen = [r for r in output if r["cohort"] == cohort]
        require(chosen, "Internal CV lacks a full cohort for the predeclared selection objective")
        scores[cohort] = metrics([r["observed_activity"] for r in chosen], [r["logit"] for r in chosen])
    return output, scores, float(np.mean([scores[c]["log_loss"] for c in COHORTS]))


def cross_validate(features, rows, splits, blocks, source, name, c_grid=C_GRID):
    """Select regularization using exclusively outer-training donor folds."""
    y = np.asarray([r["observed_activity"] for r in rows], dtype=int)
    prepared = []
    for split in splits:
        train = training_indices(rows, split["train_indices"], source)
        validation = split["validation_indices"]
        require(all(rows[i]["outer_role"] == "train" for i in train + validation),
                "Outer held or excluded row entered inner CV")
        transform = FeatureTransform(blocks).fit(features, rows, train)
        prepared.append((split, train, validation, transform,
                         transform.transform(features, rows, train),
                         transform.transform(features, rows, validation)))
    candidates, all_predictions = [], []
    for c in c_grid:
        predictions, convergence = [], []
        for split, train, validation, transform, x_train, x_val in prepared:
            model = fit_model(x_train, y[train], sample_weights(rows, train, source), c)
            logits = model.decision_function(x_val)
            convergence.append(dict(fold=split["fold"], iterations=[int(v) for v in model.n_iter_],
                                    train_index_sha256=digest(train), n_train=len(train),
                                    transform=transform.metadata()))
            predictions.extend(dict(model=name, C=c, fold=split["fold"], index=i,
                                    assembly_id=rows[i]["assembly_id"], cohort=rows[i]["cohort"],
                                    observed_activity=int(y[i]), logit=float(z), sigmoid=float(sigmoid(z)))
                               for i,z in zip(validation, logits, strict=True))
        aggregated, scores, objective = aggregate_inner(predictions, rows)
        candidates.append(dict(C=c, macro_cohort_log_loss=objective, cohort_metrics=scores,
                               predictions=aggregated, convergence=convergence))
        all_predictions.extend(predictions)
    return candidates, all_predictions


def validate_protocol(protocol):
    expected = dict(primary_panel=PRIMARY, C_grid=list(C_GRID), inner_folds=4,
                    context_pca_components=16, seed=20261108,
                    encoder_updates=0, embedding_extraction=False)
    for key, value in expected.items():
        require(protocol.get(key) == value, "Protocol setting changed or absent: " + key)
    require(set(protocol.get("feature_panels", [])) == set(PANELS), "Feature panel protocol differs")
    require(protocol.get("source_settings") == {
        "bode2":{"bode2":1.0}, "all3w025":{"bode1":.25,"bode2":1.0,"tdomain":.25}},
        "Source weights differ from the frozen protocol")
    require(protocol.get("checkpoint", {}).get("step") == 26000 and
            protocol.get("checkpoint", {}).get("activity_labels_used") is False,
            "Readout needs the original label-free 26k encoder")


def write_csv(path, records, fields):
    with Path(path).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in records:
            writer.writerow({k:json.dumps(row[k]) if isinstance(row.get(k), (list,dict)) else row.get(k)
                             for k in fields})


def save_model(directory, name, transform, model, c, source):
    """Save portable numpy+JSON coefficients and exact fitted preprocessing."""
    directory.mkdir(exist_ok=True)
    arrays = dict(coef=model.coef_, intercept=model.intercept_)
    for block, obj in transform.transforms.items():
        arrays.update({block + "__" + k:v for k,v in obj.arrays.items()})
    path = directory / (name + ".npz")
    np.savez_compressed(path, **arrays)
    meta = dict(version=VERSION, model=name, C=c, source=source,
                transform=transform.metadata(), coefficients_file=path.name,
                coefficients_sha256=sha(path), classifier="L2 logistic regression",
                solver="lbfgs", max_iter=5000, tol=1e-8,
                fitted_iterations=[int(x) for x in model.n_iter_], classes=[0,1],
                calibrated=False, probability_interpretation="uncalibrated sigmoid activity score")
    dump(directory / (name + ".json"), meta)
    return meta


def predict_saved(model_json, features, rows, indices):
    """Replay a portable model without pickle, fitting, or access to labels."""
    path = Path(model_json)
    meta = json.loads(path.read_text())
    require(meta["version"] == VERSION, "Saved readout version differs")
    payload = path.parent / meta["coefficients_file"]
    require(sha(payload) == meta["coefficients_sha256"], "Saved model coefficients changed")
    with np.load(payload, allow_pickle=False) as saved:
        transform = FeatureTransform(meta["transform"]["blocks"])
        for block in transform.blocks:
            info = meta["transform"]["transformations"][block]
            obj = BlockTransform(block)
            obj.arrays = {k.split("__",1)[1]:saved[k].copy() for k in saved.files if k.startswith(block+"__")}
            obj.used_pca = info["used_pca"]
            obj.input_width = info["input_width"]
            obj.width = info["output_width"]
            obj.divisor = info["divisor"]
            transform.transforms[block] = obj
        x = transform.transform(features, rows, indices)
        return (x @ saved["coef"].T).ravel() + float(saved["intercept"][0])


def historical_comparison(package_dir, held_rows):
    path = Path(package_dir) / "labelled_assets/historical_fold00.json"
    historical = json.loads(path.read_text())
    labels = {r["assembly_id"]:r["observed_activity"] for r in held_rows}
    archived = {r["assembly_id"]:r["label"]
                for panel in historical["panels"].values() for r in panel["rows"]}
    require(labels == archived, "Historical comparison held IDs or labels differ")
    return dict(source_file="labelled_assets/historical_fold00.json", source_sha256=sha(path),
                metrics={k:v["metrics"] for k,v in historical["panels"].items()},
                limits=historical["limits"],
                interpretation="Historical singles include typed/chemistry supervised baselines. "
                "Multi-exchange historical entries are raw frozen-map scores, not matched supervised heads.")


def fit(out, protocol, package_dir):
    out, package_dir = Path(out), Path(package_dir)
    validate_protocol(protocol)
    feature_manifest = json.loads((out / "features.json").read_text())
    require(feature_manifest["status"] == "FROZEN_FEATURES_COMPLETE" and
            feature_manifest["checkpoint_step"] == 26000 and
            feature_manifest["checkpoint_sha256"] == protocol["checkpoint"]["sha256"] and
            feature_manifest["activity_labels_used_by_encoder"] is False and
            feature_manifest["encoder_state_sha256_before"] == feature_manifest["encoder_state_sha256_after"],
            "Features do not prove unchanged label-free 26k weights")
    for name in ("features.npz", "rows.json"):
        require(sha(out / name) == feature_manifest["payload_sha256"][name],
                "Frozen feature payload changed: " + name)
    metadata = json.loads((out / "rows.json").read_text())
    rows = validate_rows(metadata)
    with np.load(out / "features.npz", allow_pickle=False) as source:
        features = {k:np.asarray(source[k], dtype=np.float64) for k in ("context","chemistry","compatibility","structure")}
    require(all(x.ndim == 2 and len(x) == len(rows) and not np.isinf(x).any() for x in features.values()),
            "Feature block dimensions or numeric values differ")
    y = np.asarray([r["observed_activity"] for r in rows], dtype=int)
    outer = [i for i,r in enumerate(rows) if r["outer_role"] == "train"]
    held = [i for i,r in enumerate(rows) if r["outer_role"] == "held"]
    splits = build_inner_splits(metadata)
    dump(out / "inner_splits.json", dict(version=VERSION, splits=splits,
          assignment="SHA-256 donor sort then round-robin; independent of activity labels",
          purge="any validation donor, exact donor-specific primary-domain hash, or validation-route duplicate",
          homology_purged=False,
          repeated_validation="Multis may validate in multiple folds; probabilities averaged once per construct before scoring"))
    selected, all_inner, outer_models, fitted = {}, [], {}, {}
    # No outer labels enter this loop's transforms, fitting or C selection.
    for panel, blocks in PANELS.items():
        for source in SOURCES:
            name = f"{panel}_{source}"
            print(json.dumps(dict(stage="READOUT_CV", model=name)), flush=True)
            candidates, predictions = cross_validate(features, rows, splits, blocks, source, name)
            all_inner.extend(predictions)
            best = min(candidates, key=lambda r:(r["macro_cohort_log_loss"], r["C"]))
            selected[name] = dict(C=best["C"], macro_cohort_log_loss=best["macro_cohort_log_loss"],
                                  cohort_metrics=best["cohort_metrics"], role="primary" if name==PRIMARY else "secondary_exploratory",
                                  candidates=[{k:v for k,v in r.items() if k != "predictions"} for r in candidates],
                                  selected_inner_predictions=best["predictions"])
            train = training_indices(rows, outer, source)
            transform = FeatureTransform(blocks).fit(features, rows, train)
            x_train = transform.transform(features, rows, train)
            model = fit_model(x_train, y[train], sample_weights(rows, train, source), best["C"])
            saved = save_model(out / "models", name, transform, model, best["C"], source)
            fitted[name] = (model, transform, train, blocks, source, saved)
            print(json.dumps(dict(stage="READOUT_FITTED", model=name, selected_C=best["C"],
                                  inner_macro_log_loss=best["macro_cohort_log_loss"], n_train=len(train))), flush=True)
    selection = dict(version=VERSION, primary_model=PRIMARY, C_grid=list(C_GRID), models=selected,
                     selection_objective="equal-weight mean of singles/doubles/triples inner OOF log loss",
                     selection_ties="smaller C first", outer_holdout_used_for_selection=False,
                     feature_file_sha256=sha(out/"features.npz"), rows_file_sha256=sha(out/"rows.json"),
                     source_weights="BODE2=1; auxiliary BODE1/Tdomain=.25 per row; normalize training weights to mean 1",
                     source_assumptions="all3 secondary shares feature coefficients with assay-specific intercept offsets",
                     interpretation="Primary panel fixed in advance; no winner selected among secondary panels using outer results")
    dump(out / "readout_selection.json", selection)
    dump(out / "inner_predictions.json", dict(predictions=all_inner,
          aggregation="Average probabilities across validation folds per construct, then compute cohort macro log loss"))
    write_csv(out / "inner_predictions.csv", all_inner,
              ("model","C","fold","index","assembly_id","cohort","observed_activity","logit","sigmoid"))
    # Every panel's C, preprocessing and final coefficients are now fixed and
    # persisted before any protected outer activity metric is calculated.
    for name, (model, transform, train, blocks, source, saved) in fitted.items():
        logits = model.decision_function(transform.transform(features, rows, held))
        replayed = predict_saved(out / "models" / (name+".json"), features, rows, held)
        require(np.allclose(logits, replayed, atol=1e-10, rtol=1e-10), "Portable model replay differs")
        predictions = [dict(index=i, assembly_id=rows[i]["assembly_id"], cohort=rows[i]["cohort"],
                            observed_activity=int(y[i]), logit=float(z), sigmoid=float(sigmoid(z)))
                       for i,z in zip(held, logits, strict=True)]
        cohort_scores = {}
        for cohort in COHORTS:
            chosen = [r for r in predictions if r["cohort"] == cohort]
            tr = [i for i in outer if rows[i]["cohort"] == cohort]
            prevalence = float((y[tr].sum()+.5)/(len(tr)+1))
            cohort_scores[cohort] = metrics([r["observed_activity"] for r in chosen],
                                            [r["logit"] for r in chosen], prevalence)
        outer_models[name] = dict(role=selected[name]["role"], C=selected[name]["C"], source=source,
                                  feature_blocks=list(blocks), metrics=cohort_scores,
                                  predictions=predictions, portable_model=saved["coefficients_file"],
                                  n_train=len(train), train_index_sha256=digest(train), calibrated=False)
    activity = dict(version=VERSION, primary_model=PRIMARY, calibrated=False,
                    metrics=outer_models[PRIMARY]["metrics"], predictions=outer_models[PRIMARY]["predictions"],
                    models=outer_models, held_donors=metadata["outer_held_donors"],
                    historical_comparison=historical_comparison(package_dir, [rows[i] for i in held]),
                    interpretation="Retrospective fixed donor holdout; previously inspected. "
                    "No prospective validation, homology-purged claim, calibration, or outer model selection.")
    dump(out / "activity_holdout.json", activity)
    summary = dict(status="FROZEN26_READOUT_COMPLETE", primary_model=PRIMARY,
                   selected_C=selected[PRIMARY]["C"], encoder_updates=0,
                   classifier_count=len(outer_models), inner_donor_folds=len(splits),
                   heldout_count=len(held), primary_metrics=activity["metrics"],
                   outer_holdout_used_for_selection=False, calibrated=False)
    dump(out / "readout_summary.json", summary)
    return summary
