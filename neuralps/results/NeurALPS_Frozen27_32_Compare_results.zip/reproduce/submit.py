#!/usr/bin/env python3
"""Submit matched frozen 27k/32k readouts against the completed 26k baseline.

Login-node commands use the standard library only. They verify the small package
and record input file stats; bulk SHA-256 and embedded checkpoint checks belong
to the compute worker. No encoder fitting or new ESM extraction is performed.
"""
from __future__ import annotations

import argparse
from collections import deque
import fcntl
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


PACKAGE = Path(__file__).resolve().parent
PREFIX = 'neuralps_frozen2732_compare_'
RECEIPT = 'neuralps_frozen2732_compare_submission.json'
LOCK = 'neuralps_frozen2732_compare_submission.lock'
CHECKPOINT = 'e1_ssl_continue30_v1_530757/best.pt'
CHECKPOINT_SHA = '9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f'
CHECKPOINT_STEP = 26000
CHECKPOINTS = {
    '27000': dict(path='neuralps_xut_continue_20261107T172538Z_976745e6/latest.pt',
                  sha256='bb78635c63d7a29ba77fc0ff09203ecc92a7938fd216e269716243e5d104a66c', step=27000),
    '32000': dict(path='neuralps_xut_5k_20261107T181244Z_82debe20/latest.pt',
                  sha256='ba62c4c3c1d8f6606c14c57fb0770d8ecfd7c9ea8eefc35424d2aa1197923e7a', step=32000),
}
BASELINE_REL = 'neuralps_frozen26_readout_20261107T211500Z_c4d6084d'
BASELINE_ZIP_SHA = '2d607400ca29c4f4217399d881e790344c1571ef687d650ffb6b9fecc041113d'
TARGET_MANIFEST = 'e1_ssl_targets_497189/manifest.json'
TARGET_MANIFEST_SHA = 'd4571217575bba57d0ee20cd9e2511d5b1a0a792bac7b2caf33033b67816e9db'
BASELINE_FILES = ('COMPLETE.json', 'features.npz', 'features.json', 'rows.json',
                  'readout_selection.json', 'activity_holdout.json', 'run_config.json',
                  'inspection.zip')
DIGEST = re.compile(r'[0-9a-f]{64}')
PINNED_INPUTS = {
    'e0_training_prep_461027/training_data.sqlite3':
        '6c273f05a6bcde4fec6fc57a26d0a35a9461f9831656248bee3ca21de1c14287',
    'e0_cache_final_491894/features.f32':
        '5a7c2f3afd527785ce3c12eaa3b97138034f4dfc811d840b5b44cf1534b9ef90',
    'e0_cache_final_491894/feature_index.sqlite3':
        '09a6bde676c2e22bcba78879cf53c1d1979d672bcc1763a9eb49e218f387735b',
    'e10_tdomain_embed_696333/feature_index.sqlite3':
        '41d81778fc2d2c015cbe28d429ed2bccc7ea8940142106a02ef98eceeac06bfe',
    'e10_tdomain_embed_696333/features.f32':
        '1134819306754396634ee0f1c00a0bfffb2cb15cd4a20daca08b22243f1ee77d',
    'e10_tdomain_embed_696333/inputs/parents.fasta.gz':
        '15f9181a74d4bb42325bfa2af5900dcd6a2a967a0d6be1c6428b1187f34a08c9',
    'e11_tdomain_transfer_699466/scores/records.json.gz':
        'fa79f3e0f8618f004bb6b157dae9235ff9580bf4bc3a0a49c2d2b167e570e2d0',
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    with Path(path).open() as stream:
        return json.load(stream)


def dump(path, data):
    path = Path(path)
    temporary = path.with_name(f'.{path.name}.{os.getpid()}.tmp')
    with temporary.open('w') as stream:
        stream.write(json.dumps(data, indent=2, sort_keys=True, allow_nan=False) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def package_digest():
    """Validate every listed package file; never import training dependencies."""
    manifest = PACKAGE / 'PACKAGE_MANIFEST.json'
    entries = load(manifest)['files']
    require(isinstance(entries, dict) and entries, 'Empty or malformed package manifest')
    for relative in ('submit.py', 'batch.sh', 'run.py', 'export_review.py',
                     'frozen_features.py', 'fit_readout.py', 'protocol.json',
                     'joint_features.py', 'compare_readouts.py', 'lineage.py', 'ssl_changes.py',
                     'supervised.py', 'labelled_backend.py', 'labelled_multis.py',
                     'vendor_neural/assembly_model.py', 'vendor_neural/masking_contract.py'):
        require(relative in entries, f'Package manifest is missing {relative}')
    for relative, expected in entries.items():
        require(isinstance(relative, str) and not Path(relative).is_absolute()
                and isinstance(expected, str) and DIGEST.fullmatch(expected),
                'Malformed package manifest entry')
        path = (PACKAGE / relative).resolve()
        require(path.is_relative_to(PACKAGE) and path.is_file() and sha(path) == expected,
                f'Package file changed or missing: {relative}')
    return sha(manifest)


def project_inputs():
    """Return pinned hashes plus metadata paths verified against sealed archives."""
    expected = dict(PINNED_INPUTS)
    expected[CHECKPOINT] = CHECKPOINT_SHA
    expected[TARGET_MANIFEST] = TARGET_MANIFEST_SHA
    for info in CHECKPOINTS.values():
        expected[info['path']] = info['sha256']
        for name in ('config.json', 'COMPLETE.json'):
            expected[str(Path(info['path']).parent / name)] = None
    for name in BASELINE_FILES:
        expected[str(Path(BASELINE_REL) / name)] = None
    expected[str(Path(BASELINE_REL) / 'inspection.zip')] = BASELINE_ZIP_SHA
    protocol = load(PACKAGE / 'protocol.json')
    require(protocol.get('checkpoints') == CHECKPOINTS,
            'Protocol checkpoints differ from the pinned 27k/32k models')
    require(protocol.get('baseline26') == dict(path=BASELINE_REL, inspection_sha256=BASELINE_ZIP_SHA),
            'Protocol does not name the exact completed 26k comparison')
    require(protocol.get('encoder_updates') == 0 and protocol.get('embedding_extraction') is False,
            'Protocol exceeds the frozen-encoder comparison scope')
    extra = protocol.get('project_inputs', {})
    required = protocol.get('required_files', [])
    require(isinstance(extra, dict) and isinstance(required, list),
            'Protocol input schema differs')
    for relative in required:
        require(isinstance(relative, str) and relative and not Path(relative).is_absolute()
                and '..' not in Path(relative).parts, 'Invalid required project input')
        expected.setdefault(relative, None)
    for relative, digest in extra.items():
        require(isinstance(relative, str) and relative and not Path(relative).is_absolute()
                and '..' not in Path(relative).parts and isinstance(digest, str)
                and DIGEST.fullmatch(digest), 'Invalid pinned project input')
        require(expected.get(relative) in (None, digest),
                f'Protocol contradicts a pinned input: {relative}')
        expected[relative] = digest
    return expected


def check_inputs(root, verify_hashes=False):
    """Only stat on login; compute hashes pins and separately verifies lineage."""
    root = Path(root).resolve()
    receipt = {}
    for relative, expected in sorted(project_inputs().items()):
        source = (root / relative).resolve()
        require(source.is_relative_to(root) and source.is_file(),
                f'Required input missing or outside project: {relative}')
        before = source.stat()
        require(before.st_size > 0, f'Empty input: {relative}')
        if source.suffix == '.sqlite3':
            require(not Path(str(source) + '-wal').exists(),
                    f'Unexpected WAL on source: {relative}')
        if verify_hashes and expected is not None:
            require(sha(source) == expected, f'Pinned input SHA-256 differs: {relative}')
        after = source.stat()
        require((before.st_size, before.st_mtime_ns, before.st_ino) ==
                (after.st_size, after.st_mtime_ns, after.st_ino),
                f'Input changed during verification: {relative}')
        receipt[relative] = dict(bytes=after.st_size, mtime_ns=after.st_mtime_ns,
                                 expected_sha256=expected)
    return receipt


def select_lineage(root):
    root = Path(root).resolve()
    checkpoints = {}
    for key, info in CHECKPOINTS.items():
        path = (root / info['path']).resolve()
        require(path.is_relative_to(root) and path.is_file() and path.stat().st_size > 0,
                f'Exact {key} checkpoint missing: {path}')
        checkpoints[key] = dict(info, path=str(path))
    baseline = (root / BASELINE_REL).resolve()
    require(baseline.is_relative_to(root) and baseline.is_dir(), 'Completed 26k baseline directory is missing')
    return dict(checkpoints=checkpoints, baseline26=str(baseline),
                baseline26_inspection_sha256=BASELINE_ZIP_SHA)


def checked_output(root, output):
    root, output = Path(root).resolve(), Path(output).resolve()
    require(output.parent == root and output.name.startswith(PREFIX) and output.is_dir(),
            f'Invalid frozen-readout output directory: {output}')
    return output


def read_request(root, output, digest):
    root, output = Path(root).resolve(), Path(output).resolve()
    path = output / 'REQUEST.json'
    require(sha(path) == (output / 'REQUEST.sha256').read_text().strip(),
            'Run request digest differs')
    request = load(path)
    require(request['root'] == str(root) and request['output'] == str(output)
            and request['package'] == str(PACKAGE)
            and request['package_manifest_sha256'] == digest
            and request['protocol_sha256'] == sha(PACKAGE / 'protocol.json'),
            'Run path, protocol, or package identity changed')
    expected_lineage = select_lineage(root)
    require(all(request.get(k) == v for k, v in expected_lineage.items()),
            'Run request does not name the exact frozen comparison lineage')
    require(request.get('encoder_training') is False
            and request.get('embedding_extraction') is False,
            'Request does not preserve the frozen-encoder scope')
    return request


def check_queue(job_id, job_name):
    """Full live-user query handles unrelated array jobs without numeric parsing."""
    result = subprocess.run(['squeue', '-h', '-u', getpass.getuser(), '-o', '%64i|%128j'],
                            capture_output=True, text=True, timeout=30, check=True)
    for row in result.stdout.splitlines():
        if not row.strip():
            continue
        identifier, separator, name = row.partition('|')
        identifier, name = identifier.strip(), name.strip()
        require(separator and identifier and name and '|' not in name,
                f'Unrecognized scheduler response; refusing to submit: {row!r}')
        same_id = bool(job_id) and (identifier == job_id
                                   or identifier.startswith(job_id + '_')
                                   or identifier.startswith(job_id + '.'))
        require(not same_id and name != job_name,
                f'Allocation is already queued or running: {row}')


def concise_event(line):
    try:
        event = json.loads(line)
    except (ValueError, TypeError):
        return line.rstrip()[:1200]
    if not isinstance(event, dict):
        return str(event)[:1200]
    keep = ('stage', 'status', 'checkpoint_step', 'completed', 'total', 'elapsed_seconds',
            'feature_rows', 'fold', 'panel', 'C', 'selected_C', 'encoder_training',
            'embedding_extraction', 'inspection_zip', 'inspection_sha256', 'output')
    result = {key: event[key] for key in keep if key in event}
    return json.dumps(result or event, allow_nan=False)[:2000]


def complete(output):
    """Allow a resumed worker to re-export a missing inspection archive."""
    archive = output / 'inspection.zip'
    return (output / 'COMPLETE.json').is_file() and archive.is_file() and archive.stat().st_size > 0


def status(receipt):
    record = load(receipt)
    output = Path(record['output'])
    print('Submission:', record['status'], '\nOutput:', output, flush=True)
    job_id = record.get('job_id', '')
    if isinstance(job_id, str) and job_id.isdigit():
        result = subprocess.run(['sacct', '-j', job_id, '--format=JobID,State,ExitCode,Elapsed'],
                                capture_output=True, text=True, timeout=30)
        print(result.stdout.strip() or result.stderr.strip(), flush=True)
        log = output / f'slurm_{job_id}.log'
        print('Log:', log, flush=True)
        if log.is_file():
            with log.open(errors='replace') as stream:
                for line in deque(stream, maxlen=8):
                    print(concise_event(line), flush=True)
    progress = output / 'progress.jsonl'
    if progress.is_file():
        with progress.open(errors='replace') as stream:
            for line in deque(stream, maxlen=1):
                print('Latest progress:', concise_event(line), flush=True)
    for name in ('COMPLETE.json', 'summary.json', 'comparison_summary.json', 'pause.json', 'fatal_error.json'):
        path = output / name
        if path.is_file():
            print(f'{name}: {concise_event(path.read_text())}', flush=True)
    if (output / 'inspection.zip').is_file():
        print('RESULT_ZIP:', output / 'inspection.zip', flush=True)


def submit(root, output, request, hours, previous=None):
    require(hours in (1, 2), 'Maximum allocation is one or two hours')
    receipt = root / RECEIPT
    job_name = 'nrps_fr2732_' + sha(output / 'REQUEST.json')[:10]
    old_job = previous.get('job_id', '') if previous else ''
    check_queue(old_job, job_name)
    cmd = ['sbatch', '--parsable', f'--job-name={job_name}', '--account=nef@a100',
           '--partition=gpu_p5', '--qos=qos_gpu_a100-t3', '--nodes=1', '--ntasks=1',
           '--cpus-per-task=8', '--hint=nomultithread', '--gres=gpu:1', '--constraint=a100',
           f'--time={hours:02d}:00:00', '--signal=USR1@180', '--no-requeue', '--propagate=NONE',
           f'--chdir={root}', f'--output={output}/slurm_%j.log', f'--error={output}/slurm_%j.log',
           str(PACKAGE / 'batch.sh'), str(PACKAGE), str(root), str(output)]
    history = list(previous.get('previous_jobs', [])) + [old_job] if previous else []
    record = dict(request, status='SUBMITTING', job_name=job_name, command=cmd,
                  previous_jobs=history)

    def persist():
        dump(output / 'SUBMISSION.json', record)
        dump(receipt, record)

    persist()
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired) as exc:
        record.update(status='SUBMISSION_UNCERTAIN', error=str(exc))
        persist()
        raise RuntimeError('Slurm submission outcome is uncertain. Inspect squeue before retrying.') from exc
    job_id = result.stdout.strip().split(';', 1)[0]
    if result.returncode != 0 or not job_id.isdigit():
        record.update(status='REJECTED_OR_UNCERTAIN', stdout=result.stdout, stderr=result.stderr)
        persist()
        raise RuntimeError('Slurm did not confirm a job. Inspect its receipt and squeue: ' + result.stderr)
    record.update(status='SUBMITTED', job_id=job_id)
    persist()
    print('SUBMITTED_JOB:', job_id, '\nOutput:', output, flush=True)
    print(f'Resources: 1 A100, 8 CPUs, maximum {hours} hours; frozen 27k/32k features; classifier settings inherited from 26k',
          flush=True)
    print('Log:', output / f'slurm_{job_id}.log', flush=True)
    print('Status: python3 -B', PACKAGE / 'submit.py', 'status', flush=True)
    print('Resume interrupted allocation: python3 -B', PACKAGE / 'submit.py',
          'resume', output, flush=True)


def worker(root, output):
    require(os.environ.get('SLURM_JOB_ID', '').isdigit(), 'Run the worker in a Slurm allocation')
    output = checked_output(root, output)
    with (output / 'run.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        require(not complete(output), 'Readout comparison and inspection export already complete')
        request = read_request(root, output, package_digest())
        require(check_inputs(root) == request['inputs'], 'Input stats differ from the submission')
        # run.py repeats identity validation, verifies all bulk hashes before model
        # loading, and resumes only its verified atomic feature cache.
        args = [sys.executable, '-B', str(PACKAGE / 'run.py'),
                '--root', str(root), '--out', str(output)]
        os.set_inheritable(lock.fileno(), True)
        os.environ['NEURALPS_RUN_LOCK_FD'] = str(lock.fileno())
        os.execv(sys.executable, args)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('preflight', 'run', 'status', 'resume', 'worker'))
    parser.add_argument('output', nargs='?', type=Path)
    parser.add_argument('--root', type=Path, default=PACKAGE.parent)
    parser.add_argument('--hours', type=int, choices=(1, 2), default=2)
    args = parser.parse_intermixed_args(argv)
    root = args.root.resolve()
    require(root.is_dir(), f'Project root is missing: {root}')
    receipt = root / RECEIPT
    if args.action == 'worker':
        require(args.output is not None, 'Worker requires an output directory')
        worker(root, args.output)
        return
    if args.action == 'status':
        status(checked_output(root, args.output) / 'SUBMISSION.json' if args.output else receipt)
        return
    if args.action in ('run', 'preflight') and args.output is not None:
        parser.error('Output is assigned automatically for a new run')
    digest = package_digest()
    if args.action == 'preflight':
        lineage = select_lineage(root)
        inputs = check_inputs(root)
        print(json.dumps(dict(lineage, status='PREFLIGHT_OK', inputs=inputs,
                              package_manifest_sha256=digest,
                              protocol_sha256=sha(PACKAGE / 'protocol.json'),
                              checkpoint_validation='SHA-256, embedded step and baseline archive verification pending compute',
                              regularization_selection='fixed from completed 26k training-only selection; no retuning',
                              large_input_hashes='deferred to compute node',
                              encoder_training=False, classifier_training=True,
                              embedding_extraction=False, login_node_model_work=False),
                         indent=2), flush=True)
        return
    with (root / LOCK).open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.action == 'run':
            if receipt.is_file():
                recorded = load(receipt)
                require(recorded.get('status') == 'SUBMITTED'
                        and str(recorded.get('job_id', '')).isdigit(),
                        f'Existing submission is unresolved. Inspect {receipt} and squeue before retrying.')
                print('Submission already recorded. Use status or resume.', flush=True)
                status(receipt)
                return
            lineage = select_lineage(root)
            inputs = check_inputs(root)
            stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
            output = root / (PREFIX + stamp + '_' + digest[:8])
            output.mkdir()
            request = dict(lineage, root=str(root), output=str(output), package=str(PACKAGE),
                           package_manifest_sha256=digest,
                           protocol_sha256=sha(PACKAGE / 'protocol.json'), inputs=inputs,
                           encoder_training=False, classifier_training=True,
                           embedding_extraction=False)
            dump(output / 'REQUEST.json', request)
            (output / 'REQUEST.sha256').write_text(sha(output / 'REQUEST.json') + '\n')
            print('Frozen checkpoints: 27000 and 32000; settings fixed from completed 26000 baseline', flush=True)
            submit(root, output, request, args.hours)
            return
        output = checked_output(root, args.output or Path(load(receipt)['output']))
        previous = load(output / 'SUBMISSION.json')
        require(previous.get('status') == 'SUBMITTED'
                and str(previous.get('job_id', '')).isdigit(),
                'Previous allocation was not confirmed. Inspect its receipt and the queue.')
        if complete(output):
            status(output / 'SUBMISSION.json')
            return
        request = read_request(root, output, digest)
        require(check_inputs(root) == request['inputs'], 'Input stats differ from the submission')
        with (output / 'run.lock').open('a') as run_lock:
            fcntl.flock(run_lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        submit(root, output, request, args.hours, previous)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, subprocess.SubprocessError) as exc:
        sys.exit(f'ERROR: {exc}')
