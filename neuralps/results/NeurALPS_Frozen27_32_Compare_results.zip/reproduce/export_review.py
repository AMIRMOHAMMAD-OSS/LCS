#!/usr/bin/env python3
"""Export bounded readout results; never include pretrained checkpoint weights."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import zipfile

MAX_BYTES = 95 * (1 << 20)


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def export(out, package):
    out, package = Path(out).resolve(), Path(package).resolve()
    if not (out / 'COMPLETE.json').is_file():
        raise RuntimeError('Cannot export an incomplete readout evaluation')
    files = {}
    allowed = {'.json', '.npz', '.csv', '.txt', '.jsonl', '.gz', '.zip'}
    for p in sorted(out.rglob('*')):
        relative = p.relative_to(out)
        if (not p.is_file() or p.suffix not in allowed or p.is_symlink()
                or any(x.startswith('.') or x in {'__pycache__','row_cache','cache','reproduce'} for x in relative.parts)
                or p.name in {'inspection.zip','REVIEW_MANIFEST.json','fatal_error.json','pause.json'}):
            continue
        files[str(relative)] = p
    package_manifest = json.loads((package / 'PACKAGE_MANIFEST.json').read_text())
    for relative, expected in package_manifest['files'].items():
        p=(package/relative).resolve()
        if not p.is_relative_to(package) or not p.is_file() or sha(p)!=expected:
            raise RuntimeError('Package changed before review export: '+relative)
        files['reproduce/'+relative] = p
    files['reproduce/PACKAGE_MANIFEST.json'] = package/'PACKAGE_MANIFEST.json'
    manifest = dict(schema='neuralps_frozen2732_review_v1',
                    files={name:dict(sha256=sha(p),bytes=p.stat().st_size) for name,p in files.items()},
                    excluded=['pretrained checkpoint weights','large project ESM-C caches','active Slurm log'],
                    bundled_features='The small audited labelled feature bank is retained in reproduce/labelled_assets.',
                    baseline26_inspection_sha256=json.loads((out/'COMPLETE.json').read_text())['baseline26_inspection_sha256'])
    manifest_text=json.dumps(manifest,indent=2,sort_keys=True,allow_nan=False)+'\n'
    temp=out/'inspection.zip.tmp'
    with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,p in files.items():
            z.write(p,name)
        z.writestr('REVIEW_MANIFEST.json',manifest_text)
    if temp.stat().st_size >= MAX_BYTES:
        temp.unlink()
        raise RuntimeError('Review archive exceeds the 95 MiB transfer limit; outputs remain intact')
    with zipfile.ZipFile(temp) as z:
        if z.testzip() is not None:
            raise RuntimeError('Review ZIP CRC validation failed')
    archive=out/'inspection.zip'
    temp.replace(archive)
    (out/'REVIEW_MANIFEST.json').write_text(manifest_text)
    return archive,sha(archive)
