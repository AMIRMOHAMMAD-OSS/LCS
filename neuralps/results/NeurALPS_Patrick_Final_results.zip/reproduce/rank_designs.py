"""Deterministic, identity-audited top-50 selection for each exchange cohort.

Primary scores are frozen classifier outputs, not calibrated probabilities.
Other readouts and concentration summaries remain diagnostics. No score blend,
diversity quota, donor ban or reference-percentile availability gate is used.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import re

VERSION = 'neuralps_patrick_exact_top50_v1'
COHORTS = ('doubles', 'triples')
PRIMARY_MODELS = {'doubles': 'context_chemistry_bode2',
                  'triples': 'static_design_bode2'}
MODELS = tuple(sorted(f'{p}_{s}' for p in
                     ('maps_chemistry', 'context_chemistry', 'combined', 'static_design')
                     for s in ('bode2', 'all3w025')))
FULL_COUNTS = {'doubles': 3675, 'triples': 42875}
KNOWN_COUNTS = {'doubles': 33, 'triples': 27}
NATIVE = {'native', 'X'}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def json_text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False)


def dump(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True,
                                    ensure_ascii=False, allow_nan=False) + '\n')
    temporary.replace(path)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def _canonical_key(row):
    return row['assembly_id'], row['candidate_index'], row['sequence_key']


def _score(row, model):
    return float(row['scores'][model]['logit'])


def _registered_known(row):
    return row.get('is_known_design', row['is_known'])


def _sigmoid(logit):
    if logit >= 0:
        return 1.0 / (1.0 + math.exp(-logit))
    e = math.exp(logit)
    return e / (1.0 + e)


def _check_row(row):
    require(isinstance(row, dict), 'Scored row must be a dictionary')
    cohort = row.get('cohort')
    require(cohort in COHORTS, 'Unknown exchange cohort')
    require(isinstance(row.get('assembly_id'), str) and row['assembly_id'],
            'Missing canonical assembly ID')
    require(type(row.get('candidate_index')) is int and row['candidate_index'] >= 0,
            'Invalid candidate index: ' + row['assembly_id'])
    require(isinstance(row.get('sequence_key'), str) and
            re.fullmatch(r'[0-9a-f]{64}', row['sequence_key']),
            'Missing canonical mature-sequence SHA-256: ' + row['assembly_id'])
    require(type(row.get('is_known')) is bool,
            'Known-design flag must be Boolean: ' + row['assembly_id'])
    for optional in ('is_known_design', 'is_known_sequence'):
        require(optional not in row or type(row[optional]) is bool,
                'Known-identity metadata must be Boolean: ' + row['assembly_id'])
    donors = row.get('donor_codes')
    require(isinstance(donors, list) and len(donors) == 3 and
            all(isinstance(d, str) and (d in NATIVE or re.fullmatch(r'\d{3}', d))
                for d in donors), 'Invalid donor-position registry: ' + row['assembly_id'])
    native = [i for i, d in enumerate(donors) if d in NATIVE]
    require(len(native) == (1 if cohort == 'doubles' else 0),
            'Exchange count differs from cohort: ' + row['assembly_id'])
    expected_native = 'XUT' + str(native[0] + 2) if native else None
    require(row.get('retained_native') == expected_native,
            'Retained-native position differs from donor codes: ' + row['assembly_id'])
    require(isinstance(row.get('score_status'), str) and row['score_status'],
            'Explicit score status required: ' + row['assembly_id'])
    if row['score_status'] != 'SCORED':
        return
    scores = row.get('scores')
    require(isinstance(scores, dict) and set(scores) == set(MODELS),
            'All eight frozen26 readouts are required: ' + row['assembly_id'])
    for model, pair in scores.items():
        require(isinstance(pair, dict), 'Invalid score record: ' + model)
        z, p = pair.get('logit'), pair.get('sigmoid')
        require(isinstance(z, (int, float)) and not isinstance(z, bool) and
                isinstance(p, (int, float)) and not isinstance(p, bool) and
                math.isfinite(z) and math.isfinite(p) and 0 <= p <= 1,
                'Nonfinite or invalid classifier output: ' + row['assembly_id'] + '/' + model)
        require(math.isclose(p, _sigmoid(z), rel_tol=1e-7, abs_tol=1e-7),
                'Sigmoid/logit mismatch: ' + row['assembly_id'] + '/' + model)


def _ranks(rows, model):
    """Rank by finite logit; exact ties receive midrank and canonical order."""
    ordered = sorted(rows, key=lambda r: (-_score(r, model), *_canonical_key(r)))
    result = {}
    n = len(ordered)
    start = 0
    while start < n:
        end = start + 1
        while end < n and _score(ordered[end], model) == _score(ordered[start], model):
            end += 1
        midrank = ((start + 1) + end) / 2
        percentile = 100 * (1 - (midrank - 1) / (n - 1)) if n > 1 else None
        for i in range(start, end):
            result[ordered[i]['assembly_id']] = dict(rank=i + 1, midrank=midrank,
                percentile=percentile, tie_count=end-start, pool_count=n)
        start = end
    return ordered, result


def _concentration(rows):
    donor_positions = {f'XUT{i+2}': Counter(r['donor_codes'][i] for r in rows)
                       for i in range(3)}
    donors = Counter(d for r in rows for d in r['donor_codes'] if d not in NATIVE)
    result = dict(designs=len(rows), donor_occurrences=dict(sorted(donors.items())),
        donor_by_recipient_position={k: dict(sorted(v.items())) for k, v in donor_positions.items()},
        retained_native=dict(sorted(Counter(str(r['retained_native']) for r in rows).items())),
        validated_phylogenetic_families=False, quotas_applied=False,
        wet_lab_inventory='Unverified unless an explicit source field states otherwise.')
    # Preserve actual available source-field vocabulary, not inferred family labels.
    sources = [d for r in rows for d in r.get('donor_sources', []) if isinstance(d, dict)]
    for field in ('source_strain', 'strain', 'source_bgc', 'source_BGC', 'source_cluster',
                  'substrate_aa', 'substrate', 'expected_amino_acid', 'aa', 'architecture'):
        observed = [str(d[field]) for d in sources if d.get(field) not in (None, '')]
        if observed:
            result[field + '_occurrences'] = dict(sorted(Counter(observed).items()))
    peptide = [r.get('expected_peptide_aa') or r.get('input_inventory', {}).get('expected_peptide_aa')
               for r in rows]
    if any(p is not None for p in peptide):
        result['expected_peptide_aa'] = dict(sorted(Counter(str(p) for p in peptide).items()))
    return result


def _csv_value(value):
    if isinstance(value, (dict, list, tuple)):
        return json_text(value)
    return value


def _write_csv(path, rows):
    leading = ['cohort', 'rank', 'midrank', 'candidate_percentile', 'selected_top50',
               'assembly_id', 'candidate_index', 'sequence_key', 'donor_codes',
               'retained_native', 'primary_model', 'primary_logit', 'primary_sigmoid',
               'within_native_position_rank', 'within_native_position_percentile',
               'is_known', 'score_status', 'selection_reason']
    flat = []
    for row in rows:
        item = dict(row)
        for model, score in item.get('scores', {}).items():
            item[model + '__logit'] = score['logit']
            item[model + '__sigmoid'] = score['sigmoid']
        flat.append(item)
    fields = leading + sorted({k for r in flat for k in r} - set(leading))
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in flat:
            writer.writerow({k: _csv_value(v) for k, v in row.items()})
    temporary.replace(path)


def _write_jsonl_gz(path, rows):
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('wb') as stream:
        with gzip.GzipFile(fileobj=stream, filename='', mode='wb', mtime=0) as compressed:
            for row in rows:
                compressed.write((json_text(row) + '\n').encode())
    temporary.replace(path)


def rank_and_export(rows, out, protocol):
    """Select exactly 50 eligible unique sequences per cohort; return audit.

    Protocol may supply primary_models, selection_count, expected_counts,
    expected_known_counts, and known_sequence_keys. Contradictory primaries or
    a changed panel size fail. Counts default to the registered full libraries.
    All output is delayed until both independent selections pass identity checks.
    """
    rows = list(rows)
    require(protocol.get('primary_models', PRIMARY_MODELS) == PRIMARY_MODELS,
            'Primary ranking models differ from the frozen selection decision')
    require(protocol.get('selection_count', 50) == 50, 'The user requested 50 of each cohort')
    expected = protocol.get('expected_counts', FULL_COUNTS)
    expected_known = protocol.get('expected_known_counts', KNOWN_COUNTS)
    require(set(expected) == set(COHORTS) and set(expected_known) == set(COHORTS),
            'Expected library count contract is incomplete')
    for row in rows:
        _check_row(row)
    require(len({r['assembly_id'] for r in rows}) == len(rows), 'Duplicate canonical assembly ID')
    require(len({(r['cohort'], r['candidate_index']) for r in rows}) == len(rows),
            'Duplicate candidate index within a cohort')
    require(dict(Counter(r['cohort'] for r in rows)) == expected,
            'Full library row counts differ from the registered inventory')
    require({c: sum(_registered_known(r) for r in rows if r['cohort'] == c) for c in COHORTS} == expected_known,
            'Known-design counts differ from the registered inventory')
    external_known = protocol.get('known_sequence_keys', [])
    require(isinstance(external_known, (list, tuple)) and
            all(isinstance(k, str) and re.fullmatch(r'[0-9a-f]{64}', k) for k in external_known),
            'Invalid known-sequence registry')
    known_keys = set(external_known) | {r['sequence_key'] for r in rows
                                       if _registered_known(r) or r['is_known'] or r.get('is_known_sequence', False)}
    exclusions, duplicate_groups, candidate_rows = [], {}, {}
    summaries, ranked, selected = {}, {}, {}
    for cohort in COHORTS:
        source = [r for r in rows if r['cohort'] == cohort]
        eligible = []
        counts = Counter()
        for row in sorted(source, key=_canonical_key):
            reason = None
            if _registered_known(row):
                reason = 'previously_tested_identity'
            elif row['sequence_key'] in known_keys:
                reason = 'sequence_alias_of_previously_tested_construct'
            elif row['score_status'] != 'SCORED':
                reason = 'explicit_scoring_failure'
            if reason:
                counts[reason] += 1
                exclusions.append(dict(cohort=cohort, assembly_id=row['assembly_id'],
                    candidate_index=row['candidate_index'], sequence_key=row['sequence_key'],
                    reason=reason, score_status=row['score_status']))
            else:
                eligible.append(row)
        groups = defaultdict(list)
        for row in eligible:
            groups[row['sequence_key']].append(row)
        representatives = []
        duplicate_groups[cohort] = []
        for sequence, aliases in sorted(groups.items()):
            aliases.sort(key=_canonical_key)
            representative = aliases[0]
            representatives.append(representative)
            if len(aliases) > 1:
                logits = [_score(a, PRIMARY_MODELS[cohort]) for a in aliases]
                duplicate_groups[cohort].append(dict(sequence_key=sequence,
                    representative=representative['assembly_id'],
                    aliases=[a['assembly_id'] for a in aliases],
                    primary_logit_spread=max(logits)-min(logits),
                    alias_scores_differ=max(logits) != min(logits),
                    choice='Canonical ID before score; no optimistic alias selection.'))
                for row in aliases[1:]:
                    counts['duplicate_sequence_alias'] += 1
                    exclusions.append(dict(cohort=cohort, assembly_id=row['assembly_id'],
                        candidate_index=row['candidate_index'], sequence_key=sequence,
                        representative=representative['assembly_id'], reason='duplicate_sequence_alias',
                        score_status=row['score_status']))
        require(len(representatives) >= 50,
                f'Fewer than 50 eligible unique new {cohort}: {len(representatives)}')
        candidate_rows[cohort] = representatives
        model_rankings = {m: _ranks(representatives, m) for m in MODELS}
        primary = PRIMARY_MODELS[cohort]
        ordered, ranks = model_rankings[primary]
        cutoff = _score(ordered[49], primary)
        native_ranks = {}
        if cohort == 'doubles':
            for native in sorted({r['retained_native'] for r in representatives}):
                group = [r for r in representatives if r['retained_native'] == native]
                native_ranks.update(_ranks(group, primary)[1])
        ranked[cohort] = []
        for row in ordered:
            aid = row['assembly_id']
            position = ranks[aid]
            item = dict(row)
            item.update(rank=position['rank'], midrank=position['midrank'],
                candidate_percentile=position['percentile'], primary_tie_count=position['tie_count'],
                percentile_pool_count=position['pool_count'], primary_model=primary,
                primary_logit=_score(row, primary), primary_sigmoid=float(row['scores'][primary]['sigmoid']),
                primary_logit_minus_cutoff=_score(row, primary)-cutoff,
                primary_ranks_from_cutoff=position['rank']-50,
                selected_top50=position['rank'] <= 50,
                selection_reason='Strict primary-score top50 eligible unique new sequence' if position['rank'] <= 50 else 'Below primary top50 cutoff',
                model_ranks={m: model_rankings[m][1][aid]['rank'] for m in MODELS},
                model_midrank_percentiles={m: model_rankings[m][1][aid]['percentile'] for m in MODELS},
                rank_disagreement_is_calibrated_uncertainty=False)
            if cohort == 'doubles':
                nr = native_ranks[aid]
                item.update(within_native_position_rank=nr['rank'],
                    within_native_position_midrank=nr['midrank'],
                    within_native_position_percentile=nr['percentile'],
                    within_native_position_count=nr['pool_count'])
            ranked[cohort].append(item)
        selected[cohort] = ranked[cohort][:50]
        tied = [r['assembly_id'] for r in ordered if _score(r, primary) == cutoff]
        chosen = {r['assembly_id'] for r in selected[cohort]}
        overlap = {}
        for model, (alternative, _) in model_rankings.items():
            other = {r['assembly_id'] for r in alternative[:50]}
            intersection = len(chosen & other)
            overlap[model] = dict(shared_count=intersection, union_count=len(chosen | other),
                jaccard=intersection/len(chosen | other), fraction_of_primary=intersection/50,
                interpretation='Descriptive agreement of correlated readouts, not a confidence level.')
        summaries[cohort] = dict(input_rows=len(source), expected_known_designs=expected_known[cohort],
            exclusions=dict(sorted(counts.items())), eligible_unique_new=len(representatives),
            selected_count=50, primary_model=primary,
            mature_sequence_alias_groups=len(duplicate_groups[cohort]),
            cutoff_logit=cutoff, cutoff_tie_count=len(tied),
            cutoff_tied_ids=tied, cutoff_tie_selected_ids=[a for a in tied if a in chosen],
            cutoff_tie_unselected_ids=[a for a in tied if a not in chosen],
            next_eligible_logit=_score(ordered[50], primary) if len(ordered) > 50 else None,
            selected_concentration=_concentration(selected[cohort]),
            secondary_top50_overlap=overlap)
    by_sequence = defaultdict(list)
    for cohort in COHORTS:
        for row in selected[cohort]:
            by_sequence[row['sequence_key']].append((cohort, row['assembly_id']))
    overlaps = {k: v for k, v in by_sequence.items() if len(v) > 1}
    require(not overlaps, 'Independent top50 panels share mature sequences; resolve the design registry before selection: ' + json_text(overlaps))
    audit = dict(version=VERSION, status='PATRICK_TOP50_SELECTION_COMPLETE',
        primary_models=PRIMARY_MODELS, selected_new_designs=100,
        controls_or_replicates_counted=False, score_is_calibrated_probability=False,
        exact_candidate_percentile='100 * (1 - (descending_midrank - 1)/(eligible_pool_count - 1))',
        percentile_reference='Eligible unique untested candidates within the same cohort',
        exact_tie_order='Canonical assembly ID, then candidate index and mature-sequence SHA-256',
        duplicate_representative='Canonical assembly ID before scoring, never highest-scoring alias',
        cohort_summaries=summaries, duplicate_sequence_groups=duplicate_groups,
        external_known_sequence_keys=len(set(external_known)), known_sequence_union=len(known_keys),
        cross_cohort_selected_sequence_overlap=0, diversity_substitutions=0,
        no_donor_exclusions=True, no_natural_reference_support_gate=True,
        retrospective_pipeline_selection=True,
        inventory_status='Wet-lab availability has not been independently verified.',
        protocol_digest=hashlib.sha256(json_text(protocol).encode()).hexdigest())
    out = Path(out).resolve()
    folder = out / 'rankings'
    folder.mkdir(parents=True, exist_ok=True)
    written = []
    for cohort in COHORTS:
        files = {
            f'{cohort}_ranked_all.csv': lambda path, c=cohort: _write_csv(path, ranked[c]),
            f'{cohort}_ranked_all.jsonl.gz': lambda path, c=cohort: _write_jsonl_gz(path, ranked[c]),
            f'{cohort}_selected_top50.csv': lambda path, c=cohort: _write_csv(path, selected[c]),
            f'{cohort}_selected_top50.json': lambda path, c=cohort: dump(path, selected[c]),
        }
        for name, writer in files.items():
            path = folder / name
            writer(path)
            written.append(path)
    exclusion_file = folder / 'selection_exclusions.json'
    dump(exclusion_file, sorted(exclusions, key=lambda r: (r['cohort'], r['assembly_id'])))
    written.append(exclusion_file)
    audit['output_files'] = {str(p.relative_to(out)): dict(sha256=sha(p), bytes=p.stat().st_size)
                             for p in written}
    dump(out / 'selection_audit.json', audit)
    return audit
