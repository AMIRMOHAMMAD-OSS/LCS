#!/usr/bin/env python3
"""Export every candidate, all maps and both top50 panels without duplicate tables."""
from __future__ import annotations
import gzip
import hashlib
import json
import lzma
from pathlib import Path
import zipfile

MAX_BYTES = 95 * (1 << 20)
COHORTS = ('doubles', 'triples')

def require(ok, message):
    if not ok: raise RuntimeError(message)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def lines(path):
    with gzip.open(path, 'rt') as stream:
        for line in stream: yield json.loads(line)

def recompress_jsonl(source, target):
    """Losslessly replace gzip with XZ for transfer; verify decoded bytes exactly."""
    temp=target.with_suffix(target.suffix+'.tmp')
    expected=hashlib.sha256();size=0
    with gzip.open(source,'rb') as incoming, lzma.open(temp,'wb',preset=6) as outgoing:
        for block in iter(lambda: incoming.read(1<<20),b''):
            expected.update(block);size+=len(block);outgoing.write(block)
    with lzma.open(temp,'rb') as incoming:
        actual=hashlib.file_digest(incoming,'sha256').hexdigest()
    require(actual==expected.hexdigest(), 'Lossless review recompression changed decoded bytes')
    temp.replace(target)
    return dict(source=str(source.name),source_sha256=sha(source),decoded_sha256=actual,decoded_bytes=size)

def write_unranked(out, cohort):
    """Ranked rows already contain every score; retain excluded/known rows separately."""
    ranked = out/'rankings'/(cohort+'_ranked_all.jsonl.gz')
    ids = [r['assembly_id'] for r in lines(ranked)]
    require(len(ids)==len(set(ids)), 'Duplicate ranked identities')
    included = set(ids)
    target = out/(cohort+'_unranked_scores.jsonl.gz')
    temp = target.with_suffix(target.suffix+'.tmp')
    count = 0; seen = set()
    with temp.open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as stream:
            for row in lines(out/(cohort+'_scores.jsonl.gz')):
                aid = row['assembly_id']
                require(aid not in seen, 'Duplicate scored identities')
                seen.add(aid)
                if aid not in included:
                    stream.write((json.dumps(row,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode())
                    count += 1
    require(included <= seen, 'Ranked identity missing from full scores')
    temp.replace(target)
    return dict(all=len(seen), ranked=len(included), unranked=count)

def export(out, package):
    out, package = Path(out).resolve(), Path(package).resolve()
    done = json.loads((out/'COMPLETE.json').read_text())
    require(done['status']=='PATRICK_FINAL_SCORING_COMPLETE', 'Cannot export incomplete scoring')
    coverage = {}
    for cohort in COHORTS:
        for rel in (cohort+'_scores.jsonl.gz',cohort+'_maps.jsonl.gz',
                    cohort+'_selected_model_inputs.jsonl.gz',cohort+'_selected_maps.jsonl.gz',
                    cohort+'_selected_mature_proteins.fasta',
                    'rankings/'+cohort+'_ranked_all.jsonl.gz',
                    'rankings/'+cohort+'_selected_top50.json',
                    'rankings/'+cohort+'_selected_top50.csv'):
            require((out/rel).is_file() and not (out/rel).is_symlink(), 'Missing review payload: '+rel)
        coverage[cohort] = write_unranked(out,cohort)
        require(coverage[cohort]['all']==done['scored_counts'][cohort], 'Review candidate count differs')
        selected=json.loads((out/'rankings'/(cohort+'_selected_top50.json')).read_text())
        require(len(selected)==50, 'Review panel count differs')
    excluded_files = {c+'_scores.jsonl.gz' for c in COHORTS}
    excluded_files |= {'rankings/'+c+'_ranked_all.csv' for c in COHORTS}
    files = {}
    for p in sorted(out.rglob('*')):
        rel = p.relative_to(out)
        if (not p.is_file() or p.is_symlink() or p.suffix not in {'.json','.csv','.gz','.fasta','.txt','.sha256'}
                or any(x.startswith('.') or x in {'chunks','__pycache__','reproduce'} for x in rel.parts)
                or str(rel) in excluded_files
                or p.name in {'REVIEW_MANIFEST.json','fatal_error.json','pause.json'}):
            continue
        files[str(rel)] = p
    recompressed={}
    for cohort in COHORTS:
        for relative in (cohort+'_maps.jsonl.gz','rankings/'+cohort+'_ranked_all.jsonl.gz'):
            source=files.pop(relative)
            target=source.with_suffix('.xz')
            new_relative=str(target.relative_to(out))
            recompressed[new_relative]=recompress_jsonl(source,target)
            recompressed[new_relative]['source']=relative
            files[new_relative]=target
    manifest_path = package/'PACKAGE_MANIFEST.json'
    package_manifest = json.loads(manifest_path.read_text())
    for relative, expected in package_manifest['files'].items():
        p = (package/relative).resolve()
        require(p.is_relative_to(package) and p.is_file() and sha(p)==expected,
                'Package changed before review export: '+relative)
        files['reproduce/'+relative] = p
    files['reproduce/PACKAGE_MANIFEST.json'] = manifest_path
    manifest = dict(schema='neuralps_patrick_final_review_v1',candidate_coverage=coverage,
        files={name:dict(sha256=sha(p),bytes=p.stat().st_size) for name,p in files.items()},
        checkpoint_sha256=done['checkpoint_sha256'],
        complete_candidate_scores='rankings/*_ranked_all.jsonl.xz plus *_unranked_scores.jsonl.gz',
        all_maps='*_maps.jsonl.xz contains every candidate, including known/excluded rows',
        lossless_recompression=recompressed,
        omitted_duplicate_files=sorted(excluded_files),
        excluded=['HPC chunk feature cache','pretrained encoder weights','large project embedding banks','active Slurm log'],
        retained_on_hpc='Complete CSV tables, all-score JSONL and committed feature chunks remain in the output directory.')
    text=json.dumps(manifest,indent=2,sort_keys=True,allow_nan=False)+'\n'
    temp=out/'inspection.zip.tmp'
    with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,p in files.items(): z.write(p,name)
        z.writestr('REVIEW_MANIFEST.json',text)
    require(temp.stat().st_size < MAX_BYTES,
            'Review ZIP exceeds95MiB; complete outputs remain intact. Do not rerun inference; adjust export only.')
    with zipfile.ZipFile(temp) as z:
        require(z.testzip() is None, 'Review ZIP CRC failed')
    archive=out/'inspection.zip';temp.replace(archive)
    (out/'REVIEW_MANIFEST.json').write_text(text)
    return archive,sha(archive)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('out',type=Path)
    args=p.parse_args()
    path,digest=export(args.out,Path(__file__).resolve().parent)
    print('RESULT_ZIP:',path);print('RESULT_SHA256:',digest)
