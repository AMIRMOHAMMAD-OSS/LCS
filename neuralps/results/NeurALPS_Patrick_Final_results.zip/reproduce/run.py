#!/usr/bin/env python3
"""Resume-safe inference and strict new-design selection; never fit a model."""
from __future__ import annotations
import argparse
from collections import Counter
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import sys
import time
import traceback
import zipfile

PACKAGE = Path(__file__).resolve().parent
BLOCKS = ('context', 'chemistry', 'structure', 'compatibility')

def require(ok, message):
    if not ok: raise RuntimeError(message)

def sha(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def dump(path, value):
    path = Path(path); temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n')
    temp.replace(path)

def write_lines(path, rows):
    path = Path(path); temp = path.with_name(path.name + '.tmp')
    with temp.open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0, compresslevel=6) as stream:
            for row in rows:
                stream.write((json.dumps(row, sort_keys=True, separators=(',', ':'), allow_nan=False)+'\n').encode())
    temp.replace(path)

def read_lines(path):
    with gzip.open(path, 'rt') as f:
        for line in f: yield json.loads(line)

def merge_lines(paths, target):
    def rows():
        for path in paths: yield from read_lines(path)
    write_lines(target, rows())

class Paused(Exception): pass

def verify_evidence(root, protocol):
    """Authenticate live baseline inputs and bundled coefficients against sealed ZIPs."""
    baseline = root/protocol['baseline26']['path']
    comparison = root/protocol['comparison']['path']
    require(sha(baseline/'inspection.zip') == protocol['baseline26']['sha256'], 'Baseline review ZIP changed')
    require(sha(comparison/'inspection.zip') == protocol['comparison']['sha256'], 'Matched review ZIP changed')
    names = ('COMPLETE.json', 'features.npz', 'features.json', 'rows.json', 'activity_holdout.json', 'maps.jsonl.gz')
    proof = {}
    with zipfile.ZipFile(baseline/'inspection.zip') as z:
        manifest = json.loads(z.read('REVIEW_MANIFEST.json'))['files']
        for name in names:
            expected = manifest[name]['sha256']
            require(sha(baseline/name) == expected, 'Baseline live payload changed: '+name)
            proof[name] = expected
        for p in sorted((PACKAGE/'models').glob('*')):
            require(p.suffix in ('.npz','.json'), 'Unexpected model payload')
            require(sha(p) == manifest['models/'+p.name]['sha256'], 'Bundled readout differs from audited fit: '+p.name)
    done = load(baseline/'COMPLETE.json')
    require(done['status']=='FROZEN26_READOUT_COMPLETE' and done['checkpoint_step']==26000
            and done['encoder_updates']==0, 'Baseline completion differs')
    with zipfile.ZipFile(comparison/'inspection.zip') as z:
        done = json.loads(z.read('COMPLETE.json'))
        report = json.loads(z.read('checkpoint_comparison.json'))
        require(done['status']=='FROZEN2732_COMPARISON_COMPLETE' and done['encoder_updates']==0,
                'Matched comparison incomplete')
        require(all(v['pass_check'] and v['max_absolute_logit_difference']==0
                    for v in report['static_design_controls'].values()), 'Matched static controls failed')
        require(hashlib.sha256(z.read('checkpoint_comparison.json')).hexdigest()==
                sha(PACKAGE/'evidence/matched_checkpoint_comparison.json'), 'Decision evidence differs')
    return dict(status='PASS', baseline=str(baseline), comparison=str(comparison),
                live_baseline_sha256=proof, frozen_existing_readouts=True)

def check_chunk(folder, identity, cohort, indices):
    marker = folder/'CHUNK.json'
    if not marker.exists(): return False
    saved = load(marker)
    require(saved['identity']==identity and saved['cohort']==cohort and saved['indices']==indices,
            'Chunk identity/order changed: '+str(folder))
    require(set(saved['files']) == {'features.npz','rows.jsonl.gz','maps.jsonl.gz','parity.json'},
            'Chunk payload inventory differs')
    for rel, checksum in saved['files'].items():
        require(sha(folder/rel)==checksum, 'Committed chunk payload changed: '+str(folder/rel))
    return True

def commit_chunk(folder, identity, cohort, indices):
    names = ('features.npz','rows.jsonl.gz','maps.jsonl.gz','parity.json')
    dump(folder/'CHUNK.json', dict(identity=identity, cohort=cohort, indices=indices,
                                  files={n:sha(folder/n) for n in names}))

def check_parity(rows, features, maps, baseline_rows, baseline_features, tolerance):
    import numpy as np
    by = {(r['cohort'], tuple(r['donor_codes'])):r for r in baseline_rows
          if r['cohort'] in ('doubles','triples')}
    matches = []
    for i, row in enumerate(rows):
        ref = by.get((row['cohort'],tuple(row['donor_codes'])))
        if ref is None: continue
        require(row['assembly_id']==ref['assembly_id'], 'Known construct identity changed')
        require(maps[i]['model_signature']==ref['route_fingerprint'], 'Known construct route changed')
        errors = {}
        for key in BLOCKS:
            a, b = features[key][i], baseline_features[key][ref['index']]
            require(np.array_equal(np.isnan(a),np.isnan(b)), 'Known missingness changed: '+key)
            errors[key] = float(np.max(np.abs(a[np.isfinite(b)]-b[np.isfinite(b)]),initial=0.))
            if key in ('chemistry','structure'):
                require(np.array_equal(a,b), 'Known static features differ: '+key)
            else:
                require(np.allclose(a,b,atol=tolerance,rtol=0.,equal_nan=True),
                        'Known frozen features differ: '+row['assembly_id']+'/'+key)
        matches.append(dict(assembly_id=row['assembly_id'], cohort=row['cohort'], max_abs_error=errors))
    return matches

def score_chunk(result, protocol):
    import numpy as np
    import fit_readout as fit
    features, rows = result['features'], result['rows']
    logits = {name:fit.predict_saved(PACKAGE/'models'/(name+'.json'),features,rows,list(range(len(rows))))
              for name in protocol['model_names']}
    require(all(np.isfinite(v).all() for v in logits.values()), 'Nonfinite classifier output')
    for i, row in enumerate(rows):
        row['scores'] = {name:dict(logit=float(values[i]),sigmoid=float(fit.sigmoid(values[i])))
                        for name,values in logits.items()}
        cov = row['map_coverage']
        row['score_status'] = 'SCORED' if cov['total_objects']==cov['scored_objects'] else 'INCOMPLETE_MAP'
        row['map_summaries'] = {name:float(value) if np.isfinite(value) else None
                                for name,value in zip(result['columns']['compatibility'],features['compatibility'][i],strict=True)}
        row['calibrated'] = False
        row['feasibility_status'] = 'SOURCE_BUILD_RECONSTRUCTED_INVENTORY_NOT_VERIFIED'
    return rows

def run(args):
    import submit
    root,out = args.root.resolve(),args.out.resolve()
    require(os.environ.get('SLURM_JOB_ID','').isdigit(), 'Run only through the Slurm worker')
    require(out.parent==root and out.name.startswith(submit.PREFIX), 'Unexpected output directory')
    fd = os.environ.get('NEURALPS_RUN_LOCK_FD','')
    require(fd.isdigit(), 'Missing inherited output lock')
    fd = int(fd); a,b = os.fstat(fd),(out/'run.lock').stat()
    require((a.st_dev,a.st_ino)==(b.st_dev,b.st_ino), 'Wrong inherited lock')
    fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    digest = submit.package_digest(); request = submit.read_request(root,out,digest)
    protocol = load(PACKAGE/'protocol.json')
    require(protocol['primary_models']==load(PACKAGE/'DECISION.json')['primary_models'], 'Primary policy changed')
    identity = dict(package_manifest_sha256=digest,request_sha256=sha(out/'REQUEST.json'),
                    protocol_sha256=sha(PACKAGE/'protocol.json'))
    def emit(stage,**kwargs):
        line = json.dumps(dict(stage=stage,**kwargs),allow_nan=False)
        print(line,flush=True)
        with (out/'progress.jsonl').open('a') as f: f.write(line+'\n')
    def stop(signum, frame): raise Paused('Allocation signal '+str(signum))
    for s in (signal.SIGTERM,signal.SIGUSR1,signal.SIGINT): signal.signal(s,stop)
    started=time.monotonic()
    try:
        emit('VERIFYING_FINAL_SCORING_INPUTS',encoder_updates=0,classifier_training=False)
        require(submit.check_inputs(root,verify_hashes=True)==request['inputs'], 'Inputs changed after submission')
        proof=verify_evidence(root,protocol); dump(out/'evidence_check.json',proof)
        baseline=Path(proof['baseline'])
        import numpy as np
        import torch
        import frozen_features as ff
        import library_features as lib
        from supervised import Bode2Design
        require(torch.__version__.split('+')[0]=='2.8.0', 'Use the pinned PyTorch2.8 runtime')
        require(torch.cuda.is_available() and torch.cuda.device_count()==1, 'Allocate exactly one CUDA GPU')
        torch.set_num_threads(8);torch.manual_seed(20261108);np.random.seed(20261108)
        torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
        torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
        torch.set_float32_matmul_precision('highest');torch.use_deterministic_algorithms(True)
        if (out/'run_config.json').exists():
            require(load(out/'run_config.json')['identity']==identity, 'Run identity changed')
        else:
            dump(out/'run_config.json',dict(identity=identity,protocol=protocol,
                runtime=dict(python=sys.version,numpy=np.__version__,torch=torch.__version__),
                encoder_training=False,classifier_training=False,embedding_extraction=False))
        with np.load(baseline/'features.npz',allow_pickle=False) as z:
            baseline_features={key:z[key].copy() for key in BLOCKS}
        baseline_rows=load(baseline/'rows.json')['rows']
        baseline_columns={key:value['columns'] for key,value in load(baseline/'features.json')['arrays'].items()}
        model,means,mean_map=ff.load_encoder(root,'cuda');before=ff.state_digest(model)
        design=Bode2Design();sources={};all_rows=[];all_parity=[];chunk_records={}
        for cohort in ('doubles','triples'):
            source=lib.load_library(root,cohort,verify=False);sources[cohort]=source
            require(len(source)==protocol['expected_counts'][cohort], 'Candidate count changed')
            ix=sorted(set([0,len(source)//2,len(source)-1]))
            parity=lib.compact_parity(source,ix)
            dump(out/(cohort+'_compact_parity.json'),parity)
            paths=[];map_paths=[];chunk_records[cohort]=[]
            for start in range(0,len(source),protocol['chunk_size']):
                indices=list(range(start,min(start+protocol['chunk_size'],len(source))))
                folder=out/'chunks'/cohort/f'{start:06d}';folder.mkdir(parents=True,exist_ok=True)
                if not check_chunk(folder,identity,cohort,indices):
                    result=lib.extract_chunk(source,indices,model,means,mean_map,design,device='cuda')
                    require(result['columns']==baseline_columns, 'Deployed feature definitions changed')
                    require(set(result['features'])==set(BLOCKS)
                            and len(result['rows'])==len(result['maps'])==len(indices),
                            'Extracted chunk payload dimensions differ')
                    require(all(result['features'][key].shape==(len(indices),len(baseline_columns[key]))
                                for key in BLOCKS), 'Extracted feature matrix shape differs')
                    for index,row,map_row in zip(indices,result['rows'],result['maps'],strict=True):
                        require(row['candidate_index']==map_row['candidate_index']==index
                                and row['cohort']==map_row['cohort']==cohort
                                and row['assembly_id']==map_row['assembly_id']
                                and row['sequence_key']==map_row['sequence_key'],
                                'Extracted row/map/index alignment differs')
                    matches=check_parity(result['rows'],result['features'],result['maps'],baseline_rows,
                                         baseline_features,protocol['known_parity_atol'])
                    rows=score_chunk(result,protocol)
                    with (folder/'features.npz.tmp').open('wb') as f:
                        np.savez_compressed(f,**result['features'])
                    (folder/'features.npz.tmp').replace(folder/'features.npz')
                    write_lines(folder/'rows.jsonl.gz',rows);write_lines(folder/'maps.jsonl.gz',result['maps'])
                    dump(folder/'parity.json',matches);commit_chunk(folder,identity,cohort,indices)
                else:
                    emit('REUSING_VERIFIED_CHUNK',cohort=cohort,completed=indices[-1]+1,total=len(source))
                rows=list(read_lines(folder/'rows.jsonl.gz'))
                require([r['candidate_index'] for r in rows]==indices and all(r['cohort']==cohort for r in rows),
                        'Chunk row alignment changed')
                all_rows.extend(rows);all_parity.extend(load(folder/'parity.json'))
                paths.append(folder/'rows.jsonl.gz');map_paths.append(folder/'maps.jsonl.gz')
                chunk_records[cohort].append(folder)
                emit('FROZEN_LIBRARY_SCORING',cohort=cohort,completed=indices[-1]+1,total=len(source),
                     elapsed_seconds=round(time.monotonic()-started,2))
            merge_lines(paths,out/(cohort+'_scores.jsonl.gz'))
            merge_lines(map_paths,out/(cohort+'_maps.jsonl.gz'))
        require(Counter(r['cohort'] for r in all_parity)=={'doubles':31,'triples':27},
                'Known construct parity coverage incomplete')
        require(len({r['assembly_id'] for r in all_parity})==58, 'Known parity duplicates')
        dump(out/'known58_feature_parity.json',dict(status='PASS',rows=all_parity,tolerance=protocol['known_parity_atol']))
        after=ff.state_digest(model)
        require(before==after and not model.training and not any(p.requires_grad or p.grad is not None for p in model.parameters()),
                'Frozen encoder changed')
        require(submit.check_inputs(root,verify_hashes=False)==request['inputs'], 'Inputs changed during inference')
        from rank_designs import rank_and_export
        known_keys=sorted(set().union(*(set(source.known_sequence_keys) for source in sources.values())))
        if 'known_sequence_keys' in protocol:
            require(set(protocol['known_sequence_keys'])==set(known_keys), 'Known physical-sequence registry changed')
        if 'expected_known_sequence_count' in protocol:
            require(len(known_keys)==protocol['expected_known_sequence_count'], 'Known physical-sequence count differs')
        ranking_protocol=dict(protocol,known_sequence_keys=known_keys)
        dump(out/'ranking_protocol.json',ranking_protocol)
        selection=rank_and_export(all_rows,out,ranking_protocol)
        # Selected build artifacts are based on the same reconstructed records and maps.
        for cohort in ('doubles','triples'):
            selected_path=out/'rankings'/(cohort+'_selected_top50.json')
            selected=load(selected_path)
            if isinstance(selected,dict): selected=selected['rows']
            require(len(selected)==50, 'Selection output count differs')
            wanted={r['assembly_id'] for r in selected}
            lookup={r['assembly_id']:r for r in all_rows if r['cohort']==cohort and r['assembly_id'] in wanted}
            require(len(wanted)==len(lookup)==50, 'Selected rows not uniquely aligned')
            original=[lookup[row['assembly_id']] for row in selected]
            for ranked,row in zip(selected,original,strict=True):
                require(all(ranked[key]==row[key] for key in
                            ('candidate_index','cohort','donor_codes','sequence_key','parent_sequence_hashes')),
                        'Selected rank/sequence identity differs from scored row')
            source=sources[cohort]
            pairs=source.pairs([r['candidate_index'] for r in original])
            records=[];parents={}
            for ranked,row,(record,seqs) in zip(selected,original,pairs,strict=True):
                require(record['assembly_id']==row['assembly_id'], 'Selected input reconstruction identity differs')
                displayed=source.annotator.annotate_record(record)
                require(source.io.model_signature(displayed)==source.io.model_signature(record),
                        'Selected boundary annotation changed model input')
                records.append(dict(selection=ranked,record=displayed))
                for key,seq in seqs.items():
                    require(key not in parents or parents[key]==seq, 'Parent sequence hash collision')
                    parents[key]=seq
            write_lines(out/(cohort+'_selected_model_inputs.jsonl.gz'),records)
            selected_maps={m['assembly_id']:m for m in read_lines(out/(cohort+'_maps.jsonl.gz'))
                           if m['assembly_id'] in wanted}
            require(len(selected_maps)==50 and all(selected_maps[row['assembly_id']]['sequence_key']==row['sequence_key']
                                                  for row in original), 'Selected map identity differs')
            write_lines(out/(cohort+'_selected_maps.jsonl.gz'),
                        (selected_maps[row['assembly_id']] for row in original))
            fasta=out/(cohort+'_selected_mature_proteins.fasta')
            with fasta.open('w') as f:
                for row,(_,seqs) in zip(original,pairs,strict=True):
                    for index,h in enumerate(row['parent_sequence_hashes'],1):
                        sequence=seqs[h]
                        f.write('>'+row['assembly_id']+'|mature_chain='+str(index)+'|sha256='+h+'\n')
                        f.write('\n'.join(sequence[j:j+80] for j in range(0,len(sequence),80))+'\n')
        dump(out/'feature_schema.json',dict(columns=baseline_columns,checkpoint_sha256=ff.CHECKPOINT_SHA,
            raw_maps='Original26 single-object reconstruction; not calibrated activity probabilities',
            normalized_ranking='Eligible-cohort descending midrank percentile; not probability'))
        dump(out/'COMPLETE.json',dict(status='PATRICK_FINAL_SCORING_COMPLETE',**identity,
            checkpoint_step=26000,checkpoint_sha256=ff.CHECKPOINT_SHA,encoder_updates=0,classifier_training=False,
            embedding_extraction=False,encoder_state_sha256_before=before,encoder_state_sha256_after=after,
            scored_counts=dict(Counter(r['cohort'] for r in all_rows)),selected_counts={'doubles':50,'triples':50},
            primary_models=protocol['primary_models'],selection=selection,calibrated=False,
            elapsed_seconds=round(time.monotonic()-started,2),completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())))
        for name in ('pause.json','fatal_error.json'): (out/name).unlink(missing_ok=True)
        emit('PATRICK_FINAL_SCORING_COMPLETE',encoder_updates=0,classifier_training=False)
        from export_review import export
        archive,checksum=export(out,PACKAGE)
        print('RESULT_ZIP:',archive,flush=True);print('RESULT_SHA256:',checksum,flush=True)
        return 0
    except Paused as exc:
        dump(out/'pause.json',dict(status='PAUSED',reason=str(exc),resume='submit.py resume '+str(out)))
        emit('PAUSED',reason=str(exc));return 75
    except Exception as exc:
        dump(out/'fatal_error.json',dict(status='FAILED',error=str(exc),traceback=traceback.format_exc()))
        raise

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    return run(p.parse_args())

if __name__=='__main__': sys.exit(main())
