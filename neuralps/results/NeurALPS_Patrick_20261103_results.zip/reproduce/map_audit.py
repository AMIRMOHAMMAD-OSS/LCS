#!/usr/bin/env python3
"""Audit frozen SSL26 physical-object maps on the 105 BODE2 single exchanges.

This job performs cached-feature inference only. It never updates a model or
fits an activity readout. Labels enter diagnostic metrics after prediction files
are sealed. The companion all-parts ZIP supplies JSON inputs, never executable
code. The supplied vendor_map code is used for the numerical contract.
"""
import argparse
from collections import Counter
import csv
import datetime as dt
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
SCHEMA = "patrick_frozen_physical_map_audit_v1"
KIT_PREFIX = "NeurALPS_BODE2_All_Parts/"
PINNED = {
    "e1_ssl_continue30_v1_530757/best.pt": "9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f",
    "e1_ssl_targets_497189/targets.npz": "7d81ce504a6b64e6b1c5cf2e71a639dde1b05ec4b2787e655dd235bad536961f",
    "e0_training_prep_461027/training_data.sqlite3": "6c273f05a6bcde4fec6fc57a26d0a35a9461f9831656248bee3ca21de1c14287",
    "e0_cache_final_491894/features.f32": "5a7c2f3afd527785ce3c12eaa3b97138034f4dfc811d840b5b44cf1534b9ef90",
}
FEATURE_SHAPE = (548713, 1152)
MAP_CONTRACT = {
    "version": "ssl26_physical_object_mixed_cosine_v1",
    "checkpoint_step": 26000,
    "primary_path": "full",
    "diagnostic_path": "local",
    "full": "Original frozen local blocks plus global read/write blocks and decoder",
    "local": "Same frozen weights; global blocks bypassed, context=False",
    "mask": "One complete physical object, with physical overlap and exact sequence alias closure",
    "protein_break": "Both terminal roles masked together, role losses averaged; boundary counted once",
    "formula": "1 - mean_roles(0.25*(1-cos(pred,target)) + 0.75*(1-cos(pred-mu,target-mu)))",
    "centered_fallback": "Raw cosine when norm(target-mu) <= 1e-6",
    "mean_source": "Natural-training-only, minimum 100 unique feature rows for specific type mean",
    "rawcos_diagnostic": "Mean role cosine using the SAME masked predictions",
    "range": [-1, 1],
    "direction": "Higher means stronger reconstruction agreement",
    "activity_probability": False,
    "causal_fault_localization": False,
    "supervised_classifier_explanation": False,
    "natural_reference_percentiles": "Not applied to this mask contract",
    "insufficient_context": "Explicit null score unless at least two distinct visible context objects remain within radius24",
    "aggregation": "Complete coverage required; no silent removal of unsupported objects",
    "primary_path_reason": "Training-consistent full path; activity labels do not select a local map definition",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for data in iter(lambda: stream.read(8 << 20), b""):
            h.update(data)
    return h.hexdigest()


def write_json(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("wb") as stream:
        stream.write(encoded(value))
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(tmp, path)


def archive_json(archive, relative, cap=10 << 20):
    name = KIT_PREFIX + relative
    matches = [z for z in archive.infolist() if z.filename == name]
    require(len(matches) == 1, "Missing or duplicated JSON input in all-parts ZIP: " + name)
    require(matches[0].file_size <= cap, "Oversized all-parts JSON input: " + name)
    return json.loads(archive.read(matches[0]))


def load_inputs(project_root):
    root = Path(project_root).resolve()
    archive_path = root / "NeurALPS_BODE2_All_Parts.zip"
    require(archive_path.is_file(), "Required existing input missing: " + str(archive_path))
    with zipfile.ZipFile(archive_path) as archive:
        cohort = archive_json(archive, "cohort.json")
        contract = archive_json(archive, "source_contract.json", 1 << 20)
        vocab = archive_json(archive, "neuralps/data/domain_vocabulary.json", 1 << 20)
    require(vocab == json.loads((HERE / "vendor_map/neuralps/data/domain_vocabulary.json").read_text()),
            "All-parts vocabulary differs from bundled frozen vocabulary")
    rows = cohort["rows"]
    require(isinstance(rows, list) and len(rows) == 105 and len({r["assembly_id"] for r in rows}) == 105,
            "Map cohort must contain exactly 105 unique engineered BODE2 constructs")
    require(Counter(r["label"] for r in rows) == {0: 42, 1: 63}, "BODE2 map label counts changed")
    for row in rows:
        require(type(row["label"]) is int and row["label"] in (0, 1), "Invalid binary map label")
        require(row["route"] and row["archived_joint"]["objects"] and row["exchange_domain_indices"],
                "Missing original structural/parity input")
    metadata_path = HERE / "inputs/metadata.json"
    require(metadata_path.is_file(), "Missing sealed package cohort: " + str(metadata_path))
    metadata = json.loads(metadata_path.read_text())
    target_rows = [r for r in metadata["rows"] if r["dataset"] == "bode2"]
    require(len(target_rows) == 105 and len({r["assembly_id"] for r in target_rows}) == 105,
            "Package BODE2 metadata must contain 105 unique target constructs")
    require({r["assembly_id"]: r["label"] for r in rows} ==
            {r["assembly_id"]: r["observed_activity"] for r in target_rows},
            "Map cohort IDs/labels differ from sealed supervised BODE2 cohort")
    expected = dict(contract["files_sha256"])
    for relative, fixed in PINNED.items():
        require(expected.get(relative, fixed) == fixed, "Conflicting pinned source: " + relative)
        expected[relative] = fixed
    required = sorted(set(expected) | {"e1_ssl_targets_497189/manifest.json",
                                      "e0_cache_final_491894/feature_index.sqlite3"})
    for relative in required:
        path = (root / relative).resolve()
        require(path.is_relative_to(root) and path.is_file(), "Missing frozen source: " + relative)
        if path.suffix == ".sqlite3":
            require(not Path(str(path) + "-wal").exists(), "Source database has a WAL: " + relative)
    require((root / "e0_cache_final_491894/features.f32").stat().st_size ==
            FEATURE_SHAPE[0] * FEATURE_SHAPE[1] * 4, "Frozen cache byte length changed")
    return rows, expected, required, {
        "input_archive_sha256": sha(archive_path), "cohort_sha256": digest(cohort),
        "source_contract_sha256": digest(contract), "vocabulary_sha256": digest(vocab),
        "package_metadata_sha256": sha(metadata_path),
        "archive": str(archive_path), "cohort_size": len(rows),
    }


def preflight(project_root):
    rows, expected, required, identity = load_inputs(project_root)
    return dict(status="PREFLIGHT_OK", **identity, required_files=required,
                hashes_verified=False, note="Full large-asset hashes are verified inside the allocated job",
                dependencies=["numpy", "torch"], training=False, esmc_inference=False)


def verify_sources(root, expected, required):
    verified, signatures = {}, {}
    for relative in required:
        path = root / relative
        before = path.stat()
        actual = sha(path)
        after = path.stat()
        signature = (after.st_size, after.st_mtime_ns, after.st_ino)
        require((before.st_size, before.st_mtime_ns, before.st_ino) == signature,
                "Source changed while hashing: " + relative)
        require(relative not in expected or actual == expected[relative], "Source hash mismatch: " + relative)
        verified[relative] = dict(sha256=actual, bytes=after.st_size, pinned=relative in expected)
        signatures[relative] = signature
        print(json.dumps(dict(stage="map_verify", file=relative)), flush=True)
    return verified, signatures


def aggregate(objects, mode, field="scores", indices=None):
    import numpy as np
    selected = objects if indices is None else [o for o in objects if o["object_index"] in set(indices)]
    result = dict(complete=False, scored=0, total=len(selected), mean=None, balanced_mean=None,
                  q25=None, balanced_q25=None, minimum=None, domains_mean=None, boundaries_mean=None)
    result["scored"] = sum(o["status"] == "SCORED" and o.get(field, {}).get(mode) is not None for o in selected)
    if not selected or result["scored"] != result["total"]:
        return result
    values = [o[field][mode] for o in selected]
    require(all(np.isfinite(v) for v in values), "Nonfinite map aggregation input")
    d = [o[field][mode] for o in selected if o["kind"] == 0]
    b = [o[field][mode] for o in selected if o["kind"] != 0]
    result.update(complete=True, mean=float(np.mean(values)), q25=float(np.quantile(values, .25)),
                  minimum=float(min(values)), domains_mean=float(np.mean(d)) if d else None,
                  boundaries_mean=float(np.mean(b)) if b else None)
    if d and b:
        result["balanced_mean"] = .5 * (result["domains_mean"] + result["boundaries_mean"])
        result["balanced_q25"] = .5 * float(np.quantile(d, .25) + np.quantile(b, .25))
    return result


def score_assembly(runtime, record, parents, vectors, row, microbatch):
    from vendor_map.score_all_parts import joint_parity
    from vendor_map.neuralps.inputs import region_targets
    from vendor_map.neuralps.scoring import make_plan, slots_by_object
    ds, bs = region_targets(record, row["exchange_domain_indices"])
    # Historical joint-mask agreement is a numerical regression test, not a map.
    parity = joint_parity(runtime, record, parents, vectors, row)
    plans = {"object_" + str(j): make_plan(record, [j], parents) for j in range(len(record["route"]))}
    scored = runtime.score_plans(record, parents, vectors, plans, modes=("local", "full"), microbatch=microbatch)
    by = slots_by_object(record)
    objects = []
    for j, annotation in enumerate(record["route"]):
        r = scored["object_" + str(j)]
        objects.append(dict(object_index=j, kind=annotation["kind"], annotation=annotation,
                            slots=by[j], is_exchange_domain=j in ds,
                            is_touching_exchange_boundary=j in bs, status=r["status"],
                            scores=r["objects"].get(str(j), {}),
                            rawcos=r.get("objects_rawcos", {}).get(str(j), {}),
                            mask={k: v for k, v in r.items() if k not in ("objects", "objects_rawcos")}))
    return dict(assembly_id=row["assembly_id"], record_sha256=digest(record), objects=objects,
                independent_aggregate={mode: aggregate(objects, mode) for mode in ("local", "full")},
                independent_exchange_aggregate={mode: aggregate(objects, mode, indices=ds+bs) for mode in ("local", "full")},
                rawcos_aggregate={mode: aggregate(objects, mode, field="rawcos") for mode in ("local", "full")},
                joint_exchange_parity=parity)


def finish(output, results, labels, provenance):
    from vendor_map.score_all_parts import auroc
    # Seal label-free predictions before attaching outcomes or computing metrics.
    prediction = dict(schema=SCHEMA, contract=MAP_CONTRACT, run_identity=provenance["run_identity"], assemblies=results)
    packed = gzip.compress(encoded(prediction), compresslevel=6, mtime=0)
    tmp = output / "maps.json.gz.tmp"
    tmp.write_bytes(packed)
    os.replace(tmp, output / "maps.json.gz")
    write_json(output / "prediction_seal.json", dict(sha256=sha(output / "maps.json.gz"),
               model_inputs_include_activity_labels=False, training_performed=False,
               note="Cohort labels are present in archive; inference uses only structural fields and cached features"))
    diagnostic = []
    for family in ("independent_aggregate", "independent_exchange_aggregate", "rawcos_aggregate"):
        for mode in ("local", "full"):
            for metric in ("mean", "balanced_mean", "q25", "balanced_q25", "minimum"):
                scores = [r[family][mode][metric] for r in results]
                n = sum(s is not None for s in scores)
                diagnostic.append(dict(family=family, mode=mode, aggregation=metric, available=n,
                    total=len(results), auroc=auroc([labels[r["assembly_id"]] for r in results], scores)
                    if n == len(results) else None, interpretation="Exploratory assembly-label association; not domain-level validation"))
    for mode in ("local", "full"):
        scores = [r["joint_exchange_parity"]["aggregate"][mode]["balanced"] for r in results]
        diagnostic.append(dict(family="historical_joint_exchange", mode=mode, aggregation="balanced_mean",
            available=len(results), total=len(results), auroc=auroc([labels[r["assembly_id"]] for r in results], scores),
            interpretation="Historical region comparator; not independent per-object map"))
    rows = []
    for r in results:
        for obj in r["objects"]:
            rows.append(dict(assembly_id=r["assembly_id"], object_index=obj["object_index"], kind=obj["kind"],
                status=obj["status"], full_mixed=obj["scores"].get("full"), local_mixed=obj["scores"].get("local"),
                full_rawcos=obj["rawcos"].get("full"), local_rawcos=obj["rawcos"].get("local"),
                is_exchange_domain=obj["is_exchange_domain"], is_touching_exchange_boundary=obj["is_touching_exchange_boundary"]))
    with (output / "object_scores.csv").open("w", newline="") as stream:
        w = csv.DictWriter(stream, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    statuses = dict(Counter(r["status"] for r in rows))
    summary = dict(schema=SCHEMA, status="MAP_AUDIT_COMPLETE", assemblies=len(results), objects=len(rows),
        object_status_counts=statuses, all_objects_scored=all(r["status"] == "SCORED" for r in rows),
        joint_parity_checked=len(results),
        joint_parity_maximum_absolute_error=max(r["joint_exchange_parity"]["maximum_absolute_error"] for r in results),
        joint_parity_atol=1e-5, score_contract=MAP_CONTRACT,
        map_definition_selected_from_activity_labels=False, independent_E8_object_parity="NOT_CHECKED_NO_MATCHED_REFERENCE_INPUT",
        target_scope="105 single exchanges only; multi-exchange sequences must be separately reconstructed and embedded",
        diagnostic_metrics=diagnostic)
    write_json(output / "summary.json", summary)
    write_json(output / "provenance.json", provenance)
    names = ["maps.json.gz", "prediction_seal.json", "object_scores.csv", "summary.json", "provenance.json"]
    write_json(output / "RESULTS_MANIFEST.json", {n: dict(sha256=sha(output/n), bytes=(output/n).stat().st_size) for n in names})
    archive_path = output / "map_inspection.zip"
    with zipfile.ZipFile(archive_path.with_suffix(".zip.tmp"), "w", zipfile.ZIP_DEFLATED) as archive:
        for name in names + ["RESULTS_MANIFEST.json"]:
            archive.write(output/name, name)
    os.replace(archive_path.with_suffix(".zip.tmp"), archive_path)
    write_json(output / "COMPLETE.json", dict(status="MAP_AUDIT_COMPLETE", run_identity=provenance["run_identity"],
        archive_sha256=sha(archive_path), all_objects_scored=summary["all_objects_scored"]))
    return summary


def run(project_root, output_dir, device="cpu", threads=4, microbatch=8):
    import numpy as np
    from vendor_map import score_all_parts as base
    root, output = Path(project_root).resolve(), Path(output_dir).resolve()
    require(device in ("cpu", "cuda") and threads > 0 and microbatch > 0, "Invalid map runtime settings")
    rows, expected, required, archive_identity = load_inputs(root)
    labels = {r["assembly_id"]: r["label"] for r in rows}
    # No phenotype labels are passed to scoring functions.
    structural_rows = [{k: r[k] for k in ("assembly_id", "route", "archived_joint", "exchange_domain_indices")}
                       for r in rows]
    verified, signatures = verify_sources(root, expected, required)
    runtime, environment = base.load_runtime(root, device, threads)
    code_paths = [HERE / "map_audit.py"] + sorted((HERE / "vendor_map").rglob("*.py"))
    code_paths += sorted((HERE / "vendor_map").rglob("*.json"))
    identity_body = dict(schema=SCHEMA, contract=MAP_CONTRACT, inputs=archive_identity, sources=verified,
        environment=environment, microbatch=microbatch,
        code_sha256={str(p.relative_to(HERE)): sha(p) for p in code_paths})
    identity = digest(identity_body)
    provenance = dict(identity_body, run_identity=identity, created_utc=dt.datetime.now(dt.timezone.utc).isoformat())
    output.mkdir(parents=True, exist_ok=True)
    with (output / ".map.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        runfile = output / "RUN_IDENTITY.json"
        if runfile.exists():
            require(json.loads(runfile.read_text())["run_identity"] == identity,
                    "Map output belongs to different inputs/settings/code; choose a new output directory")
        else:
            require(not any(p.name != ".map.lock" for p in output.iterdir()), "Unrecognized nonempty map output directory")
            write_json(runfile, dict(run_identity=identity, identity=identity_body))
        working = output / "assemblies"; working.mkdir(exist_ok=True)
        db = base.readonly(root / "e0_training_prep_461027/training_data.sqlite3")
        index = base.readonly(root / "e0_cache_final_491894/feature_index.sqlite3")
        cache = np.memmap(root / "e0_cache_final_491894/features.f32", mode="r", dtype="<f4", shape=FEATURE_SHAPE)
        results = []
        try:
            for number, row in enumerate(structural_rows, 1):
                record, parents, vectors = base.read_record(db, index, cache, row)
                path = working / (hashlib.sha256(row["assembly_id"].encode()).hexdigest() + ".json")
                if path.exists():
                    envelope = json.loads(path.read_text()); result = envelope["result"]
                    require(envelope["run_identity"] == identity and envelope["result_sha256"] == digest(result),
                            "Saved map checkpoint identity/hash mismatch")
                    require(result["assembly_id"] == row["assembly_id"] and result["record_sha256"] == digest(record),
                            "Saved map record identity mismatch")
                else:
                    result = score_assembly(runtime, record, parents, vectors, row, microbatch)
                    write_json(path, dict(run_identity=identity, result_sha256=digest(result), result=result))
                results.append(result)
                print(json.dumps(dict(stage="map_assembly", completed=number, total=len(rows),
                                     assembly_id=row["assembly_id"])), flush=True)
        finally:
            db.close(); index.close(); del cache
        for relative, signature in signatures.items():
            stat = (root/relative).stat()
            require((stat.st_size, stat.st_mtime_ns, stat.st_ino) == signature,
                    "Frozen source changed during map inference: " + relative)
        summary = finish(output, results, labels, provenance)
        print(json.dumps(dict(stage="MAP_AUDIT_COMPLETE", output=str(output), all_objects_scored=summary["all_objects_scored"])), flush=True)
        return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--microbatch", type=int, default=8)
    args = parser.parse_args()
    if args.preflight:
        print(json.dumps(preflight(args.project_root), indent=2))
        return
    parser.error("--output-dir is required for execution") if args.output_dir is None else None
    run(args.project_root, args.output_dir, args.device, args.threads, args.microbatch)


if __name__ == "__main__":
    main()
