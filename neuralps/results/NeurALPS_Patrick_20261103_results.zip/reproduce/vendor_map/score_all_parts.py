#!/usr/bin/env python3
"""Export frozen independent local/global BODE2 object maps on Jean Zay.

No training and no ESMC inference. The original cached feature vectors, SSL26
checkpoint, training target means and physical masking closure are reused.
The old jointly masked exchange is recomputed separately as a parity check.
"""
import argparse
from collections import Counter
import csv
import datetime as dt
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import sqlite3
import sys
import zipfile

import numpy as np

KIT = Path(__file__).resolve().parent
from .neuralps.contracts import SSL_SHA, TARGETS_SHA, require, seqsha, sha
from .neuralps.inputs import region_targets, vocabulary
from .neuralps.scoring import Runtime, make_plan, slots_by_object

PINNED = {
    "e1_ssl_continue30_v1_530757/best.pt": SSL_SHA,
    "e1_ssl_targets_497189/targets.npz": TARGETS_SHA,
    "e0_training_prep_461027/training_data.sqlite3":
        "6c273f05a6bcde4fec6fc57a26d0a35a9461f9831656248bee3ca21de1c14287",
    "e0_cache_final_491894/features.f32":
        "5a7c2f3afd527785ce3c12eaa3b97138034f4dfc811d840b5b44cf1534b9ef90",
}
FEATURE_SHAPE = (548713, 1152)
PARITY_ATOL = 1e-5
SCHEMA = "neuralps_bode2_independent_all_parts_v1"


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def digest_value(value):
    return hashlib.sha256(json_bytes(value)).hexdigest()


def atomic_bytes(path, content):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("wb") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def atomic_json(path, value):
    atomic_bytes(path, json_bytes(value))


def emit(stage, **details):
    print(json.dumps(dict(stage=stage, **details), sort_keys=True), flush=True)


def readonly(path):
    db = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)
    db.execute("PRAGMA query_only=ON")
    return db


def source_files(root):
    contract = json.loads((KIT / "source_contract.json").read_text())
    expected = dict(contract["files_sha256"])
    for relative, fixed in PINNED.items():
        require(expected.get(relative, fixed) == fixed, "Conflicting source contract: " + relative)
        expected[relative] = fixed
    required = ["e1_ssl_targets_497189/manifest.json",
                "e0_cache_final_491894/feature_index.sqlite3"]
    paths = sorted(set(expected) | set(required))
    verified, signatures = {}, {}
    for relative in paths:
        path = (root / relative).resolve()
        require(path.is_relative_to(root) and path.is_file(), "Missing source: " + relative)
        # A writable WAL would make a byte-level database fingerprint ambiguous.
        if path.suffix == ".sqlite3":
            require(not Path(str(path) + "-wal").exists(), "Unexpected source database WAL: " + relative)
        emit("verify_source", file=relative, bytes=path.stat().st_size)
        before = path.stat()
        actual = sha(path)
        after = path.stat()
        signature = (after.st_size, after.st_mtime_ns, after.st_ino)
        require((before.st_size, before.st_mtime_ns, before.st_ino) == signature,
                "Source changed during checksum: " + relative)
        if relative in expected:
            require(actual == expected[relative], "Source checksum mismatch: " + relative)
        verified[relative] = dict(sha256=actual, bytes=after.st_size,
                                 pinned=relative in expected)
        signatures[relative] = signature
    require((root / "e0_cache_final_491894/features.f32").stat().st_size ==
            FEATURE_SHAPE[0] * FEATURE_SHAPE[1] * 4, "Feature matrix shape changed")
    return verified, signatures


def load_runtime(root, device, threads):
    import torch
    from .neuralps.assembly_model import AssemblyEncoder, Config, collate_records
    torch.set_num_threads(threads)
    if device == "cuda":
        require(torch.cuda.is_available(), "CUDA requested but no allocated GPU is available")
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.set_float32_matmul_precision("highest")
    # This legacy checkpoint contains Python/NumPy state. Its fixed known SHA256
    # has already been verified by source_files before deserialization.
    saved = torch.load(root / "e1_ssl_continue30_v1_530757/best.pt",
                       map_location="cpu", weights_only=False)
    require(saved["step"] == 26000, "Selected checkpoint is not step 26000")
    target_dir = root / "e1_ssl_targets_497189"
    manifest = json.loads((target_dir / "manifest.json").read_text())
    require(saved["targets_manifest"] == manifest, "Checkpoint/target manifests disagree")
    with np.load(target_dir / "targets.npz", allow_pickle=False) as bank:
        means = {name: bank[name].copy() for name, _ in manifest["means"].values()}
    require(all(a.shape == (1152,) and np.isfinite(a).all() for a in means.values()),
            "Invalid training target means")
    for group, (name, count) in manifest["means"].items():
        require(np.array_equal(saved["target_means"][group].cpu().numpy(), means[name]),
                "Checkpoint target mean differs: " + group)
        require(isinstance(count, (int, float)) and count >= 0, "Invalid target mean count")
    config = saved["config"]["settings"]["encoder"]
    model = AssemblyEncoder(Config(**config))
    require(all(bool(torch.isfinite(v).all()) for v in saved["model"].values()),
            "Nonfinite checkpoint weights")
    model.load_state_dict(saved["model"], strict=True)
    model.to(device).eval().requires_grad_(False)
    runtime = Runtime.__new__(Runtime)
    runtime.model, runtime.collate, runtime.device = model, collate_records, device
    runtime.means, runtime.mean_map = means, manifest["means"]
    runtime.manifest = dict(source_checkpoint_sha256=SSL_SHA, selected_step=26000)
    version = dict(python=platform.python_version(), numpy=np.__version__,
                   torch=torch.__version__, cuda=torch.version.cuda, device=device,
                   threads=threads, tf32=False, dtype="float32", encoder_config=config)
    if device == "cuda":
        version["gpu_name"] = torch.cuda.get_device_name(0)
        version["gpu_capability"] = list(torch.cuda.get_device_capability(0))
    del saved
    return runtime, version


def load_cohort():
    cohort = json.loads((KIT / "cohort.json").read_text())
    rows = cohort["rows"]
    require(len(rows) == 105 and len({r["assembly_id"] for r in rows}) == 105,
            "Expected 105 unique engineered BODE2 constructs")
    require(Counter(r["label"] for r in rows) == {0: 42, 1: 63}, "Unexpected BODE2 labels")
    for row in rows:
        require(type(row["label"]) is int and row["label"] in (0, 1), "Nonbinary cohort label")
        require(row["route"] and row["archived_joint"]["objects"], "Missing original BODE2 query")
    return rows


def same_route(actual, archived):
    """Only the optional human-readable canonical type may be absent in the DB."""
    require(len(actual) == len(archived), "Route length differs from archived evaluation")
    names = {value: key for key, value in vocabulary().items()}
    for j, (db_object, old_object) in enumerate(zip(actual, archived)):
        current = dict(db_object)
        if "canonical_domain_type" not in current and "canonical_domain_type" in old_object:
            require(current["kind"] == 0, "Unexpected canonical type on a boundary")
            current["canonical_domain_type"] = names[current["domain_type"]]
        require(current == old_object, "Route differs from archived evaluation at object " + str(j))


def read_record(db, index, cache, row):
    found = db.execute("SELECT payload FROM assemblies WHERE dataset=? AND assembly_id=?",
                       ("bode2", row["assembly_id"])).fetchall()
    require(len(found) == 1, "Missing or duplicated BODE2 record: " + row["assembly_id"])
    source = json.loads(found[0][0])
    require(source["assembly_id"] == row["assembly_id"] and source.get("dataset", "bode2") == "bode2",
            "Source record identity mismatch")
    same_route(source["route"], row["route"])
    # Only structural fields enter inference; phenotype labels stay in cohort.json.
    keys = ("assembly_id", "route", "model_slots", "parent_sequence_hashes")
    record = {key: source[key] for key in keys}
    parents = {}
    for parent_hash in set(record["parent_sequence_hashes"].values()):
        matches = db.execute("SELECT sequence FROM proteins WHERE hash=?", (parent_hash,)).fetchall()
        require(len(matches) == 1 and seqsha(matches[0][0]) == parent_hash,
                "Parent sequence checksum mismatch")
        parents[parent_hash] = matches[0][0]
    lengths = {uid: len(parents[h]) for uid, h in record["parent_sequence_hashes"].items()}
    require(source.get("parent_lengths", lengths) == lengths, "Parent lengths disagree with sequences")
    record["parent_lengths"] = lengths
    vectors = {}
    by = slots_by_object(record)
    require(set(by) == set(range(len(record["route"]))), "Route/model slot coverage mismatch")
    for j, obj in enumerate(record["route"]):
        expected_roles = [1, 2] if obj["kind"] == 2 else [0]
        require([s["slot"] for s in by[j]] == expected_roles, "Invalid physical object roles")
    for slot in record["model_slots"]:
        require(slot["kind"] == record["route"][slot["object_index"]]["kind"], "Slot kind mismatch")
        parent = parents[slot["parent_sequence_hash"]]
        require(0 <= slot["start"] <= slot["end"] <= len(parent), "Invalid slot coordinates")
        sequence = parent[slot["start"]:slot["end"]]
        require(len(sequence) == slot["length"], "Slot sequence length mismatch")
        if slot["state"] != "OBSERVED":
            continue
        h = slot["sequence_hash"]
        require(sequence and seqsha(sequence) == h, "Feature sequence checksum mismatch")
        if h not in vectors:
            found = index.execute("SELECT feature_row FROM features WHERE hash=? AND status='covered'", (h,)).fetchall()
            require(len(found) == 1, "Observed cached feature missing: " + h)
            position = found[0][0]
            require(type(position) is int and 0 <= position < FEATURE_SHAPE[0], "Invalid cache row")
            vectors[h] = np.array(cache[position], dtype=np.float32, copy=True)
            require(np.isfinite(vectors[h]).all() and np.abs(vectors[h]).sum() > 0,
                    "Invalid cached feature values")
    return record, parents, vectors


def joint_parity(runtime, record, parents, vectors, row):
    ds, bs = region_targets(record, row["exchange_domain_indices"])
    expected = row["archived_joint"]
    require(set(expected["objects"]) == {str(j) for j in ds + bs}, "Archived query targets mismatch")
    result = runtime.score_plans(record, parents, vectors,
                                 {"joint": make_plan(record, ds + bs, parents)},
                                 modes=("local", "full"), microbatch=1)["joint"]
    require(result["status"] == "SCORED", "Original joint query cannot be recomputed")
    maximum = 0.0
    for key, values in expected["objects"].items():
        for mode in ("local", "full"):
            difference = abs(result["objects"][key][mode] - values[mode])
            require(np.isfinite(difference) and difference <= PARITY_ATOL,
                    f"Archived joint parity failed: {row['assembly_id']} object {key} {mode}: {difference:g}")
            maximum = max(maximum, difference)
    aggregates = {}
    for mode in ("local", "full"):
        domains = float(np.mean([result["objects"][str(j)][mode] for j in ds]))
        boundaries = float(np.mean([result["objects"][str(j)][mode] for j in bs]))
        aggregates[mode] = dict(domains=domains, boundaries=boundaries,
                                balanced=.5 * (domains + boundaries),
                                neighborhood_mean=float(np.mean([result["objects"][str(j)][mode] for j in ds + bs])))
        for name, value in expected["aggregate"][mode].items():
            require(name in aggregates[mode] and value is not None, "Missing archived aggregate")
            difference = abs(aggregates[mode][name] - value)
            require(difference <= PARITY_ATOL, "Archived joint aggregate parity failed")
            maximum = max(maximum, difference)
    return dict(status="PASS", absolute_tolerance=PARITY_ATOL, maximum_absolute_error=maximum,
                domain_indices=ds, boundary_indices=bs, aggregate=aggregates)


def assemble_result(runtime, record, parents, vectors, row, microbatch):
    parity = joint_parity(runtime, record, parents, vectors, row)
    plans = {"object_" + str(j): make_plan(record, [j], parents)
             for j in range(len(record["route"]))}
    scored = runtime.score_plans(record, parents, vectors, plans,
                                 modes=("local", "full"), microbatch=microbatch)
    by = slots_by_object(record)
    objects = []
    ds, bs = region_targets(record, row["exchange_domain_indices"])
    for j, route_object in enumerate(record["route"]):
        result = scored["object_" + str(j)]
        raw = result["objects"].get(str(j))
        if raw is not None:
            require(set(raw) == {"local", "full"} and all(np.isfinite(x) for x in raw.values()),
                    "Incomplete or nonfinite object score")
        objects.append(dict(object_index=j, kind=route_object["kind"],
                            annotation=row["route"][j], slots=by[j],
                            is_exchange_domain=j in ds, is_touching_exchange_boundary=j in bs,
                            status=result["status"], local=None if raw is None else raw["local"],
                            global_score=None if raw is None else raw["full"],
                            plan={key: value for key, value in result.items() if key != "objects"}))
    return dict(assembly_id=row["assembly_id"], observed_activity=row["label"],
                record_sha256=digest_value(record), object_count=len(objects), objects=objects,
                joint_exchange_parity=parity)


def aggregate_objects(objects, mode):
    """Never silently drop a missing piece when computing an assembly score."""
    result = dict(complete=False, mean=None, balanced=None, minimum=None,
                  domains_mean=None, boundaries_mean=None)
    if not objects or any(obj["status"] != "SCORED" or obj[mode] is None for obj in objects):
        return result
    domains = [obj[mode] for obj in objects if obj["kind"] == 0]
    boundaries = [obj[mode] for obj in objects if obj["kind"] != 0]
    result.update(complete=True, mean=float(np.mean([obj[mode] for obj in objects])),
                  minimum=float(min(obj[mode] for obj in objects)),
                  domains_mean=float(np.mean(domains)) if domains else None,
                  boundaries_mean=float(np.mean(boundaries)) if boundaries else None)
    if domains and boundaries:
        result["balanced"] = .5 * (result["domains_mean"] + result["boundaries_mean"])
    return result


def read_saved_assembly(path, identity, record, row):
    envelope = json.loads(Path(path).read_text())
    result = envelope["result"]
    require(envelope["run_identity"] == identity and envelope["result_sha256"] == digest_value(result),
            "Invalid saved assembly checkpoint")
    require(result["assembly_id"] == row["assembly_id"] and result["observed_activity"] == row["label"]
            and result["record_sha256"] == digest_value(record), "Saved record identity differs")
    require([obj["object_index"] for obj in result["objects"]] == list(range(len(record["route"])))
            and result["joint_exchange_parity"]["status"] == "PASS", "Incomplete saved assembly")
    return result


def auroc(labels, scores):
    """Exact pairwise AUROC, including half credit for tied scores."""
    positives = np.array([s for y, s in zip(labels, scores) if y == 1])
    negatives = np.array([s for y, s in zip(labels, scores) if y == 0])
    require(len(positives) and len(negatives), "AUROC requires both classes")
    differences = positives[:, None] - negatives[None, :]
    return float(np.mean((differences > 0) + .5 * (differences == 0)))


def write_csv(path, rows):
    require(bool(rows), "Refusing an empty output CSV")
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def finish(output, results, provenance):
    object_rows, assembly_rows = [], []
    for assembly in results:
        for obj in assembly["objects"]:
            annotation = obj["annotation"]
            object_rows.append(dict(assembly_id=assembly["assembly_id"], observed_activity=assembly["observed_activity"],
                object_index=obj["object_index"], kind=obj["kind"],
                object_type={0: "domain", 1: "covalent_boundary", 2: "protein_break"}[obj["kind"]],
                domain_type=annotation.get("canonical_domain_type", ""),
                left_domain_uid=annotation.get("left_domain_uid", ""),
                right_domain_uid=annotation.get("right_domain_uid", ""),
                status=obj["status"], local_score=obj["local"], global_score=obj["global_score"],
                is_exchange_domain=obj["is_exchange_domain"],
                is_touching_exchange_boundary=obj["is_touching_exchange_boundary"],
                slot_count=len(obj["slots"]), slots_json=json.dumps(obj["slots"], sort_keys=True),
                masked_fraction=obj["plan"].get("masked_fraction"),
                plan_json=json.dumps(obj["plan"], sort_keys=True)))
        values = dict(assembly_id=assembly["assembly_id"], observed_activity=assembly["observed_activity"],
                       objects=len(assembly["objects"]),
                       domains=sum(obj["kind"] == 0 for obj in assembly["objects"]),
                       boundaries=sum(obj["kind"] != 0 for obj in assembly["objects"]),
                       scored=sum(obj["status"] == "SCORED" for obj in assembly["objects"]))
        for display, mode in (("local", "local"), ("global", "global_score")):
            for name, value in aggregate_objects(assembly["objects"], mode).items():
                values[display + "_" + name] = value
        assembly_rows.append(values)
    exploration = []
    for mode in ("local", "global"):
        for field in ("mean", "balanced", "minimum"):
            key = mode + "_" + field
            available = sum(row[key] is not None for row in assembly_rows)
            exploration.append(dict(mode=mode, aggregation=field, available=available, total=105,
                auroc=auroc([r["observed_activity"] for r in assembly_rows], [r[key] for r in assembly_rows])
                if available == 105 else None,
                status="COMPLETE_105" if available == 105 else "INCOMPLETE_NO_AUROC"))
    summary = dict(schema=SCHEMA, assemblies=105, active=63, inactive=42,
        objects=len(object_rows), object_status_counts=dict(Counter(r["status"] for r in object_rows)),
        all_objects_scored=all(r["status"] == "SCORED" for r in object_rows),
        domain_objects=sum(r["kind"] == 0 for r in object_rows),
        boundary_objects=sum(r["kind"] != 0 for r in object_rows),
        two_role_protein_breaks=sum(r["kind"] == 2 for r in object_rows),
        joint_parity_checked=105,
        joint_parity_maximum_absolute_error=max(a["joint_exchange_parity"]["maximum_absolute_error"] for a in results),
        whole_assembly_exploratory_auroc=exploration,
        aggregation_note="Whole-assembly aggregation uses independent object scores; a two-role protein break counts once. Missing objects make assembly scores null. These exploratory comparisons are not held-out model selection.",
        missing_note="Every physical piece is listed. An unscorable piece has an explicit status and null scores.")
    write_csv(output / "all_objects.csv", object_rows)
    write_csv(output / "assembly_summaries.csv", assembly_rows)
    atomic_json(output / "summary.json", summary)
    atomic_json(output / "provenance.json", provenance)
    atomic_bytes(output / "fullmap.json.gz", gzip.compress(json_bytes(dict(
        schema=SCHEMA, run_identity=provenance["run_identity"], score_contract=provenance["score_contract"],
        assemblies=results)), compresslevel=6, mtime=0))
    names = ["all_objects.csv", "assembly_summaries.csv", "summary.json", "provenance.json", "fullmap.json.gz"]
    manifest = {name: dict(sha256=sha(output / name), bytes=(output / name).stat().st_size) for name in names}
    atomic_json(output / "RESULTS_MANIFEST.json", dict(schema=SCHEMA, files=manifest))
    archive = output / "NeurALPS_BODE2_All_Parts_Results.zip"
    temporary = archive.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as packed:
        for name in names + ["RESULTS_MANIFEST.json"]:
            packed.write(output / name, name)
    with zipfile.ZipFile(temporary) as packed:
        require(packed.testzip() is None, "Result archive integrity check failed")
    os.replace(temporary, archive)
    atomic_json(output / "COMPLETE.json", dict(schema=SCHEMA, run_identity=provenance["run_identity"],
        archive=archive.name, archive_sha256=sha(archive), summary=summary))
    emit("COMPLETE", archive=str(archive), **{k: summary[k] for k in ("assemblies", "objects", "all_objects_scored")})


def run(args):
    root, output = args.root.resolve(), args.output.resolve()
    require(args.microbatch >= 1 and args.threads >= 1, "Positive microbatch/threads required")
    output.mkdir(parents=True, exist_ok=True)
    with (output / ".run.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError("Another process is already using this output directory") from None
        rows = load_cohort()
        verified, signatures = source_files(root)
        runtime, environment = load_runtime(root, args.device, args.threads)
        code_paths = [Path(__file__).resolve()] + sorted((KIT / "neuralps").rglob("*.py"))
        code_paths += sorted((KIT / "neuralps" / "data").glob("*.json"))
        code = {str(p.relative_to(KIT)): sha(p) for p in code_paths}
        identity_body = dict(schema=SCHEMA, source_files=verified, code_sha256=code,
            cohort_sha256=sha(KIT / "cohort.json"), source_contract_sha256=sha(KIT / "source_contract.json"),
            environment=environment, microbatch=args.microbatch, parity_absolute_tolerance=PARITY_ATOL)
        identity = digest_value(identity_body)
        provenance = dict(identity_body, run_identity=identity,
            created_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
            source_root=str(root), source_checkpoint_step=26000, training_performed=False,
            esmc_inference_performed=False, natural_reference_calibration_applied=False,
            score_contract=dict(masking="one physical object at a time with overlap and sequence-alias closure",
                local="Original frozen encoder features(context=False), followed by original decoder",
                global_score="Original frozen full-context encoder and decoder; runtime mode name is full",
                formula="1 - mean_roles(0.25*(1-cos(pred,target)) + 0.75*(1-cos(pred-mean,target-mean))); raw-cosine fallback if centered target norm <= 1e-6",
                range=[-1, 1], direction="higher is more compatible", activity_probability=False,
                break_handling="Both terminal slots are masked together and their losses averaged into one boundary score",
                joint_exchange_parity="Separate original joint mask, used only to verify the historical numerical contract"))
        run_file = output / "RUN_IDENTITY.json"
        if run_file.exists():
            require(json.loads(run_file.read_text())["run_identity"] == identity,
                    "Existing output belongs to different inputs/code/device/settings; choose a new --output")
        else:
            require(not any(output.glob("*.json")), "Unrecognized existing output directory")
            atomic_json(run_file, dict(run_identity=identity, identity=identity_body))
        working = output / "assemblies"
        working.mkdir(exist_ok=True)
        db = readonly(root / "e0_training_prep_461027/training_data.sqlite3")
        index = readonly(root / "e0_cache_final_491894/feature_index.sqlite3")
        cache = np.memmap(root / "e0_cache_final_491894/features.f32", mode="r", dtype="<f4", shape=FEATURE_SHAPE)
        results = []
        try:
            for number, row in enumerate(rows, 1):
                record, parents, vectors = read_record(db, index, cache, row)
                path = working / (hashlib.sha256(row["assembly_id"].encode()).hexdigest() + ".json")
                reused = path.exists()
                if reused:
                    result = read_saved_assembly(path, identity, record, row)
                else:
                    result = assemble_result(runtime, record, parents, vectors, row, args.microbatch)
                    atomic_json(path, dict(run_identity=identity, result_sha256=digest_value(result), result=result))
                results.append(result)
                emit("assembly", completed=number, total=105, assembly_id=row["assembly_id"],
                     objects=result["object_count"], scored=sum(o["status"] == "SCORED" for o in result["objects"]),
                     reused=reused, parity_max_error=result["joint_exchange_parity"]["maximum_absolute_error"])
        finally:
            db.close()
            index.close()
            del cache
        for relative, signature in signatures.items():
            stat = (root / relative).stat()
            require((stat.st_size, stat.st_mtime_ns, stat.st_ino) == signature,
                    "Source changed while scoring: " + relative)
        finish(output, results, provenance)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True, help="Original NeurALPSv2 directory on Jean Zay")
    parser.add_argument("--output", type=Path, required=True, help="New or matching resumable output directory")
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--microbatch", type=int, default=8)
    parser.add_argument("--threads", type=int, default=int(os.environ.get("SLURM_CPUS_PER_TASK", "8")))
    args = parser.parse_args()
    run(args)


if __name__ == "__main__":
    main()
