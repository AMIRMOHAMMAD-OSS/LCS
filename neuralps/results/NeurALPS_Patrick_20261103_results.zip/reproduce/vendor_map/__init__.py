"""Vendored frozen SSL26 map contract; see SOURCE_MANIFEST.json."""
