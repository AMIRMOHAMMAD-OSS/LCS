BODE1: complete intended peptide-sequence sets and corrected label join
=====================================================================

Scope
-----
These files annotate all 324 BODE1 constructs, preserving the archived assembly
ID and index 0..323. The 6 initiation x 9 elongation x 6 termination parts are
mapped from the primary paper's design diagram (Figure 3a), including inactive
constructs. Positive-product lists were not used to infer negative chemistry.
This is expected design chemistry, not a claim that every sequence was produced.

Primary source
--------------
Gonschorek et al., Split inteins for generating combinatorial non-ribosomal
peptide libraries, bioRxiv DOI 10.1101/2025.10.02.680031, version 3 October 2025.
Local source: sources/paper.pdf, Figure 3 on PDF page 20. The same PDF version
supplies the donor design panel, activity matrix, and example product structures.
paper_figure3_top.png: Figure 3a donor diagrams and plasmid IDs.
paper_figure3_matrices.png: Figure 3b, all 324 assay cells.
paper_figure3_products_11_13.png: Figure 3c corroborating product structures.

What was corrected
------------------
Primary Figure 3a: D = pIN264, E = pIN244.
Archived engineered_parts/activity tables: D = pIN244, E = pIN264.
The archived binary matrix is correct BY ALIAS: independent color-cell reading
of all 324 Figure 3b cells finds zero alias-level mismatches and 173 positives.
The problem is the alias-to-plasmid-ID join. It affects 108 construct mappings;
22 binary labels change (11 1->0 and 11 0->1), preserving 173 positives overall.
The other 86 remapped labels happen to be equal. All remaining 216 are unchanged.

Figure 3c separately corroborates the Figure 3a mapping:
  DHU (11): C4-Pro-Gly-Val-Tyr-Phe, 0.9 mg/L => initiation pIN264.
  DMV (12): C4-Pro-Gly-Phe-Leu-Phe-Leu-Leu, 0.2 mg/L => initiation pIN264.
  EJT (13): C6-Thr-Ala-Tyr-Val-Val, 0.3 mg/L => initiation pIN244.
The archived experimental_products.tsv.gz incorrectly assigns products 11/12
to pIN244 and 13 to pIN264, inheriting the same reversed alias join. Their product
codes and primary illustrated chemistry agree with the correction. This is
corroboration of the mapping, not a source for unobserved construct chemistry.

Use label_primary_verified for the source-aligned outcome and label_archived
only for the archival sensitivity analysis. Keep frozen features and folds
attached to their original assembly IDs. Refits of all compared heads must use
the same corrected labels for a comparable primary analysis.

Files
-----
bode1_expected_chemistry.json: metadata, donor_parts, and 324 construct rows.
bode1_expected_chemistry.csv: the same construct rows; list-valued fields are JSON.
bode1_donor_annotations.csv: all 21 donor part annotations.
bode1_label_join_audit_all324.csv: complete exact label/alias old-to-new audit.
bode1_label_join_remapped108.csv: constructs with changed alias-to-ID assignment.
bode1_label_join_changed22.csv: only constructs whose binary label changes.
bode1_annotation_provenance.json: source hashes, assumptions and validation counts.
figure3_matrix_pixel_audit.json: cell coordinates and independent image labels.
DATA_DICTIONARY.txt: field meanings and sequence-set encoding.

Portable reproduction
---------------------
The builder uses Python's standard library and only small source files, not the
git checkout or large archive ZIPs. Keep the extracted source path hierarchy:
  sources/extracted data from bode paper/engineered_parts.tsv.gz
  sources/extracted data from bode paper/experimental_construct_activity.tsv.gz
The experimental_products.tsv.gz file is included only for the corroboration
audit above; the builder does not read it.

Run from any working directory (replace the metadata path):
  python build_bode1_expected_chemistry.py --metadata /path/to/inputs/metadata.json
Optional: --source-dir, --matrix-audit, --output-dir.
The required metadata input is the archived Level12 inputs/metadata.json,
provided separately with the frozen modeling inputs; its SHA256 is recorded.

To regenerate the independent cell audit, install Pillow and run:
  python verify_figure3_matrix.py
Add --render to recreate the matrix crop from the same PDF; this requires the
Poppler pdftoppm command. Rendering uses PDF page 20 at 300 dpi, crop
x=160, y=1620, width=2200, height=640. Each cell uses a 27x27-pixel inset.
Colored cells have minimum saturated fraction 0.7023, whereas every negative
cell has fraction 0. The classification threshold is 0.15, well between them.
Topology (linear/cyclic) is not reclassified by this binary audit.

Source archive provenance
-------------------------
Repository AMIRMOHAMMAD-OSS/LCS, commit
9347bfba93cc8f0033eea7524db5d8f2eda7d002.
Collection neuralps/reports/NRP_review_20261102_235638_294c9ce3.
All four ZIP archive checksums match collection.json. Extracted file bytes also
match the inventory SHA256 values. Exact hashes are recorded in provenance.
Source originals were not modified.

Interpretation limits
---------------------
There are 462 AA-sequence assignments across 324 constructs (378 distinct full
AA sequences), or 539 assignments if the displayed C5/C6 acyl alternatives are
also expanded. These are design-space assignments, not numbers of measured
products. The length distribution is 4 residues:72, 5:138, 6:84, 7:30.
Alternatives have no measured weighting. Equal weighting in a feature encoding
is a modeling convention, not an inferred product abundance.
No stereochemistry, cyclization topology, or yield is inferred from the design
AA sequences. The primary paper itself discusses deficient epimerization and
stereoisomers, so domain architecture alone does not guarantee product stereo.
Figure 3a's lowercase i is Ile identity, not a D-stereochemical annotation.
For pIN263, primary BODE1 Figure 3a specifies Ile-Thr, while archived antiSMASH
consensus says Leu-Thr. Native FitAB literature includes Ile/Leu, but we do not
silently broaden the intended BODE1 sequence beyond its displayed Ile.
Beta-Ala is kept as the separate token BETA_ALA, never the ambiguous code B.
The full observed-product table S7 is not part of this recovered source set;
the chemistry annotation does not require it. Main text/Edmond report 258
products, whereas Figure 3b prints 257; this discrepancy does not alter the
324 construct-level binary labels or the intended sequence sets.
