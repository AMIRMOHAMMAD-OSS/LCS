#!/usr/bin/env python3
"""Standard-library integrity/label checks safe on the login node."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent


def validate_package():
    manifest = json.loads((HERE / 'PACKAGE_MANIFEST.json').read_text())
    for relative, expected in manifest['files'].items():
        path = (HERE / relative).resolve()
        if not path.is_relative_to(HERE) or not path.is_file():
            raise ValueError('Missing/unsafe package path: ' + relative)
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Package file changed: ' + relative)
    rows = json.loads((HERE / 'inputs/metadata.json').read_text())['rows']
    assert len(rows) == 494
    assert all(r['index'] == i for i, r in enumerate(rows))
    assert len({(r['dataset'], r['assembly_id']) for r in rows}) == 494
    assert Counter(r['dataset'] for r in rows) == {'bode1':324,'bode2':105,'tdomain':65}
    assert sum(r['observed_activity'] for r in rows) == 286
    with (HERE / 'provenance/bode1_label_join_audit_all324.csv').open() as stream:
        audited = {r['assembly_id']:r for r in csv.DictReader(stream)}
    b1 = [r for r in rows if r['dataset'] == 'bode1']
    assert all(r['observed_activity'] == int(audited[r['assembly_id']]['label_primary_verified']) for r in b1)
    assert sum(r['observed_activity'] != r['archived_activity'] for r in b1) == 22
    b2 = [r for r in rows if r['dataset'] == 'bode2']
    counts = Counter(r['group'] for r in b2)
    assert len(counts) == 35 and set(counts.values()) == {3}
    for group in counts:
        assert {r['metadata']['exchange_position'] for r in b2 if r['group'] == group} == {2,3,4}
    chemistry = json.loads((HERE / 'inputs/chemistry.json').read_text())
    assert len(chemistry['rows']) == 494 and chemistry['scope'] == 'BODE2_only'
    assert all(bool(c) == (r['dataset']=='bode2') for c,r in zip(chemistry['rows'],rows))
    protocol = json.loads((HERE / 'PROTOCOL.json').read_text())
    assert protocol['neural']['seeds'] == [17,29,43]
    assert protocol['frozen']['outer_folds'] == 5
    return dict(package_files=len(manifest['files']), labels=494, corrected_bode1=22,
                bode2_donors=35, numerical_tests='Required inside allocated PyTorch job')


class IntegrityTests(unittest.TestCase):
    def test_package_and_labels(self):
        self.assertEqual(validate_package()['labels'],494)


if __name__ == '__main__':
    print(json.dumps(validate_package(), indent=2))
    unittest.main()
