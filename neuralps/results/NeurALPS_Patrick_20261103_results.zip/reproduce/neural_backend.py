"""Pinned Jean Zay inputs and bounded supervised assembly-model fitting.

No ESM-C weights are loaded or updated. Structural records never contain labels.
Labels are supplied explicitly to each fit and indexed only at training/validation
rows. The held-out prediction rows are accepted only by refit_predict.
"""
from __future__ import annotations

from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path
import random
import sqlite3
import time

import numpy as np

PACKAGE = Path(__file__).resolve().parent
FEATURE_SHAPE = (548713, 1152)
MAIN_DB = "e0_training_prep_461027/training_data.sqlite3"
MAIN_CACHE = "e0_cache_final_491894"
TD_RUN = "e10_tdomain_embed_696333"
TD_RECORDS = "e11_tdomain_transfer_699466/scores/records.json.gz"
CHECKPOINTS = {
    "ssl10": ("e1_ssl_continue_development_527237/best.pt", 10000,
              "b89a9da8aff6066139bc926b47b5fff707b9d625b10b7e10e0ff07dc10d9441f"),
    "ssl26": ("e1_ssl_continue30_v1_530757/best.pt", 26000,
              "9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f"),
}
PINNED_INPUTS = {
    MAIN_DB: "6c273f05a6bcde4fec6fc57a26d0a35a9461f9831656248bee3ca21de1c14287",
    MAIN_CACHE + "/features.f32": "5a7c2f3afd527785ce3c12eaa3b97138034f4dfc811d840b5b44cf1534b9ef90",
    MAIN_CACHE + "/feature_index.sqlite3": "09a6bde676c2e22bcba78879cf53c1d1979d672bcc1763a9eb49e218f387735b",
    TD_RUN + "/feature_index.sqlite3": "41d81778fc2d2c015cbe28d429ed2bccc7ea8940142106a02ef98eceeac06bfe",
    TD_RUN + "/features.f32": "1134819306754396634ee0f1c00a0bfffb2cb15cd4a20daca08b22243f1ee77d",
    TD_RUN + "/inputs/parents.fasta.gz": "15f9181a74d4bb42325bfa2af5900dcd6a2a967a0d6be1c6428b1187f34a08c9",
    TD_RECORDS: "fa79f3e0f8618f004bb6b157dae9235ff9580bf4bc3a0a49c2d2b167e570e2d0",
}
for _path, _step, _digest in CHECKPOINTS.values():
    PINNED_INPUTS[_path] = _digest

DEFAULT_RECIPE = dict(batch=16, warmup_epochs=10, tuning_epochs=100,
                      patience=12, warmup_lr=1e-3, head_lr=3e-4,
                      encoder_lr=3e-5, weight_decay=.01, gradient_clip=1.,
                      checkpoint_every_epochs=5)
ARMS = ("raw_mlp", "ssl10_finetune", "ssl26_finetune")


class TrainingPaused(RuntimeError):
    """A fit stopped at an epoch boundary; its checked resume state is saved."""


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def _torch():
    import torch
    return torch


def _readonly(path):
    db = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)
    db.execute("PRAGMA query_only=ON")
    return db


def _fasta(path):
    result, name = {}, None
    with gzip.open(path, "rt", encoding="ascii") as stream:
        for line in stream:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                name = line[1:]
                require(name not in result, "Duplicate parent FASTA identity")
                result[name] = ""
            else:
                require(name is not None, "Sequence before FASTA header")
                result[name] += line
    for h, sequence in result.items():
        require(sequence and set(sequence) <= set("ACDEFGHIKLMNPQRSTVWY") and
                hashlib.sha256(sequence.encode()).hexdigest() == h,
                "Parent FASTA sequence/hash mismatch")
    return result


def clean_record(source, dataset):
    fields = ("assembly_id", "route", "model_slots", "parent_sequence_hashes",
              "parent_lengths", "boundary_window_policy")
    rec = {key: source[key] for key in fields if key in source}
    require(all(k in rec for k in fields[:4]), "Incomplete physical route record")
    require(rec.get("boundary_window_policy") == "physical_end_extradomain_tail64_v1",
            "Physical connection-window policy differs")
    rec["dataset"] = dataset
    return rec


def _route_fingerprint(record):
    """Label/ID-free exact model input signature; no claim of homology purging."""
    tokens = [(o["kind"], o["domain_type"] if o["kind"] == 0 else 0,
               o["chain"] if o["kind"] != 2 else -1) for o in record["route"]]
    slots = sorted((s["object_index"], s["slot"], s["state"],
                    s["sequence_hash"] if s["state"] == "OBSERVED" else None)
                   for s in record["model_slots"])
    return digest(dict(tokens=tokens, slots=slots))


def source_overlap_audit(records, rows, native_record):
    """Exclude auxiliary rows sharing held-donor primary domain hashes.

    Primary regional object indices are copied from the sealed E12 query, not
    inferred from scaffold overlap. Exact route duplicates are also excluded.
    This is deliberately conservative exact-sequence exclusion, not homology CV.
    """
    targets = json.loads((PACKAGE / "vendor_neural/bode2_target_objects.json").read_text())
    aux = [i for i, r in enumerate(rows) if r["dataset"] != "bode2"]
    domains = [{s["sequence_hash"] for s in rec["model_slots"]
                if s["state"] == "OBSERVED" and rec["route"][s["object_index"]]["kind"] == 0}
               for rec in records]
    exact = [_route_fingerprint(rec) for rec in records]
    native_domain_hashes = {s["sequence_hash"] for s in native_record["model_slots"]
                            if s["state"] == "OBSERVED" and
                            native_record["route"][s["object_index"]]["kind"] == 0}
    require(native_domain_hashes, "No verified native recipient domain hashes")
    grouped = {}
    for i, row in enumerate(rows):
        if row["dataset"] != "bode2":
            continue
        aid, group = row["assembly_id"], row["group"]
        require(isinstance(group, str), "BODE2 donor group must be a string")
        require(aid in targets["targets"], "Missing verified BODE2 regional targets")
        primary = targets["targets"][aid]
        require(primary and all(type(j) is int and 0 <= j < len(records[i]["route"]) for j in primary),
                "Invalid verified regional object indices")
        ds = {j for j in primary if records[i]["route"][j]["kind"] == 0}
        hh = {s["sequence_hash"] for s in records[i]["model_slots"]
              if s["state"] == "OBSERVED" and s["object_index"] in ds}
        require(ds and len(hh) >= 2, "No verified multi-domain donor region")
        entry = grouped.setdefault(group, dict(indices=[], target_domain_hashes=set(), exact_routes=set()))
        entry["indices"].append(i)
        entry["target_domain_hashes"].update(hh)
        entry["exact_routes"].add(exact[i])
    require(len(grouped) == 35 and all(len(v["indices"]) == 3 for v in grouped.values()),
            "Expected 35 complete BODE2 donor triplets")
    exclusions, detail = {}, {}
    for group, entry in sorted(grouped.items()):
        donor_specific = entry["target_domain_hashes"] - native_domain_hashes
        domain_hits = [i for i in aux if domains[i] & donor_specific]
        route_hits = [i for i in aux if exact[i] in entry["exact_routes"]]
        exclusions[group] = sorted(set(domain_hits + route_hits))
        detail[group] = dict(target_rows=entry["indices"],
                             primary_domain_hashes=sorted(entry["target_domain_hashes"]),
                             native_recipient_identical_domain_hashes=sorted(entry["target_domain_hashes"] & native_domain_hashes),
                             donor_specific_primary_domain_hashes=sorted(donor_specific),
                             novel_domain_sequence_claim_supported=bool(donor_specific),
                             auxiliary_domain_hash_hits=domain_hits, exact_route_duplicates=route_hits,
                             excluded_counts_by_dataset=dict(Counter(rows[i]["dataset"] for i in exclusions[group])))
    return dict(schema="exact_primary_donor_domain_exclusion_v1", auxiliary_exclusions=exclusions,
                groups=detail, target_source=targets["source"], target_source_sha256=targets["source_sha256"],
                biological_homology_purged=False,
                native_recipient_identity=native_record["assembly_id"],
                limitations="Exact donor-specific primary-domain and whole-input exclusion only; native recipient domains removed before auxiliary purge; no sequence-identity clustering")


class NeuralRuntime:
    """Read-only pinned assets, label-free records, and batches in metadata order."""
    def __init__(self, root, rows, device="cuda", threads=8):
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        torch = _torch()
        from vendor_neural.assembly_model import collate_records
        self.root = Path(root).resolve()
        self.rows = [{k: r[k] for k in ("index", "dataset", "assembly_id", "group") if k in r} for r in rows]
        self.device = str(device)
        require(len(self.rows) == 494 and len({(r["dataset"], r["assembly_id"]) for r in rows}) == 494,
                "Expected exact 494-row primary cohort")
        require(dict(Counter(r["dataset"] for r in rows)) == {"bode1": 324, "bode2": 105, "tdomain": 65},
                "Wrong primary cohort counts")
        require(all(r.get("index", i) == i for i, r in enumerate(rows)), "Metadata indices must be ordered")
        if self.device.startswith("cuda"):
            require(torch.cuda.is_available(), "CUDA unavailable; run in the GPU allocation")
        torch.set_num_threads(threads)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.set_float32_matmul_precision("highest")
        torch.use_deterministic_algorithms(True)
        source_proof = {}
        for relative, expected in sorted(PINNED_INPUTS.items()):
            path = self.root / relative
            require(path.is_file(), "Required pinned input absent: " + relative)
            if path.suffix == ".sqlite3":
                require(not Path(str(path) + "-wal").exists(), "Unexpected WAL on pinned source: " + relative)
            before = path.stat()
            actual = sha(path)
            after = path.stat()
            require((before.st_size, before.st_mtime_ns, before.st_ino) ==
                    (after.st_size, after.st_mtime_ns, after.st_ino), "Source changed during verification")
            require(actual == expected, "Pinned source hash changed: " + relative)
            source_proof[relative] = dict(sha256=actual, bytes=after.st_size)
        require((self.root / MAIN_CACHE / "features.f32").stat().st_size == np.prod(FEATURE_SHAPE) * 4,
                "Main feature matrix byte count differs")
        db = _readonly(self.root / MAIN_DB)
        reviewed_bode2 = {r["assembly_id"] for r in rows if r["dataset"] == "bode2"}
        extra_bode2 = [json.loads(payload) for aid, payload in db.execute(
            "SELECT assembly_id,payload FROM assemblies WHERE dataset='bode2'") if aid not in reviewed_bode2]
        require(len(extra_bode2) == 1, "Expected the single excluded BODE2 native control")
        self.native_record = clean_record(extra_bode2[0], "bode2")
        index = _readonly(self.root / MAIN_CACHE / "feature_index.sqlite3")
        main_z = np.memmap(self.root / MAIN_CACHE / "features.f32", dtype="<f4", mode="r", shape=FEATURE_SHAPE)
        td_index = _readonly(self.root / TD_RUN / "feature_index.sqlite3")
        td_entries = list(td_index.execute("SELECT hash,feature_row,status FROM features ORDER BY feature_row"))
        require(len(td_entries) == 290 and all(row == i and status == "covered"
                for i, (_, row, status) in enumerate(td_entries)), "Invalid sealed T-domain cache index")
        td_rows = {h: i for h, i, _ in td_entries}
        td_z = np.memmap(self.root / TD_RUN / "features.f32", dtype="<f4", mode="r", shape=(len(td_rows), 1152))
        td_parents = _fasta(self.root / TD_RUN / "inputs/parents.fasta.gz")
        with gzip.open(self.root / TD_RECORDS, "rt") as stream:
            td_records = json.load(stream)
        if isinstance(td_records, dict) and "records" in td_records:
            td_records = td_records["records"]
        if isinstance(td_records, list):
            td_records = {r["assembly_id"]: r for r in td_records}
        require(isinstance(td_records, dict) and len(td_records) == 88, "Expected 88 sealed T-domain input routes")
        self.records, self.parents, self.vectors = [], {}, {}
        try:
            for row in rows:
                dataset, aid = row["dataset"], row["assembly_id"]
                if dataset == "tdomain":
                    require(aid in td_records, "Reviewed T-domain construct not in sealed input")
                    source = td_records[aid]
                else:
                    found = db.execute("SELECT payload FROM assemblies WHERE dataset=? AND assembly_id=?", (dataset, aid)).fetchall()
                    require(len(found) == 1, "Missing/duplicate structural record: " + aid)
                    source = json.loads(found[0][0])
                require(source["assembly_id"] == aid, "Structural identity differs")
                record = clean_record(source, dataset)
                parent_by_hash = {}
                for ph in set(record["parent_sequence_hashes"].values()):
                    if dataset == "tdomain":
                        require(ph in td_parents, "Missing T-domain parent sequence")
                        sequence = td_parents[ph]
                    else:
                        match = db.execute("SELECT sequence FROM proteins WHERE hash=?", (ph,)).fetchall()
                        require(len(match) == 1, "Missing/duplicated parent sequence")
                        sequence = match[0][0]
                    require(hashlib.sha256(sequence.encode()).hexdigest() == ph, "Parent sequence hash differs")
                    parent_by_hash[ph] = sequence
                    self.parents[ph] = sequence
                vectors = {}
                for slot in record["model_slots"]:
                    j, k = slot["object_index"], slot["slot"]
                    require(0 <= j < len(record["route"]) and k in (0, 1, 2), "Invalid slot index")
                    require(slot["kind"] == record["route"][j]["kind"], "Slot/route kind differs")
                    parent = parent_by_hash[slot["parent_sequence_hash"]]
                    require(0 <= slot["start"] <= slot["end"] <= len(parent), "Invalid slot interval")
                    sequence = parent[slot["start"]:slot["end"]]
                    require(len(sequence) == slot["length"], "Slot length differs")
                    if slot["state"] != "OBSERVED":
                        continue
                    h = slot["sequence_hash"]
                    require(hashlib.sha256(sequence.encode()).hexdigest() == h, "Observed slot hash differs")
                    if dataset == "tdomain":
                        require(h in td_rows, "T-domain input absent from its sealed sidecar")
                        vector = np.array(td_z[td_rows[h]], copy=True)
                    else:
                        match = index.execute("SELECT feature_row FROM features WHERE hash=? AND status='covered'", (h,)).fetchall()
                        require(len(match) == 1 and 0 <= match[0][0] < FEATURE_SHAPE[0], "Observed main feature missing")
                        vector = np.array(main_z[match[0][0]], copy=True)
                    require(np.isfinite(vector).all() and np.linalg.norm(vector) > 0, "Invalid feature vector")
                    vectors[h] = vector
                # Keep per-dataset extraction namespaces; identical hash can have a
                # separately extracted T-domain vector with tiny numerical differences.
                self.vectors[(dataset, aid)] = vectors
                self.records.append(record)
        finally:
            db.close(); index.close(); td_index.close()
            del main_z, td_z
        self._collate = collate_records
        self._checkpoint_cache, self._raw = {}, None
        # Keep a single padded master tensor on the allocated device. This avoids
        # repeating sequence-feature lookup/collation for every training epoch.
        self._master = self._collate_indices(range(len(self.records)))
        self.identity = dict(schema="patrick_neural_inputs_v1", sources=source_proof,
                             rows=[dict(dataset=r["dataset"], assembly_id=r["assembly_id"]) for r in rows],
                             structural_records_sha256=digest(self.records),
                             label_source="explicit fit arguments; source database labels ignored",
                             encoder_source_sha256=sha(PACKAGE / "vendor_neural/assembly_model.py"))
        self.identity_sha256 = digest(self.identity)
        self.overlap_audit = source_overlap_audit(self.records, rows, self.native_record)

    def _collate_indices(self, indices):
        # Collate each row independently to preserve the T-domain sidecar namespace,
        # then pad to this batch's maximum route length. Padding has no model inputs.
        torch = _torch()
        prepared = [self._collate([self.records[int(i)]],
                    self.vectors[(self.records[int(i)]["dataset"], self.records[int(i)]["assembly_id"])].__getitem__)
                    for i in indices]
        require(prepared, "Empty prediction/training batch")
        length = max(b["valid"].shape[1] for b in prepared)
        output = {}
        for key in prepared[0]:
            parts = []
            for b in prepared:
                value = b[key]
                shape = list(value.shape); shape[1] = length
                padded = torch.zeros(shape, dtype=value.dtype)
                if key == "chain":
                    padded.fill_(-1)
                padded[:, :value.shape[1]] = value
                parts.append(padded)
            output[key] = torch.cat(parts).to(self.device)
        return output

    def batch(self, indices):
        torch = _torch()
        ix = torch.tensor(list(indices), dtype=torch.long, device=self.device)
        require(ix.numel() > 0, "Empty prediction/training batch")
        return {key: value.index_select(0, ix) for key, value in self._master.items()}

    def raw_features(self):
        """Frozen ESM-C global pooling, metadata order, 3*1152+2 columns."""
        torch = _torch()
        if self._raw is None:
            with torch.no_grad():
                self._raw = torch.cat([raw_pool(self.batch(range(i, min(i + 16, len(self.records))))).cpu()
                                       for i in range(0, len(self.records), 16)])
        return self._raw.numpy().astype(np.float64, copy=True)

    def typed_features(self, indices):
        """Exact frozen SSL26 typed2822 schema used by the existing logistic head."""
        torch = _torch()
        from vendor_neural.assembly_model import AssemblyEncoder, Config
        indices = _indices(indices, len(self.records), "typed export")
        source = self._source("ssl26")
        model = AssemblyEncoder(Config(**source["config"]))
        model.load_state_dict(source["model"], strict=True)
        model.to(self.device).eval().requires_grad_(False)
        features = []
        with torch.no_grad():
            for i in indices:
                h = model.features(self.batch([i]))[0, :len(self.records[i]["route"])].cpu().numpy().astype(np.float64)
                groups = [[], [], []]
                route = self.records[i]["route"]
                require(h.shape[1] == 256, "Typed schema requires width256")
                for j, obj in enumerate(route):
                    kind = obj["kind"]
                    if kind == 0:
                        value = h[j]
                    else:
                        require(0 < j < len(route) - 1 and route[j-1]["kind"] == route[j+1]["kind"] == 0,
                                "Invalid boundary neighbors")
                        left, right = h[j-1], h[j+1]
                        value = np.concatenate([left, h[j], right, left * right, np.abs(left - right)])
                    groups[kind].append(value)
                means = [np.mean(g, axis=0) if g else np.zeros(256 if k == 0 else 1280)
                         for k, g in enumerate(groups)]
                extra = np.asarray([v for g in groups for v in (np.log1p(len(g)), float(bool(g)))])
                features.append(np.concatenate([*means, extra]))
        del model
        return np.stack(features)

    def _source(self, name):
        torch = _torch()
        if name not in self._checkpoint_cache:
            path, step, expected = CHECKPOINTS[name]
            # Only explicitly pinned user-provided trusted checkpoints are unpickled.
            require(sha(self.root / path) == expected, "Checkpoint changed before loading")
            source = torch.load(self.root / path, map_location="cpu", weights_only=False)
            require(source["step"] == step, "Wrong selected SSL update")
            state = source["model"]
            require(all(bool(torch.isfinite(v).all()) for v in state.values()), "Nonfinite pretrained weights")
            self._checkpoint_cache[name] = dict(model=state, config=source["config"]["settings"]["encoder"],
                                                sha256=expected, step=step)
        return self._checkpoint_cache[name]

    def build(self, arm, seed):
        from vendor_neural.assembly_model import AssemblyEncoder, Config
        require(arm in ARMS, "Unknown neural arm")
        if arm == "raw_mlp":
            self.raw_features()
            return new_head(3458, seed).to(self.device)
        source = self._source(arm.split("_", 1)[0])
        model = AssemblyEncoder(Config(**source["config"]))
        model.load_state_dict(source["model"], strict=True)
        model.activity_head = new_head(3 * source["config"]["width"] + 2, seed)
        return model.to(self.device)

    def logits(self, model, arm, indices):
        torch = _torch()
        if arm == "raw_mlp":
            return model(self._raw[list(indices)].to(self.device)).squeeze(-1)
        return model.activity(self.batch(indices))

    def export_bode2_records(self, path):
        """Structural provenance only; future multi-swap construction needs its own audit."""
        records = [r for r in self.records if r["dataset"] == "bode2"]
        parent_hashes = {h for r in records for h in r["parent_sequence_hashes"].values()}
        payload = dict(schema="bode2_single_swap_structural_inputs_v1", records=records,
                       parents={h: self.parents[h] for h in sorted(parent_hashes)},
                       source_identity=self.identity_sha256,
                       candidate_multi_swap_sequences_constructed=False)
        Path(path).write_bytes(gzip.compress(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode(), mtime=0))


def pool_objects(h, batch):
    torch = _torch()
    valid, kind = batch["valid"], batch["kind"]
    dm, em = valid & (kind == 0), valid & (kind != 0)
    nd, ne = dm.sum(1, keepdim=True), em.sum(1, keepdim=True)
    dmean = (h * dm.unsqueeze(-1)).sum(1) / nd.clamp_min(1)
    emean = (h * em.unsqueeze(-1)).sum(1) / ne.clamp_min(1)
    emax = h.masked_fill(~em.unsqueeze(-1), float("-inf")).amax(1)
    emax = torch.where(ne > 0, emax, torch.zeros_like(emax))
    return torch.cat([dmean, emean, emax, nd.float().log1p(), ne.float().log1p()], dim=-1)


def raw_pool(batch):
    torch = _torch()
    observed = (batch["state"] == 1) & batch["valid"].unsqueeze(-1)
    x = torch.where(observed.unsqueeze(-1), batch["x"], torch.zeros_like(batch["x"]))
    return pool_objects(x.sum(2) / observed.sum(2, keepdim=True).clamp_min(1), batch)


def new_head(width, seed):
    torch = _torch()
    nn = torch.nn
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(int(seed))
        return nn.Sequential(nn.LayerNorm(width), nn.Linear(width, 128), nn.GELU(),
                             nn.Dropout(.3), nn.Linear(128, 1))


def _configure(model, arm, phase, recipe):
    torch = _torch()
    model.requires_grad_(False)
    head = model if arm == "raw_mlp" else model.activity_head
    head.requires_grad_(True)
    train_encoder = arm != "raw_mlp" and phase == "tune"
    if train_encoder:
        for name, parameter in model.named_parameters():
            if not name.startswith(("activity_head.", "decoder.", "decoder_role.", "decoder_kind.")):
                parameter.requires_grad_(True)
    groups, head_ids = [], {id(p) for p in head.parameters()}
    for is_head in (False, True):
        named = [(n, p) for n, p in model.named_parameters()
                 if p.requires_grad and (id(p) in head_ids) == is_head]
        lr = recipe["warmup_lr"] if phase == "warmup" else (recipe["head_lr"] if is_head else recipe["encoder_lr"])
        for decay in (False, True):
            params = [p for n, p in named if (p.ndim > 1 and "norm" not in n.lower() and
                      "embedding" not in n.lower() and "global_tokens" not in n) == decay]
            if params:
                groups.append(dict(params=params, lr=lr, weight_decay=recipe["weight_decay"] if decay else 0.))
    return torch.optim.AdamW(groups, betas=(.9, .999), eps=1e-8), train_encoder


def _cpu_state(model):
    return {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}


def _save_torch(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    _torch().save(value, temporary)
    temporary.replace(path)


def normalize_weights(sample_weights, n):
    weights = np.asarray(sample_weights, dtype=np.float64)
    require(weights.shape == (n,) and np.isfinite(weights).all() and (weights > 0).all(),
            "Sample weights must be finite, positive and train-row aligned")
    return weights * (n / weights.sum())


def _indices(values, n, name, allow_empty=False):
    values = list(values)
    require((values or allow_empty) and all(isinstance(i, (int, np.integer)) and not isinstance(i, bool)
            and 0 <= int(i) < n for i in values), "Invalid " + name + " indices")
    result = [int(i) for i in values]
    require(len(result) == len(set(result)), "Duplicate " + name + " indices")
    return result


def _recipe(recipe):
    result = dict(DEFAULT_RECIPE)
    if recipe:
        require(set(recipe) <= set(result), "Unknown neural recipe setting")
        result.update(recipe)
    require(all(type(result[k]) is int and result[k] > 0 for k in
                ("batch", "tuning_epochs", "patience", "checkpoint_every_epochs")), "Invalid integer recipe")
    require(type(result["warmup_epochs"]) is int and result["warmup_epochs"] >= 0, "Invalid warmup epochs")
    require(all(np.isfinite(result[k]) and result[k] > 0 for k in
                ("warmup_lr", "head_lr", "encoder_lr", "gradient_clip")), "Invalid neural learning-rate recipe")
    require(np.isfinite(result["weight_decay"]) and result["weight_decay"] >= 0, "Invalid weight decay")
    return result


def _predict(runtime, model, arm, indices, batch):
    torch = _torch()
    model.eval()
    with torch.no_grad():
        if not indices:
            return np.empty(0, dtype=float)
        logits = np.concatenate([runtime.logits(model, arm, indices[i:i + batch]).detach().cpu().numpy()
                                 for i in range(0, len(indices), batch)]).astype(np.float64)
    require(np.isfinite(logits).all(), "Nonfinite supervised prediction")
    return logits


def _run(runtime, arm, train_indices, validation_indices, labels, sample_weights,
         seed, recipe, epochs=None, work_dir=None, deadline_monotonic=None, stop_requested=None):
    torch = _torch()
    require(arm in ARMS, "Unknown neural arm")
    recipe = _recipe(recipe)
    n = len(runtime.records)
    train = _indices(train_indices, n, "training")
    val = _indices(validation_indices, n, "validation", allow_empty=epochs is not None)
    require(not set(train) & set(val), "Training/validation overlap")
    # Deliberately index only the rows participating in this fit.
    train_y = np.asarray([labels[i] for i in train], dtype=np.float32)
    val_y = np.asarray([labels[i] for i in val], dtype=np.float64)
    require(np.isin(train_y, [0, 1]).all() and np.isin(val_y, [0, 1]).all(), "Invalid fit labels")
    require(len(set(train_y.tolist())) == 2, "Training split must contain both classes")
    weights = normalize_weights(sample_weights, len(train))
    cap = recipe["warmup_epochs"] + recipe["tuning_epochs"]
    if epochs is not None:
        require(type(epochs) is int and 0 <= epochs <= cap, "Refit epoch cap outside declared recipe")
        cap = epochs
    contract = dict(schema="patrick_neural_fit_v1", input_identity=runtime.identity_sha256,
                    arm=arm, seed=int(seed), recipe=recipe, epochs=epochs,
                    train_indices=train, train_labels=train_y.tolist(), train_weights=weights.tolist(),
                    validation_indices=val, validation_labels=val_y.tolist(),
                    backend_sha256=sha(Path(__file__)), torch_version=torch.__version__)
    contract_sha = digest(contract)
    directory = Path(work_dir) if work_dir is not None else None
    if directory is not None:
        directory.mkdir(parents=True, exist_ok=True)
        p = directory / "contract.json"
        if p.exists():
            require(json.loads(p.read_text()) == contract, "Neural resume contract changed")
        else:
            atomic_json(p, contract)
    torch.manual_seed(int(seed))
    if runtime.device.startswith("cuda"):
        torch.cuda.manual_seed_all(int(seed))
    model = runtime.build(arm, seed)
    phase, current, bad, updates = "warmup", 0, 0, 0
    opt, train_encoder = _configure(model, arm, phase, recipe)
    best = None
    start = time.monotonic()
    def validate():
        z = _predict(runtime, model, arm, val, recipe["batch"])
        return float(np.mean(np.logaddexp(0., z) - val_y * z)), z
    if val:
        loss, _ = validate()
        best = dict(epoch=0, log_loss=loss, model=_cpu_state(model))
    latest = None if directory is None else directory / "latest.pt"
    complete = None if directory is None else directory / "complete.pt"
    if complete is not None and complete.exists():
        restored = torch.load(complete, map_location="cpu", weights_only=False)
        require(restored["contract_sha256"] == contract_sha, "Completed neural fit contract differs")
        model.load_state_dict(restored["state"])
        return model, restored["report"]
    if latest is not None and latest.exists():
        saved = torch.load(latest, map_location=runtime.device, weights_only=False)
        require(saved["contract_sha256"] == contract_sha, "Saved neural fit contract differs")
        model.load_state_dict(saved["model"])
        current, phase, bad, updates = saved["epoch"], saved["phase"], saved["bad"], saved["encoder_steps"]
        best = saved["best"]
        opt, train_encoder = _configure(model, arm, phase, recipe)
        opt.load_state_dict(saved["optimizer"])
        torch.set_rng_state(saved["cpu_rng"].cpu())
        if runtime.device.startswith("cuda"):
            torch.cuda.set_rng_state_all([s.cpu() for s in saved["cuda_rng"]])
    def save_resume():
        if latest is not None:
            _save_torch(latest, dict(contract_sha256=contract_sha, model=_cpu_state(model),
                                    optimizer=opt.state_dict(), epoch=current, phase=phase, bad=bad,
                                    encoder_steps=updates, best=best, cpu_rng=torch.get_rng_state(),
                                    cuda_rng=torch.cuda.get_rng_state_all() if runtime.device.startswith("cuda") else []))
    def should_stop():
        return ((deadline_monotonic is not None and time.monotonic() >= deadline_monotonic) or
                (stop_requested is not None and stop_requested()))
    stopped = val and phase == "tune" and bad >= recipe["patience"]
    for epoch in range(current + 1, (current if stopped else cap) + 1):
        if should_stop():
            save_resume()
            raise TrainingPaused("Neural fit saved at epoch " + str(current))
        new_phase = "warmup" if epoch <= recipe["warmup_epochs"] else "tune"
        if new_phase != phase:
            phase, bad = new_phase, 0
            opt, train_encoder = _configure(model, arm, phase, recipe)
        if train_encoder or arm == "raw_mlp":
            model.train()
        else:
            model.eval()
            model.activity_head.train()
        order = list(range(len(train)))
        random.Random(int(seed) * 1000003 + epoch).shuffle(order)
        for start_row in range(0, len(order), recipe["batch"]):
            loc = order[start_row:start_row + recipe["batch"]]
            ids = [train[i] for i in loc]
            yy = torch.tensor(train_y[loc], device=runtime.device)
            ww = torch.tensor(weights[loc], dtype=torch.float32, device=runtime.device)
            opt.zero_grad(set_to_none=True)
            logits = runtime.logits(model, arm, ids)
            # Global mean-normalized weights, not per-batch weight normalization.
            loss = (torch.nn.functional.binary_cross_entropy_with_logits(logits, yy, reduction="none") * ww).mean()
            require(bool(torch.isfinite(loss)), "Nonfinite supervised training loss")
            loss.backward()
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],
                                          recipe["gradient_clip"], error_if_nonfinite=True)
            opt.step()
            if train_encoder:
                updates += 1
        current = epoch
        if val:
            loss, _ = validate()
            if loss < best["log_loss"]:
                best = dict(epoch=epoch, log_loss=loss, model=_cpu_state(model))
                bad = 0
            elif phase == "tune":
                bad += 1
        if epoch % recipe["checkpoint_every_epochs"] == 0 or epoch == cap or should_stop() or (val and bad >= recipe["patience"]):
            save_resume()
        if should_stop():
            raise TrainingPaused("Neural fit saved at epoch " + str(current))
        if val and phase == "tune" and bad >= recipe["patience"]:
            break
    if val:
        model.load_state_dict(best["model"])
        val_loss, val_logits = validate()
        require(abs(val_loss - best["log_loss"]) <= 2e-6, "Selected validation prediction changed")
        selected = best["epoch"]
    else:
        selected, val_loss, val_logits = current, None, np.empty(0)
    report = dict(schema="patrick_neural_fit_v1", arm=arm, seed=int(seed), selected_epoch=int(selected),
                  epochs_completed=int(current), selected_encoder_updated=arm != "raw_mlp" and selected > recipe["warmup_epochs"],
                  encoder_optimizer_steps=int(updates), validation_log_loss=val_loss,
                  validation_logits=val_logits.tolist(), validation_indices=val,
                  train_indices=train, contract_sha256=contract_sha, input_identity=runtime.identity_sha256,
                  seconds=time.monotonic() - start, test_labels_read=False,
                  prediction_schema="global770_mlp" if arm != "raw_mlp" else "raw3458_mlp",
                  loss="weighted_BCE_global_mean_normalization", esmc_updates=0,
                  cohort_intercepts="shared neural activity intercept; no study ID is an input",
                  selected_by="inner_BODE2_validation_log_loss" if val else "fixed_inner_selected_epoch_refit")
    if complete is not None:
        _save_torch(complete, dict(contract_sha256=contract_sha, state=_cpu_state(model), report=report))
        atomic_json(directory / "complete.json", report)
        if latest.exists():
            latest.unlink()
    return model, report


def fit_select(runtime, arm, train_indices, validation_indices, labels, sample_weights,
               seed, recipe=None, work_dir=None, deadline_monotonic=None, stop_requested=None):
    """Inner training/validation only. Returns selected epoch and validation logits."""
    model, report = _run(runtime, arm, train_indices, validation_indices, labels, sample_weights,
                         seed, recipe, work_dir=work_dir, deadline_monotonic=deadline_monotonic,
                         stop_requested=stop_requested)
    del model
    return report


def refit_predict(runtime, arm, train_indices, labels, sample_weights, seed, epochs,
                  predict_indices, output_checkpoint, recipe=None, work_dir=None,
                  deadline_monotonic=None, stop_requested=None):
    """Fresh selected-epoch refit; prediction indices must be disjoint from training.

    To write a full-data deployment model, use predict_indices=[]; the returned
    training fit is not a validation estimate.
    """
    train = _indices(train_indices, len(runtime.records), "training")
    predict = _indices(predict_indices, len(runtime.records), "prediction", allow_empty=True)
    require(not set(train) & set(predict), "Outer-training/test overlap")
    model, report = _run(runtime, arm, train, [], labels, sample_weights, seed, recipe, epochs=epochs,
                         work_dir=work_dir, deadline_monotonic=deadline_monotonic, stop_requested=stop_requested)
    logits = _predict(runtime, model, arm, predict, _recipe(recipe)["batch"])
    checkpoint = Path(output_checkpoint)
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    source = None if arm == "raw_mlp" else runtime._source(arm.split("_", 1)[0])
    payload = dict(schema="patrick_supervised_global_mlp_v1", arm=arm, model=_cpu_state(model),
                   encoder_config=None if source is None else source["config"],
                   head_input_dimension=int((model if arm == "raw_mlp" else model.activity_head)[0].normalized_shape[0]),
                   source_checkpoint_sha256=None if source is None else source["sha256"],
                   selected_epoch=epochs, seed=int(seed), input_identity=runtime.identity_sha256,
                   fit_report=report, score_interpretation="uncalibrated expected-product detection sigmoid",
                   compatibility_map_checkpoint="frozen SSL26, separate from this classifier")
    _save_torch(checkpoint, payload)
    restored = _torch().load(checkpoint, map_location=runtime.device, weights_only=False)
    model.load_state_dict(restored["model"])
    reloaded = _predict(runtime, model, arm, predict, _recipe(recipe)["batch"])
    require(np.array_equal(logits, reloaded), "Saved neural classifier reload changed logits")
    result = dict(report, prediction_indices=predict, logits=logits.tolist(),
                  checkpoint=str(checkpoint), checkpoint_sha256=sha(checkpoint), checkpoint_reload_exact=True)
    atomic_json(checkpoint.with_suffix(".json"), result)
    del model
    return result


class SavedClassifier:
    """Verified fitted classifier for new, already embedded complete assemblies.

    Inputs follow the original collate_records schema. The caller is responsible
    for validated mature-chain construction and the correct frozen ESM-C feature
    extraction. This helper neither builds hypothetical multi-swaps nor multiplies
    scores from individual swaps.
    """
    def __init__(self, checkpoint, expected_sha256, device="cuda"):
        torch = _torch()
        from vendor_neural.assembly_model import AssemblyEncoder, Config
        checkpoint = Path(checkpoint)
        require(isinstance(expected_sha256, str) and len(expected_sha256) == 64 and
                sha(checkpoint) == expected_sha256, "Saved classifier checksum mismatch")
        payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
        require(payload["schema"] == "patrick_supervised_global_mlp_v1" and payload["arm"] in ARMS,
                "Unrecognized supervised checkpoint schema")
        self.arm, self.device = payload["arm"], str(device)
        if self.arm == "raw_mlp":
            model = new_head(payload["head_input_dimension"], payload["seed"])
        else:
            model = AssemblyEncoder(Config(**payload["encoder_config"]))
            require(3 * model.cfg.width + 2 == payload["head_input_dimension"], "Neural readout dimension mismatch")
        model.load_state_dict(payload["model"], strict=True)
        self.model = model.to(device).eval().requires_grad_(False)
        self.manifest = {key: value for key, value in payload.items() if key != "model"}
        self.checkpoint_sha256 = expected_sha256

    def predict_batch(self, clean_batch):
        torch = _torch()
        required = {"x", "state", "kind", "domain_type", "chain", "valid"}
        require(set(clean_batch) == required, "Incomplete/extra clean assembly tensor fields")
        batch = {key: value.to(self.device) for key, value in clean_batch.items()}
        require(not bool((batch["state"] == 4).any()), "Activity inference requires a clean unmasked assembly")
        with torch.no_grad():
            logits = (self.model(raw_pool(batch)).squeeze(-1) if self.arm == "raw_mlp"
                      else self.model.activity(batch))
            require(bool(torch.isfinite(logits).all()), "Nonfinite saved classifier output")
            return dict(logits=logits.cpu().numpy().astype(np.float64),
                        probability=logits.double().sigmoid().cpu().numpy(),
                        interpretation="uncalibrated expected-product detection score")
