#!/usr/bin/env python3
"""Resumable, bounded one-GPU Patrick model/scorer comparison."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import time
import unittest
import zipfile

HERE = Path(__file__).resolve().parent
STOP = False


def stop_signal(signum, frame):
    global STOP
    STOP = True


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
    tmp.replace(path)


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def progress(out, stage, **kwargs):
    value = dict(stage=stage, updated_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), **kwargs)
    dump(out / 'progress.json', value)
    print(json.dumps(value), flush=True)


def check_deadline(deadline):
    from neural_backend import TrainingPaused
    if STOP or time.monotonic() >= deadline:
        raise TrainingPaused('Stopped at a resumable boundary before allocation end')


def package_check():
    from selftest import validate_package
    return validate_package()


def numerical_tests(out):
    modules = ['frozen_tests', 'map_tests', 'neural_tests', 'aggregate_tests', 'suite_tests']
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in modules)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    status = dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                  skipped=[str(x) for x in result.skipped], passed=result.wasSuccessful() and not result.skipped)
    dump(out / 'numerical_selftest.json', status)
    if not status['passed']:
        raise RuntimeError('Numerical self-tests must all pass without skips before real inference/training')


def prepare(runtime, rows, out, protocol):
    import numpy as np
    audit = runtime.overlap_audit
    dump(out / 'runtime_identity.json', runtime.identity)
    dump(out / 'auxiliary_overlap_audit.json', audit)
    protocol = dict(protocol)
    protocol['auxiliary_exclusions'] = audit['auxiliary_exclusions']
    protocol['auxiliary_exclusions_provenance'] = audit
    ids = [0, 161, 323, 324, 376, 428, 429, 461, 493]
    observed = runtime.typed_features(ids)
    with np.load(HERE / 'inputs/features.npz', allow_pickle=False) as bundle:
        expected = bundle['typed'][ids]
    delta = np.abs(observed.astype(np.float64) - expected.astype(np.float64))
    maximum = float(delta.max())
    tolerance = protocol['runtime']['typed_parity_absolute_tolerance']
    parity = dict(indices=ids, assembly_ids=[rows[i]['assembly_id'] for i in ids],
                  max_absolute_difference=maximum, tolerance=tolerance,
                  passed=bool(np.isfinite(observed).all() and maximum <= tolerance),
                  scope='Deterministic three-row sample per dataset, not exhaustive parity')
    dump(out / 'typed_feature_parity.json', parity)
    if not parity['passed']:
        raise RuntimeError('Live SSL26 typed features differ from bundled frozen inputs; inspect typed_feature_parity.json')
    runtime.export_bode2_records(out / 'bode2_structural_handoff.json.gz')
    dump(out / 'resolved_protocol.json', protocol)
    return protocol


def neural_fold(runtime, rows, protocol, out, fold_number, deadline):
    import numpy as np
    from scipy.special import expit
    import frozen_test as frozen
    import neural_backend as neural
    cfg = frozen.settings(protocol)
    fold = load(out / 'frozen' / 'folds' / f'typed__fold{fold_number:02d}.json')
    if 'record' in fold:
        fold = fold['record']
    target_split = frozen.make_splits(rows, n_splits=5, seed=cfg['seed'])[fold_number]
    if fold['test_indices'] != target_split['test_indices']:
        raise RuntimeError('Frozen/neural target folds differ')
    destination = out / 'neural' / fold['fold']
    destination.mkdir(parents=True, exist_ok=True)
    ready = destination / 'predictions.json'
    identity = dict(frozen_fold_sha256=sha(out / 'frozen' / 'folds' / f'typed__fold{fold_number:02d}.json'),
                    runtime=runtime.identity_sha256, protocol_sha256=sha(out / 'resolved_protocol.json'),
                    driver_sha256=sha(__file__))
    if ready.exists():
        saved = load(ready)
        if saved['identity'] != identity:
            raise RuntimeError('Completed neural fold belongs to a different request')
        seal = destination / 'prediction_seal.json'
        if seal.exists() and load(seal)['sha256'] != sha(ready):
            raise RuntimeError('Completed neural prediction seal changed')
        if not seal.exists():
            dump(seal, dict(sha256=sha(ready), contains_activity_labels=False,
                n=len(fold['test_indices']), seed_aggregation='equal mean probabilities'))
        return
    inner = fold['inner_splits'][0]
    labels = np.array([r['observed_activity'] for r in rows], dtype=int)
    with np.load(HERE / 'inputs/features.npz', allow_pickle=False) as bundle:
        feature_hashes = [hashlib.sha256(np.asarray(x,dtype='<f8').tobytes()).hexdigest() for x in bundle['typed']]
    prediction = dict(fold=fold['fold'], test_indices=fold['test_indices'],
                      test_assembly_ids=[rows[i]['assembly_id'] for i in fold['test_indices']],
                      identity=identity, models={})
    for arm in protocol['neural']['arms']:
        for procedure in protocol['neural']['procedures']:
            choice = fold['procedures'][procedure]['selected']
            alpha, beta = choice['alpha'], choice['beta']
            held_groups = list(fold['test_groups']) + list(inner['test_groups'])
            held_indices = list(fold['test_indices']) + list(inner['test_indices'])
            excluded = frozen.auxiliary_purge(rows, held_groups, cfg, feature_hashes, held_indices)
            inner_train = frozen.training_indices(rows, inner['train_indices'], alpha, beta, excluded)
            outer_train = fold['procedures'][procedure]['train_indices']
            weights_inner = frozen.cohort_weights(rows, inner_train, alpha, beta)
            weights_outer = frozen.cohort_weights(rows, outer_train, alpha, beta)
            key = arm + '__' + procedure
            seed_results = []
            for seed in protocol['neural']['seeds']:
                check_deadline(deadline)
                progress(out, 'neural_outer_fit', fold=fold['fold'], arm=arm, procedure=procedure, seed=seed)
                work = destination / key / f'seed{seed}'
                selected = neural.fit_select(runtime, arm, inner_train, inner['test_indices'], labels,
                    weights_inner, seed, recipe=protocol['neural']['recipe'], work_dir=work / 'select',
                    deadline_monotonic=deadline, stop_requested=lambda: STOP)
                check_deadline(deadline)
                result = neural.refit_predict(runtime, arm, outer_train, labels, weights_outer, seed,
                    selected['selected_epoch'], fold['test_indices'], work / 'checkpoint.pt',
                    recipe=protocol['neural']['recipe'], work_dir=work / 'refit',
                    deadline_monotonic=deadline, stop_requested=lambda: STOP)
                seed_results.append(dict(seed=seed, logits=result['logits'],
                    selected_epoch=selected['selected_epoch'], checkpoint=result['checkpoint'],
                    checkpoint_sha256=result['checkpoint_sha256'],
                    train_indices=outer_train, selection_train_indices=inner_train,
                    selection_validation_indices=inner['test_indices']))
            probabilities = np.mean([expit(np.array(s['logits'])) for s in seed_results], axis=0)
            prediction['models'][key] = dict(probability=probabilities.tolist(), seed_results=seed_results,
                    selected_source_weights={'alpha':alpha, 'beta':beta},
                    source_choice='Frozen typed inner selection on this outer TRAIN partition')
    dump(ready, prediction)
    dump(destination / 'prediction_seal.json', dict(sha256=sha(ready), contains_activity_labels=False,
        n=len(fold['test_indices']), seed_aggregation='equal mean probabilities'))
    # Once the whole fold is sealed, only its final classifiers are needed.
    # Delete duplicate tensors generated by this runner, preserving reports.
    for arm in protocol['neural']['arms']:
        for procedure in protocol['neural']['procedures']:
            for seed in protocol['neural']['seeds']:
                for phase in ('select','refit'):
                    duplicate = destination / (arm+'__'+procedure) / f'seed{seed}' / phase / 'complete.pt'
                    if duplicate.is_file():
                        duplicate.unlink()


def deploy(runtime, rows, protocol, out, selection, deadline):
    import numpy as np
    import frozen_test as frozen
    import neural_backend as neural
    cfg = frozen.settings(protocol)
    labels = np.array([r['observed_activity'] for r in rows], dtype=int)
    with np.load(HERE / 'inputs/features.npz', allow_pickle=False) as bundle:
        feature_hashes = [hashlib.sha256(np.asarray(x,dtype='<f8').tobytes()).hexdigest() for x in bundle['typed']]
    dest = out / 'deployment'
    dest.mkdir(exist_ok=True)
    components = []
    for component in selection['components']:
        if component['kind'] == 'frozen':
            arm, procedure = component['feature_arm'], component['procedure']
            path = out / 'frozen/deployment' / f'{arm}__{procedure}.npz'
            metadata = load(path.with_suffix('.json'))
            components.append(dict(component, model=str(path), model_sha256=sha(path),
                                   training=metadata, apply_study_intercept='bode2'))
            continue
        arm, procedure = component['arm'], component['procedure']
        base = load(out / 'frozen/deployment' / f'typed__{procedure}.json')
        selected = base['selected']
        alpha, beta = selected['alpha'], selected['beta']
        inner = base['inner_splits'][0]
        exclude = frozen.auxiliary_purge(rows, inner['test_groups'], cfg, feature_hashes, inner['test_indices'])
        inner_train = frozen.training_indices(rows, inner['train_indices'], alpha, beta, exclude)
        outer_train = base['train_indices']
        models = []
        for seed in protocol['neural']['seeds']:
            check_deadline(deadline)
            progress(out, 'final_candidate_fit', arm=arm, procedure=procedure, seed=seed)
            work = dest / (arm + '__' + procedure) / f'seed{seed}'
            fit = neural.fit_select(runtime, arm, inner_train, inner['test_indices'], labels,
                frozen.cohort_weights(rows, inner_train, alpha, beta), seed,
                recipe=protocol['neural']['recipe'], work_dir=work / 'select',
                deadline_monotonic=deadline, stop_requested=lambda: STOP)
            result = neural.refit_predict(runtime, arm, outer_train, labels,
                frozen.cohort_weights(rows, outer_train, alpha, beta), seed, fit['selected_epoch'], [],
                work / 'checkpoint.pt', recipe=protocol['neural']['recipe'], work_dir=work / 'refit',
                deadline_monotonic=deadline, stop_requested=lambda: STOP)
            models.append(dict(seed=seed, path=result['checkpoint'], sha256=result['checkpoint_sha256'],
                epochs=fit['selected_epoch']))
        components.append(dict(component, models=models, seed_aggregation='mean probability',
                               source_weights={'alpha':alpha,'beta':beta}, training_rows=len(outer_train)))
    from map_audit import MAP_CONTRACT
    manifest = dict(schema='patrick_candidate_score_and_map_v1', selection=selection,
        components=components, component_combination='weighted mean of component probabilities',
        compatibility_map=MAP_CONTRACT,
        map_checkpoint_sha256='9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f',
        output_direction='higher score predicts stronger expected-product detection',
        activity_threshold=None, probability_calibration='not established for multi-exchange candidates',
        status='SINGLES_DEVELOPMENT_COMPLETE_MULTIEXCHANGE_INPUTS_PENDING',
        next_gate=protocol['multi_exchange_gate'], runtime_identity=runtime.identity_sha256,
        protocol_sha256=sha(out / 'resolved_protocol.json'), package_sha256=sha(HERE / 'PACKAGE_MANIFEST.json'))
    dump(dest / 'SCORE_VERSION.json', manifest)
    return manifest


def inspection(out):
    """Small review bundle: keep large training tensors/checkpoints on Jean Zay."""
    destination = out / 'inspection.zip'
    temp = out / 'inspection.zip.tmp'
    paths = []
    for p in sorted(out.rglob('*')):
        if not p.is_file() or p in (destination, temp) or p.name.endswith('.tmp'):
            continue
        if p.suffix not in ('.json', '.txt', '.csv', '.gz', '.npz'):
            continue
        if p.stat().st_size > 12 * 1024 * 1024:
            continue
        paths.append(p)
    with zipfile.ZipFile(temp, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in paths:
            z.write(p, p.relative_to(out).as_posix())
        for p in sorted(HERE.rglob('*')):
            if p.is_file() and p.suffix in ('.py', '.sh', '.json', '.txt') and '__pycache__' not in p.parts and not p.name.startswith(('SUBMISSION', 'REQUEST')):
                z.write(p, 'reproduce/' + p.relative_to(HERE).as_posix())
    temp.replace(destination)
    print('RESULT_ZIP:', destination, flush=True)
    print('RESULT_SHA256:', sha(destination), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--seconds', type=int, default=6840)
    args = parser.parse_args()
    root, out = args.project_root.resolve(), args.output_dir.resolve()
    if root == out or root in out.parents and out.name in ('inputs','models'):
        raise ValueError('Choose an isolated result directory')
    out.mkdir(parents=True, exist_ok=True)
    import fcntl
    lock = (out / '.run.lock').open('a')
    fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    signal.signal(signal.SIGUSR1, stop_signal)
    signal.signal(signal.SIGTERM, stop_signal)
    deadline = time.monotonic() + args.seconds
    try:
        package_check()
        request_identity = dict(package_sha256=sha(HERE / 'PACKAGE_MANIFEST.json'), project_root=str(root))
        request_path = out / 'run_identity.json'
        if request_path.exists() and load(request_path) != request_identity:
            raise RuntimeError('Result directory belongs to a different package/project')
        dump(request_path, request_identity)
        if (out / 'COMPLETE.json').exists():
            print('Already complete:', out, flush=True)
            inspection(out)
            return
        progress(out, 'numerical_tests')
        numerical_tests(out)
        import torch
        if not torch.cuda.is_available():
            raise RuntimeError('This suite requires its requested GPU allocation')
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        protocol = load(HERE / 'PROTOCOL.json')
        rows = load(HERE / 'inputs/metadata.json')['rows']
        from neural_backend import NeuralRuntime, TrainingPaused
        progress(out, 'verify_live_inputs')
        runtime = NeuralRuntime(root, rows, device='cuda', threads=protocol['runtime']['threads'])
        protocol = prepare(runtime, rows, out, protocol)
        check_deadline(deadline)
        progress(out, 'frozen_physical_maps')
        import map_audit
        map_audit.run(root, out / 'maps', device='cuda', threads=4, microbatch=8)
        check_deadline(deadline)
        progress(out, 'nested_frozen_classifier_comparison')
        import frozen_test
        frozen_test.run_frozen(HERE / 'inputs', out / 'frozen', protocol)
        for k in range(protocol['frozen']['outer_folds']):
            check_deadline(deadline)
            neural_fold(runtime, rows, protocol, out, k, deadline)
        progress(out, 'candidate_selection')
        from aggregate import aggregate_results
        selected = aggregate_results(out, rows, protocol)
        manifest = deploy(runtime, rows, protocol, out, selected, deadline)
        dump(out / 'COMPLETE.json', dict(status=manifest['status'],
            score_version_sha256=sha(out / 'deployment/SCORE_VERSION.json'),
            candidate=selected['candidate'], prospective_validation=False))
        for old in ('PAUSED.json','fatal_error.json'):
            if (out / old).exists():
                (out / old).unlink()
        progress(out, 'COMPLETE', candidate=selected['candidate'], status=manifest['status'])
    except Exception as exc:
        from neural_backend import TrainingPaused
        if isinstance(exc, TrainingPaused):
            dump(out / 'PAUSED.json', dict(reason=str(exc), action='python3 -B submit.py resume',
                completed_work_preserved=True))
            print('PAUSED: resume will keep completed fits and continue saved training state', flush=True)
        else:
            import traceback
            dump(out / 'fatal_error.json', dict(type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc()))
            raise
    finally:
        inspection(out)


if __name__ == '__main__':
    main()
