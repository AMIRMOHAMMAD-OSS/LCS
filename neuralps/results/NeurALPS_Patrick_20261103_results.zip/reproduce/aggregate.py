"""Compare sealed Patrick-development predictions and choose a conservative candidate.

Selection remains retrospective single-exchange development. Fixed-prediction
bootstrap intervals omit model refitting, adaptive research and multiplicity.
No result in this module validates the 42,875 prospective triple exchanges.
"""
from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.special import expit

from frozen_test import evaluate_records, make_splits, metrics


DEFAULT_RULE = {
    "minimum_log_loss_improvement": .01,
    "maximum_conditional_auc_drop": .02,
    "log_loss_tie_tolerance": .001,
    "bootstrap_draws": 2000,
    "bootstrap_seed": 20266203,
}
NEURAL_ARMS = ("raw_mlp", "ssl10_finetune", "ssl26_finetune")
PROCEDURES = ("bode2_only", "inner_selected_pool")
SEEDS = (17, 29, 43)
BASELINE = "typed__bode2_only"


def require(value, message):
    if not value:
        raise ValueError(message)


def read_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    tmp.replace(path)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def valid_probabilities(values, length, context):
    result = np.asarray(values, dtype=float)
    require(result.shape == (length,) and np.isfinite(result).all() and
            np.all((result >= 0) & (result <= 1)), "Invalid probabilities: " + context)
    return result


def no_labels(value):
    if isinstance(value, dict):
        require(not set(value) & {"label", "labels", "observed_activity", "test_labels"},
                "Neural prediction file includes phenotype labels")
        for child in value.values():
            no_labels(child)
    elif isinstance(value, list):
        for child in value:
            no_labels(child)


def expected_splits(rows, protocol):
    cfg = protocol.get("frozen", {})
    splits = make_splits(rows, n_splits=int(cfg.get("outer_folds", 5)),
                         seed=int(cfg.get("seed", 20261103)))
    require(len(splits) == 5, "Final comparison requires all five outer folds")
    target = sorted(i for i, r in enumerate(rows) if r["dataset"] == "bode2")
    require(len(target) == 105 and len({rows[i]["group"] for i in target}) == 35,
            "Final comparison requires 105 engineered rows and 35 donors")
    require(set(collections.Counter(rows[i]["group"] for i in target).values()) == {3},
            "Each donor must have three placements")
    require(len({rows[i]["assembly_id"] for i in target}) == 105, "Duplicate target assembly ID")
    require(all(rows[i]["observed_activity"] in (0, 1) for i in target), "Invalid target label")
    require(sorted(i for split in splits for i in split["test_indices"]) == target,
            "Outer split coverage differs")
    return target, {s["fold"]: s for s in splits}


def load_frozen(output, rows, target, splits):
    path = output / "frozen/heldout_predictions.json"
    saved = read_json(path)
    sealed_path = output / "frozen/predictions_sealed.json"
    seal = read_json(output / "frozen/prediction_seal.json")
    require(sha(sealed_path) == seal["predictions_sha256"], "Frozen prediction seal mismatch")
    sealed = {}
    for fold in read_json(sealed_path):
        for procedure, result in fold["procedures"].items():
            require(len(result["probability"]) == len(fold["test_indices"]) == len(result["logits"]),
                    "Frozen sealed prediction lengths differ")
            for j, i in enumerate(fold["test_indices"]):
                key = (fold["feature_arm"], procedure, i)
                require(key not in sealed, "Duplicate frozen sealed prediction")
                sealed[key] = (fold["fold"], result["probability"][j], result["logits"][j])
    groups = collections.defaultdict(list)
    for r in saved:
        i = r["index"]
        require(type(i) is int and i in target, "Frozen prediction has an unexpected row")
        require(r["assembly_id"] == rows[i]["assembly_id"] and r["group"] == str(rows[i]["group"]),
                "Frozen prediction identity mismatch")
        require(r["position"] == rows[i]["metadata"]["position"], "Frozen position mismatch")
        require(r["label"] == rows[i]["observed_activity"], "Frozen evaluation label mismatch")
        require(r["fold"] in splits and i in splits[r["fold"]]["test_indices"],
                "Frozen prediction uses a different outer split")
        key = (r["feature_arm"], r["procedure"], i)
        require(key in sealed and sealed[key] == (r["fold"], r["probability"], r["logit"]),
                "Frozen evaluated predictions differ from sealed predictions")
        groups[(r["feature_arm"], r["procedure"])].append(r)
    require(len(saved) == len(sealed), "Frozen sealed/evaluated prediction coverage differs")
    candidates = {}
    partial_diagnostics = []
    for (arm, procedure), records in sorted(groups.items()):
        seen = [r['index'] for r in records]
        require(len(seen)==len(set(seen)), 'Duplicate frozen prediction')
        if sorted(seen) != target and procedure not in PROCEDURES:
            partial_diagnostics.append(dict(feature_arm=arm,procedure=procedure,
                observed_rows=len(seen),expected_rows=len(target),
                reason='Auxiliary pool unavailable in one or more purged folds; excluded from matched comparison'))
            continue
        require(sorted(r["index"] for r in records) == target, "Incomplete or duplicate frozen predictions")
        by_index = {r["index"]: r for r in records}
        p = valid_probabilities([by_index[i]["probability"] for i in target], len(target), arm + procedure)
        require(all(np.isfinite(by_index[i]["logit"]) for i in target), "Nonfinite frozen logits")
        require(np.allclose(p, expit([by_index[i]["logit"] for i in target]), atol=1e-10, rtol=1e-10),
                "Frozen probability/logit mismatch")
        name = arm + "__" + procedure
        candidates[name] = dict(name=name, kind="frozen", probabilities=p,
                               eligible=procedure in PROCEDURES,
                               components=[dict(kind="frozen", feature_arm=arm,
                                                procedure=procedure, weight=1.0)])
    require(BASELINE in candidates, "Default typed BODE2-only predictions missing")
    write_json(output/'partial_pool_diagnostics.json', partial_diagnostics)
    return candidates


def load_neural(output, target, splits):
    names = {arm + "__" + procedure for arm in NEURAL_ARMS for procedure in PROCEDURES}
    by_model = {name: {} for name in names}
    for fold, split in sorted(splits.items()):
        path = output / "neural" / fold / "predictions.json"
        require(path.is_file(), "Neural fold is incomplete: " + fold)
        seal_path = path.with_name("prediction_seal.json")
        require(seal_path.is_file(), "Neural fold prediction seal is missing: " + fold)
        seal = read_json(seal_path)
        require(seal["sha256"] == sha(path), "Neural prediction seal mismatch: " + fold)
        require(seal["contains_activity_labels"] is False, "Neural prediction seal allows phenotype labels")
        record = read_json(path)
        no_labels(record)
        require(record["fold"] == fold and record["test_indices"] == split["test_indices"],
                "Neural fold indices are not aligned with the frozen comparison")
        require(set(record["models"]) == names, "Missing or unexpected neural candidate")
        for name, result in record["models"].items():
            p = valid_probabilities(result["probability"], len(split["test_indices"]), name + fold)
            seed_results = result["seed_results"]
            require(isinstance(seed_results, list) and len(seed_results) == len(SEEDS),
                    "Neural candidate must include exactly three prespecified seeds")
            require(sorted(r["seed"] for r in seed_results) == list(SEEDS), "Neural seed set differs")
            logits = np.asarray([r["logits"] for r in seed_results], dtype=float)
            require(logits.shape == (len(SEEDS), len(p)) and np.isfinite(logits).all(),
                    "Missing/nonfinite per-seed neural logits")
            require(np.allclose(p, expit(logits).mean(axis=0), atol=5e-7, rtol=0),
                    "Neural score must average seed probabilities, not select a seed or average logits")
            for i, value in zip(split["test_indices"], p):
                require(i not in by_model[name], "Duplicate neural prediction")
                by_model[name][i] = float(value)
    candidates = {}
    for name, indexed in sorted(by_model.items()):
        require(sorted(indexed) == target, "Incomplete neural prediction coverage")
        arm, procedure = name.split("__", 1)
        candidates[name] = dict(name=name, kind="neural", eligible=True,
                               probabilities=np.array([indexed[i] for i in target]),
                               components=[dict(kind="neural", arm=arm,
                                                procedure=procedure, weight=1.0)])
    return candidates


def add_fixed_blends(candidates):
    """Four predeclared 50:50 probability blends; no fitted mixture weights."""
    for arm in ("ssl10_finetune", "ssl26_finetune"):
        for procedure in PROCEDURES:
            left = candidates["typed__" + procedure]
            right = candidates[arm + "__" + procedure]
            name = "blend__typed__" + arm + "__" + procedure
            candidates[name] = dict(name=name, kind="blend", eligible=True,
                probabilities=.5 * left["probabilities"] + .5 * right["probabilities"],
                components=[{**left["components"][0], "weight": .5},
                            {**right["components"][0], "weight": .5}])


def summarize_candidate(candidate, rows, target, splits):
    lookup = dict(zip(target, candidate["probabilities"]))
    records = []
    for fold, split in sorted(splits.items()):
        p = np.array([lookup[i] for i in split["test_indices"]])
        q = np.clip(p, 1e-12, 1-1e-12)
        records.append({**split, "feature_arm": candidate["name"],
            "procedures": {"candidate": {"probability": p.tolist(),
                                          "logits": np.log(q/(1-q)).tolist()}}})
    _, evaluated = evaluate_records(rows, records)
    summary = evaluated[0]
    return dict(name=candidate["name"], kind=candidate["kind"], eligible=candidate["eligible"],
                components=candidate["components"], **summary["pooled_metrics"],
                same_fold_position_macro_auroc=summary["same_fold_position_macro_auroc"],
                same_fold_position_auc=summary["same_fold_position_auc"],
                conditional_auc_complete=summary["conditional_auc_complete"],
                same_fold_position_metrics=summary["same_fold_position_metrics"],
                fold_metrics=summary["fold_metrics"])


def paired_intervals(candidates, rows, target, rule):
    y = np.array([rows[i]["observed_activity"] for i in target], dtype=float)
    donors = sorted({str(rows[i]["group"]) for i in target})
    group_indices = [[j for j, i in enumerate(target) if str(rows[i]["group"]) == donor]
                     for donor in donors]
    rng = np.random.default_rng(int(rule["bootstrap_seed"]))
    samples = rng.integers(0, len(donors), size=(int(rule["bootstrap_draws"]), len(donors)))
    baseline = np.clip(candidates[BASELINE]["probabilities"], 1e-12, 1-1e-12)
    reference_ll = -y*np.log(baseline) - (1-y)*np.log1p(-baseline)
    reference_brier = (baseline-y)**2
    output = {}
    for name, candidate in sorted(candidates.items()):
        p = np.clip(candidate["probabilities"], 1e-12, 1-1e-12)
        deltas = {"log_loss": -y*np.log(p)-(1-y)*np.log1p(-p)-reference_ll,
                  "brier": (p-y)**2-reference_brier}
        item = {}
        for metric, delta in deltas.items():
            grouped = np.array([delta[jj].mean() for jj in group_indices])
            distribution = grouped[samples].mean(axis=1)
            item[metric] = dict(difference=float(delta.mean()),
                                ci95=np.quantile(distribution, [.025, .975]).tolist())
        output[name] = dict(reference=BASELINE, challenger=name, contrasts=item,
            independent_units=len(donors), draws=int(rule["bootstrap_draws"]),
            description="Paired donor bootstrap conditional on fixed held-out predictions; no refitting, multiplicity correction or independent confirmation")
    return output


def complexity_key(summary):
    kind = {"frozen": 0, "neural": 1, "blend": 2}[summary["kind"]]
    return kind, len(summary["components"]), summary["name"]


def choose_candidate(summaries, intervals, rule):
    reference = summaries[BASELINE]
    require(reference["same_fold_position_macro_auroc"] is not None,
            "Default conditional ranking metric is undefined")
    qualified, decisions = [], {}
    for name, result in summaries.items():
        if name == BASELINE:
            continue
        delta = intervals[name]["contrasts"]["log_loss"]
        checks = {
            "declared_deployable_candidate": bool(result["eligible"]),
            "log_loss_improves_at_least_threshold":
                result["log_loss"] <= reference["log_loss"] - rule["minimum_log_loss_improvement"],
            "conditional_auc_within_tolerance":
                result["same_fold_position_macro_auroc"] is not None and
                result["same_fold_position_macro_auroc"] >= reference["same_fold_position_macro_auroc"] - rule["maximum_conditional_auc_drop"],
            "fixed_prediction_delta_log_loss_ci_upper_below_zero": delta["ci95"][1] < 0,
        }
        decisions[name] = dict(checks=checks, passes=all(checks.values()))
        if all(checks.values()):
            qualified.append(result)
    if qualified:
        best_loss = min(x["log_loss"] for x in qualified)
        tied = [x for x in qualified if x["log_loss"] <= best_loss + rule["log_loss_tie_tolerance"]]
        selected = min(tied, key=complexity_key)
        reason = "Challenger passed prespecified development gates; within 0.001 log loss prefer simpler family"
    else:
        selected = reference
        reason = "No challenger passed all prespecified development gates; retain frozen typed BODE2-only default"
    return selected, decisions, reason


def validate_map(output):
    summary_path = output / "maps/summary.json"
    complete_path = output / "maps/COMPLETE.json"
    require(summary_path.is_file() and complete_path.is_file(), "Frozen compatibility-map audit is incomplete")
    summary, complete = read_json(summary_path), read_json(complete_path)
    require(summary["status"] == "MAP_AUDIT_COMPLETE" and complete["status"] == "MAP_AUDIT_COMPLETE",
            "Map audit completion state differs")
    contract = summary["score_contract"]
    require(contract["primary_path"] == "full" and contract["diagnostic_path"] == "local",
            "Map contract must retain training-consistent full path and separate local diagnostic")
    require(summary["assemblies"] == 105 and summary["joint_parity_checked"] == 105,
            "Map audit target/parity coverage is incomplete")
    require(summary["joint_parity_maximum_absolute_error"] <= 1e-5 and
            summary["map_definition_selected_from_activity_labels"] is False,
            "Map parity/selection contract failed")
    return dict(contract=contract, all_objects_scored=summary["all_objects_scored"],
                object_status_counts=summary["object_status_counts"],
                joint_parity_maximum_absolute_error=summary["joint_parity_maximum_absolute_error"],
                summary_sha256=sha(summary_path), completion_sha256=sha(complete_path),
                interpretation="Frozen natural compatibility diagnostic; not an explanation of a fine-tuned classifier or a local failure probability")


def aggregate_results(output_dir, rows, protocol):
    output = Path(output_dir)
    rule = dict(DEFAULT_RULE)
    rule.update(protocol.get("selection", {}))
    require(rule["minimum_log_loss_improvement"] == .01 and rule["maximum_conditional_auc_drop"] == .02 and
            rule["log_loss_tie_tolerance"] == .001, "Selection thresholds differ from the declared package rule")
    require(int(rule["bootstrap_draws"]) >= 1000, "Use at least 1,000 descriptive donor resamples")
    target, splits = expected_splits(rows, protocol)
    stored_splits = read_json(output / "frozen/outer_splits.json")
    require(stored_splits == list(splits.values()), "Saved outer splits differ from protocol")
    candidates = load_frozen(output, rows, target, splits)
    candidates.update(load_neural(output, target, splits))
    add_fixed_blends(candidates)
    summaries = {name: summarize_candidate(c, rows, target, splits) for name, c in candidates.items()}
    # Independent re-aggregation must reproduce the frozen runner's saved metrics.
    prior = read_json(output / "frozen/summary.json")
    for summary in prior:
        name = summary["feature_arm"] + "__" + summary["procedure"]
        if name not in summaries and summary['procedure'] not in PROCEDURES:
            continue
        require(name in summaries, "Missing saved frozen summary candidate")
        for key in ("log_loss", "brier", "auroc", "average_precision"):
            require(abs(summary["pooled_metrics"][key] - summaries[name][key]) < 1e-10,
                    "Frozen metric replay mismatch: " + name + ":" + key)
        a, b = summary["same_fold_position_macro_auroc"], summaries[name]["same_fold_position_macro_auroc"]
        require((a is None and b is None) or (a is not None and b is not None and abs(a-b) < 1e-10),
                "Frozen conditional ranking replay mismatch")
    intervals = paired_intervals(candidates, rows, target, rule)
    selected, gates, reason = choose_candidate(summaries, intervals, rule)
    map_result = validate_map(output)
    selection = dict(status="DEVELOPMENT_CANDIDATE_SELECTED_MULTIEXCHANGE_PENDING",
        candidate=selected["name"], kind=selected["kind"], components=selected["components"],
        reason=reason, rule=rule, comparison_reference=BASELINE, candidate_metrics=selected,
        gates=gates, map=map_result, final_triple_library_winner=False,
        eligible_labelled_single_exchanges=105, donor_groups=35,
        selection_uses_outer_development_outcomes=True,
        inference_limit="Candidate chosen after retrospective development comparison; selection bootstrap is descriptive, not an unbiased performance guarantee",
        next_requirement="Reconstruct and verify full double/triple constructs, evaluate existing multi-exchange outcomes, then lock prospective candidate manifest before Patrick's new assays")
    write_json(output / "comparison.json", summaries)
    write_json(output / "paired_differences.json", intervals)
    write_json(output / "selection.json", selection)
    fields = ["name", "kind", "eligible", "auroc", "same_fold_position_macro_auroc", "conditional_auc_complete",
              "average_precision", "log_loss", "brier", "precision_top20_tie_expected"]
    with (output / "comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for name in sorted(summaries, key=lambda n: (summaries[n]["log_loss"], n)):
            writer.writerow({key: summaries[name][key] for key in fields})
    lines = ["NeurALPS Patrick development comparison", "", "Selected candidate: " + selected["name"],
        "Status: DEVELOPMENT_CANDIDATE_SELECTED_MULTIEXCHANGE_PENDING", reason, "",
        "105 single-exchange constructs; 35 donor groups; 5 outer donor-group folds.",
        "Neural predictions average seeds 17/29/43 probabilities. Blends are prespecified 50:50 probability means.",
        "No independent confirmation is claimed: datasets and previous model comparisons informed development.",
        "Fixed-prediction donor-bootstrap intervals omit refitting and multiplicity. The conservative gate is a decision rule, not a significance claim.", "",
        "Candidate | pooled AUROC | same-fold position AUROC | logloss | Brier"]
    for name in sorted(summaries, key=lambda n: (summaries[n]["log_loss"], n)):
        r = summaries[name]
        conditional = "undefined" if r["same_fold_position_macro_auroc"] is None else f'{r["same_fold_position_macro_auroc"]:.4f}'
        lines.append(f'{name} | {r["auroc"]:.4f} | {conditional} | {r["log_loss"]:.4f} | {r["brier"]:.4f}')
    lines += ["", "COMPATIBILITY MAP", "Frozen SSL26 full path is primary; global-bypass local path is diagnostic.",
        "Each physical domain or boundary is masked with overlap/alias closure. Protein-break roles count as one boundary.",
        "Map definition was not selected from assembly activity labels. It is not a domain-failure probability or a decomposition of the supervised activity score.",
        "Unsupported objects remain explicit. All objects scored: " + str(map_result["all_objects_scored"]), "",
        "PATRICK SCOPE", "These single-exchange results do not validate new triple combinations or precision among the top 50 of 42,875.",
        "Existing 33 doubles and 27 triples require verified full-construct representations before that comparison.",
        "Full-data refits are deployment candidates; their training scores must never be reported as validation."]
    (output / "REPORT.txt").write_text("\n".join(lines) + "\n")
    return selection


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    args = parser.parse_args()
    result = aggregate_results(args.output_dir, read_json(args.metadata)["rows"], read_json(args.protocol))
    print(json.dumps({k: result[k] for k in ("status", "candidate", "kind")}, indent=2))
