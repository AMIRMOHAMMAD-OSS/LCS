#!/usr/bin/env python3
"""Fast CPU neural contract tests; --require-torch is mandatory on Jean Zay."""
import argparse
import importlib.util
import json
from pathlib import Path
import tempfile
import time
import unittest

import numpy as np

import neural_backend as backend

HAS_TORCH = importlib.util.find_spec("torch") is not None
if HAS_TORCH:
    import torch
    from vendor_neural.assembly_model import AssemblyEncoder, Config


class PlainContracts(unittest.TestCase):
    def test_cohort_weight_normalization(self):
        # Four target rows total mass1, eight auxiliary rows total mass.25.
        weights = backend.normalize_weights([.25] * 4 + [.25 / 8] * 8, 12)
        self.assertAlmostEqual(weights.mean(), 1.)
        self.assertAlmostEqual(weights[:4].sum() / weights[4:].sum(), 4.)

    def test_weight_errors_fail_closed(self):
        for weights in ([1., 0.], [1., float("nan")], [1.], [-1., 2.]):
            with self.assertRaises(ValueError):
                backend.normalize_weights(weights, 2)

    def test_neural_encoder_is_original_source(self):
        proof = json.loads((Path(__file__).parent / "vendor_neural/SOURCE_PROVENANCE.json").read_text())
        path = Path(__file__).parent / "vendor_neural/assembly_model.py"
        self.assertEqual(backend.sha(path), proof["assembly_model.py"]["sha256"])
        self.assertEqual(backend.sha(path), "551772090b00a9bf0d5a44fa85a4014e103079c4dabd1f2b99259ed5441dd2f4")

    def test_verified_bode2_primary_targets(self):
        proof = json.loads((Path(__file__).parent / "vendor_neural/bode2_target_objects.json").read_text())
        self.assertEqual(len(proof["targets"]), 105)
        self.assertTrue(all(len(x) >= 5 for x in proof["targets"].values()))


if HAS_TORCH:
    class TinyRuntime:
        """Exercises production optimizer/fitting without any live data assets."""
        def __init__(self):
            torch.set_num_threads(1)
            self.device = "cpu"
            self.records = [{} for _ in range(8)]
            self.identity_sha256 = "synthetic-label-free-v1"
            generator = torch.Generator().manual_seed(77)
            self.x = torch.randn(8, 4, generator=generator)
            self.cfg = Config(feature_dim=4, width=8, heads=2, local_layers=1,
                              global_layers=1, global_slots=2, vocabulary_size=5, dropout=0.)
            torch.manual_seed(78)
            self.source_model = backend._cpu_state(AssemblyEncoder(self.cfg))
            self._batch = dict(x=torch.randn(8, 3, 3, 4, generator=generator),
                              state=torch.tensor([[[1, 0, 0], [1, 0, 0], [1, 0, 0]]] * 8),
                              kind=torch.tensor([[0, 1, 0]] * 8),
                              domain_type=torch.tensor([[1, 0, 2]] * 8),
                              chain=torch.ones(8, 3, dtype=torch.long),
                              valid=torch.ones(8, 3, dtype=torch.bool))

        def build(self, arm, seed):
            if arm == "raw_mlp":
                return backend.new_head(4, seed)
            model = AssemblyEncoder(self.cfg)
            model.load_state_dict(self.source_model)
            model.activity_head = backend.new_head(26, seed)
            return model

        def logits(self, model, arm, indices):
            if arm == "raw_mlp":
                return model(self.x[indices]).squeeze(-1)
            return model.activity({k: v[indices] for k, v in self._batch.items()})

        def _source(self, name):
            return dict(config=vars(self.cfg), sha256="synthetic-source")


@unittest.skipUnless(HAS_TORCH, "torch unavailable locally; must pass with --require-torch on Jean Zay")
class TensorContracts(unittest.TestCase):
    def setUp(self):
        self.runtime = TinyRuntime()
        self.labels = np.asarray([0, 1, 0, 1, 0, 1, 0, 1])
        self.recipe = dict(batch=4, warmup_epochs=1, tuning_epochs=2, patience=2,
                           checkpoint_every_epochs=1)

    def test_hidden_raw_slots_do_not_affect_raw_pooling(self):
        b = {k: v.clone() for k, v in self.runtime._batch.items()}
        p = backend.raw_pool(b)
        b["x"][b["state"] != 1] = float("nan")
        torch.testing.assert_close(backend.raw_pool(b), p, rtol=0, atol=0)

    def test_freeze_and_finetune_parameter_boundary(self):
        model = self.runtime.build("ssl26_finetune", 17)
        recipe = backend._recipe(self.recipe)
        backend._configure(model, "ssl26_finetune", "warmup", recipe)
        self.assertTrue(all(p.requires_grad == n.startswith("activity_head.") for n, p in model.named_parameters()))
        backend._configure(model, "ssl26_finetune", "tune", recipe)
        self.assertTrue(all(not p.requires_grad for n, p in model.named_parameters()
                            if n.startswith(("decoder.", "decoder_kind.", "decoder_role."))))
        self.assertTrue(model.input.project[1].weight.requires_grad)

    def test_refit_test_labels_do_not_affect_predictions(self):
        with tempfile.TemporaryDirectory() as directory:
            kwargs = dict(runtime=self.runtime, arm="raw_mlp", train_indices=[0, 1, 2, 3],
                          sample_weights=[1.] * 4, seed=17, epochs=2, predict_indices=[6, 7], recipe=self.recipe)
            first = backend.refit_predict(**kwargs, labels=self.labels, output_checkpoint=Path(directory) / "a.pt")
            altered = self.labels.copy(); altered[6:] = 1 - altered[6:]
            second = backend.refit_predict(**kwargs, labels=altered, output_checkpoint=Path(directory) / "b.pt")
            self.assertEqual(first["logits"], second["logits"])
            self.assertEqual(first["contract_sha256"], second["contract_sha256"])
            self.assertTrue(first["checkpoint_reload_exact"])

    def test_finetune_updates_encoder_but_not_decoder(self):
        model, _ = backend._run(self.runtime, "ssl26_finetune", [0, 1, 2, 3], [],
                                self.labels, [1.] * 4, 17, self.recipe, epochs=2)
        state = model.state_dict()
        self.assertFalse(torch.equal(state["input.project.1.weight"], self.runtime.source_model["input.project.1.weight"]))
        for key in state:
            if key.startswith(("decoder.", "decoder_role.", "decoder_kind.")):
                torch.testing.assert_close(state[key], self.runtime.source_model[key], rtol=0, atol=0)

    def test_heldout_labels_do_not_affect_inner_epoch_selection(self):
        first = backend.fit_select(self.runtime, "ssl10_finetune", [0, 1, 2, 3], [4, 5],
                                   self.labels, [1.] * 4, 29, recipe=self.recipe)
        altered = self.labels.copy(); altered[6:] = 1 - altered[6:]
        second = backend.fit_select(self.runtime, "ssl10_finetune", [0, 1, 2, 3], [4, 5],
                                    altered, [1.] * 4, 29, recipe=self.recipe)
        self.assertEqual(first["selected_epoch"], second["selected_epoch"])
        self.assertEqual(first["validation_logits"], second["validation_logits"])

    def test_resume_contract_rejects_changed_labels(self):
        with tempfile.TemporaryDirectory() as directory:
            kwargs = dict(runtime=self.runtime, arm="raw_mlp", train_indices=[0, 1, 2, 3],
                          validation_indices=[4, 5], sample_weights=[1.] * 4, seed=17,
                          recipe=self.recipe, work_dir=directory)
            backend.fit_select(**kwargs, labels=self.labels)
            altered = self.labels.copy(); altered[0] = 1
            with self.assertRaisesRegex(ValueError, "resume contract changed"):
                backend.fit_select(**kwargs, labels=altered)

    def test_paused_refit_resumes_exactly(self):
        with tempfile.TemporaryDirectory() as directory:
            kwargs = dict(runtime=self.runtime, arm="raw_mlp", train_indices=[0, 1, 2, 3],
                          validation_indices=[], labels=self.labels, sample_weights=[1.] * 4,
                          seed=43, recipe=self.recipe, epochs=3)
            checks = [0]
            def stop_after_first_epoch():
                checks[0] += 1
                return checks[0] >= 2
            with self.assertRaises(backend.TrainingPaused):
                backend._run(**kwargs, work_dir=directory, stop_requested=stop_after_first_epoch)
            saved = torch.load(Path(directory) / "latest.pt", map_location="cpu", weights_only=False)
            self.assertEqual(saved["epoch"], 1)
            model, _ = backend._run(**kwargs, work_dir=directory)
            uninterrupted, _ = backend._run(**kwargs)
            for key, value in model.state_dict().items():
                torch.testing.assert_close(value, uninterrupted.state_dict()[key], rtol=0, atol=0)

    def test_train_test_overlap_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, "Outer-training/test overlap"):
                backend.refit_predict(self.runtime, "raw_mlp", [0, 1, 2, 3], self.labels,
                                      [1.] * 4, 17, 2, [3, 4], Path(directory) / "bad.pt", recipe=self.recipe)

    def test_saved_classifier_clean_batch_replay(self):
        with tempfile.TemporaryDirectory() as directory:
            result = backend.refit_predict(self.runtime, "ssl26_finetune", [0, 1, 2, 3], self.labels,
                                           [1.] * 4, 17, 2, [6, 7], Path(directory) / "model.pt", recipe=self.recipe)
            saved = backend.SavedClassifier(result["checkpoint"], result["checkpoint_sha256"], device="cpu")
            batch = {key: value[[6, 7]].clone() for key, value in self.runtime._batch.items()}
            actual = saved.predict_batch(batch)
            np.testing.assert_array_equal(actual["logits"], result["logits"])
            batch["state"][0, 0, 0] = 4
            with self.assertRaisesRegex(ValueError, "unmasked"):
                saved.predict_batch(batch)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--require-torch", action="store_true")
    args, unknown = parser.parse_known_args()
    if args.require_torch and not HAS_TORCH:
        raise SystemExit("PyTorch missing: run the mandatory neural pilot under the pinned Jean Zay PyTorch module")
    unittest.main(argv=[__file__, *unknown])
