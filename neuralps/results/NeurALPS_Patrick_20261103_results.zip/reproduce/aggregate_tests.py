"""Independent aggregation and deployment-selection guard tests."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
from scipy.special import expit

import aggregate as ag
from frozen_test import evaluate_records, make_splits


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


def fixture(output):
    rows = []
    for donor in range(35):
        for position in range(3):
            i = len(rows)
            rows.append(dict(index=i, assembly_id=f"assembly{i}", dataset="bode2",
                             group=f"donor{donor:02d}", observed_activity=(donor+position) % 2,
                             metadata={"position": str(position)}))
    splits = make_splits(rows)
    dump(output / "frozen/outer_splits.json", splits)
    frozen = []
    for split in splits:
        zz = [.6 if rows[i]["observed_activity"] else -.6 for i in split["test_indices"]]
        frozen.append({**split, "feature_arm": "typed", "procedures": {
            p: {"logits": zz, "probability": expit(zz).tolist()} for p in ag.PROCEDURES}})
    detailed, summary = evaluate_records(rows, frozen)
    dump(output / "frozen/heldout_predictions.json", detailed)
    dump(output / "frozen/summary.json", summary)
    dump(output / "frozen/predictions_sealed.json", frozen)
    dump(output / "frozen/prediction_seal.json", {
        "predictions_sha256": ag.sha(output / "frozen/predictions_sealed.json")})
    for split in splits:
        models = {}
        for arm in ag.NEURAL_ARMS:
            for procedure in ag.PROCEDURES:
                zz = [.6 if rows[i]["observed_activity"] else -.6 for i in split["test_indices"]]
                models[arm + "__" + procedure] = {
                    "probability": expit(zz).tolist(),
                    "seed_results": [{"seed": seed, "logits": zz} for seed in ag.SEEDS]}
        dump(output / "neural" / split["fold"] / "predictions.json", {
            "fold": split["fold"], "test_indices": split["test_indices"], "models": models})
        dump(output / "neural" / split["fold"] / "prediction_seal.json", {
            "sha256": ag.sha(output / "neural" / split["fold"] / "predictions.json"),
            "contains_activity_labels": False})
    dump(output / "maps/summary.json", {
        "status": "MAP_AUDIT_COMPLETE", "score_contract": {"primary_path": "full", "diagnostic_path": "local"},
        "assemblies": 105, "joint_parity_checked": 105, "joint_parity_maximum_absolute_error": 0.,
        "map_definition_selected_from_activity_labels": False, "all_objects_scored": True,
        "object_status_counts": {"SCORED": 3150}})
    dump(output / "maps/COMPLETE.json", {"status": "MAP_AUDIT_COMPLETE"})
    return rows


class AggregateTests(unittest.TestCase):
    def test_complete_pipeline_retains_default_on_tie(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp)
            rows = fixture(output)
            selection = ag.aggregate_results(output, rows, {})
            self.assertEqual(selection["candidate"], ag.BASELINE)
            self.assertEqual(selection["status"], "DEVELOPMENT_CANDIDATE_SELECTED_MULTIEXCHANGE_PENDING")
            self.assertFalse(selection["final_triple_library_winner"])
            self.assertEqual(len(ag.read_json(output / "comparison.json")), 12)

    def test_misaligned_identity_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp)
            rows = fixture(output)
            path = output / "frozen/heldout_predictions.json"
            values = ag.read_json(path)
            values[0]["assembly_id"] = "wrong"
            dump(path, values)
            with self.assertRaisesRegex(ValueError, "identity mismatch"):
                ag.aggregate_results(output, rows, {})

    def test_missing_fold_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp)
            rows = fixture(output)
            (output / "neural/fold03/predictions.json").unlink()
            with self.assertRaisesRegex(ValueError, "fold is incomplete"):
                ag.aggregate_results(output, rows, {})

    def test_seed_mean_and_phenotype_free_predictions_enforced(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp)
            rows = fixture(output)
            path = output / "neural/fold00/predictions.json"
            values = ag.read_json(path)
            name = next(iter(values["models"]))
            values["models"][name]["probability"][0] = .99
            dump(path, values)
            dump(path.with_name("prediction_seal.json"), {"sha256": ag.sha(path), "contains_activity_labels": False})
            with self.assertRaisesRegex(ValueError, "average seed probabilities"):
                ag.aggregate_results(output, rows, {})
            values["label"] = 0
            dump(path, values)
            dump(path.with_name("prediction_seal.json"), {"sha256": ag.sha(path), "contains_activity_labels": False})
            with self.assertRaisesRegex(ValueError, "phenotype labels"):
                ag.aggregate_results(output, rows, {})

    def test_neural_prediction_seal_detects_changed_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp)
            rows = fixture(output)
            path = output / "neural/fold00/predictions.json"
            values = ag.read_json(path)
            values["models"][next(iter(values["models"]))]["probability"][0] = .99
            dump(path, values)
            with self.assertRaisesRegex(ValueError, "Neural prediction seal mismatch"):
                ag.aggregate_results(output, rows, {})

    def test_blends_are_fixed_probability_means(self):
        candidates = {}
        for procedure in ag.PROCEDURES:
            candidates["typed__" + procedure] = {"probabilities": np.array([.2, .8]),
                "components": [{"kind": "frozen", "feature_arm": "typed", "procedure": procedure, "weight": 1.}]}
            for arm in ("ssl10_finetune", "ssl26_finetune"):
                candidates[arm + "__" + procedure] = {"probabilities": np.array([.4, .4]),
                    "components": [{"kind": "neural", "arm": arm, "procedure": procedure, "weight": 1.}]}
        ag.add_fixed_blends(candidates)
        for name in candidates:
            if name.startswith("blend__"):
                np.testing.assert_allclose(candidates[name]["probabilities"], [.3, .6])
                self.assertEqual([c["weight"] for c in candidates[name]["components"]], [.5, .5])

    def test_conservative_gates_and_simpler_family_tie(self):
        def entry(name, kind, loss, auc=.8):
            return dict(name=name, kind=kind, eligible=True, log_loss=loss,
                        same_fold_position_macro_auroc=auc, components=[{}])
        summaries = {ag.BASELINE: entry(ag.BASELINE, "frozen", .5),
                     "small": entry("small", "frozen", .495),
                     "ranking_worse": entry("ranking_worse", "neural", .45, .75),
                     "uncertain": entry("uncertain", "neural", .46),
                     "neural": entry("neural", "neural", .47),
                     "frozen": entry("frozen", "frozen", .4705)}
        intervals = {name: {"contrasts": {"log_loss": {"ci95": [-.05, -.01]}}} for name in summaries}
        intervals["uncertain"]["contrasts"]["log_loss"]["ci95"][1] = .001
        selected, gates, _ = ag.choose_candidate(summaries, intervals, ag.DEFAULT_RULE)
        self.assertEqual(selected["name"], "frozen")
        for name in ("small", "ranking_worse", "uncertain"):
            self.assertFalse(gates[name]["passes"])

    def test_map_contract_cannot_be_selected_from_activity_labels(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp)
            rows = fixture(output)
            path = output / "maps/summary.json"
            value = ag.read_json(path)
            value["map_definition_selected_from_activity_labels"] = True
            dump(path, value)
            with self.assertRaisesRegex(ValueError, "Map parity/selection"):
                ag.aggregate_results(output, rows, {})


if __name__ == "__main__":
    unittest.main()
