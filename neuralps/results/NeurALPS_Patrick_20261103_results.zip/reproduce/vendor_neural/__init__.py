"""Frozen source copy used for checkpoint-compatible assembly inference."""
