"""Meaningful isolation, weighting, persistence and target-metric tests."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits

import frozen_test as ft


def fixture():
    rng = np.random.default_rng(19)
    rows = []
    x = []
    for study, n in (("bode1", 12), ("tdomain", 10)):
        for j in range(n):
            y = j % 2
            rows.append({"index": len(rows), "assembly_id": f"{study}-{j}", "dataset": study,
                         "observed_activity": y, "group": f"source-{j}", "metadata": {}})
            x.append(rng.normal(size=4) + y * .6)
    for donor in range(10):
        for position in range(3):
            y = (donor + position) % 2
            rows.append({"index": len(rows), "assembly_id": f"b2-{donor}-{position}", "dataset": "bode2",
                         "observed_activity": y, "group": f"donor-{donor}",
                         "metadata": {"position": str(position)}})
            x.append(rng.normal(size=4) + y * .6)
    cfg = ft.settings({"frozen": {"outer_folds": 5, "inner_folds": 2,
                        "lambda_grid": [.1, 1], "source_weights": [0, .25],
                        "auxiliary_exclusions": {f"donor-{j}": [j] for j in range(10)},
                        "auxiliary_exclusions_provenance": "synthetic audit",
                        "fit_deployment": False}})
    return rows, np.asarray(x), cfg


class FrozenTests(unittest.TestCase):
    def setUp(self):
        self.rows, self.x, self.cfg = fixture()
        self.guard = threadpool_limits(limits=1)
        self.guard.__enter__()

    def tearDown(self):
        self.guard.__exit__(None, None, None)

    def test_grouped_splits_ignore_labels_and_cover_exactly_once(self):
        splits = ft.make_splits(self.rows)
        other = copy.deepcopy(self.rows)
        for r in other:
            r["observed_activity"] = 1 - r["observed_activity"]
        self.assertEqual(splits, ft.make_splits(other))
        seen = []
        for split in splits:
            self.assertFalse(set(split["train_groups"]) & set(split["test_groups"]))
            self.assertFalse(set(split["train_indices"]) & set(split["test_indices"]))
            seen.extend(split["test_indices"])
        target = [i for i, r in enumerate(self.rows) if r["dataset"] == "bode2"]
        self.assertEqual(sorted(seen), target)

    def test_cohort_weights_are_means_not_sample_count(self):
        indices = list(range(len(self.rows)))
        weights = ft.cohort_weights(self.rows, indices, .25, 1)
        totals = {s: sum(w for i, w in zip(indices, weights) if self.rows[i]["dataset"] == s) for s in ft.STUDIES}
        self.assertAlmostEqual(totals["bode1"] / totals["bode2"], .25)
        self.assertAlmostEqual(totals["tdomain"] / totals["bode2"], 1)
        self.assertAlmostEqual(weights.sum(), 1)

    def test_missing_auxiliary_audit_fails_closed(self):
        bad = copy.deepcopy(self.cfg)
        del bad["auxiliary_exclusions"]
        with self.assertRaisesRegex(ValueError, "audited exclusion"):
            ft.validate_inputs(self.rows, {"typed": self.x}, bad)

    def test_empty_purged_source_is_unavailable_without_losing_baseline(self):
        cfg=copy.deepcopy(self.cfg)
        cfg['auxiliary_exclusions']={g:list(range(22)) for g in cfg['auxiliary_exclusions']}
        split=ft.make_splits(self.rows)[0]
        result=ft.fit_fold(self.x,self.rows,split,cfg)
        self.assertTrue(any(not t.get('available',True) for t in result['inner_trials']))
        self.assertEqual(result['procedures']['inner_selected_pool']['selected']['pool'],'bode2_only')

    def test_outer_and_inner_donor_purge(self):
        split = ft.make_splits(self.rows)[0]
        result = ft.fit_fold(self.x, self.rows, split, self.cfg)
        outer_excluded = {i for g in split["test_groups"] for i in self.cfg["auxiliary_exclusions"][g]}
        for trial in result["inner_trials"]:
            for inner in trial["inner_fits"]:
                self.assertFalse(outer_excluded & set(inner["train_indices"]))
                self.assertFalse(set(inner["purge_indices"]) & set(inner["train_indices"]))
        for procedure in result["procedures"].values():
            self.assertFalse(outer_excluded & set(procedure["train_indices"]))

    def test_test_label_perturbation_does_not_change_predictions_or_selection(self):
        split = ft.make_splits(self.rows)[0]
        result = ft.fit_fold(self.x, self.rows, split, self.cfg)
        mutated = copy.deepcopy(self.rows)
        for i in split["test_indices"]:
            mutated[i]["observed_activity"] = 1 - mutated[i]["observed_activity"]
        changed = ft.fit_fold(self.x, mutated, split, self.cfg)
        self.assertEqual(result["prediction_sha256"], changed["prediction_sha256"])
        self.assertEqual(result["inner_trials"], changed["inner_trials"])

    def test_source_intercepts_and_saved_model_round_trip(self):
        indices = list(range(len(self.rows)))
        model = ft.fit_model(self.x, [r["observed_activity"] for r in self.rows],
                              [r["dataset"] for r in self.rows],
                              ft.cohort_weights(self.rows, indices, .25, 1), .1)
        self.assertEqual(model["studies"], list(ft.STUDIES))
        self.assertLess(model["gradient_inf"], 2e-5)
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "model.npz"
            ft.save_model(p, model, {"test": True})
            with np.load(p) as z:
                restored = {k: z[k] for k in z.files}
            restored["studies"] = restored["studies"].tolist()
            np.testing.assert_array_equal(ft.predict_logits(model, self.x), ft.predict_logits(restored, self.x))
            self.assertEqual(json.loads(p.with_suffix(".json").read_text())["model_sha256"], ft.sha256(p))

    def test_chemistry_vocabulary_is_fitted_on_training_only(self):
        target = [i for i, r in enumerate(self.rows) if r["dataset"] == "bode2"]
        bundle = ft.FeatureBundle(self.x[target], [{"common": float(j % 2), "train_token": 1.0} for j in range(len(target))])
        model = ft.fit_model(bundle, [self.rows[i]["observed_activity"] for i in target],
                              ["bode2"] * len(target), np.ones(len(target)), .1)
        self.assertNotIn("test_only_token", model["chemistry_feature_names"])
        test1 = ft.FeatureBundle(self.x[target[:2]], [{"common": 1., "train_token": 1.}] * 2)
        test2 = ft.FeatureBundle(self.x[target[:2]], [{"common": 1., "train_token": 1., "test_only_token": 100.}] * 2)
        np.testing.assert_array_equal(ft.predict_logits(model, test1), ft.predict_logits(model, test2))

    def test_same_fold_conditional_auc_removes_position_and_fold_offsets(self):
        records = []
        for split in ft.make_splits(self.rows):
            p = [expit(int(self.rows[i]["metadata"]["position"]) + int(split["fold"][-1])) for i in split["test_indices"]]
            records.append({**split, "feature_arm": "control",
                            "procedures": {"position": {"probability": p, "logits": list(np.log(np.array(p)/(1-np.array(p))))}}})
        _, summary = ft.evaluate_records(self.rows, records)
        self.assertEqual(summary[0]["same_fold_position_macro_auroc"], .5)

    def test_end_to_end_seal_deployment_and_resume(self):
        protocol = {"frozen": {"outer_folds": 2, "inner_folds": 2,
                              "lambda_grid": [.1], "enable_auxiliary": False,
                              "fit_deployment": True}}
        with tempfile.TemporaryDirectory() as tmp:
            inp, out = Path(tmp) / "input", Path(tmp) / "output"
            inp.mkdir()
            ft.write_json(inp / "metadata.json", {"rows": self.rows})
            np.savez(inp / "features.npz", typed=self.x)
            complete = ft.run_frozen(inp, out, protocol)
            self.assertEqual(complete["status"], "FROZEN_COMPARISON_COMPLETE")
            self.assertFalse(complete["final_patrick_winner"])
            seal = json.loads((out / "prediction_seal.json").read_text())
            self.assertEqual(seal["predictions_sha256"], ft.sha256(out / "predictions_sealed.json"))
            model, meta = ft.load_model(out / "deployment" / "typed__bode2_only.npz")
            self.assertTrue(np.isfinite(ft.predict_logits(model, self.x)).all())
            before = ft.sha256(out / "predictions_sealed.json")
            ft.run_frozen(inp, out, protocol)
            self.assertEqual(before, ft.sha256(out / "predictions_sealed.json"))
            protocol["frozen"]["lambda_grid"] = [1.]
            with self.assertRaisesRegex(RuntimeError, "different request"):
                ft.run_frozen(inp, out, protocol)


if __name__ == "__main__":
    unittest.main()
