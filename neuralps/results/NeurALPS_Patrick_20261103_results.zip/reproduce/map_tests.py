"""CPU-only regression checks for map masking, reduction, and source isolation."""
import copy
import functools
import hashlib
import json
from pathlib import Path
import random
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import numpy as np
try:
    import torch
except ImportError:
    torch = None

import map_audit as audit
if torch is not None:
    from vendor_map.neuralps.assembly_model import AssemblyEncoder, Config, collate_records
from vendor_map.neuralps.contracts import seqsha
from vendor_map.neuralps.masking import masking_closure
from vendor_map.neuralps.scoring import Runtime, make_plan, reconstruction_agreement, predict_mode


def fixture(build_runtime=True):
    rng = random.Random(7)
    proteins = ["".join(rng.choices("ACDEFGHIKLMNPQRSTVWY", k=100)) for _ in range(2)]
    parents = {seqsha(s): s for s in proteins}
    hashes = [seqsha(s) for s in proteins]
    route = [dict(kind=k, domain_type=1 if k == 0 else 0, chain=c)
             for k, c in [(0,1), (1,1), (0,1), (2,-1), (0,2), (1,2), (0,2)]]
    spans = [(0,0,0,0,10), (1,0,0,7,23), (2,0,0,20,30),
             (3,1,0,80,90), (3,2,1,0,10), (4,0,1,20,30),
             (5,0,1,27,43), (6,0,1,40,50)]
    slots, vectors = [], {}
    nrng = np.random.default_rng(8)
    for j, role, p, start, end in spans:
        h = seqsha(proteins[p][start:end]); kind = route[j]["kind"]
        group = "D:1" if kind == 0 else "C:1:1" if kind == 1 else "B:" + ("cterm" if role == 1 else "nterm")
        slots.append(dict(object_index=j, slot=role, kind=kind, state="OBSERVED", sequence_hash=h,
                          parent_sequence_hash=hashes[p], start=start, end=end, length=end-start, group=group))
        vectors[h] = nrng.normal(size=8).astype(np.float32)
    record = dict(assembly_id="synthetic", route=route, model_slots=slots,
                  parent_sequence_hashes={"p1": hashes[0], "p2": hashes[1]})
    if not build_runtime:
        return record, parents, vectors, None
    torch.manual_seed(9)
    model = AssemblyEncoder(Config(feature_dim=8,width=16,heads=4,local_layers=1,radius=3,
                                   global_layers=1,global_slots=2,dropout=0))
    # Initialize nonzero global write weights so bypass and full paths differ.
    with torch.no_grad():
        model.global_blocks[0].write.out_proj.weight.normal_(0,.1)
    runtime = Runtime.__new__(Runtime)
    runtime.model = model.eval().requires_grad_(False)
    runtime.collate = functools.partial(collate_records, feature_dim=8)
    runtime.device = "cpu"
    runtime.means = {"zero": np.zeros(8,dtype=np.float32)}
    runtime.mean_map = {k: ("zero",100) for k in ["D", "C", "B:cterm", "B:nterm"]}
    return record, parents, vectors, runtime


class MapTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if torch is not None:
            torch.set_num_threads(1)

    def test_overlap_closure_hides_adjacent_boundary(self):
        rec, parents, _, _ = fixture(False)
        plan = make_plan(rec, [2], parents)
        self.assertEqual(plan["status"], "READY")
        self.assertIn((2,0), map(tuple, plan["hidden"]))
        self.assertIn((1,0), map(tuple, plan["hidden"]))
        self.assertNotIn((0,0), map(tuple, plan["hidden"]))  # no recursive collateral expansion

    def test_exact_alias_is_hidden_on_another_chain(self):
        rec, parents, _, _ = fixture(False)
        target = rec["model_slots"][2]
        copyseq = parents[target["parent_sequence_hash"]][target["start"]:target["end"]]
        p2 = rec["parent_sequence_hashes"]["p2"]
        parent2 = parents[p2]
        parents[p2] = parent2[:40] + copyseq + parent2[50:]
        hidden = masking_closure(rec, [(2,0)], parents.__getitem__, "independent_sequence")["hidden"]
        self.assertIn((6,0), map(tuple, hidden))

    @unittest.skipUnless(torch is not None, "PyTorch unavailable; must run on Jean Zay before inference")
    def test_break_masks_both_roles_and_counts_once(self):
        rec, parents, vectors, runtime = fixture()
        plan = make_plan(rec,[3],parents)
        self.assertEqual(set(map(tuple,plan["primary"])), {(3,1),(3,2)})
        result = runtime.score_plans(rec,parents,vectors,{"break":plan})["break"]
        self.assertEqual(set(result["objects"]), {"3"})
        objs=[dict(object_index=3,kind=2,status="SCORED",scores=result["objects"]["3"])]
        self.assertEqual(audit.aggregate(objs,"full")["total"],1)

    @unittest.skipUnless(torch is not None, "PyTorch unavailable; must run on Jean Zay before inference")
    def test_masked_values_cannot_change_predictions(self):
        rec, parents, vectors, runtime = fixture()
        plan=make_plan(rec,[2],parents)
        batch=runtime.collate([rec],vectors.__getitem__)
        other={k:v.clone() for k,v in batch.items()}
        for j,role in plan["hidden"]:
            batch["state"][0,j,role]=4; other["state"][0,j,role]=4
            batch["x"][0,j,role]=float("nan"); other["x"][0,j,role]=123456.
        for local in [False,True]:
            a=predict_mode(runtime.model,batch,local);b=predict_mode(runtime.model,other,local)
            torch.testing.assert_close(a,b,rtol=0,atol=0)
            self.assertTrue(torch.isfinite(a).all())

    @unittest.skipUnless(torch is not None, "PyTorch unavailable; must run on Jean Zay before inference")
    def test_microbatch_invariance_and_distinct_modes(self):
        rec, parents, vectors, runtime=fixture()
        plans={str(j):make_plan(rec,[j],parents) for j in range(len(rec["route"]))}
        a=runtime.score_plans(rec,parents,vectors,plans,microbatch=1)
        b=runtime.score_plans(rec,parents,vectors,plans,microbatch=4)
        differences=[]
        for key in a:
            for j,values in a[key]["objects"].items():
                for mode,score in values.items():
                    self.assertAlmostEqual(score,b[key]["objects"][j][mode],places=5)
                    self.assertAlmostEqual(score,a[key]["objects_rawcos"][j][mode],places=5) # zero means
                differences.append(abs(values["full"]-values["local"]))
        self.assertGreater(max(differences),1e-6)

    @unittest.skipUnless(torch is not None, "PyTorch unavailable; must run on Jean Zay before inference")
    def test_centered_fallback_and_role_average(self):
        target=torch.tensor([[1.,0.],[0.,1.]])
        pred=torch.tensor([[1.,0.],[1.,0.]])
        self.assertAlmostEqual(float(reconstruction_agreement(pred,target,target)),.5)

    def test_missing_coverage_never_dropped(self):
        objects=[dict(object_index=0,kind=0,status="SCORED",scores={"full":.9}),
                 dict(object_index=1,kind=1,status="MISSING_SEQUENCE_FEATURE",scores={})]
        result=audit.aggregate(objects,"full")
        self.assertFalse(result["complete"]);self.assertEqual(result["scored"],1)
        self.assertIsNone(result["balanced_mean"]);self.assertIsNone(result["q25"])

    def test_balancing_is_physical_kind_not_slot_count(self):
        objects=[dict(object_index=i,kind=k,status="SCORED",scores={"full":s})
                 for i,k,s in [(0,0,.8),(1,2,.2),(2,0,.6)]]
        result=audit.aggregate(objects,"full")
        self.assertAlmostEqual(result["balanced_mean"],.45)
        self.assertAlmostEqual(result["mean"],1.6/3)

    def test_zip_json_reader_rejects_duplicate_names(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/"test.zip"
            with zipfile.ZipFile(p,"w") as z:
                z.writestr(audit.KIT_PREFIX+"cohort.json", "{}")
                z.writestr(audit.KIT_PREFIX+"cohort.json", "{}")
            with zipfile.ZipFile(p) as z:
                with self.assertRaisesRegex(ValueError,"duplicated"):
                    audit.archive_json(z,"cohort.json")

    def test_preflight_matches_supervised_ids_and_labels(self):
        metadata=json.loads((audit.HERE/"inputs/metadata.json").read_text())
        target=[r for r in metadata["rows"] if r["dataset"]=="bode2"]
        vocab=json.loads((audit.HERE/"vendor_map/neuralps/data/domain_vocabulary.json").read_text())
        rows=[dict(assembly_id=r["assembly_id"],label=r["observed_activity"],route=[{}],
                   archived_joint={"objects":{"0":{}}},exchange_domain_indices=[0]) for r in target]
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for name in list(audit.PINNED)+["e1_ssl_targets_497189/manifest.json",
                                         "e0_cache_final_491894/feature_index.sqlite3"]:
                p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.touch()
            with (root/"e0_cache_final_491894/features.f32").open("wb") as f:
                f.truncate(audit.FEATURE_SHAPE[0]*audit.FEATURE_SHAPE[1]*4) # sparse size-only fixture
            def archive():
                with zipfile.ZipFile(root/"NeurALPS_BODE2_All_Parts.zip","w") as z:
                    z.writestr(audit.KIT_PREFIX+"cohort.json",json.dumps({"rows":rows}))
                    z.writestr(audit.KIT_PREFIX+"source_contract.json",json.dumps({"files_sha256":{}}))
                    z.writestr(audit.KIT_PREFIX+"neuralps/data/domain_vocabulary.json",json.dumps(vocab))
            archive()
            self.assertEqual(audit.preflight(root)["status"],"PREFLIGHT_OK")
            # Preserve cohort class counts; changing the join must still fail.
            positive=next(r for r in rows if r["label"]==1)
            negative=next(r for r in rows if r["label"]==0)
            positive["label"],negative["label"]=0,1
            archive()
            with self.assertRaisesRegex(ValueError,"IDs/labels differ"):
                audit.preflight(root)

    @unittest.skipUnless(torch is not None, "PyTorch unavailable; must run on Jean Zay before inference")
    def test_structural_inference_ignores_phenotype_field(self):
        rec,parents,vectors,runtime=fixture()
        a=runtime.score_plans(rec,parents,vectors,{"one":make_plan(rec,[2],parents)})
        rec["label"]=12345;rec["dataset"]="different"
        b=runtime.score_plans(rec,parents,vectors,{"one":make_plan(rec,[2],parents)})
        self.assertEqual(a,b)


if __name__ == "__main__":
    unittest.main()
