#!/usr/bin/env python3
"""Submit one bounded A100 allocation, inspect it, or resume its saved state."""
import argparse
from collections import deque
import fcntl
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import time

HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    p = Path(path)
    temp = p.with_suffix(p.suffix+'.tmp')
    temp.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
    temp.replace(p)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def preflight(root):
    from selftest import validate_package
    result = validate_package()
    import map_audit
    maps = map_audit.preflight(root)
    additional = [
        'e1_ssl_continue_development_527237/best.pt',
        'e10_tdomain_embed_696333/features.f32',
        'e10_tdomain_embed_696333/feature_index.sqlite3',
        'e10_tdomain_embed_696333/inputs/parents.fasta.gz',
        'e11_tdomain_transfer_699466/scores/records.json.gz'
    ]
    missing = [p for p in additional if not (root/p).is_file()]
    if missing:
        raise RuntimeError('Required recorded inputs missing: '+', '.join(missing))
    return dict(package=result,map=maps,additional_inputs=additional,
                large_asset_hashes='Verified inside allocation before model loading')


def command(root, out, request):
    return ['sbatch','--parsable','--job-name=nrps_patrick',
        '--account=nef@a100','--partition=gpu_p5','--qos=qos_gpu_a100-t3',
        '--nodes=1','--ntasks=1','--cpus-per-task=8','--hint=nomultithread',
        '--gres=gpu:1','--constraint=a100','--time=02:00:00',
        '--signal=USR1@300','--no-requeue','--propagate=NONE',
        '--chdir='+str(root), '--output='+str(out/'slurm_%j.log'),
        '--error='+str(out/'slurm_%j.log'),str(HERE/'batch.sh'),
        str(HERE),str(root),str(out),str(request)]


def status(info):
    job = info.get('job_id')
    if job:
        for cmd in [['squeue','-j',job,'-o','%.18i %.12P %.20j %.12T %.10M %.30R'],
                    ['sacct','-j',job,'--format=JobID,State,ExitCode,Elapsed']]:
            p = subprocess.run(cmd,capture_output=True,text=True,timeout=30)
            print(p.stdout.strip() or p.stderr.strip(),flush=True)
    out = Path(info['output'])
    print('Output:',out,flush=True)
    for name in ('progress.json','COMPLETE.json','PAUSED.json','fatal_error.json'):
        if (out/name).exists():
            print(name+':', (out/name).read_text(),flush=True)
    if job and (out/f'slurm_{job}.log').exists():
        with (out/f'slurm_{job}.log').open(errors='replace') as stream:
            print(''.join(deque(stream,maxlen=14)),flush=True)
    if (out/'inspection.zip').exists():
        print('RESULT_ZIP:',out/'inspection.zip',flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['preflight','run','resume','status'])
    parser.add_argument('--root',type=Path,default=HERE.parent)
    args = parser.parse_args()
    root = args.root.resolve()
    receipt = HERE/'SUBMISSION.json'
    if args.action == 'status':
        if not receipt.exists():
            raise RuntimeError('No submission recorded yet')
        status(read(receipt)); return
    check = preflight(root)
    print('PREFLIGHT_OK: corrected labels, sealed package, live input paths; no training on login node',flush=True)
    if args.action == 'preflight':
        print(json.dumps(check,indent=2));return
    with (HERE/'submission.lock').open('a') as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        old = read(receipt) if receipt.exists() else None
        if args.action == 'run' and old:
            print('Already submitted; no duplicate allocation created. Use status or resume.',flush=True)
            status(old);return
        if args.action == 'resume':
            if not old or not old.get('job_id'):
                raise RuntimeError('No confirmed prior job. Inspect SUBMISSION.json and squeue before retrying.')
            if old['root'] != str(root) or old['package_sha256'] != sha(HERE/'PACKAGE_MANIFEST.json'):
                raise RuntimeError('Cannot resume with different project/package')
            p = subprocess.run(['squeue','-h','-j',old['job_id'],'-o','%i %T'],capture_output=True,text=True,timeout=30,check=True)
            if p.stdout.strip():
                raise RuntimeError('Previous allocation still queued/running: '+p.stdout.strip())
            out = Path(old['output'])
            if (out/'COMPLETE.json').exists():
                status(old);return
            if (out/'fatal_error.json').exists():
                raise RuntimeError('Run failed a check. Return inspection.zip before resuming; do not bypass the failure.')
        else:
            stamp = time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())
            out = root/('neuralps_patrick_'+stamp+'_'+sha(HERE/'PACKAGE_MANIFEST.json')[:8])
            out.mkdir(exist_ok=False)
        request = out/'REQUEST.json'
        if not request.exists():
            write(request,dict(root=str(root),output=str(out),package=str(HERE),
                package_sha256=sha(HERE/'PACKAGE_MANIFEST.json'),preflight=check))
            (out/'REQUEST.sha256').write_text(sha(request)+'\n')
        cmd = command(root,out,request)
        info = dict(status='SUBMITTING',root=str(root),output=str(out),
            package_sha256=sha(HERE/'PACKAGE_MANIFEST.json'),command=cmd,
            previous_jobs=(old.get('previous_jobs',[])+[old['job_id']]) if old else [])
        write(receipt,info)
        try:
            p = subprocess.run(cmd,capture_output=True,text=True,timeout=60)
        except (OSError,subprocess.TimeoutExpired) as exc:
            info.update(status='SUBMISSION_UNCERTAIN',error=str(exc));write(receipt,info)
            raise RuntimeError('Submission outcome uncertain; inspect squeue before another submission') from exc
        job = p.stdout.strip().split(';')[0]
        info.update(stdout=p.stdout.strip(),stderr=p.stderr.strip(),returncode=p.returncode)
        if p.returncode != 0 or not job.isdigit():
            info['status']='REJECTED_OR_UNCERTAIN';write(receipt,info)
            raise RuntimeError('Slurm did not confirm a job:\n'+p.stdout+p.stderr)
        info.update(status='SUBMITTED',job_id=job);write(receipt,info)
        print('SUBMITTED_JOB:',job,flush=True)
        print('Resources: 1 A100, 8 CPUs, maximum 2 hours per submission; resumable',flush=True)
        print('Output:',out,flush=True)
        print('Status: python3 -B',HERE/'submit.py','status',flush=True)


if __name__ == '__main__':
    main()
