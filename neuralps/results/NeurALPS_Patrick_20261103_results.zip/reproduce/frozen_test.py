"""Nested BODE2 activity-head comparison on immutable frozen features.

No encoder inference, identifier features, or test-label model selection.
The shared slope uses study-specific unpenalized intercepts. The objective is
the normalized weighted sum of study mean binary log losses plus lambda/2
times the squared slope norm. The package protocol defines all candidates.
"""
from __future__ import annotations

import os
for _key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_key, "1")
import argparse
import collections
import hashlib
import json
import math
import time
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from scipy.special import expit
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.feature_extraction import DictVectorizer
from threadpoolctl import threadpool_limits

DEFAULTS = {
    "outer_folds": 5, "inner_folds": 4, "seed": 20261103,
    "lambda_grid": [0.01, 0.1, 1.0, 10.0, 100.0],
    "source_weights": [0.0, 0.25, 1.0],
    "feature_arms": ["typed"], "enable_auxiliary": True,
    "fit_deployment": True,
}
STUDIES = ("bode2", "bode1", "tdomain")


class FeatureBundle:
    """Numeric frozen features plus unencoded chemistry dictionaries."""
    def __init__(self, numeric, chemistry):
        self.numeric = np.asarray(numeric)
        self.chemistry = list(chemistry)

    def __getitem__(self, indices):
        indices = list(map(int, indices))
        return FeatureBundle(self.numeric[indices], [self.chemistry[i] for i in indices])

    def __len__(self):
        return len(self.numeric)


def encoded_features(x, names=None):
    if not isinstance(x, FeatureBundle):
        return np.asarray(x, dtype=np.float64), None
    vectorizer = DictVectorizer(sparse=False, dtype=np.float64)
    if names is None:
        chem = vectorizer.fit_transform(x.chemistry)
        names = vectorizer.get_feature_names_out().tolist()
    else:
        vectorizer.vocabulary_ = {name: j for j, name in enumerate(names)}
        vectorizer.feature_names_ = list(names)
        chem = vectorizer.transform(x.chemistry)
    return np.column_stack((x.numeric, chem)), names


def json_text(value):
    return json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json_text(value))
    temporary.replace(path)


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json_text(value).encode()).hexdigest()


def settings(protocol):
    cfg = dict(DEFAULTS)
    cfg.update(protocol.get("frozen", {}))
    for key in ("auxiliary_exclusions", "auxiliary_exclusions_provenance"):
        if key in protocol:
            cfg[key] = protocol[key]
    if any(float(v) <= 0 for v in cfg["lambda_grid"]):
        raise ValueError("Every L2 penalty must be positive")
    if set(map(float, cfg["source_weights"])) - {0.0, 0.25, 1.0}:
        raise ValueError("Source weight grid must be a subset of 0, 0.25, 1")
    if 0.0 not in cfg["source_weights"]:
        raise ValueError("BODE2-only candidate must remain available")
    if not 2 <= int(cfg["inner_folds"]) <= 5 or not 2 <= int(cfg["outer_folds"]) <= 5:
        raise ValueError("Expected 2-5 grouped inner/outer folds")
    return cfg


def make_splits(rows, indices=None, n_splits=5, seed=20261103):
    """Label-independent donor folds, with global row indices.

    This function deliberately does not access observed_activity.
    """
    if indices is None:
        indices = [i for i, r in enumerate(rows) if r["dataset"] == "bode2"]
    indices = sorted(map(int, indices))
    if any(rows[i]["dataset"] != "bode2" for i in indices):
        raise ValueError("Target splits must contain BODE2 rows only")
    groups = sorted({str(rows[i]["group"]) for i in indices})
    if n_splits < 2 or len(groups) < n_splits:
        raise ValueError("Too few donor groups for grouped split")
    rng = np.random.default_rng(seed)
    shuffled = rng.permutation(groups)
    result = []
    for fold_number, block in enumerate(np.array_split(shuffled, n_splits)):
        held = set(map(str, block))
        test = [i for i in indices if str(rows[i]["group"]) in held]
        train = [i for i in indices if str(rows[i]["group"]) not in held]
        result.append({"fold": f"fold{fold_number:02d}",
                       "train_indices": train, "test_indices": test,
                       "train_groups": sorted(set(groups) - held),
                       "test_groups": sorted(held)})
    return result


def validate_inputs(rows, arrays, cfg):
    if len({r["assembly_id"] for r in rows}) != len(rows):
        raise ValueError("Assembly identifiers must be unique")
    for i, r in enumerate(rows):
        if r.get("index", i) != i or r["dataset"] not in STUDIES:
            raise ValueError("Invalid row index or study")
        if r["observed_activity"] not in (0, 1):
            raise ValueError("Expected reviewed binary endpoint labels")
    for key, x in arrays.items():
        if key == "chemistry_dicts":
            if len(x) != len(rows) or not all(isinstance(r, dict) for r in x):
                raise ValueError("Invalid aligned chemistry dictionaries")
            continue
        if key not in {"typed", "raw_esmc"}:
            # Archived regional summaries may contain unsupported/missing values.
            # They are not inputs to these candidate heads.
            continue
        if x.ndim != 2 or len(x) != len(rows) or not np.isfinite(x).all():
            raise ValueError(f"Invalid/nonfinite aligned feature matrix: {key}")
    if "typed" not in arrays:
        raise ValueError("typed frozen representation is required")
    b2 = [r for r in rows if r["dataset"] == "bode2"]
    counts = collections.Counter(str(r["group"]) for r in b2)
    if set(counts.values()) != {3}:
        raise ValueError("Each BODE2 donor must have exactly three placements")
    for group in counts:
        positions = {r["metadata"]["position"] for r in b2 if str(r["group"]) == group}
        if len(positions) != 3:
            raise ValueError("BODE2 donor placements must be distinct")
    if cfg["enable_auxiliary"]:
        mapping = cfg.get("auxiliary_exclusions")
        if not isinstance(mapping, dict) or set(mapping) != set(counts):
            raise ValueError("Auxiliary comparison requires an audited exclusion list for every BODE2 donor")
        if not cfg.get("auxiliary_exclusions_provenance"):
            raise ValueError("Auxiliary exclusion audit provenance is required")
        for donor, ids in mapping.items():
            if not isinstance(ids, list) or len(ids) != len(set(ids)):
                raise ValueError(f"Invalid exclusion list for {donor}")
            for i in ids:
                if not isinstance(i, int) or not 0 <= i < len(rows) or rows[i]["dataset"] == "bode2":
                    raise ValueError(f"Invalid auxiliary exclusion row {i}")


def auxiliary_purge(rows, held_groups, cfg, feature_hashes=None, held_indices=()):
    excluded = set()
    mapping = cfg.get("auxiliary_exclusions", {})
    for group in held_groups:
        excluded.update(mapping.get(str(group), []))
    if feature_hashes is not None:
        hashes = {feature_hashes[i] for i in held_indices}
        excluded.update(i for i, r in enumerate(rows)
                        if r["dataset"] != "bode2" and feature_hashes[i] in hashes)
    return sorted(excluded)


def training_indices(rows, target_train, alpha, beta, excluded):
    excluded = set(excluded)
    ids = list(map(int, target_train))
    for study, weight in (("bode1", alpha), ("tdomain", beta)):
        if weight > 0:
            chosen = [i for i, r in enumerate(rows) if r["dataset"] == study and i not in excluded]
            if not chosen:
                raise ValueError(f"No eligible {study} rows for a positive source weight")
            ids.extend(chosen)
    return sorted(ids)


def cohort_weights(rows, indices, alpha=0.0, beta=0.0):
    """Normalized study means; totals are proportional to (1, alpha, beta)."""
    study_weight = {"bode2": 1.0, "bode1": float(alpha), "tdomain": float(beta)}
    counts = collections.Counter(rows[i]["dataset"] for i in indices)
    if counts["bode2"] == 0:
        raise ValueError("Target rows must be present")
    if any(study_weight[study] <= 0 for study in counts):
        raise ValueError("Training rows include a disabled study")
    weights = np.array([study_weight[rows[i]["dataset"]] / counts[rows[i]["dataset"]]
                        for i in indices], dtype=np.float64)
    return weights / weights.sum()


def study_design(studies, present):
    return np.column_stack([(np.asarray(studies) == s).astype(float) for s in present])


def fit_model(x, y, studies, sample_weights, l2):
    """Training-only weighted scaling and convex logistic fitting.

    Explicit per-study intercepts are outside the slope penalty. The BODE2
    intercept is used for all Patrick-target predictions. No posthoc inversion.
    """
    x, chemistry_names = encoded_features(x)
    y = np.asarray(y, dtype=np.float64)
    weights = np.asarray(sample_weights, dtype=np.float64)
    if len(x) != len(y) or len(weights) != len(y) or not np.isfinite(x).all():
        raise ValueError("Invalid training arrays")
    if np.any(weights <= 0):
        raise ValueError("Training weights must be positive")
    weights = weights / weights.sum()
    mean = weights @ x
    scale = np.sqrt(weights @ ((x - mean) ** 2))
    active = scale > 1e-8
    z = np.ascontiguousarray((x[:, active] - mean[active]) / scale[active])
    present = [s for s in STUDIES if s in set(studies)]
    if "bode2" not in present:
        raise ValueError("A BODE2 intercept is required")
    indicators = study_design(studies, present)
    # Require both labels within each cohort to avoid divergent unpenalized intercepts.
    for s in present:
        if len(set(y[np.asarray(studies) == s])) != 2:
            raise ValueError(f"Both outcome classes required within training study {s}")
    n_features = z.shape[1]
    initial = np.zeros(n_features + len(present), dtype=float)
    for j, s in enumerate(present):
        take = np.asarray(studies) == s
        p = np.average(y[take], weights=weights[take])
        initial[n_features + j] = np.log(p / (1 - p))

    def objective(v):
        slopes, intercepts = v[:n_features], v[n_features:]
        logits = z @ slopes + indicators @ intercepts
        residual = weights * (expit(logits) - y)
        value = np.dot(weights, np.logaddexp(0, logits) - y * logits) + .5 * l2 * np.dot(slopes, slopes)
        gradient = np.concatenate((z.T @ residual + l2 * slopes, indicators.T @ residual))
        return float(value), gradient

    result = minimize(objective, initial, method="L-BFGS-B", jac=True,
                      options={"maxiter": 2000, "ftol": 1e-12, "gtol": 1e-7, "maxls": 50})
    gradient_norm = float(np.max(np.abs(result.jac)))
    if gradient_norm > 2e-5:
        raise RuntimeError(f"Logistic optimizer failed stationarity: {result.message}; gradient={gradient_norm}")
    return {"mean": mean, "scale": scale, "active": active,
            "coef": result.x[:n_features], "intercepts": result.x[n_features:],
            "studies": present, "lambda": float(l2),
            "chemistry_feature_names": chemistry_names,
            "iterations": int(result.nit), "gradient_inf": gradient_norm}


def predict_logits(model, x, study="bode2"):
    x, _ = encoded_features(x, model.get("chemistry_feature_names"))
    active = model["active"]
    transformed = (np.asarray(x)[:, active] - model["mean"][active]) / model["scale"][active]
    return transformed @ model["coef"] + model["intercepts"][model["studies"].index(study)]


def nll(y, logits):
    return float(np.mean(np.logaddexp(0, logits) - np.asarray(y) * logits))


def feature_matrix(arrays, arm):
    if arm == "typed":
        return arrays["typed"]
    if arm == "typed_chemistry":
        if "chemistry_dicts" not in arrays:
            raise ValueError("typed_chemistry requires aligned chemistry dictionaries")
        return FeatureBundle(arrays["typed"], arrays["chemistry_dicts"])
    if arm == "raw_esmc":
        return arrays["raw_esmc"]
    raise ValueError(f"Unknown frozen feature arm {arm}")


def pool_name(alpha, beta):
    return "all_three" if alpha and beta else "bode2_bode1" if alpha else "bode2_tdomain" if beta else "bode2_only"


def pool_candidates(cfg, arm):
    weights = cfg["source_weights"] if cfg["enable_auxiliary"] and arm != "typed_chemistry" else [0.0]
    return [(float(a), float(b)) for a in weights for b in weights]


def choose_trial(trials):
    # Exact numerical ties prefer no/less auxiliary weight, then stronger L2.
    return min([t for t in trials if t.get('available',True)], key=lambda t: (round(t["inner_log_loss"], 12),
                                      t["alpha"] + t["beta"], -t["lambda"], t["alpha"], t["beta"]))


def evaluate_training_candidates(x, rows, target_train, held_groups, held_indices,
                                 cfg, arm, inner_seed, feature_hashes):
    inner = make_splits(rows, target_train, cfg["inner_folds"], inner_seed)
    labels = np.array([r["observed_activity"] for r in rows], dtype=int)
    trials = []
    for alpha, beta in pool_candidates(cfg, arm):
        prepared = []
        unavailable = None
        for split in inner:
            held = sorted(set(held_groups) | set(split["test_groups"]))
            withheld_indices = sorted(set(held_indices) | set(split["test_indices"]))
            excluded = auxiliary_purge(rows, held, cfg, feature_hashes, withheld_indices)
            for study, weight in (("bode1",alpha),("tdomain",beta)):
                if weight > 0 and not any(r['dataset']==study and i not in excluded for i,r in enumerate(rows)):
                    unavailable = f'All {study} rows excluded in inner {split["fold"]}'
            if unavailable:
                break
            tr = training_indices(rows, split["train_indices"], alpha, beta, excluded)
            weights = cohort_weights(rows, tr, alpha, beta)
            prepared.append((tr, split["test_indices"], weights, excluded))
        if unavailable:
            trials.append(dict(alpha=alpha,beta=beta,pool=pool_name(alpha,beta),
                               available=False,reason=unavailable))
            continue
        for l2 in cfg["lambda_grid"]:
            oof = {}
            fits = []
            for tr, va, weights, excluded in prepared:
                model = fit_model(x[tr], labels[tr], [rows[i]["dataset"] for i in tr], weights, float(l2))
                zz = predict_logits(model, x[va])
                oof.update(zip(va, map(float, zz)))
                fits.append({"train_indices": tr, "valid_indices": va,
                             "purge_indices": excluded,
                             "iterations": model["iterations"], "gradient_inf": model["gradient_inf"]})
            order = sorted(target_train)
            if set(oof) != set(order):
                raise AssertionError("Inner OOF coverage is incomplete")
            trials.append({"alpha": alpha, "beta": beta, "lambda": float(l2),
                           "pool": pool_name(alpha, beta),
                           "inner_log_loss": nll(labels[order], np.array([oof[i] for i in order])),
                           "inner_oof_indices": order,
                           "inner_oof_logits": [oof[i] for i in order], "inner_fits": fits})
    return inner, trials


def procedure_trials(trials, allow_augmentation):
    trials = [t for t in trials if t.get('available',True)]
    result = {"bode2_only": choose_trial([t for t in trials if t["pool"] == "bode2_only"])}
    if allow_augmentation:
        for pool in ("bode2_bode1", "bode2_tdomain", "all_three"):
            subset = [t for t in trials if t["pool"] == pool]
            if subset:
                result[pool] = choose_trial(subset)
        result["inner_selected_pool"] = choose_trial(trials)
    return result


def fit_fold(x, rows, split, cfg, arm="typed", feature_hashes=None, fold_number=0):
    """Return sealed-prediction content without reading any test outcome in a fit."""
    started = time.time()
    inner_seed = int(cfg["seed"]) + 1000 + fold_number
    inner, trials = evaluate_training_candidates(
        x, rows, split["train_indices"], split["test_groups"], split["test_indices"],
        cfg, arm, inner_seed, feature_hashes)
    procedures = {}
    cache = {}
    for name, trial in procedure_trials(trials, cfg["enable_auxiliary"] and arm != "typed_chemistry").items():
        key = (trial["alpha"], trial["beta"], trial["lambda"])
        if key not in cache:
            alpha, beta, l2 = key
            excluded = auxiliary_purge(rows, split["test_groups"], cfg, feature_hashes, split["test_indices"])
            tr = training_indices(rows, split["train_indices"], alpha, beta, excluded)
            model = fit_model(x[tr], [rows[i]["observed_activity"] for i in tr],
                              [rows[i]["dataset"] for i in tr], cohort_weights(rows, tr, alpha, beta), l2)
            logits = predict_logits(model, x[split["test_indices"]])
            cache[key] = {"selected": {k: trial[k] for k in ("alpha", "beta", "lambda", "pool", "inner_log_loss")},
                          "train_indices": tr, "purge_indices": excluded,
                          "logits": logits.tolist(), "probability": expit(logits).tolist(),
                          "active_features": int(model["active"].sum()),
                          "iterations": model["iterations"], "gradient_inf": model["gradient_inf"]}
        procedures[name] = cache[key]
    record = {"feature_arm": arm, **split, "inner_splits": inner,
              "inner_seed": inner_seed, "inner_trials": trials,
              "procedures": procedures, "seconds": time.time() - started}
    record["prediction_sha256"] = digest({"split": split, "procedures": procedures})
    return record


def metrics(y, p):
    y, p = np.asarray(y, dtype=int), np.asarray(p, dtype=float)
    if not len(y) or len(y) != len(p) or not np.isfinite(p).all():
        raise ValueError("Invalid prediction array")
    q = np.clip(p, 1e-12, 1 - 1e-12)
    k = max(1, math.ceil(.2 * len(y)))
    cut = np.sort(p)[-k]
    higher, tied = p > cut, p == cut
    precision = (y[higher].sum() + (k - higher.sum()) * y[tied].mean()) / k
    return {"n": len(y), "positive": int(y.sum()),
            "auroc": float(roc_auc_score(y, p)) if len(set(y)) == 2 else None,
            "average_precision": float(average_precision_score(y, p)) if y.sum() else None,
            "log_loss": float(np.mean(-y * np.log(q) - (1 - y) * np.log1p(-q))),
            "brier": float(np.mean((p - y) ** 2)),
            "precision_top20_tie_expected": float(precision), "top20_n": k}


def evaluate_records(rows, records):
    grouped = collections.defaultdict(list)
    detailed = []
    for record in records:
        for procedure, result in record["procedures"].items():
            for j, i in enumerate(record["test_indices"]):
                row = {"feature_arm": record["feature_arm"], "procedure": procedure,
                       "fold": record["fold"], "index": i,
                       "assembly_id": rows[i]["assembly_id"], "group": str(rows[i]["group"]),
                       "position": rows[i]["metadata"]["position"],
                       "label": rows[i]["observed_activity"],
                       "logit": result["logits"][j], "probability": result["probability"][j]}
                detailed.append(row)
                grouped[(record["feature_arm"], procedure)].append(row)
    summaries = []
    for (arm, procedure), rr in sorted(grouped.items()):
        if len({r["index"] for r in rr}) != len(rr):
            raise AssertionError("Repeated OOF rows are not independent experiments")
        out = {"feature_arm": arm, "procedure": procedure,
               "pooled_metrics": metrics([r["label"] for r in rr], [r["probability"] for r in rr])}
        folds = []
        conditional = []
        for fold in sorted({r["fold"] for r in rr}):
            sub = [r for r in rr if r["fold"] == fold]
            folds.append({"fold": fold, **metrics([r["label"] for r in sub], [r["probability"] for r in sub])})
            for position in sorted({r["position"] for r in sub}):
                ss = [r for r in sub if r["position"] == position]
                m = metrics([r["label"] for r in ss], [r["probability"] for r in ss])
                conditional.append({"fold": fold, "position": position, **m})
        # Same-model pairs only: average available fold AUCs within each position,
        # then average position values. Undefined one-class cells remain explicit.
        per_position = {}
        for position in sorted({r["position"] for r in rr}):
            values = [r["auroc"] for r in conditional if r["position"] == position and r["auroc"] is not None]
            per_position[position] = {"auroc": float(np.mean(values)) if values else None,
                                      "defined_folds": len(values), "total_folds": len(folds)}
        available = [v["auroc"] for v in per_position.values() if v["auroc"] is not None]
        out.update(fold_metrics=folds, same_fold_position_metrics=conditional,
                   same_fold_position_auc=per_position,
                   same_fold_position_macro_auroc=float(np.mean(available)) if available else None,
                   conditional_auc_complete=all(v["defined_folds"] == v["total_folds"] for v in per_position.values()),
                   warning="Single-exchange retrospective development; pooled OOF AUROC may include fold offsets. Top20% is not precision among 50 of 42,875 triples.")
        summaries.append(out)
    return detailed, summaries


def save_model(path, model, metadata):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, mean=model["mean"], scale=model["scale"], active=model["active"],
                        coef=model["coef"], intercepts=model["intercepts"], studies=np.array(model["studies"]),
                        chemistry_feature_names=np.array(model.get("chemistry_feature_names") or [], dtype=str))
    write_json(path.with_suffix(".json"), {**metadata, "model_sha256": sha256(path),
               "lambda": model["lambda"], "iterations": model["iterations"], "gradient_inf": model["gradient_inf"],
               "score_semantics": "BODE2-study sigmoid activity score; no prospective calibration guarantee",
               "training_metrics_are_validation": False})


def load_model(path):
    path = Path(path)
    metadata = json.loads(path.with_suffix(".json").read_text())
    if sha256(path) != metadata["model_sha256"]:
        raise ValueError("Deployment model hash mismatch")
    with np.load(path, allow_pickle=False) as archive:
        model = {key: archive[key].copy() for key in archive.files}
    model["studies"] = model["studies"].tolist()
    model["chemistry_feature_names"] = model["chemistry_feature_names"].tolist()
    model["lambda"] = metadata["lambda"]
    return model, metadata


def fit_deployment(x, rows, cfg, arm, feature_hashes, output_dir):
    target = [i for i, r in enumerate(rows) if r["dataset"] == "bode2"]
    inner, trials = evaluate_training_candidates(x, rows, target, [], [], cfg, arm,
                                               int(cfg["seed"]) + 2000, feature_hashes)
    chosen = procedure_trials(trials, cfg["enable_auxiliary"] and arm != "typed_chemistry")
    # Save only default and inner-selected augmentation procedures, not an outer-score winner.
    deploy = {}
    for name in ("bode2_only", "inner_selected_pool"):
        if name not in chosen:
            continue
        t = chosen[name]
        tr = training_indices(rows, target, t["alpha"], t["beta"], [])
        model = fit_model(x[tr], [rows[i]["observed_activity"] for i in tr],
                          [rows[i]["dataset"] for i in tr], cohort_weights(rows, tr, t["alpha"], t["beta"]), t["lambda"])
        metadata = {"feature_arm": arm, "procedure": name,
                    "selected": {k: t[k] for k in ("alpha", "beta", "lambda", "pool", "inner_log_loss")},
                    "train_indices": tr, "inner_splits": inner,
                    "input_rows_sha256": digest(rows), "final_patrick_winner": False,
                    "status": "candidate_deployment_fit_pending_neural_and_multiexchange_comparison"}
        save_model(Path(output_dir) / "deployment" / f"{arm}__{name}.npz", model, metadata)
        deploy[name] = metadata
    return deploy


def run_frozen(input_dir, output_dir, protocol):
    input_dir, output_dir = Path(input_dir), Path(output_dir)
    cfg = settings(protocol)
    output_dir.mkdir(parents=True, exist_ok=True)
    meta = json.loads((input_dir / "metadata.json").read_text())
    rows = meta["rows"]
    with np.load(input_dir / "features.npz", allow_pickle=False) as archive:
        arrays = {key: archive[key] for key in archive.files}
    chemistry_path = input_dir / "chemistry.json"
    if chemistry_path.exists():
        chemistry = json.loads(chemistry_path.read_text())
        if chemistry["scope"] != "BODE2_only":
            raise ValueError("This protocol only supports BODE2-only chemistry features")
        arrays["chemistry_dicts"] = chemistry["rows"]
    validate_inputs(rows, arrays, cfg)
    features_hash = sha256(input_dir / "features.npz")
    metadata_hash = sha256(input_dir / "metadata.json")
    code_hash = sha256(__file__)
    identity = {"features_sha256": features_hash, "metadata_sha256": metadata_hash,
                "chemistry_sha256": sha256(chemistry_path) if chemistry_path.exists() else None,
                "protocol_sha256": digest(protocol), "code_sha256": code_hash}
    old_identity = output_dir / "request.json"
    if old_identity.exists() and json.loads(old_identity.read_text())["identity"] != identity:
        raise RuntimeError("Output directory belongs to a different request; use a fresh directory")
    write_json(old_identity, {"identity": identity, "settings": cfg})
    feature_hashes = [hashlib.sha256(np.asarray(x, dtype="<f8").tobytes()).hexdigest() for x in arrays["typed"]]
    splits = make_splits(rows, n_splits=cfg["outer_folds"], seed=cfg["seed"])
    write_json(output_dir / "outer_splits.json", splits)
    records = []
    with threadpool_limits(limits=1):
        for arm in cfg["feature_arms"]:
            x = feature_matrix(arrays, arm)
            for number, split in enumerate(splits):
                path = output_dir / "folds" / f"{arm}__{split['fold']}.json"
                if path.exists():
                    record = json.loads(path.read_text())
                    if record.get("identity") != identity:
                        raise RuntimeError(f"Stale fold cache: {path}")
                else:
                    record = fit_fold(x, rows, split, cfg, arm, feature_hashes, number)
                    record["identity"] = identity
                    write_json(path, record)
                records.append(record)
                print(f"FROZEN_FOLD_OK {arm} {split['fold']}", flush=True)
        # Seal all unlabelled predictions before evaluation is called.
        prediction_rows = [{"feature_arm": r["feature_arm"], "fold": r["fold"],
                            "test_indices": r["test_indices"], "procedures": r["procedures"]}
                           for r in records]
        write_json(output_dir / "predictions_sealed.json", prediction_rows)
        write_json(output_dir / "prediction_seal.json", {"identity": identity,
                   "predictions_sha256": sha256(output_dir / "predictions_sealed.json"),
                   "fit_selection_uses_only_training_labels": True,
                   "evaluation_called_after_seal": True})
        detailed, summaries = evaluate_records(rows, records)
        write_json(output_dir / "heldout_predictions.json", detailed)
        write_json(output_dir / "summary.json", summaries)
        deployment = {}
        if cfg["fit_deployment"]:
            for arm in cfg["feature_arms"]:
                deployment[arm] = fit_deployment(feature_matrix(arrays, arm), rows, cfg, arm, feature_hashes, output_dir)
        complete = {"identity": identity, "status": "FROZEN_COMPARISON_COMPLETE",
                    "outer_folds": len(splits), "independent_bode2_constructs": sum(r["dataset"] == "bode2" for r in rows),
                    "candidate_deployment": deployment,
                    "final_patrick_winner": False,
                    "notes": ["Outer-fold comparisons are retrospective development evidence.",
                              "The frozen winner is not automatically the neural/multiexchange winner.",
                              "Explicit donor and exact-representation exclusions are audited; this is not a complete homology-purged evaluation."]}
        write_json(output_dir / "COMPLETE.json", complete)
    return complete


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    args = parser.parse_args()
    run_frozen(args.input_dir, args.output_dir, json.loads(args.protocol.read_text()))


if __name__ == "__main__":
    main()
