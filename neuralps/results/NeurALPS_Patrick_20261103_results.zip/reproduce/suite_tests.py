"""Controller integration tests with explicitly synthetic neural fits."""
import copy
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch
from types import SimpleNamespace
import numpy as np
import frozen_test
import neural_backend
import run_suite

HERE=Path(__file__).resolve().parent


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.rows=json.loads((HERE/'inputs/metadata.json').read_text())['rows']
        self.protocol=json.loads((HERE/'PROTOCOL.json').read_text())
        self.protocol['frozen']['lambda_grid']=[1.0]
        self.protocol['frozen']['source_weights']=[0.0]
        self.protocol['auxiliary_exclusions']={str(r['group']):[] for r in self.rows if r['dataset']=='bode2'}
        self.protocol['auxiliary_exclusions_provenance']={'synthetic_fixture':True}

    def test_neural_controller_excludes_test_and_refits_all_outer_rows(self):
        cfg=frozen_test.settings(self.protocol)
        split=frozen_test.make_splits(self.rows,seed=cfg['seed'])[0]
        x=np.random.default_rng(41).normal(size=(494,4))
        fold=frozen_test.fit_fold(x,self.rows,split,cfg)
        calls=[]
        def select(runtime,arm,tr,va,labels,weights,seed,**kwargs):
            self.assertFalse(set(tr)&set(split['test_indices']))
            self.assertFalse(set(va)&set(split['test_indices']))
            self.assertFalse(set(tr)&set(va))
            self.assertAlmostEqual(float(np.sum(weights)),1.0)
            calls.append(('select',arm,seed,set(tr),set(va)))
            return {'selected_epoch':2}
        def refit(runtime,arm,tr,labels,weights,seed,epochs,predict,checkpoint,**kwargs):
            self.assertEqual(set(tr),set(split['train_indices']))
            self.assertEqual(predict,split['test_indices'])
            self.assertEqual(epochs,2)
            calls.append(('refit',arm,seed,set(tr),set(predict)))
            return {'logits':[0.1*(seed%5)]*len(predict),'checkpoint':str(checkpoint),
                    'checkpoint_sha256':'synthetic_only'}
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)
            run_suite.dump(out/'resolved_protocol.json',self.protocol)
            run_suite.dump(out/'frozen/folds/typed__fold00.json',fold)
            runtime=SimpleNamespace(identity_sha256='synthetic_runtime')
            with patch.object(neural_backend,'fit_select',select),patch.object(neural_backend,'refit_predict',refit):
                run_suite.neural_fold(runtime,self.rows,self.protocol,out,0,time.monotonic()+30)
                first=len(calls)
                run_suite.neural_fold(runtime,self.rows,self.protocol,out,0,time.monotonic()+30)
            self.assertEqual(first,36)
            self.assertEqual(len(calls),first)
            pred=run_suite.load(out/'neural/fold00/predictions.json')
            self.assertEqual(len(pred['models']),6)
            self.assertNotIn('observed_activity',json.dumps(pred))
            self.assertEqual(run_suite.load(out/'neural/fold00/prediction_seal.json')['sha256'],
                             run_suite.sha(out/'neural/fold00/predictions.json'))

    def test_frozen_deployment_uses_chosen_saved_model(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)
            run_suite.dump(out/'resolved_protocol.json',self.protocol)
            p=out/'frozen/deployment/typed__bode2_only.npz'
            p.parent.mkdir(parents=True)
            p.write_bytes(b'synthetic model bytes only')
            run_suite.dump(p.with_suffix('.json'),{'selected':{'alpha':0,'beta':0},'train_indices':[324,325]})
            selection={'candidate':'typed__bode2_only','kind':'frozen',
                       'components':[{'kind':'frozen','feature_arm':'typed','procedure':'bode2_only','weight':1.0}]}
            with patch.object(run_suite,'sha',lambda path:'fixture_digest'):
                value=run_suite.deploy(SimpleNamespace(identity_sha256='fixture'),self.rows,self.protocol,
                                       out,selection,time.monotonic()+30)
            self.assertEqual(value['components'][0]['model'],str(p))
            self.assertEqual(value['status'],'SINGLES_DEVELOPMENT_COMPLETE_MULTIEXCHANGE_INPUTS_PENDING')
            self.assertIsNone(value['activity_threshold'])

    def test_expired_budget_stops_before_fit(self):
        with self.assertRaises(neural_backend.TrainingPaused):
            run_suite.check_deadline(time.monotonic()-1)


if __name__=='__main__':
    unittest.main()
