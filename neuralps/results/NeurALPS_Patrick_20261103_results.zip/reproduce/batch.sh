#!/usr/bin/env bash
set -euo pipefail
PATRICK_PACKAGE="$1"
PATRICK_ROOT="$2"
PATRICK_OUTPUT="$3"
PATRICK_REQUEST="$4"
module purge
module load arch/a100
module load pytorch-gpu/py3/2.8.0
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export CUBLAS_WORKSPACE_CONFIG=:4096:8
python3 -I -B - "$PATRICK_PACKAGE" "$PATRICK_REQUEST" <<'PY'
import hashlib,json,sys
from pathlib import Path
package,request=map(Path,sys.argv[1:])
digest=hashlib.sha256(request.read_bytes()).hexdigest()
assert digest==request.with_suffix('.sha256').read_text().strip(), 'Request changed'
payload=json.loads(request.read_text())
assert payload['package_sha256']==hashlib.sha256((package/'PACKAGE_MANIFEST.json').read_bytes()).hexdigest(), 'Package manifest changed'
print('REQUEST_HASH_OK:',digest,flush=True)
PY
srun --ntasks=1 python3 -B "$PATRICK_PACKAGE/run_suite.py" \
  --project-root "$PATRICK_ROOT" --output-dir "$PATRICK_OUTPUT" --seconds 6840
