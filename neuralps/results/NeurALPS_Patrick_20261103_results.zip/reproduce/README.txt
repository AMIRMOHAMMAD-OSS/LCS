NeurALPS Patrick model and compatibility-map test
Version: 20261103_v1

WHAT THIS RUN DOES

Uses the existing frozen ESM-C cache and selected SSL10/SSL26 assembly models.
No ESM-C inference, no new natural-data pretraining, no downloads or pip installs.
All original inputs are read-only. Outputs go to a new neuralps_patrick_* folder.
The included 494-row label table corrects 22 BODE1 D/E mapping labels; it does
not modify the original Jean Zay database or the old all494 head.

1. Verify source identities, run mandatory numerical tests, and compare nine
   live SSL26 typed representations with the supplied frozen features.
2. Produce physical domain/connection maps on the 105 BODE2 single exchanges.
   Compute full and local paths, verify historical joint-region parity, and
   preserve missing coverage. Primary map is the training-consistent full path.
3. Compare frozen typed classifiers, four source pools and a BODE2-only
   chemistry extension in nested donor-grouped validation.
4. Compare raw ESM-C MLP, SSL10 fine-tuning and SSL26 fine-tuning, each under
   BODE2-only and inner-selected auxiliary data, using three seeds.
5. Evaluate four fixed 50:50 frozen/neural probability blends, select a
   development candidate under the fixed rule, and fit its deployment weights.
6. Save a review ZIP, exact score/map version and structural handoff for the
   combined-exchange stage. Large model weights remain on Jean Zay.

SCIENTIFIC SCOPE

Five fixed outer folds each with seven withheld BODE2 donors. All three
placements of a donor stay together. Frozen source weights and regularization
are selected using four inner donor folds on the outer training partition.
Candidate source cohort weights are 0, 0.25 or 1 relative to BODE2. Training
weights normalize each cohort to its declared total, then normalize overall.
Frozen logistic models use training-only weighted scaling and study-specific
intercepts; the BODE2 intercept is used at prediction time.

For neural models, the source weights come from the frozen typed INNER search
of the same outer training partition. One fixed grouped inner split selects
the neural epoch, followed by a fresh fit on all eligible outer training rows.
This is a bounded transfer recipe, not a claim of optimal neural source weights.
Fine-tuning updates the assembly encoder and global770 MLP; ESM-C and the
reconstruction decoder remain frozen. Its common-intercept neural head differs
from the frozen typed2822 classifier with study intercepts. Seeds17/29/43 are
averaged in probability space, never selected by outer outcomes.

Auxiliary records sharing donor-specific primary domain hashes or complete
inputs are excluded for withheld donors. Exact typed feature duplicates are
also excluded. Native recipient domains are removed from donor-specific hash
sets before auxiliary purging. This is not a comprehensive homology-cluster split.
If purging leaves an auxiliary cohort empty, that source candidate is recorded
as unavailable; BODE2-only remains eligible.

Model selection uses held-out log loss and a same-fold, within-position AUROC
guard. The latter only compares predictions made by the same fitted model;
one-class cells remain undefined with explicit counts. Paired donor bootstrap
intervals condition on fixed predictions and are descriptive. Model exploration
has already used these datasets: this is retrospective development, not a new
independent confirmation. New fine-tuned and pooled comparisons should not be
called exact reproductions of the older .8209 result, whose fitting protocol differs.

The compatibility map is contextual reconstruction agreement. It is not a
domain failure probability or an explanation of a separately fine-tuned
activity classifier. No unsupported natural-reference percentile is used.
Map outputs show full and local scores separately. Assembly-level activity
labels do not establish the correctness of domain-level fault localization.

IMPORTANT REMAINING GATE

The supplied model inputs cover 105 single-exchange constructs. Labels for33
doubles and27 triples are included as provenance but are NOT silently treated
as scored model examples. Their mature chains, scars, coordinates and full
route features still need to be verified. The run exports verified singles'
structural data to support that next step.

Successful completion is therefore named:
  SINGLES_DEVELOPMENT_COMPLETE_MULTIEXCHANGE_INPUTS_PENDING

It does not claim a validated winner among Patrick's42,875 triple candidates,
and it does not score triples by multiplying their single-swap probabilities.

TRANSFER AND RUN

Project:
  /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2

Save NeurALPS_Patrick_Test_20261103.zip on the Mac Desktop. From the Mac:

  scp -J apandi@gate.lcqb.hosted.lip6.fr \
    /Users/amir/Desktop/NeurALPS_Patrick_Test_20261103.zip \
    unh87ms@jean-zay.idris.fr:/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/

If downloading on Windows first, run in PowerShell:

  scp "$env:USERPROFILE\Downloads\NeurALPS_Patrick_Test_20261103.zip" amir@100.72.70.1:/Users/amir/Desktop/

On Jean Zay:

  cd /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2 &&
  unzip -n NeurALPS_Patrick_Test_20261103.zip &&
  python3 -B NeurALPS_Patrick_Test_20261103/selftest.py &&
  python3 -B NeurALPS_Patrick_Test_20261103/submit.py run

Status:
  python3 -B NeurALPS_Patrick_Test_20261103/submit.py status

One A100, eight CPUs, two-hour maximum per allocation. No duplicate allocation
is made by rerunning 'run'. Scheduler settings and PyTorch module match the
recorded working Jean Zay jobs. The script does not assume they remain valid:
an sbatch/module rejection is returned verbatim for correction.

Training checkpoints preserve optimizer/RNG state at epoch boundaries. A time
pause can be resumed after the preceding allocation ends:
  python3 -B NeurALPS_Patrick_Test_20261103/submit.py resume

Do not bypass a fatal input/parity/numerical test error; return inspection.zip.
Keep several GB of output space available; retained fold classifiers account
for most of it. No large original files are copied or changed.

RESULTS

'status' prints the exact output folder and RESULT_ZIP path. Send inspection.zip
through LCS as before; it excludes .pt training/checkpoint tensors. The bundle
includes predictions, fold choices, label provenance, map scores, diagnostics,
the comparison report, exact model hashes, and BODE2 structural inputs.

Inspect these first:
  progress.json, COMPLETE.json or PAUSED.json or fatal_error.json
  numerical_selftest.json, typed_feature_parity.json
  auxiliary_overlap_audit.json
  maps/summary.json, maps/object_scores.csv
  comparison.csv, REPORT.txt, selection.json
  deployment/SCORE_VERSION.json

The chosen model weights remain at the paths in SCORE_VERSION.json.
Do not copy all checkpoints into normal Git.

LOCAL VALIDATION

See LOCAL_VALIDATION.json for executed checks. This environment did not have
PyTorch: its tensor tests are explicitly unexecuted locally. The allocated
Jean Zay run requires every numerical test to pass with zero skips before
loading real inputs or starting training. No Jean Zay run is claimed by this ZIP.
