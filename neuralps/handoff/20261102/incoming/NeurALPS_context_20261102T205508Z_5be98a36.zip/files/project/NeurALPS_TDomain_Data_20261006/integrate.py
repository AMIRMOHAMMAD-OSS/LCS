#!/usr/bin/env python3
"""Join source-preserving sequences and measurements; create explicit eligibility lists."""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path, rows):
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v) if isinstance(v, (list, dict)) else v
                             for k, v in row.items()})


def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True)
    args = parser.parse_args()
    data = args.data_dir
    output = data / "evaluation"
    output.mkdir(parents=True, exist_ok=True)
    records = [json.loads(line) for line in (data / "assay_data/assay_records.jsonl").read_text().splitlines()]
    endpoints = {int(r["variant_id"]): r for r in read_csv(data / "assay_data/published_minimal_endpoints.csv")}
    designs = {r["numeric_id"]: r for r in json.loads((data / "sequence_data/ai_designs.json").read_text())}
    constructs = {int(r["ai_id"].split("_")[1]): r for r in
                  json.loads((data / "sequence_data/reconstructed_T3_constructs.json").read_text())}
    reconcile = {int(r["AI_id"]): r for r in read_csv(data / "assay_data/minimal_summary_reconciliation.csv")}
    sequences = {int(r["variant_id"]): r for r in read_csv(data / "assay_data/source_sequences.csv")
                 if r["variant_id"] and r["source_file"] == "41467_2026_77963_MOESM3_ESM.xlsx"}
    fasta_records = {}
    current = None
    for line in (data / "sequence_data/reconstructed_T3_primary_sequence_subset.fasta").read_text().splitlines():
        if line.startswith(">"):
            current = line[1:]
            assert current not in fasta_records
            fasta_records[current] = ""
        elif line.strip():
            assert current is not None
            fasta_records[current] += line.strip()
    split = json.loads((ROOT / "provenance/split_audit.json").read_text())
    groups = {str(member): f"known_ancestry_{root}" for root, members in split["known_edge_group_members"].items()
              for member in members}
    assert set(sequences) == set(range(1, 259))
    assert len(endpoints) == 248 and not set(range(67, 77)).intersection(endpoints)
    rows = []
    queue = []
    for identifier in range(1, 259):
        seq = sequences[identifier]
        endpoint = endpoints.get(identifier)
        design = designs.get(identifier, {})
        construct = constructs.get(identifier, {})
        sequence_conflict = bool(design.get("conflicting_version_ids"))
        has_stop = "*" in seq["sequence"]
        source_disagreement = reconcile.get(identifier, {}).get("S15_zero_SD1_nonzero_disagreement") == "True"
        eligible = bool(endpoint and identifier <= 66 and construct.get("primary_sequence_eligible")
                        and not sequence_conflict and not has_stop)
        reason = ("ELIGIBLE_AFTER_STANDARD_ANNOTATION_AND_EMBEDDING" if eligible else
                  "NOT_TESTED_IN_MINIMAL_FLL" if endpoint is None else
                  "UNRESOLVED_SEQUENCE_SOURCE_CONFLICT" if sequence_conflict else
                  "PREMATURE_STOP_SEPARATE_MECHANISTIC_STRATUM" if has_stop else
                  "AI_FULL_CONSTRUCT_VERIFICATION_PENDING" if identifier <= 76 else
                  "EPPCR_FULL_CONSTRUCT_AND_BOUNDARY_VERIFICATION_PENDING")
        row = {
            "variant_id": identifier,
            "design_id": f"AI-{identifier}" if identifier <= 76 else f"EP-{identifier}",
            "variant_class": "AI_design" if identifier <= 76 else "epPCR",
            "context": "GxpS_minimal_SU2_T3", "target_position": "T3",
            "reported_sequence": seq["sequence"], "sequence_sha256": seq["sequence_sha256"],
            "sequence_length_including_stop": len(seq["sequence"]),
            "contains_stop": has_stop, "sequence_source_conflict": sequence_conflict,
            "assayed": endpoint is not None,
            "published_processed_percent_WT": float(endpoint["processed_percent_WT"]) if endpoint else None,
            "reported_nonzero_production": int(float(endpoint["processed_percent_WT"]) > 0) if endpoint else None,
            "endpoint_source_record_id": endpoint["source_record_id"] if endpoint else None,
            "source_zero_nonzero_disagreement": source_disagreement,
            "frozen_evaluation_eligible_after_annotation": eligible,
            "source_agreement_sensitivity_eligible_after_annotation": eligible and not source_disagreement,
            "eligibility_status": reason,
            "full_construct_id": construct.get("construct_id"),
            "full_construct_sha256": construct.get("amino_acid_sha256"),
            "minimum_ancestry_group": groups[str(identifier)],
            "strict_ancestry_transfer_allowed": not 27 <= identifier <= 31,
            "group_is_verified_homology_cluster": False,
            "evaluation_role": "FROZEN_SCORER_EVALUATION_ONLY_NO_TARGET_LABEL_FITTING",
            "model_scoring_ready": False,
        }
        rows.append(row)
        if eligible:
            # Clone interval is plasmid-DNA coordinates; convert through the reconstructed ORF.
            lo, hi = construct["insert_core_interval_0based_half_open"]
            start = construct["dna_start_0based"]
            assert (lo-start) % 3 == 0 and (hi-start) % 3 == 0
            interval = [(lo-start)//3, (hi-start)//3]
            aa = construct["amino_acids"]
            assert fasta_records[construct["construct_id"]] == aa
            assert hashlib.sha256(aa.encode()).hexdigest() == construct["amino_acid_sha256"]
            assert aa[interval[0]:interval[1]] == design["core_amino_acids"]
            queue.append({
                "variant_id": identifier, "construct_id": construct["construct_id"],
                "context": "GxpS_minimal_SU2_T3",
                "fasta_record_id": construct["construct_id"],
                "fasta": "sequence_data/reconstructed_T3_primary_sequence_subset.fasta",
                "amino_acid_sha256": construct["amino_acid_sha256"],
                "protein_length": len(aa),
                "exchanged_fragment_interval_0based_half_open": interval,
                "interval_is_paper_domain_boundary": False,
                "paper_domain_annotations_are_hints_only": True,
                "required_next_stage": "RUN_PROJECT_STANDARD_DOMAIN_ANNOTATION_AND_ESMC_FEATURE_CACHE",
                "desired_query": "masked_T3_domain_and_verified_touching_boundaries",
                "model_scoring_ready": False,
                "label_source_record_id": endpoint["source_record_id"],
                "minimum_ancestry_group": groups[str(identifier)],
            })
    write_csv(output / "minimal_variant_catalog.csv", rows)
    primary = [r for r in rows if r["frozen_evaluation_eligible_after_annotation"]]
    write_csv(output / "minimal_frozen_evaluation.csv", primary)
    write_csv(output / "minimal_source_agreement_sensitivity.csv",
              [r for r in primary if r["source_agreement_sensitivity_eligible_after_annotation"]])
    main_queue_count = len(queue)
    hybrids = json.loads((data / "hybrid_data/hybrid_constructs.json").read_text())
    hybrid_rows = []
    for construct in hybrids:
        identifier = int(construct["ai_id"].split("_")[1])
        observed = [r for r in records if r["dataset"] == "Fig7_hybrid_replicates"
                    and r["variant_id"] == identifier and r["context"] == construct["context"]
                    and r["expected_product"] and not r["is_control"]]
        assert len(observed) == 3, (construct["construct_id"], len(observed))
        endpoints_in_condition = {r["endpoint"] for r in observed}
        assert len(endpoints_in_condition) == 1
        peak_areas = [r["metrics"]["peak_area"]["value"] for r in observed]
        assert all(isinstance(v, (float, int)) for v in peak_areas)
        eligible = construct["primary_sequence_eligible"]
        hybrid_rows.append({
            "variant_id": identifier, "construct_id": construct["construct_id"],
            "context": construct["context"], "target_domain": construct["target_domain"],
            "sequence_eligible_after_annotation": eligible,
            "sequence_source_conflict": bool(construct["conflicting_version_ids"]),
            "amino_acid_sha256": construct["amino_acid_sha256"],
            "expected_product_endpoint": next(iter(endpoints_in_condition)),
            "Fig7_raw_replicate_count": len(observed),
            "Fig7_replicate_peak_area_mean": sum(peak_areas)/len(peak_areas),
            "units": "instrument peak-area units; do not compare magnitudes between different peptides",
            "source_record_ids": [r["record_id"] for r in observed],
            "authoritative_binary_activity_label": None,
            "minimum_ancestry_group": groups[str(identifier)],
            "reconstruction_basis": "in_silico_published_primers_and_deposited_DNA",
            "finished_clone_sequencing_verified": False, "model_scoring_ready": False,
        })
        if eligible:
            lo, hi = construct["inserted_nt_in_coding_sequence_0based_halfopen"]
            aa = construct["amino_acids"]
            assert hashlib.sha256(aa.encode()).hexdigest() == construct["amino_acid_sha256"]
            # Include codons split by cohesive-end ligation, not only the aligned source core.
            interval = [lo//3, (hi+2)//3]
            assert 0 <= interval[0] < interval[1] <= len(aa)
            queue.append({
                "variant_id": identifier, "construct_id": construct["construct_id"],
                "context": construct["context"], "fasta_record_id": construct["fasta_key"],
                "fasta": "hybrid_data/hybrid_primary_sequence_subset.fasta",
                "amino_acid_sha256": construct["amino_acid_sha256"], "protein_length": len(aa),
                "exchanged_fragment_interval_0based_half_open": interval,
                "fragment_interval_includes_partially_reassembled_junction_codons": True,
                "candidate_source_core_interval_0based_half_open": construct["candidate_source_core_aa_0based_halfopen"],
                "interval_is_paper_domain_boundary": False,
                "required_next_stage": "RUN_PROJECT_STANDARD_DOMAIN_ANNOTATION_AND_ESMC_FEATURE_CACHE",
                "desired_query": "masked_target_T_domain_and_verified_touching_boundaries",
                "model_scoring_ready": False, "finished_clone_sequencing_verified": False,
                "measurement_source_record_ids": [r["record_id"] for r in observed],
                "minimum_ancestry_group": groups[str(identifier)],
            })
    assert len(hybrids) == 20
    write_csv(output / "hybrid_construct_catalog.csv", hybrid_rows)
    write_json(output / "annotation_queue.json", queue)
    initial_context_jobs = json.loads((data / "sequence_data/other_context_reconstruction_jobs.json").read_text())
    reconciled_jobs = []
    for job in initial_context_jobs:
        resolved = [r for r in hybrids if r["acceptor_plasmid"] == job["acceptor_plasmid"]]
        reconciled_jobs.append({
            "acceptor_plasmid": job["acceptor_plasmid"],
            "reconstruction_status": "SELECTED_FIG7_VARIANTS_RECONSTRUCTED" if resolved else job["status"],
            "reconstructed_construct_ids": [r["construct_id"] for r in resolved],
            "primary_sequence_construct_ids": [r["construct_id"] for r in resolved if r["primary_sequence_eligible"]],
            "blockers_for_other_variants": job["blockers"],
            "model_scoring_ready": False,
            "do_not_score_sacb_template_as_inactive_construct": True,
        })
    write_json(output / "context_preparation_status.json", reconciled_jobs)
    group_rows = [{k: r[k] for k in ["variant_id", "design_id", "minimum_ancestry_group",
                  "strict_ancestry_transfer_allowed", "group_is_verified_homology_cluster"]} for r in rows]
    group_rows.append({"variant_id": "WT_GxpS_T3", "design_id": "WT_GxpS_T3",
                       "minimum_ancestry_group": "known_ancestry_WT", "strict_ancestry_transfer_allowed": True,
                       "group_is_verified_homology_cluster": False})
    write_csv(output / "variant_groups.csv", group_rows)
    # Every source record retains its independent assay and endpoint. This is a join index, not pooled labels.
    joined = []
    for record in records:
        identifier = record["variant_id"]
        if identifier is None:
            continue
        joined.append({
            "record_id": record["record_id"], "variant_id": identifier,
            "context": record["context"], "target_position": record["target_position"],
            "dataset": record["dataset"], "endpoint": record["endpoint"],
            "is_control_in_this_assay": record["is_control"],
            "expected_product": record["expected_product"],
            "group_assay_condition": record["group_assay_condition"],
            "minimum_ancestry_group": groups[str(identifier)],
            "source_record_retains_all_values_and_qc": True,
            "primary_minimal_construct_route_applicable": record["context"] == "GxpS_minimal_SU2_T3"
                and rows[identifier-1]["frozen_evaluation_eligible_after_annotation"],
        })
    write_csv(output / "assay_join_index.csv", joined)
    contexts = json.loads((ROOT / "provenance/methods_metadata.json").read_text())["contexts"]
    write_json(output / "context_evidence.json", contexts)
    summary = {
        "status": "CURATED_DATA_READY_STANDARD_MODEL_PREPROCESSING_PENDING",
        "total_numeric_variants": len(rows), "AI_designs": 76, "epPCR_variants": 182,
        "published_minimal_assayed": len(endpoints),
        "minimal_explicitly_unassayed": [r["variant_id"] for r in rows if not r["assayed"]],
        "epPCR_stop_containing_sequences": sum(r["contains_stop"] for r in rows if r["variant_class"] == "epPCR"),
        "minimal_frozen_evaluation_constructs": len(primary),
        "minimal_reported_nonzero_counts": dict(Counter(r["reported_nonzero_production"] for r in primary)),
        "minimal_source_agreement_sensitivity_constructs": sum(r["source_agreement_sensitivity_eligible_after_annotation"] for r in primary),
        "minimal_zero_nonzero_source_disagreements": [r["variant_id"] for r in rows if r["source_zero_nonzero_disagreement"]],
        "AI_sequence_conflicts": [r["variant_id"] for r in rows if r["sequence_source_conflict"]],
        "hybrid_in_silico_reconstructions": len(hybrid_rows),
        "hybrid_sequence_eligible_after_annotation": sum(r["sequence_eligible_after_annotation"] for r in hybrid_rows),
        "annotation_queue_engineered_constructs": len(queue),
        "model_scores_generated": 0, "models_fitted": 0,
        "standard_model_annotation_and_feature_cache_prepared": False,
        "pretraining_homology_overlap_audit_complete": False,
        "activity_probabilities_or_fault_localization_validated": False,
        "output_definition": "Reported production and conservative input reconstruction, not domain-fault ground truth.",
    }
    assert len(primary) == main_queue_count
    assert summary["epPCR_stop_containing_sequences"] == 29
    assert not any(r["contains_stop"] or r["sequence_source_conflict"] for r in primary)
    assert len({r["full_construct_sha256"] for r in primary}) == len(primary)
    write_json(output / "summary.json", summary)
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
