#!/usr/bin/env python3
"""Verify every delivered file against the bundled SHA-256 manifest."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
count = 0
for line in (root / "SHA256SUMS").read_text().splitlines():
    digest, relative = line.split("  ", 1)
    path = root / relative
    if not path.is_file():
        raise SystemExit(f"MISSING: {relative}")
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise SystemExit(f"CHECKSUM_MISMATCH: {relative}")
    count += 1
print(f"TDOMAIN_BUNDLE_OK: {count} checksummed files")
