# NeurALPS: curated T-domain swap data

Prepared 6 October 2026 from Bülbül et al., *Generative AI designs functional
thiolation domains for reprogramming non-ribosomal peptide synthetases*,
[Nature Communications, doi:10.1038/s41467-026-77963-6](https://doi.org/10.1038/s41467-026-77963-6).

This package retrieves and prepares the data. It does not train a model, generate
compatibility scores, or claim a new AUROC. Pretrained weights remain unchanged.

## Start here

| File | Purpose |
|---|---|
| `evaluation/minimal_frozen_evaluation.csv` | 65 main-assay constructs with a consistent sequence reconstruction and published processed production endpoint. |
| `sequence_data/reconstructed_T3_primary_sequence_subset.fasta` | Their complete reconstructed minimal GxpS protein chains, including the experimentally used fusion context. |
| `hybrid_data/hybrid_primary_sequence_subset.fasta` | 19 additional hybrid constructs reconstructed from deposited DNA and context-specific primers. |
| `evaluation/hybrid_construct_catalog.csv` | All 20 reconstructed hybrids linked to their Fig7 expected-product triplicates, with sequence conflicts flagged. |
| `evaluation/annotation_queue.json` | 84 engineered construct jobs with protein checksums and exchanged-fragment intervals for the next annotation/embedding step. |
| `evaluation/minimal_source_agreement_sensitivity.csv` | 63-construct subset excluding the two zero/nonzero source disagreements. |
| `evaluation/minimal_variant_catalog.csv` | All 258 variant IDs, including unassayed entries, stops, source conflicts and explicit eligibility reasons. |
| `assay_data/published_minimal_endpoints.csv` | The 248 published processed main-assay endpoints: 66 AI designs and 182 epPCR variants. |
| `assay_data/assay_records.jsonl` | Source-preserving replicate, analyte and summary observations with sheet/cell provenance. These rows are not independent training examples. |
| `assay_data/s14_expected_product_matrix.csv` | Four hybrid/recipient contexts × 76 designs: 300 source records and four explicitly missing combinations. |
| `evaluation/variant_groups.csv` | Minimum grouping constraints for descendants and repeated genotypes. These are not proven homology clusters. |
| `evaluation/context_preparation_status.json` | Current recipient reconstruction status after integrating the hybrid-primer step. |
| `EVALUATION_PROTOCOL.md` | Recommended first use and restrictions on later supervised splitting. |

The FASTA is **sequence-ready**, not yet in the model's feature format. Apply the
same domain annotation and ESMC feature preparation used by NeurALPS before scoring.
The paper's manual domain annotations are preserved as hints; substituting them
silently for the pretraining domain definition would change the experiment.
The initial `sequence_data/other_context_reconstruction_jobs.json` describes the
base sequence stage; the integrated context-status file records which selected
jobs were subsequently resolved by `prepare_hybrids.py`.

## What was recovered

- All six publisher supplementary files, including the complete Source Data ZIP,
  Supplementary Data 1 workbook, methods, and the pinned official author-code release.
- 76 AI-designed T-domain inserts with original DNA/FASTA versions and clone provenance.
- 182 epPCR sequences and reported production endpoints, of which 139 have raw
  replicate entries in the Source Data workbook.
- Source measurements from the main, full-length, culture-scale, position-swap,
  and hybrid assays, with controls, batches, endpoint identities and units retained.
- 16 deposited native/acceptor plasmids, 53 natural alignment references and
  conservative NRPS-chain extractions. Plasmid/vector sequences remain separate
  from proteins intended for model input.
- 66 sequence reconstructions in the main minimal GxpS T3 context. One is withheld
  from the primary subset because its published protein and cloned DNA disagree.
- 20 additional primer-supported hybrid reconstructions plus three native hybrid
  controls; 19 engineered hybrids have consistent sequence sources. These are
  in-silico reconstructions, not confirmation by sequencing finished clones.

No missing measurement was converted to zero. Full and half alignments are
alternative views of the same examples, not additional samples.

## Important source issues

1. **AI-48 and AI-74 have sequence-version conflicts.** In each case, a reported
   N-terminal Met disagrees with an internal insert codon translating to Leu.
   AI-48 is withheld from the main 65-construct subset. AI-74 belongs to the
   alternative context group and is not tested in the main flL assay. All versions
   remain available; neither discrepancy is repaired by assumption.
2. **AI-67–76 were explicitly not tested in the main flL assay.** The merged
   workbook annotation is propagated as unassayed, never inactive.
3. **29 epPCR sequences contain premature stops.** Preserve these as a separate
   failure-mechanism stratum. IDs 185 and 215 still retain their published nonzero
   production values; the curation does not change them to zero.
4. **AI-52 and AI-64 have conflicting zero/nonzero summaries.** Supplementary Data 1
   reports 1% WT for each; S15 reports zero. Their Fig2 replicate means are about
   0.98% and 1.21% WT. The main endpoint uses the explicitly designated published
   processed dataset, and the 63-construct sensitivity subset excludes both.
   More generally, 36/66 processed main-assay values differ from rounded S15 values;
   `minimal_summary_reconciliation.csv` records them without attributing all
   differences to rounding.
5. **S14 detection flags are not final activity classes.** `Detected_both_modes`
   counts ionization-mode detections (0, 1 or 2). The methods specify background
   subtraction, clamping negative values, and mode-specific WT normalization;
   incomplete/ambiguous control matching prevents an authoritative blanket binary
   label here. Raw values, flags, WT candidates and missingness are preserved.
6. **Recipient contexts need their own cloning reconstruction.** The 20 selected
   Fig7 hybrids were reconstructed using their published full primers and matching
   cohesive ends. Annealing uniqueness was checked against the deposited insert;
   full pEX template vectors were unavailable. This does not establish complete
   genotypes for every S14 design/context combination. Remaining recipients and
   position-swap constructs stay pending. The pCK templates contain ambiguous bases.
7. **Two epPCR source IDs conflict with sample names.** S4 cells O136/O137 say 11,
   while adjacent identifiers and sample names suggest 111; these two rows remain
   unassigned diagnostics. Mutant 209 has processed production of 70% WT without
   raw rows, while mutant 211 has a raw mean near 69.88% WT but processed zero.
   Both endpoint versions are preserved rather than swapping labels by assumption.

The main evaluation file contains 50 reported nonzero and 15 reported zero
production outcomes. `reported_nonzero_production` means **published processed
%WT > 0**. It is an operational assay endpoint, not a calibrated activity
probability, a universal inactivity threshold, or a causal boundary-fault label.

## Verify or rebuild

The derived data are already included. Verification uses only Python's standard
library; rebuilding additionally needs `openpyxl` and Python 3.10 or newer.

macOS/Linux, from the extracted package directory:

```bash
python3 verify.py
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python prepare.py --output-dir rebuilt
```

Windows PowerShell:

```powershell
py -3 verify.py
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe prepare.py --output-dir rebuilt
```

Use a new empty output directory. The rebuild verifies original-source checksums,
extracts only the required files into a temporary directory, regenerates the
sequence and assay tables, and joins their eligibility/grouping metadata. It makes
no network calls and submits no cluster jobs.

See `assay_data/SCHEMA.json`, `sequence_data/manifest.json`,
`provenance/methods_metadata.json`, and `CITATION_AND_RIGHTS.md` for details.
