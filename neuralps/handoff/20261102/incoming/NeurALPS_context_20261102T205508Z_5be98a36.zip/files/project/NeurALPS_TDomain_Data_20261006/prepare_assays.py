#!/usr/bin/env python3
"""Read-only, source-preserving extraction of the T-domain paper assay tables.

This exports observations, not a pooled training set. Blank cells, source zeros,
unassayed designs, raw peak-finder flags, and inferred QC are distinct. No model
scores or outcome-selected thresholds are used. Requires openpyxl.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import zipfile
import xml.etree.ElementTree as ET

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from openpyxl.utils.cell import range_boundaries, coordinate_to_tuple

VERSION = "1.0.0"
S14 = {
    "GxhS-1": ("Supp_Fig_S14_GxhS-1-VLFV_lin", "vLfV_lin"),
    "GxhS-2": ("Supp_Fig_S14_GxhS_2-VLVV_cyc", "vLvV_cyc"),
    "GshS": ("Supp_Fig_S14_GshS_VLFYW", "vLfYW"),
    "SzeS": ("Supp_Fig_S14_SzeS_LTFVYW", "lTfvYW_cyc"),
}
MINIMAL = "GxpS_minimal_SU2_T3"
FULL = "GxpS_reconstituted_SU1_SU2"
CONTEXT_POSITION = {"GxhS-1": "GxpS_T3", "GxhS-2": "GxpS_T2", "GshS": "SzeS_T4", "SzeS": "SzeS_T1"}


def numeric(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def design_number(x):
    if numeric(x) and int(x) == x and 1 <= x <= 258:
        return int(x)
    if isinstance(x, str):
        match = re.fullmatch(r"AI[- ](\d+)", x.strip())
        if match:
            return int(match.group(1))
    return None


def parent_from_name(name, identifier):
    if identifier is None or identifier <= 76:
        return None
    name = str(name).lower()
    if "evo155" in name:
        return "AI-15"
    if "evo21" in name:
        return "AI-12"
    if "esm3-2" in name or "esm2" in name:
        return "AI-2"
    if re.search(r"(^|_)wt(_|$)", name):
        return "WT_GxpS_T3"
    return None


def hash_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def write_csv(path, rows):
    rows = list(rows)
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False, allow_nan=False)
                             if isinstance(v, (list, dict)) else v for k, v in row.items()})


class Source:
    def __init__(self, path, source_id):
        self.path = Path(path)
        self.id = source_id
        self.sha256 = hash_file(self.path)
        self.book = load_workbook(self.path, read_only=True, data_only=True)
        formula_book = load_workbook(self.path, read_only=True, data_only=False)
        self.rows = {}
        self.formulas = {}
        # Styled empty columns and unrelated chromatography sheets are enormous.
        # Explicit source scopes prevent millions of irrelevant empty cells.
        limits = {"Fig_2_flL": (100, 20), "Fig_3a_vLflL": (31, 9),
            "Fig_3b_Scale_dependant": (152, 22), "Fig_6_diff_positions": (47, 9),
            "Fig_7_Hybrid_system": (299, 10), "Supplementary_Fig_S4_ErrorProne": (242, 34),
            "Supp_FIg_S15_pLDDT_titer": (68, 6),
            "Aminoacid_Sequence_FLL_Titer": (308, 6), "Constructs": (325, 5)}
        limits.update({name: (500, 34) for name, _ in S14.values()})
        for sheet in self.book:
            if sheet.title not in limits:
                continue
            max_row, max_col = limits[sheet.title]
            self.rows[sheet.title] = {
                row_number: {get_column_letter(i): cell.value for i, cell in enumerate(r, 1) if cell.value is not None}
                for row_number, r in enumerate(sheet.iter_rows(max_row=max_row, max_col=max_col), 1)
                if any(cell.value is not None for cell in r)
            }
        for sheet in formula_book:
            if sheet.title not in limits:
                continue
            max_row, max_col = limits[sheet.title]
            for row in sheet.iter_rows(max_row=max_row, max_col=max_col):
                for cell in row:
                    if cell.data_type == "f":
                        self.formulas[(sheet.title, cell.row, cell.column_letter)] = cell.value
        formula_book.close()
        self.merges = {}
        ns = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
        with zipfile.ZipFile(self.path) as archive:
            workbook_xml = ET.fromstring(archive.read("xl/workbook.xml"))
            relations = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
            targets = {r.attrib["Id"]: r.attrib["Target"] for r in relations}
            for sheet in workbook_xml.find("s:sheets", ns):
                name = sheet.attrib["name"]
                if name not in self.rows:
                    continue
                rel = sheet.attrib["{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"]
                target = targets[rel]
                target = target.lstrip("/") if target.startswith("/") else "xl/" + target
                # Streaming avoids materializing the worksheet's formatted cells.
                with archive.open(target) as handle:
                    self.merges[name] = []
                    for _, elem in ET.iterparse(handle, events=["end"]):
                        if elem.tag.endswith("}mergeCell"):
                            self.merges[name].append(elem.attrib["ref"])
                        elem.clear()

    def cells(self, sheet, row):
        return self.rows[sheet].get(row, {})

    def metric(self, sheet, row, col, unit):
        value = self.cells(sheet, row).get(col)
        formula = self.formulas.get((sheet, row, col))
        status = ("NUMERIC_ZERO" if numeric(value) and value == 0 else
                  "NUMERIC_NEGATIVE" if numeric(value) and value < 0 else
                  "NUMERIC" if numeric(value) else
                  "UNCACHED_FORMULA" if value is None and formula else
                  "BLANK" if value is None else "TEXT")
        return {"value": value, "unit": unit, "cell": f"{col}{row}",
                "value_status": status, "formula": formula}

    def merged_value(self, sheet, row, col):
        coordinate = f"{col}{row}"
        value = self.cells(sheet, row).get(col)
        if value is not None:
            return value, coordinate
        _, column_number = coordinate_to_tuple(coordinate)
        for region in self.merges.get(sheet, []):
            cmin, rmin, cmax, rmax = range_boundaries(region)
            if rmin <= row <= rmax and cmin <= column_number <= cmax:
                anchor_col = get_column_letter(cmin)
                return self.cells(sheet, rmin).get(anchor_col), f"{anchor_col}{rmin}"
        return None, coordinate


class Extractor:
    def __init__(self, source, supplementary=None):
        self.source = source
        self.supplementary = supplementary
        self.records = []
        self.coverage = []
        self.sequences = []
        self.duplicate_links = []

    def record(self, source, sheet, row, block, dataset, label, context,
               endpoint, metrics, **extra):
        identifier = design_number(label)
        control = identifier is None
        base = {"record_id": f"{source.id}:{sheet}:{block}:r{row}",
                "dataset": dataset, "source_file": source.path.name,
                "source_sha256": source.sha256, "source_sheet": sheet,
                "source_row": row, "source_block": block,
                "source_label": label, "variant_id": identifier,
                "AI_id": identifier if identifier and identifier <= 76 else None,
                "design_id": (f"AI-{identifier}" if identifier <= 76 else f"EP-{identifier}")
                             if identifier else None,
                "is_control": control, "context": context,
                "target_position": None, "endpoint": endpoint,
                "expected_product": True, "replicate": None,
                "replicate_definition": None, "batch": None,
                "sample_label": None, "source_date_literal": None,
                "culture_volume_ml": None, "culture_medium": None,
                "observation_level": "replicate", "metrics": metrics,
                "raw_qc": {}, "authoritative_activity_class": None,
                "activity_ready": False, "activity_label_status": "NOT_DERIVED",
                "quantitative_analysis_ready": not control and any(numeric(v["value"]) for v in metrics.values()),
                "model_input_ready": False,
                "eligibility_grade": "CONTROL_ONLY" if control else "QUANTITATIVE_SOURCE_AVAILABLE",
                "warnings": [], "source_metadata": {}}
        base.update(extra)
        base["group_design_id"] = base["design_id"]
        base["group_context"] = context
        base["group_assay_condition"] = "|".join(str(base.get(k)) for k in
            ["context", "design_id", "target_position", "culture_volume_ml", "culture_medium", "batch"])
        self.records.append(base)
        return base

    def metrics(self, source, sheet, row, mapping):
        return {name: source.metric(sheet, row, col, unit) for name, (col, unit) in mapping.items()}

    def quant_block(self, sheet, start, stop, block, dataset, label_col,
                    sample_col, mapping, context=MINIMAL, endpoint="flL/FlL production (source combined series)",
                    forward_label=False, **extra):
        label = None
        label_row = None
        counts = Counter()
        result = []
        for row in range(start, stop + 1):
            cells = self.source.cells(sheet, row)
            if not any(numeric(cells.get(col)) for col, _ in mapping.values()):
                continue
            if cells.get(label_col) is not None:
                label, label_row = cells[label_col], row
            elif not forward_label:
                raise ValueError(f"Missing label: {sheet}!{label_col}{row}")
            if label is None:
                raise ValueError(f"Missing initial label: {sheet}!{label_col}{row}")
            counts[str(label)] += 1
            rec = self.record(self.source, sheet, row, block, dataset, label, context,
                endpoint, self.metrics(self.source, sheet, row, mapping),
                sample_label=cells.get(sample_col), replicate=counts[str(label)],
                replicate_definition="Within-condition source replicate order; biological replication reported in paper captions",
                source_metadata={"label_cell": f"{label_col}{label_row}", "sample_cell": f"{sample_col}{row}"},
                **extra)
            if any(v["value_status"] == "NUMERIC_NEGATIVE" for v in rec["metrics"].values()):
                rec["warnings"].append("NEGATIVE_SOURCE_QUANTIFICATION_RETAINED_NOT_CLAMPED")
            result.append(rec)
        return result

    def summaries(self):
        sources = [(self.source, "Supp_FIg_S15_pLDDT_titer", "S15_minimal_summary", "Production_%_to_WT")]
        if self.supplementary:
            sources.append((self.supplementary, "Aminoacid_Sequence_FLL_Titer", "SD1_minimal_summary", "FLL production % to WT"))
        for source, sheet, dataset, endpoint in sources:
            type_value = None
            for row, cells in source.rows[sheet].items():
                identifier = design_number(cells.get("E"))
                if not identifier and not str(cells.get("E", "")).startswith("WT"):
                    continue
                if cells.get("B") is not None:
                    type_value = cells["B"]
                sequence = cells.get("D")
                if not isinstance(sequence, str):
                    raise ValueError(f"Missing sequence {sheet}!D{row}")
                sequence = "".join(sequence.split())
                seq_hash = hashlib.sha256(sequence.encode()).hexdigest()
                name = cells.get("C")
                value, anchor = source.merged_value(sheet, row, "F")
                not_assayed = isinstance(value, str) and "not tested" in value.lower()
                metric = source.metric(sheet, row, "F", "% matched WT")
                record = self.record(source, sheet, row, "summary", dataset, cells["E"], MINIMAL,
                    endpoint, {"reported_production_percent_WT": metric},
                    observation_level="reported_summary", sample_label=name,
                    target_position="T3", replicate_definition="Source summary; not an additional independent experiment",
                    eligibility_grade="NOT_ASSAYED" if not_assayed else "SUMMARY_SOURCE_AVAILABLE_RECONCILIATION_REQUIRED",
                    quantitative_analysis_ready=numeric(metric["value"]) and bool(identifier),
                    activity_label_status="SOURCE_SPECIFIC_SUMMARY_NOT_RECONCILED",
                    source_metadata={"sequence_cell": f"D{row}", "label_cell": f"E{row}",
                                     "summary_status_text": value if not_assayed else None,
                                     "summary_status_cell": anchor if not_assayed else None,
                                     "sequence_sha256": seq_hash, "sequence_name": name,
                                     "source_type_or_round": type_value})
                record["primary_published_quantitative_endpoint"] = dataset == "SD1_minimal_summary" and numeric(metric["value"]) and bool(identifier)
                record["operational_reported_nonzero"] = bool(metric["value"] > 0) if record["primary_published_quantitative_endpoint"] else None
                if dataset == "SD1_minimal_summary":
                    record["source_metadata"]["processed_source_basis"] = "Main article Fig2 caption identifies Supplementary Data 1 as processed data and Source Data as raw data"
                    if record["primary_published_quantitative_endpoint"]:
                        record["eligibility_grade"] = "PUBLISHED_QUANTITATIVE_ENDPOINT"
                        record["activity_label_status"] = "OPERATIONAL_REPORTED_NONZERO_AVAILABLE_NOT_ASSAY_CALIBRATED_ACTIVITY"
                if not_assayed:
                    record["warnings"].append("NOT_TESTED_IN_FLL_MERGED_SOURCE_ANNOTATION")
                if "*" in sequence:
                    record["warnings"].append("STOP_IN_REPORTED_SEQUENCE_EXCLUDE_FROM_INTACT_DOMAIN_COMPATIBILITY")
                    record["eligibility_grade"] = "GENOTYPE_QC_REVIEW"
                self.sequences.append({"variant_id": identifier, "AI_id": identifier if identifier and identifier <= 76 else None,
                    "source_file": source.path.name, "source_sha256": source.sha256,
                    "source_sheet": sheet, "source_row": row, "source_cell": f"D{row}",
                    "source_name": name, "sequence": sequence, "sequence_length": len(sequence),
                    "sequence_sha256": seq_hash, "contains_stop": "*" in sequence,
                    "parent_group_inferred_from_source_name": parent_from_name(name, identifier),
                    "parent_group_evidence": "Sequence-name convention, not inferred from outcome"})

    def quantitative_figures(self):
        q = {"concentration_nM": ("D", "nM"), "dilution_corrected_nM": ("E", "nM"),
             "percent_WT": ("G", "% matched WT"), "concentration_mg_L": ("I", "mg/L"),
             "source_mean_percent_WT": ("H", "% matched WT"), "source_mean_mg_L": ("J", "mg/L")}
        self.quant_block("Fig_2_flL", 3, 95, "left", "Fig2_minimal_replicates", "B", "C", q,
                         forward_label=True, batch="Measure 1", target_position="T3", culture_volume_ml=1,
                         culture_medium="succinate XPP")
        q2 = {k: (get_column_letter(ord(v[0]) - 64 + 10), v[1]) for k, v in q.items()}
        self.quant_block("Fig_2_flL", 3, 68, "right", "Fig2_minimal_replicates", "M", "L", q2,
                         batch="Measure 2", source_date_literal="2025.06.30", target_position="T3",
                         culture_volume_ml=1, culture_medium="succinate XPP")
        q3 = {"concentration_nM": ("C", "nM"), "dilution_corrected_nM": ("D", "nM"),
              "percent_WT": ("F", "% matched WT"), "concentration_mg_L": ("H", "mg/L"),
              "source_mean_percent_WT": ("G", "% matched WT"), "source_mean_mg_L": ("I", "mg/L")}
        self.quant_block("Fig_3a_vLflL", 4, 30, "main", "Fig3a_full_replicates", "A", "B", q3,
                         context=FULL, endpoint="cyclo(vLflL) (6)", batch="main", source_date_literal="06.10.25",
                         target_position="T3", culture_volume_ml=20, culture_medium="succinate XPP")
        blocks = [(7, 9, "Measure 1", "20.11.25", None), (10, 12, "Measure 1", "20.11.25", "T4"),
                  (17, 19, "Measure 2", "23.01.26", None), (20, 22, "Measure 2", "23.01.26", "T1"),
                  (27, 29, "Measure 3", "02.02.26", None), (30, 32, "Measure 3", "02.02.26", "T2"),
                  (33, 35, "Measure 3", "02.02.26", "T2"), (36, 38, "Measure 3", "02.02.26", "T4"),
                  (39, 41, "Measure 3", "02.02.26", "T4"), (42, 44, "Measure 3", "02.02.26", "T5"),
                  (45, 47, "Measure 3", "02.02.26", "T5")]
        for start, stop, batch, date, position in blocks:
            self.quant_block("Fig_6_diff_positions", start, stop, f"r{start}", "Fig6_position_replicates", "A", "B", q3,
                context=FULL, endpoint="cyclo(vLflL) (6)", batch=batch, source_date_literal=date,
                target_position=position, culture_volume_ml=20, culture_medium="succinate XPP")
        # The concentration and total-yield blocks repeat the same samples.
        # Keep one record per sample, link duplicate cells, add the yield fields.
        seen = {}
        for start, stop, volume, side, yield_block in [(6, 17, 1, "left", False), (22, 33, 20, "left", False),
                (40, 51, 50, "left", False), (120, 134, 1, "left", True),
                (138, 152, 20, "left", True), (120, 134, 50, "right", True)]:
            cols = ("A", "B", "G", "H", "I", "J", "K") if side == "left" else ("L", "M", "R", "S", "T", "U", "V")
            lab, sample, nm, corr, mgl, total, mean = cols
            for row in range(start, stop + 1):
                cells = self.source.cells("Fig_3b_Scale_dependant", row)
                sample_name = cells[sample]
                mapping = {"concentration_nM": (nm, "nM"), "dilution_corrected_nM": (corr, "nM"), "concentration_mg_L": (mgl, "mg/L")}
                if yield_block:
                    mapping.update({"total_yield_mg": (total, "mg"), "source_mean_total_yield_mg": (mean, "mg")})
                else:
                    mapping["source_mean_mg_L"] = (total, "mg/L")
                metrics = self.metrics(self.source, "Fig_3b_Scale_dependant", row, mapping)
                if sample_name in seen:
                    existing = seen[sample_name]
                    for name in ["concentration_nM", "dilution_corrected_nM", "concentration_mg_L"]:
                        a, b = existing["metrics"][name]["value"], metrics[name]["value"]
                        if not math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-10):
                            raise ValueError(f"Inconsistent duplicate sample {sample_name}: {name}")
                    for name, metric in metrics.items():
                        if name not in existing["metrics"]:
                            existing["metrics"][name] = metric
                    self.duplicate_links.append({"record_id": existing["record_id"], "sample_label": sample_name,
                        "source_sheet": "Fig_3b_Scale_dependant", "duplicate_row": row,
                        "duplicate_block": side, "duplicate_metrics": metrics,
                        "reason": "Same sample ID and same concentrations; not a new replicate"})
                    continue
                rec = self.record(self.source, "Fig_3b_Scale_dependant", row, side,
                    "Fig3b_culture_scale_replicates", cells[lab], FULL, "cyclo(vLflL) (6)", metrics,
                    target_position="T3", culture_volume_ml=volume, culture_medium="LB", batch=f"LB_{volume}mL",
                    sample_label=sample_name, replicate=int(sample_name.rsplit("_", 1)[-1]),
                    replicate_definition="Sample-label suffix; biological replication reported in caption")
                if any(v["value_status"] == "NUMERIC_NEGATIVE" for v in metrics.values()):
                    rec["warnings"].append("NEGATIVE_SOURCE_QUANTIFICATION_RETAINED_NOT_CLAMPED")
                seen[sample_name] = rec

    def hybrids(self):
        sheet = "Fig_7_Hybrid_system"
        blocks = [(8, 10, 27, "GxhS-1", 9, 10), (35, 37, 54, "GxhS-1", 11, 12),
                  (62, 64, 81, "GxhS-1", 13, 14), (89, 91, 108, "GxhS-1", 15, None),
                  (116, 118, 135, "GshS", 16, 17), (143, 145, 162, "GshS", 18, 19),
                  (170, 172, 189, "GshS", 20, 21), (197, 198, 215, "GshS", 22, None),
                  (224, 226, 258, "GxhS-2", 23, 24), (265, 267, 299, "GxhS-2", 25, 26)]
        for header, start, stop, context, left_id, right_id in blocks:
            for peptide_id, label_col, value_col, mean_col, sd_col in [(left_id, "B", "C", "D", "E"), (right_id, "G", "H", "I", "J")]:
                if peptide_id is None:
                    continue
                mapping = {"peak_area": (value_col, "instrument peak-area units"),
                           "source_mean_peak_area": (mean_col, "instrument peak-area units"),
                           "source_sd_peak_area": (sd_col, "instrument peak-area units")}
                records = self.quant_block(sheet, start, stop, f"peptide{peptide_id}", "Fig7_hybrid_replicates",
                    label_col, label_col, mapping, context=context, endpoint=self.source.cells(sheet, header)[label_col],
                    forward_label=True, expected_product=peptide_id in {9, 16, 23}, batch=f"Fig7_{context}",
                    target_position=CONTEXT_POSITION[context],
                    eligibility_grade="DIAGNOSTIC_QUANTITATIVE_PEAK_AREA_QC_REQUIRED")
                for rec in records:
                    rec["source_metadata"]["peptide_number"] = peptide_id
                    rec["source_metadata"]["peptide_header_cell"] = f"{label_col}{header}"
                    rec["sample_label"] = rec["source_label"]
                    if rec["is_control"]:
                        rec["eligibility_grade"] = "CONTROL_ONLY"
                        if context in {"GshS", "GxhS-2"}:
                            rec["warnings"].append("SOURCE_WT_GXPS_T3_LABEL_DIFFERS_FROM_CONTEXT_NATIVE_DOMAIN_DESCRIPTION")
                    if rec["AI_id"] == 70 and peptide_id == 23:
                        rec["warnings"].append("POSITIVE_SOURCE_AREA_DOES_NOT_ESTABLISH_PUBLISHED_EXPECTED_PRODUCT_DETECTION")

    def eppcr(self):
        sheet = "Supplementary_Fig_S4_ErrorProne"
        layouts = [("left", "D", "C", "E", "F", "H", "I", "J", "K", "2025.06.30"),
                   ("middle", "O", "N", "P", "Q", "S", "T", "U", "V", "2025.07.04"),
                   ("right", "AA", "Z", "AB", "AC", "AE", "AF", "AG", "AH", "2025.07.10")]
        for block, label, sample, nm, corr, pct, meanpct, mgl, meanmgl, date in layouts:
            mapping = {"concentration_nM": (nm, "nM"), "dilution_corrected_nM": (corr, "nM"),
                       "percent_WT": (pct, "% matched WT"), "source_mean_percent_WT": (meanpct, "% matched WT"),
                       "concentration_mg_L": (mgl, "mg/L"), "source_mean_mg_L": (meanmgl, "mg/L")}
            records = self.quant_block(sheet, 3, max(self.source.rows[sheet]), block, "S4_eppcr_replicates", label, sample, mapping,
                batch=f"S4_{date}", source_date_literal=date, target_position="T3",
                eligibility_grade="QUANTITATIVE_SOURCE_AVAILABLE_SEQUENCE_AND_ANCESTRY_JOIN_REQUIRED")
            for record in records:
                if record["AI_id"] == 11:
                    # The source labels O136/O137 say 11, while their sample
                    # names continue EP_ESM2_1_x40_5 from ID111 at O135.
                    # Keep the two observations but do not silently repair IDs.
                    if block != "middle" or record["source_row"] not in {136, 137}:
                        raise ValueError("Unexpected S4 source ID11; inspect before mapping")
                    record["source_metadata"].update({"source_variant_id": 11,
                        "candidate_variant_id_from_sample_name": 111,
                        "candidate_evidence": "O135=111; N135:N137 are EP_ESM2_1_x40_5 replicates; SD1 ID111 is the corresponding named mutant"})
                    record.update({"variant_id": None, "AI_id": None, "design_id": None,
                        "group_design_id": None, "is_control": False,
                        "group_assay_condition": f"UNRESOLVED_SOURCE_ID|{record['record_id']}",
                        "eligibility_grade": "SOURCE_ID_CONFLICT", "quantitative_analysis_ready": False})
                    record["warnings"].append("SOURCE_LABEL_11_CONFLICTS_WITH_MUTANT_SAMPLE_NAME_CANDIDATE_111_NO_AUTOMATIC_REPAIR")
                elif record["AI_id"] is not None:
                    record["is_control"] = True
                    record["source_metadata"]["control_role"] = "parent_AI_reference_in_epPCR_assay"
                    record["eligibility_grade"] = "CONTROL_ONLY"
                    record["quantitative_analysis_ready"] = False
                elif record["is_control"]:
                    record["source_metadata"]["control_role"] = "native_WT_reference_in_epPCR_assay"
                    record["eligibility_grade"] = "CONTROL_ONLY"

    def screens(self):
        measures = {
            "positive_height": ("J", "instrument peak-height units"), "positive_area": ("K", "instrument peak-area units"),
            "positive_retention_time": ("L", "min, source header; values require method reconciliation"),
            "positive_mass_error": ("M", "ppm"), "positive_control_height": ("P", "instrument peak-height units"),
            "positive_background_subtracted_height": ("Q", "instrument peak-height units"),
            "negative_height": ("U", "instrument peak-height units"), "negative_area": ("V", "instrument peak-area units"),
            "negative_retention_time": ("W", "min, source header; values require method reconciliation"),
            "negative_mass_error": ("X", "ppm"), "negative_control_height": ("AA", "instrument peak-height units"),
            "negative_background_subtracted_height": ("AB", "instrument peak-height units"),
        }
        self.s14_expected = []
        for context, (sheet, expected) in S14.items():
            present = set()
            headers = self.source.cells(sheet, 1)
            for row, cells in self.source.rows[sheet].items():
                if row == 1 or "E" not in cells:
                    continue
                identifier = design_number(cells.get("D"))
                rec = self.record(self.source, sheet, row, "screen", "S14_hybrid_screen", cells.get("D", cells.get("C")),
                    context, cells["E"], self.metrics(self.source, sheet, row, measures),
                    expected_product=cells["E"] == expected, observation_level="screen_well_analyte",
                    target_position=CONTEXT_POSITION[context],
                    sample_label=cells.get("C"), batch=str(cells.get("A")),
                    replicate_definition="One source well per design/context; multiple peptides and ion modes are not replicates",
                    quantitative_analysis_ready=False, eligibility_grade="DIAGNOSTIC_ONLY_ACTIVITY_QC_UNRESOLVED",
                    activity_label_status="RAW_DETECTION_FLAGS_ARE_NOT_AUTHORITATIVE_ACTIVITY",
                    raw_qc={headers.get(c, c): {"value": cells.get(c), "cell": f"{c}{row}"}
                            for c in ["R", "S", "AC", "AD", "AE", "AF", "AG", "AH"]},
                    source_metadata={"plate": cells.get("A"), "well": cells.get("B"),
                        "raw_cells": {c: cells.get(c) for c in headers}, "raw_headers": headers,
                        "control_role": "native_WT_candidate" if str(cells.get("C", "")).startswith("WT_") else
                                        "alternative_native_domain_control" if not identifier else None})
                if not identifier:
                    rec["eligibility_grade"] = "CONTROL_ONLY_QC_UNRESOLVED"
                if cells.get("AH") is False:
                    rec["warnings"].append("SOURCE_BIOMASS_FLAG_FALSE")
                if any(v["value_status"] == "NUMERIC_NEGATIVE" for k, v in rec["metrics"].items() if "background_subtracted" in k):
                    rec["warnings"].append("NEGATIVE_BACKGROUND_SUBTRACTED_SOURCE_HEIGHT_RETAINED")
                if identifier and cells["E"] == expected:
                    if identifier in present:
                        raise ValueError(f"Duplicate S14 expected product: {context}, {identifier}")
                    present.add(identifier)
                    self.s14_expected.append(rec)
            for identifier in range(1, 77):
                if identifier not in present:
                    missing = {"record_id": f"source_data:{sheet}:missing:AI{identifier}", "dataset": "S14_hybrid_screen",
                        "AI_id": identifier, "variant_id": identifier, "design_id": f"AI-{identifier}",
                        "context": context, "endpoint": expected, "expected_product": True,
                        "target_position": CONTEXT_POSITION[context],
                        "source_file": self.source.path.name, "source_sha256": self.source.sha256,
                        "source_sheet": sheet, "source_row": None, "observation_level": "missing_condition_placeholder",
                        "metrics": {}, "raw_qc": {}, "eligibility_grade": "ABSENT_SOURCE_ROW",
                        "authoritative_activity_class": None, "activity_ready": False,
                        "quantitative_analysis_ready": False, "model_input_ready": False,
                        "warnings": ["Absent source row; not a measured nondetection"], "is_control": False}
                    self.s14_expected.append(missing)

    def derive_coverage(self):
        minimal = [r for r in self.records if r["dataset"] == "Fig2_minimal_replicates" and not r["is_control"]]
        for identifier in range(1, 67):
            rows = [r for r in minimal if r["AI_id"] == identifier]
            self.coverage.append({"dataset": "Fig2_minimal_replicates", "context": MINIMAL,
                "AI_id": identifier, "target_position": "T3", "replicate_count": len(rows),
                "source_records": [r["record_id"] for r in rows],
                "status": "SOURCE_REPLICATES_PRESENT" if rows else "ABSENT_SOURCE_REPLICATES_SUMMARY_MAY_EXIST"})
        positions = [r for r in self.records if r["dataset"] == "Fig6_position_replicates" and not r["is_control"]]
        for identifier in [2, 12, 38]:
            for position in ["T1", "T2", "T4", "T5"]:
                rows = [r for r in positions if r["AI_id"] == identifier and r["target_position"] == position]
                self.coverage.append({"dataset": "Fig6_position_replicates", "context": FULL,
                    "AI_id": identifier, "target_position": position, "replicate_count": len(rows),
                    "source_records": [r["record_id"] for r in rows],
                    "status": "SOURCE_REPLICATES_PRESENT" if rows else "ABSENT_SOURCE_ROWS_NOT_FABRICATED_ZEROES"})

    def reconciliation(self):
        s15 = {r["variant_id"]: r for r in self.records if r["dataset"] == "S15_minimal_summary" and not r["is_control"]}
        sd1 = {r["variant_id"]: r for r in self.records if r["dataset"] == "SD1_minimal_summary" and not r["is_control"]}
        fig2 = defaultdict(list)
        for rec in self.records:
            if rec["dataset"] == "Fig2_minimal_replicates" and not rec["is_control"]:
                fig2[rec["AI_id"]].append(rec)
        result = []
        for identifier in range(1, 67):
            a = s15[identifier]["metrics"]["reported_production_percent_WT"]["value"]
            b = sd1.get(identifier, {}).get("metrics", {}).get("reported_production_percent_WT", {}).get("value")
            vals = [r["metrics"]["percent_WT"]["value"] for r in fig2[identifier] if numeric(r["metrics"]["percent_WT"]["value"])]
            c = sum(vals) / len(vals) if vals else None
            result.append({"AI_id": identifier, "S15_percent_WT": a, "SD1_percent_WT": b,
                "Fig2_replicate_mean_percent_WT": c, "Fig2_replicate_count": len(vals),
                "SD1_minus_S15": b-a if numeric(b) else None,
                "SD1_equals_rounded_S15": round(a) == b if numeric(b) else None,
                "S15_zero_SD1_nonzero_disagreement": (a == 0) != (b == 0) if numeric(b) else None,
                "S15_zero_Fig2_mean_nonzero_disagreement": (a == 0) != (c == 0) if numeric(c) else None,
                "S15_record_id": s15[identifier]["record_id"],
                "SD1_record_id": sd1.get(identifier, {}).get("record_id"),
                "Fig2_record_ids": [r["record_id"] for r in fig2[identifier]],
                "resolution": "SD1_IS_PUBLISHED_PROCESSED_ENDPOINT_PER_FIG2_CAPTION; NUMERICAL_DISCREPANCIES_RETAINED" if self.supplementary else "SUPPLEMENTARY_DATA1_NOT_PROVIDED"})
        self.summary_reconciliation = result
        raw = defaultdict(list)
        for r in self.records:
            if r["dataset"] == "S4_eppcr_replicates" and r["variant_id"] and r["variant_id"] >= 77:
                raw[r["variant_id"]].append(r)
        seqs = {r["variant_id"]: r for r in self.sequences if self.supplementary and r["source_file"] == self.supplementary.path.name}
        self.eppcr_catalog = []
        for identifier in range(77, 259):
            seq = seqs.get(identifier, {})
            report = sd1.get(identifier)
            raw_values = [r["metrics"]["percent_WT"]["value"] for r in raw[identifier]
                          if numeric(r["metrics"]["percent_WT"]["value"])]
            raw_mean = sum(raw_values) / len(raw_values) if raw_values else None
            summary_value = report["metrics"]["reported_production_percent_WT"]["value"] if report else None
            zero_conflict = (raw_mean == 0) != (summary_value == 0) if numeric(raw_mean) and numeric(summary_value) else None
            if zero_conflict:
                report["warnings"].append("RAW_REPLICATE_VS_PUBLISHED_SUMMARY_ZERO_NONZERO_CONFLICT")
            self.eppcr_catalog.append({"variant_id": identifier, "design_id": f"EP-{identifier}",
                "raw_replicate_rows": len(raw[identifier]), "raw_record_ids": [r["record_id"] for r in raw[identifier]],
                "raw_source_status": "PRESENT" if raw[identifier] else "ABSENT_SOURCE_ROWS_NOT_A_ZERO_LABEL",
                "summary_record_id": report["record_id"] if report else None,
                "summary_percent_WT": summary_value,
                "raw_mean_percent_WT": raw_mean,
                "raw_mean_replicate_count": len(raw_values),
                "raw_batches": sorted({r["batch"] for r in raw[identifier]}),
                "processed_equals_rounded_raw_mean": round(raw_mean) == summary_value if numeric(raw_mean) and numeric(summary_value) else None,
                "raw_processed_zero_nonzero_conflict": zero_conflict,
                "unresolved_rows_with_this_id_as_candidate": sum(r["source_metadata"].get("candidate_variant_id_from_sample_name") == identifier for r in self.records),
                "operational_reported_nonzero": report.get("operational_reported_nonzero") if report else None,
                "sequence_available": bool(seq), "sequence_sha256": seq.get("sequence_sha256"),
                "sequence_contains_stop": seq.get("contains_stop"), "sequence_length": seq.get("sequence_length"),
                "parent_group": seq.get("parent_group_inferred_from_source_name"),
                "parent_group_evidence": "source sequence-name convention; methods corroboration required",
                "model_input_ready": False})

    def run(self):
        self.summaries()
        self.quantitative_figures()
        self.hybrids()
        self.eppcr()
        self.screens()
        self.derive_coverage()
        self.reconciliation()
        if len({r["record_id"] for r in self.records}) != len(self.records):
            raise ValueError("Record ID collision")
        expected_observed = [r for r in self.s14_expected if r["source_row"] is not None]
        assert len(expected_observed) == 300 and len(self.s14_expected) == 304
        assert sum(r["raw_replicate_rows"] > 0 for r in self.eppcr_catalog) == 139
        assert len([r for r in self.coverage if r["dataset"] == "Fig2_minimal_replicates" and r["replicate_count"]]) == 51
        assert len([r for r in self.coverage if r["dataset"] == "Fig6_position_replicates" and r["replicate_count"]]) == 8
        if self.supplementary:
            assert sum(r["sequence_available"] for r in self.eppcr_catalog) == 182
            assert all(r["parent_group"] for r in self.eppcr_catalog)

    def save(self, output):
        output.mkdir(parents=True, exist_ok=True)
        with (output / "assay_records.jsonl").open("w", encoding="utf-8") as handle:
            for rec in self.records:
                handle.write(json.dumps(rec, ensure_ascii=False, allow_nan=False) + "\n")
        write_csv(output / "assay_records.csv", self.records)
        long_rows = []
        for rec in self.records:
            for name, value in rec["metrics"].items():
                long_rows.append({"record_id": rec["record_id"], "dataset": rec["dataset"],
                    "variant_id": rec["variant_id"], "context": rec["context"], "endpoint": rec["endpoint"],
                    "source_file": rec["source_file"], "source_sheet": rec["source_sheet"],
                    "source_row": rec["source_row"], "metric": name, **value,
                    "independence_warning": "Metrics, summaries, and ion modes are not independent assay conditions"})
        write_csv(output / "assay_measurements_long.csv", long_rows)
        write_csv(output / "source_sequences.csv", self.sequences)
        write_csv(output / "minimal_summary_reconciliation.csv", self.summary_reconciliation)
        write_csv(output / "condition_coverage.csv", self.coverage)
        write_csv(output / "s14_expected_product_matrix.csv", self.s14_expected)
        write_csv(output / "eppcr_catalog.csv", self.eppcr_catalog)
        write_csv(output / "source_id_conflicts.csv", [r for r in self.records if r["eligibility_grade"] == "SOURCE_ID_CONFLICT"])
        write_csv(output / "published_minimal_endpoints.csv", [
            {"variant_id": r["variant_id"], "design_id": r["design_id"], "context": r["context"],
             "target_position": r["target_position"], "processed_percent_WT": r["metrics"]["reported_production_percent_WT"]["value"],
             "operational_reported_nonzero": r["operational_reported_nonzero"],
             "source_record_id": r["record_id"], "source_file": r["source_file"],
             "source_sheet": r["source_sheet"], "source_cell": r["metrics"]["reported_production_percent_WT"]["cell"],
             "sequence_sha256": r["source_metadata"]["sequence_sha256"], "eligibility_grade": r["eligibility_grade"],
             "warnings": r["warnings"], "endpoint_status": "Published processed quantitative production endpoint; nonzero indicator is not calibrated activity probability or interface compatibility"}
            for r in self.records if r.get("primary_published_quantitative_endpoint")])
        write_csv(output / "duplicate_source_links.csv", self.duplicate_links)
        for dataset in sorted({r["dataset"] for r in self.records}):
            write_csv(output / f"{dataset}.csv", [r for r in self.records if r["dataset"] == dataset])
        if self.supplementary:
            write_csv(output / "supplementary_constructs_raw.csv", [
                {"source_file": self.supplementary.path.name, "source_sheet": "Constructs", "source_row": row,
                 "raw_cells": cells} for row, cells in self.supplementary.rows["Constructs"].items()])
        by_dataset = {}
        for dataset in sorted({r["dataset"] for r in self.records}):
            records = [r for r in self.records if r["dataset"] == dataset]
            by_dataset[dataset] = {"observation_rows": len(records), "control_rows": sum(r["is_control"] for r in records),
                "unique_variant_ids": len({r["variant_id"] for r in records if r["variant_id"]}),
                "unique_variant_context_position_conditions": len({(r["variant_id"], r["context"], r["target_position"], r["culture_volume_ml"], r["culture_medium"]) for r in records if r["variant_id"]}),
                "expected_product_noncontrol_rows": sum(not r["is_control"] and r["expected_product"] for r in records)}
        summary = {"status": "ASSAY_EXTRACTION_COMPLETE_ACTIVITY_QC_NOT_RESOLVED", "version": VERSION,
            "source_files": [{"file": src.path.name, "sha256": src.sha256} for src in [self.source, self.supplementary] if src],
            "record_count_not_independent_training_count": len(self.records), "by_dataset": by_dataset,
            "s14_expected_observed_rows": 300, "s14_missing_expected_rows": 4,
            "s14_missing_conditions": [{"context": r["context"], "AI_id": r["AI_id"]} for r in self.s14_expected if r["source_row"] is None],
            "eppcr_observed_raw_ids": 139, "eppcr_missing_raw_ids": 43,
            "source_id_conflicted_raw_rows": sum(r["eligibility_grade"] == "SOURCE_ID_CONFLICT" for r in self.records),
            "eppcr_summary_and_sequences_available": sum(r["sequence_available"] for r in self.eppcr_catalog),
            "eppcr_parent_groups": dict(Counter(r["parent_group"] for r in self.eppcr_catalog)),
            "eppcr_raw_processed_zero_conflict_ids": [r["variant_id"] for r in self.eppcr_catalog if r["raw_processed_zero_nonzero_conflict"]],
            "eppcr_nonzero_processed_without_raw_ids": [r["variant_id"] for r in self.eppcr_catalog if not r["raw_replicate_rows"] and numeric(r["summary_percent_WT"]) and r["summary_percent_WT"] > 0],
            "published_processed_minimal_endpoints": sum(bool(r.get("primary_published_quantitative_endpoint")) for r in self.records),
            "published_processed_minimal_nonzero": sum(r.get("operational_reported_nonzero") is True for r in self.records),
            "S15_SD1_beyond_integer_rounding": sum(r["SD1_equals_rounded_S15"] is False for r in self.summary_reconciliation),
            "S15_SD1_zero_disagreement_ids": [r["AI_id"] for r in self.summary_reconciliation if r["S15_zero_SD1_nonzero_disagreement"]],
            "S15_Fig2_zero_disagreement_ids": [r["AI_id"] for r in self.summary_reconciliation if r["S15_zero_Fig2_mean_nonzero_disagreement"]],
            "activity_ready_rows": sum(r["activity_ready"] for r in self.records),
            "model_input_ready_rows": sum(r["model_input_ready"] for r in self.records),
            "not_claimed": ["578 independent training examples", "raw S14 detection flags are published activity classes", "blank intensity means zero", "unobserved assay condition is inactive", "assay correlations identify a causal failed interface"],
            "remaining_blockers": ["SD1 is the published processed minimal endpoint per Fig2 caption; S15/Fig2 numerical disagreements remain preserved and unexplained",
                "Reconcile S14 peak/background/WT normalization and biomass QC with Methods before deriving activity",
                "Join each design to the correct complete construct sequence and domain boundaries",
                "Stop/truncated genotypes require a separate failure class, not intact-domain compatibility labels"]}
        write_json(output / "summary.json", summary)
        write_json(output / "SCHEMA.json", {"version": VERSION,
            "canonical_file": "assay_records.jsonl", "one_row_means": "One source replicate/analyte, reported summary, or screen-well/analyte; inspect observation_level",
            "source_preservation": "Original workbooks are read only. Values are not recalculated; cached formulas and exact cell coordinates are retained. Numeric zero, negative, blank, uncached formula, and text are distinct.",
            "missing_conditions": "S14 missing placeholders occur only in s14_expected_product_matrix.csv; Fig2/Fig6 absent raw conditions are in condition_coverage.csv. They are not measurements.",
            "summaries": "Summary values are retained as metrics on a replicate record, or as clearly tagged source summaries. They must not become extra training rows.",
            "replicate": "Within-condition source order, not a newly created experiment; S14 has no invented replicate index.",
            "quantitative_analysis_ready": "Source has numeric assay information for a design, subject to source/method reconciliation and condition matching. This does not mean calibrated detection, model-input readiness or independent generalization.",
            "eligibility_grades": {"QUANTITATIVE_SOURCE_AVAILABLE": "Use within documented matched assay context; preserve replicate hierarchy", "SUMMARY_SOURCE_AVAILABLE_RECONCILIATION_REQUIRED": "Compare source versions before selecting one outcome table", "DIAGNOSTIC_ONLY_ACTIVITY_QC_UNRESOLVED": "Preserve raw peak fields; no published-class claim", "NOT_ASSAYED": "Explicit merged source annotation, not zero", "ABSENT_SOURCE_ROW": "No source record, not nondetection", "GENOTYPE_QC_REVIEW": "Stop or truncated genotype must be handled separately", "CONTROL_ONLY": "Normalization/QC, not a novel AI training example"},
            "recommended_grouping": ["Keep identical design/sequence, all replicates, analytes, modes, source-summary copies and culture repeats in one fold",
                "For epPCR, group by WT/AI-2/AI-12/AI-15 parental lineage and sequence similarity; do not randomly split mutant rows",
                "For context transfer, explicitly hold out a construct context and disclose which design sequences occur in training",
                "For novel-design transfer, hold out sequence clusters across all contexts; design ID alone does not remove near-duplicate leakage"],
            "activity_labels": "authoritative_activity_class remains null; raw S14 QC fields and quantitative source summaries remain separately available",
            "published_minimal_endpoint": "Supplementary Data 1 processed percent WT is primary, based on Fig2 caption. published_minimal_endpoints.csv contains 66 original AI designs and 182 epPCR variants when Supplementary Data 1 is supplied. operational_reported_nonzero is only the transparent indicator processed_percent_WT > 0; it is not a calibrated activity or compatibility label.",
            "FLL_not_assayed": "AI67–76 inherit the explicit Not tested in flL merged-cell annotation in Supplementary Data 1, never a zero phenotype"})
        return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, required=True, help="Directory containing original Source_data.xlsx")
    parser.add_argument("--supplementary-data", type=Path, help="Original Supplementary Data 1 XLSX")
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    source = Source(args.source_dir / "Source_data.xlsx", "source_data")
    supplementary = Source(args.supplementary_data, "supplementary_data1") if args.supplementary_data else None
    extractor = Extractor(source, supplementary)
    extractor.run()
    summary = extractor.save(args.output_dir)
    for src in [source, supplementary]:
        if src:
            if hash_file(src.path) != src.sha256:
                raise RuntimeError(f"Source changed during extraction: {src.path}")
            src.book.close()
    print(json.dumps({"status": summary["status"], "records": len(extractor.records),
                      "s14_expected": 300, "s14_missing": 4, "eppcr_raw_ids": 139,
                      "eppcr_sequence_ids": summary["eppcr_summary_and_sequences_available"]}))


if __name__ == "__main__":
    main()
