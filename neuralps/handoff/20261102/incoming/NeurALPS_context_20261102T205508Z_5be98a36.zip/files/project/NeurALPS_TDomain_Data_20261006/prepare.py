#!/usr/bin/env python3
"""Rebuild the curated T-domain dataset from the untouched publisher files."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
REQUIRED = {
    "Source_data.xlsx",
    "Acceptor, native plasmids.gb",
    "AI T-domain for CE context.gb",
    "AI T-domain for C context.gb",
    "FigS10_alignment_full.fasta",
    "FigS10_alignment_half.fasta",
}


def check_sources():
    checked = []
    for record in json.loads((ROOT / "provenance/sources.json").read_text()):
        name = record.get("file") or record.get("local_file")
        if not name:
            continue
        path = ROOT / name
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != record["sha256"]:
            raise ValueError(f"Source checksum mismatch: {name}")
        checked.append(name)
    return checked


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "prepared")
    args = parser.parse_args()
    checked = check_sources()
    destination = args.output_dir.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    if any(destination.iterdir()):
        parser.error("Output directory must be empty: use a new path to preserve an existing dataset.")
    supp = ROOT / "raw/41467_2026_77963_MOESM3_ESM.xlsx"
    with tempfile.TemporaryDirectory(prefix="neur_alps_tdomain_") as temporary:
        extracted = Path(temporary)
        with zipfile.ZipFile(ROOT / "raw/41467_2026_77963_MOESM6_ESM.zip") as archive:
            for expected in sorted(REQUIRED):
                matches = [n for n in archive.namelist()
                           if Path(n).name == expected and "__MACOSX" not in Path(n).parts]
                if len(matches) != 1:
                    raise ValueError(f"Expected exactly one {expected!r}, got {matches}")
                # No archive path is used as a local path: avoid path traversal.
                (extracted / expected).write_bytes(archive.read(matches[0]))
        for script, directory in [("prepare_sequences.py", "sequence_data"),
                                  ("prepare_assays.py", "assay_data"),
                                  ("prepare_hybrids.py", "hybrid_data")]:
            command = [sys.executable, str(ROOT / script), "--source-dir", str(extracted),
                            "--supplementary-data", str(supp), "--output-dir",
                            str(destination / directory)]
            if script == "prepare_sequences.py":
                command.append("--selftest")
            subprocess.run(command, check=True)
    subprocess.run([sys.executable, str(ROOT / "integrate.py"), "--data-dir", str(destination)], check=True)
    print(json.dumps({"status": "DATA_PREPARATION_COMPLETE", "output": str(destination),
                      "verified_original_sources": len(checked)}))


if __name__ == "__main__":
    main()
