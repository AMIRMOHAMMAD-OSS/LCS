#!/usr/bin/env python3
"""Reconstruct the 20 documented hybrid T-domain constructs from PCR adapters.

These are in-silico reconstructions of the deposited GenBank sequence versions,
not confirmation of finished-clone sequencing. No assay outcomes are inferred.
"""
import argparse
import json
from pathlib import Path
import re
from prepare_sequences import (read_genbank, read_fasta, source_versions,
                               match_in_dna, translate, sha, write_json, write_fasta, write_csv)

CE_IDS=(2,12,27,31,32)
INSERT_NAMES={2:'Test-ESM2',12:'1_-_ATC_evodiff_gen_21_-_3',27:'1_-_ll_guidance-WT_-_3',
              31:'1_-_ll_guidance-IN2_-_3',32:'1_-_Test-IN1-improved_-_3'}
for number,name in enumerate(('evodiff_gen_65','evodiff_gen_154','evodiff_gen_177','evodiff_gen_298',
    'esm3_str_gen_388','esm3_str_gen_404','esm3_str_gen_459','esm3_str_gen_461','esm3_str_gen_706','esm3_str_gen_728'),67):
    INSERT_NAMES[number]='pCK_KG_'+name
CONTEXTS=(
    dict(context='GxhS-1',native='Gxps_Xtps_1(GX_1)',acceptor='Gxps_Xtps_1(GX_1)_T3_SacB_acceptor',
         ids=CE_IDS,primer_rows=range(60,65),construct_rows=range(289,294),native_source_row=287,
         target_domain='GxpS_T3',target_native_nt_1based=[13348,13545],expected_aa=4139),
    dict(context='GshS',native='Gxps_Szes(GS)',acceptor='Gxps_Szes(GS)_T4_SacB_acceptor',
         ids=CE_IDS,primer_rows=range(86,91),construct_rows=range(308,313),native_source_row=306,
         target_domain='SzeS_T4_in_hybrid',target_native_nt_1based=[13348,13557],expected_aa=5200),
    dict(context='GxhS-2',native='Gxps_Xtps_2(GX_2)',acceptor='Gxps_Xtps_2(GX_2)_T2_SacB_acceptor',
         ids=range(67,77),primer_rows=range(70,80),construct_rows=range(296,306),native_source_row=294,
         target_domain='GxpS_T2',target_native_nt_1based=[10180,10380],expected_aa=4169))


def require(ok,message):
    if not ok:raise ValueError(message)


def revcomp(dna):return dna.translate(str.maketrans('ACGT','TGCA'))[::-1]


def site(dna,motif):
    matches=[m.start() for m in re.finditer('(?='+motif+')',dna)]
    require(len(matches)==1,'Need one exact site: '+motif)
    return matches[0]


def primer_match(primer,template,reverse=False):
    matches=[]
    for n in range(8,len(primer)+1):
        target=revcomp(primer[-n:]) if reverse else primer[-n:]
        positions=[m.start() for m in re.finditer('(?='+target+')',template)]
        if positions:matches.append((n,positions))
    require(bool(matches),'No exact primer suffix match')
    length,positions=matches[-1]
    require(len(positions)==1,'Ambiguous primer suffix placement')
    return dict(length=length,start_0based=positions[0],end_0based_exclusive=positions[0]+length)


def orf(dna):
    start=5220
    require(dna[start:start+3]=='ATG','Actual hybrid initiation codon missing')
    rotated=dna[start:]+dna[:start]
    stops=[i for i in range(0,len(rotated)-2,3) if rotated[i:i+3] in ('TAA','TAG','TGA')]
    require(bool(stops),'No complete stop codon')
    stop=stops[0]
    require((start+stop)%len(dna)==0 and rotated[stop:stop+3]=='TGA','Premature or unexpected terminal stop')
    amino,ambiguities=translate(rotated[:stop])
    require(not ambiguities and '*' not in amino,'Ambiguous/intact ORF failure')
    return dict(amino_acids=amino,amino_acid_sha256=sha(amino),length=len(amino),
                coding_dna=rotated[:stop+3],coding_dna_sha256=sha(rotated[:stop+3]),
                coding_dna_1based_inclusive_segments=[[5221,len(dna)],[1,3]],
                stop_codon='TGA',stop_1based_circular=[1,3],actual_start_1based=5221,
                start_basis='Shared RBS-associated ATG at5221; partial NRPS feature starts5224/5395 are not used.')


def prepare(source_dir,supplementary,output_dir):
    output_dir.mkdir(parents=True,exist_ok=True)
    require(not any(output_dir.iterdir()),'Use an empty hybrid output directory')
    filenames=('Acceptor, native plasmids.gb','AI T-domain for CE context.gb','AI T-domain for C context.gb')
    records={}
    for filename in filenames:
        for r in read_genbank(source_dir/filename):
            require(r['record_id'] not in records,'Duplicate source record')
            records[r['record_id']]=r
    versions,tables=source_versions(source_dir,supplementary)
    primers={r['row']:r['cells'] for r in tables['Primers']}
    constructs={r['row']:r['cells'] for r in tables['Constructs']}
    alignment=read_fasta(source_dir/'FigS10_alignment_full.fasta')
    output=[];controls=[]
    for ctx in CONTEXTS:
        native=records[ctx['native']]['dna'];acceptor=records[ctx['acceptor']]['dna']
        aleft=site(acceptor,'GAGACC')-5;aright=site(acceptor,'GGTCTC')+7
        require(0<aleft<aright<len(acceptor),'Wrong acceptor orientation')
        # Entire annotated SacB coding segment lies between these cut positions.
        sacb_interval=[13758,15180] if ctx['context']!='GxhS-2' else [10590,12012]
        require(aleft<=sacb_interval[0]<sacb_interval[1]<=aright,'SacB not completely removed')
        control_key='WT|context='+ctx['context']
        controls.append(dict(construct_id=control_key,fasta_key=control_key,context=ctx['context'],
            variant_id='WT',role='native_hybrid_reference',source_plasmid=ctx['native'],
            source_construct_sheet='Constructs',source_construct_row=ctx['native_source_row'],
            target_domain=ctx['target_domain'],target_native_nt_1based_inclusive=ctx['target_native_nt_1based'],
            source_plasmid_sha256=sha(native),activity_label_implied=False,sequenced_clone_verified=False,
            primary_sequence_eligible=True,model_scoring_ready=False,
            status='NATIVE_HYBRID_ORF_ROUTE_ANNOTATION_PENDING',**orf(native)))
        for number,p_row,c_row in zip(ctx['ids'],ctx['primer_rows'],ctx['construct_rows']):
            aid='AI_'+str(number);insert=records[INSERT_NAMES[number]];dna=insert['dna']
            core=alignment[aid].replace('-','')
            require(len(match_in_dna(core,dna))==1,'AI/insert mapping lacks a unique exact source sequence')
            conflicts=[v['version_id'] for v in versions if v['variant_id']==aid and not match_in_dna(v['amino_acids'],dna)]
            pcells=primers[p_row];seqcells=[(k,v) for k,v in pcells.items() if 'F:' in str(v) and 'R:' in str(v)]
            require(len(seqcells)==1,'Missing/ambiguous primer cell')
            column,value=seqcells[0];pairs=re.findall(r'[FR]:\s*([ACGT]+)',str(value))
            require(len(pairs)==2,'Need full forward and reverse primer sequences')
            forward,reverse=pairs;fmatch=primer_match(forward,dna);rmatch=primer_match(reverse,dna,True)
            require(fmatch['end_0based_exclusive']<=rmatch['start_0based'],'Primer binding sites overlap')
            amplicon=forward+dna[fmatch['end_0based_exclusive']:rmatch['start_0based']]+revcomp(reverse)
            ileft=site(amplicon,'GGTCTC')+7;iright=site(amplicon,'GAGACC')-5
            require(0<ileft<iright<len(amplicon),'Wrong insert orientation')
            ends=[amplicon[ileft:ileft+4],amplicon[iright:iright+4]]
            require(ends==[acceptor[aleft:aleft+4],acceptor[aright:aright+4]],'Noncognate cohesive ends')
            fragment=amplicon[ileft:iright]
            ligated=acceptor[:aleft]+fragment+acceptor[aright:]
            require('GGTCTC' not in ligated and 'GAGACC' not in ligated,'Residual BsaI sites')
            protein=orf(ligated)
            require(protein['length']==ctx['expected_aa'],'Unexpected full hybrid ORF length')
            require(protein['amino_acids'].count(core)==1,'Inserted source core not retained exactly once')
            core_start=protein['amino_acids'].index(core)
            key=aid+'|context='+ctx['context']
            output.append(dict(construct_id=key,fasta_key=key,variant_id=aid,ai_id=aid,context=ctx['context'],
                target_domain=ctx['target_domain'],role='engineered_hybrid',insert_record=insert['record_id'],
                insert_source_file=insert['source_file'],insert_dna_sha256=sha(dna),
                native_plasmid=ctx['native'],acceptor_plasmid=ctx['acceptor'],acceptor_dna_sha256=sha(acceptor),
                source_construct_sheet='Constructs',source_construct_row=c_row,source_construct_cells=constructs[c_row],
                primer_provenance=dict(source_file=supplementary.name,sheet='Primers',row=p_row,
                    sequence_cell=column+str(p_row),source_cells=pcells,forward=forward,reverse=reverse,
                    forward_match=fmatch,reverse_match=rmatch,match_scope='Exact suffix uniqueness within deposited insert; full pEX plasmid unavailable'),
                cohesive_ends=ends,acceptor_removed_nt_0based_halfopen=[aleft,aright],
                removed_sacb_nt_0based_halfopen=sacb_interval,
                amplicon_kept_nt_0based_halfopen=[ileft,iright],amplicon_sha256=sha(amplicon),
                ligated_plasmid_nt=len(ligated),ligated_plasmid_sha256=sha(ligated),
                inserted_nt_in_plasmid_0based_halfopen=[aleft,aleft+len(fragment)],
                inserted_nt_in_coding_sequence_0based_halfopen=[aleft-5220,aleft-5220+len(fragment)],
                candidate_source_core_aa_0based_halfopen=[core_start,core_start+len(core)],
                candidate_source_core_amino_acid_sha256=sha(core),
                interval_note='Ligation cuts may split a codon; source-core interval is not an inferred model domain annotation.',
                conflicting_version_ids=conflicts,primary_sequence_eligible=not conflicts,
                status='BLOCKED_SOURCE_SEQUENCE_CONFLICT' if conflicts else 'IN_SILICO_PRIMER_LIGATION_VERIFIED_ROUTE_ANNOTATION_PENDING',
                model_scoring_ready=False,model_scoring_blockers=['Project-compatible domain annotation and feature extraction remain pending.']+
                    (['Conflicting amino-acid source version; retain only as a labeled GenBank reconstruction.'] if conflicts else []),
                sequenced_clone_verified=False,activity_label_implied=False,**protein))
    require(len(output)==20 and len(controls)==3,'Wrong planned hybrid count')
    write_json(output_dir/'hybrid_constructs.json',output)
    write_json(output_dir/'native_hybrid_controls.json',controls)
    write_fasta(output_dir/'hybrid_all_GenBank_versions.fasta',[(r['fasta_key'],r['amino_acids']) for r in output])
    write_fasta(output_dir/'hybrid_primary_sequence_subset.fasta',[(r['fasta_key'],r['amino_acids']) for r in output if r['primary_sequence_eligible']])
    write_fasta(output_dir/'hybrid_NRPS_coding_DNA.fasta',[(r['fasta_key'],r['coding_dna']) for r in output])
    write_fasta(output_dir/'native_hybrid_controls.fasta',[(r['fasta_key'],r['amino_acids']) for r in controls])
    write_csv(output_dir/'hybrid_constructs.csv',output,['construct_id','ai_id','context','insert_record','length',
        'amino_acid_sha256','status','primary_sequence_eligible','conflicting_version_ids','model_scoring_ready','source_construct_row'])
    sources=[source_dir/f for f in filenames]+[source_dir/'FigS10_alignment_full.fasta',source_dir/'Source_data.xlsx',supplementary]
    report=dict(status='HYBRID_RECONSTRUCTION_COMPLETE',engineered_constructs=20,native_controls=3,
        primary_engineered_sequences=sum(r['primary_sequence_eligible'] for r in output),
        excluded_conflicts=[r['construct_id'] for r in output if not r['primary_sequence_eligible']],
        model_scoring_ready=False,sequenced_clone_verified=False,activity_labels_inferred=False,
        reconstruction='Published full PCR primers, unique exact suffix placement, matching BsaI cohesive ends, complete circular NRPS ORF and exact retained candidate core.',
        limitations=['No finished-clone sequencing confirmation.','Full pEX template vectors unavailable; annealing uniqueness verified within deposited insert only.',
                    'GenBank and supplementary sequence conflicts remain separate.','No model domain annotation or phenotype inference.'],
        sources_sha256={p.name:sha(p.read_bytes()) for p in sources},
        files_sha256={p.name:sha(p.read_bytes()) for p in sorted(output_dir.iterdir())
                      if p.is_file() and p.name!='manifest.json'})
    write_json(output_dir/'manifest.json',report)
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-dir',required=True,type=Path)
    p.add_argument('--supplementary-data',required=True,type=Path)
    p.add_argument('--output-dir',required=True,type=Path)
    args=p.parse_args();print(json.dumps(prepare(args.source_dir,args.supplementary_data,args.output_dir),sort_keys=True))


if __name__=='__main__':main()
