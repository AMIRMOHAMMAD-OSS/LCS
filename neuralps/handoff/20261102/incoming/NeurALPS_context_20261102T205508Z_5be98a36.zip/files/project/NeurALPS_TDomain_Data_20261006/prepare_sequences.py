#!/usr/bin/env python3
"""Prepare versioned T-domain sequences and conservative construct inputs.

Standard library only. No assay outcomes are used to choose sequence versions.
Original plasmid DNA and annotation errors are retained. No conflicting residue
or ambiguous nucleotide is silently repaired. Output is a sequence preparation
stage; the established NRPS domain annotation/embedding pipeline remains needed.
"""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import itertools
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zipfile


GENBANK_FILES = ["AI T-domain for CE context.gb", "AI T-domain for C context.gb", "Acceptor, native plasmids.gb"]
FASTA_FILES = ["FigS10_alignment_full.fasta", "FigS10_alignment_half.fasta"]
AA = set("ACDEFGHIKLMNPQRSTVWY")
IUPAC = dict(zip("ACGTRYSWKMBDHVN", ["A", "C", "G", "T", "AG", "CT", "CG", "AT", "GT", "AC", "CGT", "AGT", "ACT", "ACG", "ACGT"]))
CODE = dict(zip([a+b+c for a in "TCAG" for b in "TCAG" for c in "TCAG"], "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"))


def sha(data):
    return hashlib.sha256(data.encode() if isinstance(data, str) else data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+"\n")


def write_csv(path, rows, fields):
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, sort_keys=True) if isinstance(v, (list, dict)) else v for k, v in row.items()})


def write_fasta(path, rows):
    with path.open("w") as handle:
        for name, sequence in rows:
            handle.write(">"+name+"\n")
            for i in range(0, len(sequence), 80):
                handle.write(sequence[i:i+80]+"\n")


def read_fasta(path):
    result = {}
    for entry in path.read_text().split(">"):
        if not entry.strip():
            continue
        name, *lines = entry.splitlines()
        sequence = "".join("".join(lines).split()).upper()
        if name in result or not sequence or set(sequence)-AA-{"-", "X", "*"}:
            raise ValueError("Invalid/duplicate FASTA record: "+name)
        result[name] = sequence
    return result


def workbook_rows(path, wanted):
    """Read cached XLSX values, preserving source cell coordinates."""
    main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    relns = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    q = lambda name: "{"+main+"}"+name
    with zipfile.ZipFile(path) as archive:
        strings = []
        if "xl/sharedStrings.xml" in archive.namelist():
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            strings = ["".join(t.text or "" for t in si.iter(q("t"))) for si in root.findall(q("si"))]
        relationships = {r.attrib["Id"]: r.attrib["Target"] for r in ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))}
        sheets = ET.fromstring(archive.read("xl/workbook.xml")).find(q("sheets"))
        result = {}
        for sheet in sheets:
            name = sheet.attrib["name"]
            if name not in wanted:
                continue
            target = relationships[sheet.attrib["{"+relns+"}id"]]
            target = target.lstrip("/") if target.startswith("/") else "xl/"+target
            xml = ET.fromstring(archive.read(target))
            rows = []
            for row in xml.iter(q("row")):
                cells = {}
                for cell in row.findall(q("c")):
                    address = cell.attrib["r"]
                    typ = cell.attrib.get("t")
                    element = cell.find(q("v"))
                    value = element.text if element is not None else None
                    if typ == "s" and value is not None:
                        value = strings[int(value)]
                    elif typ == "inlineStr":
                        value = "".join(t.text or "" for t in cell.iter(q("t")))
                    elif value is not None and typ not in ("str", "e"):
                        number = float(value)
                        value = int(number) if number.is_integer() else number
                    if value is not None:
                        cells[re.match(r"[A-Z]+", address)[0]] = value
                rows.append({"row": int(row.attrib["r"]), "cells": cells})
            result[name] = rows
    return result


def normalized_location(raw, length):
    """Retain raw location and report conservative circular-coordinate repairs."""
    intervals, issues = [], []
    for a, b in re.findall(r"[<>]?(\d+)\.\.[<>]?(\d+)", raw):
        a, b = int(a), int(b)
        if a > length and 1 <= a-length <= b <= length:
            a -= length
            issues.append("START_EXCEEDS_LENGTH_SUBTRACTED_ONE_CIRCULAR_LENGTH")
        if not (1 <= a <= length and 1 <= b <= length):
            issues.append("UNRESOLVED_OUT_OF_RANGE_LOCATION")
            continue
        intervals.extend([(a-1, b)] if a <= b else [(a-1, length), (0, b)])
    if not intervals:
        issues.append("NO_SUPPORTED_INTERVAL")
    if any(a < d and c < b for i, (a, b) in enumerate(intervals) for c, d in intervals[i+1:]):
        issues.append("OVERLAPPING_LOCATION_PARTS")
    return {"raw_location": raw, "intervals_0based_half_open": [list(x) for x in intervals], "strand": -1 if raw.startswith("complement(") else 1, "fuzzy": "<" in raw or ">" in raw, "issues": sorted(set(issues))}


def read_genbank(path):
    records = []
    for raw_record in re.split(r"^//\s*$", path.read_text(), flags=re.M):
        if not raw_record.strip():
            continue
        locus = raw_record.strip().splitlines()[0].split()
        name, length = locus[1], int(locus[2])
        dna = re.sub("[^A-Za-z]", "", raw_record.split("ORIGIN", 1)[1]).upper()
        if len(dna) != length or set(dna)-set(IUPAC):
            raise ValueError("Invalid GenBank DNA: "+name)
        raw_features = re.split(r"\n     (?=\S)", raw_record.split("FEATURES", 1)[1].split("ORIGIN", 1)[0])[1:]
        features = []
        for index, raw in enumerate(raw_features):
            typ, location = raw.splitlines()[0].split(None, 1)
            qualifiers = defaultdict(list)
            for item in re.split(r"\n                     /", raw)[1:]:
                key, _, value = item.partition("=")
                qualifiers[key].append(" ".join(value.strip().strip('"').split()))
            labels = qualifiers.get("label") or qualifiers.get("standard_name") or qualifiers.get("gene") or qualifiers.get("product") or [""]
            features.append({"index": index, "type": typ, "name": labels[0], "qualifiers": dict(qualifiers), **normalized_location(location, length)})
        definition = re.search(r"^DEFINITION\s+(.*?)^ACCESSION", raw_record, flags=re.M|re.S)
        records.append({"record_id": name, "source_file": path.name, "dna": dna, "length": length, "dna_sha256": sha(dna), "topology": locus[5], "definition": " ".join(definition[1].split()) if definition else "", "features": features})
    if len({r["record_id"] for r in records}) != len(records):
        raise ValueError("Duplicate GenBank record names")
    return records


def translate(dna):
    protein, ambiguities = [], []
    for start in range(0, len(dna)-2, 3):
        codon = dna[start:start+3]
        options = sorted({CODE["".join(c)] for c in itertools.product(*(IUPAC[n] for n in codon))})
        residue = options[0] if len(options) == 1 else "X"
        protein.append(residue)
        if set(codon)-set("ACGT"):
            ambiguities.append({"codon_index_0based": start//3, "codon": codon, "possible_amino_acids": options, "emitted_residue": residue})
    return "".join(protein), ambiguities


def source_versions(source_dir, supplementary):
    versions, tables = [], {}
    original = source_dir / "Source_data.xlsx"
    if original.exists():
        rows = workbook_rows(original, {"Supp_FIg_S15_pLDDT_titer"})
        for row in rows.get("Supp_FIg_S15_pLDDT_titer", []):
            cells = row["cells"]
            if isinstance(cells.get("E"), int) and isinstance(cells.get("D"), str):
                versions.append({"version_id": "source_data_s15_row_"+str(row["row"]), "source_file": original.name, "source_sheet": "Supp_FIg_S15_pLDDT_titer", "source_row": row["row"], "source_sequence_cell": "D"+str(row["row"]), "variant_id": "AI_"+str(cells["E"]), "numeric_id": cells["E"], "sequence_name": cells.get("C", ""), "group": "Source_data_S15", "raw_amino_acids": cells["D"]})
    if supplementary:
        tables = workbook_rows(supplementary, {"Aminoacid_Sequence_FLL_Titer", "Constructs", "Primers"})
        group = ""
        for row in tables.get("Aminoacid_Sequence_FLL_Titer", []):
            cells = row["cells"]
            if cells.get("B"):
                group = str(cells["B"])
            if "D" not in cells or "E" not in cells or cells["E"] == "Label":
                continue
            identifier = cells["E"]
            if isinstance(identifier, int):
                variant_id = ("AI_" if identifier <= 76 else "VAR_")+str(identifier)
            elif identifier == "WT GxpS_T3":
                variant_id = "WT_GxpS_T3"
            else:
                raise ValueError("Unrecognized supplementary sequence identifier: "+str(identifier))
            versions.append({"version_id": "supplement_sequence_row_"+str(row["row"]), "source_file": supplementary.name, "source_sheet": "Aminoacid_Sequence_FLL_Titer", "source_row": row["row"], "source_sequence_cell": "D"+str(row["row"]), "variant_id": variant_id, "numeric_id": identifier if isinstance(identifier, int) else None, "sequence_name": cells.get("C", ""), "group": group, "raw_amino_acids": str(cells["D"])})
    for row in versions:
        aa = "".join(row["raw_amino_acids"].split()).upper()
        row.update(amino_acids=aa, amino_acid_sha256=sha(aa), length=len(aa), stop_positions_1based=[i+1 for i, c in enumerate(aa) if c == "*"], nonstandard_residues=sorted(set(aa)-AA-{"*"}))
        row["status"] = "STOP_OR_TRUNCATION" if "*" in aa or (row.get("numeric_id", 0) or 0) > 76 and len(aa) < 115 else "NONSTANDARD_RESIDUE" if row["nonstandard_residues"] else "PRESERVED_SEQUENCE_VERSION"
        row["eligible_for_direct_intact_domain_graft"] = False
        row["eligibility_note"] = "No epPCR sequence is automatically grafted; stop/length variants retain original phenotype scope and require construct-level DNA verification."
    return versions, tables


def match_in_dna(amino_acids, dna):
    matches = []
    for frame in range(3):
        protein, _ = translate(dna[frame:])
        start = protein.find(amino_acids)
        while start >= 0:
            matches.append({"dna_start_0based": frame+3*start, "dna_end_0based_exclusive": frame+3*(start+len(amino_acids)), "frame_0based": frame})
            start = protein.find(amino_acids, start+1)
    return matches


def nearest_translated_span(amino_acids, dna):
    """Report a unique short mismatch without changing or selecting a sequence."""
    candidates = []
    for frame in range(3):
        protein, _ = translate(dna[frame:])
        for start in range(len(protein)-len(amino_acids)+1):
            actual = protein[start:start+len(amino_acids)]
            distance = sum(a != b for a, b in zip(actual, amino_acids))
            candidates.append((distance, frame+3*start, actual))
    candidates.sort()
    if not candidates or candidates[0][0] > 3 or len(candidates) > 1 and candidates[1][0] == candidates[0][0]:
        return None
    distance, start, actual = candidates[0]
    return {"dna_start_0based": start, "dna_end_0based_exclusive": start+3*len(amino_acids), "mismatch_count": distance, "residue_disagreements": [{"position_in_source_span_1based": i+1, "DNA_encoded": a, "source_version": b} for i, (a, b) in enumerate(zip(actual, amino_acids)) if a != b], "status": "DIAGNOSTIC_ALIGNMENT_ONLY_NO_CORRECTION"}


def domain_hint(name):
    label = name.strip()
    if "linker" in label.lower():
        return None
    if re.fullmatch(r"T\d+", label):
        return "PCP"
    if re.fullmatch(r"A\d+(?:\s+.*)?", label):
        return "AMP-binding"
    if re.fullmatch(r"C/E\d+", label):
        return "Condensation_Dual"
    if re.fullmatch(r"C\d+", label):
        return "Condensation_UNRESOLVED_SUBTYPE"
    if label == "TE":
        return "Thioesterase"
    if re.match(r"E\d", label):
        return "Epimerization"
    return None


def extract_nrps_candidates(record):
    """Find stop-delimited forward ORFs anchored by the paper's domain features.

    Start calls without an exact ATG NRPS annotation remain explicitly inferred.
    Native sequence extraction is separate from model-compatible domain calling.
    """
    if "sacb" in record["record_id"].lower():
        return []
    anchors = []
    for feature in record["features"]:
        if feature["strand"] != 1 or domain_hint(feature["name"]) is None:
            continue
        for start, end in feature["intervals_0based_half_open"]:
            if end > start and (end-start) % 3 == 0:
                anchors.append((start, end, feature))
    if not anchors:
        return []
    votes = Counter(a % 3 for a, _, _ in anchors)
    frame = votes.most_common(1)[0][0]
    dna = record["dna"]
    extended = dna+dna[:3]
    stops = [i for i in range(frame, len(extended)-2, 3) if extended[i:i+3] in {"TAA", "TAG", "TGA"}]
    previous = frame-3
    chains = []
    for stop in stops:
        segment_start = previous+3
        contained = [(a, b, f) for a, b, f in anchors if segment_start <= a < b <= stop and a % 3 == frame]
        previous = stop
        if not contained or stop-segment_start < 300:
            continue
        first_domain = min(a for a, _, _ in contained)
        starts = [i for i in range(segment_start, first_domain+1, 3) if extended[i:i+3] == "ATG"]
        if not starts:
            continue
        chosen = starts[0]
        exact_annotation = any(f["type"] == "NRPS" and not f["fuzzy"] and [chosen, next((b for a, b in f["intervals_0based_half_open"] if a == chosen), -1)] in f["intervals_0based_half_open"] for f in record["features"])
        coding = extended[chosen:stop]
        protein, ambiguities = translate(coding)
        assert protein and protein[0] == "M" and "*" not in protein
        chain_id = record["record_id"]+"|nrps_chain="+str(len(chains)+1)
        projected = []
        for start, end, feature in contained:
            if start < chosen:
                continue
            projected.append({"source_feature_index": feature["index"], "source_feature_name": feature["name"], "source_location": feature["raw_location"], "location_issues": feature["issues"], "amino_acid_start_0based": (start-chosen)//3, "amino_acid_end_0based_exclusive": (end-chosen)//3, "canonical_type_hint": domain_hint(feature["name"]), "source": "paper_manual_annotation_not_antismash"})
        chains.append({"chain_id": chain_id, "parent_plasmid": record["record_id"], "dna_start_0based": chosen, "dna_end_0based_exclusive": stop, "stop_codon": extended[stop:stop+3], "stop_wraps_circular_origin": stop >= len(dna), "start_basis": "exact_ATG_NRPS_annotation" if exact_annotation else "first_ATG_in_stop_bounded_frame_with_NRPS_domain_anchors", "start_requires_confirmation": not exact_annotation, "amino_acids": protein, "amino_acid_sha256": sha(protein), "dna_sha256": sha(coding), "length": len(protein), "ambiguities": ambiguities, "status": "AMBIGUOUS_CODING_SEQUENCE" if "X" in protein else "NRPS_ORF_SEQUENCE_EXTRACTED", "model_scoring_ready": False, "model_scoring_blocker": "Run established domain annotation and embedding preparation; paper manual domain cuts are not assumed equivalent to pretraining domain cuts.", "paper_domain_annotations": projected})
    return chains


def reconstruct_t3(acceptor, native, insert):
    """BsaI overhang-verified ligation for the main GxpS T3 context only."""
    dna, fragment = acceptor["dna"], insert["dna"]
    forward = [m.start() for m in re.finditer("GGTCTC", dna)]
    reverse = [m.start() for m in re.finditer("GAGACC", dna)]
    if len(forward) != 1 or len(reverse) != 1 or not (fragment.startswith("GGTCTCA") and fragment.endswith("GAGACC")):
        raise ValueError("T3 BsaI evidence is not unique")
    left_cut, right_cut = reverse[0]-5, forward[0]+7
    if not left_cut < right_cut:
        raise ValueError("Unexpected T3 cassette orientation")
    left, right = fragment[7:11], fragment[-11:-7]
    if dna[left_cut:left_cut+4] != left or dna[right_cut:right_cut+4] != right:
        raise ValueError("Insert/acceptor cohesive ends do not match")
    assembled = dna[:left_cut]+fragment[7:-11]+dna[right_cut:]
    core_start, core_end = left_cut+4, left_cut+4+len(fragment[11:-11])
    # Independent native reference verifies the NRPS ORF flanks, including the
    # immediate A/T and T/C context. Backbone differences are reported separately.
    native_chain = extract_nrps_candidates(native)
    if len(native_chain) != 1:
        raise ValueError("Main native T3 context has no unique NRPS ORF")
    chain = native_chain[0]
    start, end = chain["dna_start_0based"], chain["dna_end_0based_exclusive"]
    if not (start < core_start < core_end < end):
        raise ValueError("Replacement is not internal to native NRPS ORF")
    if assembled[start:core_start] != native["dna"][start:core_start] or assembled[core_end:end] != native["dna"][core_end:end]:
        raise ValueError("Reconstructed T3 ORF flanks differ from native reference")
    protein, ambiguities = translate(assembled[start:end])
    if ambiguities or "*" in protein or protein[0] != "M" or assembled[end:end+3] not in {"TAA", "TAG", "TGA"}:
        raise ValueError("Reconstructed T3 ORF is not intact and unambiguous")
    return {"dna": assembled, "amino_acids": protein, "amino_acid_sha256": sha(protein), "dna_sha256": sha(assembled), "protein_length": len(protein), "dna_start_0based": start, "dna_end_0based_exclusive": end, "insert_core_interval_0based_half_open": [core_start, core_end], "acceptor_cut_positions_0based": [left_cut, right_cut], "cohesive_ends": {"left": left, "right": right}, "native_nrps_flanks_exact_match": True, "paper_domain_annotations": chain["paper_domain_annotations"], "native_start_basis": chain["start_basis"]}


def prepare(source_dir, output_dir, supplementary_data=None):
    source_dir, output_dir = Path(source_dir), Path(output_dir)
    supplementary = Path(supplementary_data) if supplementary_data else None
    output_dir.mkdir(parents=True, exist_ok=True)
    full = read_fasta(source_dir/FASTA_FILES[0])
    half = read_fasta(source_dir/FASTA_FILES[1])
    assert len(full) == len(half) == 129 and set(full) == set(half)
    assert {name for name in full if name.startswith("AI_")} == {"AI_"+str(i) for i in range(1, 77)}
    ungapped = {name: seq.replace("-", "") for name, seq in full.items()}
    assert all(half[name].replace("-", "") in sequence for name, sequence in ungapped.items())
    gb = {name: read_genbank(source_dir/name) for name in GENBANK_FILES}
    assert [len(gb[name]) for name in GENBANK_FILES] == [66, 10, 16]
    inserts = gb[GENBANK_FILES[0]]+gb[GENBANK_FILES[1]]
    templates = gb[GENBANK_FILES[2]]
    versions, supplementary_tables = source_versions(source_dir, supplementary)
    by_id = defaultdict(list)
    for row in versions:
        by_id[row["variant_id"]].append(row)
    name_ids = defaultdict(set)
    for row in versions:
        name_ids[row["sequence_name"].strip()].add(row["variant_id"])
    designs = []
    insert_by_ai = {}
    for insert in inserts:
        matches = [(name, match) for name, aa in ungapped.items() if name.startswith("AI_") for match in match_in_dna(aa, insert["dna"])]
        if len(matches) == 1:
            aid, span = matches[0]
            mapping_basis = "exact_translated_DNA_substring_to_full_FASTA"
        else:
            named = name_ids[insert["record_id"]] & set(ungapped)
            if len(named) != 1:
                raise ValueError("Cannot map ambiguous insert identity: "+insert["record_id"])
            aid = next(iter(named))
            span = {"dna_start_0based": 11, "dna_end_0based_exclusive": len(insert["dna"])-11, "frame_0based": 2}
            mapping_basis = "explicit_workbook_sequence_name_match_conflicting_amino_acids"
        if aid in insert_by_ai:
            raise ValueError("Duplicate AI mapping: "+aid)
        insert_by_ai[aid] = insert
        fasta_version = {"version_id": aid+"_FigS10_full", "variant_id": aid, "source_file": FASTA_FILES[0], "source_record": aid, "amino_acids": ungapped[aid], "amino_acid_sha256": sha(ungapped[aid]), "length": len(ungapped[aid]), "status": "ALIGNED_SOURCE_SPAN"}
        all_versions = [fasta_version]+by_id[aid]
        comparisons = []
        conflicts = []
        translated_core, _ = translate(insert["dna"][11:-11])
        for version in all_versions:
            aa = version["amino_acids"]
            hits = match_in_dna(aa, insert["dna"]) if aa else []
            comp = {"version_id": version["version_id"], "source_file": version["source_file"], "length": len(aa), "amino_acid_sha256": sha(aa), "matches_insert_translation": bool(hits), "matching_DNA_intervals": hits}
            if not hits:
                conflicts.append(version["version_id"])
                if len(aa) == len(translated_core):
                    comp["residue_disagreements_against_insert_core"] = [{"position_1based": i+1, "DNA_encoded": a, "source_version": b} for i, (a, b) in enumerate(zip(translated_core, aa)) if a != b]
                else:
                    comp["comparison_note"] = "No exact translated substring; do not choose a trimming or sequence correction automatically."
                comp["unique_nearby_translated_span"] = nearest_translated_span(aa, insert["dna"])
            comparisons.append(comp)
        designs.append({"ai_id": aid, "numeric_id": int(aid.split("_")[1]), "insert_record": insert["record_id"], "insert_source_file": insert["source_file"], "insert_length_nt": insert["length"], "insert_dna_sha256": insert["dna_sha256"], "mapping_basis": mapping_basis, "full_fasta_length_aa": len(ungapped[aid]), "FASTA_DNA_span": span, "core_amino_acids": translated_core, "core_amino_acid_sha256": sha(translated_core), "core_length_aa": len(translated_core), "sequence_versions": all_versions, "version_comparisons": comparisons, "conflicting_version_ids": conflicts, "status": "SOURCE_SEQUENCE_CONFLICT" if conflicts else "INSERT_TRANSLATION_VERSIONS_CONCORDANT", "scoring_ready": False, "intended_context_family": "CE" if int(aid.split("_")[1]) <= 66 else "C", "flL_assay_missing_is_zero": False})
    designs.sort(key=lambda x: x["numeric_id"])
    assert len(insert_by_ai) == 76

    native_chains = [chain for template in templates for chain in extract_nrps_candidates(template)]
    by_name = {r["record_id"]: r for r in templates}
    native = by_name["pJW76_pCOLA_ara_tacI_II_Gxps"]
    acceptor = by_name["pJW76_T3_SacB_acceptor"]
    reconstructed = []
    for design in designs:
        if design["numeric_id"] > 66:
            continue
        build = reconstruct_t3(acceptor, native, insert_by_ai[design["ai_id"]])
        reconstruct_id = design["ai_id"]+"|context=minimal_GxpS_T3"
        reconstructed.append({"construct_id": reconstruct_id, "ai_id": design["ai_id"], "context": "minimal_GxpS_T3", "parent_native_plasmid": native["record_id"], "acceptor_plasmid": acceptor["record_id"], "insert_record": design["insert_record"], "status": "SEQUENCE_VERIFIED_ROUTE_ANNOTATION_PENDING" if not design["conflicting_version_ids"] else "BLOCKED_SOURCE_SEQUENCE_CONFLICT", "primary_sequence_eligible": not design["conflicting_version_ids"], "model_scoring_ready": False, "model_scoring_blockers": ["Project-compatible domain annotation and feature cache are not yet prepared."]+(["Conflicting source amino-acid sequence versions require resolution."] if design["conflicting_version_ids"] else []), "reconstruction_basis": "Unique acceptor BsaI cut pair, exact cohesive-end match, intact translated ORF and exact native NRPS sequence outside insert interval. Biological sequence source remains the supplied GenBank, with conflicting records withheld from primary set.", **build})
    jobs = []
    for template in templates:
        if "sacb" in template["record_id"].lower() and template["record_id"] != acceptor["record_id"]:
            jobs.append({"acceptor_plasmid": template["record_id"], "status": "BLOCKED_CONTEXT_SPECIFIC_RECONSTRUCTION", "blockers": ["Verify assayed variant-to-context/position mapping and context-specific primer/overhang modifications before ligation."]+(["pCK parental FitS A4 DNA contains nonsynonymous ambiguities."] if template["record_id"].startswith("pCK") else []), "do_not_score_sacb_template_as_inactive_construct": True})

    # Output source sequences unchanged; version IDs prevent accidental merging.
    write_fasta(output_dir/"full_alignment.fasta", full.items())
    write_fasta(output_dir/"half_alignment.fasta", half.items())
    write_fasta(output_dir/"reference_and_ai_ungapped.fasta", ungapped.items())
    write_fasta(output_dir/"insert_DNA.fasta", [(r["record_id"], r["dna"]) for r in inserts])
    write_fasta(output_dir/"plasmid_DNA_preserved.fasta", [(r["record_id"], r["dna"]) for r in templates])
    write_fasta(output_dir/"supplementary_sequence_versions.fasta", [(r["version_id"]+"|variant="+r["variant_id"]+"|status="+r["status"], r["amino_acids"]) for r in versions])
    write_fasta(output_dir/"native_NRPS_ORF_candidates.fasta", [(r["chain_id"]+"|status="+r["status"], r["amino_acids"]) for r in native_chains])
    write_fasta(output_dir/"reconstructed_T3_all_GenBank_versions.fasta", [(r["construct_id"]+"|status="+r["status"], r["amino_acids"]) for r in reconstructed])
    write_fasta(output_dir/"reconstructed_T3_DNA_GenBank_versions.fasta", [(r["construct_id"]+"|status="+r["status"], r["dna"]) for r in reconstructed])
    write_fasta(output_dir/"reconstructed_T3_primary_sequence_subset.fasta", [(r["construct_id"], r["amino_acids"]) for r in reconstructed if r["primary_sequence_eligible"]])
    alignment_rows = [{"source_record": name, "is_AI_design": name.startswith("AI_"), "full_alignment_length": len(full[name]), "full_ungapped_length": len(ungapped[name]), "full_ungapped_sha256": sha(ungapped[name]), "half_alignment_length": len(half[name]), "half_ungapped_length": len(half[name].replace("-", "")), "half_ungapped_sha256": sha(half[name].replace("-", "")), "half_span_start_in_full_0based": ungapped[name].index(half[name].replace("-", "")), "natural_reference_context_suffix": name.rsplit("_", 1)[1] if not name.startswith("AI_") else None, "activity_label_implied": False} for name in full]
    write_json(output_dir/"alignment_records.json", alignment_rows)
    write_csv(output_dir/"alignment_records.csv", alignment_rows, list(alignment_rows[0]))
    write_json(output_dir/"ai_designs.json", designs)
    write_csv(output_dir/"ai_designs.csv", designs, ["ai_id", "insert_record", "insert_source_file", "insert_length_nt", "insert_dna_sha256", "mapping_basis", "full_fasta_length_aa", "core_length_aa", "status", "conflicting_version_ids", "intended_context_family", "scoring_ready"])
    write_json(output_dir/"supplementary_sequence_versions.json", versions)
    write_csv(output_dir/"supplementary_sequence_versions.csv", versions, ["version_id", "variant_id", "numeric_id", "sequence_name", "group", "source_file", "source_sheet", "source_row", "source_sequence_cell", "raw_amino_acids", "amino_acids", "amino_acid_sha256", "length", "stop_positions_1based", "nonstandard_residues", "status", "eligible_for_direct_intact_domain_graft"])
    write_json(output_dir/"plasmid_annotations.json", [{k: v for k, v in r.items() if k != "dna"} for r in templates])
    write_json(output_dir/"insert_annotations.json", [{k: v for k, v in r.items() if k != "dna"} for r in inserts])
    write_json(output_dir/"native_NRPS_ORF_candidates.json", native_chains)
    write_csv(output_dir/"native_NRPS_ORF_candidates.csv", native_chains, ["chain_id", "parent_plasmid", "dna_start_0based", "dna_end_0based_exclusive", "stop_codon", "stop_wraps_circular_origin", "start_basis", "start_requires_confirmation", "length", "amino_acid_sha256", "status", "ambiguities", "model_scoring_ready"])
    write_json(output_dir/"reconstructed_T3_constructs.json", [{k: v for k, v in r.items() if k != "dna"} for r in reconstructed])
    write_json(output_dir/"other_context_reconstruction_jobs.json", jobs)
    # Only design/genotype/primer columns are retained here; quantitative assay
    # ingestion belongs to the independently versioned assay preparation stage.
    write_json(output_dir/"supplementary_construct_and_primer_evidence.json", {name: rows for name, rows in supplementary_tables.items() if name in {"Constructs", "Primers"}})
    inputs = [source_dir/name for name in GENBANK_FILES+FASTA_FILES]
    if (source_dir/"Source_data.xlsx").exists():
        inputs.append(source_dir/"Source_data.xlsx")
    if supplementary:
        inputs.append(supplementary)
    summary = {
        "schema": "nrps_tdomain_sequences_v1",
        "status": "SEQUENCE_PREPARATION_COMPLETE_WITH_EXPLICIT_BLOCKERS",
        "source_files": {p.name: {"sha256": sha(p.read_bytes()), "bytes": p.stat().st_size} for p in inputs},
        "counts": {"AI_designs": len(designs), "insert_records_CE": len(gb[GENBANK_FILES[0]]), "insert_records_C": len(gb[GENBANK_FILES[1]]), "plasmids": len(templates), "sacb_acceptors": sum("sacb" in r["record_id"].lower() for r in templates), "natural_alignment_references": 53, "source_sequence_versions": len(versions), "supplement_numeric_variants": sum(r["source_sheet"] == "Aminoacid_Sequence_FLL_Titer" and r["numeric_id"] is not None for r in versions), "supplement_stop_or_truncation_versions": sum(r["source_sheet"] == "Aminoacid_Sequence_FLL_Titer" and r["status"] == "STOP_OR_TRUNCATION" for r in versions), "native_NRPS_ORF_candidates": len(native_chains), "T3_reconstructed_GenBank_genotypes": len(reconstructed), "T3_primary_sequence_eligible": sum(r["primary_sequence_eligible"] for r in reconstructed), "model_scoring_ready": 0},
        "conflicting_AI_designs": [r["ai_id"] for r in designs if r["conflicting_version_ids"]],
        "two_alignment_files_are_same_examples": True,
        "half_sequences_are_substrings_of_full": True,
        "no_sequence_conflict_resolved_by_guess": True,
        "no_ambiguity_resolved_by_guess": True,
        "no_activity_outcome_used_for_sequence_selection": True,
        "limitations": ["Manual paper domain annotations are exported as hints, not silently substituted for the pretraining domain definition.", "Reconstructed primary FASTA is sequence-ready; standard annotation and embedding preparation remains required before scoring.", "All source discrepancies remain versioned; source-genotype reconstructions with disagreements are withheld from the primary subset.", "pCK ambiguous DNA is preserved and translated as X only when alternatives differ; no allele is selected.", "EpPCR stop and truncation records are controls requiring full construct verification, not intact-domain graft candidates.", "C-context variants do not acquire a zero flL label when that assay is absent.", "An ORF candidate start inferred from the first ATG in its stop-bounded frame is reported as such and requires confirmation where not anchored by an exact NRPS start annotation."],
    }
    summary["output_files"] = {p.name: {"sha256": sha(p.read_bytes()), "bytes": p.stat().st_size} for p in sorted(output_dir.iterdir()) if p.is_file() and p.name != "manifest.json"}
    write_json(output_dir/"manifest.json", summary)
    return summary


def selftest(output_dir):
    """Validate prepared real-source outputs and critical pure helper contracts."""
    output_dir = Path(output_dir)
    load = lambda name: json.loads((output_dir/name).read_text())
    manifest = load("manifest.json")
    designs = load("ai_designs.json")
    variants = load("supplementary_sequence_versions.json")
    constructs = load("reconstructed_T3_constructs.json")
    chains = load("native_NRPS_ORF_candidates.json")
    assert len(designs) == 76 and {d["ai_id"] for d in designs} == {"AI_"+str(i) for i in range(1, 77)}
    by_id = {d["ai_id"]: d for d in designs}
    assert by_id["AI_4"]["status"] == "INSERT_TRANSLATION_VERSIONS_CONCORDANT"
    assert by_id["AI_48"]["status"] == "SOURCE_SEQUENCE_CONFLICT"
    supplement_rows = [r for r in variants if r["source_sheet"] == "Aminoacid_Sequence_FLL_Titer"]
    if supplement_rows:
        assert {r["numeric_id"] for r in supplement_rows if r["numeric_id"] is not None} == set(range(1, 259))
        assert by_id["AI_74"]["status"] == "SOURCE_SEQUENCE_CONFLICT"
        assert next(r for r in supplement_rows if r["numeric_id"] == 143)["status"] == "STOP_OR_TRUNCATION"
    assert all(not r["eligible_for_direct_intact_domain_graft"] for r in variants)
    assert len(constructs) == 66
    assert {r["ai_id"] for r in constructs if not r["primary_sequence_eligible"]} == {"AI_48"}
    assert all(r["native_nrps_flanks_exact_match"] and not r["model_scoring_ready"] for r in constructs)
    primary = read_fasta(output_dir/"reconstructed_T3_primary_sequence_subset.fasta")
    assert len(primary) == 65 and all("*" not in s and "X" not in s for s in primary.values())
    all_proteins = read_fasta(output_dir/"reconstructed_T3_all_GenBank_versions.fasta")
    for record in constructs:
        key = record["construct_id"]+"|status="+record["status"]
        assert all_proteins[key] == record["amino_acids"]
        assert sha(record["amino_acids"]) == record["amino_acid_sha256"]
    assert len(chains) == 9 and all("sacb" not in c["parent_plasmid"].lower() for c in chains)
    assert translate("GAKCGYGYG")[0] == "XRX"
    location = normalized_location("14032..3393", 11928)
    assert location["intervals_0based_half_open"] == [[2103, 3393]] and location["issues"]
    for value in [manifest, designs, variants, constructs, chains]:
        assert json.loads(json.dumps(value)) == value
    for name, evidence in manifest["output_files"].items():
        assert sha((output_dir/name).read_bytes()) == evidence["sha256"], name
    return {"status": "SEQUENCE_PREPARATION_SELFTEST_OK", "AI_designs": 76, "primary_T3_sequences": 65, "checks": ["all_258_supplementary_ids_if_supplied", "source_conflicts_retained", "stop_truncation_exclusion", "FASTA_hash_replay", "no_vector_sacb_chains", "ambiguity_preservation", "coordinate_repair_evidence", "JSON_roundtrip", "all_output_checksums"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--supplementary-data", type=Path)
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args()
    result = prepare(args.source_dir, args.output_dir, args.supplementary_data)
    if args.selftest:
        print(json.dumps(selftest(args.output_dir), sort_keys=True))
    print(json.dumps({"status": result["status"], "counts": result["counts"], "conflicting_AI_designs": result["conflicting_AI_designs"]}, sort_keys=True))


if __name__ == "__main__":
    main()
