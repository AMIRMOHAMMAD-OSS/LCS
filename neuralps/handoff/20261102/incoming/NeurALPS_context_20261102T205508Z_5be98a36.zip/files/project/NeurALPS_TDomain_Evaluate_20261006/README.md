# T-domain transfer of the frozen NeurALPS model

This package consumes the completed embedding run `e10_tdomain_embed_696333`.
It generates fixed predictions for 84 engineered constructs and four native
controls. It does not update ESMC, the assembly encoder, the natural reference
scale, or any classifier.

## Run on Jean Zay

Place the extracted package directly under the existing NeurALPSv2 project.
The original data, embedding, reference-scale, BODE readout and model packages
must remain there. All source files are read-only inputs.

```bash
cd /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2
unzip -n NeurALPS_TDomain_Evaluate_20261006.zip
bash NeurALPS_TDomain_Evaluate_20261006/submit.sh
bash NeurALPS_TDomain_Evaluate_20261006/status.sh
```

One A100, eight CPUs, two-hour allocation limit, scheduler-assigned memory.
No explicit Slurm memory flag is used. The two-hour limit is not a runtime
prediction. This run reuses the ESMC embeddings; it does not load ESMC again.
Each submission creates a new `e11_tdomain_transfer_JOBID` output. Existing
outputs and caches are never replaced.

## What is computed

1. **Piece compatibility:** the same frozen 26,000-step reconstruction score
   used by the original reference-scale run, for every domain and boundary.
   Exact sequence and overlapping physical context are masked using the original
   masking closure. The original natural-training means and loss are unchanged.
2. **Natural-reference percentiles:** apply the existing e8 reference unchanged.
   Unsupported percentiles stay null. These are measures of agreement with
   natural contexts, not activity probabilities.
3. **Local-only ablation:** the original decoder with the global context path
   disabled, with the same masks and loss. These raw scores receive no e8
   percentile, because that scale was fitted to full-context scores.
4. **Activity classifier transfer:** separate means of the saved 21 BODE1 donor
   classifiers and 35 BODE2 donor classifiers, using `typed_context` as the
   primary arm and `global_context` as comparator. Every individual prediction
   is retained. This is external application of existing cross-validation model
   ensembles, not a full-data refit or cross-validation on the T-domain study.
5. **Matched comparisons:** target-PCP score and mean score of the target plus
   its two adjacent boundaries, each compared with the identical topology
   positions in the native control of the same context. Other pieces are also
   retained in the full map. Missing scores are not silently averaged away.

The `typed_context_scores` arm is excluded here: its six added features came
from the older candidate-panel comparison, which is not interchangeable with
natural-reference percentiles. The typed arm already achieved the same latest
BODE2 AUROC and a slightly higher BODE1 mean AUROC. Older neural readout and
fine-tuning variants are outside this fixed first transfer run.

## Outputs

- `simple_compatibility_map.json`: assembly IDs, names/context, domains,
  boundaries, raw and supported normalized compatibility, and separate
  BODE1/BODE2-trained assembly classifier scores.
- `object_scores.csv`: all physical objects and scores.
- `assembly_scores.csv`: prespecified target/neighborhood/native comparisons.
- `classifier_predictions.json`: full provenance, individual folds and means.
- `scores/`: exact raw/scaled rows and original-schema encoder representations.
- `prediction_seal.json`: hashes fixed before collection of assay tables.
- Assay packet: original unchanged evaluation and assay records from the
  checksummed data bundle, plus source protocol and provenance.
- `summary.json`: completion and coverage, not an activity-performance claim.
- `transfer_inspection.zip`: portable inspection archive containing these files.

## What completion means

`TDOMAIN_TRANSFER_PREDICTIONS_COMPLETE` means that predictions and maps are
ready. It does **not** claim that final assay performance has been evaluated.
The original T-domain assay tables are not available in the development
workspace, so this package deliberately does not guess their label schema or
construct-to-outcome join. It collects the exact source records after sealing
predictions. Return `transfer_inspection.zip` for that review and evaluation.

The primary compatibility score and comparison arms are declared now in
`PROTOCOL.json`, before viewing target outcomes. Report valid binary detection
AUROC/AP only when the frozen endpoint and both classes exist; use appropriate
within-assay rank comparisons for quantitative yields. Native controls are not
extra engineered test examples. Do not pool different products, culture scales,
replicates or systems into an apparently larger independent test set.

No calibrated activity-probability, novel-family independence, or causal domain
fault-localization claim is made. Check `VALIDATION.json` for what was checked
locally versus what still requires the real cluster inference run.
