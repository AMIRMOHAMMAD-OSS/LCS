#!/usr/bin/env bash
set -euo pipefail
NRPS_TDT_PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
NRPS_TDT_ROOT=$(cd -- "$NRPS_TDT_PACKAGE/.." && pwd)
if (($#)); then
    if [[ "$1" == "--root" && $# == 2 ]]; then
        NRPS_TDT_ROOT=$(cd -- "$2" && pwd)
    else
        printf '%s\n' 'Usage: bash submit.sh [--root PROJECT_DIRECTORY]' >&2
        exit 2
    fi
fi
command -v sbatch >/dev/null || { printf '%s\n' 'Run this command on Jean Zay.' >&2; exit 1; }
python3 -B "$NRPS_TDT_PACKAGE/verify.py"
python3 -B "$NRPS_TDT_PACKAGE/run.py" --root "$NRPS_TDT_ROOT" --preflight-only
NRPS_TDT_SUBMISSION=$(sbatch --parsable \
    --account=nef@a100 --partition=gpu_p5 --qos=qos_gpu_a100-t3 \
    --job-name=nrps_tdtransfer --nodes=1 --ntasks=1 --cpus-per-task=8 --hint=nomultithread \
    --gres=gpu:1 --constraint=a100 --time=02:00:00 --propagate=NONE --no-requeue \
    --chdir="$NRPS_TDT_ROOT" \
    --output="$NRPS_TDT_ROOT/e11_tdomain_transfer_%j.log" \
    --error="$NRPS_TDT_ROOT/e11_tdomain_transfer_%j.log" \
    "$NRPS_TDT_PACKAGE/batch.sh" "$NRPS_TDT_PACKAGE" "$NRPS_TDT_ROOT")
NRPS_TDT_JOB_ID=${NRPS_TDT_SUBMISSION%%;*}
if [[ ! "$NRPS_TDT_JOB_ID" =~ ^[0-9]+$ ]]; then
    printf 'Unexpected sbatch response; job may have been submitted: %s\n' "$NRPS_TDT_SUBMISSION" >&2
    exit 1
fi
python3 -B - "$NRPS_TDT_PACKAGE" "$NRPS_TDT_ROOT" "$NRPS_TDT_JOB_ID" <<'PY'
import datetime
import json
import os
from pathlib import Path
import sys
import tempfile
package, root, job = sys.argv[1:]
record = dict(job_id=job, submitted_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              package=package, project_root=root,
              output=str(Path(root) / ('e11_tdomain_transfer_' + job)),
              log=str(Path(root) / ('e11_tdomain_transfer_' + job + '.log')))
with tempfile.NamedTemporaryFile(mode='w', dir=package, prefix='.LAST_JOB.', suffix='.tmp', delete=False) as stream:
    temporary = stream.name
    json.dump(record, stream, indent=2)
    stream.write('\n')
    stream.flush()
    os.fsync(stream.fileno())
os.replace(temporary, Path(package) / 'LAST_JOB.json')
print('Submitted one-A100 T-domain frozen transfer:', job)
print('84 engineered constructs; 4 native controls; no model updates or classifier fits.')
print('Output:', record['output'])
print('Log:', record['log'])
print('Status: bash', Path(package) / 'status.sh')
PY
