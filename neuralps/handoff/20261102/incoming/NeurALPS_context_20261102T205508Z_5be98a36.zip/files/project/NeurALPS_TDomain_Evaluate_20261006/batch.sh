#!/usr/bin/env bash
set -eo pipefail
NRPS_TDT_PACKAGE="${1:?package directory}"
NRPS_TDT_ROOT="${2:?project directory}"
: "${SLURM_JOB_ID:?Must run in a submitted Slurm job}"
[[ "$SLURM_JOB_ID" =~ ^[0-9]+$ ]] || exit 2
NRPS_TDT_OUT="$NRPS_TDT_ROOT/e11_tdomain_transfer_$SLURM_JOB_ID"
if [[ -e "$NRPS_TDT_OUT" || -L "$NRPS_TDT_OUT" ]]; then
    printf 'Refusing to overwrite existing transfer output: %s\n' "$NRPS_TDT_OUT" >&2
    exit 1
fi
cd -- "$NRPS_TDT_ROOT"
module purge
module load arch/a100
module load pytorch-gpu/py3/2.8.0
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
export TMPDIR="$NRPS_TDT_ROOT/e11_tdomain_transfer_tmp_$SLURM_JOB_ID"
export SQLITE_TMPDIR="$TMPDIR"
mkdir -p -- "$TMPDIR"
NRPS_TDT_PY=$(python3 -B -c 'import sys; print(sys.base_prefix + "/bin/python3")')
"$NRPS_TDT_PY" -B "$NRPS_TDT_PACKAGE/verify.py"
exec "$NRPS_TDT_PY" -u -B "$NRPS_TDT_PACKAGE/run.py" --root "$NRPS_TDT_ROOT" --out "$NRPS_TDT_OUT"
