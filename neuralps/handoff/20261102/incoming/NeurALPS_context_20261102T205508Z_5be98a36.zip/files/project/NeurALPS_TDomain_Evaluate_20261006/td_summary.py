"""Summarize sealed-choice T-domain predictions without reading assay outcomes.

Public APIs:
    summarize(out_dir, *, records, input_manifest, annotation_qc,
              raw_rows, scaled_rows, classifier_predictions=None)
    collect_assay_packet(dataset_dir, out_dir, prediction_seal_path)

The second function is deliberately separate: it verifies the prediction seal
before it opens the assay bundle. It copies source tables without interpreting,
joining, thresholding or selecting any assay endpoint.
"""
from collections import Counter, defaultdict
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import shutil

DATASET_MANIFEST_SHA256 = "b69f592d6c8cfbdb3a77c640db58503d7301833fea28435e49945585c479bd97"
DATASET_FILES = 91
PACKAGE = Path(__file__).resolve().parent
SCORE_FIELDS = (
    "status", "native_score", "reconstruction_error", "hidden_fraction",
    "remaining_distinct_context_objects", "local_only_status",
    "local_only_native_score", "local_only_reconstruction_error",
    "local_only_is_evaluation_ablation", "global_effect_on_native_score",
)
SCALE_FIELDS = (
    "natural_percentile_0_to_100", "lower_tail_rank", "warning", "scale_status",
    "reference_components", "reference_candidate_objects", "reference_key",
    "reference_level", "tail_resolution", "reference_feature_overlap_components",
    "reference_parent_overlap_components", "reference_audit_status",
    "reference_audit_components", "reference_audit_warning_rate",
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    path = Path(path)
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as stream:
        return json.load(stream)


def read_rows(path):
    path = Path(path)
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def dump(path, value):
    Path(path).write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")


def write_csv(path, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with Path(path).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value, sort_keys=True, allow_nan=False)
                             if isinstance(value, (list, dict)) else value for key, value in row.items()})


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def strict_mean(values):
    return sum(values) / len(values) if values and all(finite(x) for x in values) else None


def difference(value, baseline):
    return value - baseline if finite(value) and finite(baseline) else None


def score_value(row, local=False):
    status = row.get("local_only_status") if local else row.get("status")
    value = row.get("local_only_native_score") if local else row.get("native_score")
    if status == "SCORED":
        require(finite(value), "Scored row has a nonfinite or missing native score")
        return value
    return None


def unique_by(rows, field):
    result = {}
    for row in rows:
        key = row[field]
        require(key not in result, f"Duplicate {field}: {key}")
        result[key] = row
    return result


def row_index(rows):
    result = {}
    for row in rows:
        require(row.get("mode") == "object_recovery" and row.get("kind") in (0, 1),
                "T-domain summary expects one object_recovery query per domain/covalent boundary")
        j = row.get("object_index")
        require(type(j) is int and j >= 0, "Invalid score object index")
        key = (row["assembly_id"], j)
        require(key not in result, "Duplicate object score: " + str(key))
        result[key] = row
    return result


def topology(route):
    return [(obj["kind"], obj.get("canonical_domain_type", obj.get("domain_type")))
            if obj["kind"] == 0 else (obj["kind"],) for obj in route]


def classifier_values(item):
    if item is None:
        return {"s1_bode1": None, "s1_bode2": None,
                "global_context_bode1": None, "global_context_bode2": None}
    result = {}
    for dataset in ("bode1", "bode2"):
        for arm, name in (("typed_context", "s1_" + dataset),
                          ("global_context", "global_context_" + dataset)):
            entry = item["predictions"][dataset][arm]
            value = entry["probability_mean"]
            require(finite(value) and 0 <= value <= 1, "Invalid classifier probability")
            result[name] = value
    return result


def summarize_records(records, metadata, qc, raw_rows, scaled_rows, classifiers=None):
    """Pure in-memory summary; no source assay directory or labels are accepted."""
    if isinstance(records, list):
        records = unique_by(records, "assembly_id")
    require(isinstance(records, dict) and records, "Missing model records")
    meta = unique_by(metadata, "assembly_id")
    quality = unique_by(qc, "assembly_id")
    require(set(records) == set(meta) == set(quality), "Record/annotation metadata coverage differs")
    raw, scaled = row_index(raw_rows), row_index(scaled_rows)
    expected = {(aid, j) for aid, record in records.items() for j in range(len(record["route"]))}
    require(set(raw) == set(scaled) == expected, "Missing or extra physical-object score rows")
    pred = unique_by(classifiers["assemblies"], "assembly_id") if classifiers else {}
    if classifiers:
        require(set(pred) == set(records), "Classifier prediction coverage differs")
    natives = {}
    target_indices = defaultdict(set)
    for aid, m in meta.items():
        q, record = quality[aid], records[aid]
        require(m["input_id"] == q["input_id"] == record["input_id"], "Input identity mismatch")
        require(m["role"] == q["role"] == record["role"] and m["context"] == q["context"], "Role/context mismatch")
        require(not q.get("flags") and q["status"] == "CANDIDATE_ROUTE_ANNOTATED", "Annotation not approved")
        require(record["assembly_id"] == aid, "Record mapping key differs from assembly ID")
        require(len(record["parent_sequence_hashes"]) == 1 and
                set(record["parent_sequence_hashes"].values()) == {m["amino_acid_sha256"]},
                "Physical parent hash differs from annotation metadata")
        if m["role"] == "native_control":
            require(m["context"] not in natives, "Multiple native controls in context")
            natives[m["context"]] = aid
        else:
            require(m["role"] == "engineered", "Unknown construct role")
            j = q["target_object_index"]
            require(type(j) is int and 0 < j < len(record["route"]) - 1 and j % 2 == 0,
                    "Target PCP must have two immediate boundary neighbors")
            obj = record["route"][j]
            require(obj["kind"] == 0 and obj["canonical_domain_type"] == "PCP", "Target is not PCP")
            require(q["target_interval"] == [obj["start_aa_0based"], obj["end_aa_0based_exclusive"]],
                    "Target interval differs from route")
            lo, hi = m["changed_interval"]
            a, b = q["target_interval"]
            require(max(0, min(hi, b) - max(lo, a)) >= (b - a) * .5, "Target PCP does not overlap engineered interval")
            target_indices[m["context"]].add(j)
    require(set(natives) == set(target_indices), "Native/engineered context coverage differs")
    require(all(len(indices) == 1 for indices in target_indices.values()), "Inconsistent target topology within context")
    targets = {context: next(iter(indices)) for context, indices in target_indices.items()}
    objects, assemblies = [], []
    for aid in sorted(records):
        record, m, q = records[aid], meta[aid], quality[aid]
        native_aid = natives[m["context"]]
        require(topology(record["route"]) == topology(records[native_aid]["route"]), "Native topology differs")
        target = targets[m["context"]]
        require(records[native_aid]["route"][target]["canonical_domain_type"] == "PCP", "Native matched target is not PCP")
        neighborhood = [target - 1, target, target + 1]
        require(all(record["route"][j]["kind"] == 1 for j in (target - 1, target + 1)), "Target flanks are not boundaries")
        mapped = []
        for j, obj in enumerate(record["route"]):
            row, scale_row = raw[(aid, j)], scaled[(aid, j)]
            require(row["kind"] == obj["kind"], "Score/route object kind mismatch")
            for field in ("status", "native_score", "mode", "kind"):
                require(row.get(field) == scale_row.get(field), "Scaled row modified raw score identity: " + field)
            full, local = score_value(row), score_value(row, True)
            native_full = score_value(raw[(native_aid, j)])
            native_local = score_value(raw[(native_aid, j)], True)
            projected = {"assembly_id": aid, "input_id": m["input_id"], "context": m["context"],
                "role": m["role"], "variant_id": m.get("variant_id"), "object_index": j,
                "object_id": obj.get("occurrence_id", obj.get("boundary_id", row.get("object_id"))),
                "kind": obj["kind"], "kind_name": row.get("kind_name", "domain" if obj["kind"] == 0 else "covalent_boundary"),
                "label": row.get("label"), "domain_type": obj.get("domain_type"),
                "canonical_domain_type": obj.get("canonical_domain_type"), "mode": row["mode"],
                "is_target_pcp": j == target, "is_target_flank": j in (target - 1, target + 1),
                "from_domain": record["route"][j - 1].get("occurrence_id") if obj["kind"] == 1 else None,
                "to_domain": record["route"][j + 1].get("occurrence_id") if obj["kind"] == 1 else None,
                "physical_slots": [s for s in record["model_slots"] if s["object_index"] == j],
                **{field: row.get(field) for field in SCORE_FIELDS},
                **{field: scale_row.get(field) for field in SCALE_FIELDS},
                "matched_native_assembly_id": native_aid, "matched_native_object_index": j,
                "matched_native_raw_score": native_full, "matched_native_local_only_raw_score": native_local,
                "raw_difference_from_matched_native": difference(full, native_full) if m["role"] == "engineered" else None,
                "local_only_difference_from_matched_native": difference(local, native_local) if m["role"] == "engineered" else None}
            percentile = projected["natural_percentile_0_to_100"]
            if percentile is not None:
                require(finite(percentile) and 0 <= percentile <= 100, "Invalid natural percentile")
            mapped.append(projected)
            objects.append(projected)
        scores = {"target_pcp_raw": score_value(raw[(aid, target)]),
                  "target_pcp_local_only_raw": score_value(raw[(aid, target)], True),
                  "target_and_flanks_raw_mean": strict_mean([score_value(raw[(aid, j)]) for j in neighborhood]),
                  "target_and_flanks_local_only_raw_mean": strict_mean([score_value(raw[(aid, j)], True) for j in neighborhood])}
        native_scores = {"target_pcp_raw": score_value(raw[(native_aid, target)]),
            "target_pcp_local_only_raw": score_value(raw[(native_aid, target)], True),
            "target_and_flanks_raw_mean": strict_mean([score_value(raw[(native_aid, j)]) for j in neighborhood]),
            "target_and_flanks_local_only_raw_mean": strict_mean([score_value(raw[(native_aid, j)], True) for j in neighborhood])}
        assembly = {"assembly_id": aid, "input_id": m["input_id"], "context": m["context"],
            "role": m["role"], "variant_id": m.get("variant_id"),
            "amino_acid_sha256": m["amino_acid_sha256"], "changed_interval": m.get("changed_interval"),
            "target_pcp_object_index": target, "target_assignment": "sequence_overlap_annotation_QC" if m["role"] == "engineered" else "matched_engineered_context_topology_index",
            "target_pcp_interval": [record["route"][target]["start_aa_0based"], record["route"][target]["end_aa_0based_exclusive"]],
            "target_neighborhood_object_indices": neighborhood, "neighborhood_requires_all_three_scores": True,
            "matched_native_assembly_id": native_aid, **scores,
            **{name + "_minus_native": difference(value, native_scores[name]) if m["role"] == "engineered" else None for name, value in scores.items()},
            **classifier_values(pred.get(aid)), "assay_join_status": "NOT_JOINED",
            "primary_metrics_eligible_role": m["role"] == "engineered", "objects": mapped}
        assemblies.append(assembly)
    report = {"status": "TDOMAIN_SCORE_SUMMARIES_COMPLETE_NO_ASSAY_EVALUATION",
        "assemblies": len(assemblies), "engineered_constructs": sum(a["role"] == "engineered" for a in assemblies),
        "native_controls": sum(a["role"] == "native_control" for a in assemblies), "physical_objects": len(objects),
        "engineered_per_context": dict(Counter(a["context"] for a in assemblies if a["role"] == "engineered")),
        "target_pcp_raw_available": sum(a["target_pcp_raw"] is not None for a in assemblies if a["role"] == "engineered"),
        "target_and_flanks_raw_mean_available": sum(a["target_and_flanks_raw_mean"] is not None for a in assemblies if a["role"] == "engineered"),
        "scale_status_counts": dict(Counter(o["scale_status"] for o in objects)),
        "reference_audit_status_counts": dict(Counter(o["reference_audit_status"] for o in objects)),
        "assay_labels_read": False, "assay_metrics": None, "classifier_probabilities_calibrated": False,
        "causal_fault_localization_validated": False,
        "notes": ["Higher native_score means greater learned context agreement; no activity probability interpretation.",
            "Natural percentiles apply only to full-context scores; unsupported reference groups remain null.",
            "s1_bode1 and s1_bode2 are external saved-CV-model ensemble means, not target out-of-fold predictions.",
            "Native differences subtract one matched context reference and cannot change within-context rankings.",
            "Native controls are excluded from subsequent engineered-construct primary metrics.",
            "Assay joins and endpoints must be reviewed separately; this report contains no AUROC or yield-association result."]}
    return {"report": report, "assemblies": assemblies, "objects": objects}


def simple_map(result):
    assemblies = []
    for assembly in result["assemblies"]:
        domains, boundaries = [], []
        for row in assembly["objects"]:
            piece = {"id": row["object_id"], "name": row["label"], "object_index": row["object_index"],
                "compatibility_score": row["natural_percentile_0_to_100"],
                "raw_score": row["native_score"], "local_only_raw_score": row["local_only_native_score"],
                "score_status": row["status"], "local_only_status": row["local_only_status"],
                "scale_status": row["scale_status"], "reference_audit_status": row["reference_audit_status"],
                "reference_components": row["reference_components"], "reference_key": row["reference_key"],
                "lower_tail_rank": row["lower_tail_rank"], "warning": row["warning"],
                "is_target_pcp": row["is_target_pcp"], "is_target_flank": row["is_target_flank"],
                "raw_difference_from_matched_native": row["raw_difference_from_matched_native"],
                "physical_regions": [{"protein_uid": slot["protein_uid"],
                    "start_aa_0based": slot["start"], "end_aa_0based_exclusive": slot["end"],
                    "sequence_hash": slot["sequence_hash"], "state": slot["state"]}
                    for slot in row["physical_slots"]]}
            if row["kind"] == 0:
                domains.append(piece)
            else:
                piece.update(from_domain=row["from_domain"], to_domain=row["to_domain"])
                boundaries.append(piece)
        assemblies.append({"id": assembly["assembly_id"],
            "name": (f"{assembly['context']} variant {assembly['variant_id']}" if assembly["role"] == "engineered"
                     else f"Native control: {assembly['context']}"),
            "context": assembly["context"], "variant_id": assembly["variant_id"], "role": assembly["role"],
            "s1_bode1": assembly["s1_bode1"], "s1_bode2": assembly["s1_bode2"],
            "global_context_bode1": assembly["global_context_bode1"], "global_context_bode2": assembly["global_context_bode2"],
            "target_pcp_raw": assembly["target_pcp_raw"],
            "target_and_flanks_raw_mean": assembly["target_and_flanks_raw_mean"],
            "target_pcp_raw_minus_native": assembly["target_pcp_raw_minus_native"],
            "target_and_flanks_raw_mean_minus_native": assembly["target_and_flanks_raw_mean_minus_native"],
            "target_pcp_object_index": assembly["target_pcp_object_index"],
            "changed_interval": assembly["changed_interval"], "matched_native_assembly_id": assembly["matched_native_assembly_id"],
            "domains": domains, "boundaries": boundaries})
    return {"schema": "tdomain_simple_compatibility_map_v1", "report": result["report"],
        "score_definitions": {"compatibility_score": "Existing full-context natural-reference percentile, 0 to 100; null when unsupported; not probability of activity",
            "raw_score": "Full-context native reconstruction agreement; higher means more agreement",
            "local_only_raw_score": "Same model's local-only evaluation ablation; no natural percentile assigned",
            "s1_bode1": "Uncalibrated typed-context BODE1 saved-CV-ensemble probability mean",
            "s1_bode2": "Uncalibrated typed-context BODE2 saved-CV-ensemble probability mean"},
        "assemblies": assemblies}


def summarize(out_dir, *, records, input_manifest, annotation_qc,
              raw_rows, scaled_rows, classifier_predictions=None):
    """Inputs may be loaded objects or JSON/JSONL(.gz) paths, respectively."""
    def as_json(value):
        return read_json(value) if isinstance(value, (str, Path)) else value
    def as_rows(value):
        return read_rows(value) if isinstance(value, (str, Path)) else value
    out_dir = Path(out_dir)
    result = summarize_records(
        as_json(records), as_json(input_manifest), as_json(annotation_qc),
        as_rows(raw_rows), as_rows(scaled_rows), as_json(classifier_predictions))
    out_dir.mkdir(parents=True, exist_ok=True)
    dump(out_dir / "simple_compatibility_map.json", simple_map(result))
    dump(out_dir / "compatibility_map_full.json", {"report": result["report"], "assemblies": result["assemblies"]})
    write_csv(out_dir / "object_scores.csv", result["objects"])
    write_csv(out_dir / "assembly_scores.csv", [{k: v for k, v in row.items() if k != "objects"} for row in result["assemblies"]])
    dump(out_dir / "summary_report.json", result["report"])
    dump(out_dir / "ASSAY_REVIEW_REQUIREMENTS.json", {
        "status": "REVIEW_REQUIRED_METRICS_UNDEFINED", "assay_labels_joined": False, "assay_metrics": None,
        "score_plan_source": "Package PROTOCOL.json; do not change planned scores after looking at assay values",
        "joins": "Match exact construct/context/variant and source sequence identity; never join by row order, approximate name, or assay result",
        "primary_compatibility": "Exchanged PCP full-context native_score, higher is greater agreement",
        "secondary_compatibility": "Mean of target PCP and both adjacent boundaries requires all three valid scores; native differences and local-only raw scores remain separately declared",
        "scale": "Existing natural-reference percentile is descriptive and full-context only; retain unsupported/audit-limited statuses",
        "minimal_assay": "Review published processed flL/FlL percent WT and its zero semantics; do not silently substitute a full-length or hybrid product assay",
        "hybrid_assays": "Review each system's expected product, quantitative units and published detection/QC; raw peak-found flags or blank cells are not automatically activity labels",
        "unit": "One engineered construct per matched assay condition; biological replicates summarize one construct rather than multiplying sample size",
        "context_reporting": "Keep minimal GxpS, GxhS-1, GshS and GxhS-2 separate; do not pool different products or culture scales",
        "dependence": "The same AI design may occur in multiple contexts; uncertainty must respect repeated variants/sequences",
        "excluded_from_primary_metrics": "Four native controls, unjoined outcomes, absent assays and unresolved outcome/sequence conflicts",
        "binary_metrics": "AUROC and average precision only after an endpoint is justified and both classes exist; otherwise null with reason",
        "continuous_metrics": "Rank association only within comparable quantitative assays; report exact construct counts and handling of censored/missing measurements",
        "classifier_interpretation": "Saved BODE1 and BODE2 fold-ensemble predictions are separate external transfer arms; probabilities are uncalibrated on this study",
        "claims": "No causal localization or novel-family independence follows from these scores"})
    return result["report"]


def safe_path(root, name):
    path = PurePosixPath(name)
    require(isinstance(name, str) and not path.is_absolute() and ".." not in path.parts and name not in ("", "."),
            "Unsafe manifest path: " + str(name))
    resolved = (root / Path(*path.parts)).resolve()
    require(resolved.is_relative_to(root.resolve()), "Manifest path escapes source root")
    return resolved


def verify_prediction_seal(path):
    path = Path(path)
    seal = read_json(path)
    require(seal.get("status") == "TDOMAIN_PREDICTIONS_SEALED", "Assay collection requires a completed prediction seal")
    files = seal.get("files")
    require(isinstance(files, dict) and files, "Empty prediction seal")
    require({"raw_objects.jsonl.gz", "scaled_objects.jsonl.gz", "classifier_predictions.json"} <=
            {PurePosixPath(name).name for name in files}, "Prediction seal lacks raw, scaled, or classifier predictions")
    for name, digest in files.items():
        source = safe_path(path.parent, name)
        require(source.is_file() and sha(source) == digest, "Sealed prediction changed: " + name)
    return seal


def collect_assay_packet(dataset_dir, out_dir, prediction_seal_path):
    """Copy reviewed source tables AFTER validating every sealed prediction.

    out_dir is the packet directory itself (e.g. run/assay_packet). No workbook
    or assay values are parsed. The original 91-file dataset identity is pinned.
    """
    prediction_seal_path = Path(prediction_seal_path)
    seal = verify_prediction_seal(prediction_seal_path)
    dataset_dir, out_dir = Path(dataset_dir).resolve(), Path(out_dir).resolve()
    require(not out_dir.is_relative_to(dataset_dir), "Assay packet must be outside the immutable dataset")
    manifest = dataset_dir / "SHA256SUMS"
    require(sha(manifest) == DATASET_MANIFEST_SHA256, "Dataset manifest differs from embedding input")
    source_hashes = {}
    for line in manifest.read_text().splitlines():
        digest, name = line.split("  ", 1)
        require(len(digest) == 64 and name not in source_hashes, "Malformed or duplicate dataset manifest entry")
        source = safe_path(dataset_dir, name)
        require(source.is_file() and sha(source) == digest, "Dataset file changed: " + name)
        source_hashes[name] = digest
    require(len(source_hashes) == DATASET_FILES, "Dataset file count differs from reviewed input")
    selected = {}
    missing = []
    for directory in ("evaluation", "assay_data"):
        root = dataset_dir / directory
        if not root.is_dir():
            missing.append(directory + "/")
            continue
        for source in sorted(root.rglob("*")):
            if source.is_file():
                name = source.relative_to(dataset_dir).as_posix()
                require(name in source_hashes, "Unmanifested assay/evaluation file: " + name)
                selected[name] = source_hashes[name]
    for name in ("EVALUATION_PROTOCOL.md", "provenance/split_audit.json", "CITATION_AND_RIGHTS.md"):
        if name in source_hashes:
            selected[name] = source_hashes[name]
        else:
            missing.append(name)
    require(any(name.startswith("evaluation/") for name in selected), "No dataset evaluation files to collect")
    require(any(name.startswith("assay_data/") for name in selected), "No source assay exports to collect")
    selected["SHA256SUMS"] = DATASET_MANIFEST_SHA256
    out_dir.mkdir(parents=True, exist_ok=True)
    for name, digest in sorted(selected.items()):
        source, destination = safe_path(dataset_dir, name), safe_path(out_dir, name)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            require(sha(destination) == digest, "Existing assay packet differs: " + name)
        else:
            shutil.copyfile(source, destination)
        require(sha(destination) == digest, "Assay packet copy differs: " + name)
    # Re-check the seal after copying; no source labels have affected predictions.
    verify_prediction_seal(prediction_seal_path)
    report = {"status": "ASSAY_PACKET_COLLECTED_JOIN_REVIEW_REQUIRED",
        "dataset_manifest_sha256": DATASET_MANIFEST_SHA256, "dataset_files_verified": DATASET_FILES,
        "prediction_seal_sha256": sha(prediction_seal_path), "sealed_prediction_files": len(seal["files"]),
        "files": selected, "copied_files": len(selected), "missing_requested_optional_paths": missing,
        "assay_values_parsed": False, "assay_labels_joined": False, "assay_metrics": None,
        "note": "Byte-identical source exports collected only after prediction sealing; copied SHA256SUMS describes the full source dataset, not just this packet. packet_manifest.json lists the copied subset."}
    dump(out_dir / "packet_manifest.json", report)
    return report
