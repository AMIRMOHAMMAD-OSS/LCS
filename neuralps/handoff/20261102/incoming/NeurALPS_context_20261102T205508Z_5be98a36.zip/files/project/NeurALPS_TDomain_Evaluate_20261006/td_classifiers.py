"""Apply the sealed BODE readout classifiers to new frozen SSL26 representations.

No classifier fitting or target assay labels are used. The arithmetic mean of
existing donor-fold probabilities is reported separately for BODE1 and BODE2.
These are external predictions of the saved cross-validation model ensembles,
not full-data refits and not new out-of-fold predictions on the target panel.

Dependencies: numpy and Python standard library. Primary arm: typed_context;
comparator: global_context. The old candidate-panel score arm is not substituted
with the scientifically different natural-reference percentile.
"""
from collections import defaultdict
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import zipfile

import numpy as np

CHECKPOINT_SHA256 = '9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f'
SOURCE_MANIFEST_SHA256 = '441fb810607bc46b8bc992e6a229981fdf892359a1c038b50d78697da7015d3e'
SOURCE_RUN = 'e7_compat_readout_benchmark_646197'
ARMS = ('typed_context', 'global_context')
DIMENSIONS = {'typed_context': 2822, 'global_context': 770}
FOLD_COUNTS = {'bode1': 21, 'bode2': 35}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def matrix_digest(matrix):
    return digest(np.asarray(matrix, dtype='<f8').tobytes())


def sigmoid(logits):
    logits = np.asarray(logits, dtype=np.float64)
    require(np.isfinite(logits).all(), 'Nonfinite classifier logits')
    result = np.empty_like(logits)
    positive = logits >= 0
    result[positive] = 1 / (1 + np.exp(-logits[positive]))
    exp_z = np.exp(logits[~positive])
    result[~positive] = exp_z / (1 + exp_z)
    return result


def build_features(records, representations, *, checkpoint_sha256):
    """Use structural route kinds and an exact-schema representations.npz only.

The caller must supply the checkpoint hash validated by frozen inference. This
NPZ format itself does not carry checkpoint metadata. No record fields other
than route/object kind are inspected; in particular no assay labels are read.
"""
    require(checkpoint_sha256 == CHECKPOINT_SHA256, 'Wrong target representation checkpoint')
    payload = Path(representations).read_bytes()
    with np.load(io.BytesIO(payload), allow_pickle=False) as archive:
        require(set(archive.files) == {'assembly_ids', 'object_offsets', 'object_states', 'assembly_readout'},
                'Unexpected target representation schema')
        ids = [str(a) for a in archive['assembly_ids']]
        offsets = archive['object_offsets'].copy()
        states = archive['object_states'].astype(np.float64)
        global_x = archive['assembly_readout'].astype(np.float64)
    require(bool(ids) and len(ids) == len(set(ids)) and set(ids) == set(records),
            'Target route/representation IDs differ or are repeated')
    require(offsets.dtype.kind in 'iu' and offsets.shape == (len(ids)+1,) and
            offsets[0] == 0 and offsets[-1] == len(states) and np.all(np.diff(offsets) > 0),
            'Invalid target object offsets')
    require(states.ndim == 2 and states.shape[1] == 256 and global_x.shape == (len(ids), 770),
            'Wrong target encoder feature dimensions')
    require(np.isfinite(states).all() and np.isfinite(global_x).all(), 'Nonfinite target features')
    typed = []
    kind_counts = np.zeros(3, dtype=np.int64)
    for i, aid in enumerate(ids):
        route = records[aid]['route']
        h = states[offsets[i]:offsets[i+1]]
        require(len(route) == len(h), 'Target route/state offsets differ: '+aid)
        kinds = np.asarray([o['kind'] for o in route])
        require(kinds.dtype.kind in 'iu' and set(kinds) <= {0, 1, 2}, 'Invalid object kind: '+aid)
        domains, boundaries = h[kinds == 0], h[kinds != 0]
        require(len(domains) > 0 and len(boundaries) > 0, 'Empty required target pool: '+aid)
        pooled = np.concatenate([domains.mean(0), boundaries.mean(0), boundaries.max(0),
                                 np.log1p([len(domains), len(boundaries)])])
        require(np.allclose(pooled, global_x[i], rtol=2e-5, atol=2e-6),
                'Target global pooling disagrees with object states: '+aid)
        groups = [[], [], []]
        for j, kind in enumerate(kinds):
            if kind == 0:
                vector = h[j]
            else:
                require(0 < j < len(route)-1 and kinds[j-1] == kinds[j+1] == 0,
                        'Target boundary has non-domain neighbors: '+aid)
                left, right = h[j-1], h[j+1]
                vector = np.concatenate([left, h[j], right, left*right, np.abs(left-right)])
            groups[kind].append(vector)
        counts = np.array([len(group) for group in groups])
        kind_counts += counts
        means = [np.mean(group, axis=0) if len(group) else np.zeros(256 if k == 0 else 1280)
                 for k, group in enumerate(groups)]
        extra = np.asarray([v for n in counts for v in (np.log1p(n), float(n > 0))])
        typed.append(np.concatenate([*means, extra]))
    matrices = {'global_context': global_x, 'typed_context': np.asarray(typed)}
    require(all(x.shape == (len(ids), DIMENSIONS[arm]) and np.isfinite(x).all()
                for arm, x in matrices.items()), 'Target readout features invalid')
    manifest = dict(assemblies=len(ids), physical_objects=len(states),
        object_counts=dict(zip(('domain', 'covalent_boundary', 'protein_break'), map(int, kind_counts))),
        dimensions=dict(DIMENSIONS), matrix_sha256={a: matrix_digest(x) for a, x in matrices.items()},
        assembly_id_sha256=digest(json.dumps(ids).encode()),
        representations_sha256=digest(payload), checkpoint_sha256=checkpoint_sha256,
        selected_step=26000, labels_read_by_feature_builder=False)
    return dict(assembly_ids=ids, matrices=matrices, manifest=manifest)


class _Source:
    def __init__(self, source):
        self.path = Path(source)
        self.archive = zipfile.ZipFile(self.path) if self.path.is_file() else None
        if self.archive is not None:
            names = self.archive.namelist()
            require(len(names) == len(set(names)), 'Duplicate source ZIP member')
        manifest_bytes = self.raw('artifact_manifest.json')
        require(digest(manifest_bytes) == SOURCE_MANIFEST_SHA256,
                'Readout source is not the sealed '+SOURCE_RUN+' inspection')
        self.manifest = json.loads(manifest_bytes)
        require(isinstance(self.manifest, dict), 'Invalid readout source manifest')
        self.verified = {}

    def raw(self, name):
        member = PurePosixPath(name)
        require(not member.is_absolute() and '..' not in member.parts and '\\' not in name,
                'Invalid source member path')
        return self.archive.read(name) if self.archive is not None else (self.path/name).read_bytes()

    def read(self, name):
        require(name in self.manifest, 'Unsealed source member: '+name)
        payload = self.raw(name)
        require(digest(payload) == self.manifest[name], 'Readout source checksum mismatch: '+name)
        self.verified[name] = self.manifest[name]
        return payload

    def json(self, name):
        return json.loads(self.read(name))

    def close(self):
        if self.archive is not None:
            self.archive.close()


def _model(payload, dimension):
    with np.load(io.BytesIO(payload), allow_pickle=False) as archive:
        model = {k: archive[k].copy() for k in archive.files}
    require(set(model) == {'weight', 'intercept', 'mean', 'scale', 'active', 'l2'},
            'Unexpected saved classifier schema')
    for field in ('weight', 'mean', 'scale', 'active'):
        require(model[field].shape == (dimension,), 'Wrong classifier '+field+' dimensions')
    require(model['active'].dtype.kind == 'b', 'Classifier active mask is not boolean')
    require(model['intercept'].shape == model['l2'].shape == (), 'Invalid classifier scalar shape')
    for field in ('weight', 'mean', 'scale', 'intercept', 'l2'):
        require(np.isfinite(model[field]).all(), 'Nonfinite classifier '+field)
    require(np.all(model['scale'] > 0) and float(model['l2']) > 0, 'Invalid classifier scale or L2')
    require(np.all(model['weight'][~model['active']] == 0), 'Disabled classifier feature has nonzero weight')
    return model


def _logits(model, matrix):
    return (((matrix-model['mean'])/model['scale'])*model['active']) @ model['weight'] + model['intercept']


class ClassifierBank:
    """Read, checksum-verify and replay all 112 selected saved donor-fold heads."""
    def __init__(self, source):
        self.models = defaultdict(list)
        reader = _Source(source)
        try:
            protocol = reader.json('PROTOCOL.json')
            require(protocol['encoder']['checkpoint_sha256'] == CHECKPOINT_SHA256 and
                    protocol['encoder']['selected_step'] == 26000 and protocol['encoder']['updates'] == 0,
                    'Readout source checkpoint changed')
            summary = reader.json('summary.json')
            require(summary['status'] == 'COMPAT_READOUT_COMPLETE' and summary['profile'] == 'benchmark' and
                    summary['encoder_updated'] is False and summary['final_models'] == 276,
                    'Readout source benchmark incomplete')
            feature_manifest = reader.json('feature_manifest.json')
            with np.load(io.BytesIO(reader.read('assembly_features.npz')), allow_pickle=False) as archive:
                arrays = {k: archive[k].copy() for k in archive.files}
            require(set(arrays) == {ds+suffix for ds in FOLD_COUNTS for suffix in ('_ids', '_global', '_typed_scores')},
                    'Unexpected saved replay feature schema')
            matrices, indices = {}, {}
            for ds in FOLD_COUNTS:
                ids = [str(a) for a in arrays[ds+'_ids']]
                indices[ds] = {a: i for i, a in enumerate(ids)}
                info = feature_manifest[ds]
                require(len(ids) == len(indices[ds]) == info['assemblies'] and
                        digest(json.dumps(ids).encode()) == info['assembly_id_sha256'],
                        'Saved replay feature IDs changed')
                for arm in ARMS:
                    x = arrays[ds+'_global'] if arm == 'global_context' else arrays[ds+'_typed_scores'][:, :2822]
                    require(x.shape == (len(ids), DIMENSIONS[arm]) and np.isfinite(x).all() and
                            matrix_digest(x) == info['matrix_sha256'][arm], 'Saved replay matrix changed')
                    matrices[ds, arm] = x
            tasks = reader.json('splits.json')
            selected = [t for t in tasks if t['dataset'] in FOLD_COUNTS and
                        t['benchmark'] == t['dataset']+'_donor']
            require(len({t['task_id'] for t in selected}) == len(selected) == 56,
                    'Saved donor-fold task coverage changed')
            worst_logit = worst_probability = 0.0
            replayed = 0
            for task in sorted(selected, key=lambda t: t['task_id']):
                ds, fold = task['dataset'], task['task_id']
                require(set(task['test_ids']).isdisjoint(task['refit_ids']), 'Source test/refit overlap')
                for arm in ARMS:
                    base = 'fits/'+fold+'/'+arm+'/'
                    contract = reader.json(base+'contract.json')
                    complete = reader.json(base+'complete.json')
                    require(contract['task'] == task and contract['arm'] == arm and
                            contract['features'] == feature_manifest[ds] and contract['encoder_updates'] == 0 and
                            contract['outer_labels_used_for_selection'] is False, 'Saved classifier contract changed')
                    require(complete['status'] == 'MODEL_COMPLETE' and complete['checkpoint_reload_exact'] is True and
                            complete['contract_sha256'] == digest(json.dumps(contract, sort_keys=True).encode()),
                            'Saved classifier seal changed')
                    for filename, expected_hash in complete['files_sha256'].items():
                        require(reader.manifest.get(base+filename) == expected_hash,
                                'Classifier per-fit/global manifest mismatch: '+base+filename)
                    model = _model(reader.read(base+'model.npz'), DIMENSIONS[arm])
                    require(float(model['l2']) == complete['selected_l2'], 'Saved classifier L2 differs')
                    saved = reader.json(base+'predictions.json')['predictions']
                    require([p['assembly_id'] for p in saved] == task['test_ids'], 'Saved held-out IDs differ')
                    x = matrices[ds, arm][[indices[ds][aid] for aid in task['test_ids']]]
                    z = _logits(model, x)
                    logit_error = float(np.max(np.abs(z-np.asarray([p['logit'] for p in saved]))))
                    probability_error = float(np.max(np.abs(sigmoid(z)-np.asarray([p['probability'] for p in saved]))))
                    require(logit_error < 1e-8 and probability_error < 1e-9, 'Original classifier replay failed')
                    worst_logit = max(worst_logit, logit_error)
                    worst_probability = max(worst_probability, probability_error)
                    replayed += len(saved)
                    self.models[ds, arm].append(dict(fold=fold, model=model,
                        model_sha256=reader.manifest[base+'model.npz'], training_examples=len(task['refit_ids'])))
            for ds, count in FOLD_COUNTS.items():
                for arm in ARMS:
                    require(len(self.models[ds, arm]) == count, 'Wrong number of source donor-fold classifiers')
            self.provenance = dict(source_run=SOURCE_RUN, source_manifest_sha256=SOURCE_MANIFEST_SHA256,
                checkpoint_sha256=CHECKPOINT_SHA256, selected_step=26000, classifier_refits=0,
                models=sum(map(len, self.models.values())), fold_counts=dict(FOLD_COUNTS),
                primary_arm='typed_context', comparator_arm='global_context',
                source_replay=dict(status='PASS', predictions=replayed,
                    maximum_logit_error=worst_logit, maximum_probability_error=worst_probability),
                source_files_sha256=dict(sorted(reader.verified.items())), target_labels_used=False,
                aggregation='Arithmetic mean of saved donor-fold classifier probabilities, equal weight per fold',
                interpretation='External application of BODE-trained CV-model ensembles; no full-data refit; uncalibrated',
                uncertainty_note='Fold dispersion is descriptive disagreement, not a confidence interval')
        finally:
            reader.close()

    def predict(self, features):
        ids = features['assembly_ids']
        manifest = features['manifest']
        require(len(ids) == len(set(ids)) == manifest['assemblies'] and
                digest(json.dumps(ids).encode()) == manifest['assembly_id_sha256'] and
                manifest['checkpoint_sha256'] == CHECKPOINT_SHA256, 'Target feature identity changed')
        require(set(features['matrices']) == set(ARMS), 'Target readout arm coverage changed')
        result = [dict(assembly_id=aid, predictions={ds: {} for ds in FOLD_COUNTS}) for aid in ids]
        for ds in FOLD_COUNTS:
            for arm in ARMS:
                x = features['matrices'][arm]
                require(x.shape == (len(ids), DIMENSIONS[arm]) and np.isfinite(x).all() and
                        matrix_digest(x) == manifest['matrix_sha256'][arm], 'Target feature matrix changed')
                per_fold = []
                for entry in self.models[ds, arm]:
                    z = _logits(entry['model'], x)
                    per_fold.append((entry, z, sigmoid(z)))
                probabilities = np.stack([p for _, _, p in per_fold])
                means = probabilities.mean(axis=0)
                stds = probabilities.std(axis=0)
                for i, row in enumerate(result):
                    row['predictions'][ds][arm] = dict(probability_mean=float(means[i]),
                        fold_probability_std=float(stds[i]), folds=len(per_fold),
                        fold_predictions=[dict(fold=entry['fold'], logit=float(z[i]), probability=float(p[i]),
                            model_sha256=entry['model_sha256']) for entry, z, p in per_fold])
        return dict(provenance=self.provenance, feature_manifest=manifest, assemblies=result)


def verify_feature_parity(features, source, dataset='bode1', *, atol=1e-12):
    """Independent development check against real sealed readout feature matrices.

Use historical routes and object states, not new target representations. Labels
are neither required nor inspected. Matching order is checked by assembly ID.
"""
    require(dataset in FOLD_COUNTS, 'Unknown feature-parity dataset')
    reader = _Source(source)
    try:
        with np.load(io.BytesIO(reader.read('assembly_features.npz')), allow_pickle=False) as archive:
            ids = [str(a) for a in archive[dataset+'_ids']]
            originals = dict(global_context=archive[dataset+'_global'].copy(),
                             typed_context=archive[dataset+'_typed_scores'][:, :2822].copy())
        require(set(ids) == set(features['assembly_ids']), 'Feature parity requires complete historical dataset')
        index = {a: i for i, a in enumerate(features['assembly_ids'])}
        errors = {}
        for arm in ARMS:
            x = features['matrices'][arm][[index[a] for a in ids]]
            errors[arm] = float(np.max(np.abs(x-originals[arm])))
            require(errors[arm] <= atol, 'Historical feature parity failed for '+arm)
        return dict(status='PASS', dataset=dataset, assemblies=len(ids), maximum_absolute_error=errors,
                    tolerance=atol, labels_used=False)
    finally:
        reader.close()
