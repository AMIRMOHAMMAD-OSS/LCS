#!/usr/bin/env python3
"""Frozen transfer predictions; assay interpretation remains a separate review."""
from __future__ import annotations
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import traceback
import zipfile

PACKAGE = Path(__file__).resolve().parent
SOURCE_MANIFEST_SHA256 = '441fb810607bc46b8bc992e6a229981fdf892359a1c038b50d78697da7015d3e'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def dump(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
    os.replace(temporary, path)


def event(stage, **values):
    print(json.dumps(dict(stage=stage, **values), allow_nan=False), flush=True)


def contained(directory, name):
    directory = Path(directory).resolve()
    path = (directory / name).resolve()
    require(not Path(name).is_absolute() and '..' not in Path(name).parts and directory in path.parents,
            'Unsafe source path: ' + name)
    return path


def verify_tree(directory, expected=None):
    directory = Path(directory)
    if expected is not None:
        require(sha(directory / 'SHA256SUMS') == expected, 'Dependency manifest changed: ' + str(directory))
    seen = set()
    for line in (directory / 'SHA256SUMS').read_text().splitlines():
        h, name = line.split('  ', 1)
        require(name not in seen, 'Duplicate checksum entry: ' + name)
        require(sha(contained(directory, name)) == h, 'Changed source file: ' + str(directory / name))
        seen.add(name)
    require(seen, 'Empty source manifest')
    return len(seen)


def locations(root):
    return dict(embedding=root / 'e10_tdomain_embed_696333',
                reference=root / 'e8_reference_scale_652486',
                classifier=root / 'e7_compat_readout_benchmark_646197',
                data=root / 'NeurALPS_TDomain_Data_20261006')


def preflight(root):
    root = Path(root).resolve()
    contract = load(PACKAGE / 'CONTRACT.json')
    verify_tree(PACKAGE)
    paths = locations(root)
    for name, h in contract['dependencies'].items():
        verify_tree(root / name, h)
    emb = paths['embedding']
    report = load(emb / 'report.json')
    require(report['status'] == 'TDOMAIN_EMBEDDINGS_COMPLETE', 'T-domain embeddings are incomplete')
    require(report['training_updates'] == 0 and report['activity_labels_used'] is False,
            'Embedding run unexpectedly used assay labels or training')
    require(report['engineered_constructs'] == 84 and report['native_controls'] == 4 and
            report['feature_sequences'] == 290 and report['feature_dimension'] == 1152,
            'Embedding counts changed')
    require(report['reference_gate']['status'] == 'PASS' and report['truncated_sequences'] == 0,
            'ESMC reference gate/truncation check failed')
    require(report['output_files_sha256'] == contract['embedding_files_sha256'], 'Different embedding output inventory')
    for name, h in contract['embedding_files_sha256'].items():
        require(sha(contained(emb, name)) == h, 'Observed embedding file changed: ' + name)
    rs = paths['reference']
    require(load(rs / 'summary.json')['status'] == 'REFERENCE_SCALE_COMPLETE', 'Reference scale is incomplete')
    rm = load(rs / 'artifact_manifest.json')
    reference_files = {}
    for name in ('reference.json', 'protocol.json', 'reference_seal.json', 'natural_scale_audit.json', 'summary.json'):
        require(name in rm and sha(contained(rs, name)) == rm[name], 'Reference artifact mismatch: ' + name)
        reference_files[name] = rm[name]
    require(load(rs / 'reference_seal.json')['reference_sha256'] == reference_files['reference.json'],
            'Reference seal mismatch')
    cp = paths['classifier']
    require(sha(cp / 'artifact_manifest.json') == SOURCE_MANIFEST_SHA256, 'Not the observed BODE readout run 646197')
    cm = load(cp / 'artifact_manifest.json')
    for name in ('PROTOCOL.json', 'summary.json', 'feature_manifest.json', 'splits.json', 'assembly_features.npz'):
        require(name in cm and sha(contained(cp, name)) == cm[name], 'Classifier source mismatch: ' + name)
    require(load(cp / 'summary.json')['status'] == 'COMPAT_READOUT_COMPLETE', 'BODE classifiers are incomplete')
    count = verify_tree(paths['data'], contract['dataset_manifest_sha256'])
    require(count == 91, 'Expected the original 91-file T-domain dataset')
    # Source validation reads BODE labels only. Target assay content is never parsed here.
    source = root / 'NeurALPS_ReferenceScale_20261006'
    sys.path.insert(0, str(source))
    common_rs = importlib.import_module('rs_common')
    require(Path(common_rs.__file__).resolve().parent == source, 'Wrong reference source module')
    common = common_rs.attach(root)
    context = common.project(root, root / 'e1_ssl_continue30_v1_530757')
    require(context['source_provenance']['best_checkpoint_sha256'] == contract['encoder_checkpoint_sha256']
            and context['ssl_summary']['selected_step'] == 26000, 'Frozen SSL26 checkpoint differs')
    request = dict(version=contract['version'], package_sha256=sha(PACKAGE / 'SHA256SUMS'),
                   protocol_sha256=sha(PACKAGE / 'PROTOCOL.json'), root=str(root),
                   embedding_report_sha256=sha(emb / 'report.json'),
                   embedding_files_sha256=contract['embedding_files_sha256'],
                   reference_files_sha256=reference_files, classifier_manifest_sha256=SOURCE_MANIFEST_SHA256,
                   dataset_manifest_sha256=contract['dataset_manifest_sha256'],
                   encoder_inputs=context['identities'])
    event('TDOMAIN_TRANSFER_PREFLIGHT_OK', engineered_constructs=84, native_controls=4,
          selected_step=26000, pretrained_weights_changed=False, classifier_fits=0,
          assay_evaluation='AFTER_PREDICTION_SEAL_AND_JOIN_REVIEW')
    return context, paths, request


def inspection(out):
    members = [p for p in sorted(out.rglob('*')) if p.is_file()
               and p.name not in ('transfer_inspection.zip', 'artifact_manifest.json')
               and not p.name.endswith('.tmp')]
    dump(out / 'artifact_manifest.json', {str(p.relative_to(out)): sha(p) for p in members})
    temporary = out / 'transfer_inspection.zip.tmp'
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for p in members + [out / 'artifact_manifest.json']:
            archive.write(p, p.relative_to(out))
    os.replace(temporary, out / 'transfer_inspection.zip')


def main(args):
    context, paths, request = preflight(args.root)
    if args.preflight_only:
        return
    require(args.out is not None, 'Use --out for an actual run')
    out = args.out.resolve()
    root = args.root.resolve()
    require(out.parent == root and out.name.startswith('e11_tdomain_transfer_'), 'Output must be a new e11_tdomain_transfer directory under the project')
    out.mkdir(exist_ok=False)
    args.owned_output = out
    started = time.monotonic()
    dump(out / 'request.json', request)
    shutil.copyfile(PACKAGE / 'PROTOCOL.json', out / 'PROTOCOL.json')
    shutil.copyfile(PACKAGE / 'CONTRACT.json', out / 'CONTRACT.json')
    input_metadata = out / 'input_metadata'
    input_metadata.mkdir()
    for name in ('input_manifest.json', 'construct_annotation_qc.json'):
        source_name = 'annotation/' + name
        destination = input_metadata / name
        shutil.copyfile(paths['embedding'] / source_name, destination)
        require(sha(destination) == request['embedding_files_sha256'][source_name],
                'Annotation metadata changed during copy: ' + name)
    shutil.copyfile(paths['embedding'] / 'report.json', input_metadata / 'embedding_report.json')
    require(sha(input_metadata / 'embedding_report.json') == request['embedding_report_sha256'],
            'Embedding report changed during copy')
    import numpy as np
    import torch
    require(torch.__version__.split('+')[0] == '2.8.0' and torch.cuda.is_available() and torch.cuda.device_count() == 1,
            'Use the pinned PyTorch 2.8.0 one-GPU allocation')
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.use_deterministic_algorithms(True)
    context['device'] = 'cuda'
    runtime = dict(torch=torch.__version__, numpy=np.__version__, cuda=torch.version.cuda,
                   device=torch.cuda.get_device_name(0), inference_dtype='float32', tf32=False,
                   deterministic_algorithms=True)
    dump(out / 'runtime.json', runtime)
    identity = dict(request=request, runtime=runtime)
    dump(out / 'pre_inference_seal.json', dict(request_sha256=sha(out / 'request.json'),
         protocol_sha256=sha(out / 'PROTOCOL.json'), target_assay_values_used=False))
    from td_scoring import run_scoring
    score_dir = out / 'scores'
    score_dir.mkdir()
    scoring = run_scoring(context, paths['embedding'], paths['reference'], score_dir, identity)
    require(scoring is not None, 'Scoring did not complete')
    event('TDOMAIN_FROZEN_SCORING_COMPLETE')
    import gzip
    with gzip.open(score_dir / 'records.json.gz', 'rt') as stream:
        records = json.load(stream)
    from td_classifiers import build_features, ClassifierBank
    features = build_features(records, score_dir / 'representations.npz',
                              checkpoint_sha256=load(PACKAGE / 'CONTRACT.json')['encoder_checkpoint_sha256'])
    bank = ClassifierBank(paths['classifier'])
    predictions = bank.predict(features)
    dump(out / 'classifier_predictions.json', predictions)
    event('TDOMAIN_CLASSIFIER_TRANSFER_COMPLETE', new_fits=0)
    from td_summary import summarize, collect_assay_packet
    mapping = summarize(out, records=records,
                        input_manifest=input_metadata / 'input_manifest.json',
                        annotation_qc=input_metadata / 'construct_annotation_qc.json',
                        raw_rows=score_dir / 'raw_objects.jsonl.gz',
                        scaled_rows=score_dir / 'scaled_objects.jsonl.gz',
                        classifier_predictions=out / 'classifier_predictions.json')
    seal_files = {str(p.relative_to(out)): sha(p) for p in sorted(out.rglob('*')) if p.is_file()}
    dump(out / 'prediction_seal.json', dict(status='TDOMAIN_PREDICTIONS_SEALED', version=request['version'], files=seal_files,
         target_activity_labels_used=False, target_activity_labels_joined=False,
         classifier_fits=0, pretrained_weights_changed=False))
    # Only now collect unchanged source assay records. This does not interpret them.
    packet = collect_assay_packet(paths['data'], out / 'assay_packet', out / 'prediction_seal.json')
    summary = dict(status='TDOMAIN_TRANSFER_PREDICTIONS_COMPLETE',
                   engineered_constructs=84, native_controls=4, selected_step=26000,
                   pretrained_weights_changed=False, training_updates=0, classifier_fits=0,
                   target_activity_labels_used_for_predictions=False,
                   predictions_sealed_before_assay_collection=True,
                   assay_metrics_computed=False, assay_join_review_required=True,
                   full_context_reference_scale_reused=True, local_only_raw_ablation=True,
                   scoring={k: scoring[k] for k in ('assemblies', 'physical_objects', 'raw_status_counts',
                       'local_only_status_counts', 'scale_status_counts')}, mapping=mapping,
                   assay_packet={k: packet[k] for k in ('status', 'copied_files', 'assay_labels_joined', 'assay_metrics')},
                   next_step='Review the collected frozen assay records and sequence joins; then compute the declared external metrics from sealed predictions.',
                   seconds=round(time.monotonic() - started, 3))
    dump(out / 'summary.json', summary)
    (out / 'PREDICTIONS_COMPLETE').write_text(request['version'] + '\n')
    inspection(out)
    print(json.dumps(summary, indent=2, allow_nan=False), flush=True)
    print('Inspection:', out / 'transfer_inspection.zip', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--preflight-only', action='store_true')
    args = parser.parse_args()
    try:
        main(args)
    except Exception:
        if getattr(args, 'owned_output', None):
            dump(args.owned_output / 'fatal_error.json', dict(status='FAILED', traceback=traceback.format_exc()))
            inspection(args.owned_output)
        raise
