#!/usr/bin/env python3
"""Replay real saved classifiers and prove pooling parity on real BODE30 states.

python selftest_classifiers.py --readout-inspection compat_readout_inspection.zip \
    --bode30-inspection bode_inspection_bode30_541171.zip
Both inputs may alternatively be the corresponding full run directories.
No GPU, fitting, target assay labels, or scientific performance selection.
"""
import argparse
import json
from pathlib import Path
import tempfile
import zipfile

from td_classifiers import (ClassifierBank, CHECKPOINT_SHA256, ARMS, build_features,
                            digest, require, verify_feature_parity)


class Reader:
    def __init__(self, source):
        self.path = Path(source)
        self.zip = zipfile.ZipFile(self.path) if self.path.is_file() else None

    def read(self, name):
        return self.zip.read(name) if self.zip is not None else (self.path/name).read_bytes()

    def close(self):
        if self.zip is not None:
            self.zip.close()


def selftest(readout_inspection, bode30_inspection):
    bank = ClassifierBank(readout_inspection)
    source, original = Reader(readout_inspection), Reader(bode30_inspection)
    try:
        pins = json.loads(source.read('INPUTS.json'))['sources']['bode1']['files']
        maps_bytes = original.read('maps.json')
        representations = original.read('representations.npz')
        require(digest(maps_bytes) == pins['maps.json'] and
                digest(representations) == pins['representations.npz'],
                'Historical BODE30 source differs from original readout inputs')
        maps = json.loads(maps_bytes)
        objects = {}
        for query in maps['queries']:
            if query['mode'] != ('joint_terminal_recovery' if query['kind'] == 2 else 'object_recovery'):
                continue
            key = (query['assembly_id'], query['object_index'])
            require(key not in objects, 'Repeated historical physical query')
            objects[key] = query['kind']
        records = {}
        for aid in sorted({a for a, j in objects}):
            indices = sorted(j for a, j in objects if a == aid)
            require(indices == list(range(len(indices))), 'Historical object coverage incomplete')
            records[aid] = {'route': [{'kind': objects[aid, j]} for j in indices]}
        with tempfile.TemporaryDirectory(prefix='tdomain_classifier_test_') as work:
            representation_path = Path(work)/'representations.npz'
            representation_path.write_bytes(representations)
            features = build_features(records, representation_path, checkpoint_sha256=CHECKPOINT_SHA256)
            parity = verify_feature_parity(features, readout_inspection)
            result = bank.predict(features)
            for assembly in result['assemblies']:
                for ds, count in (('bode1', 21), ('bode2', 35)):
                    for arm in ARMS:
                        values = assembly['predictions'][ds][arm]
                        require(len(values['fold_predictions']) == values['folds'] == count,
                                'Prediction fold coverage differs')
                        expected = sum(p['probability'] for p in values['fold_predictions'])/count
                        require(abs(expected-values['probability_mean']) < 1e-14 and 0 <= expected <= 1,
                                'Probability aggregation failed')
            features['matrices']['typed_context'][0, 0] += 1
            try:
                bank.predict(features)
            except ValueError as exc:
                require(str(exc) == 'Target feature matrix changed', 'Unexpected matrix-rejection reason')
            else:
                raise AssertionError('Modified target feature matrix was accepted')
            try:
                build_features(records, representation_path, checkpoint_sha256='0'*64)
            except ValueError as exc:
                require(str(exc) == 'Wrong target representation checkpoint', 'Unexpected checkpoint rejection')
            else:
                raise AssertionError('Wrong checkpoint accepted')
        return dict(status='CLASSIFIER_SELFTEST_PASS', real_source_replay=bank.provenance['source_replay'],
                    real_feature_parity=parity, saved_models=bank.provenance['models'],
                    aggregation_checks=324*4, per_model_inference_checks=324*112,
                    changed_matrix_rejected=True, wrong_checkpoint_rejected=True,
                    new_target_predictions_run=False, new_target_labels_used=False)
    finally:
        source.close()
        original.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--readout-inspection', required=True, type=Path)
    parser.add_argument('--bode30-inspection', required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(selftest(args.readout_inspection, args.bode30_inspection), sort_keys=True))
