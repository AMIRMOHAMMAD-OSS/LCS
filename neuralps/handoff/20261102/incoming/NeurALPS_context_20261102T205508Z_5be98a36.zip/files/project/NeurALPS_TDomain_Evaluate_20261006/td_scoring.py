"""Frozen SSL26 inference over the separately sealed T-domain feature sidecar.

run_scoring(context, embedding_run, reference_run, out, identity,
            stopping=None, progress=None) -> report or None on requested stop.

context is the validated Ensemble common.project(root, SSL26) result. The caller
pins package manifests and the observed e10/e8 run identities before calling;
this module additionally verifies their internal file/score seals. out must
already exist. No activity label, classifier, candidate panel, or fitting is
used. The e8 natural reference applies ONLY to the full-context native score.
The local-only score is a separate inference ablation, without a fitted scale.
"""
from __future__ import annotations

import ast
from collections import Counter
import gzip
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import sqlite3
import sys

CHECKPOINT_SHA = "9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f"
SELECTED_STEP = 26000
DIM = 1152
FILES = ("raw_objects.jsonl.gz", "scaled_objects.jsonl.gz", "representations.npz",
         "records.json.gz", "scoring_report.json")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            result.update(block)
    return result.hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def _event(progress, stage, **fields):
    event = dict(stage=stage, **fields)
    if progress is None:
        print(canonical(event), flush=True)
    else:
        progress(event)


def _stopped(stopping):
    return bool(stopping and stopping.get("signal"))


def _member(package, name):
    """Caller pins manifest identity; also enforce the requested member digest."""
    entries = {}
    for line in (package / "SHA256SUMS").read_text().splitlines():
        value, relative = line.split("  ", 1)
        require(relative not in entries, "Duplicate package checksum member")
        entries[relative] = value
    require(name in entries and sha(package / name) == entries[name], "Pinned dependency changed: " + str(package / name))
    return package / name


def _module(name, path):
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def _local_prediction_function(path, torch):
    tree = ast.parse(path.read_text(), filename=str(path))
    matches = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "local_prediction"]
    require(len(matches) == 1 and not matches[0].decorator_list, "Original local-only prediction function differs")
    namespace = dict(torch=torch)
    exec(compile(ast.fix_missing_locations(ast.Module(body=matches, type_ignores=[])), str(path), "exec"), namespace)
    return namespace["local_prediction"]


class SidecarStore:
    """Read-only new vector/parent lookups with untouched original-store fallback.

    Newly extracted exact-hash hits use the sealed sidecar vector. Frozen target
    means and natural candidate assets remain those of the original runtime.
    No new row indices are inserted into the original natural feature matrix.
    """
    def __init__(self, base, embedding_run, records, sequences, parents, index_rows):
        import numpy as np
        self.base = base
        self.path = Path(embedding_run)
        self.new_rows = {h: i for h, _, i in index_rows}
        self.new_z = np.memmap(self.path / "features.f32", mode="r", dtype="<f4", shape=(len(index_rows), DIM))
        self.new_parents = parents
        self.new_sequences = sequences
        # These properties still refer strictly to the original natural store.
        self.rows, self.z, self.db = base.rows, base.z, base.db
        require(np.isfinite(self.new_z).all() and (np.linalg.norm(self.new_z.astype(np.float64), axis=1) > 0).all(),
                "Nonfinite or zero sidecar feature")

    def vector(self, sequence_hash):
        import numpy as np
        if sequence_hash in self.new_rows:
            return np.array(self.new_z[self.new_rows[sequence_hash]], copy=True)
        return self.base.vector(sequence_hash)

    def parent(self, parent_hash):
        if parent_hash in self.new_parents:
            return self.new_parents[parent_hash]
        return self.base.parent(parent_hash)


def load_sidecar(root, embedding_run):
    """Validate actual e10 output and return label-free records and lookup data."""
    root, path = Path(root).resolve(), Path(embedding_run).resolve()
    require(path.parent == root, "Embedding run must belong to this project")
    report = load(path / "report.json")
    require((path / "EMBEDDINGS_COMPLETE").read_text().strip() == sha(path / "report.json"),
            "Embedding completion seal differs")
    require(report["status"] == "TDOMAIN_EMBEDDINGS_COMPLETE" and report["feature_dimension"] == DIM and
            report["feature_extraction_mode"] == "independent_sequence" and report["training_updates"] == 0 and
            report["activity_labels_used"] is False, "Unexpected embedding run contract")
    for name, expected in report["output_files_sha256"].items():
        member = (path / name).resolve()
        require(path in member.parents and sha(member) == expected, "Embedding artifact changed: " + name)
    package = root / "NeurALPS_TDomain_Embed_20261006"
    embedding = _module("td_verified_embedding_inputs", _member(package, "run_embeddings.py"))
    sequence_path, parent_path = path / "inputs/unique_sequences.fasta.gz", path / "inputs/parents.fasta.gz"
    sequences, parents = embedding.fasta(sequence_path), embedding.fasta(parent_path)
    with gzip.open(path / "inputs/routes.jsonl.gz", "rt") as stream:
        rr = [json.loads(line) for line in stream if line.strip()]
    vocabulary = load(_member(package, "domain_vocabulary.json"))["vocab"]
    counts, _ = embedding.validate_routes(rr, sequences, parents, vocabulary)
    require(counts["unique_features"] == report["feature_sequences"] == len(sequences), "Feature coverage differs")
    require(len(rr) == report["engineered_constructs"] + report["native_controls"], "Assembly coverage differs")
    records = {r["assembly_id"]: r for r in rr}
    require(len(records) == len(rr), "Duplicate sidecar assembly ID")
    db = sqlite3.connect((path / "feature_index.sqlite3").as_uri() + "?mode=ro", uri=True)
    try:
        require(db.execute("PRAGMA integrity_check").fetchone()[0] == "ok", "Sidecar index integrity failure")
        indexed = list(db.execute("SELECT hash,length,feature_row,status FROM features ORDER BY feature_row"))
        metadata = {key: json.loads(value) for key, value in db.execute("SELECT key,value FROM metadata")}
    finally:
        db.close()
    require(len(indexed) == len(sequences) and {h for h, _, _, _ in indexed} == set(sequences), "Sidecar hash index differs")
    for row, (h, length, position, status) in enumerate(indexed):
        require(position == row and status == "covered" and length == len(sequences[h]), "Invalid sidecar index row")
    require(metadata["feature_extraction_mode"] == "independent_sequence" and metadata["embedding_dimension"] == DIM and
            metadata["storage_dtype"] == "float32" and metadata["storage_byte_order"] == "little", "Sidecar representation format differs")
    require((path / "features.f32").stat().st_size == len(indexed) * DIM * 4, "Sidecar matrix byte count differs")
    return records, sequences, parents, [(h, n, i) for h, n, i, _ in indexed], dict(
        report_sha256=sha(path / "report.json"), files_sha256=report["output_files_sha256"], counts=counts)


def load_reference(root, reference_run, scale):
    """Read the completed e8 reference without any rebuilding or target fitting."""
    root, path = Path(root).resolve(), Path(reference_run).resolve()
    require(path.parent == root and (path / "REFERENCE_SCALE_COMPLETE").is_file(), "Completed reference run required")
    summary = load(path / "summary.json")
    require(summary["status"] == "REFERENCE_SCALE_COMPLETE" and summary["selected_step"] == SELECTED_STEP and
            summary["activity_labels_used_for_scale"] is False, "Unexpected natural reference source")
    reference, protocol, identity = load(path / "reference.json"), load(path / "protocol.json"), load(path / "identity.json")
    seal, prescore = load(path / "reference_seal.json"), load(path / "pre_inference_seal.json")
    require(seal["reference_sha256"] == sha(path / "reference.json") and seal["calibration_components_only"] and
            not seal["bode_activity_outcomes_used"] and not seal["audit_scores_used_to_fit_reference"], "Reference seal differs")
    require(prescore["protocol_sha256"] == sha(path / "protocol.json") and
            prescore["identity_sha256"] == sha(path / "identity.json"), "Reference pre-inference seal differs")
    require(protocol == load(_member(root / "NeurALPS_ReferenceScale_20261006", "PROTOCOL.json")),
            "Run reference protocol differs from the frozen package")
    require(protocol["checkpoint_sha256"] == CHECKPOINT_SHA and identity["request"]["checkpoint_sha256"] == CHECKPOINT_SHA and
            reference["protocol_sha256"] == scale.digest(protocol), "Natural reference model/protocol mismatch")
    artifact = load(path / "artifact_manifest.json")
    needed = ("reference.json", "protocol.json", "identity.json", "summary.json", "natural_scale_audit.json",
              "reference_seal.json", "pre_inference_seal.json")
    for name in needed:
        require(artifact.get(name) == sha(path / name), "Natural reference artifact changed: " + name)
    audit = load(path / "natural_scale_audit.json")
    return reference, protocol, {g["reference_key"]: g for g in audit["groups"]}, {
        "run": str(path), "files_sha256": {name: sha(path / name) for name in needed},
        "reference_groups": len(reference["groups"]), "reference_fitted_here": False}


def _local_scores(record, rows, runtime, model, collate, local_prediction, stopping):
    import numpy as np
    import torch
    by_object = {j: slots for j, slots in _physical_queries(record)}
    eligible = [row for row in rows if row["status"] == "SCORED"]
    for row in rows:
        row.update(local_only_native_score=None, local_only_reconstruction_error=None,
                   local_only_status=row["status"] if row["status"] != "SCORED" else "PENDING",
                   global_effect_on_native_score=None, local_only_is_evaluation_ablation=True)
    for start in range(0, len(eligible), 8):
        if _stopped(stopping):
            return False
        selected = eligible[start:start + 8]
        batch = collate([record] * len(selected), runtime.store.vector)
        for b, row in enumerate(selected):
            for j, role in row["hidden_slots"]:
                batch["state"][b, j, role] = 4
                batch["x"][b, j, role] = float("nan")
        batch = {k: v.to(runtime.device) for k, v in batch.items()}
        with torch.no_grad():
            predicted = local_prediction(model, batch)
            require(bool(torch.isfinite(predicted).all()), "Nonfinite local-only prediction")
            for b, row in enumerate(selected):
                j = row["object_index"]
                slots = by_object[j]
                roles = [s["slot"] for s in slots]
                target = torch.as_tensor(np.stack([runtime.store.vector(s["sequence_hash"]) for s in slots]), device=runtime.device)
                mean = torch.as_tensor(np.stack([runtime.targets.mean(s) for s in slots]), device=runtime.device)
                mixed, _ = runtime.ssl.slot_loss(predicted[b, j, roles], target, mean)
                error = float(mixed.mean().item())
                score = float((1 - mixed.mean()).item())
                require(np.isfinite([error, score]).all() and -1.00001 <= score <= 1.00001, "Invalid local-only score")
                row.update(local_only_native_score=score, local_only_reconstruction_error=error,
                           local_only_status="SCORED", global_effect_on_native_score=row["native_score"] - score)
    return True


def _physical_queries(record):
    by_object = {}
    for slot in record["model_slots"]:
        by_object.setdefault(slot["object_index"], []).append(slot)
    return [(j, sorted(by_object[j], key=lambda s: s["slot"])) for j in range(len(record["route"]))]


def _gzip_rows(path, rows):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_bytes(gzip.compress("".join(canonical(row) + "\n" for row in rows).encode(), mtime=0))
    os.replace(temporary, path)


def run_scoring(context, embedding_run, reference_run, out, identity, stopping=None, progress=None):
    import numpy as np
    import torch
    root, out = Path(context["root"]).resolve(), Path(out).resolve()
    require(out.is_dir() and not any((out / name).exists() for name in FILES), "Fresh scoring output directory required")
    require(context["source_provenance"]["best_checkpoint_sha256"] == CHECKPOINT_SHA and
            context["ssl_summary"]["selected_step"] == SELECTED_STEP, "The pinned SSL26 checkpoint is required")
    reference_package = root / "NeurALPS_ReferenceScale_20261006"
    scorer_path, scale_path = _member(reference_package, "score_native.py"), _member(reference_package, "scale.py")
    scorer = _module("td_frozen_native_scorer", scorer_path)
    scale = _module("td_frozen_reference_scale", scale_path)
    records, sequences, parents, index_rows, embedding_proof = load_sidecar(root, embedding_run)
    reference, protocol, audit_groups, reference_proof = load_reference(root, reference_run, scale)
    if _stopped(stopping):
        return None
    ensemble = root / "NeurALPS_Ensemble_20261004"
    sys.path.insert(0, str(ensemble))
    sys.path.insert(0, str(Path(context["base"]) / "src"))
    frozen = importlib.import_module("frozen_runtime")
    require(Path(frozen.__file__).resolve() == _member(ensemble, "frozen_runtime.py").resolve(), "Wrong frozen runtime import")
    assembly_model = importlib.import_module("assembly_model")
    require(Path(assembly_model.__file__).resolve() == (Path(context["base"]) / "src/assembly_model.py").resolve(),
            "Wrong original encoder module import")
    collate_records = assembly_model.collate_records
    require(scorer.CHECKPOINT_SHA256 == CHECKPOINT_SHA and scorer.SELECTED_STEP == SELECTED_STEP, "Scorer checkpoint contract changed")
    # Bootstrap only an existing original-store record. The discarded TensorBank
    # requires a label tensor; a constant dummy value avoids reading its assay.
    aid = min(context["records"], key=lambda a: (len(context["records"][a]["route"]), a))
    bootstrap = dict(scorer._clean_record(aid, context["records"][aid]), label=0)
    runtime = frozen.open_runtime(dict(context, records={aid: bootstrap}), context.get("device", "cuda"))
    base_store = runtime.store
    require(runtime.identities["best_checkpoint_sha256"] == CHECKPOINT_SHA, "Loaded checkpoint identity differs")
    del runtime.bank
    model = None
    rows, states, pools, offsets = [], [], [], [0]
    ids = sorted(records)
    try:
        runtime.store = SidecarStore(base_store, embedding_run, records, sequences, parents, index_rows)
        model = runtime.build("ssl").eval()
        model.requires_grad_(False)
        require(not model.training and not any(p.requires_grad for p in model.parameters()), "Encoder is not frozen")
        vocabulary = load(Path(context["base"]) / "domain_vocabulary.json")["vocab"]
        names = {int(value): key for key, value in vocabulary.items()}
        local_path = _member(root / "NeurALPS_BODE30_20261003", "natural_maps.py")
        local_prediction = _local_prediction_function(local_path, torch)
        for number, aid in enumerate(ids, 1):
            if _stopped(stopping):
                return None
            record = records[aid]
            clean = scorer._clean_record(aid, record)
            # Original e8 full-context scoring, loss and physical closure intact.
            current = scorer._score_one(clean, runtime, model, collate_records, names, stopping)
            if current is None or not _local_scores(clean, current, runtime, model, collate_records, local_prediction, stopping):
                return None
            rows.extend(current)
            with torch.no_grad():
                batch = {k: v.to(runtime.device) for k, v in collate_records([clean], runtime.store.vector).items()}
                h = model.features(batch)
                pooled = frozen.pool_objects(h, batch)
                require(tuple(h.shape) == (1, len(clean["route"]), 256) and tuple(pooled.shape) == (1, 770),
                        "Frozen representation dimensions differ")
                require(bool(torch.isfinite(h).all()) and bool(torch.isfinite(pooled).all()), "Nonfinite frozen representation")
                states.append(h[0].cpu().numpy())
                pools.append(pooled[0].cpu().numpy())
                offsets.append(offsets[-1] + len(clean["route"]))
            _event(progress, "TDOMAIN_FROZEN_SCORING", completed=number, total=len(ids),
                   assembly_id=aid, physical_objects=len(current), scored=sum(r["status"] == "SCORED" for r in current))
        scaled = []
        for row in rows:
            result = scale.apply_one(row, reference, protocol)
            group = audit_groups.get(result["reference_key"], {})
            result.update(reference_audit_status=group.get("rate_assessment", "NO_AUDIT_SUPPORT"),
                reference_audit_components=group.get("audit_components", 0),
                reference_audit_warning_rate=group.get("warning_rate"),
                engineered_false_alarm_control_validated=False,
                natural_scale_applies_to="full_context_native_score", local_only_natural_scale_available=False)
            scaled.append(result)
        _gzip_rows(out / "raw_objects.jsonl.gz", rows)
        _gzip_rows(out / "scaled_objects.jsonl.gz", scaled)
        (out / "records.json.gz").write_bytes(gzip.compress(canonical(records).encode(), mtime=0))
        temporary = out / "representations.npz.tmp"
        with temporary.open("wb") as stream:
            np.savez_compressed(stream, assembly_ids=np.asarray(ids), object_offsets=np.asarray(offsets),
                                object_states=np.concatenate(states), assembly_readout=np.stack(pools))
        os.replace(temporary, out / "representations.npz")
        report = dict(status="TDOMAIN_FROZEN_SCORING_COMPLETE", identity=identity,
            checkpoint_sha256=CHECKPOINT_SHA, selected_step=SELECTED_STEP,
            assemblies=len(ids), physical_objects=len(rows),
            raw_status_counts=dict(Counter(r["status"] for r in rows)),
            local_only_status_counts=dict(Counter(r["local_only_status"] for r in rows)),
            scale_status_counts=dict(Counter(r["scale_status"] for r in scaled)),
            source_embedding=str(Path(embedding_run).resolve()), source_reference=str(Path(reference_run).resolve()),
            embedding_provenance=embedding_proof, natural_reference_provenance=reference_proof,
            original_cache_hash_overlap=sum(h in base_store.rows for h in sequences),
            duplicate_hash_lookup_policy="sealed_new_sidecar_for_new_inputs; original_store_unchanged",
            scorer_source_sha256=sha(scorer_path), scale_source_sha256=sha(scale_path),
            local_prediction_source_sha256=sha(local_path), representation_schema="original_cr_features_256_770_v1",
            model_updated=False, labels_read_for_scoring=False, reference_fitted=False,
            candidate_panels_generated=False, typed_context_scores_features_generated=False,
            local_only_is_evaluation_ablation=True, local_only_natural_scale_available=False,
            files_sha256={name: sha(out / name) for name in FILES if name != "scoring_report.json"})
        temporary = out / "scoring_report.json.tmp"
        temporary.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n")
        os.replace(temporary, out / "scoring_report.json")
        return report
    finally:
        if model is not None:
            del model
        base_store.db.close()
        if torch.cuda.is_available() and str(runtime.device).startswith("cuda"):
            torch.cuda.empty_cache()
