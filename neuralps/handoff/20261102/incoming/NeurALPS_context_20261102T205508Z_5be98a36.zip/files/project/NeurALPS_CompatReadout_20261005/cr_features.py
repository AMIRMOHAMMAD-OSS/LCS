"""Label-blind features from the already frozen SSL26 representation/map files."""
import io,json
from pathlib import Path
from collections import Counter
import numpy as np
from cr_common import require,digest,ARMS

KINDS=('domain','covalent_boundary','protein_break')
GROUPS=((0,256),(256,1536),(1536,2816))
COUNTS=slice(2816,2822)
SCORES=((2822,2824),(2824,2826),(2826,2828))

class Features:
    def __init__(self,records,reader,spec):
        """Only route structure and frozen label-free arrays/scores enter X."""
        maps=reader.json(spec['maps'])
        with np.load(io.BytesIO(reader.bytes(spec['representations'])),allow_pickle=False) as z:
            require(set(z.files)=={'assembly_ids','object_offsets','object_states','assembly_readout'},'Unexpected representation schema')
            self.ids=[str(a) for a in z['assembly_ids']];offset=z['object_offsets'].copy();states=z['object_states'].astype(np.float64)
            global_x=z['assembly_readout'].astype(np.float64)
        require(len(self.ids)==len(set(self.ids)) and set(self.ids)==set(records),'Representation IDs differ')
        require(offset.shape==(len(self.ids)+1,) and offset[0]==0 and offset[-1]==len(states) and np.all(np.diff(offset)>0),'Invalid object offsets')
        require(states.shape[1]==256 and global_x.shape==(len(self.ids),770),'Wrong encoder feature dimensions')
        require(np.isfinite(states).all() and np.isfinite(global_x).all(),'Nonfinite frozen features')
        selected={};all_query_ids=set()
        for q in maps['queries']:
            require(q['query_id'] not in all_query_ids,'Duplicate query');all_query_ids.add(q['query_id'])
            kind=q['kind'];expected='joint_terminal_recovery' if kind==2 else 'object_recovery'
            if q['mode']!=expected:continue
            key=(q['assembly_id'],q['object_index']);require(key not in selected,'Duplicate physical object query')
            require(q['status']=='SCORED' and q['reference_size']>0,'Missing score or natural reference panel')
            refs=q['reference_scores'];require(len(refs)==q['reference_size'],'Reference count differs')
            require(np.isfinite([q['native_score'],q['relative_score'],*refs]).all(),'Nonfinite context score')
            require(abs(q['native_score']-np.mean(refs)-q['relative_score'])<1e-10,'Relative context score differs')
            selected[key]=q
        self.index={a:i for i,a in enumerate(self.ids)};self.objects={};self.rows={};self.counts={}
        typed=[];score_x=[];n_expected=0
        for i,aid in enumerate(self.ids):
            route=records[aid]['route'];h=states[offset[i]:offset[i+1]]
            require(len(route)==len(h),'Route/state offsets differ')
            kinds=np.asarray([o['kind'] for o in route]);require(set(kinds)<={0,1,2},'Unknown object kind')
            d=h[kinds==0];b=h[kinds!=0];require(len(d)>0 and len(b)>0,'Empty required pool')
            pooled=np.concatenate([d.mean(0),b.mean(0),b.max(0),np.log1p([len(d),len(b)])])
            require(np.allclose(pooled,global_x[i],rtol=2e-5,atol=2e-6),'Cached global pooling differs from object states')
            groups=[[],[],[]];scores=[[],[],[]];rows=[];vectors=[]
            for j,obj in enumerate(route):
                k=obj['kind'];q=selected.get((aid,j));require(q is not None and q['kind']==k,'Missing or mismatched physical-object query')
                if k==0:v=h[j]
                else:
                    require(0<j<len(route)-1 and kinds[j-1]==kinds[j+1]==0,'Boundary neighbors are not domains')
                    left,right=h[j-1],h[j+1];v=np.concatenate([left,h[j],right,left*right,np.abs(left-right)])
                s=np.asarray([q['native_score'],q['relative_score']]);groups[k].append(v);scores[k].append(s)
                rows.append(dict(assembly_id=aid,object_index_0based=j,object_kind=KINDS[k],kind=k,
                    object_id=obj.get('occurrence_id',obj.get('boundary_id','')),query_id=q['query_id'],
                    domain_type_label=q['label'],query_mode=q['mode'],native_agreement=float(s[0]),
                    agreement_above_reference_mean=float(s[1]),native_context_percentile_0_to_100=100*q['reference_percentile'],
                    source_domain_uid=obj.get('source_domain_uid',''),left_domain_uid=obj.get('left_domain_uid',''),
                    right_domain_uid=obj.get('right_domain_uid',''),physical_windows_json=json.dumps(q['slots'],sort_keys=True,separators=(',',':'))))
                vectors.append((k,v,s));n_expected+=1
            counts=np.array([len(g) for g in groups]);self.counts[aid]=counts
            means=[np.mean(g,axis=0) if len(g) else np.zeros(256 if k==0 else 1280) for k,g in enumerate(groups)]
            extra=np.asarray([v for n in counts for v in (np.log1p(n),float(n>0))])
            typed.append(np.concatenate([*means,extra]));score_x.append(np.concatenate([np.mean(s,axis=0) if len(s) else np.zeros(2) for s in scores]))
            self.objects[aid]=vectors;self.rows[aid]=rows
        require(n_expected==len(selected),'Map has unrecognized assemblies/objects')
        typed=np.asarray(typed);self.X={ARMS[0]:global_x,ARMS[1]:typed,ARMS[2]:np.concatenate([typed,score_x],axis=1)}
        require([self.X[a].shape[1] for a in ARMS]==[770,2822,2828],'Feature layout changed')
        self.manifest=dict(assemblies=len(self.ids),physical_objects=n_expected,
            object_counts=dict(Counter(r['object_kind'] for rows in self.rows.values() for r in rows)),
            dimensions={a:int(x.shape[1]) for a,x in self.X.items()},
            matrix_sha256={a:digest(np.asarray(x,dtype='<f8').tobytes()) for a,x in self.X.items()},
            assembly_id_sha256=digest(json.dumps(self.ids).encode()),labels_read_by_feature_builder=False)
    def matrix(self,arm,ids):return self.X[arm][[self.index[a] for a in ids]]

def save_assembly_features(path,features):
    """Small exact readout inputs permit later independent prediction replay."""
    path=Path(path);arrays={}
    for ds,f in features.items():
        arrays[ds+'_ids']=np.asarray(f.ids)
        arrays[ds+'_global']=f.X[ARMS[0]]
        arrays[ds+'_typed_scores']=f.X[ARMS[2]]
    tmp=path.with_name(path.name+'.tmp')
    with tmp.open('wb') as stream:np.savez_compressed(stream,**arrays)
    tmp.replace(path)

def local_contributions(features,aid,model,task_id):
    """Exact linear decomposition; signed evidence is not a fault probability."""
    w=model['weight'];mu=model['mean'];scale=model['scale'];active=model['active']
    x=features.matrix(ARMS[2],[aid])[0];coef=w*active/scale
    z=float(np.dot(coef,x-mu)+model['intercept']);context=float(model['intercept']+np.dot(coef[COUNTS],(x-mu)[COUNTS]))
    counts=features.counts[aid];rows=[]
    for k,(lo,hi) in enumerate(GROUPS):
        slo,shi=SCORES[k]
        if not counts[k]:context+=float(-np.dot(coef[lo:hi],mu[lo:hi])-np.dot(coef[slo:shi],mu[slo:shi]))
    for row,(k,v,s) in zip(features.rows[aid],features.objects[aid]):
        lo,hi=GROUPS[k];slo,shi=SCORES[k];n=int(counts[k])
        ev=float(np.dot(coef[lo:hi],v-mu[lo:hi]));sev=float(np.dot(coef[slo:shi],s-mu[slo:shi]))
        rows.append(dict(task_id=task_id,arm=ARMS[2],**row,objects_of_this_kind=n,
            type_absent_from_training=bool(mu[2816+2*k+1]==0),
            embedding_logit_contribution=ev/n,context_score_logit_contribution=sev/n,
            total_logit_contribution=(ev+sev)/n,unpooled_signed_evidence=ev+sev,
            assembly_context_logit_term=context,assembly_logit=z,score_is_probability=False,causal_fault_validated=False))
    require(abs(context+sum(r['total_logit_contribution'] for r in rows)-z)<1e-8,'Local decomposition does not reproduce assembly logit')
    return rows
