#!/usr/bin/env python3
"""Read-only independent replay from the inspection ZIP; no cluster files needed."""
import argparse,io,json,zipfile
import numpy as np
from cr_common import require,digest,ARMS,emit
from cr_solver import predict
from cr_metrics import probabilities

def replay(path):
    with zipfile.ZipFile(path) as z:
        names=z.namelist();require(len(names)==len(set(names)),'Duplicate ZIP entries')
        manifest=json.loads(z.read('artifact_manifest.json'))
        for name,h in manifest.items():require(digest(z.read(name))==h,'Inspection file changed: '+name)
        feature_manifest=json.loads(z.read('feature_manifest.json'))
        with np.load(io.BytesIO(z.read('assembly_features.npz')),allow_pickle=False) as f:arrays={k:f[k].copy() for k in f.files}
        matrices={};indices={}
        for ds,info in feature_manifest.items():
            ids=[str(a) for a in arrays[ds+'_ids']];indices[ds]={a:i for i,a in enumerate(ids)}
            require(len(ids)==len(indices[ds])==info['assemblies'],'Feature IDs changed')
            require(digest(json.dumps(ids).encode())==info['assembly_id_sha256'],'Feature ordering changed')
            for arm,x in [(ARMS[0],arrays[ds+'_global']),(ARMS[1],arrays[ds+'_typed_scores'][:,:2822]),(ARMS[2],arrays[ds+'_typed_scores'])]:
                require(digest(np.asarray(x,dtype='<f8').tobytes())==info['matrix_sha256'][arm],'Feature matrix changed')
                matrices[ds,arm]=x
        models=0;predictions=0;worst=0.
        for name in sorted(n for n in manifest if n.endswith('/complete.json')):
            base=name.rsplit('/',1)[0];contract=json.loads(z.read(base+'/contract.json'));task=contract['task'];arm=contract['arm'];ds=task['dataset']
            with np.load(io.BytesIO(z.read(base+'/model.npz')),allow_pickle=False) as f:model={k:f[k].copy() for k in f.files}
            x=matrices[ds,arm][[indices[ds][a] for a in task['test_ids']]];replayed=predict(model,x)
            saved=json.loads(z.read(base+'/predictions.json'))['predictions']
            require([r['assembly_id'] for r in saved]==task['test_ids'],'Prediction ID order changed')
            err=float(np.max(np.abs(replayed-np.array([r['logit'] for r in saved]))));worst=max(worst,err)
            require(err<1e-8,'Prediction replay mismatch')
            require(np.allclose(probabilities(replayed),[r['probability'] for r in saved],rtol=0,atol=1e-9),'Probability mismatch')
            models+=1;predictions+=len(saved)
        require(models==json.loads(z.read('summary.json'))['final_models'],'Model coverage differs')
    return dict(models=models,predictions=predictions,max_logit_error=worst)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('inspection_zip');a=p.parse_args();emit('INSPECTION_REPLAY_OK',**replay(a.inspection_zip))
