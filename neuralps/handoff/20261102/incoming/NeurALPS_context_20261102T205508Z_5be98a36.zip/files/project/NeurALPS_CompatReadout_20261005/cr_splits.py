"""Verify donor separation and the complete measured-edit panels."""
from collections import Counter
from cr_common import require

def alternatives(aid,parts):
    rows=[]
    for other,pp in sorted(parts.items()):
        changed=[j for j in range(3) if pp[j]!=parts[aid][j]]
        if len(changed)==1:
            j=changed[0];rows.append(dict(candidate_id=other,fragment_position=j+1,old_fragment=parts[aid][j],new_fragment=pp[j]))
    require(len(rows)==18 and [sum(r['fragment_position']==j for r in rows) for j in (1,2,3)]==[5,8,5],'Measured BODE1 panel changed')
    return rows

def validate(tasks,records,meta):
    require(len(tasks)==92 and len({t['task_id'] for t in tasks})==92,'Wrong task coverage')
    seen=Counter();pairs=Counter();b2seen=Counter();parts={a:r['parts'] for a,r in meta['bode1'].items()}
    for t in tasks:
        rr=records[t['dataset']];test=set(t['test_ids']);fit=set(t['fit_ids']);val=set(t['validation_ids']);train=set(t['refit_ids'])
        require(all(len(t[k])==len(set(t[k])) for k in ('test_ids','fit_ids','validation_ids','refit_ids','query_ids')),'Repeated split ID')
        require(not fit&val and fit|val==train and not train&test and train|test==set(rr),'Fitting/test split overlap or missing records')
        require(set(t['query_ids'])<=test,'Queries are not held out')
        require({rr[a]['label'] for a in fit}=={0,1} and {rr[a]['label'] for a in val}=={0,1},'Inner split has a single class')
        if t['benchmark']=='bode1_donor':
            donor=t['held_out_donor'];require(test=={a for a,p in parts.items() if donor in p},'Outer BODE1 donor leaked')
            inner=t['inner_held_out_donor'];require(all(inner not in parts[a] for a in fit) and all(inner in parts[a] for a in val),'Inner BODE1 donor leaked')
            seen.update(test)
        elif t['benchmark']=='bode1_edits':
            left,right=t['held_out_parts'];require(test=={a for a,p in parts.items() if p[0]==left or p[2]==right},'Pair-panel outer purge changed')
            inner=t['inner_held_out_donor'];require(all(inner not in parts[a] for a in fit) and all(inner in parts[a] for a in val),'Inner pair-panel donor leaked')
            for aid in t['query_ids']:
                require(parts[aid][0]==left and parts[aid][2]==right,'Wrong pair query')
                require({r['candidate_id'] for r in alternatives(aid,parts)}<=test,'An edit candidate enters training')
            pairs.update(t['query_ids'])
        elif t['benchmark']=='bode2_donor':
            mm=meta['bode2'];donor=t['held_out_donor']
            require(test=={a for a,m in mm.items() if m['donor']==donor} and len(test)==3,'BODE2 donor triple leaked')
            require({mm[a]['position'] for a in test}=={'Starter','Elongation','Termination'},'Incomplete donor triple')
            require({mm[a]['donor'] for a in fit if mm[a]['donor']}.isdisjoint({mm[a]['donor'] for a in val}),'Inner BODE2 donor leaked')
            require(len(val)==21 and {mm[a]['donor'] for a in val}==set(t['inner_held_out_donors']),'Wrong BODE2 inner donor coverage')
            require(all(mm[a]['donor'] for a in val) and all(a in fit for a,m in mm.items() if not m['donor']),'Native control must stay in inner fitting')
            b2seen.update(test)
        else:raise RuntimeError('Unknown benchmark')
    require(set(seen)==set(parts) and set(seen.values())=={3},'BODE1 donor coverage changed')
    require(set(pairs)==set(parts) and set(pairs.values())=={1},'BODE1 edit query assignment changed')
    require(set(b2seen)=={a for a,m in meta['bode2'].items() if m['donor']} and set(b2seen.values())=={1},'BODE2 coverage changed')
    return True

def select_tasks(tasks,profile):
    require(profile in ('pilot','benchmark'),'Unknown profile')
    if profile=='benchmark':return tasks
    return [next(t for t in tasks if t['benchmark']==b) for b in ('bode1_donor','bode2_donor','bode1_edits')]
