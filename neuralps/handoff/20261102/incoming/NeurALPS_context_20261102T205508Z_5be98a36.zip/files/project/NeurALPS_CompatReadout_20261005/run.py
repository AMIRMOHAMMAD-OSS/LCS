#!/usr/bin/env python3
"""Frozen features, inner selection, sealed predictions, then held-out evaluation."""
import argparse,fcntl,json,platform,signal,sys,time,traceback,zipfile
from pathlib import Path
import numpy as np
import scipy
from cr_common import PACKAGE,ARMS,VERSION,require,load,dump,sha,canonical,Reader,preflight,metadata,emit
from cr_features import Features,save_assembly_features
from cr_solver import select,fit,predict,save_model,load_model
from cr_metrics import probabilities

STOP=False
OWNED_OUTPUT=None
def stopping(signum,frame):
    global STOP
    STOP=True

def model_contract(request,task,arm,features):
    return dict(request_sha256=canonical(request),task=task,arm=arm,features=features.manifest,
        encoder_updates=0,outer_labels_used_for_selection=False)

def verify_complete(directory,contract,features,task,arm):
    c=load(directory/'complete.json');require(c['contract_sha256']==canonical(contract),'Model resume contract changed')
    require(set(c['files_sha256'])=={'contract.json','model.npz','trials.json','predictions.json'},'Incomplete model seal')
    for name,h in c['files_sha256'].items():require(sha(directory/name)==h,'Completed fit changed: '+str(directory/name))
    require(load(directory/'contract.json')==contract,'Saved model contract changed')
    predictions=load(directory/'predictions.json')['predictions']
    require([r['assembly_id'] for r in predictions]==task['test_ids'],'Saved prediction coverage changed')
    z=predict(load_model(directory/'model.npz'),features.matrix(arm,task['test_ids']))
    require(np.allclose(z,[r['logit'] for r in predictions],rtol=0,atol=1e-10),'Reloaded model predictions differ')
    require(np.allclose(probabilities(z),[r['probability'] for r in predictions],rtol=0,atol=1e-12),'Saved probabilities differ')
    return c

def fit_one(directory,request,task,arm,features,training_labels):
    """training_labels deliberately excludes every outer-test assembly."""
    require(set(training_labels)==set(task['refit_ids']) and not set(training_labels)&set(task['test_ids']),'Outer labels passed to fitting')
    contract=model_contract(request,task,arm,features)
    if (directory/'complete.json').exists():return verify_complete(directory,contract,features,task,arm),True
    directory.mkdir(parents=True,exist_ok=True);start=time.monotonic();dump(directory/'contract.json',contract)
    labels=lambda ids:np.array([training_labels[a] for a in ids],dtype=float)
    x=lambda ids:features.matrix(arm,ids)
    l2,trials=select(x(task['fit_ids']),labels(task['fit_ids']),x(task['validation_ids']),labels(task['validation_ids']))
    dump(directory/'trials.json',dict(trials=trials,selected_l2=l2,selection='inner_validation_bce_only'))
    model,diagnostics=fit(x(task['refit_ids']),labels(task['refit_ids']),l2);z=predict(model,x(task['test_ids']))
    save_model(directory/'model.npz',model);reloaded=load_model(directory/'model.npz');zz=predict(reloaded,x(task['test_ids']))
    require(np.array_equal(z,zz),'Model save/reload is not exact')
    predictions=[dict(assembly_id=a,logit=float(v),probability=float(p)) for a,v,p in zip(task['test_ids'],z,probabilities(z))]
    dump(directory/'predictions.json',dict(predictions=predictions,outer_labels_included=False))
    complete=dict(status='MODEL_COMPLETE',contract_sha256=canonical(contract),selected_l2=l2,solver=diagnostics,
        checkpoint_reload_exact=True,seconds=time.monotonic()-start,
        files_sha256={n:sha(directory/n) for n in ['contract.json','trials.json','model.npz','predictions.json']})
    dump(directory/'complete.json',complete);verify_complete(directory,contract,features,task,arm)
    return complete,False

def package_inspection(out):
    names=['config.json','PROTOCOL.json','INPUTS.json','splits.json','metadata.json','feature_manifest.json','assembly_features.npz','runtime.json',
        'summary.json','progress.json','fold_metrics.csv','held_out_predictions.csv','local_compatibility_evidence.csv','measured_alternative_scores.csv']
    if (out/'inactive_query_edit_metrics.csv').exists():names.append('inactive_query_edit_metrics.csv')
    names+=sorted(str(p.relative_to(out)) for p in (out/'fits').rglob('*') if p.is_file() and p.suffix in ('.json','.npz'))
    manifest={n:sha(out/n) for n in names};dump(out/'artifact_manifest.json',manifest);names.append('artifact_manifest.json')
    tmp=out/'compat_readout_inspection.zip.tmp';final=out/'compat_readout_inspection.zip'
    with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n in names:z.write(out/n,n)
    with zipfile.ZipFile(tmp) as z:
        require(z.testzip() is None,'Inspection ZIP failed verification')
        import hashlib
        require(all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in manifest.items()),'Inspection ZIP hash mismatch')
    tmp.replace(final);dump(out/'COMPAT_READOUT_COMPLETE',dict(status='COMPAT_READOUT_COMPLETE',inspection_sha256=sha(final),manifest_sha256=sha(out/'artifact_manifest.json')))
    return final

def execute(root,out,request_path,resume=False):
    global OWNED_OUTPUT
    OWNED_OUTPUT=None
    require(out.parent==root and out.name.startswith('e7_compat_readout_'),'Output must be a dedicated e7_compat_readout directory inside the project root')
    request=load(request_path);rr,tasks,checked=preflight(root,request['profile']);require(checked==request,'Submitted inputs changed before execution')
    require(not (out/'COMPAT_READOUT_COMPLETE').exists(),'Run is already complete')
    out.mkdir(parents=True,exist_ok=True)
    with (out/'.run.lock').open('a') as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        runtime=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,machine=platform.machine(),solver='scipy.optimize L-BFGS-B')
        if (out/'config.json').exists():
            require(resume and load(out/'config.json')==request,'Output exists or resume request changed')
            require(load(out/'runtime.json')==runtime,'Resume numerical runtime changed')
        else:
            require(not resume or not list((out/'fits').glob('*')),'Partial output lacks its original config')
            dump(out/'config.json',request);dump(out/'runtime.json',runtime)
        OWNED_OUTPUT=out
        for stale in ('fatal_error.json','pause.json'):(out/stale).unlink(missing_ok=True)
        for source,target in [('PROTOCOL.json','PROTOCOL.json'),('INPUTS.json','INPUTS.json'),('data/splits.json','splits.json'),('data/metadata.json','metadata.json')]:dump(out/target,load(PACKAGE/source))
        pins=load(PACKAGE/'INPUTS.json');features={}
        for dataset,spec in pins['sources'].items():
            reader=Reader(root/spec['run']);features[dataset]=Features(rr[dataset],reader,spec);reader.close()
        dump(out/'feature_manifest.json',{ds:f.manifest for ds,f in features.items()});save_assembly_features(out/'assembly_features.npz',features)
        emit('FROZEN_FEATURES_READY',datasets={ds:f.manifest['assemblies'] for ds,f in features.items()},encoder_updated=False)
        count=0
        for task in tasks:
            ds=task['dataset'];training_labels={a:rr[ds][a]['label'] for a in task['refit_ids']}
            for arm in ARMS:
                if STOP:
                    dump(out/'pause.json',dict(status='PAUSED',complete_models=count,planned_models=len(tasks)*len(ARMS),resume='bash '+str(PACKAGE/'submit.sh')+' resume '+str(out)));emit('COMPAT_READOUT_PAUSED',complete_models=count);return
                result,reused=fit_one(out/'fits'/task['task_id']/arm,request,task,arm,features[ds],training_labels);count+=1
                progress=dict(status='FITTING',complete_models=count,planned_models=len(tasks)*len(ARMS),task=task['task_id'],arm=arm,reused=reused)
                dump(out/'progress.json',progress);emit('READOUT_COMPLETE',**{k:v for k,v in progress.items() if k!='status'},selected_l2=result['selected_l2'])
        dump(out/'progress.json',dict(status='PREDICTIONS_SEALED',complete_models=count,planned_models=count))
        from cr_evaluate import evaluate
        summary=evaluate(out,tasks,rr,metadata(),features,request['profile'])
        dump(out/'progress.json',dict(status='COMPAT_READOUT_COMPLETE',complete_models=count,planned_models=count))
        archive=package_inspection(out);emit('COMPAT_READOUT_COMPLETE',models=count,inspection=str(archive),bode2_role='development_cross_validation')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True,type=Path);p.add_argument('--out',required=True,type=Path);p.add_argument('--request',required=True,type=Path);p.add_argument('--resume',action='store_true');a=p.parse_args()
    signal.signal(signal.SIGUSR1,stopping);signal.signal(signal.SIGTERM,stopping)
    try:execute(a.root.resolve(),a.out.resolve(),a.request.resolve(),a.resume)
    except Exception:
        if OWNED_OUTPUT==a.out.resolve():dump(a.out/'fatal_error.json',dict(status='FAILED',traceback=traceback.format_exc()))
        raise

if __name__=='__main__':main()
