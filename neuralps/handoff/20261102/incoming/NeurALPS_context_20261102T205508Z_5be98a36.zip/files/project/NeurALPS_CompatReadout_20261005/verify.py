#!/usr/bin/env python3
from cr_common import verify,emit
if __name__=='__main__':emit('COMPAT_READOUT_BUNDLE_OK',sha256=verify())
