# Frozen-encoder compatibility readout

This is the next controlled development experiment for NeurALPS. It tests whether separating domain, covalent-boundary and protein-break evidence, then adding continuous native-context scores, improves activity prediction and measured-fragment edit ranking.

The original SSL encoder selected at step **26000** is fixed. The experiment reads its already saved representations. It does not continue pretraining, run another GPU fine-tune, or overwrite an earlier experiment. No HTML report is generated.

## Run on Jean Zay

Place `NeurALPS_CompatReadout_20261005.zip` in:

```
/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2
```

Then run:

```bash
cd /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2
unzip -n NeurALPS_CompatReadout_20261005.zip
bash NeurALPS_CompatReadout_20261005/submit.sh benchmark
```

Check the result:

```bash
bash /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/NeurALPS_CompatReadout_20261005/status.sh
```

The launcher requests **one CPU**, account `nef@cpu`, partition `cpu_p1`, QoS `qos_cpu-t3`, with a two-hour limit. These settings come from the project's earlier CPU preparation jobs. The existing `pytorch-gpu/py3/2.8.0` environment supplies NumPy/SciPy; the code does not import PyTorch or use CUDA. Actual queue waiting time is unknown. The two-hour limit is a scheduling limit, not a runtime prediction.

A full run fits 276 final heads across 92 tasks. Each head has five inner regularization trials and one final refit: at most 1656 optimizer fits, plus convergence-only retries if needed. These are small convex fits on cached arrays.

Optional actions:

```bash
# Validate package, cached sources and all folds without submitting.
bash NeurALPS_CompatReadout_20261005/submit.sh preflight

# Nine-head smoke run: one fold from each of the three evaluations.
bash NeurALPS_CompatReadout_20261005/submit.sh pilot

# After a paused/failed job has stopped, reuse completed models.
# Replace JOBID with the job that created this output directory.
bash NeurALPS_CompatReadout_20261005/submit.sh resume \
  /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/e7_compat_readout_benchmark_JOBID
```

Running the same submitted comparison again is blocked; use status or resume. An active readout job also blocks a duplicate submission. Inputs, package checksums and numerical runtime must match when resuming. Completed models are checked and reused; an interrupted individual optimizer fit restarts deterministically. Outputs use the original directory during resume, even though SLURM assigns a new job ID.

## Transfer the bundle

If the ZIP was downloaded on Windows, run this in **Windows PowerShell** to put it on the Mac:

```powershell
scp -o PreferredAuthentications=password -o PubkeyAuthentication=no `
  "$env:USERPROFILE\Downloads\NeurALPS_CompatReadout_20261005.zip" `
  amir@100.72.70.1:/Users/amir/
```

Then in **Mac Terminal**:

```bash
scp -J apandi@gate.lcqb.hosted.lip6.fr \
  /Users/amir/NeurALPS_CompatReadout_20261005.zip \
  unh87ms@jean-zay.idris.fr:/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/
```

If downloading directly on the Mac instead, replace the local ZIP path in that command with `/Users/amir/Downloads/NeurALPS_CompatReadout_20261005.zip`.

## Fixed comparison

| Arm | Inputs | Features |
|---|---|---:|
| `global_context` | Existing domain mean, all-boundary mean/max and two counts | 770 |
| `typed_context` | Separate domain, covalent-boundary and protein-break pools; counts/presence | 2822 |
| `typed_context_scores` | Identical typed pools plus two continuous native-context features for each kind | 2828 |

For a domain the local vector is its frozen contextual state `h`. For either boundary kind it is `[left, h, right, left*right, abs(left-right)]`. Local vectors are averaged separately within each kind. Each kind also supplies `log1p(count)` and a presence indicator.

The two extra context features are **native agreement** and **agreement above the natural reference-panel mean**. They are averaged within each kind. Protein breaks use their joint terminal query once per physical break. Reference percentiles are exported as context metadata, but do not enter the model: many were saturated at 100 in the previous result. Domain labels, donor IDs, construct IDs and assay outcomes do not enter feature construction.

All arms use regularized logistic regression with an unpenalized intercept. The objective is:

```
mean binary cross-entropy + (lambda / 2) * sum(weight**2)
```

The fixed lambda grid is `[0.01, 0.1, 1, 10, 100]`. Inner-validation BCE selects lambda; ties within `1e-12` prefer stronger regularization. The selected model is refitted on all outer-training rows. Standardization is fitted afresh only on the corresponding training rows. Constant training columns are disabled. All fits have deterministic zero-weight initialization and a training-prevalence intercept; there are no random head seeds to select.

The **primary comparison** is `typed_context_scores` minus `typed_context`: does continuous compatibility evidence help beyond the same contextual features? The secondary comparison is `typed_context` minus `global_context`. Neither the feature design, threshold nor lambda grid is changed using outer-fold results. Threshold 0.5 is fixed; scores are not claimed to be calibrated probabilities.

## Evaluation and interpretation

**BODE1 donor generalization:** the original 21 donor-purged outer folds and their original full-budget inner splits. Each construct occurs in three outer folds, so the main result is macro fold performance and paired per-fold differences. Repeated predictions must not be treated as independent samples.

**BODE2 development:** 35 outer folds, each holding out one donor's complete Starter/Elongation/Termination triplet. Seven other complete donor triplets form the fixed inner validation set. The native control stays in training and is excluded from the 105-assembly out-of-fold evaluation. Models for this evaluation train on BODE2 training folds only; BODE1 and BODE2 assays are not pooled. The output includes pooled out-of-fold and position-specific metrics. The donor bootstrap resamples the saved predictions, not the training process; its intervals are descriptive and conditional on those predictions.

BODE2 previously informed this design. These new numbers are **development cross-validation**, not another untouched external test. Source-donor groups are not claimed to be sequence-homology clusters, and a new NRPS-family generalization claim would need a separate evaluation.

**BODE1 measured edits:** the original 36 first/third-fragment pair holdouts. Every query and all 18 measured one-fragment alternatives are excluded from fitting together. Candidates are generated and ranked without their labels; labels are joined only for evaluation. Inactive queries are evaluated with tie-aware hit@1, hit@3, and a positive predicted-improvement gate. A training-only fragment-frequency baseline is included. This is retrospective ranking of measured alternatives; a replacement can change product chemistry. It does not prove that a particular domain caused inactivity.

The local compatibility table contains the primary arm's held-out **signed contributions to the assembly logit**. Embedding and context-score contributions are shown separately. The sum of local contributions plus the assembly-context term reproduces the predicted logit. The context term contains the intercept, count/presence features, and normalization terms for absent kinds. A type absent from fitting is flagged and receives no learned local effect.

A negative contribution is unfavorable model evidence relative to training feature means. It is not a calibrated probability of incompatibility or an experimentally identified fault. Boundary evidence also incorporates its adjacent domains. Fold-specific contributions come from different fitted heads and should not be compared as a common probability scale.

This bundle evaluates the readout on the current measured panels. Applying it to a new researcher-supplied sequence will additionally require producing that sequence's frozen features/maps and an explicitly chosen final deployment head after this comparison is reviewed.

## Sources and output

Frozen inputs are pinned in `INPUTS.json`:

- Full BODE1/BODE2 records from `e0_training_prep_461027/training_data.sqlite3`.
- BODE1 SSL26 maps and representations from `e2_bode30_benchmark_541171`.
- BODE2 SSL26 maps and representations from `e6_compatibility_bode2_588750/native_context`.
- Original BODE1 donor and measured-pair splits, copied into `data/splits.json`; BODE2 donor triplets are frozen there too.

The BODE2 representation file was omitted from the inspection ZIP but is expected in the existing cluster output. Preflight checks its exact previously sealed SHA256. A missing or changed file stops the job with its path; the script does not silently regenerate different inputs.

New output is `e7_compat_readout_benchmark_JOBID/`:

- `summary.json`: matched comparisons, separate dataset metrics and edit-ranking results.
- `fold_metrics.csv` and `held_out_predictions.csv`: all evaluation rows.
- `local_compatibility_evidence.csv`: domain/boundary contributions for held-out assemblies; edit folds export their nine designated queries.
- `measured_alternative_scores.csv` and `inactive_query_edit_metrics.csv`: measured alternatives and retrospective edit evaluation.
- `fits/`: regularization trials, model weights/scalers, sealed predictions and checksums for every head.
- `PROTOCOL.json`, `INPUTS.json`, `splits.json`, `metadata.json`, `feature_manifest.json`, `runtime.json`: reproducibility records.
- `assembly_features.npz`: exact aggregate feature matrices used by the readouts, allowing later independent prediction replay.
- `compat_readout_inspection.zip`: CSV/JSON outputs, aggregate inputs and **all small fitted linear models**, with an artifact hash manifest. `python3 replay.py PATH_TO_ZIP` verifies hashes and recomputes every held-out prediction without the cluster's original files.

After completion, download the inspection ZIP using the output path printed by `status.sh`. For a new job `JOBID`, on the Mac:

```bash
scp -J apandi@gate.lcqb.hosted.lip6.fr \
  unh87ms@jean-zay.idris.fr:/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/e7_compat_readout_benchmark_JOBID/compat_readout_inspection.zip \
  /Users/amir/
```

Then on Windows PowerShell:

```powershell
scp -o PreferredAuthentications=password -o PubkeyAuthentication=no `
  amir@100.72.70.1:/Users/amir/compat_readout_inspection.zip `
  "$env:USERPROFILE\Downloads\compat_readout_inspection.zip"
```

## Validation supplied with this bundle

`selftest.py` checks donor separation, candidate coverage, numerical gradients, training-only scaling, missing-type handling, label-blind features, model reload/resume, tamper rejection, tie-aware metrics and CPU submission flags. It runs automatically before the job.

`LOCAL_VALIDATION.json` records local tests against all 324 real BODE1 representations, six real-data BODE1 final fits and independent scikit-learn checks. The BODE2 representation file is unavailable locally: its local pipeline tests use explicitly synthetic states with the real route/map schema. Those fixtures are never reported as biological results. The cluster checks the actual BODE2 file before fitting. No Jean Zay job was submitted during bundle preparation.

The central bachelor-project result is the reproducible answer to the matched comparison, including any failures. Improved accuracy remains an empirical question.
