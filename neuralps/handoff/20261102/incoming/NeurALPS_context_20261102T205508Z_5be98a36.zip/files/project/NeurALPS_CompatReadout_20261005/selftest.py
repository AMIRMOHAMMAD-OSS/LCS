#!/usr/bin/env python3
"""Portable integrity/numerical tests, with explicitly synthetic representations."""
import copy,io,json,tempfile,unittest
from pathlib import Path
import numpy as np
from cr_common import ARMS,Reader,dump,load,metadata,splits,protocol,sha
from cr_features import Features,local_contributions
from cr_solver import fit,predict,objective,standardize_fit,load_model
from cr_splits import validate,alternatives
from cr_metrics import binary_metrics
from cr_evaluate import tie_hit,edit_panels,fragment_baseline
from run import fit_one
from launch import sbatch_command

def synthetic_source(directory,records=None,maps=None,seed=91):
    """Make a schema-faithful fixture. These arrays are never scientific results."""
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True);rng=np.random.default_rng(seed)
    if records is None:
        records={}
        for i in range(12):
            aid='SYNTHETIC_'+str(i)
            kinds=[0,1,0,2 if i>=8 else 1,0]
            route=[dict(kind=k,source_domain_uid='fake_domain_'+str(j),occurrence_id='fake_'+str(j),boundary_id='edge_'+str(j)) for j,k in enumerate(kinds)]
            records[aid]=dict(route=route,label=i%2)
    ids=sorted(records);states=[];offset=[0];pools=[];queries=[]
    for aid in ids:
        route=records[aid]['route'];h=rng.normal(scale=.2,size=(len(route),256)).astype('float32');states.append(h);offset.append(offset[-1]+len(h))
        kinds=np.array([r['kind'] for r in route]);d=h[kinds==0];b=h[kinds!=0]
        pools.append(np.r_[d.mean(0),b.mean(0),b.max(0),np.log1p([len(d),len(b)])])
        for j,k in enumerate(kinds):
            native=float(rng.uniform(-.5,1));refs=[-.2,.3]
            queries.append(dict(assembly_id=aid,object_index=j,kind=int(k),query_id=aid+'|'+str(j),
                mode='joint_terminal_recovery' if k==2 else 'object_recovery',status='SCORED',label='synthetic_domain_type',
                reference_size=2,reference_scores=refs,native_score=native,relative_score=native-np.mean(refs),
                reference_percentile=(sum(x<native for x in refs)+.5*sum(x==native for x in refs))/2,slots=[]))
    if maps is None:maps=dict(queries=queries)
    dump(directory/'maps.json',maps)
    np.savez_compressed(directory/'representations.npz',assembly_ids=np.array(ids),object_offsets=np.array(offset),
        object_states=np.concatenate(states),assembly_readout=np.asarray(pools,dtype=np.float32))
    spec=dict(maps='maps.json',representations='representations.npz')
    return records,Features(records,Reader(directory),spec)

class Contracts(unittest.TestCase):
    def test_all_donor_splits_and_edit_candidates(self):
        mm=metadata();rr={ds:{a:{'label':int(sha_bytes(a),16)%2} for a in entries} for ds,entries in mm.items()}
        self.assertTrue(validate(splits(),rr,mm));parts={a:m['parts'] for a,m in mm['bode1'].items()}
        for a in parts:self.assertEqual(len(alternatives(a,parts)),18)
        broken=copy.deepcopy(splits());t=next(t for t in broken if t['benchmark']=='bode2_donor')
        # Exchange only one construct between inner fit and validation: donor leakage.
        x=t['fit_ids'][1];y=t['validation_ids'][0];t['fit_ids'].remove(x);t['fit_ids'].append(y);t['validation_ids'].remove(y);t['validation_ids'].append(x)
        with self.assertRaises(RuntimeError):validate(broken,rr,mm)
    def test_metrics_and_tie_ranking(self):
        m=binary_metrics([0,1,0,1],[0,0,1,1]);self.assertAlmostEqual(m['auroc'],.5);self.assertAlmostEqual(m['auprc_average_precision'],.5)
        panel=[dict(candidate_id=str(i),candidate_activity_score=.5) for i in range(4)];labels={str(i):int(i==0) for i in range(4)}
        self.assertAlmostEqual(tie_hit(panel,labels,1),.25);self.assertAlmostEqual(tie_hit(panel,labels,3),.75)
        self.assertIsNone(binary_metrics([1,1],[0,1])['auroc'])
    def test_cpu_launch_contract(self):
        cmd,_=sbatch_command(Path('/project'),Path('/request.json'),'benchmark')
        self.assertIn('--account=nef@cpu',cmd);self.assertIn('--partition=cpu_p1',cmd)
        self.assertFalse(any('--gres' in v or '--constraint=a100' in v for v in cmd))
        cmd2,_=sbatch_command(Path('/project'),Path('/request.json'),'benchmark',Path('/project/paused'))
        self.assertEqual(cmd2[-1],'/project/paused')

def sha_bytes(s):
    import hashlib
    return hashlib.sha256(s.encode()).hexdigest()

class Numerics(unittest.TestCase):
    def test_gradient_and_convex_stationarity(self):
        rng=np.random.default_rng(18);x=rng.normal(size=(19,7));y=np.arange(19)%2;theta=rng.normal(size=8);l2=.3
        value,g=objective(theta,x,y,l2);eps=1e-6
        numerical=[]
        for j in range(len(theta)):
            d=np.zeros_like(theta);d[j]=eps
            numerical.append((objective(theta+d,x,y,l2)[0]-objective(theta-d,x,y,l2)[0])/(2*eps))
        np.testing.assert_allclose(g,numerical,atol=1e-8,rtol=1e-6)
        model,diag=fit(x,y,l2);self.assertLess(diag['attempts'][-1]['gradient_inf'],protocol()['solver']['acceptable_gradient_inf'])
        self.assertEqual(model['weight'].shape,(7,))
    def test_training_only_scaler_and_unseen_column(self):
        x=np.array([[1.,0.],[2.,0.],[3.,0.],[4.,0.]]);y=np.array([0,0,1,1]);m,_=fit(x,y,.1)
        np.testing.assert_array_equal(m['mean'],[2.5,0.]);self.assertEqual(m['weight'][1],0.)
        np.testing.assert_array_equal(predict(m,np.array([[2.,0.]])),predict(m,np.array([[2.,1e8]])))

class Pipeline(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='nrps_cr_selftest_');self.p=Path(self.tmp.name)
        self.records,self.features=synthetic_source(self.p/'source');ids=self.features.ids
        # Explicitly fit with no protein breaks, then score two unseen-break inputs.
        train=[a for a in ids if int(a.split('_')[-1])<8];test=sorted(set(ids)-set(train))
        self.task=dict(task_id='synthetic',dataset='synthetic',benchmark='synthetic',fit_ids=train[:4],validation_ids=train[4:],refit_ids=train,test_ids=test,query_ids=test)
        self.labels={a:self.records[a]['label'] for a in train};self.request={'synthetic':True}
    def tearDown(self):self.tmp.cleanup()
    def test_label_blind_features_and_missing_score_rejection(self):
        changed=copy.deepcopy(self.records)
        for r in changed.values():r['label']='MUST_NOT_BE_READ'
        f=Features(changed,Reader(self.p/'source'),dict(maps='maps.json',representations='representations.npz'))
        for arm in ARMS:np.testing.assert_array_equal(f.X[arm],self.features.X[arm])
        maps=load(self.p/'source/maps.json');maps['queries'].pop();dump(self.p/'source/maps.json',maps)
        with self.assertRaises(RuntimeError):Features(changed,Reader(self.p/'source'),dict(maps='maps.json',representations='representations.npz'))
    def test_reload_resume_local_decomposition_and_tamper_guard(self):
        arm=ARMS[2];d=self.p/'fit'
        first,reused=fit_one(d,self.request,self.task,arm,self.features,self.labels);self.assertFalse(reused)
        saved={n:sha(d/n) for n in ['model.npz','predictions.json','complete.json']}
        second,reused=fit_one(d,self.request,self.task,arm,self.features,self.labels);self.assertTrue(reused);self.assertEqual(first,second)
        self.assertEqual(saved,{n:sha(d/n) for n in saved})
        model=load_model(d/'model.npz')
        for aid in self.task['test_ids']:
            rows=local_contributions(self.features,aid,model,'synthetic')
            self.assertAlmostEqual(sum(r['total_logit_contribution'] for r in rows)+rows[0]['assembly_context_logit_term'],float(predict(model,self.features.matrix(arm,[aid]))[0]),places=10)
            breaks=[r for r in rows if r['object_kind']=='protein_break'];self.assertTrue(breaks)
            self.assertTrue(all(r['type_absent_from_training'] and r['total_logit_contribution']==0 for r in breaks))
        d2=self.p/'restart';d2.mkdir();dump(d2/'trials.json',{'interrupted':True})
        fit_one(d2,self.request,self.task,arm,self.features,self.labels)
        self.assertEqual(load(d/'predictions.json'),load(d2/'predictions.json'))
        (d/'predictions.json').write_text('{}')
        with self.assertRaises(RuntimeError):fit_one(d,self.request,self.task,arm,self.features,self.labels)
    def test_outer_labels_cannot_enter_fit(self):
        bad=dict(self.labels);bad[self.task['test_ids'][0]]=1
        with self.assertRaises(RuntimeError):fit_one(self.p/'bad',self.request,self.task,ARMS[0],self.features,bad)

if __name__=='__main__':unittest.main(verbosity=2)
