#!/usr/bin/env python3
"""Collect a small, read-only NeurALPS handoff; Python 3.9+, standard library only.

Reads existing records and source. Writes one NEW ZIP under --output-dir.
Does not import project code, load checkpoints, train, infer, submit jobs, or
change any source/database. Large assets are inventoried rather than copied.
"""
import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time
from datetime import datetime, timezone
from uuid import uuid4
from zipfile import ZipFile, ZIP_DEFLATED

DEFAULT_BASE = Path('/lustre/fswork/projects/rech/nef/unh87ms')
TEXT_SUFFIXES = {'.json', '.jsonl', '.csv', '.tsv', '.txt', '.md', '.yaml', '.yml', '.toml'}
CODE_SUFFIXES = {'.py', '.sh', '.ipynb', '.html', '.js', '.css', '.toml', '.md', '.txt', '.yaml', '.yml'}
RUNS = [
    'e0_training_prep_461027', 'e0_cache_final_491894',
    'e1_ssl_targets_497189', 'e1_ssl_continue30_v1_530757',
    'e2_bode_benchmark_529464', 'e2_bode30_benchmark_541171',
    'e3_bode_diagnostics_benchmark_543115', 'e4_readout_benchmark_548206',
    'e5_ensemble_benchmark_578230', 'e6_compatibility_bode2_588750',
    'e7_compat_readout_benchmark_646197', 'e8_reference_scale_652486',
    'e10_tdomain_embed_696333', 'e11_tdomain_transfer_699466',
    'e12_context_audit_749149', 'e14_context_benefit_780987',
]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, default=DEFAULT_BASE/'NeurALPSv2')
    ap.add_argument('--explorer', type=Path, default=DEFAULT_BASE/'NeurALPS_Explorer_20261010')
    ap.add_argument('--repo', type=Path, help='Current NeurALPS-v2 checkout if different from Explorer')
    ap.add_argument('--output-dir', type=Path, default=Path.cwd())
    ap.add_argument('--max-file-mib', type=int, default=16)
    ap.add_argument('--max-total-mib', type=int, default=64)
    ap.add_argument('--skip-database', action='store_true')
    args = ap.parse_args()
    if args.max_file_mib < 1 or args.max_total_mib < 1:
        ap.error('Size limits must be positive')
    root, explorer = args.root.resolve(), args.explorer.resolve()
    repo = args.repo.resolve() if args.repo else explorer
    if not root.is_dir():
        ap.error('Project root does not exist: '+str(root))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    destination = args.output_dir.resolve()/('NeurALPS_context_'+stamp+'_'+uuid4().hex[:8]+'.zip')
    max_file, max_total = args.max_file_mib*2**20, args.max_total_mib*2**20
    manifest = {'created_utc': stamp, 'root': str(root), 'explorer': str(explorer),
                'repo': str(repo), 'source_access': 'read_only', 'files': [],
                'missing': [], 'skipped': [], 'errors': [], 'generated': []}
    copied, used = set(), 0

    with ZipFile(destination, 'x', ZIP_DEFLATED, compresslevel=6) as archive:
        def emit(name, value):
            data = (json.dumps(value, indent=2, ensure_ascii=False)+'\n').encode()
            archive.writestr('inspection/'+name, data)
            manifest['generated'].append({'path': 'inspection/'+name, 'bytes': len(data),
                                          'sha256': hashlib.sha256(data).hexdigest()})

        def add(path, archive_name):
            nonlocal used
            path = Path(path)
            if archive_name in copied:
                return
            if path.is_symlink():
                manifest['skipped'].append({'path': str(path), 'reason': 'symlink'})
                return
            if not path.is_file():
                manifest['missing'].append(str(path))
                return
            try:
                before = path.stat()
                if before.st_size > max_file or used+before.st_size > max_total:
                    manifest['skipped'].append({'path': str(path), 'bytes': before.st_size,
                                                'reason': 'file_or_total_size_limit'})
                    return
                raw = path.read_bytes()
                after = path.stat()
                if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                    manifest['skipped'].append({'path': str(path), 'reason': 'changed_during_read'})
                    return
                original_hash = hashlib.sha256(raw).hexdigest()
                transform = None
                if path.suffix == '.ipynb':
                    nb = json.loads(raw)
                    for cell in nb.get('cells', []):
                        cell['metadata'] = {}
                        if cell.get('cell_type') == 'code':
                            cell['outputs'], cell['execution_count'] = [], None
                    nb['metadata'] = {}
                    raw = (json.dumps(nb, indent=1, ensure_ascii=False)+'\n').encode()
                    transform = 'Notebook outputs and metadata removed; cells preserved'
                archive.writestr('files/'+archive_name, raw)
                copied.add(archive_name)
                used += len(raw)
                manifest['files'].append({'source': str(path), 'archive_path': 'files/'+archive_name,
                    'source_bytes': before.st_size, 'bytes': len(raw), 'source_mtime_ns': before.st_mtime_ns,
                    'source_sha256': original_hash, 'stored_sha256': hashlib.sha256(raw).hexdigest(),
                    'transformation': transform})
            except (OSError, ValueError, UnicodeError) as exc:
                manifest['errors'].append({'path': str(path), 'error': str(exc)})

        def small_directory(directory, archive_prefix):
            if not directory.is_dir():
                manifest['missing'].append(str(directory))
                return
            first = {'summary.json', 'report.json', 'config.json', 'protocol.json',
                     'artifact_manifest.json', 'provenance.json', 'identity.json',
                     'metrics.json', 'input_fingerprints.json', 'RESULTS_MANIFEST.json'}
            for p in sorted(directory.iterdir(), key=lambda p: (p.name not in first, p.name)):
                if p.is_file() and not p.name.startswith('.') and (
                    p.suffix in TEXT_SUFFIXES or p.name.endswith(('.json.gz', '.jsonl.gz', '.tsv.gz', '.csv.gz'))
                ):
                    add(p, archive_prefix+'/'+p.name)

        # Discover newer work without assuming October's run names are current.
        # Metadata only: never recurse through caches, environments, checkpoints,
        # or per-fold fits. Modification times are navigation aids, not selection
        # evidence for a scientifically frozen checkpoint.
        def recent_inventory(base, max_depth=3, max_entries=8000, seconds=25):
            records, errors = [], []
            deadline = time.monotonic()+seconds
            excluded = {'envs', 'venv', '.venv', '__pycache__', 'node_modules',
                        'site-packages', 'checkpoints', 'fits', 'shards', 'vectors'}
            stack = [(base, 0, 0)]
            limited = False
            while stack:
                if len(records) >= max_entries or time.monotonic() > deadline:
                    limited = True
                    break
                directory, depth, _ = stack.pop()
                try:
                    with os.scandir(directory) as entries:
                        for entry in entries:
                            if len(records) >= max_entries or time.monotonic() > deadline:
                                limited = True
                                break
                            if entry.name.startswith('.'):
                                continue
                            p = Path(entry.path)
                            try:
                                st = entry.stat(follow_symlinks=False)
                                link = entry.is_symlink()
                                isdir = entry.is_dir(follow_symlinks=False)
                                rec = {'path': str(p.relative_to(base)),
                                       'directory': isdir, 'symlink': link,
                                       'bytes': st.st_size, 'mtime_ns': st.st_mtime_ns}
                                records.append(rec)
                                if isdir and depth < max_depth and entry.name not in excluded:
                                    stack.append((p, depth+1, st.st_mtime_ns))
                            except OSError as exc:
                                errors.append({'path': str(p), 'error': str(exc)})
                except OSError as exc:
                    errors.append({'path': str(directory), 'error': str(exc)})
                # Visit recently modified directories first if the bounds are hit.
                stack.sort(key=lambda item: item[2])
            return {'root': str(base), 'max_depth': max_depth,
                    'entry_limit': max_entries, 'seconds_limit': seconds,
                    'limit_reached': limited, 'errors': errors,
                    'entries': sorted(records, key=lambda r: (-r['mtime_ns'], r['path'])),
                    'note': 'Times locate candidates; manifests/configs establish actual versions.'}

        discovery = recent_inventory(root)
        emit('project_inventory.json', discovery)
        siblings = []
        for p in sorted(root.parent.iterdir()):
            if p.name.lower().startswith('neuralps'):
                try:
                    st = p.lstat()
                    siblings.append({'path': str(p), 'directory': p.is_dir(),
                                     'symlink': p.is_symlink(), 'bytes': st.st_size,
                                     'mtime_ns': st.st_mtime_ns})
                except OSError as exc:
                    manifest['errors'].append({'path': str(p), 'error': str(exc)})
        emit('related_project_locations.json', siblings)

        # Small recent configs/results/source, including previously unknown runs.
        # Limit this discovery allocation so known context results keep room.
        discovery_names = {'config.json', 'summary.json', 'report.json', 'metrics.json',
                           'manifest.json', 'artifact_manifest.json', 'protocol.json',
                           'provenance.json', 'identity.json', 'README.md', 'README.txt',
                           'RUNBOOK.md', 'CHANGES.md', 'input_fingerprints.json'}
        discovery_used, discovery_count = 0, 0
        for rec in discovery['entries']:
            if rec['directory'] or rec['symlink']:
                continue
            p = Path(rec['path'])
            if any(part in {'data', 'models', 'assets', 'cache', 'caches', 'embeddings',
                            'context_exports', 'envs'} for part in p.parts):
                continue
            eligible = p.name in discovery_names or p.suffix in {'.py', '.sh'}
            if not eligible:
                continue
            if rec['bytes'] > 2*2**20 or discovery_used+rec['bytes'] > 24*2**20 or discovery_count >= 120:
                manifest['skipped'].append({'path': str(root/p), 'reason': 'recent_discovery_copy_limit'})
                continue
            prior = used
            add(root/p, 'project/'+p.as_posix())
            discovery_used += used-prior
            discovery_count += int(used > prior)

        # Prioritize context results; historical supervised tables are already in LCS.
        priority = ['e14_context_benefit_780987', 'e12_context_audit_749149',
                    'e8_reference_scale_652486', 'e11_tdomain_transfer_699466']
        for run in priority+[r for r in RUNS if r not in priority]:
            directory = root/run
            small_directory(directory, 'project/'+run)
            for child in ['evaluation', 'natural', 'bode1', 'bode2', 'tdomain']:
                if (directory/child).is_dir():
                    small_directory(directory/child, 'project/'+run+'/'+child)
        for child in ['assay_packet/evaluation', 'assay_packet/assay_data', 'input_metadata']:
            small_directory(root/'e11_tdomain_transfer_699466'/child,
                            'project/e11_tdomain_transfer_699466/'+child)
        for rel in [
            'e8_reference_scale_latest.json', 'domain_vocabulary.json',
            'NeurALPS_Assembly_v1_20261002/domain_vocabulary.json',
            'e0_closeout_342641/summary.json', 'e0_terminal_review_457023/summary.json',
            'e0_terminal_review_457023/work/inputs.json',
            'e0_training_prep_461027/input_fingerprints.json',
            'e0_training_prep_461027/report.json', 'e0_training_prep_461027/bode1/donor_folds.json',
            'e10_tdomain_embed_696333/inputs/routes.jsonl.gz',
            'e10_tdomain_embed_696333/inputs/parents.fasta.gz',
        ]:
            add(root/rel, 'project/'+rel)
        for child in ['data', 'models/all494']:
            small_directory(explorer/child, 'explorer/'+child)
        for rel in ['models/all494/supervised_head.npz', 'data/training_features.npz']:
            add(explorer/rel, 'explorer/'+rel)
        for rel in ['BODE2_all_parts_20261013', 'BODE1_TDomain_all_parts_20261013/bode1',
                    'BODE1_TDomain_all_parts_20261013/tdomain']:
            small_directory(root.parent/'NeurALPS_release_exports'/rel, 'release_exports/'+rel)
        for rel in ['NeurALPS_natural_recovered_872295/UPLOAD_MANIFEST.json',
                    'NeurALPS_natural_recovered_872295/repertoire/manifest.json']:
            add(root.parent/'NeurALPS_release_exports'/rel, 'release_exports/'+rel)

        # Source checkout identity and bounded source export. Never query remote credentials.
        def git(*words):
            try:
                cp = subprocess.run(['git', '-C', str(repo), *words], capture_output=True, timeout=20)
                return {'returncode': cp.returncode, 'stdout': cp.stdout.decode('utf8', 'replace'),
                        'stderr': cp.stderr.decode('utf8', 'replace')}
            except (OSError, subprocess.TimeoutExpired) as exc:
                return {'error': str(exc)}
        emit('repository.json', {'path': str(repo), 'head': git('log', '-1', '--format=%H%n%cI%n%s'),
                                'status': git('status', '--short', '--untracked-files=no')})
        tracked = git('ls-files', '-z').get('stdout', '').split('\0')
        candidates = [Path(n) for n in tracked if n and not Path(n).is_absolute()
                      and '..' not in Path(n).parts and not any(x.startswith('.') for x in Path(n).parts)
                      and not any(x in {'data', 'assets', 'models', 'node_modules'} for x in Path(n).parts)
                      and Path(n).suffix in CODE_SUFFIXES]
        if not candidates and repo.is_dir():
            candidates = [p.relative_to(repo) for p in repo.iterdir() if p.is_file() and p.suffix in CODE_SUFFIXES]
            for sub in ['neuralps', 'scripts', 'tests']:
                if (repo/sub).is_dir():
                    for base, dirs, files in os.walk(repo/sub, followlinks=False):
                        dirs[:] = sorted(d for d in dirs if not d.startswith('.') and d != '__pycache__'
                                         and not (Path(base)/d).is_symlink())
                        if len(Path(base).relative_to(repo).parts) >= 4:
                            dirs[:] = []
                        candidates.extend((Path(base)/f).relative_to(repo) for f in files
                                          if not f.startswith('.') and Path(f).suffix in CODE_SUFFIXES)
                        if len(candidates) >= 500:
                            break
        for p in sorted(set(candidates))[:500]:
            add(repo/p, 'current_checkout/'+p.as_posix())
        add(repo/'NeurALPS.ipynb', 'current_checkout/NeurALPS.ipynb')
        if len(candidates) > 500:
            manifest['skipped'].append({'path': str(repo), 'reason': '500_source_file_limit'})

        # Small indexed queries only; no integrity scan or database copy.
        dbpath = root/'e0_training_prep_461027/training_data.sqlite3'
        if not args.skip_database and dbpath.is_file():
            db = None
            try:
                db = sqlite3.connect(dbpath.as_uri()+'?mode=ro', uri=True, timeout=2)
                db.execute('PRAGMA query_only=ON')
                db.execute('PRAGMA cache_size=-8192')
                deadline = time.monotonic()+20
                db.set_progress_handler(lambda: int(time.monotonic()>deadline), 10000)
                schema = db.execute("SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
                emit('database_schema.json', schema)
                cohorts = db.execute('SELECT dataset,split,label,COUNT(*) FROM assemblies GROUP BY dataset,split,label').fetchall()
                emit('database_counts.json', cohorts)
                ids = db.execute('SELECT dataset,assembly_id,split,label,tokens FROM assemblies ORDER BY dataset,assembly_id')
                buffer = io.StringIO(); writer = csv.writer(buffer)
                writer.writerow(['dataset', 'assembly_id', 'split', 'label', 'tokens'])
                writer.writerows(ids)
                archive.writestr('inspection/assembly_membership.csv', buffer.getvalue())
                samples = []
                for dataset, split in sorted({(r[0], r[1]) for r in cohorts}):
                    row = db.execute('SELECT payload FROM assemblies WHERE dataset=? AND split=? LIMIT 1',
                                     (dataset, split)).fetchone()
                    if row and len(row[0]) < 500000:
                        samples.append(json.loads(row[0]))
                emit('record_examples.json', samples)
            except (OSError, sqlite3.Error, ValueError) as exc:
                manifest['errors'].append({'path': str(dbpath), 'error': str(exc)})
            finally:
                if db is not None:
                    db.close()
        else:
            emit('database_status.json', {'path': str(dbpath), 'exists': dbpath.is_file(),
                                          'skipped_by_request': args.skip_database})

        # Inventory large inputs without loading/copying their contents.
        inventory = []
        for rel in ['e0_training_prep_461027/training_data.sqlite3', 'e0_cache_final_491894/features.f32',
                    'e0_cache_final_491894/feature_index.sqlite3', 'e1_ssl_targets_497189/targets.npz',
                    'e1_ssl_continue30_v1_530757/best.pt']:
            p = root/rel
            entry = {'path': str(p), 'exists': p.is_file()}
            if p.is_file():
                st = p.stat(); entry.update(bytes=st.st_size, mtime_ns=st.st_mtime_ns)
            inventory.append(entry)
        emit('large_assets.json', inventory)
        emit('top_level_entries.json', [{'name': p.name, 'directory': p.is_dir()}
              for p in sorted(root.iterdir()) if not p.name.startswith('.')])
        emit('collector_runtime.json', {'python': sys.version, 'sqlite': sqlite3.sqlite_version,
                                        'note': 'Collector environment, not necessarily training environment'})
        manifest['copied_source_bytes'] = used
        archive.writestr('COLLECTION_MANIFEST.json', json.dumps(manifest, indent=2)+'\n')
    print('Created:', destination)
    print('Files copied:', len(manifest['files']), '| ZIP MiB:', round(destination.stat().st_size/2**20, 2))
    print('Missing paths:', len(set(manifest['missing'])), '| Skipped:', len(manifest['skipped']),
          '| Read errors:', len(manifest['errors']))
    print('Upload this ZIP. Missing/skipped items are recorded inside; no project files were changed.')


if __name__ == '__main__':
    main()
