"""Evaluate sealed context-benefit predictions without fitting or score selection.

Public API: evaluate_scores(score_file, out_dir, sealed_sha, *, data_dir,
                            bootstrap_reps=2000, seed=20261008).
The score file is verified before any assay label or grouping file is opened.
Positive context benefit is always interpreted as higher compatibility.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import gzip
import hashlib
import json
import math
from pathlib import Path

import numpy as np

METHODS = ("raw_full", "raw_local", "benefit_full", "benefit_local")
FIELDS = ("domains", "boundaries", "balanced", "neighborhood_mean")
PAIRS = (("benefit_full", "raw_full"), ("benefit_local", "raw_local"),
         ("benefit_full", "benefit_local"), ("raw_full", "raw_local"))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def read_scores(path):
    with (gzip.open(path, "rt") if str(path).endswith(".gz") else open(path)) as handle:
        return [json.loads(line) for line in handle if line.strip()]


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def finite(value):
    return type(value) in (float, int) and math.isfinite(value)


def binary_metrics(labels, scores, weights=None):
    """Tie-aware weighted AUROC/AP, without sklearn or score reversal."""
    y, s = np.asarray(labels), np.asarray(scores, dtype=float)
    require(y.ndim == s.ndim == 1 and len(y) == len(s), "Metric vector mismatch")
    require(set(y.tolist()) <= {0, 1} and np.isfinite(s).all(), "Invalid metric values")
    w = np.ones(len(y)) if weights is None else np.asarray(weights, dtype=float)
    require(w.shape == y.shape and np.isfinite(w).all() and (w >= 0).all(), "Invalid metric weights")
    p, n = float(w[y == 1].sum()), float(w[y == 0].sum())
    result = {"n": int((w > 0).sum()), "positive": int(((y == 1) & (w > 0)).sum()),
              "auroc": None, "average_precision": None, "reason": "EMPTY_OR_SINGLE_CLASS"}
    if not p or not n:
        return result
    order = np.argsort(s, kind="stable")
    yy, ss, ww = y[order], s[order], w[order]
    starts = np.r_[0, np.flatnonzero(np.diff(ss)) + 1]
    pg, ng = np.add.reduceat(ww * yy, starts), np.add.reduceat(ww * (1 - yy), starts)
    auc = float(np.sum(pg * (np.cumsum(ng) - ng + .5 * ng)) / (p * n))
    pg, ng = pg[::-1], ng[::-1]
    cp, cn = np.cumsum(pg), np.cumsum(ng)
    precision = np.divide(cp, cp + cn, out=np.zeros_like(cp), where=(cp + cn) > 0)
    return {**result, "auroc": auc, "average_precision": float(np.sum(pg * precision) / p), "reason": None}


def stable_seed(seed, *parts):
    blob = json.dumps([seed, *parts], separators=(",", ":"), sort_keys=True).encode()
    return int.from_bytes(hashlib.sha256(blob).digest()[:8], "little")


def no_bootstrap(reason):
    return {"ci95": None, "bootstrap_status": reason, "bootstrap_valid": 0,
            "bootstrap_requested": 0, "bootstrap_groups": None}


def cluster_bootstrap(y, a, clusters, *, b=None, reps=2000, seed=20261008):
    y, a = np.asarray(y), np.asarray(a, dtype=float)
    b = None if b is None else np.asarray(b, dtype=float)
    require(len(y) == len(a) == len(clusters) and (b is None or len(b) == len(y)), "Bootstrap vector mismatch")
    unique = sorted(set(clusters))
    result = {"ci95": None, "bootstrap_groups": len(unique), "bootstrap_requested": reps,
              "bootstrap_valid": 0, "bootstrap_seed": int(seed),
              "bootstrap_status": "TOO_FEW_DECLARED_GROUPS", "bootstrap_kind": "paired_cluster_percentile" if b is not None else "cluster_percentile"}
    if len(unique) < 10:
        return result
    counts = [len({group for group, label in zip(clusters, y) if label == k}) for k in (0, 1)]
    result["class_group_counts"] = counts
    if min(counts) < 2:
        result["bootstrap_status"] = "TOO_FEW_CLASS_SUPPORTING_GROUPS"
        return result
    mapping = {name: i for i, name in enumerate(unique)}
    group_index = np.array([mapping[g] for g in clusters])
    rng, values = np.random.default_rng(seed), []
    for _ in range(reps):
        weights = rng.multinomial(len(unique), np.full(len(unique), 1 / len(unique)))[group_index]
        first = binary_metrics(y, a, weights)["auroc"]
        if first is None:
            continue
        if b is not None:
            second = binary_metrics(y, b, weights)["auroc"]
            if second is None:
                continue
            first -= second
        values.append(first)
    result["bootstrap_valid"] = len(values)
    if len(values) < .9 * reps:
        result["bootstrap_status"] = "TOO_MANY_SINGLE_CLASS_RESAMPLES"
        return result
    result.update(ci95=np.quantile(values, [.025, .975]).tolist(), bootstrap_status="DESCRIPTIVE_GROUPED_INTERVAL")
    return result


def background(region):
    if region.get("background_id"):
        return region["background_id"]
    if region["dataset"] == "bode2":
        return "bode2_native_background|position=" + str(region["position"])
    if region["dataset"] == "tdomain":
        require(region.get("context"), "Missing T-domain context")
        return "tdomain|context=" + region["context"]
    raise ValueError("Missing BODE1 matched background")


def prepare(rows, regions, labels, groups):
    declared = {(r["dataset"], r["region_id"]): r for r in regions}
    require(len(declared) == len(regions), "Duplicate declared region")
    index = {}
    for row in rows:
        key = (row["dataset"], row["region_id"])
        require(key in declared and key not in index, "Unknown or duplicate scored region")
        expected = declared[key]
        for field in ("assembly_id", "role", "position", "domain_indices", "boundary_indices"):
            require(row.get(field) == expected.get(field), "Score/declaration mismatch: " + field)
        require(row.get("background_id") in (expected.get("background_id"), background(expected)), "Score background mismatch")
        require(row.get("context", "") == expected.get("context", ""), "Score context mismatch")
        require(set(row.get("methods", {})) == set(METHODS), "Missing or unknown score method")
        for method in METHODS:
            values = row["methods"][method]
            require(all(field in values for field in FIELDS), "Missing score aggregation")
            require(all(values[field] is None or finite(values[field]) for field in FIELDS), "Nonfinite score aggregation")
            if finite(values["balanced"]):
                require(finite(values["domains"]) and finite(values["boundaries"]), "Balanced score has unsupported component")
                require(abs(values["balanced"] - .5 * (values["domains"] + values["boundaries"])) < 1e-7,
                        "Balanced score is not equal domain/boundary weighting")
        index[key] = row
    require(set(index) == set(declared), "Every declared region must report score availability")
    for dataset, mapping in labels.items():
        require(isinstance(mapping, dict) and all(type(v) is int and v in (0, 1) for v in mapping.values()), "Invalid binary labels")
    for region in regions:
        require(region["assembly_id"] in groups.get(region["dataset"], {}), "Missing assembly grouping metadata")
    return index


def value(region, method, field, index):
    return index[(region["dataset"], region["region_id"])]["methods"][method][field]


def shared(entries, methods, field, index):
    return [r for r in entries if all(finite(value(r, method, field, index)) for method in methods)]


def label(region, labels):
    return labels[region["dataset"]][region["assembly_id"]]


def cluster(region, groups):
    ds, aid = region["dataset"], region["assembly_id"]
    field = "donor_triplet_group" if ds == "bode2" else "minimum_ancestry_group"
    require(ds in ("bode2", "tdomain"), "BODE1 has no independent region bootstrap")
    result = groups[ds][aid].get(field)
    require(isinstance(result, str) and result, "Missing declared resampling group")
    return result


def metric(entries, method, field, index, labels, *, macro=False):
    selected = shared(entries, (method,), field, index)
    yy = [label(r, labels) for r in selected]
    result = {"n_regions": len(selected), "n_assemblies": len({r["assembly_id"] for r in selected}),
              "positive_regions": sum(yy), "negative_regions": len(yy) - sum(yy)}
    if not macro:
        return {**result, **binary_metrics(yy, [value(r, method, field, index) for r in selected])}, []
    bins = defaultdict(list)
    for region in selected:
        bins[background(region)].append(region)
    panels = []
    for name, rr in sorted(bins.items()):
        require(len(rr) == len({r["assembly_id"] for r in rr}), "Repeated assembly inside one matched background")
        panels.append({"background_id": name, **binary_metrics([label(r, labels) for r in rr],
                     [value(r, method, field, index) for r in rr])})
    usable = [p for p in panels if p["auroc"] is not None]
    return {**result, "auroc": float(np.mean([p["auroc"] for p in usable])) if usable else None,
            "average_precision": float(np.mean([p["average_precision"] for p in usable])) if usable else None,
            "mixed_backgrounds": len(usable), "regions_in_mixed_backgrounds": sum(p["n"] for p in usable),
            "reason": None if usable else "NO_MIXED_LABEL_BACKGROUNDS"}, panels


def uncertainty(spec, entries, first, field, index, labels, groups, reps, seed, second=None):
    if spec["dataset"] == "bode1":
        return no_bootstrap("OVERLAPPING_FACTORIAL_BACKGROUNDS_NO_IID_INTERVAL")
    if not spec["allow_ci"]:
        return no_bootstrap("DESCRIPTIVE_STRATUM_ONLY")
    return cluster_bootstrap([label(r, labels) for r in entries],
        [value(r, first, field, index) for r in entries], [cluster(r, groups) for r in entries],
        b=[value(r, second, field, index) for r in entries] if second else None, reps=reps,
        seed=stable_seed(seed, spec["dataset"], spec["cohort"], field, first, second))


def cohort_specs(regions, labels, groups):
    specs = []
    for ds in ("bode1", "bode2", "tdomain"):
        entries = sorted([r for r in regions if r["dataset"] == ds and r["role"] == "engineered"
                          and r["assembly_id"] in labels.get(ds, {})], key=lambda r: r["region_id"])
        if ds == "tdomain":
            require(all(groups[ds][r["assembly_id"]]["evaluation_cohort"] == "primary65" for r in entries),
                    "Undeclared T-domain binary endpoint")
        if ds != "bode1":
            require(len(entries) == len({r["assembly_id"] for r in entries}), "Pooled metrics require one region per assembly")
        main = "primary65" if ds == "tdomain" else "all_engineered"
        strata = [(main, entries, True)]
        if ds == "tdomain":
            strata.append(("source_agreement63", [r for r in entries if groups[ds][r["assembly_id"]].get("source_agreement_subset") in (True, "True")], True))
            for generation in sorted({str(groups[ds][r["assembly_id"]].get("generation_round")) for r in entries}):
                strata.append(("generation_round=" + generation, [r for r in entries if str(groups[ds][r["assembly_id"]].get("generation_round")) == generation], False))
        else:
            for position in sorted({str(r["position"]) for r in entries}):
                strata.append(("position=" + position, [r for r in entries if str(r["position"]) == position], ds == "bode2"))
        for cohort, selected, allow_ci in strata:
            for field in (("domains", "neighborhood_mean") if ds == "tdomain" else ("balanced",)):
                specs.append({"dataset": ds, "cohort": cohort, "regions": selected, "field": field, "allow_ci": allow_ci,
                              "primary_field": field == ("domains" if ds == "tdomain" else "balanced")})
    return specs


def region_tables(specs, index, labels, groups, reps, seed):
    metrics, coverage, panels, contrasts = [], [], [], []
    for spec in specs:
        ds, entries, field = spec["dataset"], spec["regions"], spec["field"]
        base = {k: spec[k] for k in ("dataset", "cohort", "field", "primary_field")}
        base["metric_unit"] = "macro_within_matched_background" if ds == "bode1" else "pooled_unique_assemblies"
        for method in METHODS:
            selected = shared(entries, (method,), field, index)
            stats, pp = metric(selected, method, field, index, labels, macro=ds == "bode1")
            metrics.append({**base, "method": method, "coverage_rule": "method_available", **stats,
                **uncertainty(spec, selected, method, field, index, labels, groups, reps, seed)})
            coverage.append({**base, "method": method, "planned_regions": len(entries),
                             "scored_regions": len(selected), "missing_regions": len(entries) - len(selected),
                             "planned_assemblies": len({r["assembly_id"] for r in entries}),
                             "scored_assemblies": len({r["assembly_id"] for r in selected})})
            panels.extend({**base, "method": method, **p} for p in pp)
        common = shared(entries, METHODS, field, index)
        for method in METHODS:
            stats, _ = metric(common, method, field, index, labels, macro=ds == "bode1")
            metrics.append({**base, "method": method, "coverage_rule": "all_four_methods_intersection", **stats,
                **uncertainty(spec, common, method, field, index, labels, groups, reps, seed)})
        for first, second in PAIRS:
            rr = shared(entries, (first, second), field, index)
            a, _ = metric(rr, first, field, index, labels, macro=ds == "bode1")
            b, _ = metric(rr, second, field, index, labels, macro=ds == "bode1")
            contrasts.append({**base, "first": first, "second": second, "delta_definition": "first minus second",
                "shared_regions": len(rr), "shared_assemblies": len({r["assembly_id"] for r in rr}),
                "first_auroc": a["auroc"], "second_auroc": b["auroc"],
                "auroc_delta": a["auroc"] - b["auroc"] if a["auroc"] is not None and b["auroc"] is not None else None,
                **uncertainty(spec, rr, first, field, index, labels, groups, reps, seed, second)})
    return metrics, coverage, panels, contrasts


def assembly_predictions(regions, index, labels, groups):
    bins = defaultdict(list)
    for region in regions:
        bins[(region["dataset"], region["assembly_id"])].append(region)
    result = []
    for (ds, aid), rr in sorted(bins.items()):
        field = "domains" if ds == "tdomain" else "balanced"
        scores, missing = {}, {}
        for method in METHODS:
            values = [value(r, method, field, index) for r in rr]
            missing[method] = sum(not finite(v) for v in values)
            scores[method] = math.fsum(values) / len(values) if not missing[method] else None
        result.append({"dataset": ds, "assembly_id": aid, "role": rr[0]["role"],
            "region_ids": sorted(r["region_id"] for r in rr), "region_count": len(rr), "field": field,
            "scores": scores, "missing_regions": missing, "observed_activity": labels.get(ds, {}).get(aid),
            "primary_binary_eligible": rr[0]["role"] == "engineered" and aid in labels.get(ds, {}),
            "raw_complete_case": all(finite(scores[m]) for m in ("raw_full", "raw_local")),
            "metadata": groups[ds][aid]})
    return result


def bode1_assembly_tables(predictions):
    """One mean score per complete assembly, then macro over its donor panels.

    Repeated donor membership is never treated as independent observations.
    These are descriptive frozen-model panels, not newly trained CV models.
    """
    planned = [r for r in predictions if r["dataset"] == "bode1" and r["primary_binary_eligible"]]
    require(all(r["region_count"] == 3 for r in planned), "BODE1 requires all three declared regions")
    entries = [r for r in planned if r["raw_complete_case"]]
    donors = sorted({donor for r in planned for donor in r["metadata"]["parts"]})
    require(all(len(r["metadata"]["parts"]) == len(set(r["metadata"]["parts"])) == 3 for r in planned),
            "BODE1 assembly must have three distinct donor memberships")
    metrics, panels, contrasts = [], [], []

    def compute(rr, method):
        pp = []
        for donor in donors:
            dd = [r for r in rr if donor in r["metadata"]["parts"]]
            pp.append({"donor": donor, **binary_metrics([r["observed_activity"] for r in dd], [r["scores"][method] for r in dd])})
        usable = [p for p in pp if p["auroc"] is not None]
        return {"auroc": float(np.mean([p["auroc"] for p in usable])) if usable else None,
                "average_precision": float(np.mean([p["average_precision"] for p in usable])) if usable else None,
                "n_assemblies": len(rr), "positive": sum(r["observed_activity"] for r in rr),
                "planned_donor_panels": len(donors), "mixed_donor_panels": len(usable),
                "donor_panel_memberships": sum(p["n"] for p in pp)}, pp

    base = {"dataset": "bode1", "cohort": "raw_complete_assemblies", "metric_unit": "mean_donor_panel_auroc",
            "planned_assemblies": len(planned), "raw_complete_assemblies": len(entries),
            "raw_incomplete_assemblies": len(planned) - len(entries),
            **no_bootstrap("OVERLAPPING_DONOR_PANELS_NO_IID_INTERVAL")}
    for coverage_rule, required in (("method_available", None), ("all_four_methods_intersection", METHODS)):
        for method in METHODS:
            rr = [r for r in entries if all(finite(r["scores"][m]) for m in (required or (method,)))]
            stats, pp = compute(rr, method)
            metrics.append({**base, "method": method, "coverage_rule": coverage_rule, **stats})
            panels.extend({"method": method, "coverage_rule": coverage_rule, **p} for p in pp)
            metrics.append({**base, "metric_unit": "pooled_unique_assemblies_descriptive", "method": method,
                "coverage_rule": coverage_rule, **binary_metrics([r["observed_activity"] for r in rr], [r["scores"][method] for r in rr])})
    for first, second in PAIRS:
        rr = [r for r in entries if finite(r["scores"][first]) and finite(r["scores"][second])]
        a, ap = compute(rr, first)
        b, bp = compute(rr, second)
        deltas = [x["auroc"] - y["auroc"] for x, y in zip(ap, bp) if x["auroc"] is not None and y["auroc"] is not None]
        contrasts.append({**base, "first": first, "second": second, "shared_assemblies": len(rr),
            "first_auroc": a["auroc"], "second_auroc": b["auroc"], "delta_definition": "first minus second",
            "auroc_delta": float(np.mean(deltas)) if deltas else None, "paired_mixed_donor_panels": len(deltas),
            "positive_deltas": sum(d > 0 for d in deltas), "negative_deltas": sum(d < 0 for d in deltas),
            "ties": sum(d == 0 for d in deltas)})
    return metrics, panels, contrasts


def evaluate_scores(score_file, out_dir, sealed_sha, *, data_dir, bootstrap_reps=2000, seed=20261008):
    score_file, out_dir, data_dir = Path(score_file), Path(out_dir), Path(data_dir)
    require(isinstance(sealed_sha, str) and len(sealed_sha) == 64 and sha(score_file) == sealed_sha,
            "Prediction seal mismatch: labels have not been opened")
    require(type(bootstrap_reps) is int and bootstrap_reps >= 100, "Use at least 100 bootstrap repetitions")
    # No earlier label access occurs in this evaluator.
    labels, groups, regions = (read_json(data_dir / (name + ".json")) for name in ("labels", "groups", "regions"))
    rows = read_scores(score_file)
    index = prepare(rows, regions, labels, groups)
    specs = cohort_specs(regions, labels, groups)
    metrics, coverage, panels, contrasts = region_tables(specs, index, labels, groups, bootstrap_reps, seed)
    predictions = assembly_predictions(regions, index, labels, groups)
    assembly_metrics, donor_panels, assembly_contrasts = bode1_assembly_tables(predictions)
    role_coverage = []
    for ds, role in sorted({(r["dataset"], r["role"]) for r in regions}):
        rr = [r for r in regions if r["dataset"] == ds and r["role"] == role]
        for method in METHODS:
            field = "domains" if ds == "tdomain" else "balanced"
            role_coverage.append({"dataset": ds, "role": role, "method": method, "regions": len(rr),
                "assemblies": len({r["assembly_id"] for r in rr}), "scored_primary_regions": len(shared(rr, (method,), field, index)),
                "status_counts": dict(Counter(index[(ds, r["region_id"])].get("status", "UNSPECIFIED") for r in rr))})
    summary = {"status": "CONTEXT_BENEFIT_EVALUATED", "study_role": "RETROSPECTIVE_DEVELOPMENT_EXPERIMENT",
        "prediction_sha256": sealed_sha, "predictions_verified_before_label_access": True,
        "training_updates": 0, "activity_classifier_fits": 0, "score_direction_selected": False,
        "decision_threshold_selected": False, "bootstrap_repetitions": bootstrap_reps, "seed": seed,
        "orientation": "All methods: higher is more compatible. Benefit = median alternative-context error minus own-context error.",
        "primary_fields": {"bode1": "balanced", "bode2": "balanced", "tdomain": "domains"},
        "primary_metric_units": {"bode1": "macro_within_matched_background", "bode2": "pooled_unique_assemblies", "tdomain": "pooled_unique_assemblies"},
        "bode1_legacy_comparison": "Mean donor-panel AUROC after averaging exactly three complete region scores per assembly; no classifier is fitted for these panels.",
        "tdomain_secondary": "neighborhood_mean over PCP and flanking boundary objects",
        "metrics": metrics, "coverage": coverage, "paired_contrasts": contrasts,
        "bode1_assembly_metrics": assembly_metrics, "bode1_assembly_paired_contrasts": assembly_contrasts,
        "all_role_coverage": role_coverage,
        "source_files_sha256": {name + ".json": sha(data_dir / (name + ".json")) for name in ("regions", "labels", "groups")},
        "limitations": [
            "Alternative contexts are controls with unknown biological activity; no inactive labels are assigned to them.",
            "Comparisons use exact score-availability intersections. Missing matches are not zero scores and are not imputed.",
            "BODE1 backgrounds, donor panels and repeated assemblies overlap; no IID confidence interval or inflated sample size is used.",
            "BODE2 intervals resample whole donor groups; T-domain intervals resample documented minimum ancestry groups, not verified independent homology groups.",
            "Intervals resample fixed predictions without retraining and are descriptive, unadjusted for multiple comparisons.",
            "T-domain primary binary metrics include only the frozen 65 minimal-context assays; no hybrid activity endpoint is invented.",
            "Positive benefit indicates preference relative to the declared controls; it is not an activity probability or proof of causal fault localization.",
            "These already inspected datasets are retrospective development evaluations, not newly untouched external validation."]}
    require(sha(score_file) == sealed_sha, "Predictions changed during evaluation")
    out_dir.mkdir(parents=True, exist_ok=True)
    dump(out_dir / "summary.json", summary)
    dump(out_dir / "assembly_predictions.json", predictions)
    dump(out_dir / "matched_background_panels.json", panels)
    dump(out_dir / "bode1_donor_panels.json", donor_panels)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--sealed-sha", required=True)
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--bootstrap-reps", default=2000, type=int)
    args = parser.parse_args()
    result = evaluate_scores(args.input, args.out, args.sealed_sha, data_dir=args.data_dir, bootstrap_reps=args.bootstrap_reps)
    print(json.dumps({"status": result["status"], "metric_rows": len(result["metrics"]), "classifier_fits": 0}))


if __name__ == "__main__":
    main()
