#!/usr/bin/env bash
set -eo pipefail
NRPS_BENEFIT_PACKAGE="${1:?package}"
NRPS_BENEFIT_ROOT="${2:?root}"
NRPS_BENEFIT_REQUEST="${3:?request}"
cd "$NRPS_BENEFIT_ROOT"
module purge
module load arch/a100
module load pytorch-gpu/py3/2.8.0
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
export TMPDIR="$NRPS_BENEFIT_ROOT/e14_context_benefit_tmp_${SLURM_JOB_ID}"
export SQLITE_TMPDIR="$TMPDIR"
mkdir -p "$TMPDIR"
NRPS_BENEFIT_PY=$(python3 -B -c 'import sys; print(sys.base_prefix + "/bin/python3")')
"$NRPS_BENEFIT_PY" -B - "$NRPS_BENEFIT_REQUEST" <<'PY'
import hashlib
from pathlib import Path
import sys
request = Path(sys.argv[1])
expected = request.with_suffix('.json.sha256').read_text().strip()
actual = hashlib.sha256(request.read_bytes()).hexdigest()
if actual != expected:
    raise SystemExit('IMMUTABLE_REQUEST_HASH_MISMATCH: refusing context benefit')
print('CONTEXT_BENEFIT_REQUEST_SHA256_OK:', actual, flush=True)
PY
"$NRPS_BENEFIT_PY" -B "$NRPS_BENEFIT_PACKAGE/verify.py"
NRPS_BENEFIT_OUT="$NRPS_BENEFIT_ROOT/e14_context_benefit_${SLURM_JOB_ID}"
NRPS_BENEFIT_FLAGS=()
if [ -n "${4:-}" ]; then
    NRPS_BENEFIT_OUT="$4"
    NRPS_BENEFIT_FLAGS=(--resume)
fi
exec "$NRPS_BENEFIT_PY" -u -B "$NRPS_BENEFIT_PACKAGE/run_benefit.py" \
    --root "$NRPS_BENEFIT_ROOT" --out "$NRPS_BENEFIT_OUT" \
    --request "$NRPS_BENEFIT_REQUEST" "${NRPS_BENEFIT_FLAGS[@]}"
