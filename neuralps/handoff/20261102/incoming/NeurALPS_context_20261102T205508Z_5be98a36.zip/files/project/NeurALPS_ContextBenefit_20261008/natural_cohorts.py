"""Label-free cohort preparation for the fixed natural-reference scale.

The previously unused natural ``internal_test`` split is explicitly repurposed
into calibration and audit components. Assignment uses no model scores, assay
outcomes or balancing retries. This module performs no writes and runs no model.
"""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import sqlite3


SPLIT_SEED = 20261006
EXPECTED_COUNTS = {
    "natural_train": 27913,
    "natural_dev": 3499,
    "natural_internal_test": 3515,
    "bode1": 324,
    "bode2": 106,
}
MISSING_TAXONOMY = {"", "none", "null", "unknown", "missing", "unassigned", "unclassified", "na", "n/a"}
ASSAY_KEYS = {"active", "inactive", "activity", "activity_status", "peak_score", "peak_area", "outcome", "phenotype"}


def _canonical_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _sha(value):
    return hashlib.sha256(_canonical_bytes(value)).hexdigest()


def _strip_labels(value):
    """Remove label/outcome metadata recursively, retaining structural fields."""
    if isinstance(value, dict):
        return {
            key: _strip_labels(item)
            for key, item in value.items()
            if "label" not in key.lower() and key.lower() not in ASSAY_KEYS
        }
    if isinstance(value, list):
        return [_strip_labels(item) for item in value]
    return value


def _taxonomy(record):
    raw = record.get("taxonomy_group")
    if raw is not None and not isinstance(raw, str):
        raise ValueError("taxonomy_group must be a string or null")
    group = raw.strip() if isinstance(raw, str) else ""
    if group.lower() not in MISSING_TAXONOMY:
        return group, "taxonomy:" + group, "provided_taxonomy_group"
    accession = record.get("source_summary_before_repair", {}).get("accession")
    if not isinstance(accession, str) or not accession.strip():
        prefix = record["assembly_id"].split("|", 1)[0]
        accession = prefix if re.fullmatch(r"GC[AF]_\d+(?:\.\d+)?", prefix) else None
    if accession:
        return None, "fallback_accession:" + accession.strip(), "missing_taxonomy_accession_fallback"
    record_id = record.get("record_id")
    if isinstance(record_id, str) and record_id.strip():
        return None, "fallback_record:" + record_id.strip(), "missing_taxonomy_record_fallback"
    return None, "fallback_assembly:" + record["assembly_id"], "missing_taxonomy_assembly_fallback"


def _valid_hash(value, field):
    if not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise ValueError("Expected SHA256 for " + field)
    return value


def _hash_metadata(record):
    """Return the complete exact sequence/parent identities used by inference."""
    aid = record["assembly_id"]
    slots = record.get("model_slots")
    if not isinstance(slots, list):
        raise ValueError(aid + ": model_slots missing")
    parent_map = record.get("parent_sequence_hashes")
    if not isinstance(parent_map, dict):
        raise ValueError(aid + ": parent_sequence_hashes missing")
    parents = {_valid_hash(x, "parent_sequence_hashes") for x in parent_map.values()}
    features = set()
    identities = []
    seen_slots = set()
    for slot in slots:
        key = (slot["object_index"], slot["slot"])
        if key in seen_slots:
            raise ValueError(aid + ": duplicate model slot")
        seen_slots.add(key)
        parent = slot.get("parent_sequence_hash")
        if parent is not None:
            _valid_hash(parent, "slot.parent_sequence_hash")
            if parent not in parents:
                raise ValueError(aid + ": slot parent absent from parent_sequence_hashes")
        observed = slot.get("state") == "OBSERVED"
        feature = _valid_hash(slot.get("sequence_hash"), "observed sequence_hash") if observed else None
        if observed:
            features.add(feature)
        identities.append({
            "object_index": key[0], "slot": key[1], "state": slot.get("state"),
            "sequence_hash": feature, "parent_sequence_hash": parent,
        })
    group, tax_key, basis = _taxonomy(record)
    return {
        "assembly_id": aid,
        "taxonomy_group": group,
        "taxonomy_key": tax_key,
        "taxonomy_basis": basis,
        "parent_hashes": parents,
        "feature_hashes": features,
        "slots": sorted(identities, key=lambda s: (s["object_index"], s["slot"])),
    }


def _serial_hash_metadata(meta):
    return {key: sorted(value) if isinstance(value, set) else value for key, value in meta.items()}


class _UnionFind:
    def __init__(self, ids):
        self.parent = {aid: aid for aid in ids}
        self.size = {aid: 1 for aid in ids}

    def find(self, aid):
        root = aid
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[aid] != aid:
            next_aid = self.parent[aid]
            self.parent[aid] = root
            aid = next_aid
        return root

    def union(self, left, right):
        left, right = self.find(left), self.find(right)
        if left == right:
            return False
        if (self.size[left], left) < (self.size[right], right):
            left, right = right, left
        self.parent[right] = left
        self.size[left] += self.size[right]
        return True


def _connected_components(metas):
    """Union within internal_test by taxonomy OR parent OR observed feature."""
    ids = sorted(metas)
    uf = _UnionFind(ids)
    first_seen = {key: {} for key in ("taxonomy_key", "parent_hashes", "feature_hashes")}
    edge_counts = Counter()
    successful_unions = Counter()
    for aid in ids:
        meta = metas[aid]
        for kind, values in (
            ("taxonomy_key", [meta["taxonomy_key"]]),
            ("parent_hashes", sorted(meta["parent_hashes"])),
            ("feature_hashes", sorted(meta["feature_hashes"])),
        ):
            index = first_seen[kind]
            for value in values:
                if value in index:
                    edge_counts[kind] += 1
                    successful_unions[kind] += int(uf.union(aid, index[value]))
                else:
                    index[value] = aid
    members = defaultdict(list)
    for aid in ids:
        members[uf.find(aid)].append(aid)
    components, assignment = {}, {}
    for group in sorted(members.values()):
        group = sorted(group)
        cid = "component_" + _sha(group)
        assignment_hash = _sha({"seed": SPLIT_SEED, "assembly_ids": group})
        parity = int(assignment_hash, 16) % 2
        role = "calibration" if parity == 0 else "audit"
        components[cid] = {
            "assembly_ids": group, "assemblies": len(group), "role": role,
            "assignment_sha256": assignment_hash, "assignment_parity": parity,
        }
        for aid in group:
            assignment[aid] = {"component_id": cid, "role": role}
    proof = {}
    for kind in ("taxonomy_key", "parent_hashes", "feature_hashes"):
        by_role = {role: set() for role in ("calibration", "audit")}
        for aid, meta in metas.items():
            values = [meta[kind]] if kind == "taxonomy_key" else meta[kind]
            by_role[assignment[aid]["role"]].update(values)
        shared = by_role["calibration"] & by_role["audit"]
        if shared:
            raise AssertionError("Component split is not disjoint for " + kind)
        proof[kind] = {
            "cross_role_shared_count": 0,
            "calibration_unique_count": len(by_role["calibration"]),
            "audit_unique_count": len(by_role["audit"]),
            "calibration_set_sha256": _sha(sorted(by_role["calibration"])),
            "audit_set_sha256": _sha(sorted(by_role["audit"])),
        }
    union_audit = {
        "shared_key_links_to_first_member": {key: edge_counts[key] for key in first_seen},
        "successful_union_operations_in_fixed_key_order": {key: successful_unions[key] for key in first_seen},
        "unique_link_keys": {key: len(index) for key, index in first_seen.items()},
        "disjointness_proof": proof,
    }
    return components, assignment, union_audit


def _query_groups(record, meta):
    by_object = defaultdict(list)
    for slot in meta["slots"]:
        by_object[slot["object_index"]].append(slot)
    route = record["route"]
    if set(by_object) != set(range(len(route))):
        raise ValueError(record["assembly_id"] + ": slots do not cover every route object")
    for object_index in range(len(route)):
        slots = sorted(by_object[object_index], key=lambda s: s["slot"])
        kind = route[object_index]["kind"]
        if kind in (0, 1) and [s["slot"] for s in slots] != [0]:
            raise ValueError("Domain/covalent object must have slot zero")
        if kind == 2 and [s["slot"] for s in slots] != [1, 2]:
            raise ValueError("Protein break must have both physical terminal slots")
        if kind not in (0, 1, 2):
            raise ValueError("Unknown physical object kind")
        for slot in slots:
            yield object_index, kind, [slot]
        if kind == 2:
            yield object_index, kind, slots


def _count_database(connection):
    counts = Counter()
    row_counts = []
    for dataset, split, count in connection.execute("SELECT dataset, split, count(*) FROM assemblies GROUP BY dataset, split ORDER BY dataset, split"):
        row_counts.append({"dataset": dataset, "split": split, "assemblies": count})
        key = "natural_" + split if dataset == "natural" else dataset
        counts[key] += count
    return counts, row_counts


def prepare_cohorts(db_path, *, expected_counts=None):
    """Return ``(records_by_aid, split_manifest, overlap_report)`` without writes.

    Default count requirements are strict production requirements. The optional
    keyword accepts the five EXPECTED_COUNTS keys for small test fixtures only;
    its use is explicitly marked in the returned manifest. No CLI bypass exists.
    Training/dev payloads are streamed for hash metadata and discarded. Returned
    records contain natural internal_test and both BODE sets, with all labels and
    assay outcome fields removed.
    """
    expected = dict(EXPECTED_COUNTS if expected_counts is None else expected_counts)
    if set(expected) != set(EXPECTED_COUNTS) or any(type(n) is not int or n < 0 for n in expected.values()):
        raise ValueError("expected_counts must contain all five nonnegative integer count fields")
    path = Path(db_path).resolve()
    records, metas, all_ids = {}, {}, set()
    source_sets = {split: {"feature_hashes": set(), "parent_hashes": set(), "taxonomy_keys": set()} for split in ("train", "dev")}
    source_sha = {split: hashlib.sha256() for split in ("train", "dev")}
    cohort_indices = {key: [] for key in ("natural_internal_test", "bode1", "bode2")}
    with sqlite3.connect(path.as_uri() + "?mode=ro", uri=True) as connection:
        actual, db_rows = _count_database(connection)
        mismatch = {key: {"expected": n, "actual": actual.get(key, 0)} for key, n in expected.items() if actual.get(key, 0) != n}
        unexpected_natural = {key: n for key, n in actual.items() if key.startswith("natural_") and key not in expected}
        if mismatch or unexpected_natural:
            raise ValueError("Full cohort count preflight failed: " + json.dumps({"mismatch": mismatch, "unexpected_natural_splits": unexpected_natural}, sort_keys=True))
        cursor = connection.execute("SELECT dataset, assembly_id, split, payload FROM assemblies WHERE dataset IN ('natural','bode1','bode2') ORDER BY dataset, assembly_id")
        for dataset, aid, split, raw in cursor:
            if aid in all_ids:
                raise ValueError("Assembly IDs must be globally unique across datasets: " + aid)
            all_ids.add(aid)
            record = _strip_labels(json.loads(raw))
            if record.get("assembly_id") != aid or record.get("dataset") != dataset or record.get("split") != split:
                raise ValueError("Payload identity disagrees with database columns: " + aid)
            meta = _hash_metadata(record)
            if dataset == "natural" and split in ("train", "dev"):
                for key in ("feature_hashes", "parent_hashes"):
                    source_sets[split][key].update(meta[key])
                source_sets[split]["taxonomy_keys"].add(meta["taxonomy_key"])
                source_sha[split].update(_canonical_bytes(_serial_hash_metadata(meta)) + b"\n")
                continue
            key = "natural_internal_test" if dataset == "natural" else dataset
            if dataset == "natural" and split != "internal_test":
                raise ValueError("Unexpected natural split: " + split)
            records[aid], metas[aid] = record, meta
            cohort_indices[key].append(aid)

    natural_metas = {aid: metas[aid] for aid in cohort_indices["natural_internal_test"]}
    components, assignment, union_audit = _connected_components(natural_metas)
    metadata = {}
    for aid in sorted(records):
        meta = metas[aid]
        role = assignment[aid] if aid in assignment else {"component_id": None, "role": "apply_only"}
        metadata[aid] = {
            **role, "dataset": records[aid]["dataset"],
            "source_split": records[aid]["split"],
            "taxonomy_group": meta["taxonomy_group"],
            "taxonomy_key": meta["taxonomy_key"], "taxonomy_basis": meta["taxonomy_basis"],
        }
    role_assembly_counts = {role: sum(x["role"] == role for x in assignment.values()) for role in ("calibration", "audit")}
    role_component_counts = {role: sum(x["role"] == role for x in components.values()) for role in ("calibration", "audit")}
    total = len(natural_metas)
    largest = max((x["assemblies"] for x in components.values()), default=0)
    usable = all(role_assembly_counts.values())
    warnings = []
    if largest > total/2:
        warnings.append("A connected component contains more than half the natural internal_test assemblies. Exact feature/parent links have not been relaxed.")
    if not usable:
        warnings.append("One natural role is empty; calibration/audit evaluation cannot proceed with this split. Assignment was not rerandomized.")
    elif abs(role_assembly_counts["calibration"]/total - 0.5) > 0.15:
        warnings.append("Hash parity gives an assembly imbalance greater than 15 percentage points from 50%; assignment remains fixed and score-independent.")
    split_manifest = {
        "version": "reference_scale_cohorts_v1",
        "seed": SPLIT_SEED,
        "purpose": "Repurpose formerly unused natural internal_test into fixed calibration and audit components before computing new scores; apply the scale to BODE without label access.",
        "uses_activity_labels": False,
        "uses_model_scores_for_split": False,
        "former_internal_test_remains_untouched_test": False,
        "expected_counts": expected,
        "production_count_requirements": dict(EXPECTED_COUNTS),
        "test_expected_counts_override": expected_counts is not None,
        "production_counts_verified": all(actual.get(k, 0) == v for k, v in EXPECTED_COUNTS.items()),
        "database_counts": db_rows,
        "cohort_indices": cohort_indices,
        "metadata": metadata,
        "components": components,
        "component_rule": "Transitive closure of same taxonomy key OR exact parent sequence SHA256 OR exact observed model-slot sequence SHA256, within natural internal_test only. No short/repeated-feature filter.",
        "missing_taxonomy_rule": "Use accession from source metadata, else GCA/GCF assembly prefix, else record_id, else complete assembly_id; fallback namespaces are separate from supplied taxonomy groups.",
        "assignment_rule": "SHA256 of canonical JSON {seed:20261006,assembly_ids:sorted_component_members}; integer parity 0=calibration,1=audit. No retries or outcome-dependent balancing.",
        "union_audit": union_audit,
        "role_assembly_counts": role_assembly_counts,
        "role_component_counts": role_component_counts,
        "role_assembly_proportions": {role: n/total if total else None for role, n in role_assembly_counts.items()},
        "role_component_proportions": {role: n/len(components) if components else None for role, n in role_component_counts.items()},
        "largest_component_assemblies": largest,
        "largest_component_fraction": largest/total if total else None,
        "component_size_histogram": {str(size): n for size, n in sorted(Counter(x["assemblies"] for x in components.values()).items())},
        "usable_two_way_split": usable,
        "warnings": warnings,
        "label_free_records_sha256": {key: _sha([records[aid] for aid in ids]) for key, ids in cohort_indices.items()},
        "train_dev_hash_metadata_sha256": {key: value.hexdigest() for key, value in source_sha.items()},
        "limits": [
            "Taxonomy groups and exact sequence identities do not establish homology-family separation.",
            "BODE assemblies are apply_only and are not members of the natural calibration/audit component partition.",
            "The natural internal_test split is now used for calibration and audit development; it must not later be called an untouched test set.",
        ],
    }

    assembly_overlap, query_overlap = {}, {}
    summary = defaultdict(Counter)
    for aid, record in sorted(records.items()):
        meta, assignment_meta = metas[aid], metadata[aid]
        cohort = assignment_meta["role"] if record["dataset"] == "natural" else record["dataset"]
        counts = summary[cohort]
        counts["assemblies"] += 1
        entry = {"dataset": record["dataset"], "role": assignment_meta["role"], "unique_observed_features": len(meta["feature_hashes"]), "unique_parents": len(meta["parent_hashes"])}
        for source in ("train", "dev"):
            feature_hits = meta["feature_hashes"] & source_sets[source]["feature_hashes"]
            parent_hits = meta["parent_hashes"] & source_sets[source]["parent_hashes"]
            taxonomy_hit = meta["taxonomy_key"] in source_sets[source]["taxonomy_keys"]
            entry[source] = {"exact_feature_hash_count": len(feature_hits), "exact_parent_hash_count": len(parent_hits), "same_taxonomy_key": taxonomy_hit}
            counts[source+"_feature_overlap_assemblies"] += bool(feature_hits)
            counts[source+"_parent_overlap_assemblies"] += bool(parent_hits)
            counts[source+"_taxonomy_overlap_assemblies"] += taxonomy_hit
        assembly_overlap[aid] = entry
        for index, kind, slots in _query_groups(record, meta):
            roles = [s["slot"] for s in slots]
            qid = aid + "|object=" + str(index) + "|roles=" + ",".join(map(str, roles))
            qe = {"assembly_id": aid, "object_index": index, "kind": kind, "roles": roles, "observed_slots": [s["slot"] for s in slots if s["state"] == "OBSERVED"]}
            counts["queries"] += 1
            for source in ("train", "dev"):
                seen_features = [s["slot"] for s in slots if s["state"] == "OBSERVED" and s["sequence_hash"] in source_sets[source]["feature_hashes"]]
                seen_parents = [s["slot"] for s in slots if s["parent_sequence_hash"] in source_sets[source]["parent_hashes"]]
                qe[source] = {"exact_feature_overlap_slots": seen_features, "exact_parent_overlap_slots": seen_parents, "any_exact_feature_overlap": bool(seen_features), "any_exact_parent_overlap": bool(seen_parents)}
                counts[source+"_feature_overlap_queries"] += bool(seen_features)
                counts[source+"_parent_overlap_queries"] += bool(seen_parents)
            query_overlap[qid] = qe
    overlap_report = {
        "version": "reference_scale_exact_overlap_v1",
        "scope": "Exact target feature/parent identity and taxonomy-key overlap against natural pretraining train and dev metadata. No training/dev inference.",
        "homology_separation_verified": False,
        "not_a_homology_search": True,
        "observed_feature_rule": "Only model slots with state OBSERVED contribute feature hashes; all exact parent hashes are retained. Protein-break single-terminal and joint queries are listed separately.",
        "sources": {source: {"assemblies": actual["natural_"+source], "unique_observed_features": len(index["feature_hashes"]), "unique_parents": len(index["parent_hashes"]), "unique_taxonomy_keys": len(index["taxonomy_keys"]), "metadata_sha256": source_sha[source].hexdigest()} for source, index in source_sets.items()},
        "summary_by_cohort": {key: dict(value) for key, value in summary.items()},
        "assemblies": assembly_overlap,
        "queries": query_overlap,
    }
    return records, split_manifest, overlap_report
