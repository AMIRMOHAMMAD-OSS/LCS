#!/usr/bin/env python3
"""CPU-only launcher regression tests; all scheduler calls are mocked."""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch


PACKAGE = Path(__file__).resolve().parent


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode()).hexdigest()


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n')


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


class LauncherTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.request = {'version': 'fixture_v1', 'input_sha256': '1' * 64,
                        'protocol_sha256': '2' * 64}
        common = types.ModuleType('cb_common')
        common.PACKAGE = PACKAGE
        common.VERSION = 'fixture_v1'
        common.canonical = canonical
        common.dump = dump
        common.load = lambda p: json.loads(Path(p).read_text())
        common.sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
        common.require = require
        common.preflight = lambda root: (
            {}, [{'dataset': 'bode1'}, {'dataset': 'bode2'}, {'dataset': 'tdomain'}],
            [{'region_id': 'fixture'}], self.request.copy())
        spec = importlib.util.spec_from_file_location('_benefit_launch_test', PACKAGE / 'launch.py')
        self.launch = importlib.util.module_from_spec(spec)
        with patch.dict(sys.modules, {'cb_common': common}):
            spec.loader.exec_module(self.launch)
        self.calls = []
        self.active = ''
        self.sbatch = subprocess.CompletedProcess([], 0, '710001\n', '')

    def fake_subprocess(self, command, **kwargs):
        self.calls.append(command)
        if command[0] == 'squeue':
            return subprocess.CompletedProcess(command, 0, self.active, '')
        if command[0] == 'sacct':
            return subprocess.CompletedProcess(command, 0, 'JobID State\n710001 PENDING\n', '')
        if command[0] == 'sbatch':
            return self.sbatch
        raise AssertionError('Unexpected external command: ' + repr(command))

    def run_action(self, action='run', output=None):
        args = ['launch.py', action]
        if output is not None:
            args.append(str(output))
        args += ['--root', str(self.root)]
        capture = io.StringIO()
        with patch.object(sys, 'argv', args), \
                patch.object(self.launch.subprocess, 'run', self.fake_subprocess), \
                contextlib.redirect_stdout(capture):
            self.launch.main()
        return capture.getvalue()

    def latest(self):
        return self.launch.load(self.root / 'e14_context_benefit_latest.json')

    def sbatch_calls(self):
        return [c for c in self.calls if c[0] == 'sbatch']

    def test_submit_records_immutable_request(self):
        self.run_action()
        self.assertEqual(len(self.sbatch_calls()), 1)
        row = self.latest()
        self.assertEqual(row['job_id'], '710001')
        self.assertEqual(Path(row['output']).name, 'e14_context_benefit_710001')
        request = Path(row['request'])
        self.assertEqual(self.launch.load(request), self.request)
        self.assertEqual(request.with_suffix('.json.sha256').read_text().strip(), self.launch.sha(request))
        self.assertEqual(request.stat().st_mode & 0o222, 0)
        self.assertEqual(row['request_sha256'], self.launch.sha(request))
        self.assertEqual(self.launch.load(row['attempt_record'])['state'], 'SUBMITTED')

    def test_resources_and_signal_are_explicit_no_memory_option(self):
        cmd, log = self.launch.sbatch_command(self.root, self.root / 'request.json', 'a' * 64)
        for value in ['--account=nef@a100', '--partition=gpu_p5', '--qos=qos_gpu_a100-t3',
                      '--nodes=1', '--ntasks=1', '--cpus-per-task=8', '--gres=gpu:1',
                      '--constraint=a100', '--time=02:00:00', '--signal=B:USR1@180']:
            self.assertIn(value, cmd)
        self.assertFalse(any(v.startswith('--mem') for v in cmd))
        self.assertTrue(any(v.startswith('--job-name=nrps_ctxbenefit') for v in cmd))
        self.assertEqual(log.name, 'e14_context_benefit_%j.log')
        self.assertIn(str(PACKAGE / 'batch.sh'), cmd)

    def test_preflight_is_read_only_and_never_calls_slurm(self):
        self.run_action('preflight')
        self.assertEqual(self.calls, [])
        self.assertFalse((self.root / 'e14_context_benefit_latest.json').exists())

    def test_failed_preflight_never_calls_slurm(self):
        with patch.object(self.launch, 'preflight', side_effect=RuntimeError('changed source')):
            with self.assertRaisesRegex(RuntimeError, 'changed source'):
                self.run_action()
        self.assertEqual(self.calls, [])

    def test_active_identical_request_is_not_resubmitted(self):
        self.run_action()
        self.active = '710001\n'
        text = self.run_action()
        self.assertIn('no duplicate', text)
        self.assertEqual(len(self.sbatch_calls()), 1)

    def test_complete_identical_request_is_not_resubmitted(self):
        self.run_action()
        out = Path(self.latest()['output'])
        out.mkdir()
        (out / self.launch.COMPLETE).touch()
        dump(out / 'summary.json', {'status': self.launch.COMPLETE})
        (out / 'context_benefit_inspection.zip').touch()
        text = self.run_action()
        self.assertIn('already complete', text)
        self.assertIn('context_benefit_inspection.zip', text)
        self.assertEqual(len(self.sbatch_calls()), 1)

    def test_inactive_previous_attempt_requires_explicit_resume(self):
        self.run_action()
        with self.assertRaisesRegex(RuntimeError, 'explicitly resume'):
            self.run_action()
        self.assertEqual(len(self.sbatch_calls()), 1)

    def test_resume_keeps_original_output_and_request(self):
        self.run_action()
        first = self.latest()
        self.sbatch = subprocess.CompletedProcess([], 0, '710002;cluster\n', '')
        self.run_action('resume', first['output'])
        second = self.latest()
        self.assertEqual(second['job_id'], '710002')
        self.assertEqual(second['previous_job_id'], '710001')
        self.assertEqual(second['output'], first['output'])
        self.assertEqual(second['request'], first['request'])
        self.assertTrue(second['resumed'])
        self.assertEqual(self.sbatch_calls()[-1][-1], first['output'])

    def test_resume_refuses_changed_inputs(self):
        self.run_action()
        self.request['input_sha256'] = '3' * 64
        with self.assertRaisesRegex(RuntimeError, 'inputs or protocol changed'):
            self.run_action('resume', self.latest()['output'])
        self.assertEqual(len(self.sbatch_calls()), 1)

    def test_request_checksum_tampering_blocks_resume(self):
        self.run_action()
        first = self.latest()
        digest = Path(first['request']).with_suffix('.json.sha256')
        digest.chmod(0o644)
        digest.write_text('0' * 64 + '\n')
        with self.assertRaisesRegex(RuntimeError, 'checksum changed'):
            self.run_action('resume', first['output'])
        self.assertEqual(len(self.sbatch_calls()), 1)

    def test_slurm_rejection_does_not_record_job(self):
        self.sbatch = subprocess.CompletedProcess([], 1, '', 'fixture rejection')
        with self.assertRaisesRegex(RuntimeError, 'Slurm rejected'):
            self.run_action()
        self.assertFalse((self.root / 'e14_context_benefit_latest.json').exists())
        attempts = list((self.root / 'e14_context_benefit_attempts').glob('*.json'))
        self.assertEqual(len(attempts), 1)
        self.assertEqual(self.launch.load(attempts[0])['state'], 'SUBMISSION_FAILED')

    def test_uncertain_sbatch_response_blocks_retry(self):
        self.sbatch = subprocess.CompletedProcess([], 0, 'unrecognized output\n', '')
        with self.assertRaisesRegex(RuntimeError, 'unexpected response'):
            self.run_action()
        with self.assertRaisesRegex(RuntimeError, 'unresolved'):
            self.run_action()
        self.assertEqual(len(self.sbatch_calls()), 1)

    def test_queue_failure_does_not_submit(self):
        def failed_queue(command, **kwargs):
            self.calls.append(command)
            self.assertEqual(command[0], 'squeue')
            return subprocess.CompletedProcess(command, 1, '', 'scheduler unavailable')
        self.fake_subprocess = failed_queue
        with self.assertRaisesRegex(RuntimeError, 'Cannot establish active jobs'):
            self.run_action()
        self.assertEqual(self.sbatch_calls(), [])

    def test_status_without_submission_is_clear(self):
        with self.assertRaisesRegex(RuntimeError, 'No context-benefit job'):
            self.run_action('status')
        self.assertEqual(self.calls, [])

    def test_batch_uses_new_runner_and_preserves_explicit_resume(self):
        script = (PACKAGE / 'batch.sh').read_text()
        self.assertIn('/run_benefit.py', script)
        self.assertIn('NRPS_BENEFIT_FLAGS=(--resume)', script)
        self.assertIn('e14_context_benefit_', script)
        self.assertIn('request.with_suffix', script)
        self.assertNotIn('MapClassifier', script)
        self.assertNotIn('selftest.py', script)
        self.assertNotIn('run_context.py', script)


if __name__ == '__main__':
    unittest.main(verbosity=2)
