#!/usr/bin/env python3
"""Verify the shipped package with standard-library-only dependencies."""
import ast
from pathlib import Path
from cb_common import verify_tree

root = Path(__file__).resolve().parent
verify_tree(root)
files = [line.split('  ', 1)[1] for line in (root / 'SHA256SUMS').read_text().splitlines()]
for rel in files:
    if rel.endswith('.py'):
        ast.parse((root / rel).read_text(), filename=rel)
print('CONTEXT_BENEFIT_BUNDLE_OK:', len(files), 'checksummed files; training_updates=0; classifier_fits=0')
