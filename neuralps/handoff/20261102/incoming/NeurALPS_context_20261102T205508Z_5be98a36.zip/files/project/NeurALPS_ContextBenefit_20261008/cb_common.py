"""Frozen inputs and immutable requests for the matched-context experiment."""
import gzip
import hashlib
import importlib
import json
from pathlib import Path
import sys

PACKAGE = Path(__file__).resolve().parent
VERSION = 'nrps_context_benefit_20261008_v1'
AUDIT_PACKAGE = 'NeurALPS_ContextAudit_20261007'
AUDIT_RUN = 'e12_context_audit_749149'
AUDIT_PACKAGE_SHA = 'c7ffbb9d4042f6cc286e71373020aba1b82f867b99e436066cf1fe0c25b52694'
AUDIT_MANIFEST_SHA = 'c4463cbde89eb64998cecc986c3c8eeb403d30dcee5f421185618247b00e05d7'
CHECKPOINT_SHA = '9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f'
REFERENCE_RUN = 'e8_reference_scale_652486'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode()).hexdigest()


def load(path):
    path = Path(path)
    with (gzip.open(path, 'rt') if path.suffix == '.gz' else path.open()) as f:
        return json.load(f)


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
    tmp.replace(path)


def dump_gz(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + '.tmp')
    # Fixed mtime and empty filename make identity-stable gzip bytes on resume.
    with tmp.open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as f:
            f.write(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())
    tmp.replace(path)


def emit(stage, **fields):
    print(json.dumps(dict(stage=stage, **fields), allow_nan=False), flush=True)


def verify_tree(path, expected=None):
    path = Path(path).resolve()
    manifest = path / 'SHA256SUMS'
    if expected:
        require(sha(manifest) == expected, 'Dependency manifest changed: ' + str(path))
    seen = set()
    for line in manifest.read_text().splitlines():
        digest, rel = line.split('  ', 1)
        f = (path / rel).resolve()
        require(path in f.parents and rel not in seen, 'Unsafe/duplicate checksum entry')
        seen.add(rel)
        require(f.is_file() and sha(f) == digest, 'Checksummed file changed: ' + str(f))
    require(seen, 'Empty package manifest')
    return sha(manifest)


def audit_source(root, old_request):
    folder = Path(root) / AUDIT_RUN
    require((folder / 'CONTEXT_AUDIT_COMPLETE').is_file(), 'Pinned context audit is incomplete')
    require(sha(folder / 'artifact_manifest.json') == AUDIT_MANIFEST_SHA,
            'Context-audit 749149 artifact manifest changed')
    manifest = load(folder / 'artifact_manifest.json')

    def checked(rel):
        path = (folder / rel).resolve()
        require(folder.resolve() in path.parents and rel in manifest, 'Unsealed audit path: ' + rel)
        require(sha(path) == manifest[rel], 'Audit artifact changed: ' + rel)
        return path

    identity = load(checked('identity.json'))
    require(identity['request'] == old_request, 'Inputs differ from completed context audit')
    seal = load(checked('pre_inference_seal.json'))
    require(seal['identity_sha256'] == canonical(identity), 'Audit identity seal mismatch')
    plans = load(checked('mask_plans.json.gz'))
    require(canonical(plans) == seal['plans_sha256'], 'Audit mask-plan seal mismatch')
    score_seal = load(checked('score_seal.json'))
    require(score_seal['activity_outcomes_used_for_predictions'] is False, 'Expected label-free source')
    return checked, identity, seal, score_seal, plans


def checked_reference(aid, record, checked, identity, seal):
    stem = hashlib.sha256(aid.encode()).hexdigest()
    meta = load(checked('shards/' + stem + '.json'))
    path = checked('shards/' + stem + '.json.gz')
    require(meta['assembly_id'] == aid and meta['identity_sha256'] == canonical(identity)
            and meta['plans_sha256'] == seal['plans_sha256']
            and meta['record_sha256'] == canonical(record) and meta['sha256'] == sha(path),
            'Audit assembly identity mismatch: ' + aid)
    return load(path)


def preflight(root):
    root = Path(root).resolve()
    package_sha = verify_tree(PACKAGE)
    dependency = root / AUDIT_PACKAGE
    verify_tree(dependency, AUDIT_PACKAGE_SHA)
    sys.path.insert(0, str(dependency))
    ca = importlib.import_module('ca_common')
    require(Path(ca.__file__).resolve().parent == dependency, 'Wrong legacy ca_common import')
    ctx, records, regions, old_request = ca.preflight(root)
    _, identity, seal, _, _ = audit_source(root, old_request)
    split_path = root / REFERENCE_RUN / 'split_manifest.json'
    require(split_path.is_file(), 'Expected original natural calibration/audit split: ' + str(split_path))
    split = load(split_path)
    require(split['production_counts_verified'] and not split['test_expected_counts_override']
            and split['usable_two_way_split'], 'Natural split is not the completed production split')
    request = dict(version=VERSION, root=str(root), package_sha256=package_sha,
                   protocol_sha256=sha(PACKAGE / 'PROTOCOL.json'),
                   source_audit_request=old_request,
                   source_audit_manifest_sha256=AUDIT_MANIFEST_SHA,
                   source_audit_identity_sha256=canonical(identity),
                   source_mask_plans_sha256=seal['plans_sha256'],
                   natural_split_sha256=sha(split_path), checkpoint_sha256=CHECKPOINT_SHA,
                   selected_step=26000, training_updates=0, activity_classifier_fits=0)
    emit('CONTEXT_BENEFIT_PREFLIGHT_OK', assemblies=len(records), regions=len(regions),
         natural_internal_test=split['expected_counts']['natural_internal_test'],
         selected_step=26000, training_updates=0, activity_classifier_fits=0)
    return ctx, records, regions, request


def state_sha(model):
    h = hashlib.sha256()
    for name, tensor in sorted(model.state_dict().items()):
        h.update(name.encode())
        h.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()
