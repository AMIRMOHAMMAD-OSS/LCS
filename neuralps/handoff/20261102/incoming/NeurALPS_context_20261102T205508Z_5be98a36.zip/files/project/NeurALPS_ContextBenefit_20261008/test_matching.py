"""Synthetic standard-library checks of matching, exclusion, and selection rules."""
import copy
import hashlib
import random
import unittest

from matching import Matcher, build_candidate_index, natural_audit_queries, query_descriptor


def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


def protein(seed, n):
    rng = random.Random(seed)
    return ''.join(rng.choice('ACDEFGHIKLMNPQRSTVWY') for _ in range(n))


def record(aid, dataset='natural', *, n=9, chain=1):
    route, slots, sequences = [], [], []
    start = 0
    for j in range(n):
        kind = j % 2
        dtype = 1 if kind == 0 else 0
        route.append(dict(kind=kind, domain_type=dtype, chain=chain))
        sequence = protein(aid + '|' + str(j), 64)
        sequences.append(sequence)
        slots.append(dict(object_index=j, slot=0, kind=kind, state='OBSERVED',
                          group='D:1' if kind == 0 else 'C:1:1',
                          sequence_hash=digest(sequence), length=len(sequence),
                          start=start, end=start + len(sequence)))
        start += len(sequence)
    sequence = ''.join(sequences)
    key = digest(sequence)
    for slot in slots:
        slot['parent_sequence_hash'] = key
    result = dict(assembly_id=aid, dataset=dataset, route=route, model_slots=slots,
                  parent_sequence_hashes={'chain': key}, parent_lengths={'chain': len(sequence)})
    return result, {key: sequence}


def closure(rec, primary, parent, extraction):
    return dict(hidden=sorted(set(map(tuple, primary)) | set(map(tuple, rec.get('extra_hidden', [])))))


def plan(rec, targets, parent, closure_fn):
    primary = [(s['object_index'], s['slot']) for s in rec['model_slots']
               if s['object_index'] in targets]
    hidden = closure_fn(rec, primary, parent, 'independent_sequence')['hidden']
    unavailable = any(s['state'] != 'OBSERVED' for s in rec['model_slots']
                      if s['object_index'] in targets)
    return dict(status='MISSING_SEQUENCE_FEATURE' if unavailable else 'READY',
                targets=targets, primary=primary, hidden=hidden, own_hidden=hidden,
                masked_fraction=len(hidden)/len(rec['model_slots']), remaining_context_min=3)


class MatchingTests(unittest.TestCase):
    def setUp(self):
        self.parents = {}
        self.source, pp = record('engineered', 'bode1')
        self.parents.update(pp)
        self.records, self.meta = {}, {}
        for j in range(24):
            aid = 'natural' + str(j)
            rec, pp = record(aid)
            self.records[aid] = rec
            self.parents.update(pp)
            self.meta[aid] = dict(role='calibration', component_id='component' + str(j))
        self.source_plan = plan(self.source, [3, 4, 5], self.parents.__getitem__, closure)

    def matcher(self):
        return Matcher(self.records, self.meta, self.parents.__getitem__, closure, plan)

    def test_success_deterministic_capped_components(self):
        result = self.matcher().match_query(self.source, self.source_plan)
        self.assertEqual(result['status'], 'MATCHED')
        self.assertEqual(len(result['candidates']), 16)
        self.assertEqual(len({r['component_id'] for r in result['candidates']}), 16)
        reversed_records = dict(reversed(list(self.records.items())))
        other = Matcher(reversed_records, self.meta, self.parents.__getitem__, closure, plan)
        self.assertEqual(result, other.match_query(self.source, self.source_plan))

    def test_order_does_not_use_query_id_name_label_or_score(self):
        before = self.matcher().match_query(self.source, self.source_plan)
        source = copy.deepcopy(self.source)
        source.update(assembly_id='new_name', name='different', label=1,
                      observed_activity=0, compatibility=999.0)
        after = self.matcher().match_query(source, self.source_plan)
        self.assertEqual(before, after)

    def test_canonical_chain_numbers_do_not_change_matching(self):
        before = self.matcher().match_query(self.source, self.source_plan)
        for rec in self.records.values():
            for obj in rec['route']:
                obj['chain'] = 999
        after = self.matcher().match_query(self.source, self.source_plan)
        self.assertEqual(before['descriptor'], after['descriptor'])
        self.assertEqual([(c['assembly_id'], c['offset']) for c in before['candidates']],
                         [(c['assembly_id'], c['offset']) for c in after['candidates']])
        self.assertNotEqual(before['candidates'][0]['visible_identity_sha256'],
                            after['candidates'][0]['visible_identity_sha256'])

    def test_exact_mask_geometry_not_only_hidden_count(self):
        for rec in self.records.values():
            rec['extra_hidden'] = [(0, 0)]
        self.source['extra_hidden'] = [(8, 0)]
        source_plan = plan(self.source, [3, 4, 5], self.parents.__getitem__, closure)
        result = self.matcher().match_query(self.source, source_plan)
        self.assertEqual(result['status'], 'INSUFFICIENT_MATCHED_CONTEXTS')
        self.assertFalse(result['candidates'])
        self.assertGreater(result['counts']['MASK_CLOSURE_MISMATCH'], 0)

    def test_source_unavailable_not_rescued(self):
        pp = dict(self.source_plan, status='INSUFFICIENT_VISIBLE_CONTEXT')
        result = self.matcher().match_query(self.source, pp)
        self.assertEqual(result['status'], 'SOURCE_NOT_READY')
        self.assertEqual(result['source_status'], 'INSUFFICIENT_VISIBLE_CONTEXT')

    def test_no_minimum_relaxation(self):
        self.records = dict(list(self.records.items())[:7])
        result = self.matcher().match_query(self.source, self.source_plan)
        self.assertEqual(len(result['candidates']), 7)
        self.assertEqual(result['status'], 'INSUFFICIENT_MATCHED_CONTEXTS')

    def test_one_window_per_component(self):
        for aid in self.meta:
            self.meta[aid]['component_id'] = 'single'
        result = self.matcher().match_query(self.source, self.source_plan)
        self.assertEqual(len(result['candidates']), 1)
        self.assertEqual(result['status'], 'INSUFFICIENT_MATCHED_CONTEXTS')

    def test_only_calibration_contexts(self):
        for aid in list(self.meta)[:20]:
            self.meta[aid]['role'] = 'audit'
        result = self.matcher().match_query(self.source, self.source_plan)
        self.assertEqual(len(result['candidates']), 4)

    def test_same_audit_component_excluded(self):
        self.source['dataset'] = 'natural'
        self.meta['engineered'] = dict(role='audit', component_id='component0')
        result = self.matcher().match_query(self.source, self.source_plan, max_candidates=32)
        self.assertNotIn('component0', {c['component_id'] for c in result['candidates']})
        self.assertGreater(result['counts'].get('SAME_NATURAL_COMPONENT', 0), 0)

    def test_group_type_length_flank_and_chain_strict(self):
        mutations = [
            lambda rec: rec['model_slots'][4].update(group='D:2'),
            lambda rec: rec['route'][4].update(domain_type=2),
            lambda rec: rec['model_slots'][4].update(length=128),
            lambda rec: rec['route'][2].update(domain_type=2),
            lambda rec: rec['route'][4].update(chain=2),
        ]
        for mutation in mutations:
            with self.subTest(mutation=mutation):
                rr = copy.deepcopy(self.records)
                for rec in rr.values():
                    mutation(rec)
                matcher = Matcher(rr, self.meta, self.parents.__getitem__, closure, plan)
                result = matcher.match_query(self.source, self.source_plan)
                # The alternate [1,2,3] or [5,6,7] window must also match all
                # target and immediate-flank chain/type constraints. At least
                # one mutation can leave an alternate window legitimately valid;
                # inspect specifically the originally matching offset=0.
                self.assertTrue(all(c['offset'] != 0 for c in result['candidates']))

    def test_exact_target_substring_anywhere_in_parent_is_rejected(self):
        source_slot = self.source['model_slots'][4]
        source_parent = self.parents[source_slot['parent_sequence_hash']]
        target = source_parent[source_slot['start']:source_slot['end']]
        for rec in self.records.values():
            old = rec['parent_sequence_hashes']['chain']
            joined = self.parents[old] + target
            new = digest(joined)
            self.parents[new] = joined
            rec['parent_sequence_hashes']['chain'] = new
            rec['parent_lengths']['chain'] = len(joined)
            for slot in rec['model_slots']:
                slot['parent_sequence_hash'] = new
        result = self.matcher().match_query(self.source, self.source_plan)
        self.assertFalse(result['candidates'])
        self.assertGreater(result['counts']['TARGET_SEQUENCE_SUBSTRING_IN_DONOR_PARENT'], 0)

    def test_exact_shared_target_hash_and_shared_parent_exclusions(self):
        for rec in self.records.values():
            rec['model_slots'][0]['sequence_hash'] = self.source['model_slots'][4]['sequence_hash']
        result = self.matcher().match_query(self.source, self.source_plan)
        self.assertFalse(result['candidates'])
        self.assertGreater(result['counts']['SHARED_TARGET_FEATURE'], 0)
        for rec in self.records.values():
            rec['parent_sequence_hashes']['extra'] = next(iter(self.source['parent_sequence_hashes'].values()))
        result = self.matcher().match_query(self.source, self.source_plan)
        self.assertFalse(result['candidates'])
        self.assertGreater(result['counts']['SHARED_PARENT_SEQUENCE'], 0)

    def test_source_identical_visible_context_is_rejected(self):
        self.source['route'][4]['domain_type'] = 2
        self.source['model_slots'][4]['group'] = 'D:2'
        donor = copy.deepcopy(self.source)
        donor.update(assembly_id='context-copy', dataset='natural')
        original_parent = self.parents[next(iter(donor['parent_sequence_hashes'].values()))]
        sequence = ''.join(protein('replacement|' + str(j), 64) if j in [3, 4, 5]
                           else original_parent[j*64:(j+1)*64] for j in range(9))
        key = digest(sequence)
        self.parents[key] = sequence
        donor['parent_sequence_hashes'] = {'chain': key}
        for slot in donor['model_slots']:
            slot['parent_sequence_hash'] = key
            slot['sequence_hash'] = digest(sequence[slot['start']:slot['end']])
        self.records = {'context-copy': donor}
        self.meta = {'context-copy': dict(role='calibration', component_id='independent')}
        result = self.matcher().match_query(self.source, self.source_plan)
        # Other shifted windows can be structurally valid but are different
        # visible inputs; the exact source-visible offset must be rejected.
        self.assertTrue(all(c['offset'] != 0 for c in result['candidates']))
        self.assertGreater(result['counts'].get('SOURCE_IDENTICAL_VISIBLE_CONTEXT', 0), 0)

    def test_duplicate_visible_control_context_is_rejected(self):
        template = self.records['natural0']
        self.records = {aid: dict(copy.deepcopy(template), assembly_id=aid) for aid in self.records}
        result = self.matcher().match_query(self.source, self.source_plan, max_candidates=32)
        # Three window placements are possible in this synthetic repeated route.
        signatures = [c['visible_identity_sha256'] for c in result['candidates']]
        self.assertEqual(len(signatures), len(set(signatures)))
        self.assertLessEqual(len(signatures), 3)
        self.assertGreater(result['counts'].get('DUPLICATE_SELECTED_VISIBLE_CONTEXT', 0), 0)

    def test_missing_group_is_an_error(self):
        del self.source['model_slots'][4]['group']
        with self.assertRaisesRegex(ValueError, 'training group missing'):
            self.matcher().match_query(self.source, self.source_plan)

    def test_relative_closure_and_offset_mapping(self):
        pp = plan(self.source, [1, 2, 3], self.parents.__getitem__, closure)
        result = self.matcher().match_query(self.source, pp)
        for candidate in result['candidates']:
            offset = candidate['offset']
            self.assertEqual(candidate['plan']['targets'], [j + offset for j in pp['targets']])
            self.assertEqual(sorted([j - offset, role] for j, role in candidate['plan']['hidden']),
                             sorted([j, role] for j, role in pp['hidden']))

    def test_two_role_break_slots_and_orientation_preserved(self):
        def turn_into_break(rec):
            rec['route'][3].update(kind=2, chain=-1)
            for obj in rec['route'][4:]:
                obj['chain'] = 2
            old = next(s for s in rec['model_slots'] if s['object_index'] == 3)
            sequence = self.parents[old['parent_sequence_hash']]
            new = []
            for role, a, b in [(1, old['start'], old['start'] + 32),
                               (2, old['start'] + 32, old['end'])]:
                value = dict(old, kind=2, slot=role, start=a, end=b, length=b-a,
                             group='T:' + str(role), sequence_hash=digest(sequence[a:b]))
                new.append(value)
            rec['model_slots'] = [s for s in rec['model_slots'] if s['object_index'] != 3] + new
        turn_into_break(self.source)
        for rec in self.records.values():
            turn_into_break(rec)
        pp = plan(self.source, [3], self.parents.__getitem__, closure)
        result = self.matcher().match_query(self.source, pp)
        self.assertEqual(result['status'], 'MATCHED')
        for candidate in result['candidates']:
            self.assertEqual(sorted(candidate['plan']['primary']), [(3, 1), (3, 2)])
        for rec in self.records.values():
            for slot in rec['model_slots']:
                if slot['object_index'] == 3:
                    slot['group'] = 'T:' + str(3 - slot['slot'])
        rejected = self.matcher().match_query(self.source, pp)
        self.assertFalse(rejected['candidates'])

    def test_route_terminal_status_required(self):
        pp = plan(self.source, [0, 1, 2], self.parents.__getitem__, closure)
        result = self.matcher().match_query(self.source, pp)
        self.assertTrue(result['candidates'])
        self.assertTrue(all(c['window_start'] == 0 for c in result['candidates']))

    def test_unknown_counts_or_disjoint_target_are_errors(self):
        with self.assertRaises(ValueError):
            self.matcher().match_query(self.source, self.source_plan, min_candidates=17, max_candidates=16)
        with self.assertRaises(ValueError):
            query_descriptor(self.source, dict(self.source_plan, targets=[1, 3]))

    def test_audit_selection_is_before_feature_eligibility(self):
        for aid in self.meta:
            self.meta[aid]['role'] = 'audit'
        queries = natural_audit_queries(self.records, self.meta, max_components=4)
        self.assertEqual(len(queries), 8)
        self.assertEqual(len({q['component_id'] for q in queries}), 4)
        changed = copy.deepcopy(self.records)
        for rec in changed.values():
            rec['observed_activity'] = 1
            for slot in rec['model_slots']:
                slot['state'] = 'MISSING'
                slot['sequence_hash'] = None
        self.assertEqual(queries, natural_audit_queries(changed, self.meta, max_components=4))
        for q in queries:
            if q['query_kind'] == 'domain_flanks':
                self.assertIn(q['target_object_index'], q['targets'])
                self.assertTrue(len(q['targets']) in (2, 3))
            else:
                self.assertEqual(q['targets'], [q['target_object_index']])

    def test_audit_missing_object_kind_is_not_resampled(self):
        rec, pp = record('one-domain', n=1)
        metadata = {'one-domain': dict(role='audit', component_id='only')}
        queries = natural_audit_queries({'one-domain': rec}, metadata)
        self.assertEqual(queries[1]['status'], 'NO_PHYSICAL_OBJECT_OF_KIND')
        self.assertEqual(queries[1]['targets'], [])

    def test_cache_does_not_mutate_source_records(self):
        original = copy.deepcopy(self.records)
        matcher = self.matcher()
        first = matcher.match_query(self.source, self.source_plan)
        self.assertEqual(first, matcher.match_query(self.source, self.source_plan))
        self.assertEqual(original, self.records)
        self.assertTrue(matcher.plan_cache)
        self.assertTrue(matcher.index.structural_cache)


if __name__ == '__main__':
    unittest.main()
