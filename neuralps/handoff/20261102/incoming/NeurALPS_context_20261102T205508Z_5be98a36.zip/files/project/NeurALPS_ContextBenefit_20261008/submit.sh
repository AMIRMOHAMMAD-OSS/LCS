#!/usr/bin/env bash
set -euo pipefail
NRPS_BENEFIT_PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [ "$#" -eq 0 ]; then
    set -- run
fi
exec python3 -B "$NRPS_BENEFIT_PACKAGE/launch.py" "$@"
