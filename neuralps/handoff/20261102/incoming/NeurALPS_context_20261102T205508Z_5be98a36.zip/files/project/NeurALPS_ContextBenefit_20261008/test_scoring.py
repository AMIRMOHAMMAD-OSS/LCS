#!/usr/bin/env python3
"""Synthetic CPU tests with the ORIGINAL encoder, masking and SSL loss.

No real checkpoint or production vectors are loaded. --source-root points to
the directory containing NeurALPS_Assembly_v1_20261002 and ContextAudit packages.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import sys
import unittest

import numpy as np
import torch

DIM = 8


def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


class BaseStore:
    def __init__(self):
        self.parents, self.vectors = {}, {}

    def parent(self, key):
        return self.parents[key]

    def vector(self, key):
        return self.vectors[key].copy()

    def register(self, sequence):
        key = digest(sequence)
        self.parents[key] = sequence
        rng = np.random.default_rng(int(key[:16], 16))
        self.vectors[key] = rng.normal(size=DIM).astype(np.float32)
        return key


class NamespacedStore:
    def __init__(self):
        self.base = BaseStore()
        self.tdomain = {}
        self.dataset = None
        self.selections = []

    def select_dataset(self, dataset):
        assert dataset in ("bode1", "bode2", "tdomain")
        self.dataset = dataset
        self.selections.append(dataset)

    def vector(self, key):
        assert self.dataset is not None
        if self.dataset == "tdomain":
            return self.tdomain[key].copy()
        return self.base.vector(key)

    def parent(self, key):
        return self.base.parent(key)


class TrainingMeans:
    def mean(self, slot):
        rng = np.random.default_rng(int(digest(slot["group"])[:16], 16))
        return (rng.normal(size=DIM) * .2).astype(np.float32)


def make_record(store, aid, seed, dataset="natural"):
    rng = np.random.default_rng(seed)
    alphabet = np.array(list("ACDEFGHIKLMNPQRSTVWY"))
    proteins = ["".join(rng.choice(alphabet, size=n)) for n in (80, 100)]
    parent_hashes = {"p" + str(i): store.base.register(seq) for i, seq in enumerate(proteins)}
    route, slots = [], []
    for j in range(17):
        kind = 2 if j == 7 else j % 2
        chain = 0 if j < 7 else 1
        route.append(dict(kind=kind, domain_type=1 if kind == 0 else 0, chain=chain))
        if kind == 0:
            local = j // 2 if chain == 0 else j // 2 - 4
            regions = [(0, chain, local * 20, (local + 1) * 20, "D:1")]
        elif kind == 1:
            midpoint = (j // 2 + 1) * 20 if chain == 0 else (j // 2 - 3) * 20
            regions = [(0, chain, midpoint - 3, midpoint + 3, "C:1:1")]
        else:
            regions = [(1, 0, 70, 80, "L:1:1"), (2, 1, 0, 10, "R:1:1")]
        for role, p, start, end, group in regions:
            seq = proteins[p][start:end]
            seqhash = store.base.register(seq)
            store.tdomain[seqhash] = store.base.vector(seqhash) + np.arange(DIM, dtype=np.float32) * .2
            slots.append(dict(object_index=j, slot=role, kind=kind, state="OBSERVED",
                              sequence_hash=seqhash, parent_sequence_hash=parent_hashes["p" + str(p)],
                              protein_uid="p" + str(p), start=start, end=end, length=end-start, group=group))
    return dict(assembly_id=aid, dataset=dataset, split="synthetic_only",
                route=route, model_slots=slots, parent_sequence_hashes=parent_hashes,
                parent_lengths={"p0": 80, "p1": 100},
                boundary_window_policy="physical_end_extradomain_tail64_v1")


class ScoringTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(73)
        self.model = AssemblyEncoder(Config(feature_dim=DIM, width=16, heads=4,
                                           local_layers=4, global_layers=2, dropout=0)).eval()
        with torch.no_grad():
            for block in self.model.global_blocks:
                block.write.out_proj.weight.normal_(0, .03)
                block.h_ff[3].weight.normal_(0, .03)
        for p in self.model.parameters():
            p.requires_grad_(False)
        self.store = NamespacedStore()
        self.source = make_record(self.store, "source", 12, "bode1")
        self.natural = {"n" + str(i): make_record(self.store, "n" + str(i), i + 91)
                        for i in range(8)}
        self.runtime = SimpleNamespace(model=self.model, store=self.store,
            targets=TrainingMeans(), ssl=ssl, device="cpu", closure=masking_closure,
            collate=lambda rr, lookup: collate_records(rr, lookup, feature_dim=DIM))
        self.cache = {}

    def plan(self, record, targets):
        return make_plan(record, targets, self.store.parent, masking_closure)

    def matched(self, targets=(8,), count=8):
        return dict(status="MATCHED", candidates=[dict(assembly_id=aid, component_id="c_" + aid,
            offset=0, plan=self.plan(rec, list(targets)))
            for aid, rec in list(self.natural.items())[:count]])

    def score(self, targets=(8,), count=8, source=None):
        source = source or self.source
        return score_query(self.runtime, source, self.plan(source, list(targets)),
                           self.matched(targets, count), self.natural, self.cache)

    def manual_loss(self, source, source_j, context, context_j, plan, mode):
        lookup = feature_lookup(self.runtime, source)
        ss = slots_by_object(source)[source_j]
        target = torch.tensor(np.stack([lookup(s["sequence_hash"]) for s in ss]))
        mean = torch.tensor(np.stack([self.runtime.targets.mean(s) for s in ss]))
        batch = masked_batch(context, plan, self.runtime.collate, feature_lookup(self.runtime, context))
        with torch.inference_mode():
            pred = predict_mode(self.model, batch, local=(mode == "local"))[0, context_j,
                                                                         [s["slot"] for s in ss]]
            loss, _ = ssl.slot_loss(pred, target, mean)
        return float(loss.mean()), pred, target, mean

    def test_same_source_piece_and_mean_across_contexts(self):
        result = self.score()
        self.assertEqual(result["status"], "SCORED")
        for mode in ("full", "local"):
            row = result["objects"]["8"][mode]
            losses = []
            for aid, rec in self.natural.items():
                loss, _, _, _ = self.manual_loss(self.source, 8, rec, 8, self.plan(rec, [8]), mode)
                losses.append(loss)
            np.testing.assert_allclose(row["alternative_errors"], losses, rtol=0, atol=0)
            self.assertEqual(row["context_benefit"], float(np.median(losses)) - row["original_error"])
            first = self.natural["n0"]
            wrong, _, _, _ = self.manual_loss(first, 8, first, 8, self.plan(first, [8]), mode)
            self.assertGreater(abs(losses[0] - wrong), 1e-5)

    def test_identical_context_zero_and_duplicate_exclusion(self):
        identical = copy.deepcopy(self.source)
        identical.update(assembly_id="identity", dataset="natural")
        for mode in ("full", "local"):
            own = self.manual_loss(self.source, 8, self.source, 8, self.plan(self.source, [8]), mode)[0]
            alternate = self.manual_loss(self.source, 8, identical, 8, self.plan(identical, [8]), mode)[0]
            self.assertEqual(alternate - own, 0.)
        candidates = dict(candidates=[dict(assembly_id="identity", component_id="identity", offset=0,
                                          plan=self.plan(identical, [8]))])
        with self.assertRaisesRegex(ValueError, "duplicates the source"):
            score_query(self.runtime, self.source, self.plan(self.source, [8]), candidates,
                        {"identity": identical}, {})

    def test_protein_break_averages_losses_not_vectors(self):
        result = self.score(targets=(7,))
        self.assertEqual(result["objects"]["7"]["roles"], [1, 2])
        wrong_different = False
        for mode in ("full", "local"):
            for i, rec in enumerate(self.natural.values()):
                expected, pred, target, mean = self.manual_loss(self.source, 7, rec, 7,
                                                               self.plan(rec, [7]), mode)
                self.assertEqual(result["objects"]["7"][mode]["alternative_errors"][i], expected)
                wrong = float(ssl.slot_loss(pred.mean(0), target.mean(0), mean.mean(0))[0])
                wrong_different |= abs(expected - wrong) > 1e-5
        self.assertTrue(wrong_different)

    def test_masked_value_poisoning_and_signature(self):
        plan = self.plan(self.source, [8])
        lookup = feature_lookup(self.runtime, self.source)
        batch = masked_batch(self.source, plan, self.runtime.collate, lookup)
        poisoned = {k: v.clone() for k, v in batch.items()}
        poisoned["x"][poisoned["state"] == 4] = 1e20
        self.assertEqual(tensor_signature(batch), tensor_signature(poisoned))
        with torch.inference_mode():
            for mode in (False, True):
                torch.testing.assert_close(predict_mode(self.model, batch, mode),
                                           predict_mode(self.model, poisoned, mode), rtol=0, atol=0)

    def test_explicit_namespace_and_natural_source(self):
        target = copy.deepcopy(self.source)
        target.update(assembly_id="tdomain", dataset="tdomain")
        tdomain = self.score(source=target)
        bode = self.score()
        self.assertGreater(abs(tdomain["objects"]["8"]["full"]["original_error"] -
                               bode["objects"]["8"]["full"]["original_error"]), 1e-5)
        self.assertNotIn("natural", self.store.selections)
        self.assertEqual(self.store.dataset, "bode1")
        natural_source = make_record(self.store, "natural_source", 671, "natural")
        self.assertEqual(self.score(source=natural_source)["status"], "SCORED")

    def test_insufficient_matches_retains_original_and_null_benefit(self):
        for count in (0, 7):
            result = self.score(count=count)
            self.assertEqual(result["status"], "INSUFFICIENT_MATCHED_CONTEXTS")
            row = result["objects"]["8"]["full"]
            self.assertIsInstance(row["original_error"], float)
            self.assertIsNone(row["context_benefit"])
            self.assertEqual(len(row["alternative_errors"]), count)
            self.assertEqual(row["median_alternative_error"] is None, count == 0)

    def test_deterministic_replay_cache_and_no_gradients(self):
        before = {name: value.detach().clone() for name, value in self.model.state_dict().items()}
        a = self.score(targets=(7, 8, 9))
        self.assertEqual(len(self.cache), 9)
        def fail(*args, **kwargs):
            raise AssertionError("Inference was rerun despite complete prediction cache")
        original_features = self.model.features
        self.model.features = fail
        b = self.score(targets=(7, 8, 9))
        self.model.features = original_features
        self.assertEqual(a, b)
        for saved in self.cache.values():
            for prediction in saved["predictions"].values():
                self.assertEqual(set(prediction), {7, 8, 9})
                for row in prediction.values():
                    self.assertEqual(row.shape, (3, DIM))
                    self.assertFalse(row.flags.writeable)
        for name, value in self.model.state_dict().items():
            torch.testing.assert_close(value, before[name], rtol=0, atol=0)
        self.assertTrue(all(p.grad is None and not p.requires_grad for p in self.model.parameters()))

    def test_direct_original_plan_replay(self):
        result = self.score()
        for mode in ("full", "local"):
            expected = self.manual_loss(self.source, 8, self.source, 8,
                                        self.plan(self.source, [8]), mode)[0]
            self.assertEqual(result["objects"]["8"][mode]["original_error"], expected)
        json.dumps(result, allow_nan=False)

    def test_translated_target_index_and_label_independence(self):
        matched = dict(status="MATCHED", candidates=[dict(assembly_id=aid,
            component_id="c_" + aid, offset=2, plan=self.plan(rec, [10]))
            for aid, rec in self.natural.items()])
        plan = self.plan(self.source, [8])
        result = score_query(self.runtime, self.source, plan, matched, self.natural, self.cache)
        for mode in ("full", "local"):
            expected = [self.manual_loss(self.source, 8, rec, 10, self.plan(rec, [10]), mode)[0]
                        for rec in self.natural.values()]
            self.assertEqual(result["objects"]["8"][mode]["alternative_errors"], expected)
        label_changed = copy.deepcopy(self.source)
        label_changed.update(label=1, activity="ACTIVE", donor_name="arbitrary")
        replay = score_query(self.runtime, label_changed, plan, matched, self.natural, self.cache)
        self.assertEqual(result, replay)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=Path(__file__).resolve().parent.parent)
    args, rest = parser.parse_known_args()
    root = args.source_root.resolve()
    sys.path.insert(0, str(root / "NeurALPS_ContextAudit_20261007"))
    sys.path.insert(0, str(root / "NeurALPS_Assembly_v1_20261002" / "src"))
    from assembly_model import AssemblyEncoder, Config, collate_records
    from masking_contract import masking_closure
    from context_plans import make_plan, masked_batch, slots_by_object, tensor_signature
    from frozen_scoring import predict_mode
    spec = importlib.util.spec_from_file_location("context_benefit_original_ssl",
             root / "NeurALPS_Assembly_v1_20261002" / "run_ssl.py")
    ssl = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = ssl
    spec.loader.exec_module(ssl)
    from scoring import feature_lookup, score_query
    torch.set_num_threads(1)
    unittest.main(argv=[sys.argv[0]] + rest)
