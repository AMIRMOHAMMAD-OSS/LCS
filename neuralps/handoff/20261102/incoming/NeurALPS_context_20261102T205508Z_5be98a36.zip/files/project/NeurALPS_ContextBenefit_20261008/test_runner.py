"""Pure runner-contract tests; no model is loaded and no inference is run."""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

from cb_common import load, sha
from run_benefit import aggregate_object_scores, immutable_json, verify_old_query, PredictionCache


def example():
    region = {"domain_indices": [0, 2], "boundary_indices": [1]}
    scores = {"objects": {str(j): {mode: {"original_error": error, "context_benefit": benefit}
               for mode in ("full", "local")} for j, error, benefit in ((0, .2, .3), (2, .6, -.1), (1, .9, .5))}}
    return region, scores


class RunnerContractTests(unittest.TestCase):
    def test_domain_boundary_balanced_mean_is_not_object_mean(self):
        region, scored = example()
        result = aggregate_object_scores(scored, region)
        self.assertAlmostEqual(result["raw_full"]["domains"], .6)
        self.assertAlmostEqual(result["raw_full"]["boundaries"], .1)
        self.assertAlmostEqual(result["raw_full"]["balanced"], .35)
        self.assertAlmostEqual(result["raw_full"]["neighborhood_mean"], 1.3 / 3)
        self.assertAlmostEqual(result["benefit_full"]["domains"], .1)
        self.assertAlmostEqual(result["benefit_full"]["balanced"], .3)

    def test_unsupported_piece_does_not_shrink_the_region(self):
        region, scored = example()
        scored["objects"]["0"]["full"]["context_benefit"] = None
        result = aggregate_object_scores(scored, region)
        self.assertIsNone(result["benefit_full"]["domains"])
        self.assertIsNone(result["benefit_full"]["balanced"])
        self.assertIsNone(result["benefit_full"]["neighborhood_mean"])
        self.assertEqual(result["benefit_full"]["boundaries"], .5)
        self.assertAlmostEqual(result["benefit_local"]["balanced"], .3)
        self.assertAlmostEqual(result["raw_full"]["balanced"], .35)
        del scored["objects"]["2"]
        result = aggregate_object_scores(scored, region)
        self.assertIsNone(result["raw_full"]["balanced"])

    def test_old_query_parity_enforced(self):
        reference = {"status": "SCORED", "context_signature": "fixed", "objects": {"0": {"full": .8, "local": .7}}}
        scored = {"source_input_signature": "fixed", "objects": {"0": {"full": {"original_error": .2}, "local": {"original_error": .3}}}}
        result = verify_old_query(scored, reference, {"status": "READY"})
        self.assertEqual(result["comparisons"], 2)
        self.assertLess(result["maximum_absolute_difference"], 1e-15)
        changed = deepcopy(scored)
        changed["objects"]["0"]["full"]["original_error"] += .001
        with self.assertRaisesRegex(RuntimeError, "replay differs"):
            verify_old_query(changed, reference, {"status": "READY"})
        changed = deepcopy(scored)
        changed["source_input_signature"] = "changed"
        with self.assertRaisesRegex(RuntimeError, "tensors changed"):
            verify_old_query(changed, reference, {"status": "READY"})

    def test_unsupported_original_query_cannot_have_scores(self):
        reference = {"status": "INSUFFICIENT_VISIBLE_CONTEXT", "objects": {}}
        plan = {"status": "INSUFFICIENT_VISIBLE_CONTEXT"}
        result = verify_old_query({"objects": {}}, reference, plan)
        self.assertEqual(result["comparisons"], 0)
        with self.assertRaisesRegex(RuntimeError, "Unsupported query has scores"):
            verify_old_query({"objects": {"0": {}}}, reference, plan)

    def test_immutable_gzip_bytes_and_resume_payload(self):
        with tempfile.TemporaryDirectory() as tmp:
            a, b = Path(tmp) / "a.json.gz", Path(tmp) / "b.json.gz"
            payload = {"b": [1, None, -.4], "a": "record"}
            immutable_json(a, payload, compressed=True)
            immutable_json(b, payload, compressed=True)
            original_bytes = a.read_bytes()
            self.assertEqual(sha(a), sha(b))
            self.assertEqual(load(a), payload)
            immutable_json(a, {"a": "record", "b": [1, None, -.4]}, compressed=True)
            self.assertEqual(a.read_bytes(), original_bytes)
            with self.assertRaisesRegex(RuntimeError, "Resume input differs"):
                immutable_json(a, {"a": "different"}, compressed=True)
            self.assertEqual(a.read_bytes(), original_bytes)

    def test_prediction_cache_eviction_preserves_values(self):
        cache = PredictionCache(limit=2)
        cache["a"], cache["b"] = "A", "B"
        self.assertEqual(cache["a"], "A")
        cache["c"] = "C"
        self.assertEqual(set(cache), {"a", "c"})
        self.assertEqual(cache["a"], "A")


if __name__ == "__main__":
    unittest.main(verbosity=2)
