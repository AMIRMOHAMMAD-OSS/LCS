NeurALPS: same-piece context benefit, 2026-10-08
================================================

This job tests the frozen compatibility model itself. It fits no classifier,
does not fine-tune ESMC or NeurALPS, and does not generate new ESMC embeddings.
The production GPU experiment has NOT been run by the assistant. The original
checkpoint and full natural cache are on Jean Zay. See VALIDATION.json for the
local synthetic, structural and previous-score replay checks actually run.

What it computes
----------------
For a domain or boundary in a declared exchanged region:

  benefit = median(error in matched alternative natural contexts)
            - error in its original context

Every error uses the SAME original piece embedding and original training mean.
The alternative natural piece is not the scoring target. No sequence is
physically spliced: both the original and natural counterpart positions are
masked, and the reconstructed natural-context vectors are compared with the
original piece. Full-context is primary; global-path-disabled local is secondary.

Positive means the actual context helps reconstruction relative to the sampled
matched controls. Zero means no median advantage. Negative means the controls
reconstruct the piece better. None is an activity threshold or probability.
This is a new score; the previous natural-reference percentiles do not scale it.
Alternative contexts are not experimentally established inactive assemblies.

Frozen controls and missing scores
----------------------------------
Engineered queries preserve the exact JOINT region masks from context audit
749149. The job replays both full/local original scores against sealed outputs
to tolerance 5e-5 before evaluating activity. Single-object results from an older
masking experiment are not silently substituted.

Natural calibration components supply controls. The original reference-scale
calibration/audit split is rebuilt from the full immutable database and must
match the completed split exactly. Up to256 natural audit components supply
queries chosen by hash before checking eligibility or model scores.

Matching requires the same typed target pattern, slot roles/groups, chain/break
pattern, route-end status, outside flank types, feature/route length bins, and
exact translated physical masking closure. Target sequence leakage, shared
parents and identical visible contexts are excluded. It selects up to 16
independent natural components and requires at least 8. Unsupported queries
retain their raw scores but get null benefit; there is no relaxed fallback.
Strict matching can leave substantial gaps. Coverage is a result of this test.

Exact identity exclusions do not establish homology-family independence.
Boundaries contain neighboring residues, so their scores are not isolated
linker-function measurements. This tests contextual reconstruction, not causal
identification of a faulty biological part.

Evaluation and outputs
----------------------
Prediction bytes are sealed before the new evaluator opens activity labels.
The inherited source validator may check old BODE1 labels for integrity only;
they never enter context selection or prediction. Already examined datasets
remain retrospective development data, not fresh confirmation.

* BODE1: matched-background macro AUROC plus the familiar mean 21 donor-panel
  AUROC. The assembly score averages ALL three region scores; all must exist.
  Mean fold AUROC is not the AUROC of one averaged prediction per assembly.
* BODE2: 105 engineered constructs, pooled and by replacement position.
* T-domain: 65 reviewed minimal-scaffold constructs, target-PCP primary;
  target-plus-flanks, design-round and 63-sample sensitivity are secondary.
* Native controls and 19 T-domain hybrids are scored where supported but are
  excluded from primary binary activity metrics.
* Compare the new and raw scores on EXACTLY the same covered samples. Full-
  cohort raw results are also reported so lost coverage is visible.

The completed output folder is e14_context_benefit_JOBID and contains:

  summary.json                       completion, coverage and primary metrics
  matching_coverage.json              support and exclusions by dataset
  natural_audit_summary.json          natural-context sanity check, no activity AUC
  matches.json.gz                     every selected control and its mask
  query_specs.json.gz                 all frozen engineered/natural queries
  shards/                            per-object original/alternative errors
  maps_bode1.json.gz                  domain/boundary values within query regions
  maps_bode2.json.gz                  domain/boundary values within query regions
  maps_tdomain.json.gz                target PCP and flank values
  region_scores.jsonl.gz              declared aggregate values
  evaluation/summary.json             AUCs, paired contrasts, coverage
  evaluation/assembly_predictions.json assembly-level scores used for evaluation
  score_seal.json                     prediction and unchanged-model checksums
  context_benefit_inspection.zip      portable results for analysis

The maps retain multiple query-specific values if a shared physical boundary
is reconstructed under different region masks. They cover the audited regions;
they do not invent new values elsewhere in an assembly. Local scores do not
sum to a classifier probability, because no activity classifier is fitted.

Transfer from Windows through Mac
----------------------------------
Save NeurALPS_ContextBenefit_20261008.zip in Windows Downloads, then PowerShell:

  scp -o PreferredAuthentications=password -o PubkeyAuthentication=no `
    "$env:USERPROFILE\Downloads\NeurALPS_ContextBenefit_20261008.zip" `
    amir@100.72.70.1:/Users/amir/

On the Mac:

  scp -J apandi@gate.lcqb.hosted.lip6.fr \
    /Users/amir/NeurALPS_ContextBenefit_20261008.zip \
    unh87ms@jean-zay.idris.fr:/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/

Run on Jean Zay
---------------
  cd /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2
  unzip -n NeurALPS_ContextBenefit_20261008.zip
  bash NeurALPS_ContextBenefit_20261008/submit.sh

The submission validates sources before queuing one A100, with a 2-hour ceiling.
That ceiling is not an estimated runtime. It uses the established PyTorch 2.8
environment and no forbidden --mem flag. There is no need to run the previous
e13 rich-vector exporter first. Source dependencies must remain unchanged.

  bash NeurALPS_ContextBenefit_20261008/status.sh

Follow the log printed by status. Press Ctrl+C to stop following; this does not
cancel the job. A repeated submit command will not duplicate an active or
completed identical request. For a paused run use the ORIGINAL output path:

  bash NeurALPS_ContextBenefit_20261008/submit.sh resume \
    /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/e14_context_benefit_JOBID

This resumes completed query shards only when every identity and checksum
agrees. It never edits pretrained checkpoints or original embedding caches.

Required existing project sources
----------------------------------
  NeurALPS_ContextAudit_20261007 (exact fixed package used by job 749149)
  e12_context_audit_749149 (completed, sealed)
  e8_reference_scale_652486/split_manifest.json
  e1_ssl_continue30_v1_530757 (selected step 26000)
  e10_tdomain_embed_696333 and e11_tdomain_transfer_699466 inputs
  Original frozen assembly database/cache and the old package dependency chain

Local checks (no production checkpoint required)
------------------------------------------------
  python verify.py
  python test_matching.py
  python test_launch.py
  python test_evaluate.py
  python test_runner.py

Original-model synthetic scoring tests additionally require torch and the
original Assembly_v1/ContextAudit source packages:

  python test_scoring.py --source-root /path/containing/NeurALPS_packages

New activity results will exist only after the real GPU job completes. This
bundle contains code and validation evidence, not newly measured AUCs.
