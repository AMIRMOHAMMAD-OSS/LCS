#!/usr/bin/env python3
"""Frozen same-piece context-benefit inference, then sealed assay evaluation."""
import argparse
from collections import Counter, OrderedDict, defaultdict
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import signal
import time
import traceback
import zipfile

from cb_common import (PACKAGE, VERSION, AUDIT_PACKAGE, CHECKPOINT_SHA, REFERENCE_RUN,
                       audit_source, canonical, checked_reference, dump, dump_gz,
                       emit, load, preflight, require, sha, state_sha)


class PredictionCache(OrderedDict):
    """Bounded immutable CPU prediction cache; evicting only changes runtime."""
    def __init__(self, limit=512):
        super().__init__()
        self.limit = limit

    def __getitem__(self, key):
        value = super().__getitem__(key)
        self.move_to_end(key)
        return value

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        self.move_to_end(key)
        while len(self) > self.limit:
            self.popitem(last=False)


def immutable_json(path, value, compressed=False):
    if path.exists():
        require(canonical(load(path)) == canonical(value), 'Resume input differs: ' + str(path))
    else:
        (dump_gz if compressed else dump)(path, value)


def aggregate_object_scores(scored, region):
    """Never average only the surviving subset of an originally declared region."""
    ds, bs = region['domain_indices'], region['boundary_indices']
    objects = scored['objects']
    output = {}
    for prefix in ('raw', 'benefit'):
        for mode in ('full', 'local'):
            values = {}
            for j in ds + bs:
                row = objects.get(str(j), {}).get(mode, {})
                value = row.get('original_error' if prefix == 'raw' else 'context_benefit')
                values[j] = (1 - value if prefix == 'raw' else value) if value is not None else None
            def mean(indices):
                v = [values[j] for j in indices]
                return sum(v) / len(v) if v and all(x is not None for x in v) else None
            d, b = mean(ds), mean(bs)
            output[prefix + '_' + mode] = dict(domains=d, boundaries=b,
                balanced=.5 * (d + b) if d is not None and b is not None else None,
                neighborhood_mean=mean(ds + bs))
    return output


def verify_old_query(result, reference, plan):
    require(reference['status'] == ('SCORED' if plan['status'] == 'READY' else plan['status']),
            'Original query eligibility changed')
    if plan['status'] != 'READY':
        require(not reference['objects'] and not result['objects'], 'Unsupported query has scores')
        return dict(comparisons=0, maximum_absolute_difference=0.)
    require(result['source_input_signature'] == reference['context_signature'],
            'Original masked model-input tensors changed')
    require(set(result['objects']) == set(reference['objects']), 'Original object coverage changed')
    delta = 0.
    count = 0
    for j, obj in result['objects'].items():
        for mode in ('full', 'local'):
            difference = abs(1 - obj[mode]['original_error'] - reference['objects'][j][mode])
            require(difference <= 5e-5, 'Original raw score replay differs by more than5e-5')
            delta = max(delta, difference)
            count += 1
    return dict(comparisons=count, maximum_absolute_difference=delta)


def validate_sequences(record, parent, lookup, seen):
    """Validate every physical slice used in an actually scored source/donor."""
    key = (record['dataset'], record['assembly_id'])
    if key in seen:
        return
    import numpy as np
    for slot in record['model_slots']:
        if slot['state'] != 'OBSERVED':
            continue
        sequence = parent(slot['parent_sequence_hash'])[slot['start']:slot['end']]
        require(len(sequence) == slot['length'] and
                hashlib.sha256(sequence.encode()).hexdigest() == slot['sequence_hash'],
                'Scored physical slice/hash mismatch: ' + record['assembly_id'])
        vector = lookup(slot['sequence_hash'])
        require(vector.shape == (1152,) and np.isfinite(vector).all() and np.linalg.norm(vector) > 0,
                'Invalid scored ESMC vector')
    seen.add(key)


def natural_summary(rows):
    import numpy as np
    output = dict(queries=len(rows), components=len({x['component_id'] for x in rows}),
                  status_counts=dict(Counter(x['score']['status'] for x in rows)),
                  activity_labels_used=False, activity_auroc=None,
                  interpretation='Own-context advantage sanity check, not activity validation.',
                  groups={})
    for kind in ('domain_flanks', 'boundary_single'):
        for mode in ('full', 'local'):
            chosen = [r for r in rows if r['query_kind'] == kind]
            values = []
            for r in chosen:
                j = r.get('target_object_index')
                value = r['score']['objects'].get(str(j), {}).get(mode, {}).get('context_benefit')
                if value is not None:
                    values.append(value)
            output['groups'][kind + '_' + mode] = dict(
                selected_queries=len(chosen), scored_queries=len(values),
                median=float(np.median(values)) if values else None,
                mean=float(np.mean(values)) if values else None,
                fraction_positive=float(np.mean(np.asarray(values) > 0)) if values else None,
                fraction_zero=float(np.mean(np.asarray(values) == 0)) if values else None)
    return output


def inspection(out):
    members = [p for p in sorted(out.rglob('*')) if p.is_file() and
               p.suffix in ('.json', '.gz', '.csv') and 'attempt_history' not in p.parts
               and p.name != 'artifact_manifest.json']
    manifest = {str(p.relative_to(out)): sha(p) for p in members}
    dump(out / 'artifact_manifest.json', manifest)
    temp = out / 'context_benefit_inspection.zip.tmp'
    with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in members + [out / 'artifact_manifest.json']:
            z.write(p, p.relative_to(out))
    temp.replace(out / 'context_benefit_inspection.zip')


def compact_evaluation(evaluation):
    """Keep status output readable; complete tables remain in evaluation/summary.json."""
    def main_row(row):
        return row.get('primary_field') and row.get('cohort') in ('all_engineered', 'primary65')
    def keep(row, keys):
        return {k: row.get(k) for k in keys}
    return dict(
        declared_primary_method='benefit_full',
        primary_metric_units=evaluation['primary_metric_units'],
        method_available=[keep(r, ('dataset', 'method', 'auroc', 'n_assemblies', 'mixed_backgrounds'))
                          for r in evaluation['metrics'] if main_row(r) and r['coverage_rule'] == 'method_available'],
        matched_cohort_comparisons=[keep(r, ('dataset', 'first', 'second', 'shared_assemblies',
            'first_auroc', 'second_auroc', 'auroc_delta', 'ci95'))
            for r in evaluation['paired_contrasts'] if main_row(r) and r['first'].startswith('benefit_')
            and r['second'].startswith('raw_')],
        bode1_mean_donor_panel_auroc=[keep(r, ('method', 'coverage_rule', 'auroc',
            'n_assemblies', 'mixed_donor_panels')) for r in evaluation['bode1_assembly_metrics']
            if r['metric_unit'] == 'mean_donor_panel_auroc'],
        complete_tables='evaluation/summary.json')


def execute(args):
    root, out = args.root.resolve(), args.out.resolve()
    require(os.environ.get('SLURM_JOB_ID'), 'Run this inference inside a one-A100 Slurm allocation')
    ctx, records, regions, request = preflight(root)
    require(load(args.request) == request, 'Submitted immutable request changed')
    require(out.parent == root and out.name.startswith('e14_context_benefit_'), 'Invalid output path')
    require(not (out / 'CONTEXT_BENEFIT_COMPLETE').exists(), 'This run is already complete')
    require(not out.exists() or args.resume, 'Existing output requires explicit resume')
    out.mkdir(exist_ok=True)
    lock = (out / '.lock').open('a')
    fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    args.owns_output = True
    for name in ('pause.json', 'fatal_error.json'):
        if (out / name).exists():
            archive = out / 'attempt_history'
            archive.mkdir(exist_ok=True)
            (out / name).rename(archive / (str(time.time_ns()) + '_' + name))
    stopping = {'signal': None}
    def stop(signum, frame):
        stopping['signal'] = signum
    signal.signal(signal.SIGUSR1, stop)
    signal.signal(signal.SIGTERM, stop)
    started = time.monotonic()
    import torch
    require(torch.__version__.split('+')[0] == '2.8.0' and torch.cuda.is_available()
            and torch.cuda.device_count() == 1 and 'A100' in torch.cuda.get_device_name(0),
            'Use the established PyTorch2.8.0 one-A100 environment')
    torch.set_num_threads(8)
    torch.manual_seed(20261008)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.use_deterministic_algorithms(True)

    from natural_cohorts import prepare_cohorts
    from ca_common import clean_record
    from context_plans import build_plans, make_plan
    from frozen_scoring import open_frozen
    from matching import Matcher, natural_audit_queries
    from scoring import score_query, feature_lookup

    emit('READING_FIXED_NATURAL_COMPONENTS')
    natural_source, split, overlap = prepare_cohorts(ctx['prep'] / 'training_data.sqlite3')
    require(canonical(split) == canonical(load(root / REFERENCE_RUN / 'split_manifest.json')),
            'Rebuilt natural component assignment differs from the completed reference-scale split')
    natural = {aid: clean_record(r, 'natural') for aid, r in natural_source.items() if r['dataset'] == 'natural'}
    require(len(natural) == 3515, 'Expected the full production natural internal_test cohort')
    del natural_source
    checked, old_identity, old_seal, old_scores, old_plans = audit_source(root, request['source_audit_request'])
    runtime = open_frozen(ctx, records)
    weights_sha = state_sha(runtime.model)
    require(weights_sha == old_scores['weights_state_sha256'], 'Frozen weight state differs from audit')
    plans = build_plans(records, regions, runtime.store.parent, runtime.closure)
    require(canonical(plans) == canonical(old_plans) == old_seal['plans_sha256'],
            'Original engineered masks changed')
    protocol = load(PACKAGE / 'PROTOCOL.json')
    identity = dict(request=request, natural_records_sha256=canonical(natural),
                    natural_split_sha256=canonical(split), weights_state_sha256=weights_sha,
                    torch=torch.__version__, cuda=torch.version.cuda, device=torch.cuda.get_device_name(0),
                    precision='fp32', tf32=False, deterministic_algorithms=True,
                    training_updates=0, classifier_fits=0, activity_labels_used_for_predictions=False)
    immutable_json(out / 'identity.json', identity)
    immutable_json(out / 'protocol.json', protocol)
    immutable_json(out / 'natural_split.json', split)
    immutable_json(out / 'natural_overlap_summary.json', dict(
        summary_by_cohort=overlap['summary_by_cohort'], homology_separation_verified=False,
        audit_assemblies={aid: x for aid, x in overlap['assemblies'].items()
                         if x['dataset'] == 'natural' and x['role'] == 'audit'}))
    del overlap

    query_specs = {}
    for r in regions:
        query_specs['engineered/' + r['region_id']] = dict(cohort='engineered', region=r,
            assembly_id=r['assembly_id'], plan=plans['joint'][r['region_id']])
    natural_specs = natural_audit_queries(natural, split['metadata'])
    for r in natural_specs:
        if r['targets']:
            p = make_plan(natural[r['assembly_id']], r['targets'], runtime.store.base.parent, runtime.closure)
        else:
            p = dict(status=r['status'], targets=[], primary=[], hidden=[],
                     masked_fraction=None, remaining_context_min=None)
        query_specs['natural/' + r['region_id']] = dict(cohort='natural', region=r,
                                                       assembly_id=r['assembly_id'], plan=p)
    immutable_json(out / 'query_specs.json.gz', query_specs, compressed=True)
    matches_path = out / 'matches.json.gz'
    if matches_path.exists() and not (out / 'pre_inference_seal.json').exists():
        require(args.resume, 'Found an unsealed matching file outside an explicit resume')
        history = out / 'attempt_history'
        history.mkdir(exist_ok=True)
        matches_path.rename(history / (str(time.time_ns()) + '_unsealed_matches.json.gz'))
        emit('REBUILDING_UNSEALED_MATCHES', scores_reused=False)
    if matches_path.exists():
        seal = load(out / 'pre_inference_seal.json')
        require(seal['identity_sha256'] == canonical(identity) and
                seal['query_specs_sha256'] == canonical(query_specs) and
                sha(matches_path) == seal['matches_file_sha256'], 'Resume matching identity changed')
        matches = load(matches_path)
    else:
        matcher = Matcher(natural, split['metadata'], runtime.store.parent, runtime.closure)
        matches = {}
        for i, (qid, spec) in enumerate(sorted(query_specs.items())):
            rec = (natural if spec['cohort'] == 'natural' else records)[spec['assembly_id']]
            matches[qid] = matcher.match_query(rec, spec['plan'])
            if i % 50 == 0 or i + 1 == len(query_specs):
                emit('MATCHED_CONTEXT_PLAN_PROGRESS', complete=i + 1, planned=len(query_specs))
            if stopping['signal']:
                dump(out / 'pause.json', dict(status='PAUSED', stage='matching_before_inference',
                     resume=str(out), completed_plans=i + 1))
                inspection(out)
                return 75
        dump_gz(matches_path, matches)
        dump(out / 'pre_inference_seal.json', dict(identity_sha256=canonical(identity),
            query_specs_sha256=canonical(query_specs), matches_file_sha256=sha(matches_path),
            matches_sha256=canonical(matches), activity_outcomes_used_for_matching=False))
        del matcher
    require(set(matches) == set(query_specs), 'Incomplete or additional matched queries')
    plan_seal = load(out / 'pre_inference_seal.json')
    require(canonical(matches) == plan_seal['matches_sha256'], 'Match payload checksum changed')
    coverage = {}
    for cohort in ('natural', 'bode1', 'bode2', 'tdomain'):
        ids = [qid for qid, q in query_specs.items() if
               (q['cohort'] == 'natural' if cohort == 'natural' else
                q['cohort'] == 'engineered' and q['region']['dataset'] == cohort)]
        coverage[cohort] = dict(queries=len(ids), status_counts=dict(Counter(matches[k]['status'] for k in ids)),
            selected_components_histogram=dict(Counter(str(len(matches[k]['candidates'])) for k in ids)))
    dump(out / 'matching_coverage.json', coverage)
    emit('CONTEXT_MATCHES_SEALED', coverage=coverage)

    shard_dir = out / 'shards'
    shard_dir.mkdir(exist_ok=True)
    cache = PredictionCache()
    old_cache = {}
    validated = set()
    results = {}
    ordered = sorted(query_specs, key=lambda qid: (not qid.startswith('natural/'), qid))
    for i, qid in enumerate(ordered):
        spec, match = query_specs[qid], matches[qid]
        rec = (natural if spec['cohort'] == 'natural' else records)[spec['assembly_id']]
        stem = hashlib.sha256(qid.encode()).hexdigest()
        shard_path, meta_path = shard_dir / (stem + '.json.gz'), shard_dir / (stem + '.json')
        expected = dict(query_id=qid, identity_sha256=canonical(identity),
                        spec_sha256=canonical(spec), match_sha256=canonical(match))
        if meta_path.exists():
            meta = load(meta_path)
            require(all(meta.get(k) == v for k, v in expected.items()) and
                    shard_path.is_file() and sha(shard_path) == meta['sha256'], 'Sealed query shard changed')
            result = load(shard_path)
        else:
            validate_sequences(rec, runtime.store.parent, feature_lookup(runtime, rec), validated)
            for c in match['candidates']:
                donor = natural[c['assembly_id']]
                validate_sequences(donor, runtime.store.base.parent, runtime.store.base.vector, validated)
            result = score_query(runtime, rec, spec['plan'], match, natural, cache)
            result['query_id'] = qid
            if spec['cohort'] == 'engineered':
                aid = rec['assembly_id']
                if aid not in old_cache:
                    old_cache[aid] = checked_reference(aid, rec, checked, old_identity, old_seal)
                ref = old_cache[aid]['queries']['joint/' + spec['region']['region_id']]
                result['original_score_parity'] = verify_old_query(result, ref, spec['plan'])
            dump_gz(shard_path, result)
            dump(meta_path, dict(expected, sha256=sha(shard_path)))
        results[qid] = result
        if i % 20 == 0 or i + 1 == len(ordered):
            emit('CONTEXT_BENEFIT_INFERENCE_PROGRESS', complete=i + 1, planned=len(ordered),
                 stage_cohort=spec['cohort'], reused_or_computed=True)
        if stopping['signal']:
            dump(out / 'pause.json', dict(status='PAUSED', stage='frozen_inference',
                 resume=str(out), completed_queries=i + 1))
            inspection(out)
            return 75
    require(state_sha(runtime.model) == weights_sha and sha(ctx['ssl_run'] / 'best.pt') == CHECKPOINT_SHA,
            'Pretrained weights changed')

    natural_rows = []
    region_rows = []
    by_assembly = defaultdict(list)
    for qid, spec in sorted(query_specs.items()):
        result = results[qid]
        if spec['cohort'] == 'natural':
            natural_rows.append(dict(spec['region'], score=result))
            continue
        r = spec['region']
        row = {key: r.get(key) for key in ('assembly_id', 'dataset', 'region_id', 'role',
                 'position', 'background_id', 'context', 'domain_indices', 'boundary_indices')}
        row['context'] = r.get('context', '')
        row.update(status=result['status'], methods=aggregate_object_scores(result, r),
                   matched_contexts=result['available_alternatives'], match_status=matches[qid]['status'])
        region_rows.append(row)
        by_assembly[r['assembly_id']].append(dict(region_id=r['region_id'],
            domain_indices=r['domain_indices'], boundary_indices=r['boundary_indices'],
            status=result['status'], methods=row['methods'], objects=result['objects'],
            alternatives=result['alternatives']))
    dump(out / 'natural_audit_summary.json', natural_summary(natural_rows))
    dump_gz(out / 'natural_audit_queries.json.gz', natural_rows)
    for dataset in ('bode1', 'bode2', 'tdomain'):
        assemblies = []
        for aid, rec in sorted(records.items()):
            if rec['dataset'] == dataset:
                assemblies.append(dict(assembly_id=aid, route=rec['route'], queries=by_assembly[aid],
                    scores_are_activity_probabilities=False, training_updates=0))
        dump_gz(out / ('maps_' + dataset + '.json.gz'), dict(dataset=dataset, assemblies=assemblies,
            score='median alternative error minus original error',
            scope='Declared joint-mask regions; query-specific boundary values retained',
            calibrated_local_probabilities=False))
    score_file = out / 'region_scores.jsonl.gz'
    with score_file.with_suffix('.tmp').open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as f:
            for r in region_rows:
                f.write((json.dumps(r, sort_keys=True, allow_nan=False) + '\n').encode())
    score_file.with_suffix('.tmp').replace(score_file)
    score_seal = dict(region_scores_sha256=sha(score_file), identity_sha256=canonical(identity),
        matching_sha256=canonical(matches), weights_state_sha256=weights_sha,
        activity_labels_used_for_predictions=False, pretrained_weights_changed=False,
        maps_sha256={d: sha(out / ('maps_' + d + '.json.gz')) for d in ('bode1', 'bode2', 'tdomain')})
    dump(out / 'score_seal.json', score_seal)
    # Only now may the evaluator open assay labels and outcomes.
    from benefit_evaluate import evaluate_scores
    evaluation = evaluate_scores(score_file, out / 'evaluation', score_seal['region_scores_sha256'],
                                 data_dir=root / AUDIT_PACKAGE / 'data')
    parity = [r['original_score_parity'] for r in results.values() if 'original_score_parity' in r]
    summary = dict(status='CONTEXT_BENEFIT_COMPLETE', version=VERSION, selected_step=26000,
        pretrained_weights_changed=False, training_updates=0, activity_classifier_fits=0,
        activity_labels_used_for_matching=False, activity_labels_used_for_predictions=False,
        prediction_sealed_before_activity_evaluation=True, natural_audit=natural_summary(natural_rows),
        matching_coverage=coverage, evaluation=compact_evaluation(evaluation),
        original_score_parity=dict(comparisons=sum(x['comparisons'] for x in parity),
            maximum_absolute_difference=max((x['maximum_absolute_difference'] for x in parity), default=0.)),
        causal_localization_validated=False, calibrated_activity_probabilities=False,
        natural_contexts_are_known_inactive=False, seconds_this_attempt=time.monotonic() - started)
    dump(out / 'summary.json', summary)
    inspection(out)
    (out / 'CONTEXT_BENEFIT_COMPLETE').write_text(VERSION + '\n')
    print(json.dumps(summary, indent=2, allow_nan=False), flush=True)
    print('Inspection:', out / 'context_benefit_inspection.zip', flush=True)
    return 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--request', required=True, type=Path)
    parser.add_argument('--resume', action='store_true')
    arguments = parser.parse_args()
    try:
        code = execute(arguments)
    except Exception:
        if getattr(arguments, 'owns_output', False):
            dump(arguments.out / 'fatal_error.json', dict(status='FAILED', traceback=traceback.format_exc()))
        raise
    raise SystemExit(code)
