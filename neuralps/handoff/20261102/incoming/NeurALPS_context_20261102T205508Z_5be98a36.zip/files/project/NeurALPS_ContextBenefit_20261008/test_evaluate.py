"""Synthetic evaluator tests; these are not production model results."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import benefit_evaluate as ev


def fixture(root, *, bode1=True, bode2=True, tdomain=True):
    regions, rows = [], []
    labels, groups = {ds: {} for ds in ("bode1", "bode2", "tdomain")}, {ds: {} for ds in ("bode1", "bode2", "tdomain")}
    for ds, enabled in (("bode1", bode1), ("bode2", bode2), ("tdomain", tdomain)):
        if not enabled:
            continue
        for i in range(4):
            aid = ds + "_" + str(i)
            labels[ds][aid] = i // 2
            if ds == "bode1":
                groups[ds][aid] = {"parts": ["P" + str(i), "X", "Y"]}
            elif ds == "bode2":
                groups[ds][aid] = {"donor_triplet_group": "donor:" + str(i)}
            else:
                groups[ds][aid] = {"evaluation_cohort": "primary65", "minimum_ancestry_group": "ancestry:" + str(i),
                                   "generation_round": i // 2 + 1, "source_agreement_subset": i != 3}
            for j in range(3 if ds == "bode1" else 1):
                region = {"assembly_id": aid, "region_id": aid + ":r" + str(j), "dataset": ds,
                          "role": "engineered", "position": str(j), "domain_indices": [2 * j], "boundary_indices": [2 * j + 1]}
                if ds == "bode1":
                    region["background_id"] = "XY" if j == 0 else "P" + str(i) + ":j" + str(j)
                if ds == "tdomain":
                    region["context"] = "minimal"
                regions.append(region)
                rows.append({**deepcopy(region), "status": "SCORED", "methods": {
                    method: {field: i / 4 for field in ev.FIELDS} for method in ev.METHODS}})
    data = root / "data"
    data.mkdir()
    for name, obj in (("regions", regions), ("labels", labels), ("groups", groups)):
        (data / (name + ".json")).write_text(json.dumps(obj))
    score = root / "scores.jsonl"
    score.write_text("".join(json.dumps(row) + "\n" for row in rows))
    return data, score, rows, regions, labels, groups


class EvaluatorTests(unittest.TestCase):
    def test_score_direction_never_flips(self):
        self.assertEqual(ev.binary_metrics([0, 0, 1, 1], [1, .8, .2, 0])["auroc"], 0)
        self.assertEqual(ev.binary_metrics([0, 1], [.5, .5])["auroc"], .5)

    def test_invalid_seal_before_any_label_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            data, score, *_ = fixture(root)
            with patch.object(ev, "read_json", side_effect=AssertionError("Labels opened too early")):
                with self.assertRaisesRegex(ValueError, "seal mismatch"):
                    ev.evaluate_scores(score, root / "out", "0" * 64, data_dir=data, bootstrap_reps=100)
            self.assertFalse((root / "out").exists())

    def test_missing_matches_use_exact_common_cohort(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            data, score, rows, regions, labels, groups = fixture(root, bode1=False, tdomain=False)
            for i, row in enumerate(rows):
                # Raw ordering makes a mistake only on the unsupported positive.
                raw = [0, .6, .2, .9][i]
                for field in ev.FIELDS:
                    row["methods"]["raw_full"][field] = raw
                    row["methods"]["benefit_full"][field] = None if i == 2 else i / 4
            score.write_text("".join(json.dumps(row) + "\n" for row in rows))
            summary = ev.evaluate_scores(score, root / "out", ev.sha(score), data_dir=data, bootstrap_reps=100)
            pair = next(p for p in summary["paired_contrasts"] if p["dataset"] == "bode2" and
                        p["cohort"] == "all_engineered" and p["first"] == "benefit_full" and p["second"] == "raw_full")
            self.assertEqual(pair["shared_assemblies"], 3)
            self.assertEqual(pair["first_auroc"], 1)
            self.assertEqual(pair["second_auroc"], 1)
            full = next(m for m in summary["metrics"] if m["dataset"] == "bode2" and m["cohort"] == "all_engineered" and
                        m["method"] == "raw_full" and m["coverage_rule"] == "method_available")
            self.assertEqual(full["auroc"], .75)
            coverage = next(c for c in summary["coverage"] if c["dataset"] == "bode2" and c["cohort"] == "all_engineered" and c["method"] == "benefit_full")
            self.assertEqual(coverage["missing_regions"], 1)

    def test_bode1_complete_assembly_mean_without_pseudoreplication(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, _, rows, regions, labels, groups = fixture(root, bode2=False, tdomain=False)
            for j, number in enumerate([.9, 0, 0]):
                for field in ev.FIELDS:
                    rows[j]["methods"]["raw_full"][field] = number
            # One unsupported benefit region must exclude its whole assembly.
            for field in ev.FIELDS:
                rows[4]["methods"]["benefit_full"][field] = None
            index = ev.prepare(rows, regions, labels, groups)
            predictions = ev.assembly_predictions(regions, index, labels, groups)
            self.assertEqual(len(predictions), 4)
            self.assertAlmostEqual(predictions[0]["scores"]["raw_full"], .3)
            self.assertIsNone(predictions[1]["scores"]["benefit_full"])
            metrics, panels, pairs = ev.bode1_assembly_tables(predictions)
            raw = next(m for m in metrics if m["method"] == "raw_full" and m["coverage_rule"] == "method_available" and m["metric_unit"] == "mean_donor_panel_auroc")
            self.assertEqual(raw["n_assemblies"], 4)
            self.assertEqual(raw["donor_panel_memberships"], 12)
            self.assertEqual(raw["mixed_donor_panels"], 2)
            self.assertIsNone(raw["ci95"])
            comparison = next(p for p in pairs if p["first"] == "benefit_full" and p["second"] == "raw_full")
            self.assertEqual(comparison["shared_assemblies"], 3)

    def test_raw_missing_region_excludes_entire_legacy_assembly(self):
        with tempfile.TemporaryDirectory() as tmp:
            _, _, rows, regions, labels, groups = fixture(Path(tmp), bode2=False, tdomain=False)
            for field in ev.FIELDS:
                rows[0]["methods"]["raw_full"][field] = None
            index = ev.prepare(rows, regions, labels, groups)
            pred = ev.assembly_predictions(regions, index, labels, groups)
            metrics, _, _ = ev.bode1_assembly_tables(pred)
            self.assertTrue(all(m["raw_complete_assemblies"] == 3 for m in metrics))
            self.assertTrue(all(m["raw_incomplete_assemblies"] == 1 for m in metrics))

    def test_duplicate_or_missing_region_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            _, _, rows, regions, labels, groups = fixture(Path(tmp))
            with self.assertRaisesRegex(ValueError, "duplicate"):
                ev.prepare(rows + [deepcopy(rows[0])], regions, labels, groups)
            with self.assertRaisesRegex(ValueError, "Every declared region"):
                ev.prepare(rows[1:], regions, labels, groups)

    def test_no_fabricated_balanced_score(self):
        with tempfile.TemporaryDirectory() as tmp:
            _, _, rows, regions, labels, groups = fixture(Path(tmp))
            rows[0]["methods"]["benefit_full"]["domains"] = None
            with self.assertRaisesRegex(ValueError, "unsupported component"):
                ev.prepare(rows, regions, labels, groups)

    def test_cluster_paired_identical_methods_have_zero_interval(self):
        labels = [i % 2 for i in range(20)]
        scores = [i / 20 for i in range(20)]
        clusters = ["g" + str(i) for i in range(20)]
        result = ev.cluster_bootstrap(labels, scores, clusters, b=scores, reps=100, seed=17)
        self.assertEqual(result["bootstrap_groups"], 20)
        self.assertEqual(result["ci95"], [0, 0])
        self.assertEqual(result, ev.cluster_bootstrap(labels, scores, clusters, b=scores, reps=100, seed=17))

    def test_tdomain_domains_primary_and_flanks_secondary(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            data, score, *_ = fixture(root, bode1=False, bode2=False)
            report = ev.evaluate_scores(score, root / "out", ev.sha(score), data_dir=data, bootstrap_reps=100)
            primary = [m for m in report["metrics"] if m["cohort"] == "primary65"]
            self.assertEqual({m["field"] for m in primary}, {"domains", "neighborhood_mean"})
            self.assertTrue(all(m["primary_field"] == (m["field"] == "domains") for m in primary))
            self.assertTrue(any(m["cohort"] == "source_agreement63" and m["n_assemblies"] == 3 for m in report["metrics"]))
            self.assertEqual(report["activity_classifier_fits"], 0)
            self.assertEqual(report["training_updates"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
