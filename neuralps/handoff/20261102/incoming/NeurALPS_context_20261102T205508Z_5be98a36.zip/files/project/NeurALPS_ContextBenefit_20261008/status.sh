#!/usr/bin/env bash
set -euo pipefail
NRPS_BENEFIT_PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
exec python3 -B "$NRPS_BENEFIT_PACKAGE/launch.py" status "$@"
