"""Deterministic, label-free natural-context matching for a frozen-model test.

No target names, outcomes, scores, embeddings, or fitted parameters are used in
candidate ordering.  An offset maps source indices to donor indices.  A donor
prediction must later be scored against the SOURCE target, not its own target.
"""
from collections import Counter, defaultdict
import hashlib
import json

SEED = 20261008
MIN_COMPONENTS = 8
MAX_COMPONENTS = 16


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def _metadata(metadata):
    return metadata['metadata'] if 'metadata' in metadata else metadata


def _slots(record):
    result = defaultdict(list)
    for slot in record['model_slots']:
        result[slot['object_index']].append(slot)
    return {index: sorted(slots, key=lambda s: s['slot']) for index, slots in result.items()}


def _length_bin(length):
    require(type(length) is int and length > 0, 'Observed feature length must be a positive integer')
    return length.bit_length() - 1


def _object_kind(obj):
    return (obj['kind'], obj['domain_type'] if obj['kind'] == 0 else 0)


def _target_tag(record, index, by):
    obj = record['route'][index]
    require(all(isinstance(s.get('group'), str) and s['group'] for s in by[index]),
            'Physical slot training group missing')
    return (_object_kind(obj), tuple((s['slot'], s['state'], s['group'],
                                     _length_bin(s['length']) if s['state'] == 'OBSERVED' else None)
                                    for s in by[index]))


def _chain_pattern(record, indices):
    chain_ids, pattern = {}, []
    for index in indices:
        obj = record['route'][index]
        if obj['kind'] == 2:
            pattern.append('BREAK')
        else:
            value = obj['chain']
            if value not in chain_ids:
                chain_ids[value] = len(chain_ids)
            pattern.append(chain_ids[value])
    return pattern


def structural_descriptor(record, targets, by=None):
    """Typed contiguous target geometry and fixed nuisance-matching strata."""
    by = _slots(record) if by is None else by
    targets = sorted(targets)
    require(targets and len(set(targets)) == len(targets), 'Targets must be nonempty and unique')
    start, end = targets[0], targets[-1]
    n = len(record['route'])
    require(0 <= start <= end < n and targets == list(range(start, end + 1)),
            'This protocol requires contiguous physical target objects')
    require(all(index in by for index in targets), 'Target physical slot metadata missing')
    def flank(index):
        return list(_object_kind(record['route'][index])) if 0 <= index < n else None
    indices = list(range(max(0, start - 1), min(n, end + 2)))
    return dict(targets=[_target_tag(record, index, by) for index in targets],
                target_count=len(targets),
                touches_route_start=start == 0, touches_route_end=end == n - 1,
                left_flank=flank(start - 1), right_flank=flank(end + 1),
                chain_pattern_with_immediate_flanks=_chain_pattern(record, indices),
                route_object_count_bin=_length_bin(n))


def query_descriptor(record, plan):
    descriptor = structural_descriptor(record, plan['targets'])
    start = min(plan['targets'])
    descriptor['hidden_relative_slots'] = sorted([j - start, role] for j, role in plan['hidden'])
    return descriptor


def visible_identity(record, hidden):
    """Original ContextAudit metadata identity, retaining actual chain IDs.

    Runtime additionally checks masked tensor signatures because distinct feature
    sequence IDs alone do not prove distinct observed numerical model tensors.
    """
    hidden = set(map(tuple, hidden))
    slots = sorted(record['model_slots'], key=lambda slot: (slot['object_index'], slot['slot']))
    geometry = dict(objects=[(obj['kind'], obj['domain_type'] if obj['kind'] == 0 else 0,
                              obj['chain'] if obj['kind'] != 2 else -1)
                             for obj in record['route']],
                    slots=[(slot['object_index'], slot['slot'], slot['state']) for slot in slots],
                    target_indices=[])
    return canonical(dict(geometry=geometry, visible=[
        (slot['object_index'], slot['slot'],
         'MASKED' if (slot['object_index'], slot['slot']) in hidden else slot['state'],
         None if (slot['object_index'], slot['slot']) in hidden or slot['state'] != 'OBSERVED'
         else slot['sequence_hash']) for slot in slots]))


class CandidateIndex:
    """Index only calibration objects; cache structural matches by descriptor."""
    def __init__(self, records, metadata):
        metadata = _metadata(metadata)
        self.records = {}
        self.metadata = metadata
        self.slots = {}
        self.by_first_tag = defaultdict(list)
        self.structural_cache = {}
        for aid, record in sorted(records.items()):
            if record.get('dataset') != 'natural' or metadata.get(aid, {}).get('role') != 'calibration':
                continue
            require(record['assembly_id'] == aid, 'Natural assembly key differs from record identity')
            require(isinstance(metadata[aid].get('component_id'), str), 'Calibration component ID missing')
            self.records[aid] = record
            by = self.slots[aid] = _slots(record)
            for index in range(len(record['route'])):
                if index not in by or any(s['state'] != 'OBSERVED' for s in by[index]):
                    continue
                self.by_first_tag[canonical(_target_tag(record, index, by))].append((aid, index))

    def structural_candidates(self, descriptor):
        structural = {k: v for k, v in descriptor.items() if k != 'hidden_relative_slots'}
        key = canonical(structural)
        if key not in self.structural_cache:
            candidates = []
            first = canonical(structural['targets'][0])
            width = structural['target_count']
            for aid, start in self.by_first_tag.get(first, []):
                record = self.records[aid]
                if start + width > len(record['route']):
                    continue
                targets = list(range(start, start + width))
                actual = structural_descriptor(record, targets, self.slots[aid])
                if canonical(actual) == key:
                    candidates.append((aid, start))
            self.structural_cache[key] = candidates
        return self.structural_cache[key]


def build_candidate_index(records, metadata):
    return CandidateIndex(records, metadata)


class Matcher:
    def __init__(self, natural_records, metadata, parent, closure, make_plan=None,
                 candidate_index=None, seed=SEED):
        self.records = natural_records
        self.metadata = _metadata(metadata)
        self.parent = parent
        self.closure = closure
        if make_plan is None:
            from context_plans import make_plan
        self.make_plan = make_plan
        self.index = candidate_index or build_candidate_index(natural_records, self.metadata)
        require(isinstance(self.index, CandidateIndex), 'Use the declared CandidateIndex')
        self.seed = seed
        self.plan_cache = {}
        self.visible_cache = {}
        self.parent_cache = {}
        self.feature_cache = {}
        self.overlap_cache = {}
        self.target_sequence_cache = {}

    def _parents(self, record):
        aid = record['assembly_id']
        if aid not in self.parent_cache:
            hashes = sorted(set(record['parent_sequence_hashes'].values()))
            self.parent_cache[aid] = {key: self.parent(key) for key in hashes}
        return self.parent_cache[aid]

    def _target_sequences(self, record, plan):
        by = _slots(record)
        hashes = tuple(sorted({s['sequence_hash'] for j in plan['targets'] for s in by[j]}))
        if hashes not in self.target_sequence_cache:
            sequences = {}
            parents = self._parents(record)
            for j in plan['targets']:
                for slot in by[j]:
                    sequence = parents[slot['parent_sequence_hash']][slot['start']:slot['end']]
                    require(len(sequence) == slot['length'] and
                            hashlib.sha256(sequence.encode()).hexdigest() == slot['sequence_hash'],
                            'Source target sequence differs from frozen physical metadata')
                    sequences[slot['sequence_hash']] = sequence
            self.target_sequence_cache[hashes] = sequences
        return hashes, self.target_sequence_cache[hashes]

    def _overlap_reason(self, source, plan, donor):
        source_parents = tuple(sorted(set(source['parent_sequence_hashes'].values())))
        target_hashes, sequences = self._target_sequences(source, plan)
        aid = donor['assembly_id']
        cache_key = (source_parents, target_hashes, aid)
        if cache_key in self.overlap_cache:
            return self.overlap_cache[cache_key]
        donor_parent_hashes = set(donor['parent_sequence_hashes'].values())
        if set(source_parents) & donor_parent_hashes:
            reason = 'SHARED_PARENT_SEQUENCE'
        else:
            if aid not in self.feature_cache:
                self.feature_cache[aid] = {s['sequence_hash'] for s in donor['model_slots']
                                           if s['state'] == 'OBSERVED'}
            if set(target_hashes) & self.feature_cache[aid]:
                reason = 'SHARED_TARGET_FEATURE'
            elif any(target in protein for protein in self._parents(donor).values()
                     for target in sequences.values()):
                reason = 'TARGET_SEQUENCE_SUBSTRING_IN_DONOR_PARENT'
            else:
                reason = None
        self.overlap_cache[cache_key] = reason
        return reason

    def match_query(self, source_record, source_plan, *, max_candidates=MAX_COMPONENTS,
                    min_candidates=MIN_COMPONENTS):
        require(type(min_candidates) is int and type(max_candidates) is int and
                1 <= min_candidates <= max_candidates, 'Invalid candidate component limits')
        if source_plan['status'] != 'READY':
            return dict(status='SOURCE_NOT_READY', source_status=source_plan['status'],
                        descriptor=None, candidates=[], counts={},
                        minimum_components=min_candidates, maximum_components=max_candidates)
        descriptor = query_descriptor(source_record, source_plan)
        descriptor_sha = canonical(descriptor)
        start = min(source_plan['targets'])
        source_component = self.metadata.get(source_record['assembly_id'], {}).get('component_id')
        pool = self.index.structural_candidates(descriptor)
        ordered = sorted(pool, key=lambda x: (canonical(dict(
            seed=self.seed, descriptor_sha256=descriptor_sha,
            component_id=self.metadata[x[0]]['component_id'], assembly_id=x[0], window_start=x[1])), x))
        counts = Counter(structural_candidates=len(pool))
        candidates, components, visible_controls = [], set(), set()
        source_visible = visible_identity(source_record, source_plan['hidden'])
        for aid, donor_start in ordered:
            component = self.metadata[aid]['component_id']
            if source_component is not None and component == source_component:
                counts['SAME_NATURAL_COMPONENT'] += 1
                continue
            if component in components:
                counts['COMPONENT_ALREADY_SELECTED'] += 1
                continue
            donor = self.index.records[aid]
            reason = self._overlap_reason(source_record, source_plan, donor)
            if reason is not None:
                counts[reason] += 1
                continue
            offset = donor_start - start
            targets = [j + offset for j in source_plan['targets']]
            key = (aid, tuple(targets))
            if key not in self.plan_cache:
                self.plan_cache[key] = self.make_plan(donor, targets, self.parent, self.closure)
            plan = self.plan_cache[key]
            if plan['status'] != 'READY':
                counts['DONOR_' + plan['status']] += 1
                continue
            hidden = sorted([j - donor_start, role] for j, role in plan['hidden'])
            if hidden != descriptor['hidden_relative_slots']:
                counts['MASK_CLOSURE_MISMATCH'] += 1
                continue
            if key not in self.visible_cache:
                self.visible_cache[key] = visible_identity(donor, plan['hidden'])
            visible = self.visible_cache[key]
            if visible == source_visible:
                counts['SOURCE_IDENTICAL_VISIBLE_CONTEXT'] += 1
                continue
            if visible in visible_controls:
                counts['DUPLICATE_SELECTED_VISIBLE_CONTEXT'] += 1
                continue
            visible_controls.add(visible)
            candidates.append(dict(assembly_id=aid, component_id=component,
                                   offset=offset, window_start=donor_start,
                                   visible_identity_sha256=visible,
                                   plan=plan, plan_sha256=canonical(plan),
                                   selection_sha256=canonical(dict(seed=self.seed,
                                       descriptor_sha256=descriptor_sha, component_id=component,
                                       assembly_id=aid, window_start=donor_start))))
            components.add(component)
            if len(candidates) == max_candidates:
                break
        counts['selected_components'] = len(candidates)
        return dict(status='MATCHED' if len(candidates) >= min_candidates else 'INSUFFICIENT_MATCHED_CONTEXTS',
                    descriptor=descriptor, descriptor_sha256=descriptor_sha,
                    source_visible_identity_sha256=source_visible,
                    candidates=candidates, counts=dict(sorted(counts.items())),
                    minimum_components=min_candidates, maximum_components=max_candidates,
                    candidate_counts_scope='Exclusions counted in deterministic scan until cap, not all possible exclusions',
                    seed=self.seed, candidate_selection_uses_activity_labels=False,
                    target_sequence_exclusion='Reject target substring anywhere in donor parents; no remasking',
                    mask_policy='Exact translated original closure; no relaxation')


def match_query(source_record, source_plan, natural_records, metadata, parent, closure, *,
                max_candidates=MAX_COMPONENTS, min_candidates=MIN_COMPONENTS,
                candidate_index=None, make_plan=None):
    """Convenience wrapper; reuse Matcher for caches across production queries."""
    return Matcher(natural_records, metadata, parent, closure, make_plan,
                   candidate_index).match_query(source_record, source_plan,
                       max_candidates=max_candidates, min_candidates=min_candidates)


def natural_audit_queries(records, metadata, *, max_components=256, seed=SEED):
    """Select before eligibility: one assembly/component, one query of each kind.

    No replacement is selected for missing features, short visible context, or
    unsupported matching. Caller constructs plans and records those outcomes.
    """
    require(type(max_components) is int and max_components > 0, 'Invalid natural audit component cap')
    metadata = _metadata(metadata)
    components = defaultdict(list)
    for aid, record in sorted(records.items()):
        meta = metadata.get(aid, {})
        if record.get('dataset') == 'natural' and meta.get('role') == 'audit':
            require(isinstance(meta.get('component_id'), str), 'Natural audit component ID missing')
            components[meta['component_id']].append(aid)
    order = sorted(components, key=lambda component: (canonical(
        [seed, 'audit_component', component]), component))[:max_components]
    queries = []
    for component in order:
        aid = min(components[component], key=lambda value: (canonical(
            [seed, 'audit_assembly', component, value]), value))
        record = records[aid]
        for query_kind, kinds in [('domain_flanks', {0}), ('boundary_single', {1, 2})]:
            choices = [j for j, obj in enumerate(record['route']) if obj['kind'] in kinds]
            region_id = 'natural_audit|' + component + '|' + query_kind
            if not choices:
                queries.append(dict(assembly_id=aid, component_id=component, region_id=region_id,
                                    query_kind=query_kind, status='NO_PHYSICAL_OBJECT_OF_KIND',
                                    targets=[]))
                continue
            index = min(choices, key=lambda j: (canonical(
                [seed, 'audit_object', component, aid, query_kind, j]), j))
            targets = [index]
            if query_kind == 'domain_flanks':
                targets += [j for j in (index - 1, index + 1)
                            if 0 <= j < len(record['route']) and record['route'][j]['kind'] != 0]
            queries.append(dict(assembly_id=aid, component_id=component, region_id=region_id,
                                query_kind=query_kind, status='SELECTED_BEFORE_ELIGIBILITY',
                                target_object_index=index, targets=sorted(targets)))
    return queries
