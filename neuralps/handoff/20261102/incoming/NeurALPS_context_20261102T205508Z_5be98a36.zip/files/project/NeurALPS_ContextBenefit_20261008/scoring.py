"""Frozen same-piece scoring in original and matched alternative contexts.

Matching supplies every mask. This module neither samples donors, recomputes
closures, reads labels, fits a classifier nor changes model weights. A single
source target vector and source training mean are reused across all contexts.
"""
import hashlib
import json

import numpy as np


MIN_ALTERNATIVES = 8
MODES = ("full", "local")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def feature_lookup(runtime, record):
    """Explicit namespaces: natural/BODE cache and separate T-domain sidecar."""
    dataset = record["dataset"]
    if dataset == "natural":
        return runtime.store.base.vector
    require(dataset in ("bode1", "bode2", "tdomain"), "Unknown feature namespace")
    runtime.store.select_dataset(dataset)
    return runtime.store.vector


def _cached_prediction(runtime, record, plan, cache):
    from context_plans import masked_batch, tensor_signature
    from frozen_scoring import predict_mode
    import torch

    require(plan["status"] == "READY", "Inference requires a READY mask plan")
    require(not runtime.model.training, "Frozen inference requires model.eval()")
    require(plan.get("targets"), "Mask plan has no targets")
    # Model inputs/provenance only; labels must not affect identity or inference.
    fields = ("assembly_id", "dataset", "route", "model_slots",
              "parent_sequence_hashes", "parent_lengths", "boundary_window_policy")
    record_sha = canonical({k: record[k] for k in fields if k in record})
    key = (record["dataset"], record["assembly_id"], record_sha, canonical(plan))
    if key in cache:
        return cache[key]
    lookup = feature_lookup(runtime, record)
    batch = masked_batch(record, plan, runtime.collate, lookup)
    signature = tensor_signature(batch)
    batch = {k: v.to(runtime.device) for k, v in batch.items()}
    predictions = {}
    with torch.inference_mode():
        for mode in MODES:
            value = predict_mode(runtime.model, batch, local=(mode == "local"))
            require(bool(torch.isfinite(value).all()), "Nonfinite reconstructed embedding")
            predictions[mode] = {}
            for j in plan["targets"]:
                row = value[0, j].detach().cpu().numpy().copy()
                row.setflags(write=False)
                predictions[mode][j] = row
    result = {"signature": signature, "predictions": predictions}
    cache[key] = result
    return result


def _object_contract(record, j, slots):
    obj = record["route"][j]
    kind = obj["kind"]
    types = ([obj["domain_type"]] if kind == 0 else
             [record["route"][j - 1]["domain_type"],
              record["route"][j + 1]["domain_type"]])
    return kind, types, [(s["slot"], s["group"]) for s in slots]


def score_query(runtime, source_record, source_plan, match_result,
                natural_records, prediction_cache):
    """Return JSON-safe losses/benefits for every source-plan primary object.

    match_result['candidates'] contains assembly_id, component_id, offset and
    plan. Mapping is source object j -> donor object j + offset. Every candidate
    is scored against the ORIGINAL source vectors/means. Alternative error
    lists follow the order of output['alternatives']; higher context_benefit
    (median alternative error minus original error) favors the original context.
    Below eight candidates the source error is retained and benefit is null.
    Prediction cache holds immutable CPU arrays, indexed by input and mask identity.
    """
    import torch
    from context_plans import slots_by_object

    candidates = match_result.get("candidates", [])
    result = dict(assembly_id=source_record["assembly_id"],
                  status="PENDING", match_status=match_result.get("status"),
                  minimum_alternatives=MIN_ALTERNATIVES,
                  available_alternatives=len(candidates),
                  source_input_signature=None, alternatives=[], objects={})
    if source_plan["status"] != "READY":
        result["status"] = "SOURCE_" + source_plan["status"]
        return result
    require(len({(c["assembly_id"], c["offset"]) for c in candidates}) == len(candidates),
            "Duplicate alternative context")
    source_slots = slots_by_object(source_record)
    source_lookup = feature_lookup(runtime, source_record)
    original_targets = {}
    for j in source_plan["targets"]:
        ss = source_slots[j]
        require(all(s["state"] == "OBSERVED" for s in ss), "Source target must be observed")
        roles = [s["slot"] for s in ss]
        require(roles == ([1, 2] if source_record["route"][j]["kind"] == 2 else [0]),
                "Unexpected physical-object roles")
        target = np.stack([source_lookup(s["sequence_hash"]) for s in ss])
        mean = np.stack([runtime.targets.mean(s) for s in ss])
        require(target.shape == mean.shape and np.isfinite(target).all()
                and np.isfinite(mean).all(), "Invalid original target or mean")
        original_targets[j] = (roles, torch.as_tensor(target, device=runtime.device),
                               torch.as_tensor(mean, device=runtime.device))
    source = _cached_prediction(runtime, source_record, source_plan, prediction_cache)
    result["source_input_signature"] = source["signature"]
    for j, (roles, target, mean) in original_targets.items():
        obj = dict(object_index=j, kind=source_record["route"][j]["kind"],
                   roles=roles, source_sequence_hashes=[s["sequence_hash"] for s in source_slots[j]],
                   loss_reduction="mean_original_role_losses")
        with torch.inference_mode():
            for mode in MODES:
                pred = torch.as_tensor(source["predictions"][mode][j][roles].copy(),
                                       device=runtime.device)
                loss, _ = runtime.ssl.slot_loss(pred, target, mean)
                error = float(loss.mean().item())
                require(np.isfinite(error), "Nonfinite original error")
                obj[mode] = dict(original_error=error, median_alternative_error=None,
                                 context_benefit=None, alternative_errors=[])
        result["objects"][str(j)] = obj
    seen_signatures = {source["signature"]}
    for candidate in candidates:
        aid, offset = candidate["assembly_id"], candidate["offset"]
        require(type(offset) is int and aid in natural_records, "Invalid alternative mapping")
        record = natural_records[aid]
        require(record["dataset"] == "natural", "Alternative context must be natural")
        plan = candidate["plan"]
        require(plan["status"] == "READY", "Unready matched context")
        by = slots_by_object(record)
        for j in original_targets:
            k = j + offset
            require(k in plan["targets"] and k in by, "Matched target absent from donor plan")
            require(_object_contract(source_record, j, source_slots[j]) ==
                    _object_contract(record, k, by[k]), "Matched target kind, type or roles differ")
        alternate = _cached_prediction(runtime, record, plan, prediction_cache)
        require(alternate["signature"] not in seen_signatures,
                "Alternative input duplicates the source or another alternative")
        seen_signatures.add(alternate["signature"])
        result["alternatives"].append(dict(assembly_id=aid,
                                            component_id=candidate["component_id"],
                                            offset=offset,
                                            plan=plan,
                                            input_signature=alternate["signature"]))
        with torch.inference_mode():
            for j, (roles, target, mean) in original_targets.items():
                for mode in MODES:
                    pred = torch.as_tensor(alternate["predictions"][mode][j + offset][roles].copy(),
                                           device=runtime.device)
                    loss, _ = runtime.ssl.slot_loss(pred, target, mean)
                    error = float(loss.mean().item())
                    require(np.isfinite(error), "Nonfinite alternative error")
                    result["objects"][str(j)][mode]["alternative_errors"].append(error)
    eligible = len(candidates) >= MIN_ALTERNATIVES
    result["status"] = "SCORED" if eligible else "INSUFFICIENT_MATCHED_CONTEXTS"
    for obj in result["objects"].values():
        for mode in MODES:
            values = obj[mode]["alternative_errors"]
            if values:
                median = float(np.median(values))
                obj[mode]["median_alternative_error"] = median
                if eligible:
                    obj[mode]["context_benefit"] = median - obj[mode]["original_error"]
    # This also verifies absence of NaN, tensors and NumPy scalars in the export.
    json.dumps(result, allow_nan=False)
    return result
