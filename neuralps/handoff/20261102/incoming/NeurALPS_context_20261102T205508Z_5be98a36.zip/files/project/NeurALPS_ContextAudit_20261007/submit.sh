#!/usr/bin/env bash
set -euo pipefail
NRPS_AUDIT_PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [ "$#" -eq 0 ]; then
    set -- run
fi
exec python3 -B "$NRPS_AUDIT_PACKAGE/launch.py" "$@"
