#!/usr/bin/env python3
"""Submit, inspect, or explicitly resume the frozen NeurALPS context audit."""
import argparse
from collections import Counter, deque
from datetime import datetime, timezone
import fcntl
import getpass
from pathlib import Path
import re
import subprocess
import sys
import uuid

from ca_common import PACKAGE, VERSION, canonical, dump, load, preflight, require, sha

PREFIX = 'e12_context_audit'
COMPLETE = 'CONTEXT_AUDIT_COMPLETE'


def now():
    return datetime.now(timezone.utc).isoformat()


def sbatch_command(root, request, intent, resume=None):
    log = root / (PREFIX + '_%j.log')
    cmd = [
        'sbatch', '--parsable', '--job-name=nrps_ctxaudit_' + intent[:8],
        '--account=nef@a100', '--partition=gpu_p5', '--qos=qos_gpu_a100-t3',
        '--nodes=1', '--ntasks=1', '--cpus-per-task=8', '--hint=nomultithread',
        '--gres=gpu:1', '--constraint=a100', '--time=02:00:00',
        '--signal=B:USR1@180', '--no-requeue', '--propagate=NONE',
        '--chdir=' + str(root), '--output=' + str(log), '--error=' + str(log),
        str(PACKAGE / 'batch.sh'), str(PACKAGE), str(root), str(request),
    ]
    if resume is not None:
        cmd.append(str(resume))
    return cmd, log


def submissions(history):
    rows = [load(p) for p in history.glob('*.json')]
    for row in rows:
        require(str(row.get('job_id', '')).isdigit(), 'Invalid submission history row')
    return sorted(rows, key=lambda row: int(row['job_id']))


def status(info):
    job = str(info['job_id'])
    try:
        result = subprocess.run(
            ['sacct', '-j', job, '--format=JobID,JobName%28,State,ExitCode,Elapsed'],
            capture_output=True, text=True, check=False,
        )
        if result.stdout.strip():
            print(result.stdout.rstrip(), flush=True)
        if result.returncode or result.stderr.strip():
            print('Scheduler status:', result.stderr.strip() or 'sacct returned no status', flush=True)
    except OSError as exc:
        print('Scheduler status unavailable:', exc, flush=True)
    out = Path(info['output'])
    print('Job:', job, flush=True)
    print('Output:', out, flush=True)
    print('Log:', info['log'], flush=True)
    print('Request:', info['request'], flush=True)
    if (out / COMPLETE).is_file() and (out / 'summary.json').is_file():
        print((out / 'summary.json').read_text(), flush=True)
        inspection = out / 'context_audit_inspection.zip'
        if inspection.is_file():
            print('Inspection:', inspection, flush=True)
    else:
        report = next((out / name for name in ('fatal_error.json', 'pause.json', 'summary.json')
                       if (out / name).is_file()), None)
        if report is not None:
            print(report.read_text(), flush=True)
        log = Path(info['log'])
        if log.is_file():
            with log.open(errors='replace') as handle:
                print(''.join(deque(handle, maxlen=25)).rstrip(), flush=True)
        elif report is None:
            print('The job has not created a log or report yet.', flush=True)


def queue_jobs():
    result = subprocess.run(
        ['squeue', '-h', '-u', getpass.getuser(), '-o', '%i'],
        capture_output=True, text=True, check=False,
    )
    require(result.returncode == 0, 'Cannot establish active jobs; no submission was attempted.\n' + result.stderr.strip())
    return set(result.stdout.split())


def immutable_request(root, request, intent):
    directory = root / (PREFIX + '_requests')
    directory.mkdir(exist_ok=True)
    path = directory / (intent + '.json')
    digest_path = path.with_suffix('.json.sha256')
    if path.exists():
        require(load(path) == request, 'Stored immutable request differs from the current preflight')
        require(digest_path.is_file(), 'Stored request has no checksum; inspect before submitting')
        require(digest_path.read_text().strip() == sha(path), 'Stored immutable request checksum changed')
    else:
        require(not digest_path.exists(), 'Request checksum exists without its request file')
        dump(path, request)
        with digest_path.open('x') as handle:
            handle.write(sha(path) + '\n')
        path.chmod(0o444)
        digest_path.chmod(0o444)
    return path, sha(path)


def audit_counts(records, regions, request):
    values = records.values() if isinstance(records, dict) else records
    counts = Counter(str(record.get('dataset', 'unspecified')) for record in values)
    print('Frozen context audit:', VERSION, flush=True)
    print('Input assemblies:', len(records), '| regions:', len(regions), flush=True)
    print('Assemblies by dataset:', dict(sorted(counts.items())), flush=True)
    print('Request intent:', canonical(request), flush=True)
    print('No training updates or activity-classifier fitting.', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('run', 'preflight', 'status', 'resume'))
    parser.add_argument('output', nargs='?', type=Path)
    parser.add_argument('--root', type=Path, default=PACKAGE.parent)
    args = parser.parse_args()
    root = args.root.resolve()
    require(root.is_dir(), 'Project root does not exist: ' + str(root))
    latest = root / (PREFIX + '_latest.json')
    history = root / (PREFIX + '_submissions')
    attempts = root / (PREFIX + '_attempts')
    if args.action == 'status':
        if args.output is None:
            require(latest.is_file(), 'No context-audit job has been submitted yet')
            info = load(latest)
        else:
            matched = [row for row in submissions(history) if Path(row['output']).resolve() == args.output.resolve()]
            require(matched, 'Unknown context-audit output: ' + str(args.output))
            info = matched[-1]
        status(info)
        return
    if args.action == 'preflight':
        require(args.output is None, 'Preflight takes no output path')
        _, records, regions, request = preflight(root)
        audit_counts(records, regions, request)
        return
    with (root / (PREFIX + '_submission.lock')).open('a') as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('Another context-audit submission command is running; no job was submitted')
        rows = submissions(history)
        previous = None
        resume = None
        if args.action == 'resume':
            require(args.output is not None, 'Resume requires the original paused/failed output path')
            resume = args.output.resolve()
            require(resume.parent == root and re.fullmatch(PREFIX + r'_\d+', resume.name),
                    'Resume must use an original e12_context_audit_JOBID directory in this project')
            matched = [row for row in rows if Path(row['output']).resolve() == resume]
            require(matched, 'Unknown resume output; no new job was submitted')
            previous = matched[-1]
            require(not (resume / COMPLETE).exists(), 'This output is already complete; use status')
        else:
            require(args.output is None, 'A new output directory is assigned from the Slurm job ID')
        _, records, regions, request = preflight(root)
        intent = canonical(request)
        require(re.fullmatch(r'[0-9a-f]{64}', intent), 'Preflight intent is not a SHA-256 digest')
        if previous is not None:
            require(previous['intent'] == intent, 'Resume inputs or protocol changed; refusing to modify the old output')
        same_intent = [row for row in rows if row['intent'] == intent]
        if resume is None:
            completed = [row for row in same_intent if (Path(row['output']) / COMPLETE).is_file()]
            if completed:
                print('This exact context-audit request is already complete; no job was submitted.', flush=True)
                status(completed[-1])
                return
        active = queue_jobs()
        running = [row for row in rows if str(row['job_id']) in active]
        if running:
            same = [row for row in running if row['intent'] == intent]
            if same and resume is None:
                print('This exact context-audit request is already pending/running; no duplicate was submitted.', flush=True)
                status(same[-1])
                return
            raise RuntimeError('A context-audit job is already pending/running: ' + ', '.join(str(row['job_id']) for row in running))
        for path in attempts.glob('*.json'):
            attempt = load(path)
            require(attempt.get('state') not in ('SUBMISSION_IN_PROGRESS', 'SUBMISSION_UNCERTAIN'),
                    'An earlier sbatch result is unresolved. Inspect squeue and ' + str(path) + ' before retrying; no job was submitted')
        if resume is None and same_intent:
            old = same_intent[-1]
            raise RuntimeError('This exact request already has an attempt. Inspect it with status, then explicitly resume: '
                               + 'bash ' + str(PACKAGE / 'submit.sh') + ' resume ' + old['output'])
        request_path, request_sha = immutable_request(root, request, intent)
        audit_counts(records, regions, request)
        cmd, log_template = sbatch_command(root, request_path, intent, resume)
        attempts.mkdir(exist_ok=True)
        attempt_path = attempts / (intent + '_' + uuid.uuid4().hex + '.json')
        attempt = dict(version=VERSION, state='SUBMISSION_IN_PROGRESS', created_at=now(), intent=intent,
                       request=str(request_path), request_sha256=request_sha, command=cmd,
                       resume_output=str(resume) if resume is not None else None)
        dump(attempt_path, attempt)
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        except OSError as exc:
            attempt.update(state='SUBMISSION_FAILED', finished_at=now(), error=str(exc))
            dump(attempt_path, attempt)
            raise RuntimeError('Could not invoke sbatch; no job was recorded.\n' + str(exc))
        attempt.update(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr, finished_at=now())
        if result.returncode:
            attempt['state'] = 'SUBMISSION_FAILED'
            dump(attempt_path, attempt)
            raise RuntimeError('Slurm rejected the submission; no job was recorded.\n'
                               + (result.stderr.strip() or result.stdout.strip() or 'sbatch exit code ' + str(result.returncode)))
        response = result.stdout.strip()
        if not re.fullmatch(r'\d+(?:;[A-Za-z0-9_.-]+)?', response):
            attempt['state'] = 'SUBMISSION_UNCERTAIN'
            dump(attempt_path, attempt)
            raise RuntimeError('sbatch returned an unexpected response. Inspect squeue before retrying; no job ID was recorded.\n'
                               + response + '\nSubmission record: ' + str(attempt_path))
        job = response.split(';', 1)[0]
        out = resume if resume is not None else root / (PREFIX + '_' + job)
        info = dict(version=VERSION, job_id=job, output=str(out), intent=intent,
                    request=str(request_path), request_sha256=request_sha,
                    log=str(log_template).replace('%j', job), resumed=resume is not None,
                    submitted_at=now(), previous_job_id=previous['job_id'] if previous else None,
                    attempt_record=str(attempt_path))
        history.mkdir(exist_ok=True)
        dump(history / (job + '.json'), info)
        dump(latest, info)
        attempt.update(state='SUBMITTED', job_id=job, output=str(out))
        dump(attempt_path, attempt)
        if result.stderr.strip():
            print(result.stderr.strip(), flush=True)
        print('Submitted one-A100 frozen context audit:', job, flush=True)
        print('Output:', out, flush=True)
        print('Log:', info['log'], flush=True)
        print('Status: bash', PACKAGE / 'status.sh', flush=True)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError) as exc:
        print('CONTEXT_AUDIT_LAUNCH_ERROR:', exc, file=sys.stderr, flush=True)
        sys.exit(1)
