"""Unchanged encoder/loss; fresh masks, no classifier and no optimizer."""
from collections import defaultdict
import gzip
import hashlib
from pathlib import Path
from types import SimpleNamespace
import numpy as np

from ca_common import (require, sha, sidecar_index, emit, CHECKPOINT_SHA, TDOMAIN_RUN)
from context_plans import slots_by_object, masked_batch, tensor_signature


class SidecarStore:
    """Keep T-domain features separate; never overwrite the original cache."""
    def __init__(self, base, sidecar):
        self.base = base
        self.dataset = None
        self.parents = {}
        seq = []
        def finish():
            if not seq:
                return
            value = ''.join(seq)
            key = hashlib.sha256(value.encode()).hexdigest()
            require(key not in self.parents or self.parents[key] == value, 'Parent hash collision')
            self.parents[key] = value
        with gzip.open(sidecar / 'inputs/parents.fasta.gz', 'rt') as f:
            for line in f:
                line = line.strip()
                if line.startswith('>'):
                    finish()
                    seq = []
                elif line:
                    seq.append(line)
            finish()
        require(len(self.parents) == 88, 'Expected 88 independent T-domain parents')
        self.rows = sidecar_index(sidecar)
        self.z = np.memmap(sidecar / 'features.f32', mode='r', dtype='<f4', shape=(290, 1152))
        require(np.isfinite(self.z).all() and (np.linalg.norm(self.z, axis=1) > 0).all(), 'Invalid sidecar vectors')

    def select_dataset(self, dataset):
        require(dataset in ('bode1', 'bode2', 'tdomain'), 'Unknown feature namespace')
        self.dataset = dataset

    def vector(self, key):
        require(self.dataset is not None, 'Select frozen feature namespace before lookup')
        if self.dataset == 'tdomain':
            require(key in self.rows, 'T-domain feature absent from its pinned sidecar')
            return np.array(self.z[self.rows[key]], copy=True)
        return self.base.vector(key)

    def parent(self, key):
        return self.parents[key] if key in self.parents else self.base.parent(key)


def open_frozen(ctx, records, device='cuda'):
    import torch
    import common
    from source_contract import validate_loaded_checkpoints
    ssl = common.module('nrps_context_original_ssl', ctx['base'] / 'run_ssl.py')
    from assembly_model import AssemblyEncoder, Config, collate_records
    from masking_contract import masking_closure
    ram = common.module('nrps_context_ram_io', ctx['ram'] / 'ram_io.py')
    base = ssl.Store(ctx['root'])
    emit('LOADING_FROZEN_FEATURES')
    base.z = ram.load_checked_f32(base.cache / 'features.f32', (548713, 1152), common.FEATURE_SHA)
    store = SidecarStore(base, ctx['root'] / TDOMAIN_RUN)
    targets = ssl.Targets(SimpleNamespace(assets=ctx['assets'], settings={'object_loss': 'centered'}), base)
    require(sha(ctx['ssl_run'] / 'best.pt') == CHECKPOINT_SHA, 'SSL26 checkpoint changed')
    require(sha(ctx['ssl_run'] / 'initial.pt') == ctx['source_provenance']['initial_checkpoint_sha256'],
            'Initial checkpoint changed')
    saved = torch.load(ctx['ssl_run'] / 'best.pt', map_location='cpu', weights_only=False)
    initial = torch.load(ctx['ssl_run'] / 'initial.pt', map_location='cpu', weights_only=False)
    validate_loaded_checkpoints(ctx, saved, initial)
    require(saved['targets_manifest'] == targets.manifest, 'Natural training means differ')
    model = AssemblyEncoder(Config(**ctx['config']['settings']['encoder']))
    model.load_state_dict(saved['model'], strict=True)
    model.to(device).eval()
    for p in model.parameters():
        p.requires_grad_(False)
    require(sha(ctx['ssl_run'] / 'best.pt') == CHECKPOINT_SHA, 'Checkpoint changed during load')
    del saved, initial
    for rec in records.values():
        store.select_dataset(rec['dataset'])
        for s in rec['model_slots']:
            if s['state'] == 'OBSERVED':
                sequence = store.parent(s['parent_sequence_hash'])[s['start']:s['end']]
                require(len(sequence) == s['length'] and hashlib.sha256(sequence.encode()).hexdigest() == s['sequence_hash'],
                        'Physical feature sequence mismatch: ' + rec['assembly_id'])
                v = store.vector(s['sequence_hash'])
                require(v.shape == (1152,) and np.isfinite(v).all() and np.linalg.norm(v) > 0, 'Invalid frozen feature')
    return SimpleNamespace(model=model, store=store, targets=targets, ssl=ssl,
                           closure=masking_closure, collate=collate_records, device=device)


def predict_mode(model, batch, local=False):
    """Exact original decoder, with only the global blocks optionally disabled."""
    import torch
    if not local:
        return model.predict_masked(batch)
    require(bool(((batch['state'] == 4) & batch['valid'].unsqueeze(-1)).any()), 'Explicit mask required')
    h = model.features(batch, context=False)
    b, t, _ = h.shape
    roles = model.decoder_role(torch.arange(3, device=h.device))[None, None].expand(b, t, -1, -1)
    kinds = model.decoder_kind(batch['kind']).unsqueeze(2).expand(-1, -1, 3, -1)
    pred = model.decoder(torch.cat([h.unsqueeze(2).expand(-1, -1, 3, -1), roles, kinds], dim=-1))
    return torch.where(batch['valid'][:, :, None, None], pred, torch.zeros_like(pred))


def score_vectors(runtime, record, plan, predictions):
    """Average terminal slots once per physical object, using original slot_loss."""
    import torch
    by = slots_by_object(record)
    scores = {}
    for j in plan['targets']:
        slots = by[j]
        roles = [s['slot'] for s in slots]
        targets = torch.as_tensor(np.stack([runtime.store.vector(s['sequence_hash']) for s in slots]), device=runtime.device)
        means = torch.as_tensor(np.stack([runtime.targets.mean(s) for s in slots]), device=runtime.device)
        value = {}
        for mode, prediction in predictions.items():
            pred = torch.as_tensor(prediction[j], device=runtime.device)[roles]
            loss, raw = runtime.ssl.slot_loss(pred, targets, means)
            score = float((1 - loss.mean()).item())
            require(np.isfinite(score) and -1.00001 <= score <= 1.00001, 'Invalid reconstruction agreement')
            value[mode] = score
        scores[str(j)] = value
    return scores


def type_scores(runtime, record, target_indices):
    import torch
    result = {}
    by = slots_by_object(record)
    for j in sorted(target_indices):
        slots = by[j]
        if any(s['state'] != 'OBSERVED' for s in slots):
            result[str(j)] = None
            continue
        target = torch.as_tensor(np.stack([runtime.store.vector(s['sequence_hash']) for s in slots]), device=runtime.device)
        mean = torch.as_tensor(np.stack([runtime.targets.mean(s) for s in slots]), device=runtime.device)
        loss, _ = runtime.ssl.slot_loss(mean, target, mean)
        result[str(j)] = float((1 - loss.mean()).item())
    return result


def score_assembly(runtime, record, queries, common_cache, stopping=None, microbatch=8):
    """Queries contain plans only; activity outcomes have no code path here."""
    import torch
    runtime.store.select_dataset(record['dataset'])
    output, pending = {}, []

    def finish(qid, plan, signature, pred):
        scores = score_vectors(runtime, record, plan, pred)
        output[qid] = dict(status='SCORED', context_signature=signature, objects=scores)

    def flush():
        if not pending:
            return
        batch = runtime.collate([record] * len(pending), runtime.store.vector)
        for b, (_, plan, _) in enumerate(pending):
            for j, role in plan['hidden']:
                batch['state'][b, j, role] = 4
                batch['x'][b, j, role] = float('nan')
        batch = {k: v.to(runtime.device) for k, v in batch.items()}
        with torch.inference_mode():
            full = predict_mode(runtime.model, batch)
            local = predict_mode(runtime.model, batch, local=True)
        require(bool(torch.isfinite(full).all() and torch.isfinite(local).all()), 'Nonfinite predicted embeddings')
        for b, (qid, plan, signature) in enumerate(pending):
            pred = {mode: {j: tensor[b, j].detach().cpu().numpy().copy() for j in plan['targets']}
                    for mode, tensor in (('full', full), ('local', local))}
            if plan.get('common_group_id'):
                key = (signature, tuple(plan['targets']))
                if key in common_cache:
                    cached = common_cache[key]
                    for mode in pred:
                        for j in pred[mode]:
                            require(np.allclose(pred[mode][j], cached[mode][j], atol=2e-5, rtol=2e-5),
                                    'Identical common inputs reconstructed differently')
                    pred = cached
                else:
                    common_cache[key] = pred
            finish(qid, plan, signature, pred)
        pending.clear()

    for qid, plan in queries.items():
        if stopping and stopping.get('signal'):
            return None
        if plan['status'] != 'READY':
            output[qid] = dict(status=plan['status'], context_signature=None, objects={})
            continue
        one = masked_batch(record, plan, runtime.collate, runtime.store.vector)
        signature = tensor_signature(one)
        key = (signature, tuple(plan['targets']))
        if plan.get('common_group_id') and key in common_cache:
            finish(qid, plan, signature, common_cache[key])
        else:
            pending.append((qid, plan, signature))
            if len(pending) >= microbatch:
                flush()
    flush()
    targets = {j for p in queries.values() for j in p['targets']}
    return dict(queries=output, type_mean=type_scores(runtime, record, targets))


def aggregate(scores, region):
    ds, bs = region['domain_indices'], region['boundary_indices']
    vals = [scores.get(str(j)) for j in ds + bs]
    if any(v is None or not np.isfinite(v) for v in vals):
        return dict(domains=None, boundaries=None, balanced=None, neighborhood_mean=None)
    d = float(np.mean([scores[str(j)] for j in ds]))
    b = float(np.mean([scores[str(j)] for j in bs]))
    return dict(domains=d, boundaries=b, balanced=.5*(d+b), neighborhood_mean=float(np.mean(vals)))
