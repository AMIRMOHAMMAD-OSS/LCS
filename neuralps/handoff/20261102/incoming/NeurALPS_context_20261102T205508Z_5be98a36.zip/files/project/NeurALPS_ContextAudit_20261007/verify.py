#!/usr/bin/env python3
"""Verify this complete release using only the Python standard library."""
import ast
from pathlib import Path
import subprocess
from ca_common import PACKAGE, emit, load, require, sha, verify_tree


def main():
    digest = verify_tree(PACKAGE)
    names = [line.split('  ', 1)[1] for line in (PACKAGE / 'SHA256SUMS').read_text().splitlines()]
    for name in names:
        path = PACKAGE / name
        if path.suffix == '.py':
            ast.parse(path.read_text(), filename=name)
        elif path.suffix == '.sh':
            subprocess.run(['bash', '-n', str(path)], check=True)
    provenance = load(PACKAGE / 'data/provenance.json')
    for name, expected in provenance['files_sha256'].items():
        require(sha(PACKAGE / 'data' / name) == expected, 'Data snapshot changed: ' + name)
    emit('CONTEXT_AUDIT_BUNDLE_OK', files=len(names), package_sha256=digest,
         training_updates=0, activity_classifier_fits=0)


if __name__ == '__main__':
    main()
