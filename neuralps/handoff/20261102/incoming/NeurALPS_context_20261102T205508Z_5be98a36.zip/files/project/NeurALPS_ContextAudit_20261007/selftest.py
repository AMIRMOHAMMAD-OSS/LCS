#!/usr/bin/env python3
"""Focused CPU contracts using original model/loss and synthetic sequence features.

No real checkpoint, production embeddings, activity outcomes or GPU are loaded.
Run: python selftest.py --root /path/to/NeurALPSv2
"""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import sys

import numpy as np
import torch

PACKAGE = Path(__file__).resolve().parent
DIM = 8


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


class FakeStore:
    def __init__(self):
        self.parents, self.vectors = {}, {}
        self.dataset = None

    def select_dataset(self, dataset):
        assert dataset in ('bode1', 'bode2', 'tdomain')
        self.dataset = dataset

    def parent(self, key):
        return self.parents[key]

    def vector(self, key):
        assert self.dataset is not None
        return self.vectors[key].copy()

    def feature(self, sequence):
        key = digest(sequence)
        if key not in self.vectors:
            rng = np.random.default_rng(int(key[:16], 16))
            self.vectors[key] = rng.normal(size=DIM).astype(np.float32)
        return key


class FakeTargets:
    def mean(self, slot):
        rng = np.random.default_rng(int(digest(slot['group'])[:16], 16))
        return (rng.normal(size=DIM) * .2).astype(np.float32)


def record(store, aid, sequence, dataset='bode1'):
    parent = digest(sequence)
    store.parents[parent] = sequence
    n = len(sequence) // 20
    route, slots = [], []
    for j in range(2*n-1):
        kind = j % 2
        if kind == 0:
            start, end = (j//2)*20, (j//2+1)*20
        else:
            start, end = (j//2+1)*20-3, (j//2+1)*20+3
        route.append(dict(kind=kind, domain_type=1 if kind == 0 else 0, chain=0))
        slots.append(dict(object_index=j, slot=0, kind=kind, state='OBSERVED',
            sequence_hash=store.feature(sequence[start:end]), parent_sequence_hash=parent,
            protein_uid=aid+'|p0', start=start, end=end, length=end-start,
            group='D:1' if kind == 0 else 'C:1:1'))
    return dict(assembly_id=aid, dataset=dataset, split='synthetic_only', route=route,
                model_slots=slots, parent_sequence_hashes={'p0':parent}, parent_lengths={'p0':len(sequence)})


def region(rec, rid, domain=6, background='same_background'):
    return dict(assembly_id=rec['assembly_id'], dataset=rec['dataset'], region_id=rid,
                domain_indices=[domain], boundary_indices=[domain-1, domain+1],
                background_id=background)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=PACKAGE.parent)
    args = parser.parse_args()
    base = args.root.resolve() / 'NeurALPS_Assembly_v1_20261002'
    assert (base/'src/assembly_model.py').is_file(), 'Original Assembly package not found'
    sys.path.insert(0, str(base/'src'))
    from assembly_model import AssemblyEncoder, Config, collate_records
    from masking_contract import masking_closure
    ssl = load_module('context_selftest_original_ssl', base/'run_ssl.py')
    from context_plans import (build_plans, make_plan, masked_batch, tensor_signature,
                               validate_regions, piece_signature)
    from frozen_scoring import (predict_mode, score_assembly, score_vectors, type_scores,
                                aggregate, SidecarStore)

    torch.set_num_threads(1)
    torch.manual_seed(211)
    model = AssemblyEncoder(Config(feature_dim=DIM, width=16, heads=4, dropout=0)).eval()
    # Initial global writes are zero. Exercise genuine full/local differences.
    with torch.no_grad():
        for block in model.global_blocks:
            block.write.out_proj.weight.normal_(0, .03)
            block.h_ff[3].weight.normal_(0, .03)
    store = FakeStore()
    rng = np.random.default_rng(144)
    alphabet = np.array(list('ACDEFGHIKLMNPQRSTVWY'))
    seq = ''.join(rng.choice(alphabet, size=140))
    changed = seq[:60] + ''.join(rng.choice(alphabet, size=20)) + seq[80:]
    a, b = record(store, 'a', seq), record(store, 'b', changed)
    ra, rb = region(a, 'ra'), region(b, 'rb')
    store.select_dataset('bode1')
    collate = lambda records, lookup: collate_records(records, lookup, feature_dim=DIM)
    runtime = SimpleNamespace(model=model, store=store, targets=FakeTargets(), ssl=ssl,
                              device='cpu', collate=collate, closure=masking_closure)
    checks, differences = [], []

    def close(name, left, right, atol=2e-6):
        left, right = np.asarray(left), np.asarray(right)
        value = float(np.max(np.abs(left-right))) if left.size else 0.
        assert np.allclose(left, right, atol=atol, rtol=atol), (name, value)
        checks.append(name)
        differences.append(value)

    def assertion(name, value):
        assert value, name
        checks.append(name)

    validate_regions({'a':a, 'b':b}, [ra, rb])
    plans = build_plans({'a':a, 'b':b}, [ra, rb], store.parent, masking_closure)
    single = plans['single']['a|object=6']
    joint = plans['joint']['ra']
    assertion('individual_overlap_closure', single['hidden'] == [(5,0),(6,0),(7,0)])
    assertion('joint_overlap_closure_nonrecursive', joint['hidden'] == [(4,0),(5,0),(6,0),(7,0),(8,0)])
    own_union = set().union(*(set(map(tuple, masking_closure(a, [(j,0)], store.parent,
                           'independent_sequence')['hidden'])) for j in [5,6,7]))
    assertion('joint_is_union_of_primary_closures', set(joint['hidden']) == own_union)
    alias_seq = seq[:100] + seq[60:80] + seq[120:]
    alias = record(store, 'alias', alias_seq)
    alias_plan = make_plan(alias, [6], store.parent, masking_closure)
    assertion('exact_copy_and_overlap_closure', set(alias_plan['hidden']) ==
              {(5,0),(6,0),(7,0),(9,0),(10,0),(11,0)})

    batch = masked_batch(a, single, collate, store.vector)
    with torch.inference_mode():
        full = predict_mode(model, batch)
        local = predict_mode(model, batch, local=True)
        close('full_original_decoder_parity', full.numpy(), model.predict_masked(batch).numpy(), 0)
        h = model.features(batch, context=False)
        nr, nt, _ = h.shape
        roles = model.decoder_role(torch.arange(3))[None,None].expand(nr,nt,-1,-1)
        kinds = model.decoder_kind(batch['kind']).unsqueeze(2).expand(-1,-1,3,-1)
        manual_local = model.decoder(torch.cat([h.unsqueeze(2).expand(-1,-1,3,-1),roles,kinds],dim=-1))
        manual_local = torch.where(batch['valid'][:,:,None,None], manual_local, torch.zeros_like(manual_local))
        close('local_original_decoder_parity', local.numpy(), manual_local.numpy(), 0)
        assertion('global_ablation_test_is_nonvacuous', float((full-local).abs().max()) > 1e-6)
        poisoned = {k:v.clone() for k,v in batch.items()}
        poisoned['x'][poisoned['state']==4] = 1e20
        close('hidden_value_poisoning_full', full.numpy(), predict_mode(model, poisoned).numpy(), 0)
        close('hidden_value_poisoning_local', local.numpy(), predict_mode(model, poisoned, True).numpy(), 0)
        assertion('masked_tensor_hash_poisoning_invariant', tensor_signature(batch)==tensor_signature(poisoned))

    scored = score_assembly(runtime, a, {'single':single}, {})
    slot = a['model_slots'][6]
    target = torch.tensor(store.vector(slot['sequence_hash']))
    mean = torch.tensor(runtime.targets.mean(slot))
    for mode, pred in [('full',full),('local',local)]:
        loss, _ = ssl.slot_loss(pred[0,6,0], target, mean)
        close('individual_manual_loss_parity_'+mode,
              scored['queries']['single']['objects']['6'][mode], (1-loss).item())

    common_a, common_b = plans['joint_common']['ra'], plans['joint_common']['rb']
    assertion('common_group_ready', common_a['status']==common_b['status']=='READY')
    ba, bb = (masked_batch(rec, plan, collate, store.vector)
              for rec,plan in [(a,common_a),(b,common_b)])
    assertion('different_candidates_common_input_tensor_equality', tensor_signature(ba)==tensor_signature(bb))
    with torch.inference_mode():
        close('common_input_reconstruction_equality', predict_mode(model,ba).numpy(), predict_mode(model,bb).numpy(),0)
    feature_calls = [0]
    original_features = model.features
    def counted_features(*args, **kwargs):
        feature_calls[0] += 1
        return original_features(*args, **kwargs)
    model.features = counted_features
    cache = {}
    sa = score_assembly(runtime,a,{'common':common_a},cache)
    before = feature_calls[0]
    sb = score_assembly(runtime,b,{'common':common_b},cache)
    assertion('common_prediction_cache_reused', before==feature_calls[0] and len(cache)==1)
    model.features = original_features
    assertion('common_prediction_candidate_targets_remain_distinct',
              sa['queries']['common']['objects']['6']['full'] != sb['queries']['common']['objects']['6']['full'])

    # Candidate-specific exact aliases enlarge only the common intervention.
    alias_a = record(store, 'alias_a', seq[:60] + seq[100:120] + seq[80:])
    alias_b = record(store, 'alias_b', changed)
    alias_plans = build_plans({'alias_a':alias_a,'alias_b':alias_b},
        [region(alias_a,'alias_ra'),region(alias_b,'alias_rb')],store.parent,masking_closure)
    union = set(alias_plans['joint_common']['alias_ra']['hidden'])
    assertion('common_union_includes_candidate_specific_aliases',
        set(alias_plans['joint']['alias_ra']['hidden']) <= union
        and set(alias_plans['joint']['alias_rb']['hidden']) < union
        and (10,0) in union)
    alias_batches = [masked_batch(rec,alias_plans['joint_common'][rid],collate,store.vector)
                     for rec,rid in [(alias_a,'alias_ra'),(alias_b,'alias_rb')]]
    assertion('alias_union_restores_common_input_equality',
        tensor_signature(alias_batches[0])==tensor_signature(alias_batches[1])
        and all(p['status']=='READY' for p in alias_plans['joint_common'].values()))

    # Different visible background must not be silently erased to make a match.
    other_seq = 'W' + changed[1:]
    if other_seq == changed:
        other_seq = 'A' + changed[1:]
    other = record(store, 'other', other_seq)
    other_plans = build_plans({'a':a,'other':other},[ra,region(other,'ro')],store.parent,masking_closure)
    assertion('nonidentical_background_rejected', all(p['status']=='NONIDENTICAL_BACKGROUND'
              for p in other_plans['joint_common'].values()))
    one = build_plans({'a':a},[ra],store.parent,masking_closure)
    assertion('singleton_common_group_rejected', one['joint_common']['ra']['status']=='NO_COMPARABLE_ALTERNATIVES')

    # Same domain sequence in another background has identical marginal control.
    same_piece = record(store, 'same_piece', ('W' if seq[0]!='W' else 'A') + seq[1:])
    assertion('same_piece_signature_is_background_independent', piece_signature(a,ra)==piece_signature(same_piece,region(same_piece,'rsp')))
    close('same_piece_type_mean_invariant', type_scores(runtime,a,[6])['6'], type_scores(runtime,same_piece,[6])['6'],0)
    changed_meta = copy.deepcopy(a)
    changed_meta['label'],changed_meta['activity'],changed_meta['donor_name'] = 1,'deliberately_flipped','unseen'
    for s in changed_meta['model_slots']:
        s['length'] += 73
        s['start'] += 9
        s['end'] += 82
    meta_score = score_assembly(runtime, changed_meta, {'single':single}, {})
    assertion('outcomes_and_non_tensor_metadata_invariant', meta_score==scored)
    renamed_chain = copy.deepcopy(a)
    for obj in renamed_chain['route']:
        obj['chain'] = 17
    with torch.inference_mode():
        close('physical_chain_renaming_invariant', full.numpy(),
              predict_mode(model,masked_batch(renamed_chain,single,collate,store.vector)).numpy(),0)

    # A protein break has TWO terminal predictions but only ONE physical weight.
    terminal = copy.deepcopy(a)
    terminal['route'][5]['kind']=2
    terminal['route'][5]['chain']=-1
    terminal['model_slots']=[s for s in terminal['model_slots'] if s['object_index']!=5]
    for role,start,end in [(1,54,60),(2,60,66)]:
        terminal['model_slots'].append(dict(object_index=5,slot=role,kind=2,state='OBSERVED',
            sequence_hash=store.feature(seq[start:end]),parent_sequence_hash=digest(seq),
            start=start,end=end,length=end-start,group='P:'+str(role)))
    validate_regions({'a':terminal},[ra])
    predictions={'full':{j:np.random.default_rng(j).normal(size=(3,DIM)).astype(np.float32) for j in [5,6,7]}}
    values=score_vectors(runtime,terminal,{'targets':[5,6,7]},predictions)
    terminal_slots=sorted((s for s in terminal['model_slots'] if s['object_index']==5),key=lambda s:s['slot'])
    tt=torch.tensor(np.stack([store.vector(s['sequence_hash']) for s in terminal_slots]))
    mm=torch.tensor(np.stack([runtime.targets.mean(s) for s in terminal_slots]))
    loss,_=ssl.slot_loss(torch.tensor(predictions['full'][5][[1,2]]),tt,mm)
    close('terminal_slots_average_once',values['5']['full'],(1-loss.mean()).item())
    agg=aggregate({j:v['full'] for j,v in values.items()},ra)
    close('physical_boundary_equal_weight',agg['boundaries'],(values['5']['full']+values['7']['full'])/2,0)
    close('domain_boundary_balanced_weight',agg['balanced'],.5*(values['6']['full']+agg['boundaries']),0)

    # All-or-none status when one target has no nearby visible context.
    long_seq=''.join(rng.choice(alphabet,size=660))
    scarce=record(store,'scarce',long_seq)
    for s in scarce['model_slots']:
        if s['object_index'] not in (0,30,34,36):
            s['state']='MISSING'
    bad=make_plan(scarce,[0,30],store.parent,masking_closure)
    assertion('target_context_eligibility_all_or_none',bad['status']=='INSUFFICIENT_VISIBLE_CONTEXT'
              and bad['remaining_context_by_target']['0']==0 and bad['remaining_context_by_target']['30']==2)
    bad_score=score_assembly(runtime,scarce,{'bad':bad},{})
    assertion('unsupported_plan_no_partial_object_scores',bad_score['queries']['bad']['objects']=={})
    assertion('incomplete_region_not_silently_averaged',all(v is None for v in aggregate({'6':.2,'5':.3},ra).values()))

    # Test real SidecarStore dispatch without opening/mocking production files.
    class BaseNamespace:
        def vector(self,key):
            assert key=='shared';return np.full(DIM,1,dtype=np.float32)
        def parent(self,key):
            return 'BASE:'+key
    namespace=SidecarStore.__new__(SidecarStore)
    namespace.base=BaseNamespace();namespace.dataset=None
    namespace.parents={'sideparent':'SIDE'};namespace.rows={'shared':0}
    namespace.z=np.full((1,DIM),2,dtype=np.float32)
    rejected=False
    try:namespace.vector('shared')
    except RuntimeError:rejected=True
    assertion('namespace_selection_required',rejected)
    namespace.select_dataset('bode1');original=namespace.vector('shared')
    namespace.select_dataset('tdomain');fresh=namespace.vector('shared')
    fresh[0]=999
    namespace.select_dataset('bode2');base_again=namespace.vector('shared')
    assertion('same_hash_fresh_features_namespace_isolated',np.all(original==1) and np.all(base_again==1) and np.all(namespace.z==2))
    namespace.select_dataset('tdomain');rejected=False
    try:namespace.vector('only_in_original')
    except RuntimeError:rejected=True
    assertion('sidecar_missing_feature_does_not_fall_back',rejected)
    assertion('parent_lookup_namespaces',namespace.parent('sideparent')=='SIDE' and namespace.parent('other')=='BASE:other')

    print(json.dumps(dict(stage='CONTEXT_AUDIT_SELFTEST_OK',checks=len(checks),check_names=checks,
        max_numeric_discrepancy=max(differences,default=0),device='cpu',feature_dim=DIM,
        production_checkpoint_loaded=False,production_embeddings_loaded=False,
        original_model_sha256=hashlib.sha256((base/'src/assembly_model.py').read_bytes()).hexdigest(),
        original_ssl_sha256=hashlib.sha256((base/'run_ssl.py').read_bytes()).hexdigest()),sort_keys=True))


if __name__=='__main__':
    main()
