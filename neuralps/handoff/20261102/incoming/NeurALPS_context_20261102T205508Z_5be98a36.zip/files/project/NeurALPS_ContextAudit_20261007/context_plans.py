"""Label-free physical masks and exact-input matched-background audits."""
from collections import defaultdict, Counter
from ca_common import require, canonical


def slots_by_object(record):
    result = defaultdict(list)
    for slot in record['model_slots']:
        result[slot['object_index']].append(slot)
    return {j: sorted(ss, key=lambda s: s['slot']) for j, ss in result.items()}


def validate_regions(records, regions):
    require(len({r['region_id'] for r in regions}) == len(regions), 'Duplicate region ID')
    for r in regions:
        require(r['assembly_id'] in records, 'Region has no input: ' + r['region_id'])
        rec = records[r['assembly_id']]
        require(rec['dataset'] == r['dataset'], 'Region dataset mismatch')
        ds, bs = r['domain_indices'], r['boundary_indices']
        require(ds and bs and len(ds) == len(set(ds)) and len(bs) == len(set(bs)), 'Empty/duplicate region')
        require(all(0 <= j < len(rec['route']) and rec['route'][j]['kind'] == 0 for j in ds), 'Invalid domain index')
        touch = [j for j, o in enumerate(rec['route']) if o['kind'] != 0 and (j-1 in ds or j+1 in ds)]
        require(bs == touch, 'Region must include exactly all touching physical boundaries')
        by = slots_by_object(rec)
        require(set(by) == set(range(len(rec['route']))), 'Incomplete physical slots')
        for j, o in enumerate(rec['route']):
            require([s['slot'] for s in by[j]] == ([1, 2] if o['kind'] == 2 else [0]), 'Invalid physical slot roles')
        for expected in r.get('expected_objects', []):
            j = expected['object_index']
            require(rec['route'][j]['kind'] == expected['kind'], 'Audited T-domain target kind changed')
            actual = [(s['sequence_hash'], s['start'], s['end'], s['state']) for s in by[j]]
            wanted = [(s['sequence_hash'], s['start_aa_0based'], s['end_aa_0based_exclusive'], s['state'])
                      for s in expected['physical_regions']]
            require(sorted(actual) == sorted(wanted), 'Audited T-domain target coordinates or sequences changed')
    require(set(records) == {r['assembly_id'] for r in regions}, 'Region/input assembly coverage differs')


def remaining_context(record, target, hidden):
    seen, count = set(), 0
    by = defaultdict(set)
    for s in record['model_slots']:
        if s['state'] == 'OBSERVED' and (s['object_index'], s['slot']) not in hidden:
            by[s['object_index']].add(s['sequence_hash'])
    for j in sorted(by):
        if j != target and abs(j-target) <= 24 and by[j] - seen:
            count += 1
            seen.update(by[j])
    return count


def geometry(record, targets):
    # These are exactly the structural inputs to the original model. Physical
    # lengths/coordinates, labels, IDs and donor names are not model tensors.
    return dict(objects=[(o['kind'], o['domain_type'] if o['kind'] == 0 else 0,
                          o['chain'] if o['kind'] != 2 else -1) for o in record['route']],
                slots=[(s['object_index'], s['slot'], s['state']) for s in
                       sorted(record['model_slots'], key=lambda s: (s['object_index'], s['slot']))],
                target_indices=sorted(targets))


def piece_signature(record, region):
    by = slots_by_object(record)
    return canonical([(record['route'][j]['domain_type'],
                       [(s['slot'], s['sequence_hash']) for s in by[j]])
                      for j in region['domain_indices']])


def visible_identity(record, hidden):
    # Sequence identities are a conservative pre-inference check; actual tensor
    # equality is checked independently after embedding lookup and masking.
    return canonical(dict(geometry=geometry(record, []), visible=[
        (s['object_index'], s['slot'], 'MASKED' if (s['object_index'], s['slot']) in hidden else s['state'],
         None if (s['object_index'], s['slot']) in hidden or s['state'] != 'OBSERVED' else s['sequence_hash'])
        for s in sorted(record['model_slots'], key=lambda s: (s['object_index'], s['slot']))]))


def background(region):
    if region['dataset'] == 'bode1':
        require(region.get('background_id'), 'BODE1 background missing')
        return region['background_id']
    if region['dataset'] == 'bode2':
        return 'bode2_native_background|position=' + region['position']
    require(region.get('context'), 'T-domain context missing')
    return 'tdomain|context=' + region['context']


def make_plan(record, targets, parent, closure, hidden=None):
    by = slots_by_object(record)
    primary = [(j, s['slot']) for j in targets for s in by[j]]
    if any(by[j][k]['state'] != 'OBSERVED' for j in targets for k in range(len(by[j]))):
        return dict(status='MISSING_SEQUENCE_FEATURE', targets=targets, primary=primary, hidden=[],
                    masked_fraction=None, remaining_context_min=None)
    own = closure(record, primary, parent, 'independent_sequence')['hidden']
    chosen = sorted(set(map(tuple, own)) if hidden is None else set(map(tuple, hidden)))
    require(set(map(tuple, own)) <= set(chosen), 'Common mask omitted original physical closure')
    remaining = {str(j): remaining_context(record, j, set(chosen)) for j in targets}
    minimum = min(remaining.values())
    n = sum(s['state'] == 'OBSERVED' for s in record['model_slots'])
    return dict(status='READY' if minimum >= 2 else 'INSUFFICIENT_VISIBLE_CONTEXT',
                targets=targets, primary=primary, hidden=chosen, own_hidden=own,
                masked_fraction=len(chosen)/n, remaining_context_min=minimum,
                remaining_context_by_target=remaining)


def build_plans(records, regions, parent, closure):
    singles, joint, common, buckets = {}, {}, {}, defaultdict(list)
    for r in regions:
        aid, rid = r['assembly_id'], r['region_id']
        rec = records[aid]
        targets = sorted(r['domain_indices'] + r['boundary_indices'])
        for j in targets:
            key = aid + '|object=' + str(j)
            if key not in singles:
                singles[key] = dict(assembly_id=aid, **make_plan(rec, [j], parent, closure))
        joint[rid] = dict(assembly_id=aid, **make_plan(rec, targets, parent, closure))
        key = canonical([r['dataset'], background(r), geometry(rec, targets)])
        buckets[key].append(r)
    common_audit = []
    for group_id, rr in sorted(buckets.items()):
        own = [joint[r['region_id']] for r in rr]
        hidden = sorted({tuple(key) for p in own for key in p['hidden']})
        distinct = len({piece_signature(records[r['assembly_id']], r) for r in rr})
        identities = {visible_identity(records[r['assembly_id']], set(hidden)) for r in rr}
        for r in rr:
            rid, aid = r['region_id'], r['assembly_id']
            p = make_plan(records[aid], joint[rid]['targets'], parent, closure, hidden=hidden)
            if len(rr) < 2:
                p['status'] = 'NO_COMPARABLE_ALTERNATIVES'
            elif distinct < 2:
                p['status'] = 'NO_DISTINCT_ALTERNATIVES'
            elif len(identities) != 1:
                p['status'] = 'NONIDENTICAL_BACKGROUND'
            common[rid] = dict(assembly_id=aid, common_group_id=group_id,
                               common_group_size=len(rr), **p)
        common_audit.append(dict(common_group_id=group_id, dataset=rr[0]['dataset'],
                                 background_id=background(rr[0]), regions=[r['region_id'] for r in rr],
                                 candidates=len(rr), distinct_pieces=distinct,
                                 sequence_identity_count=len(identities), union_hidden=hidden,
                                 status_counts=dict(Counter(common[r['region_id']]['status'] for r in rr))))
    return dict(single=singles, joint=joint, joint_common=common, common_groups=common_audit)


def masked_batch(record, plan, collate, lookup):
    batch = collate([record], lookup)
    for j, role in plan['hidden']:
        require(int(batch['state'][0, j, role]) == 1, 'Mask includes non-observed slot')
        batch['state'][0, j, role] = 4
        batch['x'][0, j, role] = float('nan')
    return batch


def tensor_signature(batch):
    import hashlib
    import torch
    require(set(batch) == {'x', 'state', 'kind', 'domain_type', 'chain', 'valid'}, 'New/unreviewed model input')
    h = hashlib.sha256()
    for key in sorted(batch):
        value = batch[key].detach().cpu().clone()
        if key == 'x':
            observed = (batch['state'].cpu() == 1) & batch['valid'].cpu().unsqueeze(-1)
            value = torch.where(observed.unsqueeze(-1), value, torch.zeros_like(value))
        require(not value.is_floating_point() or bool(torch.isfinite(value).all()), 'Nonfinite visible tensor')
        h.update((key + str(tuple(value.shape)) + str(value.dtype)).encode())
        h.update(value.contiguous().numpy().tobytes())
    return h.hexdigest()
