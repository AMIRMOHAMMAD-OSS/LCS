#!/usr/bin/env bash
set -eo pipefail
NRPS_AUDIT_PACKAGE="${1:?package}"
NRPS_AUDIT_ROOT="${2:?root}"
NRPS_AUDIT_REQUEST="${3:?request}"
cd "$NRPS_AUDIT_ROOT"
module purge
module load arch/a100
module load pytorch-gpu/py3/2.8.0
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
export TMPDIR="$NRPS_AUDIT_ROOT/e12_context_audit_tmp_${SLURM_JOB_ID}"
export SQLITE_TMPDIR="$TMPDIR"
mkdir -p "$TMPDIR"
NRPS_AUDIT_PY=$(python3 -B -c 'import sys; print(sys.base_prefix + "/bin/python3")')
"$NRPS_AUDIT_PY" -B - "$NRPS_AUDIT_REQUEST" <<'PY'
import hashlib
from pathlib import Path
import sys
request = Path(sys.argv[1])
expected = request.with_suffix('.json.sha256').read_text().strip()
actual = hashlib.sha256(request.read_bytes()).hexdigest()
if actual != expected:
    raise SystemExit('IMMUTABLE_REQUEST_HASH_MISMATCH: refusing context audit')
print('CONTEXT_AUDIT_REQUEST_SHA256_OK:', actual, flush=True)
PY
"$NRPS_AUDIT_PY" -B "$NRPS_AUDIT_PACKAGE/verify.py"
"$NRPS_AUDIT_PY" -B "$NRPS_AUDIT_PACKAGE/selftest.py" --root "$NRPS_AUDIT_ROOT"
NRPS_AUDIT_OUT="$NRPS_AUDIT_ROOT/e12_context_audit_${SLURM_JOB_ID}"
NRPS_AUDIT_FLAGS=()
if [ -n "${4:-}" ]; then
    NRPS_AUDIT_OUT="$4"
    NRPS_AUDIT_FLAGS=(--resume)
fi
exec "$NRPS_AUDIT_PY" -u -B "$NRPS_AUDIT_PACKAGE/run_context.py" \
    --root "$NRPS_AUDIT_ROOT" --out "$NRPS_AUDIT_OUT" \
    --request "$NRPS_AUDIT_REQUEST" "${NRPS_AUDIT_FLAGS[@]}"
