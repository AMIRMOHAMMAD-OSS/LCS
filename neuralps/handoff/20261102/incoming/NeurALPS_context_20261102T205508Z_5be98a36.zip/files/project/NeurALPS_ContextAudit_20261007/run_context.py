#!/usr/bin/env python3
"""Run the sealed, frozen compatibility audit in one existing A100 allocation."""
import argparse
from collections import Counter, defaultdict
import fcntl
import gzip
import hashlib
import json
from pathlib import Path
import signal
import time
import traceback
import zipfile

from ca_common import (PACKAGE, VERSION, CHECKPOINT_SHA, canonical, dump, emit,
                       load, preflight, require, sha)
from context_plans import build_plans, piece_signature, background


def gzip_json(path, value):
    raw = json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_bytes(gzip.compress(raw, mtime=0))
    tmp.replace(path)


def gzip_rows(path, rows):
    raw = ''.join(json.dumps(r, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n' for r in rows).encode()
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_bytes(gzip.compress(raw, mtime=0))
    tmp.replace(path)


def state_sha(model):
    h = hashlib.sha256()
    for key, value in sorted(model.state_dict().items()):
        h.update(key.encode())
        h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


def inspection(out):
    files = [p for p in sorted(out.rglob('*')) if p.is_file() and
             p.suffix not in ('.zip', '.lock', '.tmp') and 'history' not in p.relative_to(out).parts]
    manifest = {str(p.relative_to(out)): sha(p) for p in files if p.name != 'artifact_manifest.json'}
    dump(out / 'artifact_manifest.json', manifest)
    files = [p for p in files if p.name != 'artifact_manifest.json'] + [out / 'artifact_manifest.json']
    tmp = out / 'context_audit_inspection.zip.tmp'
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p, str(p.relative_to(out)))
    tmp.replace(out / 'context_audit_inspection.zip')


def collect_rows(records, regions, plans, results):
    from frozen_scoring import aggregate
    rows = []
    for r in regions:
        aid, rid = r['assembly_id'], r['region_id']
        result = results[aid]
        base = {k: r.get(k, '') for k in ('dataset', 'assembly_id', 'region_id', 'role',
                                          'position', 'background_id', 'donor', 'context')}
        base['background_id'] = r.get('background_id') or background(r)
        base['piece_signature'] = piece_signature(records[aid], r)
        target = sorted(r['domain_indices'] + r['boundary_indices'])
        for scope in ('single', 'joint', 'joint_common'):
            if scope == 'single':
                keys = [aid + '|object=' + str(j) for j in target]
            else:
                keys = [rid]
            pp = [plans[scope][key] for key in keys]
            qq = [result['queries'][scope + '/' + key] for key in keys]
            statuses = sorted({q['status'] for q in qq})
            status = 'SCORED' if statuses == ['SCORED'] else '+'.join(s for s in statuses if s != 'SCORED')
            for mode in ('full', 'local'):
                scores = {j: values[mode] for q in qq for j, values in q['objects'].items()}
                values = aggregate(scores, r) if status == 'SCORED' else aggregate({}, r)
                fractions = [p['masked_fraction'] for p in pp if p['masked_fraction'] is not None]
                remain = [p['remaining_context_min'] for p in pp if p['remaining_context_min'] is not None]
                rows.append(dict(base, method=scope + '_' + mode, status=status, **values,
                                 context_signature=qq[0]['context_signature'] if scope != 'single' else None,
                                 common_group_id=pp[0].get('common_group_id'),
                                 common_group_size=pp[0].get('common_group_size'),
                                 masked_fraction=sum(fractions)/len(fractions) if fractions else None,
                                 remaining_context_min=min(remain) if remain else None,
                                 domain_count=len(r['domain_indices']), boundary_count=len(r['boundary_indices'])))
        values = aggregate(result['type_mean'], r)
        rows.append(dict(base, method='type_mean', status='SCORED' if values['balanced'] is not None else 'MISSING_SEQUENCE_FEATURE',
                         **values, context_signature=None, common_group_id=None, common_group_size=None,
                         masked_fraction=None, remaining_context_min=None,
                         domain_count=len(r['domain_indices']), boundary_count=len(r['boundary_indices'])))
    return rows


def original_parity(results, records):
    original = load(PACKAGE / 'data/single_object_scores.json.gz')
    by_dataset = defaultdict(lambda: dict(comparisons=0, max_absolute_difference=0.0))
    for aid, result in results.items():
        dataset = records[aid]['dataset']
        expected = {str(q['object_index']): q for q in original[dataset][aid]}
        for key, q in result['queries'].items():
            if not key.startswith('single/') or q['status'] != 'SCORED':
                continue
            for j, scores in q['objects'].items():
                ref = expected[j]
                for mode, field in (('full', 'native_score'), ('local', 'local_only_native_score')):
                    require(ref.get(field) is not None, 'Original baseline score absent')
                    delta = abs(scores[mode] - ref[field])
                    item = by_dataset[dataset]
                    item['comparisons'] += 1
                    item['max_absolute_difference'] = max(item['max_absolute_difference'], delta)
                if ref.get('type_mean_native_score') is not None:
                    delta = abs(result['type_mean'][j] - ref['type_mean_native_score'])
                    item['comparisons'] += 1
                    item['max_absolute_difference'] = max(item['max_absolute_difference'], delta)
    require(set(by_dataset) == {'bode1', 'bode2', 'tdomain'}, 'Incomplete original score parity coverage')
    passed = all(v['comparisons'] > 0 and v['max_absolute_difference'] <= 5e-5 for v in by_dataset.values())
    report = dict(status='PASS' if passed else 'FAIL', tolerance=5e-5, datasets=dict(by_dataset),
                  comparison='Same frozen physical-object query, extraction namespace, weights and loss; fp32 tolerance')
    return report


def common_input_audit(rows):
    grouped = defaultdict(list)
    for r in rows:
        if r['method'] == 'joint_common_full' and r['status'] == 'SCORED':
            grouped[r['common_group_id']].append(r)
    for rr in grouped.values():
        require(len(rr) >= 2 and len({r['context_signature'] for r in rr}) == 1,
                'Common-background candidates did not have identical actual model inputs')
    return dict(status='PASS', scored_groups=len(grouped), scored_regions=sum(map(len, grouped.values())),
                checked_tensor_keys=['x', 'state', 'kind', 'domain_type', 'chain', 'valid'],
                hidden_x_canonicalized=True, identical_input_predictions_reused=True,
                equal_inputs_do_not_require_equal_candidate_losses=True)


def execute(args):
    import torch
    ctx, records, regions, request = preflight(args.root)
    require(load(args.request) == request, 'Request differs from current verified source files')
    out = args.out.resolve()
    require(out.parent == args.root.resolve() and out.name.startswith('e12_context_audit_'), 'Invalid output location')
    require(not (out / 'CONTEXT_AUDIT_COMPLETE').exists(), 'Output already complete')
    if args.resume:
        require(out.is_dir() and (out / 'identity.json').is_file(), 'No valid resumable output')
    else:
        require(not out.exists(), 'Output exists; use explicit resume')
        out.mkdir()
    args.owns_output = True
    lock = (out / 'run.lock').open('a')
    fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    args.run_lock = lock
    require(torch.__version__.split('+')[0] == '2.8.0' and torch.cuda.is_available() and torch.cuda.device_count() == 1,
            'Use the pinned PyTorch2.8.0 one-GPU allocation')
    torch.set_num_threads(8)
    torch.manual_seed(20261007)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.use_deterministic_algorithms(True)
    runtime_info = dict(torch=torch.__version__, cuda=torch.version.cuda, device=torch.cuda.get_device_name(0),
                        precision='fp32', tf32=False, deterministic_algorithms=True, microbatch=8)
    identity = dict(request=request, runtime=runtime_info)
    if (out / 'identity.json').exists():
        require(load(out / 'identity.json') == identity, 'Resume runtime/source identity changed')
    else:
        dump(out / 'identity.json', identity)
    for name in ('fatal_error.json', 'pause.json'):
        if (out / name).exists():
            history = out / 'history'
            history.mkdir(exist_ok=True)
            (out / name).rename(history / (str(time.time_ns()) + '_' + name))
    started = time.monotonic()
    stopping = {'signal': None}
    def stop(signum, frame):
        stopping['signal'] = signum
    signal.signal(signal.SIGUSR1, stop)
    signal.signal(signal.SIGTERM, stop)
    from frozen_scoring import open_frozen, score_assembly
    runtime = open_frozen(ctx, records)
    original_weights = state_sha(runtime.model)
    plans = build_plans(records, regions, runtime.store.parent, runtime.closure)
    plan_sha = canonical(plans)
    dump(out / 'protocol.json', load(PACKAGE / 'PROTOCOL.json'))
    gzip_json(out / 'mask_plans.json.gz', plans)
    dump(out / 'pre_inference_seal.json', dict(identity_sha256=canonical(identity), plans_sha256=plan_sha,
         protocol_sha256=sha(out / 'protocol.json'), outcomes_used_for_masks=False,
         legacy_lineage_validator_checks_bode1_labels=True, prediction_interface_excludes_activity_fields=True))
    emit('MASK_PLAN_READY', counts={k: dict(Counter(p['status'] for p in plans[k].values()))
                                   for k in ('single', 'joint', 'joint_common')})
    by_assembly = defaultdict(dict)
    for scope in ('single', 'joint', 'joint_common'):
        for key, p in plans[scope].items():
            by_assembly[p['assembly_id']][scope + '/' + key] = p
    shard_dir = out / 'shards'
    shard_dir.mkdir(exist_ok=True)
    results, common_cache = {}, {}
    for index, aid in enumerate(sorted(records)):
        stem = hashlib.sha256(aid.encode()).hexdigest()
        path, metapath = shard_dir / (stem + '.json.gz'), shard_dir / (stem + '.json')
        expected = dict(assembly_id=aid, identity_sha256=canonical(identity), plans_sha256=plan_sha,
                        record_sha256=canonical(records[aid]))
        if metapath.exists():
            meta = load(metapath)
            require(all(meta.get(k) == v for k, v in expected.items()) and sha(path) == meta['sha256'],
                    'Completed assembly shard changed')
            result = load(path)
        else:
            result = score_assembly(runtime, records[aid], by_assembly[aid], common_cache, stopping)
            if result is None or stopping['signal']:
                dump(out / 'pause.json', dict(status='PAUSED', completed_assemblies=len(results), signal=stopping['signal']))
                inspection(out)
                return 75
            gzip_json(path, result)
            dump(metapath, dict(expected, sha256=sha(path)))
        require(set(result['queries']) == set(by_assembly[aid]), 'Assembly query coverage changed')
        results[aid] = result
        if index % 10 == 0 or index + 1 == len(records):
            emit('CONTEXT_AUDIT_PROGRESS', completed=index+1, planned=len(records), assembly_id=aid)
    require(state_sha(runtime.model) == original_weights and sha(ctx['ssl_run'] / 'best.pt') == CHECKPOINT_SHA,
            'Frozen pretrained weights changed')
    parity = original_parity(results, records)
    dump(out / 'original_score_parity.json', parity)
    require(parity['status'] == 'PASS', 'Original single-piece scores were not reproduced; do not interpret new metrics')
    rows = collect_rows(records, regions, plans, results)
    audit = common_input_audit(rows)
    dump(out / 'common_input_audit.json', audit)
    score_file = out / 'region_scores.jsonl.gz'
    gzip_rows(score_file, rows)
    sealed_sha = sha(score_file)
    dump(out / 'score_seal.json', dict(path=score_file.name, sha256=sealed_sha, rows=len(rows),
         checkpoint_sha256=CHECKPOINT_SHA, weights_state_sha256=original_weights,
         training_updates=0, classifier_fits=0, activity_outcomes_used_for_predictions=False,
         natural_reference_percentiles_applied=False))
    # Only now does the new evaluator load the packaged activity endpoint file.
    from evaluate import evaluate_scores
    metrics = evaluate_scores(score_file, out / 'evaluation', sealed_sha)
    summary = dict(status='CONTEXT_AUDIT_COMPLETE', version=VERSION, selected_step=26000,
                   assemblies=len(records), regions=len(regions), method_rows=len(rows),
                   pretrained_weights_changed=False, activity_classifier_fits=0, training_updates=0,
                   original_single_object_parity=parity, common_input_audit=audit,
                   methods={m: dict(Counter(r['status'] for r in rows if r['method'] == m))
                            for m in sorted({r['method'] for r in rows})},
                   evaluation_summary='evaluation/summary.json',
                   development_evaluation_not_new_independent_test=True,
                   seconds_this_attempt=round(time.monotonic()-started, 3))
    # Keep status.sh concise; full metric and paired-comparison tables are in the archive.
    if isinstance(metrics, dict):
        summary['metric_summary'] = [
            {k: row.get(k) for k in ('dataset', 'cohort', 'field', 'method', 'metric_unit',
                                      'auroc', 'n_regions_available', 'n_assemblies_available', 'n_mixed_panels', 'ci95')}
            for row in metrics.get('metrics', [])
            if row.get('primary_field') and row['cohort'] in ('all_engineered', 'primary65')]
    dump(out / 'summary.json', summary)
    (out / 'CONTEXT_AUDIT_COMPLETE').write_text(VERSION + '\n')
    inspection(out)
    print(json.dumps(summary, indent=2, allow_nan=False), flush=True)
    print('Inspection:', out / 'context_audit_inspection.zip', flush=True)
    return 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    try:
        code = execute(args)
    except Exception:
        if getattr(args, 'owns_output', False):
            dump(args.out / 'fatal_error.json', dict(status='FAILED', traceback=traceback.format_exc()))
            inspection(args.out)
        raise
    raise SystemExit(code)
