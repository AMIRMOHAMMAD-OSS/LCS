"""Read-only source contracts for the frozen compatibility context audit."""
import gzip
import hashlib
import importlib
import json
from pathlib import Path
import sqlite3
import sys

PACKAGE = Path(__file__).resolve().parent
VERSION = 'nrps_context_audit_20261007_v1'
CHECKPOINT_SHA = '9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f'
ENSEMBLE_SHA = 'b23bcd0322ff786cf7dcfba21de0243642ad51681ea5149ab25ee0b405dda7fb'
TDOMAIN_RUN = 'e10_tdomain_embed_696333'
TDOMAIN_RECORDS = 'e11_tdomain_transfer_699466/scores/records.json.gz'
TDOMAIN_RECORDS_SHA = 'fa79f3e0f8618f004bb6b157dae9235ff9580bf4bc3a0a49c2d2b167e570e2d0'
TDOMAIN_FILES = {
    'feature_index.sqlite3': '41d81778fc2d2c015cbe28d429ed2bccc7ea8940142106a02ef98eceeac06bfe',
    'features.f32': '1134819306754396634ee0f1c00a0bfffb2cb15cd4a20daca08b22243f1ee77d',
    'inputs/routes.jsonl.gz': 'e58d8592d95b68ae31578585e8cdae74977c2ece4f6a212c298ba78c51567608',
    'inputs/parents.fasta.gz': '15f9181a74d4bb42325bfa2af5900dcd6a2a967a0d6be1c6428b1187f34a08c9',
    'reference_comparison.json': 'ed978d29e92ffe2d60bb8634a66c139fe787ffc57fb6c2a0485482c7fc25e7c6',
}
INPUT_FIELDS = ('assembly_id', 'dataset', 'split', 'route', 'model_slots',
                'parent_sequence_hashes', 'parent_lengths', 'boundary_window_policy')


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def load(path):
    path = Path(path)
    if path.suffix == '.gz':
        with gzip.open(path, 'rt') as f:
            return json.load(f)
    return json.loads(path.read_text())


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode()).hexdigest()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def emit(stage, **kw):
    print(json.dumps(dict(stage=stage, **kw), allow_nan=False), flush=True)


def verify_tree(path, expected=None):
    path = Path(path).resolve()
    if expected:
        require(sha(path / 'SHA256SUMS') == expected, 'Dependency manifest changed: ' + str(path))
    seen = set()
    for line in (path / 'SHA256SUMS').read_text().splitlines():
        digest, rel = line.split('  ', 1)
        item = (path / rel).resolve()
        require(path in item.parents and rel not in seen, 'Invalid checksum path')
        seen.add(rel)
        require(item.is_file() and sha(item) == digest, 'Checksummed file changed: ' + str(item))
    require(seen, 'Empty checksum manifest')
    return sha(path / 'SHA256SUMS')


def readonly_db(path):
    db = sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True)
    db.execute('PRAGMA query_only=ON')
    db.execute('PRAGMA temp_store=MEMORY')
    return db


def sidecar_index(sidecar):
    """Inspect the pinned sidecar schema on the login node, before allocation."""
    db = readonly_db(sidecar / 'feature_index.sqlite3')
    candidates, inventory = [], {}
    for (table,) in db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall():
        safe = '"' + table.replace('"', '""') + '"'
        columns = {r[1] for r in db.execute('PRAGMA table_info(' + safe + ')')}
        inventory[table] = sorted(columns)
        for hcol in ('hash', 'sequence_hash'):
            for rcol in ('feature_row', 'row_index', 'row'):
                if {hcol, rcol} <= columns:
                    candidates.append((safe, hcol, rcol))
    require(len(candidates) == 1, 'Unrecognized/ambiguous pinned sidecar index schema: ' + repr(inventory))
    table, hcol, rcol = candidates[0]
    rows = list(db.execute('SELECT "' + hcol + '","' + rcol + '" FROM ' + table))
    db.close()
    result = dict(rows)
    require(len(rows) == len(result) == 290 and set(result.values()) == set(range(290)),
            'T-domain feature index is not a complete unique permutation')
    require((sidecar / 'features.f32').stat().st_size == 290 * 1152 * 4, 'Sidecar feature shape differs')
    return result


def clean_record(record, dataset=None):
    # Outcome values and construct names are not copied into the prediction interface.
    r = {k: record[k] for k in INPUT_FIELDS if k in record}
    if dataset is not None:
        r['dataset'] = dataset
    require(r.get('route') and r.get('model_slots'), 'Empty model input')
    require(r.get('boundary_window_policy') == 'physical_end_extradomain_tail64_v1',
            'Unexpected boundary extraction policy')
    return r


def database_contract(ctx):
    """Use the production fingerprint sealed in the validated training manifest."""
    dbpath = (ctx['prep'] / 'training_data.sqlite3').resolve()
    manifest_path = ctx['assets'] / 'manifest.json'
    manifest_sha = sha(manifest_path)
    require(manifest_sha == ctx['config']['targets_manifest_sha256'] ==
            ctx['identities']['target_manifest_sha256'], 'Frozen target manifest changed')
    matches = [item for item in load(manifest_path)['fingerprints']
               if Path(item['path']).resolve() == dbpath]
    require(len(matches) == 1, 'Expected one exact production database fingerprint')
    expected = matches[0]
    digest = expected.get('sha256', '')
    require(isinstance(digest, str) and len(digest) == 64 and
            all(c in '0123456789abcdef' for c in digest), 'Invalid database fingerprint SHA256')
    size = expected.get('bytes')
    require(type(size) is int and size > 0, 'Invalid database fingerprint size')
    require(dbpath.stat().st_size == size, 'Frozen production database size changed')
    require(sha(dbpath) == digest, 'Frozen production database SHA256 changed')
    return dict(path=str(dbpath), sha256=digest, bytes=size,
                target_manifest_path=str(manifest_path.resolve()),
                target_manifest_sha256=manifest_sha)


def load_records(root, database):
    dbpath = Path(database['path'])
    records = {}
    db = readonly_db(dbpath)
    for aid, dataset, payload in db.execute(
            "SELECT assembly_id,dataset,payload FROM assemblies WHERE dataset IN ('bode1','bode2')"):
        r = clean_record(json.loads(payload), dataset)
        require(r['assembly_id'] == aid and aid not in records, 'Duplicate/inconsistent BODE assembly')
        records[aid] = r
    db.close()
    for dataset, count in (('bode1', 324), ('bode2', 106)):
        require(sum(r['dataset'] == dataset for r in records.values()) == count, 'Wrong BODE cohort size')
    sidecar = root / TDOMAIN_RUN
    for rel, digest in TDOMAIN_FILES.items():
        require(sha(sidecar / rel) == digest, 'Frozen T-domain sidecar changed: ' + rel)
    available = sidecar_index(sidecar)
    # Reuse the exact input records sealed by the previous transfer scorer,
    # rather than reconstructing a route from visual-map coordinates.
    require(sha(root / TDOMAIN_RECORDS) == TDOMAIN_RECORDS_SHA, 'Original T-domain scoring records changed')
    payload = load(root / TDOMAIN_RECORDS)
    if isinstance(payload, dict) and 'records' in payload:
        payload = payload['records']
    if isinstance(payload, dict):
        for aid, r in payload.items():
            require(isinstance(r, dict) and r.get('assembly_id') == aid, 'Invalid sealed T-domain record mapping')
        source_records = list(payload.values())
    else:
        require(isinstance(payload, list), 'Sealed T-domain records must be an ID mapping or list')
        source_records = payload
    for source in source_records:
        r = clean_record(source, 'tdomain')
        require(r['assembly_id'] not in records, 'Duplicate T-domain assembly')
        require(all(s['state'] != 'OBSERVED' or s['sequence_hash'] in available for s in r['model_slots']),
                'T-domain slot is absent from its own feature sidecar')
        records[r['assembly_id']] = r
    require(sum(r['dataset'] == 'tdomain' for r in records.values()) == 88, 'Expected 88 T-domain routes')
    return records


def attach(root):
    ensemble = root / 'NeurALPS_Ensemble_20261004'
    verify_tree(ensemble, ENSEMBLE_SHA)
    sys.path.insert(0, str(ensemble))
    common = importlib.import_module('common')
    require(Path(common.__file__).resolve().parent == ensemble, 'Unexpected legacy common module')
    return common


def preflight(root):
    root = Path(root).resolve()
    package_sha = verify_tree(PACKAGE)
    common = attach(root)
    # The inherited lineage validator checks BODE1 labels/folds. These are never
    # used by the new inference interface, which copies only model input fields.
    ctx = common.project(root, root / 'e1_ssl_continue30_v1_530757')
    require(ctx['source_provenance']['best_checkpoint_sha256'] == CHECKPOINT_SHA and
            ctx['ssl_summary']['selected_step'] == 26000, 'Expected frozen SSL26 checkpoint')
    database = database_contract(ctx)
    records = load_records(root, database)
    regions = load(PACKAGE / 'data/regions.json')
    from context_plans import validate_regions
    validate_regions(records, regions)
    original = load(PACKAGE / 'data/single_object_scores.json.gz')
    for aid, record in records.items():
        source = original[record['dataset']][aid]
        require(len(source) == len(record['route']), 'Original physical-object inventory changed')
        for q in source:
            j = q['object_index']
            ss = sorted([s for s in record['model_slots'] if s['object_index'] == j], key=lambda s: s['slot'])
            require(q['kind'] == record['route'][j]['kind'] and
                    q['native_hashes'] == [s.get('sequence_hash') for s in ss],
                    'Original score targets differ from current inputs: ' + aid)
    request = dict(version=VERSION, root=str(root), package_sha256=package_sha,
                   protocol_sha256=sha(PACKAGE / 'PROTOCOL.json'),
                   model_inputs=ctx['identities'], database_contract=database,
                   records_sha256=canonical(records),
                   regions_sha256=canonical(regions), tdomain_files=TDOMAIN_FILES,
                   tdomain_scoring_records_sha256=TDOMAIN_RECORDS_SHA,
                   checkpoint_sha256=CHECKPOINT_SHA, selected_step=26000,
                   training_updates=0, activity_classifier_fits=0)
    emit('CONTEXT_AUDIT_PREFLIGHT_OK', assemblies=len(records), regions=len(regions),
         selected_step=26000, training_updates=0, activity_classifier_fits=0)
    return ctx, records, regions, request
