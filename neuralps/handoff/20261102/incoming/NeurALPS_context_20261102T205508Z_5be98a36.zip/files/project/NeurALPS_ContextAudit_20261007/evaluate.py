"""Evaluate prespecified frozen context scores after verifying their byte seal.

No fitting, threshold choice, score reversal or method selection. BODE1 uses
macro within-background AUROC, with overlapping panels treated descriptively.
BODE2 uncertainty resamples donor triplets; T-domain uncertainty resamples the
declared minimum ancestry groups. These groups are not verified homology groups.

Public API: evaluate_scores(score_file, out_dir, sealed_sha, *, data_dir=None,
                            bootstrap_reps=2000, seed=20261007).
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path

import numpy as np

METHODS = ("single_full", "single_local", "joint_full", "joint_local",
           "joint_common_full", "joint_common_local", "type_mean")
JOINT = ("joint_full", "joint_local", "joint_common_full", "joint_common_local")
PAIRS = (
    ("joint_full", "single_full"), ("joint_local", "single_local"),
    ("single_full", "single_local"), ("joint_full", "joint_local"),
    ("single_full", "type_mean"), ("single_local", "type_mean"),
    ("joint_full", "type_mean"), ("joint_local", "type_mean"),
    ("joint_common_full", "single_full"), ("joint_common_local", "single_local"),
    ("joint_common_full", "joint_full"), ("joint_common_local", "joint_local"),
    ("joint_common_full", "joint_common_local"),
    ("joint_common_full", "type_mean"), ("joint_common_local", "type_mean"),
)
FIELDS = ("domains", "boundaries", "balanced", "neighborhood_mean")
MIN_BOOTSTRAP_GROUPS = 10
MIN_CLASS_GROUPS = 2
MIN_VALID_BOOTSTRAP_FRACTION = .90


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    with Path(path).open() as handle:
        return json.load(handle)


def read_scores(path):
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def dump(path, value):
    Path(path).write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")


def write_csv(path, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with Path(path).open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value, sort_keys=True, allow_nan=False)
                             if isinstance(value, (dict, list, tuple)) else value for key, value in row.items()})


def finite(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


def available(row, field):
    return row["status"] == "SCORED" and finite(row[field])


def true(value):
    return value is True or value == "True"


def signature(value):
    if value is None or value == "":
        return None
    return value if isinstance(value, str) else json.dumps(value, sort_keys=True, separators=(",", ":"))


def background(region):
    if region.get("background_id"):
        return region["background_id"]
    if region["dataset"] == "bode2":
        return "bode2_native_background|position=" + str(region["position"])
    if region["dataset"] == "tdomain":
        require(region.get("context"), "T-domain context missing")
        return "tdomain|context=" + region["context"]
    raise ValueError("BODE1 matched background missing")


def binary_metrics(y, score, weights=None):
    """Tie-aware AUROC/AP; zero-weight bootstrap observations do not count."""
    y, score = np.asarray(y), np.asarray(score, dtype=float)
    require(y.ndim == score.ndim == 1 and len(y) == len(score), "Metric vector dimensions differ")
    require(np.isfinite(score).all() and set(y.tolist()) <= {0, 1}, "Invalid metric values")
    y = y.astype(np.int8)
    weights = np.ones(len(y), dtype=float) if weights is None else np.asarray(weights, dtype=float)
    require(weights.shape == y.shape and np.isfinite(weights).all() and (weights >= 0).all(), "Invalid metric weights")
    p, n = float(weights[y == 1].sum()), float(weights[y == 0].sum())
    if not p or not n:
        return {"auroc": None, "average_precision": None, "reason": "EMPTY_OR_SINGLE_CLASS"}
    order = np.argsort(score, kind="stable")
    ss, yy, ww = score[order], y[order], weights[order]
    starts = np.r_[0, np.flatnonzero(np.diff(ss)) + 1]
    pg = np.add.reduceat(ww * yy, starts)
    ng = np.add.reduceat(ww * (1 - yy), starts)
    before = np.cumsum(ng) - ng
    auc = float(np.sum(pg * (before + .5 * ng)) / (p * n))
    pg, ng = pg[::-1], ng[::-1]
    cp, cn = np.cumsum(pg), np.cumsum(ng)
    precision = np.divide(cp, cp + cn, out=np.zeros_like(cp), where=(cp + cn) > 0)
    ap = float(np.sum(pg * precision) / p)
    return {"auroc": auc, "average_precision": ap, "reason": None}


def deterministic_seed(seed, *parts):
    payload = json.dumps([seed, *parts], sort_keys=True, separators=(",", ":")).encode()
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "little")


def cluster_bootstrap(y, a, clusters, *, b=None, reps=2000, seed=20261007):
    """Percentile interval; paired contrasts reuse identical sampled clusters."""
    y, a = np.asarray(y), np.asarray(a, dtype=float)
    b = None if b is None else np.asarray(b, dtype=float)
    require(len(y) == len(a) == len(clusters) and (b is None or len(b) == len(y)), "Bootstrap dimensions differ")
    unique = sorted(set(clusters))
    result = {"ci95": None, "bootstrap_groups": len(unique), "bootstrap_requested": reps,
              "bootstrap_valid": 0, "bootstrap_method": "cluster_percentile_paired" if b is not None else "cluster_percentile",
              "bootstrap_status": "UNAVAILABLE", "bootstrap_seed": int(seed)}
    if len(unique) < MIN_BOOTSTRAP_GROUPS:
        result["bootstrap_status"] = "TOO_FEW_DECLARED_GROUPS"
        return result
    by_class = [len({group for group, label in zip(clusters, y) if label == kind}) for kind in (0, 1)]
    result["class_group_counts"] = by_class
    if min(by_class) < MIN_CLASS_GROUPS:
        result["bootstrap_status"] = "TOO_FEW_CLASS_SUPPORTING_GROUPS"
        return result
    group_index = {group: i for i, group in enumerate(unique)}
    row_group = np.array([group_index[group] for group in clusters])
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(reps):
        counts = rng.multinomial(len(unique), np.full(len(unique), 1 / len(unique)))
        weights = counts[row_group]
        first = binary_metrics(y, a, weights)["auroc"]
        if first is None:
            continue
        if b is not None:
            second = binary_metrics(y, b, weights)["auroc"]
            if second is None:
                continue
            first -= second
        values.append(first)
    result["bootstrap_valid"] = len(values)
    if len(values) < MIN_VALID_BOOTSTRAP_FRACTION * reps:
        result["bootstrap_status"] = "TOO_MANY_SINGLE_CLASS_RESAMPLES"
        return result
    result.update(ci95=np.quantile(values, [.025, .975]).tolist(), bootstrap_status="DESCRIPTIVE_GROUPED_INTERVAL")
    return result


def no_bootstrap(reason):
    return {"ci95": None, "bootstrap_groups": None, "bootstrap_requested": 0,
            "bootstrap_valid": 0, "bootstrap_method": None, "bootstrap_status": reason}


def prepare(rows, regions, labels, groups):
    region_index = {}
    for region in regions:
        key = (region["dataset"], region["region_id"])
        require(key not in region_index, "Duplicate declared region")
        region_index[key] = region
    index = {}
    for row in rows:
        key = (row["dataset"], row["region_id"], row["method"])
        require(key not in index and row["method"] in METHODS, "Duplicate or unknown score method")
        declared = region_index.get(key[:2])
        require(declared is not None, "Undeclared scored region")
        for name in ("assembly_id", "role", "position"):
            require(row.get(name) == declared.get(name), "Score/region identity differs: " + name)
        require(row.get("background_id") in (declared.get("background_id"), background(declared)),
                "Score/region background differs")
        for field in FIELDS:
            require(field in row, "Missing region aggregation: " + field)
            require(row[field] is None or finite(row[field]), "Nonfinite region score")
        if row["status"] == "SCORED":
            require(all(finite(row[f]) for f in FIELDS), "SCORED region lacks a required target score")
        else:
            require(all(row[f] is None for f in FIELDS), "Unscored region contains an available aggregate")
        index[key] = row
    require(set(index) == {(dataset, rid, method) for dataset, rid in region_index for method in METHODS},
            "Missing score rows: every declared region and method must report availability explicitly")
    for dataset, mapping in labels.items():
        require(isinstance(mapping, dict), "Labels must be keyed by assembly ID")
        require(all(type(v) is int and v in (0, 1) for v in mapping.values()), "Labels must be literal binary integers")
    for (dataset, _), region in region_index.items():
        require(region["assembly_id"] in groups.get(dataset, {}), "Assembly grouping metadata missing")
    return region_index, index


def cohorts(region_index, labels, groups):
    result = []
    for dataset in ("bode1", "bode2", "tdomain"):
        selected = [r for (ds, _), r in region_index.items() if ds == dataset and r["role"] == "engineered"
                    and r["assembly_id"] in labels.get(dataset, {})]
        if dataset == "tdomain":
            require(all(groups[dataset][r["assembly_id"]]["evaluation_cohort"] == "primary65" for r in selected),
                    "T-domain binary labels extend outside the declared primary minimal assay")
        selected.sort(key=lambda r: r["region_id"])
        if not selected:
            continue
        fields = ("domains", "neighborhood_mean") if dataset == "tdomain" else ("balanced",)
        strata = [("primary65" if dataset == "tdomain" else "all_engineered", selected, True)]
        if dataset in ("bode1", "bode2"):
            for position in sorted({str(r["position"]) for r in selected}):
                strata.append(("position=" + position, [r for r in selected if str(r["position"]) == position], dataset == "bode2"))
        else:
            agreement = [r for r in selected if true(groups[dataset][r["assembly_id"]].get("source_agreement_subset"))]
            strata.append(("source_agreement63", agreement, True))
            rounds = sorted({str(groups[dataset][r["assembly_id"]]["generation_round"]) for r in selected})
            for generation in rounds:
                strata.append(("generation_round=" + generation,
                    [r for r in selected if str(groups[dataset][r["assembly_id"]]["generation_round"]) == generation], False))
        for name, entries, allow_ci in strata:
            for field in fields:
                result.append({"dataset": dataset, "cohort": name, "field": field,
                    "primary_field": field == ("domains" if dataset == "tdomain" else "balanced"),
                    "regions": entries, "allow_ci": allow_ci and dataset != "bode1"})
    return result


def label_for(region, labels):
    return labels[region["dataset"]][region["assembly_id"]]


def group_for(region, groups):
    group = groups[region["dataset"]][region["assembly_id"]]
    if region["dataset"] == "bode2":
        value = group.get("donor_triplet_group")
        require(isinstance(value, str) and value, "Missing BODE2 donor-triplet group")
    elif region["dataset"] == "tdomain":
        value = group.get("minimum_ancestry_group")
        require(isinstance(value, str) and value, "Missing T-domain minimum ancestry group")
    else:
        value = region["assembly_id"]  # Never used to form BODE1 IID intervals.
    return value


def evaluate_subset(entries, method, field, index, labels, *, macro=False, panel_key=None):
    selected = [r for r in entries if available(index[(r["dataset"], r["region_id"], method)], field)]
    counts = {"n_regions_available": len(selected), "n_assemblies_available": len({r["assembly_id"] for r in selected}),
        "positive_regions_available": sum(label_for(r, labels) for r in selected),
        "negative_regions_available": sum(1 - label_for(r, labels) for r in selected)}
    if not macro:
        metrics = binary_metrics([label_for(r, labels) for r in selected],
                                 [index[(r["dataset"], r["region_id"], method)][field] for r in selected])
        return {**counts, **metrics, "n_mixed_panels": None, "n_regions_in_mixed_panels": len(selected) if metrics["auroc"] is not None else 0}, []
    panels = defaultdict(list)
    for region in selected:
        panels[panel_key(region) if panel_key else background(region)].append(region)
    panel_rows = []
    for panel, members in sorted(panels.items()):
        yy = [label_for(r, labels) for r in members]
        values = [index[(r["dataset"], r["region_id"], method)][field] for r in members]
        score = binary_metrics(yy, values)
        panel_rows.append({"panel_id": panel, "n_regions": len(members), "n_assemblies": len({r["assembly_id"] for r in members}),
            "positive": sum(yy), "negative": len(yy) - sum(yy), **score})
    usable = [p for p in panel_rows if p["auroc"] is not None]
    metrics = {"auroc": sum(p["auroc"] for p in usable) / len(usable) if usable else None,
               "average_precision": sum(p["average_precision"] for p in usable) / len(usable) if usable else None,
               "reason": None if usable else "NO_MIXED_LABEL_PANELS", "n_mixed_panels": len(usable),
               "n_regions_in_mixed_panels": sum(p["n_regions"] for p in usable)}
    return {**counts, **metrics}, panel_rows


def shared_entries(entries, methods, field, index):
    return [r for r in entries if all(available(index[(r["dataset"], r["region_id"], m)], field) for m in methods)]


def uncertainty(spec, selected, first, field, index, labels, groups, reps, seed, second=None):
    if not spec["allow_ci"]:
        return no_bootstrap("NO_IID_CI_OVERLAPPING_FACTORIAL_PANELS" if spec["dataset"] == "bode1" else "DESCRIPTIVE_STRATUM_ONLY")
    if not selected:
        return no_bootstrap("NO_SHARED_ELIGIBLE_REGIONS")
    yy = [label_for(r, labels) for r in selected]
    aa = [index[(r["dataset"], r["region_id"], first)][field] for r in selected]
    bb = [index[(r["dataset"], r["region_id"], second)][field] for r in selected] if second else None
    return cluster_bootstrap(yy, aa, [group_for(r, groups) for r in selected], b=bb, reps=reps,
        seed=deterministic_seed(seed, spec["dataset"], spec["cohort"], field, first, second))


def exact_panels(spec, method, index):
    """Panels contain >=2 engineered candidates with distinct domain pieces."""
    bins = defaultdict(list)
    excluded = Counter()
    for region in spec["regions"]:
        row = index[(region["dataset"], region["region_id"], method)]
        if not available(row, spec["field"]):
            excluded["UNAVAILABLE"] += 1
            continue
        context, piece = signature(row.get("context_signature")), signature(row.get("piece_signature"))
        if context is None or piece is None:
            excluded["MISSING_SIGNATURE"] += 1
            continue
        key = json.dumps([background(region), context], separators=(",", ":"))
        bins[key].append(region)
    kept, mapping, catalog = [], {}, []
    for key, entries in sorted(bins.items()):
        pieces = {signature(index[(r["dataset"], r["region_id"], method)]["piece_signature"]) for r in entries}
        valid = len(entries) >= 2 and len(pieces) >= 2
        catalog.append({"panel_id": key, "method": method, "n_engineered_candidates": len(entries),
                        "distinct_domain_pieces": len(pieces), "eligible_candidate_panel": valid})
        if not valid:
            excluded["FEWER_THAN_TWO_DISTINCT_ENGINEERED_PIECES"] += len(entries)
            continue
        kept.extend(entries)
        mapping.update({r["region_id"]: key for r in entries})
    return kept, mapping, catalog, dict(excluded)


def standard_tables(specs, index, labels, groups, reps, seed):
    metrics, coverage, panels, contrasts = [], [], [], []
    for spec in specs:
        ds, cohort, field, entries = (spec[k] for k in ("dataset", "cohort", "field", "regions"))
        base = {"dataset": ds, "cohort": cohort, "field": field, "primary_field": spec["primary_field"],
                "metric_unit": "macro_within_background" if ds == "bode1" else "pooled_constructs"}
        for method in METHODS:
            selected = shared_entries(entries, (method,), field, index)
            stats, pp = evaluate_subset(entries, method, field, index, labels, macro=ds == "bode1")
            ci = uncertainty(spec, selected, method, field, index, labels, groups, reps, seed)
            metrics.append({**base, "method": method, **stats, **ci})
            coverage.append({**base, "method": method, "planned_regions": len(entries),
                "planned_unique_assemblies": len({r["assembly_id"] for r in entries}),
                "scored_regions": len(selected), "missing_regions": len(entries) - len(selected),
                "status_counts": dict(Counter(index[(ds, r["region_id"], method)]["status"] for r in entries)),
                "scored_fraction": len(selected) / len(entries) if entries else None})
            panels.extend({**base, "method": method, **p} for p in pp)
        for first, second in PAIRS:
            selected = shared_entries(entries, (first, second), field, index)
            a, _ = evaluate_subset(selected, first, field, index, labels, macro=ds == "bode1")
            b, _ = evaluate_subset(selected, second, field, index, labels, macro=ds == "bode1")
            delta = a["auroc"] - b["auroc"] if a["auroc"] is not None and b["auroc"] is not None else None
            contrasts.append({**base, "first": first, "second": second, "delta_definition": "first minus second",
                "shared_regions": len(selected), "shared_unique_assemblies": len({r["assembly_id"] for r in selected}),
                "shared_positive_regions": sum(label_for(r, labels) for r in selected),
                "shared_negative_regions": sum(1 - label_for(r, labels) for r in selected),
                "shared_mixed_panels": a["n_mixed_panels"], "shared_regions_in_mixed_panels": a["n_regions_in_mixed_panels"],
                "first_auroc_on_shared_coverage": a["auroc"], "second_auroc_on_shared_coverage": b["auroc"],
                "auroc_delta": delta, "reason": a["reason"] or b["reason"],
                **uncertainty(spec, selected, first, field, index, labels, groups, reps, seed, second)})
    return metrics, coverage, panels, contrasts


def signature_tables(specs, index, labels):
    metrics, panels, contrasts = [], [], []
    for spec in specs:
        # Position/round breakdowns are already in ordinary coverage tables.
        if spec["cohort"] not in ("all_engineered", "primary65"):
            continue
        base = {"dataset": spec["dataset"], "cohort": spec["cohort"], "field": spec["field"],
                "metric_unit": "macro_within_exact_postmask_signature_panel", "ci95": None,
                "uncertainty_status": "DESCRIPTIVE_SIGNATURE_SUBPANELS"}
        for method in JOINT:
            entries, panel_map, catalog, excluded = exact_panels(spec, method, index)
            key = lambda region: panel_map[region["region_id"]]
            stats, pp = evaluate_subset(entries, method, spec["field"], index, labels, macro=True, panel_key=key)
            metrics.append({**base, "method": method, "declared_regions": len(spec["regions"]),
                "signature_eligible_regions": len(entries), "signature_eligible_panels": len(set(panel_map.values())),
                "excluded_region_reasons": excluded, **stats})
            values = {p["panel_id"]: p for p in pp}
            panels.extend({**base, **item, **values.get(item["panel_id"], {})} for item in catalog)
            for first, second in PAIRS:
                if first != method:
                    continue
                shared = shared_entries(entries, (first, second), spec["field"], index)
                # Missing comparator scores can remove the last distinct alternative.
                # Recheck panel eligibility on the actual paired intersection.
                shared_bins = defaultdict(list)
                for region in shared:
                    shared_bins[key(region)].append(region)
                shared = [r for members in shared_bins.values()
                          if len(members) >= 2 and len({signature(index[(r["dataset"], r["region_id"], first)]
                              ["piece_signature"]) for r in members}) >= 2 for r in members]
                a, _ = evaluate_subset(shared, first, spec["field"], index, labels, macro=True, panel_key=key)
                b, _ = evaluate_subset(shared, second, spec["field"], index, labels, macro=True, panel_key=key)
                contrasts.append({**base, "panel_defining_method": method, "first": first, "second": second,
                    "shared_regions": len(shared), "shared_mixed_panels": a["n_mixed_panels"],
                    "first_auroc_on_shared_coverage": a["auroc"], "second_auroc_on_shared_coverage": b["auroc"],
                    "auroc_delta": a["auroc"] - b["auroc"] if a["auroc"] is not None and b["auroc"] is not None else None,
                    "delta_definition": "first minus second", "reason": a["reason"] or b["reason"]})
    return metrics, panels, contrasts


def same_piece_tables(region_index, index, labels):
    """Domains-only scores avoid treating changed flanking windows as fixed pieces."""
    rows, summary = [], []
    for dataset in ("bode1", "bode2", "tdomain"):
        engineered = [r for (ds, _), r in region_index.items() if ds == dataset and r["role"] == "engineered"]
        for method in METHODS:
            bins = defaultdict(list)
            for region in engineered:
                score = index[(dataset, region["region_id"], method)]
                piece = signature(score.get("piece_signature"))
                if available(score, "domains") and piece is not None:
                    bins[piece].append(region)
            selected_rows = []
            for piece, entries in sorted(bins.items()):
                backgrounds = {background(r) for r in entries}
                if len(backgrounds) < 2:
                    continue
                values = [index[(dataset, r["region_id"], method)]["domains"] for r in entries]
                eligible = [r for r in entries if r["assembly_id"] in labels.get(dataset, {})]
                yy = [label_for(r, labels) for r in eligible]
                ss = [index[(dataset, r["region_id"], method)]["domains"] for r in eligible]
                metric = binary_metrics(yy, ss)
                if len({background(r) for r in eligible}) < 2:
                    metric = {"auroc": None, "average_precision": None, "reason": "FEWER_THAN_TWO_LABELED_BACKGROUNDS"}
                item = {"dataset": dataset, "method": method, "field": "domains", "piece_signature": piece,
                    "n_regions": len(entries), "n_backgrounds": len(backgrounds),
                    "positions": sorted({str(r["position"]) for r in entries}),
                    "n_labeled_regions": len(eligible), "positive": sum(yy), "negative": len(yy) - sum(yy),
                    "score_min": min(values), "score_max": max(values), "score_range": max(values) - min(values),
                    "score_std": float(np.std(values)), **metric,
                    "interpretation": "Same ordered domain-feature hashes/types, changed background; boundary sequences are excluded from the fixed-piece definition; descriptive, not causal"}
                rows.append(item)
                selected_rows.append(item)
            mixed = [r for r in selected_rows if r["auroc"] is not None]
            summary.append({"dataset": dataset, "method": method, "field": "domains",
                "pieces_in_multiple_backgrounds": len(selected_rows), "mixed_label_pieces": len(mixed),
                "macro_within_piece_auroc": sum(r["auroc"] for r in mixed) / len(mixed) if mixed else None,
                "regions_in_mixed_pieces": sum(r["n_labeled_regions"] for r in mixed),
                "ci95": None, "uncertainty_status": "DESCRIPTIVE_DEPENDENT_CONTEXTS",
                "hybrid_binary_labels_created": False})
    return rows, summary


def evaluate_scores(score_file, out_dir, sealed_sha, *, data_dir=None, bootstrap_reps=2000, seed=20261007):
    score_file, out_dir = Path(score_file), Path(out_dir)
    require(isinstance(sealed_sha, str) and len(sealed_sha) == 64 and sha(score_file) == sealed_sha,
            "Region scores must match the supplied prediction seal before labels are opened")
    require(type(bootstrap_reps) is int and bootstrap_reps >= 100, "Use at least100 declared bootstrap repetitions")
    data_dir = Path(data_dir) if data_dir else Path(__file__).resolve().parent / "data"
    # This is the first label access; callers must create their prediction seal first.
    labels = read_json(data_dir / "labels.json")
    groups = read_json(data_dir / "groups.json")
    regions = read_json(data_dir / "regions.json")
    rows = read_scores(score_file)
    region_index, index = prepare(rows, regions, labels, groups)
    specs = cohorts(region_index, labels, groups)
    metric, coverage, panels, contrast = standard_tables(specs, index, labels, groups, bootstrap_reps, seed)
    exact_metric, exact_panel, exact_contrast = signature_tables(specs, index, labels)
    pieces, piece_summary = same_piece_tables(region_index, index, labels)
    all_coverage = []
    for dataset in sorted({r["dataset"] for r in regions}):
        for role in sorted({r["role"] for r in regions if r["dataset"] == dataset}):
            rr = [r for r in regions if r["dataset"] == dataset and r["role"] == role]
            for method in METHODS:
                all_coverage.append({"dataset": dataset, "role": role, "method": method,
                    "regions": len(rr), "labeled_regions": sum(r["assembly_id"] in labels.get(dataset, {}) for r in rr),
                    "status_counts": dict(Counter(index[(dataset, r["region_id"], method)]["status"] for r in rr)),
                    "primary_binary_metrics_role_eligible": role == "engineered"})
    summary = {"status": "FROZEN_CONTEXT_AUDIT_EVALUATED", "study_role": "RETROSPECTIVE_DEVELOPMENT_AUDIT",
        "prediction_sha256": sealed_sha, "predictions_verified_before_label_access": True,
        "methods": list(METHODS), "orientation": "Higher score means more agreement for every method; no score reversal",
        "primary_fields": {"bode1": "balanced", "bode2": "balanced", "tdomain": "domains"},
        "tdomain_secondary_field": "neighborhood_mean", "bootstrap_repetitions": bootstrap_reps, "seed": seed,
        "metrics": metric, "paired_contrasts": contrast, "exact_context_metrics": exact_metric,
        "same_piece_context_summary": piece_summary, "coverage": all_coverage,
        "source_files_sha256": {name: sha(data_dir / name) for name in ("regions.json", "labels.json", "groups.json")},
        "limitations": ["BODE1 backgrounds and their repeated assemblies overlap; no IID background/region confidence interval is reported.",
            "BODE2 confidence intervals resample donor triplets and preserve paired method membership.",
            "T-domain intervals use minimum known ancestry groups, which do not establish homology independence; guided ancestry and selection dependence remain.",
            "Method comparisons use identical scored candidate intersections; differing coverage is reported explicitly.",
            "Exact-input panels require at least two engineered candidates and two distinct domain pieces after the fixed masks; they do not establish causal fault localization.",
            "Same-piece context discrimination uses domain scores, while neighboring boundary sequences may change.",
            "No hybrid activity label, assay threshold, score direction, pretrained weight or classifier is fitted or selected here.",
            "Bootstrap intervals are descriptive group-resampling intervals, unadjusted for the prespecified multiple comparisons."]}
    out_dir.mkdir(parents=True, exist_ok=True)
    for name, table in (("metrics.csv", metric), ("coverage.csv", coverage), ("all_role_coverage.csv", all_coverage),
                        ("background_panels.csv", panels), ("paired_contrasts.csv", contrast),
                        ("exact_context_metrics.csv", exact_metric), ("exact_context_panels.csv", exact_panel),
                        ("exact_context_paired_contrasts.csv", exact_contrast),
                        ("same_piece_context_panels.csv", pieces), ("same_piece_context_summary.csv", piece_summary)):
        write_csv(out_dir / name, table)
    # Detect accidental score changes during an evaluation or concurrent write.
    require(sha(score_file) == sealed_sha, "Region scores changed during evaluation")
    dump(out_dir / "summary.json", summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--sealed-sha", required=True)
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--bootstrap-reps", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=20261007)
    args = parser.parse_args()
    report = evaluate_scores(args.input, args.out, args.sealed_sha, data_dir=args.data_dir,
                             bootstrap_reps=args.bootstrap_reps, seed=args.seed)
    print(json.dumps({"status": report["status"], "prediction_sha256": report["prediction_sha256"],
                      "metric_rows": len(report["metrics"]), "paired_contrasts": len(report["paired_contrasts"])}))


if __name__ == "__main__":
    main()
