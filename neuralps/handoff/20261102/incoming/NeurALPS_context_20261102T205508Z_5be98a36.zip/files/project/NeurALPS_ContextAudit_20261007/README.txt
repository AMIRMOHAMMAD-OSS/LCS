NeurALPS frozen context-contribution and joint-mask audit
=======================================================

Purpose
-------
Evaluate whether the existing compatibility map captures context-dependent
ordering, and whether hiding an entire exchanged region changes its usefulness.
This is development on already inspected datasets. It trains nothing and does
not generate a new natural-reference scale, HTML report, or activity classifier.

Use on Jean Zay (from the NeurALPSv2 project directory)
----------------------------------------------------
unzip -n NeurALPS_ContextAudit_20261007.zip
python3 NeurALPS_ContextAudit_20261007/verify.py
bash NeurALPS_ContextAudit_20261007/submit.sh
bash NeurALPS_ContextAudit_20261007/status.sh

Optional validation without submitting:
bash NeurALPS_ContextAudit_20261007/submit.sh preflight

The default is one A100, 8 CPU cores, 2-hour allocation maximum; actual duration
depends on the cluster. The login-node preflight does not load the GPU model.
There are no --mem, --mem-per-cpu or --mem-per-gpu Slurm options.

Required existing sources
-------------------------
- Original NeurALPS_Assembly_v1_20261002, RAM, Continue, Continue30 and Ensemble
  packages, with the checkpoint lineage dependencies already on Jean Zay.
- e1_ssl_continue30_v1_530757 (selected best.pt step 26000).
- e0_training_prep_461027 and e0_cache_final_491894, unchanged.
- e10_tdomain_embed_696333, unchanged; its separate 290-row sidecar is reused.
- e11_tdomain_transfer_699466/scores/records.json.gz, the exact sealed input routes
  used for the previous T-domain compatibility scores.
No ESMC embedding recomputation or raw paper download is required.

What is compared
----------------
single_full/local reproduce the original one-object-at-a-time maps.
joint_full/local jointly hide every region domain and touching boundary.
joint_common_full/local additionally share the union mask across comparable
alternatives and require exactly equal model input tensors. Geometry-incompatible
alternatives remain unscored for this stricter test. Every required object needs
at least two independent visible context objects under the inherited rule.
type_mean is the original Natural-train mean predictor, with no assembly encoder.

Local means global blocks disabled; four radius-6 local layers remain. It is NOT
a candidate-only network. Domain-only type_mean is the candidate marginal
control; boundary sequences inherently incorporate nearby sequence.

All seven methods are scored without activity fitting. Higher raw agreement
always means greater compatibility. New joint-query raw values are not mapped
through the old natural-percentile reference, which used different masks.

Regions and endpoints
---------------------
BODE1: 324 constructs, 972 region queries, 144 backgrounds. Primary: mean within-
background AUROC. BODE2: 105 engineered constructs, 35 donor triplets, three swap
positions; position-specific metrics and pooled secondary metrics. Its native
assembly has three reference regions and is excluded from activity metrics.
T-domain: 88 scored assemblies (84 engineered, 4 native); binary analysis remains
the audited 65 minimal-scaffold constructs (50 nonzero, 15 zero). PCP-only score is
primary; mean of PCP+two flanks is secondary. Fixed source-agreement 63 and
design-round analyses are retained. No binary labels are invented for 19 hybrids.

The packet includes five exact T-domain sequences used across multiple contexts,
but those hybrid assays currently lack a common authoritative binary endpoint.
Their maps can reveal model sensitivity; they cannot yet validate activity-
dependent context changes. Likewise an unchanged BODE piece's association with
whole-assembly activity does not establish that this piece caused inactivity.

Every method comparison uses shared available constructs/backgrounds. BODE1
overlapping factorial panels receive descriptive point contrasts, not an IID CI.
BODE2 and T-domain intervals resample declared donor/ancestry groups. These are
not claims of complete family independence. All orientation/aggregation choices
are fixed in PROTOCOL.json; no highest-AUC method is automatically selected.

Outputs
-------
e12_context_audit_JOBID/summary.json                 compact status
e12_context_audit_JOBID/evaluation/summary.json      AUROCs and paired comparisons
e12_context_audit_JOBID/evaluation/*.csv             detailed metrics/coverage
e12_context_audit_JOBID/region_scores.jsonl.gz        all seven methods, explicit nulls
e12_context_audit_JOBID/mask_plans.json.gz            primary/overlap/common masks
e12_context_audit_JOBID/common_input_audit.json       actual input-equality checks
e12_context_audit_JOBID/original_score_parity.json    original-map reproduction
e12_context_audit_JOBID/context_audit_inspection.zip complete inspectable packet

The run fails before evaluating new outcomes if the original single-piece
scores cannot be reproduced within the declared fp32 tolerance. Check the log
or fatal_error.json rather than relaxing this gate. SHA256 identities and
per-assembly checkpoints make interrupted runs reviewable and resumable.

Resume only an interrupted/failed output with unchanged inputs:
bash NeurALPS_ContextAudit_20261007/submit.sh resume /absolute/path/e12_context_audit_JOBID

Validation status
-----------------
VALIDATION.json distinguishes local original-code/synthetic numerical checks,
existing-score metric regressions and real BODE mask planning from production
GPU inference. The production checkpoint and T-domain sidecar remain on Jean
Zay; new joint-mask AUROCs are not known until this package runs there.

Data provenance
---------------
data/provenance.json pins the existing source archives and audited mappings.
data/endpoints.json preserves reviewed assay endpoint distinctions. The new
inference path never reads this endpoint file. data/build_snapshot.py documents
how this compact data packet was assembled; its local archive paths are only
needed to recreate the packet, not to run the cluster benchmark.
