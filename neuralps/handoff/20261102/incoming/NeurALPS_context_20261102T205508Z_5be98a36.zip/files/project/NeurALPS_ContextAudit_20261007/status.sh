#!/usr/bin/env bash
set -euo pipefail
NRPS_AUDIT_PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
exec python3 -B "$NRPS_AUDIT_PACKAGE/launch.py" status "$@"
