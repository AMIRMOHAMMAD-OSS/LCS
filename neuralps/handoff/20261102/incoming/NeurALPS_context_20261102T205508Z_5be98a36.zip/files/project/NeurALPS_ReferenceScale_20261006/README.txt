NeurALPS natural reference scale — frozen SSL checkpoint 26000

This bundle prepares an empirical, type-matched scale for the domain/boundary
maps. It does not contain already-calibrated scores. The real checkpoint,
target means and feature cache are on Jean Zay, so a new inference run is needed.
No pretrained weights, activity classifiers or BODE labels are fitted here.

DATA ROLE CHANGE WHEN YOU RUN IT

The 3,515 natural internal-test assemblies were previously reserved for final
natural-context evaluation. This run explicitly reassigns connected groups from
that split to calibration or audit, using a fixed hash before model inference.
It is roughly a 50/50 split by groups; assembly counts can be unbalanced.
Those assemblies must thereafter be described as calibration/audit data, not an
untouched test set. The remaining audit portion is used to check this fixed
scale, not to select its thresholds. Future model selection using its results
would make that audit development data as well.

WHAT THE SCALE MEANS

Every actual natural piece is masked in its own natural assembly context, with
the exact same overlap/exact-copy masking closure used for the BODE maps.
The unchanged model reconstructs its frozen ESM-C vector. Raw agreement remains
1 minus the original 0.25 raw + 0.75 centered cosine-error mixture; the original
near-zero-residual fallback is preserved. Protein breaks are scored jointly
once. These are individual-piece masks, not whole exchanged-fragment masks.

Compare like with like: domain type; ordered flanking types for boundaries;
separate physical kind/query mode; and masking-fraction band. First try log2
slot-length matching. An explicit length-unmatched fallback may be used within
the same type/mode/mask band. Types and physical kinds are never silently pooled.

The display percentile is:
  100 * (number of reference scores below yours + half the ties) / n.

  0   No selected reference score lies below yours (apart from tie convention).
  5   Approximately the lower 5% of this specified natural reference.
  50  Near the middle of this reference distribution.
  95  Higher agreement than about 95% of this reference.
  100 At the upper end or beyond the observed reference scores.

These numbers are not percentages of biological compatibility or activity.
Natural sequences are not experimentally verified positive activity labels.
Zero does not mean impossible/inactive, and 100 does not mean certain activity.

Warnings use a separate conservative lower-tail rank:
  (1 + number of reference scores at or below yours) / (n + 1).
Its minimum is positive: 1/(n+1), even when the display percentile is zero.
Rank <=0.05 gives LOW_NATURAL_SUPPORT. Rank <=0.01 is reported VERY_LOW only
with at least 500 reference components. At least 100 components are required
for any numerical scale; otherwise the result is INSUFFICIENT_REFERENCE.
These support cutoffs are fixed pragmatic rules, not a theorem of precision.

DEPENDENCE, AUDIT, AND LIMITS

Natural assemblies sharing a taxonomy group, exact protein sequence, or exact
observed feature sequence are joined into connected components. Components
cannot cross calibration/audit. One object is selected by a score-blind hash
per component and stratum, so repeated domains and long assemblies do not get
extra independent votes. Large connected components can reduce coverage;
the code does not relax the grouping to manufacture support.

For each resolved reference stratum the audit selects one object per separate
audit component and reports its <=5% warning rate and a descriptive Wilson
95% interval. With >=100 audit components, the predeclared diagnostic checks
whether the interval lies below a 10% warning-rate ceiling, above it, or is
indeterminate. This ceiling is a diagnostic tolerance, not a promised 5%
false-positive guarantee. The audit status and count accompany each BODE score.
Strata overlap components: do not pool all their observations as independent.

Taxonomy and exact identities do not establish complete homology independence.
Train/dev target-feature and parent overlap are exported. Distribution shift
from natural to engineered assemblies can invalidate formal tail guarantees.
Therefore this is an empirical natural-context reference with an audit, not
formal conformal certification or a calibrated inactivity probability.
Methodological background: https://arxiv.org/abs/2104.08279

Per-piece flags do not give an assembly-level failure decision. Long lines can
have several flags by chance; no multiple-testing or worst-piece calibration is
claimed. Low support is a region to inspect, not a validated causal diagnosis.
The audit can reveal that the scale is inadequate for some or all groups.

The previously saved BODE1 and BODE2 raw scores are reproduced and checked for
parity (14,002 physical objects, tolerance 2e-5) before any reference scale is
exported. No BODE activity outcomes are used to select references/thresholds.

RUN ON JEAN ZAY

Copy this ZIP to the existing project root. Extract as a NEW sibling package;
do not overwrite any earlier model or experiment directory.

  cd /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2
  unzip -n NeurALPS_ReferenceScale_20261006.zip
  python3 -B NeurALPS_ReferenceScale_20261006/verify.py
  bash NeurALPS_ReferenceScale_20261006/submit.sh calibrate
  bash NeurALPS_ReferenceScale_20261006/status.sh

One A100, eight CPU cores, maximum wall time four hours. Actual inference time
has not been measured; queue delay is separate. This is inference, not another
training run. The launcher prevents duplicate submissions for this package.

Read-only full-cohort preflight without submission:
  bash NeurALPS_ReferenceScale_20261006/submit.sh preflight

If interrupted or failed, inspect the error. To resume the SAME inputs:
  bash NeurALPS_ReferenceScale_20261006/submit.sh resume /absolute/path/to/e8_reference_scale_JOBID

Per-assembly score shards have identities and checksums. Completed shards are
reused on resume. Changing code/model/protocol/runtime refuses reuse. If a score
parity or data-contract check fails, retain the output for inspection.

The reviewed existing packages and their original source dependencies must
still be present alongside this folder. The launcher verifies their hashes:
  NeurALPS_Ensemble_20261004
  NeurALPS_BODE30_20261003
  NeurALPS_Assembly_v1_20261002 and its continuation/RAM dependencies
  e1_ssl_continue30_v1_530757 and its original parent/target/cache/data inputs

FILES TO RETURN

The status command prints:
  e8_reference_scale_JOBID/reference_scale_inspection.zip

That ZIP contains the exact split, frozen protocol, raw natural scores,
reference distributions and selected representatives, reference counts,
train/dev overlap audit, natural warning-rate audit, BODE1/BODE2 piece tables,
per-piece audit status, raw-score parity, and a compact summary.

The useful tables are bode1_piece_scale.csv and bode2_piece_scale.csv. Keep
native_score, natural_percentile, reference count/level, and audit status
together. A scaled value with little audit support is not a validated flag.
No HTML report is generated.

TRANSFER FROM MAC (download ZIP into /Users/amir/Downloads first)

  scp -J apandi@gate.lcqb.hosted.lip6.fr \
    /Users/amir/Downloads/NeurALPS_ReferenceScale_20261006.zip \
    unh87ms@jean-zay.idris.fr:/lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2/

IF DOWNLOADED ON WINDOWS, POWERSHELL -> MAC FIRST

  scp -o PreferredAuthentications=password -o PubkeyAuthentication=no `
    "$env:USERPROFILE\Downloads\NeurALPS_ReferenceScale_20261006.zip" `
    amir@100.72.70.1:/Users/amir/Downloads/

Then run the Mac transfer and Jean Zay commands above.

LOCAL CHECKS

  python3 -B selftest.py
  python3 -B selftest_cohorts.py

See VALIDATION.json for exactly what was verified locally. Local checks do not
claim that the real GPU checkpoint inference or natural calibration has run.
