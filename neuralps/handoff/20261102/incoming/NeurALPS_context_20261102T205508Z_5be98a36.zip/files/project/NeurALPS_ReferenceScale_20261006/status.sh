#!/usr/bin/env bash
set -euo pipefail
NRPS_SCALE_PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
python3 -B "$NRPS_SCALE_PACKAGE/launch.py" status "$@"
