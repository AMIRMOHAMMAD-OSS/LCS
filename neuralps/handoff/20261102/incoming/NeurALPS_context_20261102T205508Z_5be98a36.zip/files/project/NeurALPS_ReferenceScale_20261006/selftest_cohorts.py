"""Portable cohort-contract tests using synthetic records and a temporary DB."""
import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile

from cohorts import (
    EXPECTED_COUNTS,
    _connected_components,
    _strip_labels,
    _taxonomy,
    prepare_cohorts,
)


def _h(text):
    return hashlib.sha256(text.encode()).hexdigest()


def _record(aid, dataset, split, *, taxonomy=None, parent=None, feature=None, label=1):
    parent = parent or _h("parent:" + aid)
    feature = feature or _h("feature:" + aid)
    protein = aid + "|protein=1"
    return {
        "assembly_id": aid, "dataset": dataset, "split": split,
        "record_id": aid, "taxonomy_group": taxonomy,
        "label": label, "label_status": "SYNTHETIC_TEST_ONLY",
        "original_label_fields": {"activity": label, "peak_score": label},
        "n_domains": 1, "n_chains": 1,
        "parent_sequence_hashes": {protein: parent},
        "parent_lengths": {protein: 30},
        "route": [{"kind": 0, "domain_type": 1, "seq_hash": feature}],
        "model_slots": [{
            "object_index": 0, "slot": 0, "kind": 0, "state": "OBSERVED",
            "sequence_hash": feature, "parent_sequence_hash": parent,
            "protein_uid": protein, "length": 20, "start": 0, "end": 20,
            "group": "D:1",
        }],
    }


def _fixture_rows():
    train_feature, train_parent = _h("shared_train_feature"), _h("shared_train_parent")
    rows = [
        _record("train0", "natural", "train", taxonomy="train_species", feature=train_feature, parent=train_parent),
        _record("dev0", "natural", "dev", taxonomy="dev_species"),
        _record("test_a", "natural", "internal_test", taxonomy="linked_species"),
        _record("test_b", "natural", "internal_test", taxonomy="linked_species", parent=_h("shared_parent_bc")),
        _record("test_c", "natural", "internal_test", taxonomy="different_species_c", parent=_h("shared_parent_bc"), feature=_h("shared_feature_cd")),
        _record("test_d", "natural", "internal_test", taxonomy="different_species_d", feature=_h("shared_feature_cd")),
    ]
    rows.extend(_record("test_independent_"+str(i), "natural", "internal_test", taxonomy="independent_species_"+str(i)) for i in range(12))
    rows.extend([
        _record("bode1_a", "bode1", "supervised", feature=train_feature),
        _record("bode1_b", "bode1", "supervised", parent=train_parent),
        _record("bode2_a", "bode2", "external"),
    ])
    return rows


def _write_fixture(path, rows):
    with sqlite3.connect(path) as connection:
        connection.execute("CREATE TABLE assemblies(dataset TEXT, assembly_id TEXT, split TEXT, label INTEGER, payload TEXT)")
        connection.executemany(
            "INSERT INTO assemblies VALUES(?,?,?,?,?)",
            [(r["dataset"], r["assembly_id"], r["split"], r["label"], json.dumps(r)) for r in rows],
        )


def run():
    """Run self-contained assertions and return a short JSON-compatible summary."""
    small_counts = {"natural_train": 1, "natural_dev": 1, "natural_internal_test": 16, "bode1": 2, "bode2": 1}
    assert small_counts != EXPECTED_COUNTS
    rows = _fixture_rows()
    with tempfile.TemporaryDirectory(prefix="reference_scale_cohorts_test_") as tmp:
        first = Path(tmp) / "first.sqlite3"
        second = Path(tmp) / "reversed.sqlite3"
        _write_fixture(first, rows)
        # SQL ordering plus set-based linkage must erase ingestion order.
        _write_fixture(second, list(reversed(rows)))
        try:
            prepare_cohorts(first)
        except ValueError as error:
            assert "Full cohort count preflight failed" in str(error)
        else:
            raise AssertionError("Strict production counts accepted a toy database")
        result = prepare_cohorts(first, expected_counts=small_counts)
        reversed_result = prepare_cohorts(second, expected_counts=small_counts)
        assert result == reversed_result
        records, split, overlap = result
        for item in result:
            assert json.loads(json.dumps(item, sort_keys=True)) == item
        assert len(records) == 19
        assert split["test_expected_counts_override"] is True
        assert split["production_counts_verified"] is False
        assert "train0" not in records and "dev0" not in records
        assert all("label" not in key.lower() for record in records.values() for key in record)
        linked = {split["metadata"]["test_"+letter]["component_id"] for letter in "abcd"}
        assert len(linked) == 1
        component = split["components"][next(iter(linked))]
        assert component["assembly_ids"] == ["test_a", "test_b", "test_c", "test_d"]
        assert len(split["components"]) == 13
        for proof in split["union_audit"]["disjointness_proof"].values():
            assert proof["cross_role_shared_count"] == 0
        assert overlap["queries"]["bode1_a|object=0|roles=0"]["train"]["exact_feature_overlap_slots"] == [0]
        assert overlap["queries"]["bode1_b|object=0|roles=0"]["train"]["exact_parent_overlap_slots"] == [0]
        assert overlap["queries"]["bode2_a|object=0|roles=0"]["train"]["any_exact_feature_overlap"] is False
        # Alter every outcome while preserving genotypes: all three products
        # must remain bit-for-bit equivalent after JSON serialization.
        with sqlite3.connect(second) as connection:
            for row in reversed(rows):
                changed = dict(row, label=0, label_status="CHANGED_LABEL_IGNORED", original_label_fields={"activity": 0, "peak_score": 99})
                connection.execute("UPDATE assemblies SET label=0,payload=? WHERE assembly_id=?", (json.dumps(changed), row["assembly_id"]))
        assert prepare_cohorts(second, expected_counts=small_counts) == result
        # A genuine giant component is kept intact, even if this leaves a role
        # empty. No retry seed, species relaxation or sequence filter is allowed.
        with sqlite3.connect(second) as connection:
            for row in rows:
                if row["dataset"] == "natural" and row["split"] == "internal_test":
                    changed = dict(row, taxonomy_group="giant_component_species")
                    connection.execute("UPDATE assemblies SET payload=? WHERE assembly_id=?", (json.dumps(changed), row["assembly_id"]))
        _, giant, _ = prepare_cohorts(second, expected_counts=small_counts)
        assert len(giant["components"]) == 1
        assert giant["largest_component_assemblies"] == 16
        assert giant["usable_two_way_split"] is False
        assert any("empty" in warning for warning in giant["warnings"])

    # Direct helper tests do not depend on records returned from a database.
    stripped = _strip_labels({"label": 1, "original_label_fields": {"active": 1}, "nested": {"peak_score": 4, "sequence_hash": "keep"}})
    assert stripped == {"nested": {"sequence_hash": "keep"}}
    tax_a = _taxonomy({"assembly_id": "GCF_000000001.1|region=1", "taxonomy_group": None})
    tax_b = _taxonomy({"assembly_id": "GCF_000000001.1|region=2", "taxonomy_group": "unknown"})
    assert tax_a[1] == tax_b[1] == "fallback_accession:GCF_000000001.1"
    assert _taxonomy({"assembly_id": "unique", "taxonomy_group": None})[1] == "fallback_assembly:unique"
    metas = {
        "a": {"taxonomy_key": "tax1", "parent_hashes": {"p1"}, "feature_hashes": {"f1"}},
        "b": {"taxonomy_key": "tax1", "parent_hashes": {"p2"}, "feature_hashes": {"f2"}},
        "c": {"taxonomy_key": "tax2", "parent_hashes": {"p2"}, "feature_hashes": {"f3"}},
        "d": {"taxonomy_key": "tax3", "parent_hashes": {"p3"}, "feature_hashes": {"f3"}},
    }
    forward = _connected_components(metas)
    assert forward == _connected_components(dict(reversed(list(metas.items()))))
    assert len(forward[0]) == 1
    return {
        "status": "COHORT_SELFTEST_OK",
        "checks": ["production_count_rejection", "transitive_union", "permutation_invariance", "json_roundtrip", "outcome_independence", "label_removal", "exact_overlap", "giant_component_retained", "missing_taxonomy_fallback"],
    }


def selftest():
    """Alias for package selftest runners."""
    return run()


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True))
