"""Stream frozen SSL26 native-object reconstruction scores without activity labels.

Entry point: score_records(context, records, destination, identity, stopping).
``context`` is the validated Ensemble ``common.project`` context for SSL26;
``device`` may additionally be ``cpu`` or ``cuda`` (default cuda). The caller
must make that pinned package's ``frozen_runtime`` importable. ``records`` is an
assembly-ID mapping. Only structure/model-input fields are copied; labels are
never consumed. ``identity`` must be a JSON-compatible frozen run identity.

Output: immutable per-assembly ``shards/<sha256(assembly_id)>.jsonl.gz`` files
with atomic companion metadata, a resume identity, and summary.json. A completed
report contains relative shard paths and hashes. On a requested signal, return
None; fully sealed assemblies are reused on resume. Incomplete assemblies are
recomputed. No training, candidate panels, classifier or local-only control.

Rows include dataset/split, assembly/object/query IDs, kind/name, label,
domain_types and names (one target type or ordered flanking types), mode, slots
(role/state/group/length/log2 length-bin/feature+parent hashes/physical spans),
native_hashes, parent_hashes, native_score, reconstruction_error,
native_raw_cosine_loss, closure indices/fraction, remaining distinct context,
status, checkpoint hash and step. Grouping for reference calibration is left to
the caller. Here "label" is the domain-type display label, never assay activity.

Query selection copies the physical-object subset of the pinned BODE30
map_contract.query_modes: one query per domain/covalent boundary, both terminal
slots together per protein break. remaining_context copies that module exactly.
The original model, slot_loss, target means and masking_closure are imported
through the validated frozen runtime rather than reimplemented.
"""
import gzip
import hashlib
import json
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path

CHECKPOINT_SHA256 = '9599242bed3ffd7118593874cfe6462b30d1bae97dde1c8b6131d6fa44f70e0f'
SELECTED_STEP = 26000
FEATURE_DIM = 1152
MICROBATCH = 8
SCHEMA = 'nrps_native_object_scores_v1'
KINDS = ('domain', 'covalent_boundary', 'protein_break')
INPUT_FIELDS = ('assembly_id', 'dataset', 'split', 'route', 'model_slots',
                'parent_sequence_hashes', 'parent_lengths', 'boundary_window_policy')


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _json_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def _digest(value):
    return hashlib.sha256(_json_bytes(value)).hexdigest()


def _sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def _dump(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_bytes(_json_bytes(value) + b'\n')
    os.replace(tmp, path)


def _stopped(stopping):
    return bool(stopping and stopping.get('signal'))


def _clean_record(aid, record):
    # Copy only inputs and provenance; no activity-label value is inspected.
    result = {k: record[k] for k in INPUT_FIELDS if k in record}
    _require(result.get('assembly_id') == aid, 'Assembly key/record ID differ')
    _require(result.get('route') and result.get('model_slots'), 'Empty assembly input')
    return result


def _remaining_context(record, j, hidden):
    """Exact BODE30 map_contract.remaining_context implementation."""
    seen, count = set(), 0
    by_object = {}
    for s in record['model_slots']:
        if s['state'] == 'OBSERVED' and (s['object_index'], s['slot']) not in hidden:
            by_object.setdefault(s['object_index'], set()).add(s['sequence_hash'])
    for k in sorted(by_object):
        if k != j and abs(k-j) <= 24 and by_object[k]-seen:
            count += 1
            seen.update(by_object[k])
    return count


def _physical_queries(record):
    by_object = defaultdict(list)
    for s in record['model_slots']:
        by_object[s['object_index']].append(s)
    _require(set(by_object) == set(range(len(record['route']))), 'Incomplete physical-slot coverage')
    for j, obj in enumerate(record['route']):
        kind = obj['kind']
        _require(kind in (0, 1, 2), 'Unknown physical kind')
        slots = sorted(by_object[j], key=lambda s:s['slot'])
        roles = [s['slot'] for s in slots]
        _require(roles == ([1, 2] if kind == 2 else [0]), 'Unexpected physical slot roles')
        yield j, slots


def _row(record, j, slots, names):
    obj = record['route'][j]
    kind = obj['kind']
    if kind == 0:
        types = [obj['domain_type']]
    else:
        _require(0 < j < len(record['route'])-1 and
                 record['route'][j-1]['kind'] == record['route'][j+1]['kind'] == 0,
                 'Boundary does not have two adjacent domains')
        types = [record['route'][j-1]['domain_type'], record['route'][j+1]['domain_type']]
    labels = [names.get(t, 'UNKNOWN') for t in types]
    label = labels[0] if kind == 0 else ('COVALENT ' + ' -> '.join(labels) if kind == 1 else 'PROTEIN BREAK')
    aid = record['assembly_id']
    return dict(schema=SCHEMA, dataset=record.get('dataset'), split=record.get('split'),
        assembly_id=aid, object_index=j,
        object_id=obj.get('occurrence_id', obj.get('boundary_id', '')),
        query_id=aid+'|object='+str(j)+'|roles='+','.join(str(s['slot']) for s in slots),
        kind=kind, kind_name=KINDS[kind], label=label, domain_types=types,
        domain_type_names=labels,
        mode='joint_terminal_recovery' if kind == 2 else 'object_recovery',
        slots=[dict(slot=s['slot'], state=s['state'], group=s.get('group'),
                    length=s.get('length'), length_bin=max(0,int(s.get('length') or 0).bit_length()-1),
                    sequence_hash=s.get('sequence_hash'), parent_sequence_hash=s.get('parent_sequence_hash'),
                    start=s.get('start'), end=s.get('end')) for s in slots],
        native_hashes=[s.get('sequence_hash') for s in slots],
        parent_hashes=sorted({s['parent_sequence_hash'] for s in slots if s.get('parent_sequence_hash')}),
        native_score=None, reconstruction_error=None, native_raw_cosine_loss=None,
        hidden_slots=[], hidden_fraction=None, remaining_distinct_context_objects=None,
        status='PENDING', source_checkpoint_sha256=CHECKPOINT_SHA256, selected_step=SELECTED_STEP)


def _validate_physical_sources(record, store):
    for slot in record['model_slots']:
        if slot['state'] != 'OBSERVED':
            continue
        sequence = store.parent(slot['parent_sequence_hash'])[slot['start']:slot['end']]
        _require(len(sequence) == slot['length'] and
                 hashlib.sha256(sequence.encode()).hexdigest() == slot['sequence_hash'],
                 'Physical sequence does not match frozen feature: '+record['assembly_id'])


def _score_one(record, runtime, model, collate, names, stopping):
    import numpy as np
    import torch
    rows, pending = [], []
    n_observed = sum(s['state'] == 'OBSERVED' for s in record['model_slots'])
    _validate_physical_sources(record, runtime.store)

    def flush():
        if not pending:
            return
        batch = collate([record] * len(pending), runtime.store.vector)
        _require(batch['x'].shape[-1] == FEATURE_DIM, 'Wrong feature dimension')
        for b, (j, slots, row) in enumerate(pending):
            for index, role in row['hidden_slots']:
                batch['state'][b, index, role] = 4
                batch['x'][b, index, role] = float('nan')
        batch = {k:v.to(runtime.device) for k,v in batch.items()}
        with torch.no_grad():
            prediction = model.predict_masked(batch)
            _require(tuple(prediction.shape) == (len(pending), len(record['route']), 3, FEATURE_DIM),
                     'Wrong prediction shape')
            _require(bool(torch.isfinite(prediction).all()), 'Nonfinite reconstructed embedding')
            for b, (j, slots, row) in enumerate(pending):
                roles = [s['slot'] for s in slots]
                targets = torch.as_tensor(np.stack([runtime.store.vector(s['sequence_hash']) for s in slots]),
                                          device=runtime.device)
                means = torch.as_tensor(np.stack([runtime.targets.mean(s) for s in slots]), device=runtime.device)
                mixed, raw = runtime.ssl.slot_loss(prediction[b,j,roles], targets, means)
                error = float(mixed.mean().item())
                raw_error = float(raw.mean().item())
                _require(np.isfinite([error, raw_error]).all() and -1e-5 <= error <= 2.00001,
                         'Invalid reconstruction error')
                row.update(status='SCORED', native_score=float((1-mixed.mean()).item()),
                           reconstruction_error=error, native_raw_cosine_loss=raw_error)
        pending.clear()

    for j, slots in _physical_queries(record):
        if _stopped(stopping):
            return None
        row = _row(record, j, slots, names)
        rows.append(row)
        if any(s['state'] != 'OBSERVED' for s in slots):
            row['status'] = 'MISSING_SEQUENCE_FEATURE'
            continue
        hidden = runtime.closure(record, [(j,s['slot']) for s in slots],
                                 runtime.store.parent, 'independent_sequence')['hidden']
        hidden = [list(x) for x in hidden]
        row['hidden_slots'] = hidden
        row['hidden_fraction'] = len(hidden)/n_observed
        row['remaining_distinct_context_objects'] = _remaining_context(record, j, set(map(tuple,hidden)))
        if row['remaining_distinct_context_objects'] < 2:
            row['status'] = 'INSUFFICIENT_VISIBLE_CONTEXT'
            continue
        pending.append((j, slots, row))
        if len(pending) == MICROBATCH:
            flush()
    flush()
    if _stopped(stopping):
        return None
    _require(len(rows) == len(record['route']) and all(r['status'] != 'PENDING' for r in rows),
             'Physical query coverage incomplete')
    return rows


def _existing_shard(destination, aid, record_sha, identity_sha):
    stem = hashlib.sha256(aid.encode()).hexdigest()
    payload = destination/'shards'/(stem+'.jsonl.gz')
    metadata = destination/'shards'/(stem+'.json')
    if not metadata.exists():
        return None
    saved = json.loads(metadata.read_text())
    _require(saved['assembly_id'] == aid and saved['record_sha256'] == record_sha and
             saved['identity_sha256'] == identity_sha, 'Completed shard identity changed')
    _require(saved['path'] == str(payload.relative_to(destination)) and payload.is_file() and
             _sha(payload) == saved['sha256'], 'Completed shard file changed')
    with gzip.open(payload,'rt') as stream:
        rows = [json.loads(line) for line in stream]
    _require(len(rows) == saved['rows'] and [r['object_index'] for r in rows] == list(range(len(rows))) and
             all(r['assembly_id'] == aid for r in rows), 'Completed shard coverage changed')
    _require(dict(Counter(r['status'] for r in rows)) == saved['status_counts'], 'Shard status counts changed')
    return saved


def score_records(context, records, destination, identity, stopping):
    """Score all physical objects, resume sealed assemblies, return report or None."""
    destination = Path(destination)
    _require(records, 'No assemblies selected for scoring')
    _require(context['source_provenance']['best_checkpoint_sha256'] == CHECKPOINT_SHA256 and
             context['ssl_summary']['selected_step'] == SELECTED_STEP, 'Use the pinned SSL26 checkpoint')
    cfg = context['config']['settings']['encoder']
    _require(cfg.get('feature_dim',1152) == FEATURE_DIM and cfg.get('width',256) == 256,
             'Wrong frozen encoder dimensions')
    cleaned = {aid:_clean_record(aid,record) for aid,record in sorted(records.items())}
    record_hashes = {aid:_digest(record) for aid,record in cleaned.items()}
    request = dict(schema=SCHEMA, identity=identity, checkpoint_sha256=CHECKPOINT_SHA256,
                   selected_step=SELECTED_STEP, scorer_sha256=_sha(__file__),
                   records_sha256=_digest(record_hashes), assemblies=len(cleaned),
                   device=str(context.get('device','cuda')), microbatch=MICROBATCH)
    request_sha = _digest(request)
    destination.mkdir(parents=True, exist_ok=True)
    (destination/'shards').mkdir(exist_ok=True)
    resume = destination/'resume_identity.json'
    if resume.exists():
        _require(json.loads(resume.read_text()) == request, 'Scoring resume identity changed')
    else:
        _require(not any((destination/'shards').iterdir()), 'Unidentified existing shards')
        _dump(resume, request)
    completed, missing = [], []
    for aid in cleaned:
        saved = _existing_shard(destination, aid, record_hashes[aid], request_sha)
        if saved is None:
            missing.append(aid)
        else:
            completed.append(saved)
    if _stopped(stopping):
        return None
    if missing:
        import torch
        from frozen_runtime import open_runtime
        base_source = str(Path(context['base'])/'src')
        if base_source not in sys.path:
            sys.path.insert(0, base_source)
        # The inherited TensorBank requires a nonempty input and a label tensor.
        # Supply one structural record with a constant dummy label, then discard
        # that unused bank immediately. No real activity labels are copied/read.
        aid = min(missing, key=lambda a:(len(cleaned[a]['route']),a))
        bootstrap = dict(cleaned[aid], label=0)
        runtime_context = dict(context, records={aid:bootstrap})
        runtime = open_runtime(runtime_context, context.get('device','cuda'))
        _require(runtime.identities['best_checkpoint_sha256'] == CHECKPOINT_SHA256,
                 'Loaded model source identity differs')
        _require(runtime.store.z.shape == (548713,FEATURE_DIM), 'Wrong frozen feature cache shape')
        del runtime.bank
        from assembly_model import collate_records
        model = runtime.build('ssl').eval()
        model.requires_grad_(False)
        vocabulary = json.loads((Path(context['base'])/'domain_vocabulary.json').read_text())['vocab']
        names = {int(v):k for k,v in vocabulary.items()}
        try:
            for aid in missing:
                if _stopped(stopping):
                    return None
                rows = _score_one(cleaned[aid], runtime, model, collate_records, names, stopping)
                if rows is None:
                    return None
                stem = hashlib.sha256(aid.encode()).hexdigest()
                payload = destination/'shards'/(stem+'.jsonl.gz')
                tmp = payload.with_name(payload.name+'.tmp')
                raw = b''.join(_json_bytes(row)+b'\n' for row in rows)
                tmp.write_bytes(gzip.compress(raw,mtime=0))
                os.replace(tmp,payload)
                saved = dict(assembly_id=aid, record_sha256=record_hashes[aid], identity_sha256=request_sha,
                             path=str(payload.relative_to(destination)), sha256=_sha(payload),
                             rows=len(rows), status_counts=dict(Counter(r['status'] for r in rows)))
                _dump(destination/'shards'/(stem+'.json'),saved)
                completed.append(saved)
                if len(completed) % 25 == 0 or len(completed) == len(cleaned):
                    print(json.dumps(dict(stage='NATURAL_REFERENCE_SCORING', completed=len(completed),
                                          planned=len(cleaned))), flush=True)
        finally:
            del model
            runtime.store.db.close()
            if torch.cuda.is_available() and str(runtime.device).startswith('cuda'):
                torch.cuda.empty_cache()
    completed.sort(key=lambda r:r['assembly_id'])
    _require(len(completed) == len(cleaned), 'Missing completed assemblies')
    status = Counter()
    for row in completed:
        status.update(row['status_counts'])
    report = dict(status='NATIVE_REFERENCE_SCORING_COMPLETE', schema=SCHEMA,
                  identity=identity, identity_sha256=request_sha, selected_step=SELECTED_STEP,
                  checkpoint_sha256=CHECKPOINT_SHA256, assemblies=len(completed),
                  physical_objects=sum(r['rows'] for r in completed), status_counts=dict(status),
                  encoder_updated=False, activity_labels_used=False, candidate_panels_used=False,
                  shards=completed)
    _dump(destination/'summary.json',report)
    return report
