#!/usr/bin/env python3
"""Submit, inspect or resume one frozen natural-reference calibration/audit run."""
import argparse
import fcntl
import getpass
from pathlib import Path
import subprocess
from rs_common import PACKAGE,canonical,dump,load,preflight,require


def sbatch_command(root,request,resume=None):
    log=root/'e8_reference_scale_%j.log'
    cmd=['sbatch','--parsable','--job-name=nrps_refscale','--account=nef@a100','--partition=gpu_p5',
        '--qos=qos_gpu_a100-t3','--nodes=1','--ntasks=1','--cpus-per-task=8','--hint=nomultithread',
        '--gres=gpu:1','--constraint=a100','--time=04:00:00','--signal=B:USR1@180',
        '--no-requeue','--propagate=NONE','--chdir='+str(root),'--output='+str(log),'--error='+str(log),
        str(PACKAGE/'batch.sh'),str(PACKAGE),str(root),str(request)]
    if resume:cmd.append(str(resume))
    return cmd,log


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=('calibrate','preflight','status','resume'))
    p.add_argument('output',nargs='?',type=Path)
    p.add_argument('--root',type=Path,default=PACKAGE.parent)
    args=p.parse_args();root=args.root.resolve()
    latest=root/'e8_reference_scale_latest.json';history=root/'e8_reference_scale_submissions'
    require(root.is_dir(),'Project root does not exist')
    submissions=lambda:sorted([load(p) for p in history.glob('*.json')],key=lambda s:int(s['job_id']))
    if args.action=='status':
        require(latest.exists(),'No reference-scale job has been submitted')
        info=load(latest)
        if args.output:
            matched=[s for s in submissions() if Path(s['output'])==args.output.resolve()]
            require(matched,'Unknown reference-scale output');info=matched[-1]
        subprocess.run(['sacct','-j',info['job_id'],'--format=JobID,JobName%20,State,ExitCode,Elapsed'],check=True)
        out=Path(info['output']);print('Output:',out,flush=True)
        if (out/'REFERENCE_SCALE_COMPLETE').exists():
            print((out/'summary.json').read_text(),flush=True)
            print('Inspection:',out/'reference_scale_inspection.zip',flush=True)
        elif (out/'fatal_error.json').exists():print((out/'fatal_error.json').read_text(),flush=True)
        elif (out/'pause.json').exists():print((out/'pause.json').read_text(),flush=True)
        elif Path(info['log']).exists():subprocess.run(['tail','-n','20',info['log']],check=True)
        return
    if args.action=='preflight':
        require(args.output is None,'Preflight takes no output path')
        _,_,split,_,_=preflight(root)
        print('Natural assemblies by role:',split['role_assembly_counts'],flush=True)
        print('Natural connected groups by role:',split['role_component_counts'],flush=True)
        for message in split['warnings']:print('Reference coverage:',message,flush=True)
        return
    with (root/'e8_reference_scale_submission.lock').open('a') as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        previous=None;resume=None;history_rows=submissions()
        if args.action=='resume':
            require(args.output is not None,'Provide the paused/failed output path')
            resume=args.output.resolve()
            require(resume.parent==root and resume.name.startswith('e8_reference_scale_') and
                    not (resume/'REFERENCE_SCALE_COMPLETE').exists(),'Invalid/completed resume output')
            matched=[s for s in history_rows if Path(s['output'])==resume]
            require(matched,'Unknown resume output');previous=matched[-1]
        else:require(args.output is None,'The job ID assigns the new output')
        _,_,split,_,request=preflight(root);intent=canonical(request)
        if previous:require(previous['intent']==intent,'Resume protocol or inputs changed')
        live=subprocess.run(['squeue','-h','-u',getpass.getuser(),'-o','%i'],capture_output=True,text=True,check=True)
        active=set(live.stdout.split())
        for s in history_rows:
            require(s['job_id'] not in active,'A reference-scale job is already pending/running')
        require(resume is not None or not history_rows,'Reference scale already submitted; use status or resume')
        requests=root/'e8_reference_scale_requests';requests.mkdir(exist_ok=True)
        request_path=requests/(intent+'.json')
        if request_path.exists():require(load(request_path)==request,'Stored request changed')
        else:dump(request_path,request)
        print('This run dedicates former natural internal-test components to calibration and audit.',flush=True)
        print('Assemblies:',split['role_assembly_counts'],'| independent-by-recorded-links groups:',split['role_component_counts'],flush=True)
        print('No model updates or activity-classifier fits.',flush=True)
        cmd,log=sbatch_command(root,request_path,resume)
        result=subprocess.run(cmd,capture_output=True,text=True,check=True)
        if result.stderr.strip():print(result.stderr.strip(),flush=True)
        job=result.stdout.strip().split(';')[0]
        require(job.isdigit(),'Unexpected sbatch response; inspect squeue before retrying')
        out=resume or root/('e8_reference_scale_'+job)
        info=dict(job_id=job,output=str(out),intent=intent,request=str(request_path),
            log=str(log).replace('%j',job),resumed=bool(resume))
        history.mkdir(exist_ok=True);dump(history/(job+'.json'),info);dump(latest,info)
        print('Submitted one-A100 reference-scale inference:',job,flush=True)
        print('Output:',out,flush=True);print('Status: bash',PACKAGE/'status.sh',flush=True)


if __name__=='__main__':main()
