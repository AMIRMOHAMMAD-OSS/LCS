#!/usr/bin/env bash
set -eo pipefail
NRPS_SCALE_PACKAGE="${1:?package}"
NRPS_SCALE_ROOT="${2:?root}"
NRPS_SCALE_REQUEST="${3:?request}"
cd "$NRPS_SCALE_ROOT"
module purge
module load arch/a100
module load pytorch-gpu/py3/2.8.0
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
export TMPDIR="$NRPS_SCALE_ROOT/e8_reference_scale_tmp_${SLURM_JOB_ID}"
export SQLITE_TMPDIR="$TMPDIR"
mkdir -p "$TMPDIR"
NRPS_SCALE_PY=$(python3 -B -c 'import sys; print(sys.base_prefix + "/bin/python3")')
"$NRPS_SCALE_PY" -B "$NRPS_SCALE_PACKAGE/verify.py"
"$NRPS_SCALE_PY" -B "$NRPS_SCALE_PACKAGE/selftest.py"
"$NRPS_SCALE_PY" -B "$NRPS_SCALE_PACKAGE/selftest_cohorts.py"
"$NRPS_SCALE_PY" -B "$NRPS_SCALE_PACKAGE/selftest_scoring.py"
NRPS_SCALE_OUT="$NRPS_SCALE_ROOT/e8_reference_scale_${SLURM_JOB_ID}"
NRPS_SCALE_FLAGS=()
if [ -n "${4:-}" ]; then
    NRPS_SCALE_OUT="$4"
    NRPS_SCALE_FLAGS=(--resume)
fi
exec "$NRPS_SCALE_PY" -u -B "$NRPS_SCALE_PACKAGE/run_scale.py" \
    --root "$NRPS_SCALE_ROOT" --out "$NRPS_SCALE_OUT" --request "$NRPS_SCALE_REQUEST" "${NRPS_SCALE_FLAGS[@]}"
