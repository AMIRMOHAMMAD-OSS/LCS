#!/usr/bin/env python3
"""CPU numerical integration test: real structure, synthetic frozen vectors/model.

No trained checkpoint or production ESM-C vectors are loaded. This validates the
streaming scoring path against independent one-query original-map inference.
"""
import argparse
from collections import defaultdict
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys
from types import SimpleNamespace


def main():
    package = Path(__file__).resolve().parent
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base',type=Path,default=package.parent/'NeurALPS_Assembly_v1_20261002')
    p.add_argument('--database',type=Path,default=package.parent/'e0_training_prep_461027/training_data.sqlite3')
    args = p.parse_args()
    import numpy as np
    import torch
    from score_native import _clean_record, _score_one
    sys.path.insert(0,str(args.base/'src'))
    from assembly_model import AssemblyEncoder,Config,collate_records,MASKED
    from masking_contract import masking_closure
    spec=importlib.util.spec_from_file_location('nrps_original_ssl_scoring_selftest',args.base/'run_ssl.py')
    ssl=importlib.util.module_from_spec(spec);spec.loader.exec_module(ssl)
    db=sqlite3.connect(args.database.resolve().as_uri()+'?mode=ro',uri=True)
    candidates=[]
    for aid,payload in db.execute("SELECT assembly_id,payload FROM assemblies WHERE dataset='bode1'"):
        r=json.loads(payload)
        if any(o['kind']==2 for o in r['route']):candidates.append(r)
    assert candidates,'Need a BODE1 structural example with a protein break'
    record=min(candidates,key=lambda r:(len(r['route']),r['assembly_id']))
    record=_clean_record(record['assembly_id'],record)
    parents={h:db.execute('SELECT sequence FROM proteins WHERE hash=?',(h,)).fetchone()[0]
             for h in set(record['parent_sequence_hashes'].values())}
    db.close()
    def vector(key):
        seed=int.from_bytes(hashlib.sha256(('synthetic/'+key).encode()).digest()[:8],'little')
        return np.random.default_rng(seed).standard_normal(1152).astype(np.float32)
    vectors={s['sequence_hash']:vector(s['sequence_hash']) for s in record['model_slots'] if s['state']=='OBSERVED'}
    means={s['group']:.1*vector('mean/'+s['group']) for s in record['model_slots'] if s['state']=='OBSERVED'}
    store=SimpleNamespace(vector=lambda key:vectors[key].copy(),parent=lambda key:parents[key])
    runtime=SimpleNamespace(store=store,targets=SimpleNamespace(mean=lambda s:means[s['group']]),
                            closure=masking_closure,ssl=ssl,device='cpu')
    torch.set_num_threads(2);torch.manual_seed(20261006)
    model=AssemblyEncoder(Config()).eval();model.requires_grad_(False)
    # The stock initialization has a zero global-output path. Activate it for
    # this synthetic numerical test so accidental removal of context is tested.
    with torch.no_grad():
        for block in model.global_blocks:
            block.write.out_proj.weight.normal_(0,.01)
            block.h_ff[3].weight.normal_(0,.01)
    names={int(v):k for k,v in json.loads((args.base/'domain_vocabulary.json').read_text())['vocab'].items()}
    actual=_score_one(record,runtime,model,collate_records,names,{'signal':None})
    assert actual is not None
    slots=defaultdict(list)
    for s in record['model_slots']:slots[s['object_index']].append(s)
    max_score,max_raw,max_error=0.,0.,0.
    scored=0
    for j,obj in enumerate(record['route']):
        ss=sorted(slots[j],key=lambda s:s['slot'])
        row=actual[j]
        assert row['object_index']==j and len(ss)==(2 if obj['kind']==2 else 1)
        if any(s['state']!='OBSERVED' for s in ss):
            assert row['status']=='MISSING_SEQUENCE_FEATURE';continue
        closure=masking_closure(record,[(j,s['slot']) for s in ss],store.parent,'independent_sequence')
        hidden=set(map(tuple,closure['hidden']))
        seen=set();independent=0
        for k in range(len(record['route'])):
            if k==j or abs(k-j)>24:continue
            hs={s['sequence_hash'] for s in slots[k] if s['state']=='OBSERVED' and (k,s['slot']) not in hidden}
            if hs-seen:independent+=1;seen.update(hs)
        assert row['remaining_distinct_context_objects']==independent
        assert sorted(map(tuple,row['hidden_slots']))==sorted(hidden)
        if independent<2:
            assert row['status']=='INSUFFICIENT_VISIBLE_CONTEXT';continue
        assert row['status']=='SCORED'
        batch=collate_records([record],store.vector)
        for index,role in hidden:
            batch['state'][0,index,role]=MASKED;batch['x'][0,index,role]=float('nan')
        roles=[s['slot'] for s in ss]
        with torch.no_grad():
            prediction=model.predict_masked(batch)
            keys=torch.tensor(np.stack([store.vector(s['sequence_hash']) for s in ss]))[None]
            mu=torch.tensor(np.stack([runtime.targets.mean(s) for s in ss]))[None]
            # Exact dimensions used by the original map routine, with the true
            # synthetic target as candidate zero and no alternate candidates.
            mixed,raw=ssl.slot_loss(prediction[0,j,roles][None],keys,mu)
            expected=float((1-mixed.mean(-1))[0]);raw_error=float(raw[0].mean())
            max_score=max(max_score,abs(row['native_score']-expected))
            max_raw=max(max_raw,abs(row['native_raw_cosine_loss']-raw_error))
            max_error=max(max_error,abs(row['reconstruction_error']-float(mixed[0].mean())))
        scored+=1
    assert max(max_score,max_raw,max_error)<=2e-6,(max_score,max_raw,max_error)
    assert _score_one(record,runtime,model,collate_records,names,{'signal':15}) is None
    # An unavailable side must make the physical break unscored; it may not
    # silently downgrade to a one-sided query on a different scale.
    missing=copy.deepcopy(record)
    target=next(s for s in missing['model_slots'] if missing['route'][s['object_index']]['kind']==2)
    target['state']='MISSING'
    unavailable=_score_one(missing,runtime,model,collate_records,names,{'signal':None})
    assert unavailable[target['object_index']]['status']=='MISSING_SEQUENCE_FEATURE'
    assert unavailable[target['object_index']]['mode']=='joint_terminal_recovery'
    print(json.dumps(dict(status='SCORING_SYNTHETIC_CPU_PASS',assembly_id=record['assembly_id'],
        physical_objects=len(actual),scored_objects=scored,joint_breaks=sum(o['kind']==2 for o in record['route']),
        max_score_difference=max_score,max_raw_difference=max_raw,max_error_difference=max_error,
        stopped_query_returned_none=True,missing_break_side_not_scored=True,
        trained_checkpoint_used=False,production_esmc_vectors_used=False,torch=torch.__version__),sort_keys=True))


if __name__=='__main__':main()
