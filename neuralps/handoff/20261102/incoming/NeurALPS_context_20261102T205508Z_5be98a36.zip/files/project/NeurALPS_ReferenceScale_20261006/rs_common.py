"""Pinned, read-only source validation and immutable reference-scale request."""
import hashlib
import importlib
import json
from pathlib import Path
import sys

PACKAGE = Path(__file__).resolve().parent
VERSION = 'nrps_reference_scale_20261006_v1'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(8<<20),b''):
            h.update(block)
    return h.hexdigest()


def canonical(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.tmp')
    tmp.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')
    tmp.replace(path)


def verify_tree(path, expected=None):
    path=Path(path).resolve()
    if expected:
        require(sha(path/'SHA256SUMS')==expected,'Dependency manifest changed: '+path.name)
    seen=set()
    for line in (path/'SHA256SUMS').read_text().splitlines():
        value,name=line.split('  ',1);p=(path/name).resolve()
        require(path in p.parents and name not in seen,'Invalid package checksum entry')
        seen.add(name)
        require(p.is_file() and sha(p)==value,'Package changed: '+str(p))
    return sha(path/'SHA256SUMS')


def attach(root):
    dependencies=load(PACKAGE/'DEPENDENCIES.json')
    for name,expected in dependencies.items():
        verify_tree(root/name,expected)
    ensemble=root/'NeurALPS_Ensemble_20261004'
    sys.path.insert(0,str(ensemble))
    common=importlib.import_module('common')
    require(Path(common.__file__).resolve().parent==ensemble,'Wrong common module was imported')
    return common


def preflight(root):
    from cohorts import prepare_cohorts
    root=Path(root).resolve();package_sha=verify_tree(PACKAGE)
    common=attach(root)
    ctx=common.project(root,root/'e1_ssl_continue30_v1_530757')
    protocol=load(PACKAGE/'PROTOCOL.json')
    require(ctx['source_provenance']['best_checkpoint_sha256']==protocol['checkpoint_sha256'] and
            ctx['ssl_summary']['selected_step']==26000,'Expected the fixed observed SSL26 checkpoint')
    records,split,overlap=prepare_cohorts(ctx['prep']/'training_data.sqlite3')
    require(split['usable_two_way_split'],'Connected natural groups did not yield a usable two-way split; do not silently relax grouping')
    request=dict(version=VERSION,root=str(root),package_sha256=package_sha,
        protocol_sha256=sha(PACKAGE/'PROTOCOL.json'),model_inputs=ctx['identities'],
        split_manifest_sha256=canonical(split),overlap_report_sha256=canonical(overlap),
        records_sha256=canonical(records),checkpoint_sha256=protocol['checkpoint_sha256'],selected_step=26000,
        internal_test_role_change=protocol['new_internal_test_role'])
    print(json.dumps(dict(stage='REFERENCE_SCALE_PREFLIGHT_OK',selected_step=26000,
        inference_assemblies=len(records),internal_test_role_change=request['internal_test_role_change']),allow_nan=False),flush=True)
    return ctx,records,split,overlap,request
