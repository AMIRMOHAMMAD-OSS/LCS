#!/usr/bin/env python3
import ast
from pathlib import Path
import subprocess
from rs_common import PACKAGE,verify_tree

if __name__=='__main__':
    digest=verify_tree(PACKAGE)
    for line in (PACKAGE/'SHA256SUMS').read_text().splitlines():
        _,name=line.split('  ',1);p=PACKAGE/name
        if p.suffix=='.py':ast.parse(p.read_text(),filename=name)
        if p.suffix=='.sh':subprocess.run(['bash','-n',str(p)],check=True)
    print('REFERENCE_SCALE_BUNDLE_OK',digest)
