"""Synthetic checks for empirical reference scaling; no model/assay data needed."""
import copy
import json
import math
from pathlib import Path
import random
import unittest

import scale


ROOT = Path(__file__).resolve().parent


def protocol(**overrides):
    p = json.loads((ROOT / 'PROTOCOL.json').read_text())
    # Small synthetic fixtures exercise the same rule, not production support.
    p.update(minimum_reference_components=4,
             very_low_minimum_components=8,
             minimum_audit_components_for_rate_assessment=4)
    p.update(overrides)
    return p


def row(aid, score=0.0, index=0, length=7, types=(1,), **overrides):
    result = dict(assembly_id=aid, object_index=index, status='SCORED',
                  native_score=score, kind=0, domain_types=list(types),
                  mode='object_recovery', hidden_fraction=0.1,
                  slots=[{'slot': 0, 'length_bin': length}],
                  native_hashes=['feature-' + aid + '-' + str(index)],
                  parent_hashes=['parent-' + aid])
    result.update(overrides)
    return result


def metadata(rows, role='calibration', component_overrides=None):
    component_overrides = component_overrides or {}
    return {r['assembly_id']: dict(role=role, dataset='natural',
            component_id=component_overrides.get(r['assembly_id'], r['assembly_id']))
            for r in rows}


def selected(r):
    """Exclude pass-through input fields; compare only scale-generated values."""
    names = ('natural_percentile_0_to_100', 'lower_tail_rank',
             'reference_components', 'reference_candidate_objects',
             'reference_level', 'reference_key', 'tail_resolution',
             'reference_feature_overlap_components',
             'reference_parent_overlap_components', 'warning', 'scale_status')
    return {k: r[k] for k in names}


class ReferenceScaleTests(unittest.TestCase):
    def setUp(self):
        self.p = protocol()
        self.rows = [row('cal-' + str(i), s)
                     for i, s in enumerate((-0.6, -0.2, -0.2, 0.7))]
        self.meta = metadata(self.rows)
        self.ref = scale.build_reference(self.rows, self.meta, self.p)

    def test_ties_have_midrank_display_and_conservative_tail_rank(self):
        got = scale.apply_one(row('query', -0.2), self.ref, self.p)
        self.assertEqual(got['natural_percentile_0_to_100'], 50.0)
        self.assertEqual(got['lower_tail_rank'], 4 / 5)
        self.assertEqual(got['reference_components'], 4)
        self.assertEqual(got['tail_resolution'], 1 / 5)
        # Equal calibration scores count in the conservative lower tail.
        lower = scale.apply_one(row('query', -0.200001), self.ref, self.p)
        self.assertEqual(lower['lower_tail_rank'], 2 / 5)

    def test_zero_display_is_not_zero_tail_probability(self):
        low = scale.apply_one(row('query', -0.9), self.ref, self.p)
        high = scale.apply_one(row('query', 0.9), self.ref, self.p)
        self.assertEqual(low['natural_percentile_0_to_100'], 0.0)
        self.assertEqual(low['lower_tail_rank'], 1 / 5)
        self.assertGreater(low['lower_tail_rank'], 0)
        self.assertEqual(high['natural_percentile_0_to_100'], 100.0)
        self.assertEqual(high['lower_tail_rank'], 1.0)

    def test_rare_group_refuses_scale_and_cross_type_fallback(self):
        p = protocol(minimum_reference_components=5)
        ref = scale.build_reference(self.rows, self.meta, p)
        rare = scale.apply_one(row('query', 0), ref, p)
        self.assertEqual(rare['scale_status'], 'INSUFFICIENT_REFERENCE')
        self.assertEqual(rare['reference_components'], 4)
        self.assertIsNone(rare['natural_percentile_0_to_100'])
        self.assertIsNone(rare['lower_tail_rank'])
        self.assertIsNone(rare['warning'])
        other_type = scale.apply_one(row('query', 0, types=(2,)), self.ref, self.p)
        self.assertEqual(other_type['scale_status'], 'INSUFFICIENT_REFERENCE')
        self.assertEqual(other_type['reference_components'], 0)

    def test_length_fallback_is_explicit(self):
        rows = [row('cal-' + str(i), s, length=7 if i < 2 else 8)
                for i, s in enumerate((-0.6, -0.2, 0.2, 0.7))]
        ref = scale.build_reference(rows, metadata(rows), self.p)
        got = scale.apply_one(row('query', 0, length=7), ref, self.p)
        self.assertEqual(got['scale_status'], 'SCALED_LENGTH_UNMATCHED')
        self.assertEqual(got['reference_level'], 'type_mask')
        self.assertEqual(got['reference_components'], 4)
        self.assertEqual(got['reference_candidate_objects'], 4)
        exact = scale.apply_one(row('query', 0), self.ref, self.p)
        self.assertEqual(exact['scale_status'], 'SCALED')
        self.assertEqual(exact['reference_level'], 'type_mask_length')

    def test_mask_and_query_kind_are_not_silently_pooled(self):
        variants = [dict(hidden_fraction=0.3), dict(hidden_fraction=0.6),
                    dict(kind=1, domain_types=[1, 2]),
                    dict(kind=2, domain_types=[1, 2], mode='joint_terminal_recovery',
                         slots=[{'slot': 1, 'length_bin': 7},
                                {'slot': 2, 'length_bin': 7}])]
        for change in variants:
            with self.subTest(change=change):
                got = scale.apply_one(row('query', 0, **change), self.ref, self.p)
                self.assertEqual(got['scale_status'], 'INSUFFICIENT_REFERENCE')

    def test_invalid_mask_metadata_fails(self):
        for invalid in (float('nan'), float('inf'), -float('inf'),
                        -0.001, 1.001, '0.1', None):
            with self.subTest(hidden_fraction=invalid):
                r = row('bad-mask', hidden_fraction=invalid)
                with self.assertRaises(ValueError):
                    scale.apply_one(r, self.ref, self.p)
                with self.assertRaises(ValueError):
                    scale.build_reference([r], metadata([r]), self.p)

    def test_invalid_domain_type_shape_or_kind_fails(self):
        variants = [dict(kind='domain'), dict(kind=-1), dict(kind=3),
                    dict(kind=0, domain_types=[]), dict(kind=0, domain_types=[1, 2]),
                    dict(kind=1, domain_types=[1]), dict(kind=2, domain_types=[1]),
                    dict(kind=2, domain_types=[1, 2, 3])]
        for change in variants:
            with self.subTest(change=change):
                r = row('bad-stratum', **change)
                with self.assertRaises(ValueError):
                    scale.apply_one(r, self.ref, self.p)
                with self.assertRaises(ValueError):
                    scale.build_reference([r], metadata([r]), self.p)

    def test_one_representative_per_component_in_each_group(self):
        extra = [row('cal-extra', 0.99, index=i) for i in range(20)]
        rows = self.rows + extra
        meta = metadata(rows, component_overrides={'cal-extra': 'cal-0'})
        ref = scale.build_reference(rows, meta, self.p)
        for group, data in ref['groups'].items():
            self.assertEqual(data['n'], 4)
            self.assertEqual(data['candidate_objects'], 24)
            self.assertEqual(len({r['component_id'] for r in data['representatives']}), 4)
            candidates = [r for r in rows if meta[r['assembly_id']]['component_id'] == 'cal-0']
            expected = min(candidates, key=lambda r: scale.digest(
                self.p['seed'], 'reference_representative', 'cal-0', group, scale.query_id(r)))
            actual = next(r for r in data['representatives'] if r['component_id'] == 'cal-0')
            self.assertEqual(actual['query_id'], scale.query_id(expected))

    def test_audit_rows_never_fit_reference(self):
        audit = [row('audit-0', -0.99), row('audit-1', 0.99)]
        meta = {**self.meta, **metadata(audit, role='audit')}
        ref = scale.build_reference(self.rows + audit, meta, self.p)
        self.assertEqual(ref, self.ref)
        audit[0]['native_score'], audit[1]['native_score'] = 0.88, -0.88
        self.assertEqual(scale.build_reference(self.rows + audit, meta, self.p), self.ref)

    def test_permutation_invariance(self):
        rows = self.rows + [row('cal-extra', 0.9, index=i) for i in range(12)]
        meta = metadata(rows, component_overrides={'cal-extra': 'cal-0'})
        expected = scale.canonical(scale.build_reference(rows, meta, self.p))
        rng = random.Random(311)
        for _ in range(10):
            rng.shuffle(rows)
            self.assertEqual(scale.canonical(scale.build_reference(rows, meta, self.p)), expected)

    def test_outcomes_do_not_affect_reference_or_scale(self):
        changed = copy.deepcopy(self.rows)
        changed_meta = copy.deepcopy(self.meta)
        for i, r in enumerate(changed):
            r.update(active=i % 2, label=1, detected=False, phenotype='unused')
            changed_meta[r['assembly_id']].update(active=1 - i % 2, outcome='unused')
        ref = scale.build_reference(changed, changed_meta, self.p)
        self.assertEqual(ref, self.ref)
        q1, q2 = row('query', 0.1, active=0), row('query', 0.1, active=1)
        self.assertEqual(selected(scale.apply_one(q1, ref, self.p)),
                         selected(scale.apply_one(q2, ref, self.p)))

    def test_audit_does_not_treat_many_objects_as_independent(self):
        audit = [row('audit-' + str(j), -0.9, index=i)
                 for j in range(3) for i in range(30)]
        meta = metadata(audit, role='audit')
        scaled = [scale.apply_one(r, self.ref, self.p) for r in audit]
        p = protocol(low_tail_threshold=0.25)
        got = scale.audit_scale(scaled, meta, p)
        self.assertEqual(got['object_coverage']['SCALED'], 90)
        self.assertEqual(len(got['groups']), 1)
        group = got['groups'][0]
        self.assertEqual(group['audit_components'], 3)
        self.assertEqual(group['low_tail_warnings'], 3)
        self.assertEqual(group['rate_assessment'], 'TOO_FEW_AUDIT_COMPONENTS')
        self.assertEqual(len(group['representative_query_ids']), 3)
        self.assertFalse(got['formal_conformal_validity_claim'])
        self.assertFalse(got['multiple_testing_adjusted'])
        shuffled = list(reversed(scaled))
        self.assertEqual(scale.canonical(scale.audit_scale(shuffled, meta, p)), scale.canonical(got))

    def test_nonfinite_and_out_of_range_scored_values_fail(self):
        for invalid in (float('nan'), float('inf'), -float('inf'), 1.01, -1.01):
            with self.subTest(score=invalid):
                r = row('bad', invalid)
                with self.assertRaises(ValueError):
                    scale.apply_one(r, self.ref, self.p)
                with self.assertRaises(ValueError):
                    scale.build_reference([r], metadata([r]), self.p)

    def test_unscored_remains_unscored(self):
        got = scale.apply_one(row('query', None, status='NO_REMAINING_CONTEXT'), self.ref, self.p)
        self.assertEqual(got['scale_status'], 'UNSCORED')
        self.assertIsNone(got['natural_percentile_0_to_100'])
        self.assertIsNone(got['lower_tail_rank'])
        self.assertIsNone(got['warning'])

    def test_duplicate_physical_query_fails(self):
        with self.assertRaises(ValueError):
            scale.build_reference(self.rows + [copy.deepcopy(self.rows[0])], self.meta, self.p)

    def test_overlap_counts_components_and_is_exposed(self):
        q = row('query', 0.0, native_hashes=['feature-cal-0-0', 'feature-cal-2-0'],
                parent_hashes=['parent-cal-0', 'parent-cal-1'])
        got = scale.apply_one(q, self.ref, self.p)
        self.assertEqual(got['reference_feature_overlap_components'], 2)
        self.assertEqual(got['reference_parent_overlap_components'], 2)

    def test_low_and_very_low_warnings_require_declared_support(self):
        p = protocol(low_tail_threshold=0.21, very_low_tail_threshold=0.21)
        ref = scale.build_reference(self.rows, self.meta, p)
        got = scale.apply_one(row('query', -0.9), ref, p)
        self.assertEqual(got['warning'], 'LOW_NATURAL_SUPPORT')
        p['very_low_minimum_components'] = 4
        ref = scale.build_reference(self.rows, self.meta, p)
        got = scale.apply_one(row('query', -0.9), ref, p)
        self.assertEqual(got['warning'], 'VERY_LOW_NATURAL_SUPPORT')

    def test_assembly_summary_makes_no_activity_or_alarm_claim(self):
        rows = [scale.apply_one(row('query', s, index=i), self.ref, self.p)
                for i, s in enumerate((-0.9, 0.0, 0.9))]
        got = scale.assembly_summaries(rows, metadata(rows, role='application'))
        self.assertEqual(len(got), 1)
        self.assertEqual(got[0]['scaled_objects'], 3)
        self.assertIsNone(got[0]['whole_assembly_activity_prediction'])
        self.assertFalse(got[0]['whole_assembly_alarm_calibrated'])

    def test_wilson_basic_limits(self):
        self.assertEqual(scale.wilson(0, 0), [None, None])
        lo, hi = scale.wilson(0, 100)
        self.assertLessEqual(lo, 1e-15)
        self.assertGreater(hi, 0)
        self.assertLess(hi, 0.05)
        lo, hi = scale.wilson(100, 100)
        self.assertGreater(lo, 0.95)
        self.assertTrue(math.isclose(hi, 1.0))


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ReferenceScaleTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        raise SystemExit(1)
    print(json.dumps({'stage': 'REFERENCE_SCALE_SELFTEST_OK', 'tests': result.testsRun}))
