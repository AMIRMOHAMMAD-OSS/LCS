#!/usr/bin/env python3
"""Freeze reference groups, score once, construct empirical scale, audit, apply."""
import argparse
from collections import Counter
import csv
import fcntl
import gzip
import json
import os
from pathlib import Path
import signal
import time
import traceback
import zipfile
from rs_common import PACKAGE,VERSION,canonical,dump,load,preflight,require,sha


def csv_table(path,rows):
    if not rows:
        return
    fields=list(rows[0])
    with Path(path).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for row in rows:
            w.writerow({k:json.dumps(v,sort_keys=True) if isinstance(v,(dict,list)) else v for k,v in row.items()})


def inspection(out):
    members=[p for p in sorted(out.rglob('*')) if p.is_file() and p.suffix in ('.json','.csv','.gz') and 'attempt_history' not in p.parts]
    dump(out/'artifact_manifest.json',{str(p.relative_to(out)):sha(p) for p in members if p.name!='artifact_manifest.json'})
    members=[p for p in sorted(out.rglob('*')) if p.is_file() and p.suffix in ('.json','.csv','.gz') and 'attempt_history' not in p.parts]
    tmp=out/'reference_scale_inspection.zip.tmp'
    with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in members:
            z.write(p,p.relative_to(out))
    tmp.replace(out/'reference_scale_inspection.zip')


def parity(rows):
    with gzip.open(PACKAGE/'expected_bode_scores.json.gz','rt') as f:
        expected=json.load(f)
    got={(r['assembly_id'],r['object_index']):r for r in rows if r['dataset'] in ('bode1','bode2')}
    require(len(got)==len(expected)==14002,'BODE score parity coverage changed')
    worst=0.;scored=0
    for old in expected:
        new=got[old['assembly_id'],old['object_index']]
        for field in ('kind','mode','status','native_hashes'):
            require(old[field]==new[field],'Reconstructed BODE map metadata differs: '+field)
        if old['status']=='SCORED':
            require(sorted(old['hidden_slots'])==sorted(new['hidden_slots']),'BODE masking closure differs')
            delta=abs(old['native_score']-new['native_score']);worst=max(worst,delta);scored+=1
            require(delta<=2e-5,'BODE raw score parity failed; no scale should be used')
    return dict(status='PASS',objects=len(got),scored=scored,maximum_absolute_difference=worst,absolute_tolerance=2e-5)


def main(args):
    ctx,records,split,overlap,request=preflight(args.root)
    require(load(args.request)==request,'Submitted reference-scale request changed')
    root=args.root.resolve();out=args.out.resolve()
    require(out.parent==root and out.name.startswith('e8_reference_scale_'),'Invalid output path')
    require(not (out/'REFERENCE_SCALE_COMPLETE').exists(),'Reference-scale run already complete')
    require(not out.exists() or args.resume,'Use a new output or explicit resume')
    out.mkdir(exist_ok=True)
    lock=(out/'.lock').open('a');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    args.owns_output=True
    for name in ('pause.json','fatal_error.json'):
        if (out/name).exists():
            history=out/'attempt_history';history.mkdir(exist_ok=True)
            (out/name).rename(history/(str(time.time_ns())+'_'+name))
    stopping={'signal':None}
    def stop(signum,frame):stopping['signal']=signum
    signal.signal(signal.SIGUSR1,stop);signal.signal(signal.SIGTERM,stop)
    import torch
    require(torch.__version__.split('+')[0]=='2.8.0' and torch.cuda.is_available() and torch.cuda.device_count()==1,
            'Use the existing pinned PyTorch2.8.0 one-GPU allocation')
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.use_deterministic_algorithms(True)
    runtime=dict(torch=torch.__version__,cuda=torch.version.cuda,device=torch.cuda.get_device_name(0),
        precision='fp32',tf32=False,deterministic_algorithms=True,threads=8)
    identity=dict(request=request,runtime=runtime)
    protocol=load(PACKAGE/'PROTOCOL.json')
    for name,value in [('identity.json',identity),('split_manifest.json',split),('overlap_audit.json',overlap),('protocol.json',protocol)]:
        if (out/name).exists():require(load(out/name)==value,'Resume identity changed: '+name)
        else:dump(out/name,value)
    # The split and reference recipe are sealed BEFORE model inference.
    dump(out/'pre_inference_seal.json',dict(split_sha256=sha(out/'split_manifest.json'),
        protocol_sha256=sha(out/'protocol.json'),identity_sha256=sha(out/'identity.json')))
    from score_native import score_records
    started=time.monotonic()
    report=score_records(ctx,records,out/'native_scores',identity,stopping)
    if report is None:
        dump(out/'pause.json',dict(status='PAUSED',stage='frozen_inference',resume=str(out)))
        inspection(out);return 75
    rows=[]
    for shard in report['shards']:
        p=out/'native_scores'/shard['path']
        require(sha(p)==shard['sha256'],'Score shard changed')
        with gzip.open(p,'rt') as f:rows.extend(json.loads(line) for line in f if line.strip())
    dump(out/'bode_raw_score_parity.json',parity(rows))
    from scale import build_reference,apply_one,audit_scale,assembly_summaries
    metadata=split['metadata']
    reference=build_reference(rows,metadata,protocol)
    dump(out/'reference.json',reference)
    csv_table(out/'reference_group_support.csv',[dict(reference_key=k,components=v['n'],
        candidate_objects=v['candidate_objects'],enough_reference=v['n']>=protocol['minimum_reference_components'])
        for k,v in sorted(reference['groups'].items())])
    dump(out/'reference_seal.json',dict(reference_sha256=sha(out/'reference.json'),
        calibration_components_only=True,bode_activity_outcomes_used=False,audit_scores_used_to_fit_reference=False))
    scaled=[apply_one(r,reference,protocol) for r in rows if metadata[r['assembly_id']]['role']!='calibration']
    audit=audit_scale(scaled,metadata,protocol);dump(out/'natural_scale_audit.json',audit)
    audit_groups={g['reference_key']:g for g in audit['groups']}
    for row in scaled:
        group=audit_groups.get(row['reference_key'],{})
        row.update(reference_audit_status=group.get('rate_assessment','NO_AUDIT_SUPPORT'),
            reference_audit_components=group.get('audit_components',0),
            reference_audit_warning_rate=group.get('warning_rate'),
            engineered_false_alarm_control_validated=False)
    assembly=assembly_summaries(scaled,metadata);csv_table(out/'assembly_summary.csv',assembly)
    with gzip.open(out/'scaled_objects.jsonl.gz','wt') as f:
        for row in scaled:f.write(json.dumps(row,sort_keys=True,allow_nan=False)+'\n')
    fields=('assembly_id','object_index','kind_name','label','native_score','natural_percentile_0_to_100',
        'lower_tail_rank','warning','scale_status','reference_components','reference_level','tail_resolution',
        'reference_feature_overlap_components','reference_parent_overlap_components','hidden_fraction','remaining_distinct_context_objects',
        'reference_audit_status','reference_audit_components','reference_audit_warning_rate')
    coverage={}
    for dataset in ('bode1','bode2'):
        selected=[r for r in scaled if r['dataset']==dataset]
        csv_table(out/(dataset+'_piece_scale.csv'),[{k:r[k] for k in fields} for r in selected])
        coverage[dataset]=dict(Counter(r['scale_status'] for r in selected))
    summary=dict(status='REFERENCE_SCALE_COMPLETE',version=VERSION,selected_step=26000,
        pretrained_weights_changed=False,activity_classifier_fits=0,activity_labels_used_for_scale=False,
        scored_assemblies=len(records),reference_groups=len(reference['groups']),coverage=coverage,
        natural_audit_coverage=audit['object_coverage'],natural_audit_rate_assessments=audit['rate_assessments'],
        former_internal_test_repartitioned=True,scale_kind='empirical_natural_context_reference',
        calibrated_inactivity_probabilities=False,formal_conformal_validity_claim=False,
        domain_fault_localization_validated=False,seconds_this_attempt=time.monotonic()-started)
    dump(out/'summary.json',summary)
    inspection(out);(out/'REFERENCE_SCALE_COMPLETE').write_text(VERSION+'\n')
    print(json.dumps(summary,sort_keys=True),flush=True)
    print('Inspection:',out/'reference_scale_inspection.zip',flush=True)
    return 0


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',required=True,type=Path);p.add_argument('--out',required=True,type=Path)
    p.add_argument('--request',required=True,type=Path);p.add_argument('--resume',action='store_true')
    args=p.parse_args()
    try:code=main(args)
    except Exception:
        if getattr(args,'owns_output',False):dump(args.out/'fatal_error.json',dict(status='FAILED',traceback=traceback.format_exc()))
        raise
    raise SystemExit(code)
