"""Export label-free, single-protein inference routes using frozen E0 windows.

API: export_routes(records, out, domains_by_id, vocab=None) -> summary.
Each record requires input_id, assembly_id, sequence and role (engineered or
native_control). domains_by_id[input_id] is the caller-approved domain list;
each domain requires zero-based half-open start/end and raw profile type.
This module does not call domains, resolve competing HMM hits, embed sequences,
or score activity. It rejects unsafe records instead of inventing model types.
The legacy window policy is "physical_end_extradomain_tail64_v1". Inputs here
are one actual full physical protein each: no inferred protein breaks or B/J
module annotations are created.
"""
from __future__ import annotations

import csv
import gzip
import hashlib
import importlib.util
import io
import json
from collections import Counter
from pathlib import Path

AA = frozenset("ACDEFGHIKLMNPQRSTVWY")
WINDOW_POLICY = "physical_end_extradomain_tail64_v1"
FILES = ("routes.jsonl.gz", "slot_provenance.tsv.gz", "parents.fasta.gz",
         "unique_sequences.fasta.gz", "sequence_inventory.tsv.gz",
         "holds.jsonl.gz", "summary.json")
SLOT_FIELDS = ("assembly_id", "object_index", "slot", "kind", "state",
               "sequence_hash", "length", "protein_uid", "parent_sequence_hash",
               "start", "end", "group")


def _sha(value):
    return hashlib.sha256(value.encode("ascii")).hexdigest()


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _rules():
    path = Path(__file__).resolve().parent / "src" / "connection_rules.py"
    spec = importlib.util.spec_from_file_location("tdomain_frozen_connection_rules", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if (module.K_COVALENT, module.BREAK_CAP, module.MIN_OBS) != (20, 64, 3):
        raise ValueError("Frozen window constants differ")
    return module, path


def _vocabulary(vocab):
    path = Path(__file__).resolve().parent / "src" / "domain_vocabulary.json"
    frozen = json.loads(path.read_text())["vocab"] if path.is_file() else None
    chosen = vocab.get("vocab", vocab) if vocab is not None else frozen
    if not isinstance(chosen, dict) or not chosen:
        raise ValueError("A frozen domain vocabulary is required")
    if frozen is not None and chosen != frozen:
        raise ValueError("Supplied vocabulary differs from the frozen vocabulary")
    if any(type(v) is not int or not 0 <= v < 32 for v in chosen.values()):
        raise ValueError("Invalid frozen vocabulary indices")
    if len(set(chosen.values())) != len(chosen):
        raise ValueError("Duplicate frozen vocabulary indices")
    if chosen.get("PCP") != 1 or chosen.get("AMP-binding") != 2:
        raise ValueError("Frozen core domain vocabulary changed")
    return chosen


def _record(record, supplied_domains, vocab, rules):
    aid, iid = record["assembly_id"], record["input_id"]
    sequence = record.get("sequence")
    if not isinstance(sequence, str) or not sequence or not set(sequence) <= AA:
        raise ValueError("EMPTY_OR_NONCANONICAL_PROTEIN")
    if record.get("role") not in {"engineered", "native_control"}:
        raise ValueError("UNSUPPORTED_INPUT_ROLE")
    if record.get("n_chains", 1) != 1:
        raise ValueError("ONLY_SINGLE_PHYSICAL_PROTEINS_SUPPORTED")
    if not supplied_domains:
        raise ValueError("NO_APPROVED_DOMAINS")
    domains, seen = [], set()
    for supplied in supplied_domains:
        start, end, raw = supplied.get("start"), supplied.get("end"), supplied.get("raw")
        if type(start) is not int or type(end) is not int or not 0 <= start < end <= len(sequence):
            raise ValueError("INVALID_DOMAIN_COORDINATES")
        if not isinstance(raw, str):
            raise ValueError("MISSING_RAW_DOMAIN_TYPE")
        canonical = rules.canonical_type(raw)
        if canonical not in vocab or canonical in {"UNKNOWN", "OTHER"}:
            raise ValueError("UNSUPPORTED_OR_UNRESOLVED_DOMAIN_TYPE:" + raw)
        key = (start, end)
        if key in seen:
            raise ValueError("DUPLICATE_OR_CONFLICTING_DOMAIN_INTERVAL")
        seen.add(key)
        evidence = {k: supplied[k] for k in (
            "bitscore", "evalue", "profile", "profile_accession", "profile_sha256",
            "hmm_start", "hmm_end", "hmm_length", "alignment_start", "alignment_end",
            "envelope_start", "envelope_end", "annotation_source") if k in supplied}
        _json(evidence)  # Nonfinite scores are not valid provenance.
        domains.append(dict(start=start, end=end, raw=raw, canonical=canonical, evidence=evidence))
    domains.sort(key=lambda d: (d["start"], d["end"], d["raw"]))
    if not any(d["canonical"] == "PCP" for d in domains):
        raise ValueError("NO_APPROVED_PCP_DOMAIN")
    uid = aid + "|physical_chain=1"
    parent_hash = _sha(sequence)
    route, slots, sequences = [], [], {}

    def add_slot(index, kind, start, end, group):
        seq = sequence[start:end]
        state = "OBSERVED" if (bool(seq) if kind == 0 else len(seq) >= rules.MIN_OBS) else "MISSING"
        digest = _sha(seq) if state == "OBSERVED" else None
        if digest is not None:
            sequences[digest] = seq
        slots.append(dict(object_index=index, slot=0, kind=kind, state=state,
                          sequence_hash=digest, length=len(seq), protein_uid=uid,
                          parent_sequence_hash=parent_hash, start=start, end=end, group=group))
        return digest, state

    for number, d in enumerate(domains):
        dtype = vocab[d["canonical"]]
        domain_uid = uid + "|" + d["canonical"] + "|" + str(d["start"]) + ":" + str(d["end"])
        if number:
            previous = route[-1]
            start, end, window = rules.covalent_window(sequence, previous["end_aa_0based_exclusive"], d["start"])
            if window != sequence[start:end]:
                raise ValueError("FROZEN_WINDOW_SLICE_MISMATCH")
            digest, state = add_slot(len(route), 1, start, end,
                                     "C:" + str(previous["domain_type"]) + ":" + str(dtype))
            route.append(dict(boundary_id=aid + "|boundary=" + str(number), kind=1,
                              domain_type=0, chain=1, left_domain_uid=previous["source_domain_uid"],
                              right_domain_uid=domain_uid, left_protein_uid=uid, right_protein_uid=uid,
                              seq_hash=digest, state0=state, cterm_hash=None, nterm_hash=None,
                              annotation_status="MODULE_PARTITION_NOT_INFERRED"))
        digest, state = add_slot(len(route), 0, d["start"], d["end"], "D:" + str(dtype))
        assert state == "OBSERVED"
        route.append(dict(kind=0, chain=1, domain_type=dtype, raw_domain_type=d["raw"],
                          canonical_domain_type=d["canonical"], seq_hash=digest,
                          cterm_hash=None, nterm_hash=None,
                          occurrence_id=aid + "|domain_occurrence=" + str(number + 1),
                          source_domain_uid=domain_uid, protein_uid=uid,
                          start_aa_0based=d["start"], end_aa_0based_exclusive=d["end"],
                          annotation_evidence=d["evidence"]))
    result = dict(assembly_id=aid, input_id=iid, role=record["role"], dataset="tdomain",
                  split="external_inference", label_status="ASSAY_LABELS_NOT_INCLUDED",
                  n_domains=len(domains), n_chains=1, route=route, model_slots=slots,
                  parent_sequence_hashes={uid: parent_hash}, parent_lengths={uid: len(sequence)},
                  boundary_window_policy=WINDOW_POLICY, break_tail_cap_aa=rules.BREAK_CAP,
                  cohort_policy="caller_approved_annotation_v1",
                  cache_dependency_policy="UNVERIFIED_REQUIRES_FEATURE_PROVENANCE")
    assert len(route) == 2 * len(domains) - 1
    assert all(obj["kind"] == (i % 2) for i, obj in enumerate(route))
    return result, parent_hash, sequences


def _gzip_text(path, text):
    path.write_bytes(gzip.compress(text.encode("utf-8"), compresslevel=6, mtime=0))


def _tsv(fieldnames, rows):
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fieldnames, delimiter="\t", lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return buffer.getvalue()


def export_routes(records, out, domains_by_id, vocab=None):
    """Export approved single-chain records; validation failures go to holds.

    Existing owned output files are never overwritten. Assembly/input IDs must
    be unique. A held record contributes no parent, domain, or window sequence.
    Optional vocab is the frozen name->integer mapping or its {vocab:...} file.
    """
    rules, rules_path = _rules()
    vocabulary = _vocabulary(vocab)
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    if any((out / name).exists() for name in FILES):
        raise FileExistsError("Route export destination already contains owned outputs")
    records = list(records)
    for field in ("input_id", "assembly_id"):
        ids = [r.get(field) for r in records]
        if any(not isinstance(x, str) or not x or any(c in x for c in "\n\r\t") for x in ids):
            raise ValueError("Invalid " + field)
        if len(set(ids)) != len(ids):
            raise ValueError("Duplicate " + field)
    exported, holds, parents, sequences = [], [], {}, {}
    uses = {}
    for record in sorted(records, key=lambda r: r["input_id"]):
        try:
            result, parent_hash, new_sequences = _record(
                record, domains_by_id.get(record["input_id"], []), vocabulary, rules)
        except (ValueError, TypeError) as exc:
            holds.append(dict(input_id=record["input_id"], assembly_id=record["assembly_id"],
                              role=record.get("role"), status="ROUTE_EXPORT_HELD", reason=str(exc)))
            continue
        exported.append(result)
        if parent_hash in parents and parents[parent_hash] != record["sequence"]:
            raise ValueError("Physical parent hash collision")
        parents[parent_hash] = record["sequence"]
        for digest, sequence in new_sequences.items():
            if digest in sequences and sequences[digest] != sequence:
                raise ValueError("Feature sequence hash collision")
            sequences[digest] = sequence
        for slot in result["model_slots"]:
            if slot["state"] == "OBSERVED":
                counts = uses.setdefault(slot["sequence_hash"], Counter())
                counts["domain_uses" if slot["kind"] == 0 else "boundary_uses"] += 1
    _gzip_text(out / "routes.jsonl.gz", "".join(_json(r) + "\n" for r in exported))
    _gzip_text(out / "holds.jsonl.gz", "".join(_json(r) + "\n" for r in holds))
    _gzip_text(out / "slot_provenance.tsv.gz", _tsv(SLOT_FIELDS,
        (dict(assembly_id=r["assembly_id"], **s) for r in exported for s in r["model_slots"])))
    for filename, inventory in (("parents.fasta.gz", parents), ("unique_sequences.fasta.gz", sequences)):
        _gzip_text(out / filename, "".join(">" + h + "\n" + seq + "\n" for h, seq in sorted(inventory.items())))
    _gzip_text(out / "sequence_inventory.tsv.gz", _tsv(
        ("sequence_hash", "length", "domain_uses", "boundary_uses"),
        (dict(sequence_hash=h, length=len(seq), domain_uses=uses[h]["domain_uses"],
              boundary_uses=uses[h]["boundary_uses"]) for h, seq in sorted(sequences.items()))))
    slots = [s for r in exported for s in r["model_slots"]]
    summary = dict(status="LABEL_FREE_ROUTES_EXPORTED", input_records=len(records),
                   exported_records=len(exported), held_records=len(holds),
                   exported_roles=dict(Counter(r["role"] for r in exported)),
                   domains=sum(r["n_domains"] for r in exported),
                   covalent_boundaries=sum(r["n_domains"] - 1 for r in exported), protein_breaks=0,
                   observed_slots=sum(s["state"] == "OBSERVED" for s in slots),
                   missing_slots=sum(s["state"] == "MISSING" for s in slots),
                   unique_parent_sequences=len(parents), unique_feature_sequences=len(sequences),
                   feature_sequences_over_2046=sum(len(seq) > 2046 for seq in sequences.values()),
                   labels_used=False, embeddings_computed=False, model_scores_computed=False,
                   boundary_window_policy=WINDOW_POLICY,
                   connection_rules_sha256=hashlib.sha256(rules_path.read_bytes()).hexdigest(),
                   vocabulary_sha256=hashlib.sha256(_json(vocabulary).encode()).hexdigest())
    summary["files_sha256"] = {name: hashlib.sha256((out / name).read_bytes()).hexdigest()
                               for name in FILES if name != "summary.json"}
    (out / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    return summary


def selftest():
    """Portable fixture tests; requires the bundled rules and frozen vocabulary."""
    import tempfile
    rules, _ = _rules()
    vocab = _vocabulary(None)
    seq = "ACDEFGHIKLMNPQRSTVWY" * 10
    records = [dict(input_id="ok", assembly_id="fixture", sequence=seq, role="engineered"),
               dict(input_id="bad", assembly_id="held", sequence=seq, role="engineered")]
    doms = {"ok": [dict(start=10, end=80, raw="AMP-binding"),
                    dict(start=70, end=100, raw="PP-binding")],
            "bad": [dict(start=10, end=80, raw="Condensation"),
                     dict(start=90, end=120, raw="PCP")]}
    with tempfile.TemporaryDirectory() as temporary:
        report = export_routes(records, temporary, doms)
        assert (report["exported_records"], report["held_records"]) == (1, 1)
        with gzip.open(Path(temporary) / "routes.jsonl.gz", "rt") as stream:
            rec = json.loads(next(stream))
        assert rec["route"][2]["domain_type"] == 1
        slot = rec["model_slots"][1]
        assert (slot["start"], slot["end"]) == (50, 100)  # overlapping domains
        assert slot["sequence_hash"] == _sha(seq[50:100])
        assert slot["group"] == "C:2:1"
        assert "label" not in rec and len(rec["route"]) == 3
        try:
            export_routes(records, temporary, doms)
        except FileExistsError:
            pass
        else:
            raise AssertionError("Existing route output overwritten")
    # Missing tiny physical windows stay explicit; no vector requested.
    tiny, _, sequence_map = _record(dict(input_id="tiny", assembly_id="tiny",
        sequence="AC", role="native_control"), [dict(start=0, end=1, raw="PCP"),
        dict(start=1, end=2, raw="AMP-binding")], vocab, rules)
    assert tiny["model_slots"][1]["state"] == "MISSING"
    assert tiny["model_slots"][1]["sequence_hash"] is None
    assert _sha("AC") not in sequence_map
    print("ROUTE_EXPORT_SELFTEST_OK: overlap, exact hashes, alias, type hold, missing state, no overwrite")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args()
    if not args.selftest:
        parser.error("Use the export_routes API or --selftest")
    selftest()
