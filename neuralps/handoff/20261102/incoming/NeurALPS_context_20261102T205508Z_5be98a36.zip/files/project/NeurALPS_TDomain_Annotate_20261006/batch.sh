#!/usr/bin/env bash
set -euo pipefail
NRPS_TA_PACKAGE="${1:?annotation package directory}"
NRPS_TA_ROOT="${2:?project directory}"
NRPS_TA_DATA="${3:?curated data directory}"
: "${SLURM_JOB_ID:?This script must run in the submitted Slurm job}"
NRPS_TA_CPUS="${SLURM_CPUS_PER_TASK:-4}"
if [[ ! "$SLURM_JOB_ID" =~ ^[0-9]+$ || ! "$NRPS_TA_CPUS" =~ ^[1-9][0-9]*$ ]]; then
    printf '%s\n' 'Invalid Slurm job ID or CPU count.' >&2
    exit 2
fi
NRPS_TA_OUT="$NRPS_TA_ROOT/e9_tdomain_annotation_$SLURM_JOB_ID"
if [[ -e "$NRPS_TA_OUT" || -L "$NRPS_TA_OUT" ]]; then
    printf 'Refusing to overwrite existing annotation output: %s\n' "$NRPS_TA_OUT" >&2
    exit 1
fi
cd -- "$NRPS_TA_ROOT"
module purge
module load hmmer/3.3.2-mpi
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
python3 -B "$NRPS_TA_PACKAGE/verify.py"
command -v hmmscan >/dev/null
command -v hmmpress >/dev/null
exec python3 -u -B "$NRPS_TA_PACKAGE/run_annotation.py" \
    --data-dir "$NRPS_TA_DATA" --out "$NRPS_TA_OUT" --cpus "$NRPS_TA_CPUS"
