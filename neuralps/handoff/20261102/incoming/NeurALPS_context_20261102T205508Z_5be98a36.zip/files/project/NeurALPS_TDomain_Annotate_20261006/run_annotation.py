#!/usr/bin/env python3
"""Pinned, label-free NRPS domain annotation audit; no training or embeddings."""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
import as_refinement as refine
import connection_rules as rules
from route_export import export_routes

PROFILE_SHA = "b9ce6d3a36841e869a5f0ee0730493c2a0e8145d1138d4582a81de4343a487b9"
AA = set("ACDEFGHIKLMNPQRSTVWY")
DOCK = {"NRPS-COM_Nterm", "NRPS-COM_Cterm", "PKS_Docking_Cterm", "PKS_Docking_Nterm"}
CONTEXTS = {"GxpS_minimal_SU2_T3", "GxhS-1", "GxhS-2", "GshS"}
EXPECTED_MODULE_COUNTS = {"GxpS_minimal_SU2_T3": 3, "GxhS-1": 4, "GxhS-2": 4, "GshS": 5}


def sha(value):
    return hashlib.sha256(value.encode("ascii") if isinstance(value, str) else value).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def write_csv(path, rows):
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows({k: json.dumps(v) if isinstance(v, (dict, list)) else v
                         for k, v in r.items()} for r in rows)


def fasta(path):
    result = {}; current = None
    for line in path.read_text().splitlines():
        if line.startswith(">"):
            current = line[1:].strip()
            if current in result:
                raise ValueError("Duplicate FASTA ID: " + current)
            result[current] = ""
        elif line.strip():
            if current is None:
                raise ValueError("FASTA sequence before header")
            result[current] += line.strip()
    return result


def safe_path(root, relative):
    path = (root / relative).resolve()
    if root.resolve() not in path.parents:
        raise ValueError("Path outside data package: " + str(relative))
    return path


def load_data(data):
    """Use only sequence records and input queue, never activity tables."""
    data = data.resolve()
    manifest = data / "SHA256SUMS"
    count = 0
    for line in manifest.read_text().splitlines():
        digest, name = line.split("  ", 1)
        path = safe_path(data, name)
        if sha(path.read_bytes()) != digest:
            raise ValueError("Dataset checksum mismatch: " + name)
        count += 1
    if count != 91:
        raise ValueError(f"Expected the verified 91-file dataset, found {count}")
    queue = json.loads((data / "evaluation/annotation_queue.json").read_text())
    if len(queue) != 84:
        raise ValueError("Expected 84 engineered input jobs")
    records = []; loaded = {}
    for index, job in enumerate(queue, 1):
        relative = job["fasta"]
        if relative not in loaded:
            loaded[relative] = fasta(safe_path(data, relative))
        sequence = loaded[relative][job["fasta_record_id"]]
        if sha(sequence) != job["amino_acid_sha256"] or not sequence or not set(sequence) <= AA:
            raise ValueError("Protein hash/alphabet mismatch: " + job["construct_id"])
        lo, hi = job["exchanged_fragment_interval_0based_half_open"]
        if not (type(lo) is int and type(hi) is int and 0 <= lo < hi <= len(sequence)):
            raise ValueError("Invalid exchanged interval")
        context = job["context"]
        if context not in CONTEXTS:
            raise ValueError("Unknown context: " + context)
        records.append(dict(input_id=f"TD{index:04d}", assembly_id=job["construct_id"],
                            sequence=sequence, role="engineered", context=context,
                            variant_id=job["variant_id"], changed_interval=[lo, hi],
                            sequence_source=relative, amino_acid_sha256=sha(sequence)))
    if Counter(r["context"] for r in records) != {"GxpS_minimal_SU2_T3": 65, "GxhS-1": 5, "GshS": 5, "GxhS-2": 9}:
        raise ValueError("Unexpected engineered context counts")
    # Match whole physical native chains, not SacB/vector templates.
    natives = json.loads((data / "sequence_data/native_NRPS_ORF_candidates.json").read_text())
    main = [r for r in natives if r.get("parent_plasmid", "").lower().startswith("pjw76_")
            and "sacb" not in r.get("parent_plasmid", "").lower()]
    if len(main) != 1:
        raise ValueError("Cannot identify single native minimal GxpS parent; record keys=" +
                         str(list(natives[0]) if natives else []) + "; parent names=" +
                         str([r.get("parent_plasmid") for r in natives]))
    native_sources = [("GxpS_minimal_SU2_T3", main[0])]
    hybrids = json.loads((data / "hybrid_data/native_hybrid_controls.json").read_text())
    if len(hybrids) != 3:
        raise ValueError("Expected three native hybrid controls")
    if any("context" not in r or "amino_acids" not in r for r in hybrids):
        raise ValueError("Native hybrid schema differs: keys=" + str([list(r) for r in hybrids]))
    native_sources.extend((r["context"], r) for r in hybrids)
    for index, (context, record) in enumerate(native_sources, 1):
        seq = record["amino_acids"]
        if not seq or not set(seq) <= AA:
            raise ValueError("Ambiguous native control: " + context)
        digest = record.get("amino_acid_sha256")
        if digest and digest != sha(seq):
            raise ValueError("Native control hash mismatch")
        records.append(dict(input_id=f"WT{index:04d}", assembly_id="native|context=" + context,
                            sequence=seq, role="native_control", context=context,
                            amino_acid_sha256=sha(seq)))
    if {r["context"] for r in records if r["role"] == "native_control"} != CONTEXTS:
        raise ValueError("Incomplete native context coverage")
    if len({r["assembly_id"] for r in records}) != len(records):
        raise ValueError("Duplicate input identities")
    return records, dict(dataset_files_verified=count, engineered_constructs=84, native_controls=4,
                         dataset_manifest_sha256=sha(manifest.read_bytes()),
                         annotation_queue_sha256=sha((data / "evaluation/annotation_queue.json").read_bytes()))


def profiles():
    path = ROOT / "profiles/nrpspksdomains.hmm"
    if sha(path.read_bytes()) != PROFILE_SHA:
        raise ValueError("Pinned profile checksum mismatch")
    result = {}
    for block in path.read_text().split("//"):
        fields = {}
        for line in block.splitlines():
            parts = line.split()
            if parts and parts[0] in {"NAME", "ACC", "LENG", "TC"}:
                fields[parts[0]] = parts[1:]
        if "NAME" not in fields:
            continue
        name = fields["NAME"][0]
        if name in result or "TC" not in fields:
            raise ValueError("Missing TC or duplicate profile")
        result[name] = dict(length=int(fields["LENG"][0]), accession=fields.get("ACC", [None])[0],
                            trusted_cutoff=fields["TC"])
    if len(result) != 60:
        raise ValueError("Unexpected profile count")
    return result


def parse_domtbl(path, lengths, query_lengths):
    hits = defaultdict(list)
    for line in path.read_text().splitlines():
        if not line or line.startswith("#"):
            continue
        f = line.split(maxsplit=22)
        if len(f) < 22:
            raise ValueError("Truncated domtblout row")
        name, query = f[0], f[3]
        start, end = int(f[17])-1, int(f[18])
        if name not in lengths or query not in query_lengths:
            raise ValueError("Unrecognized HMM or query ID")
        if int(f[2]) != lengths[name]["length"] or int(f[5]) != query_lengths[query]:
            raise ValueError("HMM/query length mismatch")
        if not 0 <= start < end <= query_lengths[query]:
            raise ValueError("Alignment coordinate mismatch")
        evalue, bitscore = float(f[12]), float(f[13])
        if not math.isfinite(evalue) or not math.isfinite(bitscore):
            raise ValueError("Nonfinite HMM score")
        hits[query].append(dict(raw=name, start=start, end=end, evalue=evalue, bitscore=bitscore,
                               hmm_start=int(f[15])-1, hmm_end=int(f[16]),
                               envelope_start=int(f[19])-1, envelope_end=int(f[20])))
    return hits


def refine_hits(raw_hits, metadata, protein_length):
    """Upstream neighbour-mode helpers, with a declared deterministic tie order."""
    lengths = {name: value["length"] for name, value in metadata.items()}
    values = {refine.HMMResult(h["raw"], h["start"], h["end"], h["evalue"], h["bitscore"])
              for h in raw_hits}
    values = sorted(values, key=lambda h: (h.query_start, h.query_end, h.hit_id, -h.bitscore, h.evalue))
    ties = sum(n > 1 for n in Counter(h.query_start for h in values).values())
    if not values:
        return [], {"raw_hits": 0, "same_start_tie_groups": 0}
    retained = refine._remove_overlapping(values, lengths)
    retained = refine._merge_immediate_neigbours(retained, lengths)
    retained = refine.remove_incomplete(retained, lengths)
    docking = []; domains = []
    for hit in retained:
        if hit.hit_id in DOCK:
            docking.append(dict(raw=hit.hit_id, start=hit.query_start, end=hit.query_end,
                                terminal=(protein_length-hit.query_end < 50 or hit.query_start < 50)))
            continue  # Existing model contract omits docking nodes and preserves actual chains.
        domains.append(dict(raw=hit.hit_id, start=hit.query_start, end=hit.query_end,
                            bitscore=hit.bitscore, evalue=hit.evalue,
                            is_tigrfam=hit.hit_id.startswith("TIGR"),
                            profile_accession=metadata[hit.hit_id]["accession"],
                            hmm_length=lengths[hit.hit_id], profile_sha256=PROFILE_SHA,
                            annotation_source="antismash8.0.0_profiles_neighbour_refinement_deterministic_v1"))
    kept, collapsed = rules.resolve_domain_nodes(domains)
    audit = dict(raw_hits=len(raw_hits), deduplicated_hits=len(values), same_start_tie_groups=ties,
                 docking_annotations=docking,
                 collapsed_overlays=[dict(raw=d["raw"], start=d["start"], end=d["end"], into=o["raw"])
                                     for d, o in collapsed])
    return kept, audit


def run_scan(records, out, cpus):
    metadata = profiles()
    for name in ["hmmscan", "hmmpress"]:
        if not shutil.which(name):
            raise RuntimeError(name + " unavailable: load hmmer/3.3.2-mpi")
    version = subprocess.run(["hmmscan", "-h"], capture_output=True, text=True, check=True).stdout
    if "HMMER 3.3.2" not in version:
        raise RuntimeError("This package pins HMMER3.3.2; observed: " + version.splitlines()[1])
    out.mkdir(parents=True, exist_ok=False)
    database = out / "profiles"; database.mkdir()
    shutil.copy2(ROOT / "profiles/nrpspksdomains.hmm", database / "nrpspksdomains.hmm")
    unique = {}; query_for = {}
    for record in records:
        digest = sha(record["sequence"])
        query = "P" + digest
        unique[query] = record["sequence"]; query_for[record["input_id"]] = query
    (out / "queries.fasta").write_text("".join(">" + key + "\n" + value + "\n" for key, value in sorted(unique.items())))
    with (out / "hmmpress.log").open("w") as log:
        subprocess.run(["hmmpress", str(database / "nrpspksdomains.hmm")], stdout=log, stderr=subprocess.STDOUT, check=True)
    command = ["hmmscan", "--cpu", str(cpus), "--nobias", "--cut_tc", "--noali",
               "--domtblout", str(out / "hits.domtbl"), "-o", str(out / "hmmscan.txt"),
               str(database / "nrpspksdomains.hmm"), str(out / "queries.fasta")]
    with (out / "hmmscan_process.log").open("w") as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    hits = parse_domtbl(out / "hits.domtbl", metadata, {k: len(v) for k, v in unique.items()})
    called = {}; audit = {}
    for query, sequence in unique.items():
        called[query], audit[query] = refine_hits(hits.get(query, []), metadata, len(sequence))
    dump(out / "raw_hits.json", dict(hits)); dump(out / "refinement_audit.json", audit)
    domains = {r["input_id"]: called[query_for[r["input_id"]]] for r in records}
    dump(out / "domains.json", domains)
    dump(out / "scan_provenance.json", dict(hmmer_version=version.splitlines()[1], command=command,
         query_count=len(unique), profile_sha256=PROFILE_SHA, profiles=60,
         antismash_commit="7453d16ebf5d3a843b54232a9f8fc4d95382aa8a",
         full_antismash_run=False, historical_8dev_equivalence_claim=False,
         deterministic_tie_sort=["query_start", "query_end", "profile", "descending_bitscore", "evalue"],
         same_start_tie_groups=sum(a["same_start_tie_groups"] for a in audit.values())))
    return domains


def compare_reference(records, domains):
    rows = []
    for record in records:
        expected = record["expected_domains"]
        found = domains[record["input_id"]]
        exact = sum(any(rules.canonical_type(d["raw"]) == e["canonical"] and d["start"] == e["start"]
                        and d["end"] == e["end"] for d in found) for e in expected)
        overlap = sum(any(rules.canonical_type(d["raw"]) == e["canonical"] and
                          max(0, min(d["end"], e["end"])-max(d["start"], e["start"])) /
                          (max(d["end"], e["end"])-min(d["start"], e["start"])) >= 0.8
                          for d in found) for e in expected)
        rows.append(dict(input_id=record["input_id"], expected_domains=len(expected), found_domains=len(found),
                         same_type_exact_interval=exact, same_type_IoU_at_least_0_8=overlap,
                         exact_type_order=[rules.canonical_type(d["raw"]) for d in found] == [e["canonical"] for e in expected]))
    return rows


def evaluate_annotations(records, domains):
    native = {r["context"]: domains[r["input_id"]] for r in records if r["role"] == "native_control"}
    native_complete = {}
    for context, calls in native.items():
        counts = Counter(rules.canonical_type(d["raw"]) for d in calls)
        expected = EXPECTED_MODULE_COUNTS[context]
        native_complete[context] = counts["AMP-binding"] == counts["PCP"] == expected and counts["Thioesterase"] == 1
    vocab = json.loads((ROOT / "src/domain_vocabulary.json").read_text())["vocab"]
    result = []; approved = []
    for record in records:
        found = domains[record["input_id"]]
        types = [rules.canonical_type(d["raw"]) for d in found]
        flags = []; target = None
        unsupported = [d["raw"] for d in found if rules.canonical_type(d["raw"]) not in vocab
                       or rules.canonical_type(d["raw"]) in {"OTHER", "UNKNOWN"}]
        if unsupported:
            flags.append("UNSUPPORTED_OR_UNRESOLVED_TYPE")
        if not found or "PCP" not in types or "AMP-binding" not in types:
            flags.append("CORE_DOMAIN_CALL_MISSING")
        if not native_complete[record["context"]]:
            flags.append("NATIVE_CONTEXT_CORE_COUNTS_OR_TE_INCOMPLETE")
        if "Thioesterase" not in types:
            flags.append("EXPECTED_TERMINAL_TE_NOT_DETECTED")
        if record["role"] == "engineered":
            lo, hi = record["changed_interval"]
            matches = [i for i, d in enumerate(found) if rules.canonical_type(d["raw"]) == "PCP" and
                       max(0, min(hi, d["end"])-max(lo, d["start"])) >= 0.5*(d["end"]-d["start"])]
            if len(matches) == 1:
                target = matches[0]
            else:
                flags.append("TARGET_PCP_NOT_DETECTED" if not matches else "AMBIGUOUS_TARGET_PCP")
            parent = native[record["context"]]
            parent_types = [rules.canonical_type(d["raw"]) for d in parent]
            if parent_types != types:
                flags.append("DOMAIN_TYPE_ORDER_DIFFERS_FROM_NATIVE_CONTEXT")
            if not parent or "PCP" not in parent_types or "AMP-binding" not in parent_types:
                flags.append("NATIVE_CONTEXT_ANNOTATION_INCOMPLETE")
        row = dict(input_id=record["input_id"], assembly_id=record["assembly_id"], role=record["role"],
                   context=record["context"], domain_count=len(found), canonical_types=types,
                   target_domain_index=target, target_object_index=2*target if target is not None else None,
                   target_interval=[found[target]["start"], found[target]["end"]] if target is not None else None,
                   status="CANDIDATE_ROUTE_ANNOTATED" if not flags else "HELD_FOR_ANNOTATION_REVIEW",
                   flags=flags, unsupported_profiles=unsupported,
                   interpretation="Annotation status only; absence of a hit is not an inactivity label.")
        result.append(row)
        if not flags:
            approved.append(record)
    return result, approved


def inspection(out):
    with zipfile.ZipFile(out / "annotation_inspection.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(out.rglob("*")):
            if path.is_file() and "profiles" not in path.relative_to(out).parts and path.suffix != ".zip":
                archive.write(path, path.relative_to(out))


def run(data, out, cpus):
    started = time.monotonic()
    records, proof = load_data(data)
    references = json.loads((ROOT / "fixtures/annotation_references.json").read_text())["records"]
    out.mkdir(parents=True, exist_ok=False)
    dump(out / "input_manifest.json", [{k: v for k, v in r.items() if k != "sequence"} for r in records])
    domains = run_scan(records + references, out / "scan", cpus)
    comparisons = compare_reference(references, domains)
    write_csv(out / "reference_concordance.csv", comparisons)
    qc, approved = evaluate_annotations(records, domains)
    write_csv(out / "construct_annotation_qc.csv", qc); dump(out / "construct_annotation_qc.json", qc)
    exports = export_routes(approved, out / "candidate_inputs", domains)
    if exports["held_records"]:
        raise RuntimeError("Route exporter rejected annotation-approved inputs; inspect candidate_inputs/holds.jsonl.gz")
    report = dict(status="TDOMAIN_ANNOTATION_COMPLETE_REVIEW_REQUIRED", **proof,
                  annotation_status_counts=dict(Counter(r["status"] for r in qc)),
                  engineered_candidate_routes=sum(r["role"] == "engineered" and not r["flags"] for r in qc),
                  engineered_annotation_holds=sum(r["role"] == "engineered" and bool(r["flags"]) for r in qc),
                  hold_reasons=dict(Counter(flag for r in qc for flag in r["flags"])),
                  reference_domains=sum(r["expected_domains"] for r in comparisons),
                  reference_same_type_exact_interval=sum(r["same_type_exact_interval"] for r in comparisons),
                  reference_same_type_IoU_at_least_0_8=sum(r["same_type_IoU_at_least_0_8"] for r in comparisons),
                  candidate_export=exports, seconds=round(time.monotonic()-started, 3),
                  activity_labels_used=False, activity_labels_inferred=False, model_scores_generated=0,
                  pretrained_weights_changed=False, esmc_embeddings_generated=0,
                  full_antismash_run=False, historical_8dev_equivalence_claim=False,
                  proceed_to_embedding_automatically=False,
                  next_step="Review target-PCP coverage, native topology and reference concordance before ESMC embedding.")
    dump(out / "report.json", report)
    inspection(out)
    print(json.dumps(report, indent=2))
    return report


def selftest():
    metadata = profiles()
    example = [dict(raw="PCP", start=10, end=65, evalue=1e-10, bitscore=40),
               dict(raw="PP-binding", start=11, end=64, evalue=1e-9, bitscore=30),
               dict(raw="AMP-binding", start=100, end=500, evalue=1e-40, bitscore=80)]
    a, _ = refine_hits(example, metadata, 520)
    b, _ = refine_hits(list(reversed(example)), metadata, 520)
    assert a == b and [d["raw"] for d in a] == ["PCP", "AMP-binding"]
    assert rules.canonical_type("PP-binding") == "PCP"
    assert not refine_hits([dict(raw="PCP", start=0, end=20, evalue=1e-5, bitscore=30)], metadata, 40)[0]
    import tempfile
    with tempfile.TemporaryDirectory() as temporary:
        path = Path(temporary) / "fixture.domtbl"
        path.write_text("PCP - 70 Pexample - 100 1e-8 40 0 1 1 1e-8 1e-8 40 0 1 55 11 65 8 68 0.95 fixture\n")
        h = parse_domtbl(path, metadata, {"Pexample": 100})["Pexample"][0]
        assert (h["start"], h["end"], h["envelope_start"], h["envelope_end"]) == (10, 65, 7, 68)
    native = dict(input_id="N", assembly_id="N", role="native_control", context="GxpS_minimal_SU2_T3", sequence="A"*1200)
    mutant = dict(input_id="M", assembly_id="M", role="engineered", context="GxpS_minimal_SU2_T3",
                  sequence="A"*1200, changed_interval=[450, 550])
    calls = [dict(raw="AMP-binding", start=0, end=300), dict(raw="PCP", start=350, end=410),
             dict(raw="Thioesterase", start=900, end=1150)]
    qc, _ = evaluate_annotations([native, mutant], {"N": calls, "M": calls})
    assert "TARGET_PCP_NOT_DETECTED" in qc[1]["flags"]
    assert "NATIVE_CONTEXT_CORE_COUNTS_OR_TE_INCOMPLETE" in qc[1]["flags"]
    from route_export import selftest as route_selftest
    route_selftest()
    return dict(status="ANNOTATION_SELFTEST_OK", pinned_profiles=len(metadata),
                tests=["deterministic_profile_competition", "short_domain_filter", "domtbl_coordinate_orientation",
                       "missing_target_and_incomplete_native_hold", "frozen_route_contract"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--cpus", type=int, default=4)
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument("--selftest", action="store_true")
    parser.add_argument("--validate-backend", action="store_true", help="Scan six annotation references only, not the study dataset")
    args = parser.parse_args()
    if args.cpus < 1:
        parser.error("--cpus must be positive")
    if args.selftest:
        print(json.dumps(selftest())); return
    if args.validate_backend:
        if args.out is None:
            parser.error("--out required")
        references = json.loads((ROOT / "fixtures/annotation_references.json").read_text())["records"]
        found = run_scan(references, args.out.resolve(), args.cpus)
        rows = compare_reference(references, found)
        dump(args.out / "reference_concordance.json", rows)
        print(json.dumps(rows, indent=2)); return
    if args.data_dir is None:
        parser.error("--data-dir required")
    profiles()
    if args.preflight_only:
        _, proof = load_data(args.data_dir)
        print(json.dumps(dict(status="TDOMAIN_ANNOTATION_PREFLIGHT_OK", **proof))); return
    if args.out is None:
        parser.error("--out required")
    run(args.data_dir.resolve(), args.out.resolve(), args.cpus)


if __name__ == "__main__":
    main()
