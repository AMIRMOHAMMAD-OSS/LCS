#!/usr/bin/env bash
# Submit one explicit new CPU-only annotation run; no model weights are changed.
set -euo pipefail
NRPS_TA_PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
NRPS_TA_ROOT=$(cd -- "$NRPS_TA_PACKAGE/.." && pwd)
NRPS_TA_DATA=""
while (($#)); do
    case "$1" in
        --root)
            if (($# < 2)); then printf '%s\n' 'Missing value for --root' >&2; exit 2; fi
            NRPS_TA_ROOT="$2"; shift 2 ;;
        --data-dir)
            if (($# < 2)); then printf '%s\n' 'Missing value for --data-dir' >&2; exit 2; fi
            NRPS_TA_DATA="$2"; shift 2 ;;
        -h|--help)
            printf '%s\n' 'Usage: bash submit.sh [--root PROJECT_DIRECTORY] [--data-dir DATA_BUNDLE_DIRECTORY]'
            printf '%s\n' 'Defaults: project = parent of this bundle; data = project/NeurALPS_TDomain_Data_20261006.'
            exit 0 ;;
        *) printf 'Unknown argument: %s\n' "$1" >&2; exit 2 ;;
    esac
done
NRPS_TA_ROOT=$(cd -- "$NRPS_TA_ROOT" && pwd)
if [[ -z "$NRPS_TA_DATA" ]]; then
    NRPS_TA_DATA="$NRPS_TA_ROOT/NeurALPS_TDomain_Data_20261006"
fi
NRPS_TA_DATA=$(cd -- "$NRPS_TA_DATA" && pwd)
command -v sbatch >/dev/null || { printf '%s\n' 'sbatch is not available; run submit.sh on Jean Zay.' >&2; exit 1; }
python3 -B "$NRPS_TA_PACKAGE/verify.py"
python3 -B "$NRPS_TA_PACKAGE/run_annotation.py" --data-dir "$NRPS_TA_DATA" --preflight-only
NRPS_TA_SUBMISSION=$(sbatch --parsable \
    --account=nef@cpu --partition=cpu_p1 --qos=qos_cpu-t3 \
    --job-name=nrps_tdannot --nodes=1 --ntasks=1 --cpus-per-task=4 \
    --propagate=NONE --no-requeue \
    --time=02:00:00 --chdir="$NRPS_TA_ROOT" \
    --output="$NRPS_TA_ROOT/e9_tdomain_annotation_%j.log" \
    "$NRPS_TA_PACKAGE/batch.sh" "$NRPS_TA_PACKAGE" "$NRPS_TA_ROOT" "$NRPS_TA_DATA")
NRPS_TA_JOB_ID=${NRPS_TA_SUBMISSION%%;*}
if [[ ! "$NRPS_TA_JOB_ID" =~ ^[0-9]+$ ]]; then
    printf 'Unexpected sbatch response; job may have been submitted: %s\n' "$NRPS_TA_SUBMISSION" >&2
    exit 1
fi
python3 -B - "$NRPS_TA_PACKAGE" "$NRPS_TA_ROOT" "$NRPS_TA_DATA" "$NRPS_TA_JOB_ID" <<'PY'
import datetime
import json
import os
from pathlib import Path
import sys
import tempfile

package, root, data, job_id = sys.argv[1:]
record = {
    "job_id": job_id,
    "submitted_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "package": package, "project_root": root, "data_dir": data,
    "output": str(Path(root) / f"e9_tdomain_annotation_{job_id}"),
    "log": str(Path(root) / f"e9_tdomain_annotation_{job_id}.log"),
    "cpus": 4, "gpu_requested": False,
}
name = None
try:
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=package,
                                     prefix=".LAST_JOB.", suffix=".tmp", delete=False) as handle:
        name = handle.name
        json.dump(record, handle, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(name, Path(package) / "LAST_JOB.json")
except OSError as error:
    if name is not None:
        Path(name).unlink(missing_ok=True)
    print(f"Job {job_id} was submitted, but LAST_JOB.json could not be written: {error}", file=sys.stderr)
    print(f"Output: {record['output']}\nLog: {record['log']}", file=sys.stderr)
    raise SystemExit(1)
print(f"Submitted CPU-only T-domain annotation: {job_id}")
print("Resources: 4 CPUs, scheduler-assigned memory, 2 hours; HMMER annotation only.")
print(f"Data: {data}")
print(f"Output: {record['output']}")
print(f"Log: {record['log']}")
print(f"Status: bash {Path(package) / 'status.sh'}")
PY
