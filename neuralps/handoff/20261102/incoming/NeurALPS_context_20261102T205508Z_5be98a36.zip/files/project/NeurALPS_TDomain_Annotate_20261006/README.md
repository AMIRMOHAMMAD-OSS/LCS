# T-domain annotation audit for NeurALPS

This add-on processes the already transferred `NeurALPS_TDomain_Data_20261006`
bundle. It submits one **CPU job: 4 CPUs, 8 GB, 2-hour time limit**. No full
antiSMASH installation, GPU job, model fitting, or embedding extraction is needed
for this stage. The checked ESMC environment is used in the subsequent stage.

## Run on Jean Zay

Place this directory next to the data bundle under the project root, then run:

```bash
cd /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2
python3 NeurALPS_TDomain_Annotate_20261006/verify.py
bash NeurALPS_TDomain_Annotate_20261006/submit.sh
bash NeurALPS_TDomain_Annotate_20261006/status.sh
```

The launcher checks all 91 original data files, all 84 queued protein hashes,
the exchanged-fragment intervals, the four native controls and the pinned profile
checksum before submission. Source data and existing caches/checkpoints remain
unchanged. Each run writes a new `e9_tdomain_annotation_JOBID` directory and
`e9_tdomain_annotation_JOBID.log`. The job loads `hmmer/3.3.2-mpi` and executes
one multithreaded `hmmscan` process. It does not invoke MPI workers.

## What this runs

This is a focused **antiSMASH-derived NRPS-domain scanner**, not a full antiSMASH
run. It uses all 60 trusted-cutoff profiles from official antiSMASH 8.0.0, commit
`7453d16ebf5d3a843b54232a9f8fc4d95382aa8a`, and HMMER 3.3.2:

```text
hmmscan --cpu 4 --nobias --cut_tc --noali --domtblout ... -o ... profiles.hmm proteins.fasta
```

The original profile file is included and checksummed. No profile databases are
downloaded on Jean Zay. HMMER's database indices are generated only inside the
new job's output directory.

Refinement uses upstream neighbour-mode helpers: resolve substantial overlaps
by bit score, merge adjacent fragments of the same profile, and apply the
upstream length filter/fallback. Protein alignment coordinates, not HMM or
envelope coordinates, define the domains. The published code's effective
length filter is >50% of profile length, with the >one-third fallback only when
no domain survives for the protein.

One declared reproducibility change is deterministic secondary sorting of
equal-start hits by end, profile name, descending score and E-value. Upstream
sorts only by start after a set operation. The count of equal-start groups is
reported. The vendored refinement implementation otherwise changes only
type-only Biopython imports; original files are preserved in `vendor/`.

After refinement, the existing NeurALPS rules map PP-binding to PCP, collapse
overlapping TIGRFAM overlays, omit docking nodes, and create whole-domain inputs
and covalent windows with 20-aa flanks. Every source record represents one
physical protein; no artificial protein break is introduced. All sequence and
parent hashes use uppercase amino-acid ASCII SHA-256. No activity labels enter
domain selection or route construction.

## Why this remains an audit stage

The historical pretraining annotations record `8.dev`, without the exact
antiSMASH commit. This package therefore does **not** claim identical annotation
software. Six existing BODE physical protein chains, selected by identifier and
sequence uniqueness without activity-based selection, are scanned as controls.
Their historical domain types and coordinates are compared with the new calls.

Local HMMER 3.3.2 validation matched **51 of 52 historical domains exactly** in
type and interval. The difference is a short thioesterase annotation in
REFERENCE_2 (residues 3695:3798, zero-based/end-exclusive). Its short span does not
survive this scanner's refinement. This is an annotation discrepancy, not a
functional result. All six comparison records are included in the job output.

For the new study, each engineered construct must have exactly one PCP call with
at least half of that PCP inside its exchanged-fragment interval. Its ordered
domain types must match its matched native context. Native controls must have
the paper-supported core counts: three A/T pairs for minimal GxpS, four for
GxhS-1/2, five for GshS, and one terminal TE. Unresolved profile types, missing
targets, missing TE, incomplete native controls, or changed topology produce
explicit holds. These holds are **not inactive labels**. Held inputs and their
raw hits remain in the audit and are not silently removed from the dataset.

The output status is `TDOMAIN_ANNOTATION_COMPLETE_REVIEW_REQUIRED`, even if all
constructs pass. Review coverage and the reference comparisons before preparing
the ESMC sidecar cache. Do not score a shortened route that joins around a missing
target domain, or relax detection thresholds after looking at activity outcomes.

## Outputs

| Path inside the job output | Contents |
|---|---|
| `report.json` | Counts, holds, reference concordance and explicit next-stage status. |
| `construct_annotation_qc.csv` | All 84 engineered constructs and four native controls, target intervals and holds. |
| `reference_concordance.csv` | Type/coordinate comparison for six historical protein chains. |
| `scan/hits.domtbl`, `scan/raw_hits.json` | Complete HMMER hit evidence. |
| `scan/domains.json`, `scan/refinement_audit.json` | Refined domains, ties, docking and overlay decisions. |
| `candidate_inputs/routes.jsonl.gz` | Label-free model routes for annotation-approved inputs. |
| `candidate_inputs/parents.fasta.gz` | Hash-keyed physical protein sequences. |
| `candidate_inputs/unique_sequences.fasta.gz` | Hash-keyed domains and boundary windows to embed later. |
| `candidate_inputs/slot_provenance.tsv.gz` | Exact window coordinates, types, states and hashes. |
| `annotation_inspection.zip` | Review files without HMMER database indices. |

Candidate routes contain no ESMC vectors or compatibility scores. The frozen
model's existing store does not automatically recognize these new inputs; the
next stage needs a separate feature/parent lookup adapter. The old cache and
training-derived target means must remain unchanged.

## Verification performed

See `VALIDATION.json`. The real scanner was compiled and run locally against
six existing reference proteins. Parser coordinate tests, competition/filtering,
missing-target holds, overlap windows, alias mapping, sequence hashes and
overwrite protections passed. Slurm commands were tested with mocks, not submitted
from this environment. The full 84-construct input preflight and annotation run
will execute on your transferred copy on Jean Zay; this package does not claim
that those cluster results already exist.

Developer checks:

```bash
python3 run_annotation.py --selftest
python3 run_annotation.py --validate-backend --out NEW_VALIDATION_DIRECTORY --cpus 4
```

The backend check requires HMMER 3.3.2; all source and fixture files are bundled.
Original sources and adaptation details are recorded in
`provenance/annotation_sources.json`. See `LICENSE_AND_SOURCES.md` for attribution.
