#!/usr/bin/env python3
"""Verify the immutable embedding bundle against its SHA256SUMS manifest."""
import hashlib
import json
from pathlib import Path
import re
import sys


def verify(directory):
    root = Path(directory).resolve()
    manifest = root / "SHA256SUMS"
    if not manifest.is_file():
        raise ValueError(f"Missing bundle manifest: {manifest}")
    seen = set()
    for number, line in enumerate(manifest.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        match = re.fullmatch(r"([0-9a-fA-F]{64}) [ *](.+)", line)
        if not match:
            raise ValueError(f"Invalid SHA256SUMS line {number}")
        expected, relative = match.groups()
        target = Path(relative)
        if target.is_absolute() or ".." in target.parts or relative in seen:
            raise ValueError(f"Unsafe or duplicate manifest path: {relative}")
        if target.name in {"LAST_JOB.json", "SHA256SUMS"}:
            raise ValueError(f"Generated/self-referencing file in immutable manifest: {relative}")
        path = (root / target).resolve()
        if root not in path.parents or not path.is_file():
            raise ValueError(f"Missing or out-of-bundle file: {relative}")
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        if digest.hexdigest() != expected.lower():
            raise ValueError(f"Checksum mismatch: {relative}")
        seen.add(relative)
    if not seen:
        raise ValueError("The bundle manifest is empty")
    return len(seen)


if __name__ == "__main__":
    try:
        count = verify(Path(__file__).resolve().parent)
    except (OSError, ValueError) as error:
        print(f"TDOMAIN_EMBED_BUNDLE_ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
    print(json.dumps({"stage": "TDOMAIN_EMBED_BUNDLE_OK", "files": count}))
