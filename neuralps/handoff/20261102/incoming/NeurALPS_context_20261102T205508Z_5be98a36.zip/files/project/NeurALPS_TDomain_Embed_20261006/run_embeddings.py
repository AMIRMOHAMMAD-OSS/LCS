#!/usr/bin/env python3
"""Extract independent ESMC features for the reviewed T-domain annotation run."""
from __future__ import annotations
import argparse
from collections import Counter
import csv
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
import traceback
import zipfile

PACKAGE = Path(__file__).resolve().parent
POLICY = "physical_end_extradomain_tail64_v1"
AA = set("ACDEFGHIKLMNPQRSTVWY")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def sha_sequence(sequence):
    return hashlib.sha256(sequence.encode("ascii")).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    os.replace(temporary, path)


def event(stage, **fields):
    print(json.dumps(dict(stage=stage, **fields), allow_nan=False), flush=True)


def fasta(path):
    result = {}; name = None
    with gzip.open(path, "rt", encoding="ascii") as stream:
        for raw in stream:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                name = line[1:]
                require(name not in result, "Duplicate FASTA identity")
                result[name] = ""
            else:
                require(name is not None, "Sequence before FASTA header")
                result[name] += line
    for h, seq in result.items():
        require(seq and set(seq) <= AA and sha_sequence(seq) == h, "FASTA hash/alphabet mismatch: " + h)
    return result


def validate_routes(routes, features, parents, vocabulary):
    """Check provenance and future inference lookup without using activity labels."""
    ids = set(); inputs = set(); used_features = set(); used_parents = set()
    uses = {}; domains = boundaries = 0
    for r in routes:
        aid = r["assembly_id"]
        require(aid not in ids and r["input_id"] not in inputs, "Duplicate route identity")
        ids.add(aid); inputs.add(r["input_id"])
        require(r["role"] in {"engineered", "native_control"}, "Unexpected route role")
        require(r["dataset"] == "tdomain" and r["label_status"] == "ASSAY_LABELS_NOT_INCLUDED", "Unexpected route cohort")
        require("label" not in r and "activity" not in r, "Activity label in embedding input")
        require(r["n_chains"] == 1 and r["boundary_window_policy"] == POLICY, "Route policy changed")
        route = r["route"]; slots = r["model_slots"]
        require(len(route) == len(slots) == 2 * r["n_domains"] - 1, "Route/slot cardinality mismatch")
        require(len(r["parent_sequence_hashes"]) == 1, "Expected one physical parent")
        uid, ph = next(iter(r["parent_sequence_hashes"].items()))
        require(ph in parents and r["parent_lengths"][uid] == len(parents[ph]), "Parent sequence length mismatch")
        used_parents.add(ph)
        for index, (obj, slot) in enumerate(zip(route, slots)):
            kind = index % 2
            require(obj["kind"] == slot["kind"] == kind and obj["chain"] == 1, "Object kind/chain mismatch")
            require(slot["object_index"] == index and slot["slot"] == 0, "Slot/object alignment mismatch")
            require(slot["state"] == "OBSERVED", "Unexpected missing slot in approved annotation run")
            require(slot["protein_uid"] == uid and slot["parent_sequence_hash"] == ph, "Slot parent mismatch")
            lo, hi = slot["start"], slot["end"]
            require(type(lo) is int and type(hi) is int and 0 <= lo < hi <= len(parents[ph]), "Invalid slot interval")
            h = slot["sequence_hash"]
            require(h in features and obj["seq_hash"] == h, "Missing or inconsistent feature identity")
            require(features[h] == parents[ph][lo:hi] and slot["length"] == hi - lo, "Feature is not exact parent slice")
            require(0 < len(features[h]) <= 2046, "Direct ESMC input exceeds 2046 residues")
            if kind == 0:
                canonical = obj["canonical_domain_type"]
                require(canonical not in {"UNKNOWN", "OTHER"} and vocabulary.get(canonical) == obj["domain_type"], "Domain vocabulary mismatch")
                require(obj["protein_uid"] == uid, "Domain physical chain mismatch")
                require([lo, hi] == [obj["start_aa_0based"], obj["end_aa_0based_exclusive"]], "Domain coordinate mismatch")
                group = "D:" + str(obj["domain_type"])
                domains += 1
            else:
                left, right = route[index-1], route[index+1]
                lend, rstart = left["end_aa_0based_exclusive"], right["start_aa_0based"]
                expected = [max(0, min(lend, rstart)-20), min(len(parents[ph]), max(lend, rstart)+20)]
                require([lo, hi] == expected, "Covalent window differs from frozen +/-20 rule")
                require(obj["left_domain_uid"] == left["source_domain_uid"] and obj["right_domain_uid"] == right["source_domain_uid"], "Boundary endpoints differ")
                require(obj["left_protein_uid"] == obj["right_protein_uid"] == uid, "Boundary crosses an undeclared protein break")
                require(obj["state0"] == "OBSERVED" and hi-lo >= 3, "Invalid boundary availability")
                group = "C:" + str(left["domain_type"]) + ":" + str(right["domain_type"])
                boundaries += 1
            require(slot["group"] == group, "Slot context group mismatch")
            used_features.add(h)
            counts = uses.setdefault(h, Counter())
            counts["domain_uses" if kind == 0 else "boundary_uses"] += 1
    require(used_features == set(features) and used_parents == set(parents), "Extra or missing feature/parent sequences")
    return dict(routes=len(routes), domains=domains, covalent_boundaries=boundaries,
                observed_slots=domains+boundaries, unique_features=len(features), unique_parents=len(parents)), uses


def load_annotation(annotation, contract):
    report = read_json(annotation / "report.json")
    require(report["status"] == "TDOMAIN_ANNOTATION_COMPLETE_REVIEW_REQUIRED", "Annotation did not finish")
    require(report["dataset_manifest_sha256"] == contract["dataset_manifest_sha256"] and
            report["annotation_queue_sha256"] == contract["annotation_queue_sha256"], "Annotation input dataset differs")
    require(report["engineered_annotation_holds"] == 0 and report["hold_reasons"] == {}, "Annotation holds need review")
    require(report["reference_domains"] == 52 and report["reference_same_type_exact_interval"] == 51,
            "Reference concordance differs from reviewed job 695798")
    require(report["activity_labels_used"] is False and report["activity_labels_inferred"] is False, "Unexpected label use")
    source = annotation / "candidate_inputs"
    summary = read_json(source / "summary.json")
    require(summary == report["candidate_export"], "Export summary/report disagreement")
    require(summary["files_sha256"] == contract["annotation_files_sha256"], "Different annotation export; needs review")
    for name, expected in contract["annotation_files_sha256"].items():
        require(sha_file(source / name) == expected, "Annotation export changed: " + name)
    require(summary["connection_rules_sha256"] == contract["connection_rules_sha256"] and
            summary["vocabulary_sha256"] == contract["vocabulary_sha256"], "Frozen input contract changed")
    with gzip.open(source / "routes.jsonl.gz", "rt") as stream:
        routes = [json.loads(line) for line in stream if line.strip()]
    with gzip.open(source / "holds.jsonl.gz", "rt") as stream:
        require(not stream.read().strip(), "Unexpected export holds")
    features = fasta(source / "unique_sequences.fasta.gz")
    parents = fasta(source / "parents.fasta.gz")
    vocab = read_json(PACKAGE / "domain_vocabulary.json")["vocab"]
    canonical = json.dumps(vocab, sort_keys=True, separators=(",", ":"))
    require(sha_sequence(canonical) == contract["vocabulary_sha256"], "Bundled vocabulary differs")
    proof, uses = validate_routes(routes, features, parents, vocab)
    require(proof == contract["expected_counts"], "Annotated route inventory differs")
    require(Counter(r["role"] for r in routes) == {"engineered": 84, "native_control": 4}, "Unexpected roles")
    with gzip.open(source / "sequence_inventory.tsv.gz", "rt") as stream:
        inventory = list(csv.DictReader(stream, delimiter="\t"))
    require(len(inventory) == len(features) and {r["sequence_hash"] for r in inventory} == set(features), "Feature inventory identity mismatch")
    for row in inventory:
        h = row["sequence_hash"]
        require(int(row["length"]) == len(features[h]), "Inventory length mismatch")
        require(all(int(row[k]) == uses[h][k] for k in ("domain_uses", "boundary_uses")), "Inventory use count mismatch")
    qc = read_json(annotation / "construct_annotation_qc.json")
    records = read_json(annotation / "input_manifest.json")
    require(len(qc) == len(records) == len(routes), "Annotation metadata coverage mismatch")
    by_id = {r["input_id"]: r for r in routes}
    require({r["input_id"] for r in qc} == {r["input_id"] for r in records} == set(by_id), "Annotation metadata identity mismatch")
    for q, meta in [(q, next(m for m in records if m["input_id"] == q["input_id"])) for q in qc]:
        r = by_id[q["input_id"]]
        require(q["assembly_id"] == meta["assembly_id"] == r["assembly_id"], "Annotation metadata assembly mismatch")
        require(q["role"] == meta["role"] == r["role"] and q["context"] == meta["context"], "Annotation context mismatch")
        require(not q["flags"] and q["status"] == "CANDIDATE_ROUTE_ANNOTATED", "Annotation is not approved")
        require(meta["amino_acid_sha256"] == next(iter(r["parent_sequence_hashes"].values())), "Input parent hash mismatch")
        if r["role"] == "engineered":
            j = q["target_object_index"]
            require(type(j) is int and 0 <= j < len(r["route"]) and j % 2 == 0, "Invalid target domain index")
            target = r["route"][j]
            require(target["canonical_domain_type"] == "PCP", "Target is not a PCP")
            lo, hi = target["start_aa_0based"], target["end_aa_0based_exclusive"]
            require(q["target_interval"] == [lo, hi], "Target coordinates disagree")
            a, b = meta["changed_interval"]
            require(max(0, min(hi, b)-max(lo, a)) >= (hi-lo)*0.5, "Target PCP does not overlap exchanged fragment")
    proof["max_feature_length"] = max(map(len, features.values()))
    proof["annotation_report_sha256"] = sha_file(annotation / "report.json")
    proof["annotation_metadata_sha256"] = {name: sha_file(annotation / name) for name in
        ("input_manifest.json", "construct_annotation_qc.json", "construct_annotation_qc.csv", "reference_concordance.csv")}
    return sorted(features.items(), key=lambda row: (len(row[1]), row[0])), proof


def preflight(root, annotation):
    contract = read_json(PACKAGE / "CONTRACT.json")
    rows, proof = load_annotation(annotation, contract)
    for name in ("models/ESMC-600M/config.json", "models/ESMC-600M/model.safetensors",
                 "envs/esmc_connections_hf/bin/python", "nrps_esmc_environment.sh",
                 "results/routeA_esmc600m_embeddings/domains/domains_embedding_index.tsv.gz"):
        require((root / name).is_file(), "Missing project dependency: " + name)
    for name, expected in contract["project_files_sha256"].items():
        require(sha_file(root / name) == expected, "Pinned project file changed: " + name)
    reference_manifest = read_json(root / contract["reference_manifest"])
    refs = reference_manifest["references"]
    require(len(refs) >= 8 and len({r["hash"] for r in refs}) == len(refs), "Too few or duplicate cache reference sequences")
    for r in refs:
        require(r["hash"] == sha_sequence(r["seq"]) and r["length"] == len(r["seq"])
                and 0 < r["length"] <= 2046 and set(r["seq"]) <= set("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), "Reference sequence contract mismatch")
    cfg = read_json(root / "models/ESMC-600M/config.json")
    require(cfg.get("model_type") == "esmc" and cfg.get("d_model") == 1152 and cfg.get("n_layers") == 36 and cfg.get("n_heads") == 18,
            "Unexpected ESMC model configuration")
    proof["reference_sequences"] = len(refs)
    proof["project_files_sha256"] = contract["project_files_sha256"]
    proof["config_sha256"] = sha_file(root / "models/ESMC-600M/config.json")
    return rows, refs, proof


def run(root, annotation, out):
    started = time.monotonic()
    require(not out.exists(), "Output already exists; submit a fresh job")
    rows, refs, proof = preflight(root, annotation)
    out.mkdir(parents=True, exist_ok=False)
    try:
        write_json(out / "input_preflight.json", proof)
        shutil.copytree(annotation / "candidate_inputs", out / "inputs")
        contract = read_json(PACKAGE / "CONTRACT.json")
        for name, expected in contract["annotation_files_sha256"].items():
            require(sha_file(out / "inputs" / name) == expected, "Input changed during copy: " + name)
        (out / "annotation").mkdir()
        for name in ("report.json", "input_manifest.json", "construct_annotation_qc.json", "construct_annotation_qc.csv", "reference_concordance.csv"):
            shutil.copy2(annotation / name, out / "annotation" / name)
            expected = proof["annotation_report_sha256"] if name == "report.json" else proof["annotation_metadata_sha256"][name]
            require(sha_file(out / "annotation" / name) == expected, "Annotation metadata changed during copy: " + name)
        event("TDOMAIN_EMBED_INPUTS_VALIDATED", **proof)
        from embedding_backend import run_backend
        backend = run_backend(root, out, rows, refs)
        # Inputs copied byte-for-byte for subsequent masking/scoring; no new type means.
        files = {str(p.relative_to(out)): sha_file(p) for p in sorted(out.rglob("*")) if p.is_file()}
        report = dict(status="TDOMAIN_EMBEDDINGS_COMPLETE", annotation_source=str(annotation),
            engineered_constructs=84, native_controls=4, feature_sequences=290,
            feature_dimension=1152, feature_extraction_mode="independent_sequence",
            full_parent_proteins_embedded=0, truncated_sequences=0, training_updates=0,
            pretrained_weights_changed=False, original_caches_changed=False,
            activity_labels_used=False, model_scores_generated=0, compatibility_mapping_validated=False,
            reference_gate=backend.get("reference_comparison", backend.get("reference_gate")),
            backend=backend, input_preflight=proof, output_files_sha256=files,
            seconds=round(time.monotonic()-started, 3),
            next_step="Use a separate input lookup to evaluate the frozen 26000-step compatibility model; activity labels remain separate.")
        write_json(out / "report.json", report)
        with zipfile.ZipFile(out / "embedding_inspection.zip", "w", zipfile.ZIP_DEFLATED) as archive:
            for p in sorted(out.rglob("*")):
                if p.is_file() and p.suffix != ".zip":
                    archive.write(p, p.relative_to(out))
        (out / "EMBEDDINGS_COMPLETE").write_text(sha_file(out / "report.json") + "\n")
        print(json.dumps(report, indent=2, allow_nan=False), flush=True)
        return report
    except BaseException as exc:
        write_json(out / "fatal_error.json", dict(status="TDOMAIN_EMBEDDINGS_FAILED", error=str(exc), traceback=traceback.format_exc()))
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--annotation-dir", type=Path, required=True)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    root, annotation = args.root.resolve(), args.annotation_dir.resolve()
    if args.preflight_only:
        _, _, proof = preflight(root, annotation)
        event("TDOMAIN_EMBED_PREFLIGHT_OK", **proof)
        return
    if args.out is None:
        parser.error("--out required")
    run(root, annotation, args.out.resolve())


if __name__ == "__main__":
    main()
