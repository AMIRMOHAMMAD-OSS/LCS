#!/usr/bin/env bash
# Submit one new frozen ESMC embedding run. No scoring or model fitting.
set -euo pipefail
NRPS_TDE_PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
NRPS_TDE_ROOT=$(cd -- "$NRPS_TDE_PACKAGE/.." && pwd)
NRPS_TDE_ANNOTATION=""
while (($#)); do
    case "$1" in
        --root)
            if (($# < 2)); then printf '%s\n' 'Missing value for --root' >&2; exit 2; fi
            NRPS_TDE_ROOT="$2"; shift 2 ;;
        --annotation-dir)
            if (($# < 2)); then printf '%s\n' 'Missing value for --annotation-dir' >&2; exit 2; fi
            NRPS_TDE_ANNOTATION="$2"; shift 2 ;;
        -h|--help)
            printf '%s\n' 'Usage: bash submit.sh [--root PROJECT_DIRECTORY] [--annotation-dir ANNOTATION_OUTPUT]'
            printf '%s\n' 'Defaults: project = parent of this bundle; annotation = project/e9_tdomain_annotation_695798.'
            exit 0 ;;
        *) printf 'Unknown argument: %s\n' "$1" >&2; exit 2 ;;
    esac
done
NRPS_TDE_ROOT=$(cd -- "$NRPS_TDE_ROOT" && pwd)
if [[ -z "$NRPS_TDE_ANNOTATION" ]]; then
    NRPS_TDE_ANNOTATION="$NRPS_TDE_ROOT/e9_tdomain_annotation_695798"
fi
NRPS_TDE_ANNOTATION=$(cd -- "$NRPS_TDE_ANNOTATION" && pwd)
command -v sbatch >/dev/null || { printf '%s\n' 'sbatch is not available; run submit.sh on Jean Zay.' >&2; exit 1; }
python3 -B "$NRPS_TDE_PACKAGE/verify.py"
python3 -B "$NRPS_TDE_PACKAGE/run_embeddings.py" \
    --root "$NRPS_TDE_ROOT" --annotation-dir "$NRPS_TDE_ANNOTATION" --preflight-only
NRPS_TDE_SUBMISSION=$(sbatch --parsable \
    --account=nef@a100 --partition=gpu_p5 --qos=qos_gpu_a100-t3 \
    --job-name=nrps_tdembed --nodes=1 --ntasks=1 --cpus-per-task=8 --hint=nomultithread \
    --gres=gpu:1 --constraint=a100 --time=02:00:00 --propagate=NONE --no-requeue \
    --chdir="$NRPS_TDE_ROOT" \
    --output="$NRPS_TDE_ROOT/e10_tdomain_embed_%j.log" \
    --error="$NRPS_TDE_ROOT/e10_tdomain_embed_%j.log" \
    "$NRPS_TDE_PACKAGE/batch.sh" "$NRPS_TDE_PACKAGE" "$NRPS_TDE_ROOT" "$NRPS_TDE_ANNOTATION")
NRPS_TDE_JOB_ID=${NRPS_TDE_SUBMISSION%%;*}
if [[ ! "$NRPS_TDE_JOB_ID" =~ ^[0-9]+$ ]]; then
    printf 'Unexpected sbatch response; job may have been submitted: %s\n' "$NRPS_TDE_SUBMISSION" >&2
    exit 1
fi
python3 -B - "$NRPS_TDE_PACKAGE" "$NRPS_TDE_ROOT" "$NRPS_TDE_ANNOTATION" "$NRPS_TDE_JOB_ID" <<'PY'
import datetime
import json
import os
from pathlib import Path
import sys
import tempfile

package, root, annotation, job_id = sys.argv[1:]
record = {
    "job_id": job_id,
    "submitted_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "package": package, "project_root": root, "annotation_dir": annotation,
    "output": str(Path(root) / f"e10_tdomain_embed_{job_id}"),
    "log": str(Path(root) / f"e10_tdomain_embed_{job_id}.log"),
    "cpus": 8, "gpus": 1, "gpu_type": "a100",
    "model_fitting": False, "compatibility_scoring": False,
}
name = None
try:
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=package,
                                     prefix=".LAST_JOB.", suffix=".tmp", delete=False) as handle:
        name = handle.name
        json.dump(record, handle, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(name, Path(package) / "LAST_JOB.json")
except OSError as error:
    if name is not None:
        Path(name).unlink(missing_ok=True)
    print(f"Job {job_id} was submitted, but LAST_JOB.json could not be written: {error}", file=sys.stderr)
    print(f"Output: {record['output']}\nLog: {record['log']}", file=sys.stderr)
    raise SystemExit(1)
print(f"Submitted one-A100 T-domain embedding run: {job_id}")
print("Resources: one A100, 8 CPUs, scheduler-assigned memory, 2 hours.")
print("Frozen ESMC feature extraction only; no compatibility scoring or training.")
print(f"Annotation: {annotation}")
print(f"Output: {record['output']}")
print(f"Log: {record['log']}")
print(f"Status: bash {Path(package) / 'status.sh'}")
PY
