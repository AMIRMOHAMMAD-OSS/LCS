#!/usr/bin/env python3
"""Coordinate/identity rejection tests; no inference or biological validation."""
import copy
import json
from pathlib import Path
from run_embeddings import validate_routes


def main():
    root = Path(__file__).resolve().parent
    fixture = json.loads((root / "fixtures/route_contract.json").read_text())
    vocab = json.loads((root / "domain_vocabulary.json").read_text())["vocab"]
    route = fixture["route"]
    # Deliberately overlapping A/PCP calls: seam spans both edges plus 20 aa.
    assert [route["model_slots"][1][k] for k in ("start", "end")] == [170, 220]
    proof, _ = validate_routes([route], fixture["features"], fixture["parents"], vocab)
    assert proof["domains"] == 3 and proof["covalent_boundaries"] == 2
    cases = 0
    for mutation in ("wrong_slice", "swapped_slots", "wrong_group", "wrong_parent", "wrong_endpoint", "label", "extra_feature"):
        f = copy.deepcopy(fixture); r = f["route"]
        if mutation == "wrong_slice": r["model_slots"][1]["start"] += 1
        elif mutation == "swapped_slots": r["model_slots"][1], r["model_slots"][2] = r["model_slots"][2], r["model_slots"][1]
        elif mutation == "wrong_group": r["model_slots"][1]["group"] = "C:1:2"
        elif mutation == "wrong_parent": r["model_slots"][1]["parent_sequence_hash"] = "0"*64
        elif mutation == "wrong_endpoint": r["route"][1]["right_domain_uid"] = "wrong"
        elif mutation == "label": r["label"] = 1
        elif mutation == "extra_feature": f["features"]["0"*64] = "ACD"
        try:
            validate_routes([r], f["features"], f["parents"], vocab)
        except ValueError:
            cases += 1
        else:
            raise AssertionError("Failed to reject " + mutation)
    print(json.dumps(dict(status="ROUTE_INPUT_TESTS_OK", valid_overlap_fixture=True, rejected_mutations=cases)))


if __name__ == "__main__":
    main()
