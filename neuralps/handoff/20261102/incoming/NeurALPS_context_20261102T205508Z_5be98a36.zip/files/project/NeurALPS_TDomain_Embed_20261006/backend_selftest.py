"""Focused CPU fake-model tests; these do not exercise a real ESM-C checkpoint."""
from pathlib import Path
from types import SimpleNamespace
import argparse
import gzip
import tempfile
import torch
import embedding_backend as backend


def run(producer):
    letters = "ACDEFGHIKLMNPQRSTVWY"

    class Tokenizer:
        cls_token_id, eos_token_id = 0, 1

        def convert_ids_to_tokens(self, ids):
            return [letters[int(i) - 3] for i in ids]

        def __call__(self, sequences, **kwargs):
            assert kwargs["padding"] and not kwargs["truncation"] and kwargs["add_special_tokens"]
            width = max(map(len, sequences)) + 2
            ids, masks, specials = [], [], []
            for sequence in sequences:
                padding = width - len(sequence) - 2
                ids.append([0] + [letters.index(aa) + 3 for aa in sequence] + [1] + [2] * padding)
                masks.append([1] * (len(sequence) + 2) + [0] * padding)
                specials.append([1] + [0] * len(sequence) + [1] * (padding + 1))
            result = dict(input_ids=ids, attention_mask=masks, special_tokens_mask=specials)
            return {k: torch.tensor(v) for k, v in result.items()} if kwargs.get("return_tensors") else result

    class Model:
        def __call__(self, input_ids, attention_mask):
            assert not torch.is_grad_enabled(), "Original inference_mode was lost"
            x = input_ids.float().unsqueeze(-1) + torch.arange(backend.DIM).remainder(7) * .25
            x = x.masked_fill((input_ids < 3).unsqueeze(-1), 8192).to(torch.bfloat16)
            return SimpleNamespace(last_hidden_state=x)

    tokenizer = Tokenizer()
    pooled, batch_size = backend._load_original_functions(Path(producer), dict(
        torch=torch, tokenizer=tokenizer, model=Model(), device=torch.device("cpu"), EMBED_DIM=backend.DIM))
    sequences = ["ACD", "YW", "W" * 2046]
    backend._check_tokens(tokenizer, sequences)
    actual = pooled(sequences)
    expected = torch.stack([torch.stack([
        (letters.index(aa) + 3 + torch.arange(backend.DIM).remainder(7) * .25).to(torch.bfloat16).float()
        for aa in seq]).mean(0) for seq in sequences])
    discrepancy = float((actual - expected).abs().max())
    assert actual.dtype == torch.float32 and discrepancy == 0
    rows = backend._validate_rows([(backend._seqsha(s), s) for s in ("ACD", "YW", "A", "C")])
    assert rows == sorted(rows, key=lambda r: (len(r[1]), r[0]))
    for invalid in [[("incorrect", "A")], [(backend._seqsha("A" * 2047), "A" * 2047)],
                    [(backend._seqsha("A"), "A"), (backend._seqsha("A"), "A")]]:
        try:
            backend._validate_rows(invalid)
        except ValueError:
            pass
        else:
            raise AssertionError("Invalid feature input accepted")
    events = []

    def limited(batch):
        if len(batch) > 2:
            raise torch.cuda.OutOfMemoryError("synthetic test OOM")
        return pooled(batch)

    fake_cuda = SimpleNamespace(OutOfMemoryError=torch.cuda.OutOfMemoryError, empty_cache=lambda: None)
    torch_proxy = SimpleNamespace(cuda=fake_cuda, isfinite=torch.isfinite, cat=torch.cat)
    vectors, batches = backend._infer_batches(rows, limited, batch_size, torch_proxy,
                                              events.append, "fake_cpu_test")
    assert vectors.shape == (len(rows), backend.DIM)
    assert sum(b.get("status") == "CUDA_OOM_RETRY" for b in batches) == 1
    assert torch.equal(vectors, pooled([s for _, s in rows]))

    def broken(batch):
        raise RuntimeError("unrelated failure")

    try:
        backend._infer_batches(rows, broken, batch_size, torch_proxy, events.append, "fake_failure")
    except RuntimeError as exc:
        assert str(exc) == "unrelated failure"
    else:
        raise AssertionError("Non-OOM exception was retried or swallowed")
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        directory = root / "results/routeA_esmc600m_embeddings/domains"
        directory.mkdir(parents=True)
        digest = backend._seqsha("ACD")
        with gzip.open(directory / "domains_embedding_index.tsv.gz", "wt") as stream:
            stream.write("sequence_hash\tlength\tshard_index\trow_index\n" + digest + "\t3\t0\t0\n")
        payload = dict(kind="domains", pipeline_version="routeA_esmc600m_v1", model_name="ESMC-600M",
            inference_dtype="bfloat16", storage_dtype="float32", embedding_dimension=backend.DIM,
            pooling=backend.POOLING, sequence_hashes=[digest], lengths=[3],
            embeddings=torch.ones(1, backend.DIM, dtype=torch.float32))
        path = directory / "domains_shard_0000.pt"
        torch.save(payload, path)
        cached, proof = backend._reference_vectors(root, [dict(hash=digest, seq="ACD", length=3)], torch)
        assert torch.equal(cached[digest], payload["embeddings"][0]) and len(proof["source_files_sha256"]) == 2
        payload["pooling"] = "incorrect pooling"
        torch.save(payload, path)
        try:
            backend._reference_vectors(root, [dict(hash=digest, seq="ACD", length=3)], torch)
        except ValueError as exc:
            assert "metadata differs: pooling" in str(exc)
        else:
            raise AssertionError("Wrong historical reference pooling accepted")
    print(backend._json(dict(status="BACKEND_CPU_FAKE_MODEL_SELFTEST_OK", max_pooling_discrepancy=discrepancy,
          tested=["pinned_original_ast", "BF16_hidden_FP32_mean", "special_padding_exclusion",
                  "2046_residue_no_truncation", "hash_length_duplicate_rejection", "deterministic_order",
                  "OOM_only_batch_reduction", "non_OOM_propagation", "historical_reference_metadata_gate"],
          real_checkpoint_inference=False, GPU_inference=False)))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--producer", type=Path, required=True)
    run(parser.parse_args().producer)
