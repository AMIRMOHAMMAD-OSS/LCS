#!/usr/bin/env bash
set -euo pipefail
NRPS_TDE_PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
exec python3 -B - "$NRPS_TDE_PACKAGE" <<'PY'
import json
from pathlib import Path
import shutil
import subprocess
import sys

package = Path(sys.argv[1])
record_path = package / "LAST_JOB.json"
if not record_path.is_file():
    print(f"No embedding job is recorded: {record_path}")
    print(f"Submit with: bash {package / 'submit.sh'}")
    raise SystemExit(0)
try:
    record = json.loads(record_path.read_text(encoding="utf-8"))
    job_id = str(record["job_id"])
    if not job_id.isdecimal():
        raise ValueError("job_id must contain digits only")
    output, log = Path(record["output"]), Path(record["log"])
except (OSError, KeyError, ValueError) as error:
    print(f"Cannot read LAST_JOB.json: {error}", file=sys.stderr)
    raise SystemExit(1)
if shutil.which("sacct"):
    try:
        subprocess.run(["sacct", "-j", job_id, "--format=JobID,JobName%24,State,ExitCode,Elapsed"],
                       check=False, timeout=20)
    except subprocess.TimeoutExpired:
        print("sacct did not answer within 20 seconds.")
else:
    print("sacct is not available on this computer.")
print(f"Job: {job_id}\nOutput: {output}\nLog: {log}", flush=True)
report = next((output / name for name in ("report.json", "summary.json", "fatal_error.json")
               if (output / name).is_file()), None)
if report is not None:
    try:
        result = json.loads(report.read_text(encoding="utf-8"))
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except (OSError, ValueError) as error:
        print(f"Report is not yet readable: {error}")
elif log.is_file():
    with log.open("rb") as handle:
        handle.seek(0, 2)
        handle.seek(max(0, handle.tell() - 32768))
        lines = handle.read().decode("utf-8", errors="replace").splitlines()
    print("\n".join(lines[-35:]))
else:
    print("The job has not created a log or report yet.")
inspection = output / "embedding_inspection.zip"
if inspection.is_file():
    print(f"Inspection: {inspection}")
PY
