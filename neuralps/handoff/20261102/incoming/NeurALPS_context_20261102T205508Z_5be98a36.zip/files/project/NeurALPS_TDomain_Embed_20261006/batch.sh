#!/usr/bin/env bash
# Follow the working A100 + existing esmc_connections_hf environment convention.
set -eo pipefail
NRPS_TDE_PACKAGE="${1:?embedding package directory}"
NRPS_TDE_ROOT="${2:?project directory}"
NRPS_TDE_ANNOTATION="${3:?annotation output directory}"
: "${SLURM_JOB_ID:?This script must run in the submitted Slurm job}"
if [[ ! "$SLURM_JOB_ID" =~ ^[0-9]+$ ]]; then
    printf '%s\n' 'Invalid Slurm job ID.' >&2
    exit 2
fi
NRPS_TDE_OUT="$NRPS_TDE_ROOT/e10_tdomain_embed_$SLURM_JOB_ID"
if [[ -e "$NRPS_TDE_OUT" || -L "$NRPS_TDE_OUT" ]]; then
    printf 'Refusing to overwrite existing embedding output: %s\n' "$NRPS_TDE_OUT" >&2
    exit 1
fi
NRPS_TDE_PY="$NRPS_TDE_ROOT/envs/esmc_connections_hf/bin/python"
NRPS_TDE_ENV="$NRPS_TDE_ROOT/nrps_esmc_environment.sh"
if [[ ! -x "$NRPS_TDE_PY" || ! -r "$NRPS_TDE_ENV" ]]; then
    printf 'Missing existing ESMC environment: %s or %s\n' "$NRPS_TDE_PY" "$NRPS_TDE_ENV" >&2
    exit 1
fi
cd -- "$NRPS_TDE_ROOT"
module purge
module load arch/a100
module load pytorch-gpu/py3/2.8.0
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export TMPDIR="$NRPS_TDE_ROOT/e10_tdomain_embed_tmp_$SLURM_JOB_ID"
mkdir -p -- "$TMPDIR"
export SQLITE_TMPDIR="$TMPDIR"
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
# This existing helper activates the HF environment and its required CUDA setup.
# Preserve its PYTHONPATH and CUDA header settings after sourcing it.
source "$NRPS_TDE_ENV"
"$NRPS_TDE_PY" -B "$NRPS_TDE_PACKAGE/verify.py"
exec "$NRPS_TDE_PY" -u -B "$NRPS_TDE_PACKAGE/run_embeddings.py" \
    --root "$NRPS_TDE_ROOT" --annotation-dir "$NRPS_TDE_ANNOTATION" --out "$NRPS_TDE_OUT"
