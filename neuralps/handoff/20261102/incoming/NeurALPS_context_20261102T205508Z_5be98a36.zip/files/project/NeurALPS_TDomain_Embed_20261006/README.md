# T-domain ESMC embedding stage

Input: the reviewed annotation output `e9_tdomain_annotation_695798`.
It contains 84 engineered constructs, four native controls, 876 domains,
788 covalent boundaries and 290 unique feature sequences. All 1,664 model
slots are observed; no feature exceeds 2,046 amino acids.

This job extracts frozen **ESMC-600M input embeddings only**. It does not run
the NRPS compatibility transformer, train a classifier, update pretrained
weights, fit a reference scale, join activity labels, or compute an AUC.
Successful annotation or embedding does not validate biological compatibility
or domain fault localization.

## Run on Jean Zay

Place this directory beside the existing project packages:

```bash
cd /lustre/fswork/projects/rech/nef/unh87ms/NeurALPSv2
bash NeurALPS_TDomain_Embed_20261006/submit.sh
bash NeurALPS_TDomain_Embed_20261006/status.sh
```

The launcher uses one A100, eight CPUs and a two-hour walltime limit. It uses
`nef@a100`, `gpu_p5`, `qos_gpu_a100-t3`, and no explicit memory options. The
time limit is not an estimate of queue waiting time or runtime. Nothing is
installed or downloaded. The existing `nrps_esmc_environment.sh` and
`envs/esmc_connections_hf/bin/python` supply the runtime.

Each successful submission creates a new output path:
`e10_tdomain_embed_JOBID`, with `e10_tdomain_embed_JOBID.log` beside it.
The log prints checkpoint verification, model loading, reference comparison
and completed batch counts. Existing output paths are never overwritten.

## Input review and preflight

The submitted annotation summary showed all 88 records passing its checks,
with zero holds. The 51/52 historical reference match reproduces the declared
short-thioesterase discrepancy from the annotation package. This is enough
to proceed with feature extraction, not a claim that all boundaries are
experimentally validated.

`CONTRACT.json` pins the six export-file hashes from that actual job, the data
and annotation-queue identities, frozen vocabulary and window rules. It does
not silently accept another annotation run. Before submitting a GPU job,
the code checks exact feature slices against physical parents, slot order,
domain types, covalent window endpoints, target-PCP coordinates, role counts,
inventory counts, and source hashes. Labels are neither read nor inferred.

Only `unique_sequences.fasta.gz` is embedded. The 88 whole physical proteins
in `parents.fasta.gz` are preserved for masking and provenance in the next
stage. They are not embedded as whole proteins or truncated.

## Exact extraction contract

- Local ESMC-600M checkpoint SHA256:
  `e4232c30fd35fe2f57051ec88a703996ac94520580b4b836894207a3d45d9ff8`.
- Transformers 4.57.6, Biohub fork commit
  `ef32577f55da19a4989cd7b22e004dc43a4998cb`.
- The original `src/esmc_routeA_production.py` must match SHA256
  `8948a0c221702e10117162d43fbf1f2caba7901fc5ad96ff37b164d6e18130bd`.
- The original `pooled_batch` and `batch_size_for` function definitions are
  loaded from its AST without executing the original production job.
- Inference is frozen/evaluation-mode BF16; residue means accumulate in
  float32, excluding CLS/EOS/padding. Final dimension is 1,152.
- Inputs are embedded independently, without truncation, normalization,
  centering, module pooling or parent conditioning. Every input is at most
  2,046 residues. Rows sort by sequence length then SHA256.
- The original connection batch caps are retained; CUDA out-of-memory may
  reduce batch size. Such reductions are reported. Other errors stop the job.

The fixed references in the pinned historical
`data/esmc_bode2_domains_v2/manifest.json` are re-embedded and compared with
their original cached domain vectors. The pre-existing provisional numerical
tolerances are cosine >= 0.999 and relative L2 <= 0.02. Failure stops extraction
before any new feature matrix is written. This is an implementation agreement
check, not a biological validation or a claim of bitwise reproducibility.

## Outputs

| File | Purpose |
|---|---|
| `report.json` | Completion status, numerical reference agreement and provenance. |
| `reference_comparison.json` | Per-reference agreement and original cache locations. |
| `features.f32` | 290 x 1152 independent embeddings, little-endian float32. |
| `feature_index.sqlite3` | Sequence hash, length, row and covered status; metadata. |
| `inputs/` | Byte-identical annotated routes, sequences and slot provenance. |
| `annotation/` | Source report, construct metadata and annotation QC. |
| `EMBEDDINGS_COMPLETE` | Written after successful extraction and inspection packaging. |
| `embedding_inspection.zip` | Small review bundle including the new feature matrix. |

This is a separate cache: existing training caches, parent databases and target
means are never changed. The next step is to connect this cache and its physical
parent sequences to frozen 26,000-step compatibility inference. Preserve the
original natural reference scale; any unsupported score groups must remain
explicit rather than being fitted using activity outcomes.

## Local validation limits

`VALIDATION.json` distinguishes local software checks from the GPU run. Local
checks exercise exact source-function extraction, pooling with a fake model,
input coordinate/identity rejection, batch/OOM handling and mocked Slurm
routing. The actual 290 ESMC embeddings and numerical reference comparison
must run on Jean Zay. This package does not claim those results already exist.
