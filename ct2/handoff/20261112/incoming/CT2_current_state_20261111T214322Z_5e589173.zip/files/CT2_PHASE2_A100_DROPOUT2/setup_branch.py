#!/usr/bin/env python3
"""Create a sealed *separate* A100 phase-2 training experiment from a completed CT2 stage-0 run.

CPU-only. Does not modify the original run, its checkpoint or Slurm submissions.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()


def digest(data):
    return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def save_atomic(path, value):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_name(p.name+f'.tmp.{os.getpid()}')
    with temp.open('x') as f:
        json.dump(value,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(temp,p)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--production',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--package',type=Path,default=Path(__file__).resolve().parent)
    a=p.parse_args()
    prod=a.production.resolve();output=a.output.resolve();package=a.package.resolve()
    config_file=prod/'run.json'
    cfg=json.loads(config_file.read_text())
    if cfg.get('fingerprint') != hashlib.sha256(json.dumps({k:v for k,v in cfg.items() if k!='fingerprint'},sort_keys=True).encode()).hexdigest():
        raise ValueError('Original run.json fingerprint invalid')
    if cfg.get('production_revision')!=4 or cfg.get('world_size')!=8 or cfg['stages'][0]['steps']!=40000 or cfg['stages'][1]['steps']!=60000:
        raise ValueError('Expected sealed CT2 v4 eight-rank stage boundary')
    for rel,expected in cfg['hashes'].items():
        path=Path(rel)
        if path.is_absolute() or '..' in path.parts:raise ValueError('Unsafe source hash path')
        if sha(prod/path)!=expected:raise ValueError('Original sealed file changed: '+rel)
    prev=Path(cfg['output'])/'training'/'fullmask512'
    cp=prev/'last.ckpt'
    done=json.loads((prev/'verified_complete.json').read_text())
    complete=json.loads((prev/'completed.json').read_text())
    if (done['fingerprint']!=cfg['fingerprint'] or done['stage']!=0 or
        done['continuation_step']!=40000 or complete['continuation_step']!=40000 or
        complete['fingerprint']!=cfg['fingerprint']):
        raise ValueError('Stage-0 verified-complete provenance mismatch')
    cp_sha=sha(cp)
    if cp_sha!=done['checkpoint_sha256']:raise ValueError('Stage-0 checkpoint hash mismatch')
    if not str(output).startswith('/lustre/fswork/'):
        raise ValueError('Output must be under /lustre/fswork (not scratch)')
    if output==Path(cfg['output']).resolve() or output.is_relative_to(Path(cfg['output']).resolve()):
        raise ValueError('Branch must not write inside original output')
    if output.exists():raise FileExistsError('Refusing to reuse existing branch output: '+str(output))
    files={name:sha(package/name) for name in ('branch_phase2.py','verify_smoke.py','a100_phase2.slurm','setup_branch.py')}
    manifest={
        'schema':1,'description':'CT2 stage-1 A100 experimental continuation with targeted unknown-species dropout intervention',
        'production_root':str(prod),'production_run_sha256':sha(config_file),
        'parent_fingerprint':cfg['fingerprint'],'parent_checkpoint':str(cp),
        'parent_checkpoint_sha256':cp_sha,'parent_verified_complete_sha256':sha(prev/'verified_complete.json'),
        'output':str(output),'package':str(package),'program_hashes':files,
        'world_size':8,'stage':1,'stage_name':'length1024','stage_start':40000,
        'stage_updates':60000,'source_step':cfg['source_step'],
        'intervention':{
            'full_mask_start':0.05,'full_mask_end':0.05,
            'unknown_dropout_start':0.12,'unknown_dropout_end':0.02,
            'ramp_updates':4000,
            'species_embed_scale':0.0347,
            'same_learning_rate_and_length_schedule':True,
            'training_objective':'original CE only; no ranking-loss modification'
        },
        'checkpoint_every':2000,'evaluate_every':1000,
    }
    manifest['fingerprint']=digest(manifest)
    output.mkdir(parents=True)
    (output/'training'/'length1024').mkdir(parents=True)
    (output/'diagnostics').mkdir()
    (package/'logs').mkdir(exist_ok=True)
    save_atomic(output/'branch_manifest.json',manifest)
    print('BRANCH_READY',output)
    print('BRANCH_FINGERPRINT',manifest['fingerprint'])
    print('PARENT_CHECKPOINT_SHA256',cp_sha)
    print('ORIGINAL_PRODUCTION_UNCHANGED',prod)
    print('NEXT: sbatch --test-only --export=ALL '+str(package/'a100_phase2.slurm'))

if __name__=='__main__':main()
