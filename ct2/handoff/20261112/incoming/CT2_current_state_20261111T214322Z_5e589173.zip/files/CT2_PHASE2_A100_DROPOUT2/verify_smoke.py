#!/usr/bin/env python3
"""Read-only eight-rank A100 smoke reference/resume comparison; never stamps the original production run."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from branch_phase2 import load_manifest

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--manifest',type=Path,required=True)
    p.add_argument('--folder',type=Path,required=True)
    a=p.parse_args()
    m=load_manifest(a.manifest)
    sys.path.insert(0,m['production_root'])
    import torch
    from checks import check_checkpoint,equal_tree
    from common import load_run,atomic_json
    cfg=load_run()
    branch_cfg=dict(cfg);branch_cfg['fingerprint']=m['fingerprint']
    hardware=json.loads((a.folder/'hardware'/'hardware_checks.json').read_text())
    names=[r['gpu'] for r in hardware['memory']]
    if not all('A100' in n for n in names):
        raise RuntimeError('Expected eight A100 devices; got '+repr(names))
    if sorted(r['rank'] for r in hardware['memory'])!=list(range(8)):
        raise RuntimeError('Missing GPU rank hardware evidence')
    first=torch.load(a.folder/'reference'/'last.ckpt',map_location='cpu',weights_only=False,mmap=True)
    resumed=torch.load(a.folder/'resumed'/'last.ckpt',map_location='cpu',weights_only=False,mmap=True)
    check_checkpoint(first,branch_cfg,1,32,'smoke-reference')
    check_checkpoint(resumed,branch_cfg,1,32,'smoke-resume')
    equal_tree(first['rank_states'],resumed['rank_states'])
    equal_tree(first['state_dict'],resumed['state_dict'],close=True)
    equal_tree(first['optimizer_states'],resumed['optimizer_states'],close=True)
    for i in (1,3,4,5,6,7):
        if first['statistics']['totals'][i]!=resumed['statistics']['totals'][i]:
            raise ValueError('Training accounting differs at index '+str(i))
    if first['branch']['fingerprint']!=m['fingerprint'] or resumed['branch']!=first['branch']:
        raise ValueError('Smoke branch provenance mismatch')
    record={'fingerprint':m['fingerprint'],'comparisons':'state_dict and AdamW moments within rtol=1e-5/atol=2e-6; streams and RNG exact',
            'updates':32,'resume_boundary':16,'hardware':names,'passed':True}
    atomic_json(a.folder/'smoke_passed.json',record)
    print('A100_PHASE2_SMOKE_PASSED',str(a.folder),flush=True)

if __name__=='__main__':main()
