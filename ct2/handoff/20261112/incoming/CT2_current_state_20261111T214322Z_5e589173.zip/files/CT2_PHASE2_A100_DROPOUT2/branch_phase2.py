#!/usr/bin/env python3
"""Eight-rank CT2 phase-2 experimental continuation from sealed stage-0 checkpoint.

Numerical model, AdamW, streamed dataset, CE and evaluator are imported from the
unaltered reviewed production source. Only the unknown-species dropout schedule
is overridden; full-protein masking follows the original stage-1 schedule. Never writes to the parent training directory.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
import signal
import sys
import time
from pathlib import Path

_STOP=False

def _signal(signum,frame):
    global _STOP
    _STOP=True

def _sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
    return h.hexdigest()

def _fingerprint(doc):
    return hashlib.sha256(json.dumps({k:v for k,v in doc.items() if k!='fingerprint'},
                                      sort_keys=True,separators=(',',':')).encode()).hexdigest()

def load_manifest(path):
    doc=json.loads(Path(path).read_text())
    if doc.get('schema')!=1 or doc.get('fingerprint')!=_fingerprint(doc):
        raise ValueError('Invalid experimental manifest fingerprint')
    package=Path(doc['package'])
    for name,digest in doc['program_hashes'].items():
        if _sha(package/name)!=digest:raise ValueError('Experiment program changed: '+name)
    if doc['world_size']!=8 or doc['stage']!=1 or doc['stage_start']!=40000 or doc['stage_updates']!=60000:
        raise ValueError('Unexpected branch geometry or stage counters')
    s=doc['intervention']
    if s!={'full_mask_start':0.05,'full_mask_end':0.05,
           'unknown_dropout_start':0.12,'unknown_dropout_end':0.02,
           'ramp_updates':4000,'species_embed_scale':0.0347,
           'same_learning_rate_and_length_schedule':True,
           'training_objective':'original CE only; no ranking-loss modification'}:
        raise ValueError('Unexpected intervention specification')
    return doc

def curriculum(step,manifest):
    settings=manifest['intervention']
    p=min(1.0,step/settings['ramp_updates'])
    full=settings['full_mask_start']+p*(settings['full_mask_end']-settings['full_mask_start'])
    drop=settings['unknown_dropout_start']+p*(settings['unknown_dropout_end']-settings['unknown_dropout_start'])
    return full,drop

def _save_checkpoint(path,model,optimizer,names,stream,cfg,step,stats,mode,manifest):
    import torch
    from engine import gather,rank,world,barrier,rng_state,atomic_torch_save
    from execution import assert_profile,PROFILE
    execution=assert_profile(model)
    local={'stream':stream.state_dict(),'rng':rng_state(),'execution_settings':execution}
    states=gather(local)
    if rank()==0:
        total=40000+step
        cp={'ct2_format':1,'fingerprint':manifest['fingerprint'],'mode':mode,'world_size':world(),
            'execution_profile':dict(PROFILE),'execution_settings':execution,
            'state_dict':model.state_dict(),'model_config':model.model.config.to_dict(),
            'species_embed_scale':model.scale,'mapping_sha256':cfg['mapping_sha256'],
            'global_step':cfg['source_step']+total,'continuation_step':total,
            'source_step':cfg['source_step'],'stage':1,'stage_step':step,
            'optimizer_states':[optimizer.state_dict()],'optimizer_parameter_names':names,
            'rank_states':states,'statistics':stats,'schedule':{'stage':1,'completed':step},
            'next_update_controls':'branch_phase2.curriculum + common.controls(1,step)',
            'hyper_parameters':{'species_embed_scale':model.scale,'unknown_species_id':26678,'n_species_total':28678},
            'branch':{'fingerprint':manifest['fingerprint'],
                      'origin_checkpoint_sha256':manifest['parent_checkpoint_sha256'],
                      'intervention':manifest['intervention']}}
        path=Path(path)
        atomic_torch_save(path,cp)
        alias=path.parent/'last.ckpt';tmp=path.parent/f'.last.{os.getpid()}'
        tmp.unlink(missing_ok=True)
        os.link(path,tmp);os.replace(tmp,alias)
    barrier()

def run(args):
    signal.signal(signal.SIGUSR1,_signal)
    signal.signal(signal.SIGTERM,_signal)
    manifest=load_manifest(args.manifest)
    prod=Path(manifest['production_root'])
    sys.path.insert(0,str(prod))
    import torch
    from torch.nn.parallel import DistributedDataParallel
    from common import load_run,controls,batch_profile,atomic_json,stable_seed
    from model_io import tokenizer_at,read_checkpoint,build_model,optimizer_for
    from data_stream import RecordStream
    from augmentation import TrainingCollator
    from engine import initialize,rank,world,barrier,seed_all,restore_rng,optimizer_update,sum_tensor,gather
    from checks import check_checkpoint
    from evaluation import Evaluator
    from execution import assert_profile

    cfg=load_run()
    if (_sha(prod/'run.json')!=manifest['production_run_sha256'] or
        cfg['fingerprint']!=manifest['parent_fingerprint'] or
        cfg['source_step']!=manifest['source_step'] or cfg['world_size']!=8):
        raise ValueError('Parent CT2 configuration no longer matches this experiment')
    branch_cfg=dict(cfg)
    branch_cfg['fingerprint']=manifest['fingerprint']
    branch_cfg['output']=manifest['output']
    device=initialize()
    seed_all(cfg['seed'])
    if rank()==0:
        done_path=Path(cfg['output'])/'training/fullmask512/verified_complete.json'
        if (_sha(done_path)!=manifest['parent_verified_complete_sha256'] or
            _sha(manifest['parent_checkpoint'])!=manifest['parent_checkpoint_sha256']):
            raise ValueError('Parent checkpoint or verified-complete receipt changed')
    barrier()

    out=(Path(args.output) if args.output else
         Path(manifest['output'])/'training'/'length1024')
    if rank()==0:out.mkdir(parents=True,exist_ok=True)
    barrier()
    path=None
    if args.resume=='auto':
        if (out/'last.ckpt').exists():path=out/'last.ckpt'
    elif args.resume:
        path=Path(args.resume)
        if not path.is_file():raise FileNotFoundError(path)
    if path is None and any(out.glob('*.ckpt')):
        raise RuntimeError('Existing checkpoints require an explicit resume; refuse overwriting')
    from_parent=path is None
    checkpoint=read_checkpoint(manifest['parent_checkpoint'] if from_parent else path)
    if from_parent:
        check_checkpoint(checkpoint,cfg,0,40000,'full')
        model_cfg=cfg;done_steps=0
    else:
        done_steps=int(checkpoint['stage_step'])
        check_checkpoint(checkpoint,branch_cfg,1,done_steps)
        if checkpoint.get('branch',{}).get('fingerprint')!=manifest['fingerprint']:
            raise ValueError('Resumed checkpoint is from a different experiment')
        if args.mode=='full' and checkpoint['mode']!='full':
            raise ValueError('Cannot resume experimental production from smoke checkpoint')
        if args.mode=='smoke-resume' and checkpoint['mode'] not in ('smoke-reference','smoke-resume'):
            raise ValueError('Smoke resume must load smoke checkpoint')
        model_cfg=branch_cfg
    if args.mode=='smoke-reference' and not from_parent:
        raise ValueError('Smoke reference must start from original stage-0 checkpoint')
    if args.mode=='smoke-resume' and from_parent:
        raise ValueError('Smoke resume needs the smoke-reference checkpoint')

    tok=tokenizer_at()
    model=build_model(checkpoint,tok,model_cfg,device)
    assert_profile(model)
    opt,names=optimizer_for(model,checkpoint)
    ddp=DistributedDataParallel(model,device_ids=[device.index],broadcast_buffers=False)
    mapping=json.loads(Path(cfg['mapping']).read_text())
    stream=RecordStream([str(Path(cfg['data_root'])/row[0]) for row in cfg['shards']],
                        tok.get_vocab(),mapping,26678,rank(),world(),cfg['seed'],cfg['shuffle_buffer'])
    stream.load_state_dict(checkpoint['rank_states'][rank()]['stream'])
    restore_rng(checkpoint['rank_states'][rank()]['rng'])
    stats=copy.deepcopy(checkpoint['statistics'])
    if from_parent:
        stats['branch_origin']={'parent_fingerprint':cfg['fingerprint'],
                                'parent_checkpoint_sha256':manifest['parent_checkpoint_sha256'],
                                'branch_fingerprint':manifest['fingerprint']}
    else:
        if stats.get('branch_origin',{}).get('branch_fingerprint')!=manifest['fingerprint']:
            raise ValueError('Branch statistics provenance mismatch')
    del checkpoint
    collator=TrainingCollator(tok,26678,cfg['seed'],rank())
    stage=1
    stop=args.stop_after if args.stop_after else manifest['stage_updates']
    if not 0<stop<=manifest['stage_updates'] or done_steps>=stop:
        raise ValueError('Stop limit is already reached or invalid')
    if args.mode=='full' and args.validation_max_length:
        raise ValueError('Full training must preserve the reviewed length ramp')
    evaluator=Evaluator(branch_cfg,tok,root=prod) if args.mode=='full' else None
    total=40000+done_steps
    if evaluator and done_steps==0:
        evaluator.evaluate(model,out,total,'length1024_drop02_v2_entry',long_panels=True)
    deadline=time.monotonic()+args.max_runtime_seconds if args.max_runtime_seconds else None
    if rank()==0:
        print('BRANCH_START',json.dumps({'mode':args.mode,'done':done_steps,'stop':stop,
            'source_checkpoint':str(path or manifest['parent_checkpoint']),
            'branch_fingerprint':manifest['fingerprint']}),flush=True)

    save_every=16 if args.mode!='full' else manifest['checkpoint_every']
    while done_steps<stop:
        tick=time.monotonic()
        length,original_full,lr=controls(1,done_steps,cfg['seed'])
        if args.validation_max_length:length=1024
        full_prob,drop_prob=curriculum(done_steps,manifest)
        if abs(original_full-full_prob)>1e-12:
            raise RuntimeError('The original phase-2 masking schedule has changed; refusing training')
        micro,accumulate=batch_profile(length,cfg['batch_divisor'])
        batches=[]
        for j in range(accumulate):
            records=stream.batch(micro,length)
            batch=collator(records,length,full_prob,total,j)
            # Keep the original independent, stateless species draw, change only its threshold.
            gen=torch.Generator().manual_seed(stable_seed(f'species:{cfg["seed"]}:{rank()}:{total}:{j}'))
            true_species=torch.tensor([r['species_id'] for r in records],dtype=torch.long)
            unknown=torch.rand(true_species.shape,generator=gen)<drop_prob
            batch['species_id']=torch.where(unknown,26678,true_species)
            batch['unknown']=unknown
            batches.append(batch)
        metrics,norm=optimizer_update(ddp,opt,batches,device,lr)
        assert_profile(model)
        del batches
        done_steps+=1;total+=1
        stats['active_seconds']+=time.monotonic()-tick
        stats['totals']=[a+b for a,b in zip(stats['totals'],metrics)]
        stats['grad_norms'].append(norm)
        local_stop=int(_STOP or (deadline is not None and time.monotonic()>=deadline))
        stopping=bool(sum_tensor(torch.tensor(local_stop,dtype=torch.int64,device=device)).item()) and done_steps<stop
        if rank()==0 and (done_steps==1 or done_steps%50==0 or stopping):
            print('CT2_TRAIN',json.dumps({'stage':'length1024_drop02_v2','stage_step':done_steps,
                'continuation_step':total,'source_plus_updates':cfg['source_step']+total,
                'length':length,'full_mask_probability':full_prob,'unknown_species_probability':drop_prob,
                'lr':lr,'microbatch':micro,'accumulation':accumulate,'grad_preclip':norm,
                'mlm_loss':metrics[0]/metrics[1] if metrics[1] else None,
                'full_mask_loss':metrics[2]/metrics[3] if metrics[3] else None,
                'global_draws':int(stats['totals'][4]),'valid_tokens':int(stats['totals'][5]),
                'update_seconds':time.monotonic()-tick}),flush=True)
        if evaluator and not stopping and (done_steps%manifest['evaluate_every']==0 or done_steps==stop):
            evaluator.evaluate(model,out,total,'length1024_drop02_v2',long_panels=True)
        if (done_steps%save_every==0 or done_steps==stop or stopping):
            if stream.counts['accepted']!=192*total:
                raise RuntimeError('Data-stream accepted count differs from optimizer update accounting')
            _save_checkpoint(out/f'step_{total:06d}.ckpt',model,opt,names,stream,cfg,
                             done_steps,stats,args.mode,manifest)
            audit=gather(stream.summary())
            if rank()==0:
                atomic_json(out/'data_audit.json',{'fingerprint':manifest['fingerprint'],
                                                  'continuation_step':total,'ranks':audit})
                atomic_json(out/'progress.json',{'fingerprint':manifest['fingerprint'],
                    'stage_step':done_steps,'continuation_step':total,'job_id':os.environ.get('SLURM_JOB_ID'),
                    'stopped_by_signal':bool(stopping),'branch':manifest['intervention']})
        if stopping:
            if rank()==0:print('BRANCH_PAUSED',str(out/'last.ckpt'),flush=True)
            barrier()
            return
    if rank()==0:
        atomic_json(out/'completed.json',{'fingerprint':manifest['fingerprint'],
                    'stage':1,'stage_step':done_steps,'continuation_step':total,'mode':args.mode,
                    'branch':manifest['intervention']})
        print('BRANCH_STAGE_COMPLETE',args.mode,done_steps,flush=True)
    barrier()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',type=Path,required=True)
    p.add_argument('--mode',required=True,choices=['full','smoke-reference','smoke-resume'])
    p.add_argument('--resume',help='auto or a specific checkpoint')
    p.add_argument('--output',type=Path)
    p.add_argument('--stop-after',type=int)
    p.add_argument('--checkpoint-interval',type=int,default=0) # reserved for backward CLI compatibility
    p.add_argument('--validation-max-length',action='store_true')
    p.add_argument('--max-runtime-seconds',type=float,default=0)
    a=p.parse_args()
    if a.checkpoint_interval:
        raise ValueError('Checkpoint schedule is fixed by sealed experiment manifest')
    if a.max_runtime_seconds<0:raise ValueError('Invalid deadline')
    run(a)
if __name__=='__main__':main()
