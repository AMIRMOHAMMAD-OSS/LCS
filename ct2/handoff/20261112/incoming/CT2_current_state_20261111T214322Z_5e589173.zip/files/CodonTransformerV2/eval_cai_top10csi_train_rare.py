"""
CAI-top10CSI-train with rare-mode filtering.

Reuses the existing reference-gene parquet cache. Rare-mode filtering applies
only at the CAI-weight-building stage (excludes codon contributions for triples
flagged as rare by the same convention as eval_minmax_ct2_stages.py).
"""

import argparse
import math
from collections import defaultdict
from pathlib import Path
import multiprocessing as mp

import numpy as np
import pandas as pd
from tqdm import tqdm


GENETIC_CODE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

SYNONYMOUS_CODONS = defaultdict(list)
for codon, aa in GENETIC_CODE.items():
    if aa != "*":
        SYNONYMOUS_CODONS[aa].append(codon)

G_CAI_WEIGHTS = None
G_RARE_MODE = None


def clean_dna(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def iter_codons(seq):
    seq = clean_dna(seq)
    for i in range(0, len(seq) - 2, 3):
        codon = seq[i:i+3]
        if len(codon) != 3 or any(c not in "ACGT" for c in codon):
            continue
        aa = GENETIC_CODE.get(codon)
        if aa is None or aa == "*":
            continue
        yield aa, codon


def build_rare_mask(codon_table_path, rare_mode):
    if rare_mode == "all":
        return set()

    if rare_mode == "no_rare_0_001":
        col = "rare_lt_0_001"
    elif rare_mode == "no_rare_0_01":
        col = "rare_lt_0_01"
    else:
        raise ValueError(f"Unknown rare_mode: {rare_mode}")

    freq = pd.read_parquet(codon_table_path)
    if col not in freq.columns:
        raise SystemExit(
            f"Codon table is missing required rare-mode flag column '{col}'. "
            f"Have: {list(freq.columns)}"
        )

    rare = freq[freq[col]]
    excluded = {
        (str(r.species), str(r.aa), str(r.codon))
        for r in rare.itertuples(index=False)
    }
    print(f"rare_mode={rare_mode}: {len(excluded):,} (species, aa, codon) triples excluded",
          flush=True)
    return excluded


def build_cai_weights(top_ref, pseudocount, excluded_codons):
    counts = defaultdict(float)
    species_set = sorted(top_ref["species"].astype(str).unique())

    for species in species_set:
        for aa, codons in SYNONYMOUS_CODONS.items():
            for codon in codons:
                key = (species, aa, codon)
                if key in excluded_codons:
                    continue
                counts[key] += pseudocount

    for r in tqdm(top_ref.itertuples(index=False), total=len(top_ref),
                  desc="counting top10CSI reference codons"):
        species = str(r.species)
        for aa, codon in iter_codons(r.dna):
            key = (species, aa, codon)
            if key in excluded_codons:
                continue
            counts[key] += 1.0

    max_by_species_aa = defaultdict(float)
    for (species, aa, codon), count in counts.items():
        if count > max_by_species_aa[(species, aa)]:
            max_by_species_aa[(species, aa)] = count

    weights = {}
    for key, count in counts.items():
        species, aa, codon = key
        mx = max_by_species_aa[(species, aa)]
        if mx > 0:
            weights[key] = count / mx

    return weights


def cai_score(seq, species, weights):
    logs = []
    total = 0
    missing = 0

    for aa, codon in iter_codons(seq):
        total += 1
        w = weights.get((species, aa, codon))
        if w is None or w <= 0:
            missing += 1
            continue
        logs.append(math.log(w))

    if not logs:
        return np.nan, total, missing

    return float(math.exp(sum(logs) / len(logs))), total, missing


def init_cai_worker(cai_weights, rare_mode):
    global G_CAI_WEIGHTS, G_RARE_MODE
    G_CAI_WEIGHTS = cai_weights
    G_RARE_MODE = rare_mode


def score_prediction_row(rec):
    species = str(rec["species"])
    score, total, missing = cai_score(rec["pred_dna"], species, G_CAI_WEIGHTS)

    return {
        "rare_mode": G_RARE_MODE,
        "model": rec["model"],
        "eval_id": rec["eval_id"],
        "species": species,
        "bucket": rec.get("bucket", ""),
        "protein_len": rec.get("protein_len", np.nan),
        "cai_top10csi_train": score,
        "codons_total": total,
        "codons_missing_weight": missing,
        "missing_weight_frac": missing / max(total, 1),
    }


def score_predictions_parallel(pred, cai_weights, rare_mode, workers, chunksize):
    records = pred.to_dict(orient="records")
    rows = []

    with mp.Pool(
        processes=workers,
        initializer=init_cai_worker,
        initargs=(cai_weights, rare_mode),
    ) as pool:
        for row in tqdm(
            pool.imap(score_prediction_row, records, chunksize=chunksize),
            total=len(records),
            desc=f"scoring CAI-top10CSI-train [{rare_mode}]",
        ):
            rows.append(row)

    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--reference_genes", required=True)
    ap.add_argument("--out_prefix", required=True)
    ap.add_argument("--rare_mode", choices=["all", "no_rare_0_001", "no_rare_0_01"], required=True)
    ap.add_argument("--pseudocount", type=float, default=1.0)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--score_chunksize", type=int, default=200)
    args = ap.parse_args()

    print(f"=== CAI-top10CSI-train --- rare_mode={args.rare_mode} ===", flush=True)

    pred = pd.read_csv(args.predictions, low_memory=False)
    pred = pred[pred["pred_dna"].fillna("").astype(str).str.len() > 0].copy()

    print("prediction rows:", len(pred), flush=True)
    print("models:", pred["model"].nunique(), flush=True)
    print("workers:", args.workers, flush=True)
    print("pseudocount:", args.pseudocount, flush=True)

    top_ref_path = Path(args.reference_genes)
    if not top_ref_path.exists():
        raise SystemExit(f"Reference-genes parquet not found: {top_ref_path}")
    top_ref = pd.read_parquet(top_ref_path)
    print("reference genes:", len(top_ref), flush=True)
    print("reference species:", top_ref["species"].nunique(), flush=True)

    excluded_codons = build_rare_mask(args.codon_table, args.rare_mode)
    cai_weights = build_cai_weights(top_ref, args.pseudocount, excluded_codons)
    print("CAI weight entries:", len(cai_weights), flush=True)

    out = score_predictions_parallel(pred, cai_weights, args.rare_mode,
                                     args.workers, args.score_chunksize)
    out.to_csv(f"{args.out_prefix}_{args.rare_mode}_by_sequence.csv", index=False)

    summary = (
        out.groupby(["rare_mode", "model"], as_index=False)
        .agg(
            n=("eval_id", "count"),
            cai_top10csi_train=("cai_top10csi_train", "mean"),
            missing_weight_frac=("missing_weight_frac", "mean"),
        )
    )
    summary.to_csv(f"{args.out_prefix}_{args.rare_mode}_summary_by_model.csv", index=False)

    print(f"\n=== CAI-top10CSI-train summary ({args.rare_mode}) ===", flush=True)
    print(summary.to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
