CT2 train-derived clean codon usage table path:

/lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2/ct2_codon_usage_tables_qc/ct2_train_species_codon_frequencies_clean.parquet

Use this for:
- CSI own species
- CSI wrong species
- MinMax
- rare-codon filtered CSI/MinMax

Rare flags included:
- rare_lt_0_001
- rare_lt_0_01
