import json
import csv
from pathlib import Path
from collections import defaultdict

TEST_DIR = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/test_set")
OUT = Path("eval_testset_length_summary.csv")

def iter_records(path):
    text = path.read_text(errors="ignore").strip()
    if not text:
        return
    if path.suffix == ".jsonl":
        for line in text.splitlines():
            line = line.strip()
            if line:
                yield json.loads(line)
        return

    obj = json.loads(text)
    if isinstance(obj, list):
        for x in obj:
            yield x
    elif isinstance(obj, dict):
        for key in ["genes", "records", "data", "items", "examples"]:
            if key in obj and isinstance(obj[key], list):
                for x in obj[key]:
                    yield x
                return
        yield obj

def get_len(r):
    prot = r.get("protein_sequence") or r.get("protein") or r.get("aa_sequence") or ""
    dna = r.get("dna_sequence") or r.get("cds") or r.get("sequence") or ""
    if prot:
        return len(prot), "protein"
    if dna:
        return len(dna) // 3, "dna_codons"
    return 0, "unknown"

def bucket(n):
    if n <= 512:
        return "<=512"
    if n <= 1024:
        return "513-1024"
    if n <= 2048:
        return "1025-2048"
    return ">2048"

summary = defaultdict(lambda: {"n":0, "sum_len":0, "max_len":0})
files = sorted(TEST_DIR.glob("*.json")) + sorted(TEST_DIR.glob("*.jsonl"))

for p in files:
    species_from_file = p.stem
    for r in iter_records(p):
        species = r.get("species") or r.get("organism") or species_from_file
        n, source = get_len(r)
        b = bucket(n)
        key = (species, b)
        summary[key]["n"] += 1
        summary[key]["sum_len"] += n
        summary[key]["max_len"] = max(summary[key]["max_len"], n)

with OUT.open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["species", "bucket", "n", "avg_len", "max_len"])
    for (species, b), s in sorted(summary.items(), key=lambda x: (x[0][0], x[0][1])):
        avg = s["sum_len"] / s["n"] if s["n"] else 0
        w.writerow([species, b, s["n"], round(avg, 2), s["max_len"]])

print("wrote", OUT)
print()
global_summary = defaultdict(int)
for (_, b), s in summary.items():
    global_summary[b] += s["n"]

print("GLOBAL LENGTH BUCKETS")
for b in ["<=512", "513-1024", "1025-2048", ">2048"]:
    print(b, global_summary[b])
