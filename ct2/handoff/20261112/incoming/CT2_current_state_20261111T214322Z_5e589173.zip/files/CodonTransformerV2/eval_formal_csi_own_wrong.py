import argparse
import hashlib
import math
import multiprocessing as mp

import numpy as np
import pandas as pd
from tqdm import tqdm


GENETIC_CODE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

G_WEIGHT = None
G_SPECIES = None
G_WRONG_N = None


def clean_dna(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def stable_wrong_species(target, all_species, n):
    pool = [s for s in all_species if s != target]
    seed = int(hashlib.md5(str(target).encode()).hexdigest()[:8], 16)
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(pool), size=min(n, len(pool)), replace=False)
    return [pool[i] for i in idx]


def build_formal_csi_weights(freq_df):
    max_freq = (
        freq_df.groupby(["species", "aa"], as_index=False)["frequency"]
        .max()
        .rename(columns={"frequency": "max_frequency"})
    )
    use = freq_df.merge(max_freq, on=["species", "aa"], how="left")
    use["weight"] = use["frequency"] / use["max_frequency"]

    lookup = {}
    for r in tqdm(use.itertuples(index=False), total=len(use), desc="building formal CSI weights"):
        lookup[(str(r.species), str(r.aa), str(r.codon))] = float(r.weight)
    return lookup


def formal_csi(seq, species):
    seq = clean_dna(seq)
    logs = []
    total = 0
    missing = 0

    for i in range(0, len(seq) - 2, 3):
        codon = seq[i:i+3]
        if len(codon) != 3 or any(c not in "ACGT" for c in codon):
            continue

        aa = GENETIC_CODE.get(codon)
        if aa is None or aa == "*":
            continue

        total += 1
        w = G_WEIGHT.get((species, aa, codon))
        if w is None or w <= 0:
            missing += 1
            continue

        logs.append(math.log(w))

    if not logs:
        return np.nan, total, missing

    return float(math.exp(sum(logs) / len(logs))), total, missing


def init_worker(weight_lookup, species_list, wrong_n):
    global G_WEIGHT, G_SPECIES, G_WRONG_N
    G_WEIGHT = weight_lookup
    G_SPECIES = species_list
    G_WRONG_N = wrong_n


def score_row(item):
    idx, r = item
    model = str(r["model"])
    species = str(r["species"])
    pred_dna = r["pred_dna"]

    own, total, missing = formal_csi(pred_dna, species)

    wrong_vals = []
    for ws in stable_wrong_species(species, G_SPECIES, G_WRONG_N):
        v, _, _ = formal_csi(pred_dna, ws)
        if not pd.isna(v):
            wrong_vals.append(v)

    wrong_mean = float(np.mean(wrong_vals)) if wrong_vals else np.nan

    ratio = own / wrong_mean if own > 0 and wrong_mean > 0 else np.nan
    delta_log = math.log(own) - math.log(wrong_mean) if own > 0 and wrong_mean > 0 else np.nan

    return {
        "row_id": idx,
        "model": model,
        "species": species,
        "bucket": r.get("bucket", ""),
        "protein_len": r.get("protein_len", np.nan),
        "formal_csi_own": own,
        "formal_csi_wrong_mean": wrong_mean,
        "ratio_formal_csi_own_over_wrong": ratio,
        "delta_log_formal_csi_own_minus_wrong": delta_log,
        "codons_total": total,
        "codons_missing_weight": missing,
        "missing_weight_frac": missing / max(total, 1),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--out_prefix", required=True)
    ap.add_argument("--wrong_n", type=int, default=5)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--chunksize", type=int, default=100)
    args = ap.parse_args()

    pred = pd.read_csv(args.predictions, low_memory=False)
    pred = pred[pred["pred_dna"].fillna("").astype(str).str.len() > 0].copy()

    freq = pd.read_parquet(args.codon_table)
    species_list = sorted(freq["species"].dropna().astype(str).unique())

    print("prediction rows:", len(pred))
    print("models:", pred["model"].nunique())
    print("codon-table species:", len(species_list))

    weight_lookup = build_formal_csi_weights(freq)
    records = list(pred.to_dict(orient="index").items())

    with mp.Pool(
        processes=args.workers,
        initializer=init_worker,
        initargs=(weight_lookup, species_list, args.wrong_n),
    ) as pool:
        rows = list(
            tqdm(
                pool.imap(score_row, records, chunksize=args.chunksize),
                total=len(records),
                desc="formal CSI own/wrong",
            )
        )

    out = pd.DataFrame(rows)
    out.to_csv(f"{args.out_prefix}_by_sequence.csv", index=False)

    summary = (
        out.groupby("model", as_index=False)
        .agg(
            n=("row_id", "count"),
            formal_csi_own=("formal_csi_own", "mean"),
            formal_csi_wrong_mean=("formal_csi_wrong_mean", "mean"),
            ratio_formal_csi_own_over_wrong=("ratio_formal_csi_own_over_wrong", "mean"),
            delta_log_formal_csi_own_minus_wrong=("delta_log_formal_csi_own_minus_wrong", "mean"),
            missing_weight_frac=("missing_weight_frac", "mean"),
        )
    )

    summary.to_csv(f"{args.out_prefix}_summary_by_model.csv", index=False)

    print("\n=== FORMAL CSI SUMMARY ===")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
