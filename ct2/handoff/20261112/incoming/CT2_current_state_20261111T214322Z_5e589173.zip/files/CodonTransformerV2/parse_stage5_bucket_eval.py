from pathlib import Path
import re
import pandas as pd

inp = Path("eval_stage5_epoch3_fullmask_buckets_1076759.txt")
txt = inp.read_text(errors="ignore")

bucket_re = re.compile(
    r"MODEL=stage5_epoch3 BUCKET=(\S+).*?"
    r"│\s+test_acc\s+│\s+([0-9.]+)\s+│.*?"
    r"│\s+test_acc_correct\s+│\s+([0-9.]+)\s+│.*?"
    r"│\s+test_acc_unknown\s+│\s+([0-9.]+)\s+│.*?"
    r"│\s+test_acc_wrong\s+│\s+([0-9.]+)\s+│.*?"
    r"│\s+test_delta_unk\s+│\s+([-0-9.eE]+)\s+│.*?"
    r"│\s+test_delta_wrong\s+│\s+([-0-9.eE]+)\s+│.*?"
    r"│\s+test_loss\s+│\s+([0-9.]+)\s+│.*?"
    r"│\s+test_loss_correct\s+│\s+([0-9.]+)\s+│.*?"
    r"│\s+test_loss_unknown\s+│\s+([0-9.]+)\s+│.*?"
    r"│\s+test_loss_wrong\s+│\s+([0-9.]+)\s+│.*?"
    r"│\s+test_syn_acc\s+│\s+([0-9.]+)\s+│.*?"
    r"│\s+test_top5_acc\s+│\s+([0-9.]+)\s+│.*?"
    r"│\s+test_top5_acc_correct\s+│\s+([0-9.]+)\s+│.*?"
    r"│\s+test_top5_acc_unknown\s+│\s+([0-9.]+)\s+│.*?"
    r"│\s+test_top5_acc_wrong\s+│\s+([0-9.]+)\s+│",
    re.S,
)

rows = []
for m in bucket_re.finditer(txt):
    vals = m.groups()
    bucket = vals[0]
    nums = list(map(float, vals[1:]))
    row = {
        "model": "stage5_epoch3",
        "bucket": bucket,
        "test_acc": nums[0],
        "test_acc_correct": nums[1],
        "test_acc_unknown": nums[2],
        "test_acc_wrong": nums[3],
        "test_delta_unk": nums[4],
        "test_delta_wrong": nums[5],
        "test_loss": nums[6],
        "test_loss_correct": nums[7],
        "test_loss_unknown": nums[8],
        "test_loss_wrong": nums[9],
        "test_syn_acc": nums[10],
        "test_top5_acc": nums[11],
        "test_top5_acc_correct": nums[12],
        "test_top5_acc_unknown": nums[13],
        "test_top5_acc_wrong": nums[14],
    }
    row["acc_correct_minus_unknown"] = row["test_acc_correct"] - row["test_acc_unknown"]
    row["top5_correct_minus_unknown"] = row["test_top5_acc_correct"] - row["test_top5_acc_unknown"]
    rows.append(row)

df = pd.DataFrame(rows)
out = Path("eval_stage5_epoch3_fullmask_buckets_1076759.csv")
df.to_csv(out, index=False)

print(df.to_string(index=False))
print()
print("wrote", out)
