import json
import tarfile
import csv
import math
from pathlib import Path
from collections import Counter, defaultdict

import numpy as np
import pandas as pd

try:
    from tqdm import tqdm
except Exception:
    tqdm = None

TRAIN_DIR = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/train_set_shard")
TEST_DIR = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/test_set")

OUTDIR = Path("ct2_length_distribution_report")
OUTDIR.mkdir(exist_ok=True)

BUCKETS = [
    ("<=128", lambda x: x <= 128),
    ("129-256", lambda x: 128 < x <= 256),
    ("257-512", lambda x: 256 < x <= 512),
    ("513-1024", lambda x: 512 < x <= 1024),
    ("1025-2048", lambda x: 1024 < x <= 2048),
    (">2048", lambda x: x > 2048),
]

PERCENTILES = [0, 1, 5, 10, 25, 50, 75, 90, 95, 99, 99.5, 99.9, 100]


def get_protein_len_from_record(r):
    protein = (
        r.get("protein_sequence")
        or r.get("protein")
        or r.get("aa_sequence")
        or ""
    )
    dna = (
        r.get("dna_sequence")
        or r.get("dna")
        or r.get("cds")
        or r.get("sequence")
        or ""
    )

    if protein:
        return len(str(protein).rstrip("*_")), "protein"
    if dna:
        return len(str(dna)) // 3, "dna_codons"

    return None, "missing"


def update_species_counter(counter, species, length):
    if species is None:
        species = "UNKNOWN"
    counter[str(species)].append(length)


def iter_test_records(test_dir):
    files = sorted(test_dir.glob("*.json"))
    iterator = tqdm(files, desc="Scanning TEST json files", unit="file") if tqdm else files
    for fp in iterator:
        try:
            obj = json.loads(fp.read_text(errors="ignore"))
        except Exception as e:
            print("BAD TEST JSON", fp, repr(e), flush=True)
            continue

        species = None
        genome_id = fp.stem

        if isinstance(obj, dict):
            species = obj.get("species")
            genome_id = obj.get("genome_id", genome_id)
            genes = obj.get("genes") or obj.get("records") or obj.get("data") or obj.get("items") or obj.get("examples")
            if isinstance(genes, list):
                for g in genes:
                    if isinstance(g, dict):
                        yield {
                            "source_file": fp.name,
                            "genome_id": genome_id,
                            "species": species,
                            "record": g,
                        }
            else:
                yield {
                    "source_file": fp.name,
                    "genome_id": genome_id,
                    "species": species,
                    "record": obj,
                }

        elif isinstance(obj, list):
            for g in obj:
                if isinstance(g, dict):
                    yield {
                        "source_file": fp.name,
                        "genome_id": genome_id,
                        "species": g.get("species"),
                        "record": g,
                    }


def parse_json_bytes(raw):
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", errors="ignore")
    raw = raw.strip()
    if not raw:
        return []

    try:
        obj = json.loads(raw)
    except Exception:
        return []

    if isinstance(obj, dict):
        # Normal WebDataset sample: one record
        if "genes" in obj and isinstance(obj["genes"], list):
            # If a whole organism was stored in a shard
            out = []
            species = obj.get("species")
            genome_id = obj.get("genome_id")
            for g in obj["genes"]:
                if isinstance(g, dict):
                    gg = dict(g)
                    gg.setdefault("species", species)
                    gg.setdefault("genome_id", genome_id)
                    out.append(gg)
            return out
        return [obj]

    if isinstance(obj, list):
        return [x for x in obj if isinstance(x, dict)]

    return []


def iter_train_records(train_dir):
    shards = sorted(train_dir.glob("*.tar")) + sorted(train_dir.glob("*.tar.gz")) + sorted(train_dir.glob("*.tgz"))
    print("train shards:", len(shards), flush=True)

    shard_iter = tqdm(shards, desc="Scanning TRAIN shards", unit="shard") if tqdm else shards

    for si, shard in enumerate(shard_iter, 1):
        if tqdm is None and si % 100 == 0:
            print(f"train shard {si}/{len(shards)}: {shard.name}", flush=True)

        try:
            with tarfile.open(shard, "r:*") as tar:
                for member in tar:
                    if not member.isfile():
                        continue

                    name = member.name.lower()
                    if not (name.endswith(".json") or name.endswith(".jsonl")):
                        continue

                    f = tar.extractfile(member)
                    if f is None:
                        continue

                    raw = f.read()

                    if name.endswith(".jsonl"):
                        for line in raw.decode("utf-8", errors="ignore").splitlines():
                            for rec in parse_json_bytes(line):
                                yield {
                                    "source_file": shard.name,
                                    "record": rec,
                                }
                    else:
                        for rec in parse_json_bytes(raw):
                            yield {
                                "source_file": shard.name,
                                "record": rec,
                            }

        except Exception as e:
            print("BAD TRAIN SHARD", shard, repr(e), flush=True)


def summarize_lengths(lengths, name):
    arr = np.asarray(lengths, dtype=np.float64)

    if arr.size == 0:
        return pd.DataFrame([{"dataset": name, "n": 0}])

    row = {
        "dataset": name,
        "n": int(arr.size),
        "min": int(np.min(arr)),
        "max": int(np.max(arr)),
        "mean": float(np.mean(arr)),
        "std": float(np.std(arr)),
    }

    for p in PERCENTILES:
        key = f"p{str(p).replace('.', '_')}"
        row[key] = float(np.percentile(arr, p))

    return pd.DataFrame([row])


def bucket_table(lengths, name):
    rows = []
    n_total = len(lengths)

    for bucket, fn in BUCKETS:
        n = sum(1 for x in lengths if fn(x))
        rows.append({
            "dataset": name,
            "bucket": bucket,
            "n": n,
            "fraction": n / n_total if n_total else math.nan,
        })

    return pd.DataFrame(rows)


def species_summary(species_to_lengths, dataset):
    rows = []
    for species, vals in species_to_lengths.items():
        arr = np.asarray(vals, dtype=np.float64)
        rows.append({
            "dataset": dataset,
            "species": species,
            "n": int(arr.size),
            "min": int(np.min(arr)),
            "max": int(np.max(arr)),
            "mean": float(np.mean(arr)),
            "p50": float(np.percentile(arr, 50)),
            "p90": float(np.percentile(arr, 90)),
            "p95": float(np.percentile(arr, 95)),
            "p99": float(np.percentile(arr, 99)),
            "n_gt2048": int(np.sum(arr > 2048)),
            "frac_gt2048": float(np.mean(arr > 2048)),
        })
    return pd.DataFrame(rows).sort_values(["dataset", "n"], ascending=[True, False])


def collect_test():
    lengths = []
    source_counter = Counter()
    species_to_lengths = defaultdict(list)
    source_type_counter = Counter()

    for item in iter_test_records(TEST_DIR):
        r = item["record"]
        length, source_type = get_protein_len_from_record(r)
        source_type_counter[source_type] += 1

        if length is None:
            continue

        lengths.append(length)
        source_counter[item["source_file"]] += 1
        update_species_counter(species_to_lengths, item.get("species"), length)

    return lengths, species_to_lengths, source_type_counter


def collect_train():
    lengths = []
    species_to_lengths = defaultdict(list)
    source_type_counter = Counter()
    n_seen = 0

    for item in iter_train_records(TRAIN_DIR):
        r = item["record"]
        length, source_type = get_protein_len_from_record(r)
        source_type_counter[source_type] += 1
        n_seen += 1

        if n_seen % 100_000 == 0:
            if tqdm is not None:
                # Show counters in the active shard progress bar.
                try:
                    shard_iter.set_postfix(records=f"{n_seen:,}", valid=f"{len(lengths):,}")
                except Exception:
                    pass
            else:
                print(f"train records seen: {n_seen:,}; valid lengths: {len(lengths):,}", flush=True)

        if length is None:
            continue

        lengths.append(length)
        update_species_counter(species_to_lengths, r.get("species"), length)

    return lengths, species_to_lengths, source_type_counter


def main():
    all_summaries = []
    all_buckets = []
    all_species = []

    print("Collecting TEST lengths...", flush=True)
    test_lengths, test_species, test_source_types = collect_test()
    print("test n:", len(test_lengths), flush=True)
    print("test source types:", dict(test_source_types), flush=True)

    all_summaries.append(summarize_lengths(test_lengths, "test"))
    all_buckets.append(bucket_table(test_lengths, "test"))
    all_species.append(species_summary(test_species, "test"))

    pd.DataFrame({"protein_length": test_lengths}).to_csv(
        OUTDIR / "ct2_test_protein_lengths_raw.csv",
        index=False,
    )

    print("Collecting TRAIN lengths...", flush=True)
    train_lengths, train_species, train_source_types = collect_train()
    print("train n:", len(train_lengths), flush=True)
    print("train source types:", dict(train_source_types), flush=True)

    all_summaries.append(summarize_lengths(train_lengths, "train"))
    all_buckets.append(bucket_table(train_lengths, "train"))
    all_species.append(species_summary(train_species, "train"))

    # Raw train lengths can be large but still manageable as one integer column.
    pd.DataFrame({"protein_length": train_lengths}).to_csv(
        OUTDIR / "ct2_train_protein_lengths_raw.csv",
        index=False,
    )

    summary = pd.concat(all_summaries, ignore_index=True)
    buckets = pd.concat(all_buckets, ignore_index=True)
    species = pd.concat(all_species, ignore_index=True)

    summary.to_csv(OUTDIR / "ct2_length_summary_train_test.csv", index=False)
    buckets.to_csv(OUTDIR / "ct2_length_buckets_train_test.csv", index=False)
    species.to_csv(OUTDIR / "ct2_length_species_summary_train_test.csv", index=False)

    print()
    print("SUMMARY")
    print(summary.to_string(index=False))

    print()
    print("BUCKETS")
    print(buckets.to_string(index=False))

    print()
    print("WROTE")
    for p in sorted(OUTDIR.glob("*.csv")):
        print(p)


if __name__ == "__main__":
    main()
