import argparse
import hashlib
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm


GENETIC_CODE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

AA_TO_CODONS = {}
for codon, aa in GENETIC_CODE.items():
    if aa == "*":
        continue
    AA_TO_CODONS.setdefault(aa, []).append(codon)


def clean_protein(x):
    return str(x).strip().upper().rstrip("*_")


def normalize_dna(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def gc3_content(seq):
    seq = normalize_dna(seq)
    codons = [seq[i:i+3] for i in range(0, len(seq)-2, 3)]
    if not codons:
        return np.nan
    third = [c[2] for c in codons if len(c) == 3]
    return sum(1 for x in third if x in "GC") / len(third)


def codon_recovery(native, pred):
    native = normalize_dna(native)
    pred = normalize_dna(pred)
    n = min(len(native), len(pred)) // 3
    if n == 0:
        return np.nan
    return sum(native[3*i:3*i+3] == pred[3*i:3*i+3] for i in range(n)) / n


def nt_identity(native, pred):
    native = normalize_dna(native)
    pred = normalize_dna(pred)
    n = min(len(native), len(pred))
    if n == 0:
        return np.nan
    return sum(a == b for a, b in zip(native[:n], pred[:n])) / n


def length_bucket(protein_len):
    protein_len = int(protein_len)
    if protein_len <= 512:
        return "<=512"
    if protein_len <= 1024:
        return "513-1024"
    if protein_len <= 2048:
        return "1025-2048"
    return ">2048"


def stable_rng(*parts):
    key = "|".join(map(str, parts))
    h = hashlib.md5(key.encode("utf-8")).hexdigest()
    seed = int(h[:8], 16)
    return np.random.default_rng(seed)


def build_species_aa_tables(freq_df):
    hfc = {}
    bfc = {}

    for (species, aa), g in tqdm(freq_df.groupby(["species", "aa"]), desc="building codon choice tables"):
        g = g.sort_values("frequency", ascending=False)
        hfc[(species, aa)] = str(g.iloc[0]["codon"])

        codons = g["codon"].astype(str).tolist()
        probs = g["frequency"].astype(float).to_numpy()
        probs = probs / probs.sum()
        bfc[(species, aa)] = (codons, probs)

    return hfc, bfc


def generate_hfc(protein, species, hfc):
    out = []
    for aa in clean_protein(protein):
        codon = hfc.get((species, aa))
        if codon is None:
            codon = AA_TO_CODONS.get(aa, ["NNN"])[0]
        out.append(codon)
    return "".join(out)


def generate_bfc(protein, species, bfc, row_id):
    rng = stable_rng("bfc", species, row_id)
    out = []
    for aa in clean_protein(protein):
        item = bfc.get((species, aa))
        if item is None:
            codons = AA_TO_CODONS.get(aa, ["NNN"])
            out.append(codons[0])
        else:
            codons, probs = item
            out.append(str(rng.choice(codons, p=probs)))
    return "".join(out)


def generate_uniform(protein, species, row_id):
    rng = stable_rng("uniform", species, row_id)
    out = []
    for aa in clean_protein(protein):
        codons = AA_TO_CODONS.get(aa, ["NNN"])
        out.append(str(rng.choice(codons)))
    return "".join(out)


def make_row(base, model, pred_dna):
    native = base["dna_sequence"]
    protein_len = int(base["protein_len"])

    native_gc3 = gc3_content(native)
    pred_gc3 = gc3_content(pred_dna)

    return {
        "model": model,
        "eval_id": int(base["eval_id"]),
        "species": base["species"],
        "genome_id": base.get("genome_id", ""),
        "gene_id": base.get("gene_id", ""),
        "gene_idx": int(base.get("gene_idx", -1)),
        "protein_len": protein_len,
        "bucket": length_bucket(protein_len),
        "native_dna": native,
        "pred_dna": pred_dna,
        "translation_valid": int(len(pred_dna) == 3 * len(clean_protein(base["protein_sequence"]))),
        "codon_recovery": codon_recovery(native, pred_dna),
        "nt_identity": nt_identity(native, pred_dna),
        "native_gc3": native_gc3,
        "pred_gc3": pred_gc3,
        "abs_gc3_error": abs(pred_gc3 - native_gc3) if not np.isnan(pred_gc3) and not np.isnan(native_gc3) else np.nan,
        "error": "",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default="ct2_full_species_eval_manifest_n1.csv")
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--out_csv", default="ct2_baseline_full_species_predictions.csv")
    args = ap.parse_args()

    manifest = pd.read_csv(args.manifest)
    freq_df = pd.read_parquet(args.codon_table)

    print("manifest rows:", len(manifest))
    print("species:", manifest["species"].nunique())
    print("codon table rows:", len(freq_df))

    hfc, bfc = build_species_aa_tables(freq_df)

    rows = []
    for rec in tqdm(manifest.to_dict(orient="records"), total=len(manifest), desc="generating baselines"):
        species = str(rec["species"])
        protein = rec["protein_sequence"]
        row_id = rec["eval_id"]

        rows.append(make_row(rec, "native", normalize_dna(rec["dna_sequence"])))
        rows.append(make_row(rec, "baseline_hfc", generate_hfc(protein, species, hfc)))
        rows.append(make_row(rec, "baseline_bfc", generate_bfc(protein, species, bfc, row_id)))
        rows.append(make_row(rec, "baseline_uniform", generate_uniform(protein, species, row_id)))

    out = pd.DataFrame(rows)
    out.to_csv(args.out_csv, index=False)

    print("WROTE", args.out_csv)
    print("rows:", len(out))
    print(out["model"].value_counts().to_string())

    summary = (
        out.groupby("model", as_index=False)
        .agg(
            n=("eval_id", "count"),
            translation_valid=("translation_valid", "mean"),
            codon_recovery=("codon_recovery", "mean"),
            nt_identity=("nt_identity", "mean"),
            abs_gc3_error=("abs_gc3_error", "mean"),
        )
    )
    summary.to_csv(args.out_csv.replace(".csv", "_summary.csv"), index=False)
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
