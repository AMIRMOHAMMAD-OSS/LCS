import pandas as pd
import torch
from pathlib import Path
from transformers import AutoTokenizer, BigBirdForMaskedLM
from CodonTransformer.CodonPrediction import predict_dna_sequence

CT1_MODEL_DIR = Path("/linkhome/rech/genjqx01/unh87ms/.cache/huggingface/hub/models--adibvafa--CodonTransformer/snapshots/9744dcc920d813066391fc828d7a590207f148e8")

df = pd.read_csv("ct1_ct2_162species_overlap_manifest_n10_len512.csv")
r = df.iloc[0]

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
tokenizer = AutoTokenizer.from_pretrained(str(CT1_MODEL_DIR), local_files_only=True)
model = BigBirdForMaskedLM.from_pretrained(str(CT1_MODEL_DIR), local_files_only=True).to(device)
model.eval()

out = predict_dna_sequence(
    protein=r["protein_sequence"],
    organism=r["ct1_organism"],
    tokenizer=tokenizer,
    model=model,
    device=device,
)

print("RETURN TYPE:", type(out))
print("RETURN REPR:")
print(repr(out)[:5000])

if isinstance(out, dict):
    print("DICT KEYS:", out.keys())
    for k, v in out.items():
        print("\nKEY:", k, "TYPE:", type(v), "LEN:", len(str(v)))
        print(str(v)[:1000])
elif isinstance(out, (list, tuple)):
    print("LIST/TUPLE LEN:", len(out))
    for i, v in enumerate(out):
        print("\nIDX:", i, "TYPE:", type(v), "LEN:", len(str(v)))
        print(str(v)[:1000])
