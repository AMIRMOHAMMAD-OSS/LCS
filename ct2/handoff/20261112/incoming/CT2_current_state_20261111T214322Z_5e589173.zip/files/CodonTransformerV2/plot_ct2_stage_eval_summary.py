from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt


OUTDIR = Path("ct2_stage_eval_plots")
OUTDIR.mkdir(exist_ok=True)

ORDER = {
    "native": 0,
    "baseline_hfc": 1,
    "baseline_bfc": 2,
    "baseline_uniform": 3,
    "stage1_main_e10": 4,
    "stage2_e3": 5,
    "stage3_e14": 6,
    "stage4_e7": 7,
    "stage5_e3": 8,
    "stage5_continue_e4": 9,
}

LABELS = {
    "native": "Native",
    "baseline_hfc": "HFC",
    "baseline_bfc": "BFC",
    "baseline_uniform": "Uniform",
    "stage1_main_e10": "Stage1 e10",
    "stage2_e3": "Stage2 e3",
    "stage3_e14": "Stage3 e14",
    "stage4_e7": "Stage4 e7",
    "stage5_e3": "Stage5 e3",
    "stage5_continue_e4": "Stage5 cont e4",
}


def prep(df):
    df = df.copy()
    df["order"] = df["model"].map(ORDER)
    df["label"] = df["model"].map(LABELS).fillna(df["model"])
    return df.sort_values("order")


def save_bar(df, xcol, ycol, title, ylabel, fname, rotate=True):
    df = prep(df)

    plt.figure(figsize=(11, 5))
    plt.bar(df[xcol], df[ycol])
    plt.title(title)
    plt.ylabel(ylabel)
    plt.xlabel("")
    if rotate:
        plt.xticks(rotation=35, ha="right")
    plt.tight_layout()
    path = OUTDIR / fname
    plt.savefig(path, dpi=200)
    plt.close()
    print("WROTE", path)


def save_line_by_rare(df, ycol, title, ylabel, fname):
    d = df.copy()
    d["order"] = d["model"].map(ORDER)
    d["label"] = d["model"].map(LABELS).fillna(d["model"])
    d = d.sort_values(["rare_mode", "order"])

    plt.figure(figsize=(11, 5))
    for rare_mode, g in d.groupby("rare_mode"):
        plt.plot(g["label"], g[ycol], marker="o", label=rare_mode)
    plt.title(title)
    plt.ylabel(ylabel)
    plt.xlabel("")
    plt.xticks(rotation=35, ha="right")
    plt.legend()
    plt.tight_layout()
    path = OUTDIR / fname
    plt.savefig(path, dpi=200)
    plt.close()
    print("WROTE", path)


def main():
    # 1. Generation metrics for CT2 stages only.
    pred_summary_path = Path("ct2_full_species_stage_predictions/ct2_stage_full_species_prediction_summary.csv")
    if pred_summary_path.exists():
        gen = pd.read_csv(pred_summary_path)
        gen["label"] = gen["model"].map(LABELS).fillna(gen["model"])
        gen = prep(gen)

        save_bar(gen, "label", "codon_recovery",
                 "CT2 stages: codon recovery", "Mean codon recovery",
                 "01_ct2_stage_codon_recovery.png")

        save_bar(gen, "label", "nt_identity",
                 "CT2 stages: nucleotide identity", "Mean NT identity",
                 "02_ct2_stage_nt_identity.png")

        save_bar(gen, "label", "abs_gc3_error",
                 "CT2 stages: absolute GC3 error", "Mean abs GC3 error",
                 "03_ct2_stage_abs_gc3_error.png")
    else:
        print("MISSING", pred_summary_path)

    # 2. CSI own-vs-wrong, CT2 stages only.
    csi_stage_path = Path("csi_own_wrong_ct2_stage1_to_stage5_full_species_summary_by_model.csv")
    if csi_stage_path.exists():
        csi = pd.read_csv(csi_stage_path)
        save_line_by_rare(csi, "delta_log_own_minus_wrong",
                          "CT2 stages: CSI own-minus-wrong log gap",
                          "Delta log CSI: own - wrong",
                          "04_ct2_stage_csi_delta_log.png")

        save_line_by_rare(csi, "csi_geomean_own",
                          "CT2 stages: own-species CSI",
                          "CSI geometric mean to own species",
                          "05_ct2_stage_csi_own.png")

        save_line_by_rare(csi, "ratio_geomean_own_over_wrong",
                          "CT2 stages: CSI own/wrong ratio",
                          "CSI own/wrong ratio",
                          "06_ct2_stage_csi_ratio.png")
    else:
        print("MISSING", csi_stage_path)

    # 3. Species rank.
    rank_path = Path("csi_rank_ct2_stage1_to_stage5_full_species_summary_by_model.csv")
    if rank_path.exists():
        rank = pd.read_csv(rank_path)
        save_line_by_rare(rank, "mean_true_rank",
                          "CT2 stages: mean true-species rank among 26,678 species",
                          "Mean true-species rank lower is better",
                          "07_ct2_stage_mean_true_rank.png")

        save_line_by_rare(rank, "median_true_rank",
                          "CT2 stages: median true-species rank among 26,678 species",
                          "Median true-species rank lower is better",
                          "08_ct2_stage_median_true_rank.png")

        save_line_by_rare(rank, "top100_rate",
                          "CT2 stages: true species in top 100",
                          "Top-100 rate",
                          "09_ct2_stage_top100_rate.png")

        save_line_by_rare(rank, "mean_reciprocal_rank",
                          "CT2 stages: mean reciprocal rank",
                          "MRR higher is better",
                          "10_ct2_stage_mrr.png")
    else:
        print("MISSING", rank_path)

    # 4. MinMax stages only.
    minmax_stage_path = Path("minmax_ct2_stage1_to_stage5_full_species_summary_by_model.csv")
    if minmax_stage_path.exists():
        mm = pd.read_csv(minmax_stage_path)
        save_line_by_rare(mm, "profile_mae",
                          "CT2 stages: MinMax local profile MAE",
                          "Profile MAE lower is better",
                          "11_ct2_stage_minmax_profile_mae.png")

        save_line_by_rare(mm, "profile_corr",
                          "CT2 stages: MinMax local profile correlation",
                          "Profile corr higher is better",
                          "12_ct2_stage_minmax_profile_corr.png")

        save_line_by_rare(mm, "abs_mean_minmax_diff",
                          "CT2 stages: mean MinMax bias difference",
                          "Abs mean MinMax diff lower is better",
                          "13_ct2_stage_minmax_mean_diff.png")
    else:
        print("MISSING", minmax_stage_path)

    # 5. MinMax + baselines.
    minmax_base_path = Path("minmax_ct2_stages_plus_baselines_full_species_summary_by_model.csv")
    if minmax_base_path.exists():
        mmb = pd.read_csv(minmax_base_path)
        for rare in ["all", "no_rare_0_001", "no_rare_0_01"]:
            sub = mmb[mmb["rare_mode"] == rare].copy()
            tag = rare.replace("no_rare_", "norare").replace(".", "p")
            save_bar(sub.assign(label=sub["model"].map(LABELS).fillna(sub["model"])),
                     "label", "profile_mae",
                     f"MinMax profile MAE with baselines ({rare})",
                     "Profile MAE lower is better",
                     f"14_minmax_baselines_profile_mae_{tag}.png")

            save_bar(sub.assign(label=sub["model"].map(LABELS).fillna(sub["model"])),
                     "label", "profile_corr",
                     f"MinMax profile correlation with baselines ({rare})",
                     "Profile corr higher is better",
                     f"15_minmax_baselines_profile_corr_{tag}.png")
    else:
        print("MISSING", minmax_base_path)

    # 6. CSI + baselines, if present.
    csi_base_path = Path("csi_own_wrong_ct2_stages_plus_baselines_full_species_summary_by_model.csv")
    if csi_base_path.exists():
        csib = pd.read_csv(csi_base_path)
        for rare in ["all", "no_rare_0_001", "no_rare_0_01"]:
            sub = csib[csib["rare_mode"] == rare].copy()
            tag = rare.replace("no_rare_", "norare").replace(".", "p")
            save_bar(sub.assign(label=sub["model"].map(LABELS).fillna(sub["model"])),
                     "label", "delta_log_own_minus_wrong",
                     f"CSI own-minus-wrong gap with baselines ({rare})",
                     "Delta log CSI: own - wrong",
                     f"16_csi_baselines_delta_log_{tag}.png")
    else:
        print("MISSING", csi_base_path)

    print()
    print("DONE. Plot folder:", OUTDIR)


if __name__ == "__main__":
    main()
