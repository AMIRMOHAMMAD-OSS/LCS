import json
import shutil
from pathlib import Path

TEST_DIR = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/test_set")
OUTROOT = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/test_set_len_buckets")

if OUTROOT.exists():
    shutil.rmtree(OUTROOT)
OUTROOT.mkdir(parents=True, exist_ok=True)

BUCKETS = {
    "le512": lambda n: n <= 512,
    "513_1024": lambda n: 512 < n <= 1024,
    "1025_2048": lambda n: 1024 < n <= 2048,
    "gt2048": lambda n: n > 2048,
}

for b in BUCKETS:
    (OUTROOT / b).mkdir(parents=True, exist_ok=True)

def find_record_list(obj):
    if isinstance(obj, list):
        return None, obj
    if isinstance(obj, dict):
        for key in ["genes", "records", "data", "items", "examples"]:
            if key in obj and isinstance(obj[key], list):
                return key, obj[key]
    return None, None

def get_len(r):
    if not isinstance(r, dict):
        return 0
    prot = r.get("protein_sequence") or r.get("protein") or r.get("aa_sequence") or ""
    dna = r.get("dna_sequence") or r.get("cds") or r.get("sequence") or ""
    if prot:
        return len(prot)
    if dna:
        return len(dna) // 3
    return 0

counts = {b: 0 for b in BUCKETS}
files_written = {b: 0 for b in BUCKETS}
bad = 0

for p in sorted(TEST_DIR.glob("*.json")):
    try:
        obj = json.loads(p.read_text(errors="ignore"))
    except Exception as e:
        bad += 1
        print("BAD_JSON", p, repr(e))
        continue

    list_key, records = find_record_list(obj)
    if records is None:
        bad += 1
        print("NO_RECORD_LIST", p)
        continue

    by_bucket = {b: [] for b in BUCKETS}
    for r in records:
        n = get_len(r)
        for b, fn in BUCKETS.items():
            if fn(n):
                by_bucket[b].append(r)
                counts[b] += 1
                break

    for b, recs in by_bucket.items():
        if not recs:
            continue

        if isinstance(obj, dict) and list_key is not None:
            new_obj = dict(obj)
            new_obj[list_key] = recs
        else:
            new_obj = recs

        out = OUTROOT / b / p.name
        out.write_text(json.dumps(new_obj, ensure_ascii=False))
        files_written[b] += 1

print("wrote", OUTROOT)
print("bad_files", bad)
print("bucket\tn_records\tn_files")
for b in ["le512", "513_1024", "1025_2048", "gt2048"]:
    print(f"{b}\t{counts[b]}\t{files_written[b]}")
