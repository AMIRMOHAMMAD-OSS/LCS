import argparse
import hashlib
import multiprocessing as mp
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm


GENETIC_CODE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

DNA_COL_CANDIDATES = [
    "pred_dna", "predicted_dna", "generated_dna", "optimized_dna",
    "prediction", "pred_sequence", "generated_sequence", "output_sequence",
    "dna", "dna_sequence", "nt_sequence", "sequence",
]
SPECIES_COL_CANDIDATES = ["species", "organism", "organism_name", "species_name"]
MODEL_COL_CANDIDATES = ["model", "model_name", "checkpoint"]

G_FREQ = None
G_SPECIES_LIST = None
G_SPECIES_SET = None
G_DNA_COL = None
G_SPECIES_COL = None
G_MODEL_COL = None
G_WRONG_N = None
G_RARE_MODE = None


def pick_col(df, candidates, required=True, label="column"):
    for c in candidates:
        if c in df.columns:
            return c
    if required:
        raise SystemExit(
            f"Could not find {label}. Candidates={candidates}\n"
            f"Available columns={df.columns.tolist()}"
        )
    return None


def normalize_dna(seq):
    if seq is None or pd.isna(seq):
        return ""
    return str(seq).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def codons_from_dna(seq):
    seq = normalize_dna(seq)
    n = len(seq) // 3
    out = []
    for i in range(n):
        codon = seq[3 * i:3 * i + 3]
        if len(codon) != 3:
            continue
        if any(c not in "ACGT" for c in codon):
            continue
        aa = GENETIC_CODE.get(codon)
        if aa is None or aa == "*":
            continue
        out.append((aa, codon))
    return out


def stable_wrong_species(species_list, true_species, row_key, n=5):
    candidates_len = len(species_list)
    if candidates_len <= 1:
        return []

    h = hashlib.md5(str(row_key).encode("utf-8")).hexdigest()
    seed = int(h[:8], 16)
    rng = np.random.default_rng(seed)

    wrong = []
    tried = set()
    while len(wrong) < n and len(tried) < min(candidates_len, n * 20 + 100):
        j = int(rng.integers(0, candidates_len))
        tried.add(j)
        sp = species_list[j]
        if sp != true_species:
            wrong.append(sp)

    return wrong


def score_sequence(codons, species, freq_lookup, eps=1e-9):
    logs = []
    missing = 0

    for aa, codon in codons:
        f = freq_lookup.get((species, aa, codon))
        if f is None:
            missing += 1
            f = eps
        logs.append(np.log(max(f, eps)))

    if not logs:
        return 0, missing, np.nan, np.nan

    log_mean = float(np.mean(logs))
    return len(logs), missing, log_mean, float(np.exp(log_mean))


def init_worker(freq_lookup, species_list, species_set, dna_col, species_col, model_col, wrong_n, rare_mode):
    global G_FREQ, G_SPECIES_LIST, G_SPECIES_SET, G_DNA_COL, G_SPECIES_COL, G_MODEL_COL, G_WRONG_N, G_RARE_MODE
    G_FREQ = freq_lookup
    G_SPECIES_LIST = species_list
    G_SPECIES_SET = species_set
    G_DNA_COL = dna_col
    G_SPECIES_COL = species_col
    G_MODEL_COL = model_col
    G_WRONG_N = wrong_n
    G_RARE_MODE = rare_mode


def score_row(item):
    idx, rec = item

    true_species = str(rec[G_SPECIES_COL])
    model = str(rec[G_MODEL_COL])
    dna = rec[G_DNA_COL]

    codons = codons_from_dna(dna)

    n_codons, missing_own, own_log, own_geo = score_sequence(codons, true_species, G_FREQ)

    wrong_species = stable_wrong_species(
        G_SPECIES_LIST,
        true_species,
        row_key=f"{idx}_{true_species}_{model}",
        n=G_WRONG_N,
    )

    wrong_logs = []
    for ws in wrong_species:
        _, _, wlog, _ = score_sequence(codons, ws, G_FREQ)
        if not pd.isna(wlog):
            wrong_logs.append(wlog)

    wrong_log_mean = float(np.mean(wrong_logs)) if wrong_logs else np.nan
    wrong_geo = float(np.exp(wrong_log_mean)) if not pd.isna(wrong_log_mean) else np.nan

    return {
        "rare_mode": G_RARE_MODE,
        "row_id": idx,
        "model": model,
        "species": true_species,
        "species_in_table": true_species in G_SPECIES_SET,
        "dna_col": G_DNA_COL,
        "n_codons_scored": n_codons,
        "missing_freq_codons_own": missing_own,
        "csi_log_own": own_log,
        "csi_geomean_own": own_geo,
        "wrong_n": len(wrong_logs),
        "csi_log_wrong_mean": wrong_log_mean,
        "csi_geomean_wrong_mean": wrong_geo,
        "delta_log_own_minus_wrong": own_log - wrong_log_mean if not pd.isna(own_log) and not pd.isna(wrong_log_mean) else np.nan,
        "ratio_geomean_own_over_wrong": own_geo / wrong_geo if wrong_geo and not pd.isna(own_geo) else np.nan,
        "wrong_species_sample": ";".join(wrong_species[:5]),
    }


def build_freq_lookup(freq_df, rare_mode):
    use = freq_df
    if rare_mode == "no_rare_0_001":
        use = use[~use["rare_lt_0_001"]]
    elif rare_mode == "no_rare_0_01":
        use = use[~use["rare_lt_0_01"]]

    return {
        (r.species, r.aa, r.codon): float(r.frequency)
        for r in tqdm(use.itertuples(index=False), total=len(use), desc=f"lookup {rare_mode}")
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--out_prefix", default="csi_own_wrong")
    ap.add_argument("--wrong_n", type=int, default=5)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--chunksize", type=int, default=200)
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    pred = pd.read_csv(args.predictions)
    if args.limit:
        pred = pred.head(args.limit).copy()

    species_col = pick_col(pred, SPECIES_COL_CANDIDATES, label="species column")
    model_col = pick_col(pred, MODEL_COL_CANDIDATES, required=False, label="model column")
    dna_col = pick_col(pred, DNA_COL_CANDIDATES, label="DNA/generated sequence column")

    if model_col is None:
        pred["model"] = "unknown_model"
        model_col = "model"

    print("prediction rows:", len(pred), flush=True)
    print("species_col:", species_col, flush=True)
    print("model_col:", model_col, flush=True)
    print("dna_col:", dna_col, flush=True)

    freq_df = pd.read_parquet(args.codon_table)
    species_list = sorted(freq_df["species"].dropna().unique().tolist())
    species_set = set(species_list)

    print("codon table rows:", len(freq_df), flush=True)
    print("codon table species:", len(species_list), flush=True)
    print("workers:", args.workers, flush=True)
    print("wrong_n:", args.wrong_n, flush=True)

    records = list(pred.to_dict(orient="index").items())

    all_results = []

    for rare_mode in ["all", "no_rare_0_001", "no_rare_0_01"]:
        print("\n" + "=" * 80, flush=True)
        print("RARE MODE:", rare_mode, flush=True)
        print("=" * 80, flush=True)

        freq_lookup = build_freq_lookup(freq_df, rare_mode)

        with mp.Pool(
            processes=args.workers,
            initializer=init_worker,
            initargs=(
                freq_lookup,
                species_list,
                species_set,
                dna_col,
                species_col,
                model_col,
                args.wrong_n,
                rare_mode,
            ),
        ) as pool:
            rows = list(
                tqdm(
                    pool.imap(score_row, records, chunksize=args.chunksize),
                    total=len(records),
                    desc=f"scoring {rare_mode}",
                )
            )

        res = pd.DataFrame(rows)
        all_results.append(res)

        partial = f"{args.out_prefix}_{rare_mode}_partial.csv"
        res.to_csv(partial, index=False)
        print("wrote partial:", partial, flush=True)

        del freq_lookup

    by_seq = pd.concat(all_results, ignore_index=True)
    out_seq = f"{args.out_prefix}_by_sequence.csv"
    by_seq.to_csv(out_seq, index=False)

    summary_model = (
        by_seq.groupby(["rare_mode", "model"], as_index=False)
        .agg(
            n=("row_id", "count"),
            species_in_table_rate=("species_in_table", "mean"),
            mean_codons_scored=("n_codons_scored", "mean"),
            csi_log_own=("csi_log_own", "mean"),
            csi_log_wrong_mean=("csi_log_wrong_mean", "mean"),
            delta_log_own_minus_wrong=("delta_log_own_minus_wrong", "mean"),
            csi_geomean_own=("csi_geomean_own", "mean"),
            csi_geomean_wrong_mean=("csi_geomean_wrong_mean", "mean"),
            ratio_geomean_own_over_wrong=("ratio_geomean_own_over_wrong", "mean"),
        )
    )

    out_model = f"{args.out_prefix}_summary_by_model.csv"
    summary_model.to_csv(out_model, index=False)

    summary_species = (
        by_seq.groupby(["rare_mode", "model", "species"], as_index=False)
        .agg(
            n=("row_id", "count"),
            mean_codons_scored=("n_codons_scored", "mean"),
            csi_log_own=("csi_log_own", "mean"),
            csi_log_wrong_mean=("csi_log_wrong_mean", "mean"),
            delta_log_own_minus_wrong=("delta_log_own_minus_wrong", "mean"),
            ratio_geomean_own_over_wrong=("ratio_geomean_own_over_wrong", "mean"),
        )
    )

    out_species = f"{args.out_prefix}_summary_by_species.csv"
    summary_species.to_csv(out_species, index=False)

    print("\n=== SUMMARY BY MODEL ===", flush=True)
    print(summary_model.to_string(index=False), flush=True)

    print("\nWROTE", flush=True)
    print(out_seq, flush=True)
    print(out_model, flush=True)
    print(out_species, flush=True)


if __name__ == "__main__":
    main()
