import json
import csv
from pathlib import Path

import torch
from transformers import PreTrainedTokenizerFast, ModernBertConfig, ModernBertForMaskedLM

from train_updated import TrainHarness, load_species_to_id
from codontransformer2.dataset.constants import TOKEN2MASK

CT1_CSV = Path("ct1_overlap_subset_predictions.csv")
OUT_CSV = Path("ct2_stage_overlap_predictions/stage3_e14_overlap_predictions.csv")

TOKENIZER_FILE = "/lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2/CodonTransformerTokenizer.json"
SPECIES_TO_ID_PATH = "/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/species_to_id.json"
CKPT = "/lustre/fsn1/projects/rech/nef/unh87ms/ct2_final/h100_8gpu_stage3_from_stage2e3_bs192_w1_sd002_lr2e5_acc1/epoch_14.ckpt"

MAX_LENGTH = 2048
NUM_ORGANISMS = 26678
EXTRA_ORGANISMS = 2000
UNKNOWN_SPECIES_ID = 26678


def gc_content(seq):
    seq = str(seq).upper()
    if not seq:
        return float("nan")
    return (seq.count("G") + seq.count("C")) / len(seq)


def gc3_content(seq):
    seq = str(seq).upper()
    codons = [seq[i:i + 3] for i in range(0, len(seq) - 2, 3)]
    if not codons:
        return float("nan")
    third = [c[2] for c in codons if len(c) == 3]
    return sum(1 for x in third if x in "GC") / len(third)


def codon_recovery(native, pred):
    native = str(native).upper()
    pred = str(pred).upper()
    n = min(len(native), len(pred)) // 3
    if n == 0:
        return float("nan")
    return sum(
        native[3 * i:3 * i + 3] == pred[3 * i:3 * i + 3]
        for i in range(n)
    ) / n


def nt_identity(native, pred):
    native = str(native).upper()
    pred = str(pred).upper()
    n = min(len(native), len(pred))
    if n == 0:
        return float("nan")
    return sum(a == b for a, b in zip(native[:n], pred[:n])) / n


def length_bucket(protein_len):
    protein_len = int(protein_len)
    if protein_len <= 512:
        return "<=512"
    if protein_len <= 1024:
        return "513-1024"
    if protein_len <= 2048:
        return "1025-2048"
    return ">2048"


def clean_protein(protein):
    protein = str(protein).strip().upper()
    protein = protein.rstrip("*_")
    return protein


def build_vocab_maps(tokenizer):
    vocab = tokenizer.get_vocab()
    id_to_token = {v: k for k, v in vocab.items()}

    aa_to_mask_id = {}
    aa_to_codon_ids = {}

    for codon_id, mask_id in TOKEN2MASK.items():
        codon_id = int(codon_id)
        mask_id = int(mask_id)

        if codon_id not in id_to_token:
            continue

        tok = id_to_token[codon_id]

        # Expected CT2 tokens are like "m_atg", "a_gcc", "__taa", etc.
        if "_" not in tok:
            continue

        aa = tok.split("_", 1)[0].upper()
        codon = tok.split("_", 1)[1].upper()

        if len(codon) != 3:
            continue

        if aa == "":
            aa = "_"

        aa_to_mask_id.setdefault(aa, mask_id)
        aa_to_codon_ids.setdefault(aa, []).append(codon_id)

    return id_to_token, aa_to_mask_id, aa_to_codon_ids


def token_to_codon(token):
    token = str(token)
    if "_" not in token:
        return None
    codon = token.split("_", 1)[1].upper()
    if len(codon) == 3 and all(c in "ATCG" for c in codon):
        return codon
    return None


def make_input_ids_for_protein(protein, tokenizer, aa_to_mask_id, device):
    protein = clean_protein(protein)

    ids = []

    if tokenizer.cls_token_id is not None:
        ids.append(tokenizer.cls_token_id)

    for aa in protein:
        if aa not in aa_to_mask_id:
            raise ValueError(f"No CT2 amino-acid mask token found for amino acid: {aa}")
        ids.append(int(aa_to_mask_id[aa]))

    if tokenizer.sep_token_id is not None:
        ids.append(tokenizer.sep_token_id)

    ids = ids[:MAX_LENGTH]

    input_ids = torch.tensor([ids], dtype=torch.long, device=device)
    attention_mask = torch.ones_like(input_ids)

    return input_ids, attention_mask


@torch.no_grad()
def ct2_predict_dna(
    protein,
    species,
    *,
    tokenizer,
    harness,
    species_to_id,
    id_to_token,
    aa_to_mask_id,
    aa_to_codon_ids,
    device,
):
    protein = clean_protein(protein)

    sid = species_to_id.get(str(species), UNKNOWN_SPECIES_ID)
    sid = int(sid)

    input_ids, attention_mask = make_input_ids_for_protein(
        protein,
        tokenizer,
        aa_to_mask_id,
        device,
    )

    species_id = torch.tensor([sid], dtype=torch.long, device=device)

    token_embeds = harness.model.get_input_embeddings()(input_ids)
    sp_vec = harness.species_embed(species_id)
    token_embeds = token_embeds + sp_vec[:, None, :]

    out = harness.model(
        inputs_embeds=token_embeds,
        attention_mask=attention_mask,
    )

    logits = out.logits[0]

    offset = 1 if tokenizer.cls_token_id is not None else 0

    pred_codons = []

    for i, aa in enumerate(protein):
        pos = i + offset
        if pos >= logits.shape[0]:
            break

        allowed = aa_to_codon_ids.get(aa)
        if not allowed:
            raise ValueError(f"No allowed codons for amino acid: {aa}")

        allowed_t = torch.tensor(allowed, dtype=torch.long, device=device)
        scores = logits[pos, allowed_t]
        best_id = int(allowed_t[torch.argmax(scores)].item())

        tok = id_to_token[best_id]
        codon = token_to_codon(tok)

        if codon is None:
            raise ValueError(f"Could not parse codon from token: {tok}")

        pred_codons.append(codon)

    return "".join(pred_codons)


def load_ct2(device):
    tokenizer = PreTrainedTokenizerFast(
        tokenizer_file=TOKENIZER_FILE,
        bos_token="[CLS]",
        eos_token="[SEP]",
        unk_token="[UNK]",
        sep_token="[SEP]",
        pad_token="[PAD]",
        cls_token="[CLS]",
        mask_token="[MASK]",
        max_len=MAX_LENGTH,
    )

    config = ModernBertConfig(
        vocab_size=len(tokenizer),
        pad_token_id=tokenizer.pad_token_id,
        sep_token_id=tokenizer.sep_token_id,
        cls_token_id=tokenizer.cls_token_id,
        max_position_embeddings=MAX_LENGTH,
        attn_implementation="sdpa",
    )

    model = ModernBertForMaskedLM(config=config)

    harness = TrainHarness(
        model,
        n_species_total=NUM_ORGANISMS + EXTRA_ORGANISMS,
        learning_rate=5e-6,
        warmup_fraction=0.05,
        learning_rate_decay=0.2,
        weight_decay=0.01,
        unknown_species_id=UNKNOWN_SPECIES_ID,
        eval_topk=5,
        synonym_topk=1,
        do_species_ablations_every=0,
        head_frac=0.1,
        tail_frac=0.5,
        species_counts_path=None,
    )

    ckpt = torch.load(CKPT, map_location="cpu")
    sd = ckpt.get("state_dict", ckpt)
    missing, unexpected = harness.load_state_dict(sd, strict=False)

    print("Loaded CT2 checkpoint")
    print("missing:", len(missing), "unexpected:", len(unexpected))

    harness.to(device)
    harness.eval()

    return tokenizer, harness


def main():
    import pandas as pd

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("device:", device)

    tokenizer, harness = load_ct2(device)

    species_to_id = load_species_to_id(SPECIES_TO_ID_PATH)
    id_to_token, aa_to_mask_id, aa_to_codon_ids = build_vocab_maps(tokenizer)

    print("n amino acids with mask:", len(aa_to_mask_id))
    print("n amino acids with codons:", len(aa_to_codon_ids))

    df = pd.read_csv(CT1_CSV)
    df = df[df["error"].fillna("") == ""].copy()

    rows = []

    for idx, r in df.iterrows():
        species = r["species"]
        protein_id = r["protein_id"]
        protein_len = int(r["protein_len"])

        native_dna = str(r["native_dna"]) if "native_dna" in r and pd.notna(r["native_dna"]) else None

        # CT1 csv may not contain the original protein/native DNA depending on previous script.
        # If not present, recover them from the source JSON by genome_id/protein_id.
        protein = None

        genome_id = r["genome_id"]
        json_path = Path("ct2_fair_overlap_test_jsons") / f"{genome_id}.json"

        if json_path.exists():
            obj = json.loads(json_path.read_text())
            for g in obj.get("genes", []):
                if str(g.get("protein_id")) == str(protein_id):
                    protein = g.get("protein_sequence")
                    native_dna = g.get("dna_sequence")
                    break

        if protein is None or native_dna is None:
            rows.append({
                "model": "stage3_e14",
                "genome_id": genome_id,
                "species": species,
                "protein_id": protein_id,
                "protein_len": protein_len,
                "bucket": length_bucket(protein_len),
                "error": "missing protein/native dna",
            })
            continue

        try:
            pred_dna = ct2_predict_dna(
                protein,
                species,
                tokenizer=tokenizer,
                harness=harness,
                species_to_id=species_to_id,
                id_to_token=id_to_token,
                aa_to_mask_id=aa_to_mask_id,
                aa_to_codon_ids=aa_to_codon_ids,
                device=device,
            )

            native_gc3 = gc3_content(native_dna)
            pred_gc3 = gc3_content(pred_dna)

            rows.append({
                "model": "stage3_e14",
                "genome_id": genome_id,
                "species": species,
                "protein_id": protein_id,
                "protein_len": len(clean_protein(protein)),
                "bucket": length_bucket(len(clean_protein(protein))),
                "native_dna_len": len(native_dna),
                "pred_dna_len": len(pred_dna),
                "translation_valid": True,  # constrained by synonymous codon selection
                "codon_recovery": codon_recovery(native_dna, pred_dna),
                "nt_identity": nt_identity(native_dna, pred_dna),
                "native_gc": gc_content(native_dna),
                "pred_gc": gc_content(pred_dna),
                "native_gc3": native_gc3,
                "pred_gc3": pred_gc3,
                "abs_gc3_error": abs(native_gc3 - pred_gc3),
                "error": "",
            })

        except Exception as e:
            rows.append({
                "model": "stage3_e14",
                "genome_id": genome_id,
                "species": species,
                "protein_id": protein_id,
                "protein_len": protein_len,
                "bucket": length_bucket(protein_len),
                "error": repr(e),
            })

        if len(rows) % 25 == 0:
            print("processed", len(rows), flush=True)

    keys = sorted(set().union(*[r.keys() for r in rows]))
    front = ["model", "genome_id", "species", "protein_id", "protein_len", "bucket"]
    keys = front + [k for k in keys if k not in front]

    with OUT_CSV.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)

    print("wrote", OUT_CSV)
    print("n_rows", len(rows))

    outdf = pd.read_csv(OUT_CSV)
    ok = outdf[outdf["error"].fillna("") == ""].copy()

    print()
    print("By bucket:")
    print(ok.groupby("bucket")[[
        "translation_valid",
        "codon_recovery",
        "nt_identity",
        "abs_gc3_error",
    ]].mean())

    print()
    print("By species:")
    print(ok.groupby("species")[[
        "translation_valid",
        "codon_recovery",
        "nt_identity",
        "abs_gc3_error",
    ]].mean())


if __name__ == "__main__":
    main()
