import tarfile
import json
from pathlib import Path

SHARD = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/train_set_shard/shard-000000.tar.gz")

print("shard:", SHARD)
n = 0

with tarfile.open(SHARD, "r:gz") as tar:
    for member in tar:
        if not member.isfile():
            continue
        if not member.name.endswith((".json", ".jsonl")):
            continue

        f = tar.extractfile(member)
        if f is None:
            continue

        raw = f.read().decode("utf-8", errors="replace").strip()
        if not raw:
            continue

        print("\nMEMBER:", member.name)
        try:
            obj = json.loads(raw)
        except Exception as e:
            print("json error:", repr(e))
            continue

        print("type:", type(obj))
        if isinstance(obj, dict):
            print("keys:", list(obj.keys()))
            for k, v in obj.items():
                if isinstance(v, str):
                    print(k, "str len", len(v), "sample:", v[:120])
                elif isinstance(v, list):
                    print(k, "list len", len(v), "first type:", type(v[0]) if v else None)
                else:
                    print(k, type(v), v)
        elif isinstance(obj, list):
            print("list len:", len(obj))
            if obj and isinstance(obj[0], dict):
                print("first keys:", list(obj[0].keys()))
                for k, v in obj[0].items():
                    print(k, type(v), str(v)[:120])

        n += 1
        if n >= 5:
            break
