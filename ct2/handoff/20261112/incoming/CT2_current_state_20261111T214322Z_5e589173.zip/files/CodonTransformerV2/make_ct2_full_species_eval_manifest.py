import json
from pathlib import Path
import pandas as pd
from tqdm import tqdm

TEST_DIR = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/test_set")
OUT = Path("ct2_full_species_eval_manifest_n1.csv")

N_PER_SPECIES = 1
MAX_PROTEIN_LEN = 2048

PROTEIN_KEYS = [
    "protein_sequence", "protein", "aa_sequence", "amino_acid_sequence",
    "aminoacid_sequence", "amino_acids", "aa", "protein_seq",
    "translation", "prot", "amino_acids_sequence"
]

DNA_KEYS = [
    "dna_sequence", "dna", "cds", "cds_sequence", "nt_sequence",
    "nucleotide_sequence", "sequence", "coding_sequence", "cds_seq"
]


def get_first(rec, keys):
    for k in keys:
        if k in rec and rec[k] not in [None, ""]:
            return rec[k]
    return None


def normalize_seq(x):
    if x is None:
        return None
    return str(x).replace(" ", "").replace("\n", "").replace("\r", "")


rows = []
seen = {}
gene_key_counter = {}

files = sorted(TEST_DIR.glob("*.json"))

print("test files:", len(files))

for fp in tqdm(files, desc="Scanning test genome jsons", unit="file"):
    try:
        obj = json.loads(fp.read_text(errors="replace"))
    except Exception as e:
        print("SKIP_BAD_JSON", fp, repr(e))
        continue

    species = obj.get("species")
    genome_id = obj.get("genome_id", fp.stem)
    genes = obj.get("genes", [])

    if species is None or not isinstance(genes, list):
        continue

    species = str(species).strip()

    if seen.get(species, 0) >= N_PER_SPECIES:
        continue

    for gi, gene in enumerate(genes):
        if not isinstance(gene, dict):
            continue

        for k in gene.keys():
            gene_key_counter[k] = gene_key_counter.get(k, 0) + 1

        protein = normalize_seq(get_first(gene, PROTEIN_KEYS))
        dna = normalize_seq(get_first(gene, DNA_KEYS))

        if protein is None:
            continue

        protein_len = len(protein)
        if protein_len <= 0 or protein_len > MAX_PROTEIN_LEN:
            continue

        rows.append({
            "eval_id": len(rows),
            "species": species,
            "genome_id": genome_id,
            "protein_sequence": protein,
            "dna_sequence": dna if dna is not None else "",
            "protein_len": protein_len,
            "source_file": str(fp),
            "gene_idx": gi,
            "gene_id": gene.get("gene_id", gene.get("id", gene.get("locus_tag", ""))),
        })

        seen[species] = seen.get(species, 0) + 1
        break

df = pd.DataFrame(rows)

if len(df) == 0:
    print("\nNO ROWS FOUND.")
    print("Most common gene keys discovered:")
    for k, v in sorted(gene_key_counter.items(), key=lambda x: -x[1])[:80]:
        print(k, v)
else:
    df.to_csv(OUT, index=False)
    print("WROTE", OUT)
    print("rows:", len(df))
    print("species:", df["species"].nunique())
    print("min_len:", df["protein_len"].min())
    print("max_len:", df["protein_len"].max())
    print("missing dna rows:", (df["dna_sequence"].fillna("") == "").sum())
    print(df.head().to_string(index=False))
