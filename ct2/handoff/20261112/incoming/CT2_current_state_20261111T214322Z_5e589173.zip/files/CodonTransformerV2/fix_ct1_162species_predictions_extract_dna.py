import re
import numpy as np
import pandas as pd


def clean_dna(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def extract_predicted_dna(x):
    s = str(x)

    # CT1 output repr looks like:
    # DNASequencePrediction(..., PREDICTED_DNA='ATG...')
    m = re.search(r"PREDICTED_DNA='([ACGTUNacgtun\s\r\n]+)'", s)
    if m:
        return clean_dna(m.group(1))

    # Fallback if the CSV already contains plain DNA.
    y = clean_dna(s)
    if y and set(y).issubset(set("ACGTN")):
        return y

    return ""


def gc_content(seq):
    seq = clean_dna(seq)
    if not seq:
        return np.nan
    return sum(1 for c in seq if c in "GC") / len(seq)


def gc3_content(seq):
    seq = clean_dna(seq)
    codons = [seq[i:i+3] for i in range(0, len(seq)-2, 3)]
    if not codons:
        return np.nan
    third = [c[2] for c in codons if len(c) == 3]
    if not third:
        return np.nan
    return sum(1 for c in third if c in "GC") / len(third)


def codon_recovery(native, pred):
    native = clean_dna(native)
    pred = clean_dna(pred)
    n = min(len(native), len(pred)) // 3
    if n == 0:
        return np.nan
    return sum(native[3*i:3*i+3] == pred[3*i:3*i+3] for i in range(n)) / n


def nt_identity(native, pred):
    native = clean_dna(native)
    pred = clean_dna(pred)
    n = min(len(native), len(pred))
    if n == 0:
        return np.nan
    return sum(a == b for a, b in zip(native[:n], pred[:n])) / n


inp = "ct1_162species_overlap_predictions.csv"
out = "ct1_162species_overlap_predictions_fixed.csv"

df = pd.read_csv(inp)

df["ct1_raw_output"] = df["pred_dna"].astype(str)
df["pred_dna"] = df["ct1_raw_output"].apply(extract_predicted_dna)

df["native_dna"] = df["native_dna"].apply(clean_dna)
df["native_dna_len"] = df["native_dna"].str.len()
df["pred_dna_len"] = df["pred_dna"].str.len()

df["native_gc"] = df["native_dna"].apply(gc_content)
df["pred_gc"] = df["pred_dna"].apply(gc_content)
df["native_gc3"] = df["native_dna"].apply(gc3_content)
df["pred_gc3"] = df["pred_dna"].apply(gc3_content)

df["abs_gc_error"] = (df["pred_gc"] - df["native_gc"]).abs()
df["abs_gc3_error"] = (df["pred_gc3"] - df["native_gc3"]).abs()

df["codon_recovery"] = [
    codon_recovery(n, p) for n, p in zip(df["native_dna"], df["pred_dna"])
]
df["nt_identity"] = [
    nt_identity(n, p) for n, p in zip(df["native_dna"], df["pred_dna"])
]

df["translation_valid"] = df["pred_dna_len"] == 3 * df["protein_len"].astype(int)

# Mark extraction failures.
bad = df["pred_dna"].eq("")
df.loc[bad, "error"] = df.loc[bad, "error"].fillna("").astype(str) + ";failed_to_extract_predicted_dna"
df.loc[~bad, "error"] = df.loc[~bad, "error"].fillna("")

df.to_csv(out, index=False)

summary = (
    df[df["error"].fillna("") == ""]
    .groupby("model", as_index=False)
    .agg(
        n=("eval_id", "count"),
        translation_valid=("translation_valid", "mean"),
        codon_recovery=("codon_recovery", "mean"),
        nt_identity=("nt_identity", "mean"),
        abs_gc3_error=("abs_gc3_error", "mean"),
        mean_pred_dna_len=("pred_dna_len", "mean"),
        mean_native_dna_len=("native_dna_len", "mean"),
    )
)
summary.to_csv(out.replace(".csv", "_summary.csv"), index=False)

print("WROTE", out)
print("rows:", len(df))
print("empty extracted pred_dna:", int(bad.sum()))
print()
print(summary.to_string(index=False))
print()
print(df[["eval_id", "ct1_organism", "protein_len", "native_dna_len", "pred_dna_len", "translation_valid", "codon_recovery", "nt_identity", "abs_gc3_error", "error"]].head(20).to_string(index=False))
