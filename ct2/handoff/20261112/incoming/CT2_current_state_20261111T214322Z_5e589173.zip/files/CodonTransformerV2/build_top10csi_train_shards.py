import argparse
import io
import json
import math
import tarfile
from pathlib import Path

import pandas as pd
from tqdm import tqdm

GENETIC_CODE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

def translate(dna):
    aa = []
    for i in range(0, len(dna) - 2, 3):
        codon = dna[i:i+3]
        if len(codon) != 3 or any(c not in "ACGT" for c in codon):
            aa.append("X")
            continue
        a = GENETIC_CODE.get(codon, "X")
        if a == "*":
            break
        aa.append(a)
    return "".join(aa)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input_parquet", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--records_per_shard", type=int, default=8192)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    df = pd.read_parquet(args.input_parquet)
    print(f"loaded {len(df)} reference genes from {df['species'].nunique()} species")
    print(f"mean CSI: {df['formal_csi'].mean():.4f}")

    df = df.sample(frac=1.0, random_state=args.seed).reset_index(drop=True)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    n_shards = math.ceil(len(df) / args.records_per_shard)
    print(f"writing {n_shards} shards to {out_dir}")

    for shard_idx in tqdm(range(n_shards), desc="shards"):
        start = shard_idx * args.records_per_shard
        end = min(start + args.records_per_shard, len(df))
        chunk = df.iloc[start:end]
        shard_path = out_dir / f"shard-{shard_idx:06d}.tar.gz"

        with tarfile.open(shard_path, "w:gz") as tar:
            for rec_idx, row in enumerate(chunk.itertuples(index=False)):
                dna = str(row.dna).upper().replace("U", "T")
                protein = translate(dna)
                if not protein:
                    continue
                record = {
                    "species": str(row.species),
                    "genome_id": str(row.genome_id),
                    "protein_id": str(row.protein_id),
                    "dna_sequence": dna,
                    "protein_sequence": protein,
                }
                payload = json.dumps(record).encode("utf-8")
                info = tarfile.TarInfo(name=f"sample{rec_idx:08d}.json")
                info.size = len(payload)
                tar.addfile(info, io.BytesIO(payload))

    print(f"done, wrote {n_shards} shards to {out_dir}")

if __name__ == "__main__":
    main()
