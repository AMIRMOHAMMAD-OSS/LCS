import pandas as pd
from pathlib import Path

PRED = Path("ct1_overlap_predictions.csv")
df = pd.read_csv(PRED)

CODON_TABLE = {
    "TTT":"F","TTC":"F",
    "TTA":"L","TTG":"L","CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S","AGT":"S","AGC":"S",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R","AGA":"R","AGG":"R",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

def clean_dna(x):
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "")

def codons(dna, n_codons):
    dna = clean_dna(dna)
    return [dna[i:i+3] for i in range(0, min(len(dna), n_codons * 3), 3)]

def gc_frac(dna):
    dna = clean_dna(dna)
    if not dna:
        return float("nan")
    return (dna.count("G") + dna.count("C")) / len(dna)

rows = []

for _, r in df.iterrows():
    L = int(r["protein_len"])

    true_dna = clean_dna(r["true_dna"])
    pred_dna = clean_dna(r["ct1_pred_dna"])

    true_codons = codons(true_dna, L)
    pred_codons = codons(pred_dna, L)

    n = min(len(true_codons), len(pred_codons), L)

    exact = 0
    syn = 0
    valid = 0

    for tc, pc in zip(true_codons[:n], pred_codons[:n]):
        if len(tc) != 3 or len(pc) != 3:
            continue
        aa_t = CODON_TABLE.get(tc, "X")
        aa_p = CODON_TABLE.get(pc, "X")
        if aa_t == "X" or aa_p == "X":
            continue
        valid += 1
        exact += int(tc == pc)
        syn += int(aa_t == aa_p)

    rows.append({
        "row_id": int(r["row_id"]),
        "ct1_organism": r["ct1_organism"],
        "species": r["species"],
        "protein_len": L,
        "valid_codons": valid,
        "ct1_exact_codon_acc": exact / valid if valid else float("nan"),
        "ct1_syn_codon_acc": syn / valid if valid else float("nan"),
        "true_gc": gc_frac(true_dna[:L*3]),
        "ct1_gc": gc_frac(pred_dna[:L*3]),
        "abs_gc_error": abs(gc_frac(true_dna[:L*3]) - gc_frac(pred_dna[:L*3])),
    })

m = pd.DataFrame(rows)
m.to_csv("ct1_overlap_metrics_per_gene.csv", index=False)

print("OVERALL")
print("n_successful_genes:", len(m))
print("mean_exact_codon_acc:", m["ct1_exact_codon_acc"].mean())
print("mean_syn_codon_acc:", m["ct1_syn_codon_acc"].mean())
print("mean_abs_gc_error:", m["abs_gc_error"].mean())
print("median_abs_gc_error:", m["abs_gc_error"].median())

print()
print("BY_ORGANISM")
org = (
    m.groupby("ct1_organism")
    .agg(
        n_genes=("row_id", "count"),
        exact=("ct1_exact_codon_acc", "mean"),
        syn=("ct1_syn_codon_acc", "mean"),
        abs_gc_error=("abs_gc_error", "mean"),
    )
    .sort_values("exact", ascending=False)
)
print(org)

org.to_csv("ct1_overlap_metrics_by_organism.csv")

print()
print("wrote ct1_overlap_metrics_per_gene.csv")
print("wrote ct1_overlap_metrics_by_organism.csv")
