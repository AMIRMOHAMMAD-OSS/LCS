#!/usr/bin/env python3
"""Prepare a new sealed continuation from the already reviewed Phase-1 snapshot."""
from __future__ import annotations
import argparse
import json
import re
import shutil
import subprocess
from pathlib import Path
from common import ROOT, DEFAULT_SOURCE, SOURCE_FINGERPRINT, STAGES, fingerprint, sha, atomic_json, inventory, stable_seed, validate_mapping

def header(root,name,hours):
    return f'''#!/bin/bash
#SBATCH --job-name={name}
#SBATCH -A nef@h100
#SBATCH --partition=gpu_p6
#SBATCH -C h100
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=4
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=8
#SBATCH --time={hours}:00:00
#SBATCH --hint=nomultithread
#SBATCH --signal=USR1@300
#SBATCH --chdir={root}
#SBATCH --output={root}/logs/{name}_%j.out
#SBATCH --error={root}/logs/{name}_%j.err
set -euo pipefail
cd '{root}'
exec 9> .run.lock
flock -n 9 || {{ echo 'Another job is using this continuation directory.' >&2; exit 75; }}
module purge
module load arch/h100
module load pytorch-gpu/py3/2.6.0
export PYTHONUNBUFFERED=1 TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=8
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export MASTER_ADDR="$(scontrol show hostnames "$SLURM_JOB_NODELIST" | sed -n '1p')"
export MASTER_PORT="$((15000 + SLURM_JOB_ID % 40000))"
export PYTHONPATH="$PWD:$PWD/source${{PYTHONPATH:+:$PYTHONPATH}}"
'''

def scripts(root,output,stage):
    name=STAGES[stage]['name']
    preflight=header(root,'ct2_check_'+name,'04')+f'''
bash runtime_python.sh -u checks.py inputs
export CT2_RUN_DDP_TESTS=1
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 bash runtime_python.sh -u -m unittest discover -s tests -p 'test_*.py' -v
export CT2_CHECK_DIR='{output}/preflight/{name}/job_'"$SLURM_JOB_ID"
mkdir -p "$CT2_CHECK_DIR"
srun --kill-on-bad-exit=1 bash runtime_python.sh -u preflight.py --stage {stage} --output "$CT2_CHECK_DIR"
srun --kill-on-bad-exit=1 bash runtime_python.sh -u train.py --stage {stage} --mode smoke-reference --stop-after 32 --eval-interval 32 --checkpoint-interval 16 --output "$CT2_CHECK_DIR/reference"
srun --kill-on-bad-exit=1 bash runtime_python.sh -u train.py --stage {stage} --mode smoke-resume --stop-after 32 --eval-interval 32 --checkpoint-interval 16 --resume "$CT2_CHECK_DIR/reference/step_{sum(s['steps'] for s in STAGES[:stage])+16:06d}.ckpt" --output "$CT2_CHECK_DIR/resumed"
bash runtime_python.sh -u checks.py compare --stage {stage} --output "$CT2_CHECK_DIR"
echo 'PREFLIGHT FINISHED. Review submit.py baselines. Production training requires a separate submit.py train command.'
'''
    full=header(root,'ct2_'+name,'20')+f'''
bash runtime_python.sh -u checks.py inputs
srun --kill-on-bad-exit=1 bash runtime_python.sh -u train.py --stage {stage} --resume auto
bash runtime_python.sh -u checks.py completed --stage {stage}
'''
    return {f'preflight_{name}.slurm':preflight,f'train_{name}.slurm':full}

def select_rows(rows):
    from phase1_tokens import normalize_protein, AMINO_ACIDS
    ordered=sorted(range(len(rows)),key=lambda i:stable_seed('panel:'+str(rows[i]['eval_key'])))
    buckets=[[],[],[]];exclusions={'over_2045_residues':0,'unsupported_protein':0}
    for i in ordered:
        protein=normalize_protein(rows[i]['protein_sequence']);n=len(protein)
        buckets[0 if n<=509 else 1 if n<=1021 else 2].append(i)
        if n>2045:exclusions['over_2045_residues']+=1
        if set(protein)-AMINO_ACIDS:exclusions['unsupported_protein']+=1
    long=[]
    for bucket,n in zip(buckets,(64,96,96)):long.extend(bucket[:n])
    long.extend(i for i in ordered if i not in set(long))
    long=long[:256]
    generation=[];probes=[]
    for bucket in buckets:
        valid=[i for i in bucket if len(normalize_protein(rows[i]['protein_sequence']))<=2045 and not set(normalize_protein(rows[i]['protein_sequence']))-AMINO_ACIDS]
        generation.extend(valid[:8]);probes.extend(valid[:2])
    if not generation:raise ValueError('No complete genes available for generation probes')
    return long,generation,probes,exclusions

def setup(source,initialization,batch_divisor,root=ROOT):
    root=Path(root).resolve();source=Path(source).resolve()
    if not re.fullmatch(r'[A-Za-z0-9_./-]+',str(root)):raise ValueError('Extraction path must not contain spaces or shell metacharacters')
    if (root/'run.json').exists() or (root/'source').exists():raise FileExistsError('Use a fresh extraction directory')
    cfg=json.loads((source/'run_config.json').read_text())
    if cfg['fingerprint']!=fingerprint(cfg) or cfg['fingerprint']!=SOURCE_FINGERPRINT:
        raise ValueError('This is not the reviewed Phase-1 run configuration')
    for rel,expected in cfg['code_hashes'].items():
        if Path(rel).is_absolute() or '..' in Path(rel).parts:raise ValueError('Invalid sealed source path')
        if sha(source/rel)!=expected:raise ValueError(f'Phase-1 source changed: {rel}')
    meta=json.loads((source/'eval_panel_meta.json').read_text())
    if meta['fingerprint']!=cfg['fingerprint'] or meta['sha256']!=sha(source/'eval_panel.jsonl') or meta['samples']!=4096:
        raise ValueError('Fixed panel seal mismatch')
    if sha(cfg['species_mapping'])!=cfg['species_mapping_sha256']:raise ValueError('Source mapping changed')
    for rel in ('phase1_tokens.py','strict_generation.py'):
        if sha(root/rel)!=cfg['code_hashes'][rel]:raise ValueError(f'Bundled helper mismatch: {rel}')
    mapping=json.loads(Path(cfg['species_mapping']).read_text());validate_mapping(mapping,26678)
    shards=inventory(cfg['data_root'])
    checkpoints={}
    for name in ('epoch_6','epoch_9'):
        p=Path(cfg['output_dir'])/'full'/(name+'.ckpt');stat=p.stat()
        if stat.st_size<1_000_000_000:raise ValueError(f'Missing/incomplete checkpoint: {p}')
        print('HASHING_SOURCE_CHECKPOINT',name,flush=True)
        checkpoints[name]={'path':str(p),'stat':[stat.st_size,stat.st_mtime_ns],'sha256':sha(p)}
    output=Path(cfg['output_dir']).parent/root.name
    if output.exists():raise FileExistsError(f'Output directory already exists: {output}')
    for rel in sorted(set(cfg['code_hashes'])|{'run_config.json','eval_panel.jsonl','eval_panel_meta.json'}):
        target=root/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/rel,target)
    shutil.copy2(cfg['species_mapping'],root/'source/species_to_id.json')
    rows=[json.loads(l) for l in (source/'eval_panel.jsonl').read_text().splitlines() if l.strip()]
    long,generation,probes,exclusions=select_rows(rows)
    hosts=[]
    for query in ('Escherichia coli str. K-12 substr. MG1655','Homo sapiens','Saccharomyces cerevisiae S288C','Plasmodium falciparum 3D7'):
        if query not in mapping:raise ValueError(f'Expected comparison host missing: {query}')
        hosts.append(query)
    streptomyces=sorted(k for k in mapping if k.startswith('Streptomyces '))
    if not streptomyces:raise ValueError('No Streptomyces host in mapping')
    hosts.append(streptomyces[0])
    (root/'logs').mkdir(exist_ok=True)
    for i in range(len(STAGES)):
        for name,body in scripts(root,output,i).items():
            (root/name).write_text(body);subprocess.run(['bash','-n',str(root/name)],check=True)
    run={'version':2,'source_run':str(source),'source_fingerprint':cfg['fingerprint'],
        'launch_policy':'preflight_only_then_explicit_train',
        'runtime':{'training_cpu_threads':8,'test_cpu_threads':1,'cache_policy':'node_local_job_directory'},
        'data_root':cfg['data_root'],'mapping':str(root/'source/species_to_id.json'),'mapping_sha256':cfg['species_mapping_sha256'],
        'checkpoints':checkpoints,'initialization':initialization,'source_step':(int(initialization[-1])+1)*8000,
        'optimizer_initialization':'retain_source_AdamW_moments_and_step; new continuation warmup/schedule',
        'output':str(output),'seed':123,'world_size':8,'batch_divisor':batch_divisor,'shuffle_buffer':1024,
        'shards':shards,'stages':STAGES,'long_panel_indices':long,'generation_indices':generation,
        'host_probe_indices':probes,'generation_exclusions':exclusions,'comparison_hosts':hosts}
    paths=[p for p in root.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.jsonl','.slurm','.sh') and '__pycache__' not in p.parts]
    run['hashes']={str(p.relative_to(root)):sha(p) for p in sorted(paths)}
    run['fingerprint']=fingerprint(run);atomic_json(root/'run.json',run)
    output.mkdir(parents=True)
    print('READY:',root);print('OUTPUT:',output);print('INITIALIZATION:',initialization,'with saved AdamW state')
    print('FIRST_STAGE: 8000 updates, length 512, full-mask 0 -> 5%, no later stage automatically launched')
    print('No Slurm jobs have been submitted.')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source-run',default=DEFAULT_SOURCE)
    p.add_argument('--init',default='epoch_9',choices=['epoch_6','epoch_9'])
    p.add_argument('--batch-divisor',type=int,choices=[1,2,4,8],default=1)
    a=p.parse_args();setup(a.source_run,a.init,a.batch_divisor)
