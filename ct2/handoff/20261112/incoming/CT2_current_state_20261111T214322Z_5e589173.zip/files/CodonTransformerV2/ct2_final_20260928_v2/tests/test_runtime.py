import os
from pathlib import Path
import subprocess
import tempfile
import unittest


class RuntimeTests(unittest.TestCase):
    def test_cache_paths_override_home_and_are_created_on_each_node(self):
        wrapper=Path(__file__).resolve().parents[1]/'runtime_python.sh'
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);binary=root/'bin';binary.mkdir()
            fake=binary/'python'
            fake.write_text('#!/bin/bash\n'
                'printf "%s\\n" "$XDG_CACHE_HOME" "$HF_HOME" "$HF_HUB_CACHE" '
                '"$HF_DATASETS_CACHE" "$TORCH_HOME" "$TORCHINDUCTOR_CACHE_DIR" '
                '"$TRITON_CACHE_DIR" "$TRITON_HOME" "$CUDA_CACHE_PATH"\n')
            fake.chmod(0o700)
            for rank in ('0','4'):
                local=root/('node_'+rank);local.mkdir()
                env={'PATH':str(binary)+':'+os.environ['PATH'],'SLURM_JOB_ID':'123',
                     'SLURM_TMPDIR':str(local),'SLURM_PROCID':rank,
                     'HOME':'/home-not-writable','TRITON_CACHE_DIR':'/home-not-writable/.triton'}
                result=subprocess.run(['bash',str(wrapper)],env=env,text=True,capture_output=True,check=True)
                paths=[Path(s) for s in result.stdout.splitlines() if not s.startswith('CT2_RUNTIME_CACHE:')]
                self.assertEqual(len(paths),9)
                for path in paths:
                    self.assertTrue(path.is_dir());self.assertTrue(path.is_relative_to(local))


if __name__=='__main__':unittest.main()
