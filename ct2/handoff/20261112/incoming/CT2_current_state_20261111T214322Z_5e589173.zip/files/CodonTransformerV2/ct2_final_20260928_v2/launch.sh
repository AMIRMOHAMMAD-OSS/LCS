#!/bin/bash
# Configure a fresh run and submit only its preflight. No training is queued.
set -euo pipefail
ct2_bundle_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f "$ct2_bundle_dir/run.json" ]]; then
    python3 "$ct2_bundle_dir/setup.py" "$@"
elif [[ $# -gt 0 ]]; then
    echo 'This directory is already configured. New setup options require a fresh extraction.' >&2
    exit 1
fi
python3 "$ct2_bundle_dir/submit.py" start
