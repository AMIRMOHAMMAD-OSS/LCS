import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import submit
from setup import scripts

class SubmissionTests(unittest.TestCase):
    def test_start_submits_only_preflight_and_duplicate_is_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);calls=[]
            def fake(command,**kwargs):
                calls.append(command)
                return SimpleNamespace(stdout='' if command[0]=='squeue' else str(100+len(calls))+'\n')
            cfg={'fingerprint':'f','output':str(root/'output')}
            with patch.object(submit,'ROOT',root),patch.object(submit.subprocess,'run',side_effect=fake):
                submit.submit(cfg,'start',0)
                with self.assertRaisesRegex(RuntimeError,'Already submitted'):submit.submit(cfg,'start',0)
            jobs=json.loads((root/'jobs.json').read_text())['submissions']
            self.assertEqual([j['stage'] for j in jobs],[0]);self.assertEqual([j['kind'] for j in jobs],['preflight'])
            sbatch=[c for c in calls if c[0]=='sbatch']
            self.assertEqual(len(sbatch),1)
            self.assertTrue(sbatch[0][-1].endswith('preflight_fullmask512.slurm'))

    def make_passed_preflight(self,root):
        cfg={'fingerprint':'f','output':str(root/'output')}
        jobs={'fingerprint':'f','submissions':[{'stage':0,'kind':'preflight','job':'101','action':'start'}]}
        (root/'jobs.json').write_text(json.dumps(jobs))
        stamp={'fingerprint':'f','stage':0,'comparison_passed':True,'job_id':'101',
               'output':str(root/'output/preflight/fullmask512/job_101')}
        (root/'preflight_fullmask512_passed.json').write_text(json.dumps(stamp))
        return cfg,jobs,stamp

    def test_training_requires_explicit_action_and_completed_preflight(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);cfg,_,_=self.make_passed_preflight(root);calls=[]
            def fake(command,**kwargs):
                calls.append(command)
                return SimpleNamespace(stdout={'squeue':'','sacct':'101|COMPLETED|0:0\n','sbatch':'102\n'}[command[0]])
            with patch.object(submit,'ROOT',root),patch.object(submit.subprocess,'run',side_effect=fake):
                submit.submit(cfg,'train',0)
            sbatch=[c for c in calls if c[0]=='sbatch']
            self.assertEqual(len(sbatch),1);self.assertTrue(sbatch[0][-1].endswith('train_fullmask512.slurm'))

    def test_failed_or_stale_preflight_never_submits_training(self):
        for mode in ('failed','stale','missing','wrong_fingerprint'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as d:
                root=Path(d);cfg,jobs,stamp=self.make_passed_preflight(root)
                path=root/'preflight_fullmask512_passed.json'
                if mode=='missing':path.unlink()
                if mode=='stale':
                    jobs['submissions'].append({'stage':0,'kind':'preflight','job':'103','action':'retry-preflight'})
                    (root/'jobs.json').write_text(json.dumps(jobs))
                if mode=='wrong_fingerprint':
                    stamp['fingerprint']='other';path.write_text(json.dumps(stamp))
                def fake(command,**kwargs):
                    if command[0]=='squeue':return SimpleNamespace(stdout='')
                    if command[0]=='sacct':return SimpleNamespace(stdout='101|FAILED|1:0\n')
                    self.fail('A failing gate attempted sbatch')
                with patch.object(submit,'ROOT',root),patch.object(submit.subprocess,'run',side_effect=fake):
                    with self.assertRaises(RuntimeError):submit.submit(cfg,'train',0)

    def test_retry_submits_preflight_only(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);cfg,_,_=self.make_passed_preflight(root);calls=[]
            def fake(command,**kwargs):
                calls.append(command);return SimpleNamespace(stdout='' if command[0]=='squeue' else '104\n')
            with patch.object(submit,'ROOT',root),patch.object(submit.subprocess,'run',side_effect=fake):
                submit.submit(cfg,'retry-preflight',0)
            sbatch=[c for c in calls if c[0]=='sbatch']
            self.assertEqual(len(sbatch),1);self.assertTrue(sbatch[0][-1].endswith('preflight_fullmask512.slurm'))

    def test_host_report_averages_all_predictions_once(self):
        hs={'predictions':[{'protein_length':2,'predicted_dna':dna,'species':'A'}
                           for dna in ('AAAAAATAA','AAGAAGTAA')],
            'paired_host_comparisons':[{'host_a':'A','host_b':'B','codon_disagreement':x} for x in (0.,1.)]}
        report=submit.host_summary(hs)
        self.assertEqual(report['hosts'][0]['mean_gc3'],.5)
        self.assertEqual(report['hosts'][0]['proteins'],2)
        self.assertEqual(report['host_pairs'][0]['mean_codon_disagreement'],.5)

    def test_ambiguous_submission_cannot_be_retried(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);cfg={'fingerprint':'f','output':str(root/'output')}
            with patch.object(submit,'ROOT',root),patch.object(submit.subprocess,'run',return_value=SimpleNamespace(stdout='unrecognized')):
                with self.assertRaisesRegex(RuntimeError,'Ambiguous'):submit.submit(cfg,'start',0)
                with self.assertRaisesRegex(RuntimeError,'ambiguous'):submit.submit(cfg,'retry-preflight',0)

    def test_all_generated_shell_scripts_parse(self):
        import subprocess
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for stage in range(5):
                for name,body in scripts(root,root/'output',stage).items():
                    path=root/name;path.write_text(body);subprocess.run(['bash','-n',str(path)],check=True)
                    self.assertIn('srun --kill-on-bad-exit=1',body)
                    self.assertIn('--ntasks-per-node=4',body)
                    self.assertIn('bash runtime_python.sh',body)
                    if name.startswith('preflight_'):
                        self.assertIn('OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 bash runtime_python.sh',body)

if __name__=='__main__':unittest.main()
