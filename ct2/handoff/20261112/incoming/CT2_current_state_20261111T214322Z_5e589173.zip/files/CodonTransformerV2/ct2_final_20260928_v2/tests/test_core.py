from __future__ import annotations
import copy
import io
import json
import tempfile
import tarfile
import unittest
from unittest.mock import patch
from pathlib import Path
from types import SimpleNamespace
import torch
from common import STAGES, controls, batch_profile, stage_start, resolve_species
from data_stream import RecordStream, shard_order
from augmentation import TrainingCollator
from phase1_tokens import prepare_sequence, RecordRejected, STANDARD_CODE
from strict_generation import validate_generated_dna
from generation import generate_batch, generation_precision
from model_io import CT2, optimizer_for, build_model
from engine import optimizer_update, rng_state, restore_rng, seed_all, atomic_torch_save
from checks import equal_tree
from diagnostic_metrics import row_statistics, synonymous_groups

torch.set_num_threads(1)

class Tokenizer:
    def __init__(self):
        self.vocab=json.loads((Path(__file__).parent/'tokenizer_fixture.json').read_text())['model']['vocab']
        for name in ('cls','sep','pad','unk','mask'):setattr(self,name+'_token_id',self.vocab['['+name.upper()+']'])
    def get_vocab(self):return self.vocab
    def __len__(self):return len(self.vocab)

class TinyLM(torch.nn.Module):
    def __init__(self,dropout=0.):
        super().__init__();self.emb=torch.nn.Embedding(90,8);self.drop=torch.nn.Dropout(dropout);self.head=torch.nn.Linear(8,90)
        self.config=SimpleNamespace(hidden_size=8,max_position_embeddings=2048)
    def get_input_embeddings(self):return self.emb
    def forward(self,inputs_embeds,attention_mask):
        self.last_vectors=inputs_embeds.detach().clone()
        return SimpleNamespace(logits=self.head(self.drop(inputs_embeds)))

def make_shards(directory,n=8,records=7):
    paths=[]
    for s in range(n):
        path=Path(directory)/f'shard-{s:06d}.tar.gz';paths.append(path)
        with tarfile.open(path,'w:gz') as archive:
            for i in range(records):
                protein='M'+'A'*(1+(s+i)%9)
                doc={'species':s%3,'protein_id':f'{s}-{i}','protein_sequence':protein,'dna_sequence':'ATG'+'GCT'*(len(protein)-1)+'TAA'}
                if i==2:doc['dna_sequence']='TAA'+doc['dna_sequence'][3:]
                data=json.dumps(doc).encode();info=tarfile.TarInfo(f'{s}-{i}.json');info.size=len(data);archive.addfile(info,io.BytesIO(data))
    return paths

def stream(paths,rank=0,world=1):return RecordStream(paths,Tokenizer().vocab,{'a':0,'b':1,'c':2},3,rank,world,seed=321,buffer_size=11)

class DataTests(unittest.TestCase):
    def test_full_permutation_and_disjoint_rank_partitions(self):
        partitions=[shard_order(5874,123,0,r,8) for r in range(8)]
        joined=[i for part in partitions for i in part]
        self.assertEqual(sorted(joined),list(range(5874)))
        self.assertGreater(max(partitions[0][:40]),5000)
        self.assertNotEqual(partitions[0],shard_order(5874,123,1,0,8))

    def test_resume_cursor_buffer_rejections_and_species_counts(self):
        with tempfile.TemporaryDirectory() as d:
            paths=make_shards(d);a=stream(paths)
            a.batch(19,512);state=a.state_dict();expected=a.batch(90,512);end=a.state_dict()
            b=stream(paths);b.load_state_dict(state);actual=b.batch(90,512)
            self.assertEqual(expected,actual);self.assertEqual(end,b.state_dict())
            self.assertGreater(end['counts']['excluded'],0)
            self.assertEqual(sum(end['species'].values()),109)

    def test_raw_distributed_cycle_visits_all_members_once(self):
        with tempfile.TemporaryDirectory() as d:
            paths=make_shards(d);keys=[]
            for rank in range(2):
                s=stream(paths,rank,2)
                for _ in range(4*7):
                    r=s._next_raw();self.assertEqual(r['cycle'],0);keys.append((r['shard'],r['key']))
            self.assertEqual(len(set(keys)),56)

    def test_duplicate_member_aborts(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'bad.tar.gz'
            with tarfile.open(path,'w:gz') as tar:
                for _ in range(2):
                    info=tarfile.TarInfo('same.json');info.size=2;tar.addfile(info,io.BytesIO(b'{}'))
            with self.assertRaisesRegex(ValueError,'Duplicate'):list(RecordStream._records(path))

    def test_translation_filter_and_unknown_codon(self):
        vocab=Tokenizer().vocab
        p=prepare_sequence('GTGGCTNNNTAA','MAA',vocab)
        self.assertEqual(p.text,'m_unk a_gct a_unk __taa')
        self.assertEqual(p.target_positions,(1,3))
        for dna,protein in [('ATGGCTTAA','MX'),('ATGGAATAA','MA'),('ATGTGAGCTTAA','MAA')]:
            with self.assertRaises(RecordRejected):prepare_sequence(dna,protein,vocab)

    def test_species_rejects_unknown_name_and_reserved_id(self):
        self.assertEqual(resolve_species('a',{'a':0},1),0)
        for v in ('0','typo',1,True):
            with self.assertRaises(ValueError):resolve_species(v,{'a':0},1)

class AugmentationTests(unittest.TestCase):
    def setUp(self):
        self.tok=Tokenizer();self.collator=TrainingCollator(self.tok,3)
        self.rows=[{'prepared':prepare_sequence('ATGGCTNNNTAA','MAA',self.tok.vocab),'species_id':i%3} for i in range(512)]

    def test_full_mask_preserves_protein_and_ignores_unknown(self):
        b=self.collator(self.rows,512,1.,0,0)
        allowed={self.tok.vocab[t] for t in ('[CLS]','[SEP]','m_unk','a_unk','__unk')}
        self.assertTrue(set(b['input_ids'].flatten().tolist())<=allowed)
        self.assertTrue(b['labels'][:,3].eq(-100).all())
        self.assertEqual(int(b['labels'].ne(-100).sum()),512*3)

    def test_full_mask_rng_independent_of_species_and_global_rng(self):
        before=torch.get_rng_state().clone()
        a=self.collator(self.rows,512,0.,10,0);b=self.collator(self.rows,512,.05,10,0)
        self.assertTrue(torch.equal(a['species_id'],b['species_id']))
        self.assertTrue(torch.equal(a['input_ids'][~b['full']],b['input_ids'][~b['full']]))
        self.assertTrue(torch.equal(before,torch.get_rng_state()))
        self.assertTrue(.08<float(b['unknown'].float().mean())<.16)

    def test_schedules_and_effective_batch(self):
        for i,s in enumerate(STAGES):
            self.assertEqual(controls(i,s['steps']-1)[1],s['full'][1])
            self.assertAlmostEqual(controls(i,s['steps']-1)[2],s['lr'][1])
            self.assertEqual(controls(i,4000)[0],s['lengths'][1])
        self.assertAlmostEqual(controls(0,999)[2],2e-5)
        for length in (512,1024,2048):
            for divisor in (1,2,4,8):
                b,a=batch_profile(length,divisor);self.assertEqual(b*a*8,1536)

class TrainingTests(unittest.TestCase):
    def test_unequal_rank_target_weighting_before_ddp_average(self):
        seed_all(87);tok=Tokenizer();base=CT2(TinyLM(),4,.0347)
        rows=[{'prepared':prepare_sequence('ATG'+'GCT'*n+'TAA','M'+'A'*n,tok.vocab),'species_id':i%3} for i,n in enumerate((1,8,2,7,3))]
        b=TrainingCollator(tok,3)(rows,512,1.,0,0);target_count=int(b['labels'].ne(-100).sum())
        gradients=[]
        for spans in (((0,1),(1,2)),((2,3),(3,5))):
            model=copy.deepcopy(base);opt,_=optimizer_for(model)
            parts=[{k:v[a:z].clone() for k,v in b.items()} for a,z in spans]
            def reduction(t):return torch.tensor(target_count) if t.ndim==0 else t
            with patch('engine.world',return_value=2),patch('engine.sum_tensor',side_effect=reduction),patch.object(opt,'step'):
                optimizer_update(model,opt,parts,torch.device('cpu'),1e-4,clip=1e10)
            gradients.append([p.grad.clone() for p in model.parameters()])
        opt,_=optimizer_for(base)
        with patch.object(opt,'step'):optimizer_update(base,opt,[b],torch.device('cpu'),1e-4,clip=1e10)
        for p,a,c in zip(base.parameters(),*gradients):torch.testing.assert_close(p.grad,(a+c)/2,rtol=1e-5,atol=1e-7)

    def test_accumulation_uses_global_token_mean(self):
        seed_all(87);tok=Tokenizer();m=CT2(TinyLM(),4,.0347);reference=copy.deepcopy(m)
        optimizer,_=optimizer_for(m);other,_=optimizer_for(reference)
        rows=[{'prepared':prepare_sequence('ATG'+'GCT'*n+'TAA','M'+'A'*n,tok.vocab),'species_id':i%3} for i,n in enumerate((1,8,2,7,3))]
        collator=TrainingCollator(tok,3);all_batch=collator(rows,512,1.,0,0)
        parts=[{k:v[a:b].clone() for k,v in all_batch.items()} for a,b in ((0,1),(1,3),(3,5))]
        optimizer_update(m,optimizer,parts,torch.device('cpu'),1e-4)
        optimizer_update(reference,other,[all_batch],torch.device('cpu'),1e-4)
        for a,b in zip(m.parameters(),reference.parameters()):torch.testing.assert_close(a,b,atol=1e-7,rtol=1e-6)

    def test_actual_save_resume_with_adamw_dropout_and_buffer(self):
        with tempfile.TemporaryDirectory() as d:
            paths=make_shards(d);s=stream(paths);tok=Tokenizer();collator=TrainingCollator(tok,3)
            seed_all(13);model=CT2(TinyLM(.25),4,.0347);optimizer,names=optimizer_for(model)
            def step(m,o,s,n):
                batches=[collator(s.batch(3,512),512,.15,n,j) for j in range(2)]
                return optimizer_update(m,o,batches,torch.device('cpu'),2e-5)
            for i in range(6):step(model,optimizer,s,i)
            state={'state_dict':copy.deepcopy(model.state_dict()),'optimizer_states':[optimizer.state_dict()],
                   'optimizer_parameter_names':names,'global_step':6,'stream':s.state_dict(),'rng':rng_state()}
            path=Path(d)/'saved.pt';atomic_torch_save(path,state)
            for i in range(6,12):step(model,optimizer,s,i)
            final_rng=rng_state();final_stream=s.state_dict()
            saved=torch.load(path,weights_only=False);resumed=CT2(TinyLM(.25),4,.0347);resumed.load_state_dict(saved['state_dict'],strict=True)
            opt,_=optimizer_for(resumed,saved);rs=stream(paths);rs.load_state_dict(saved['stream']);restore_rng(saved['rng'])
            for i in range(6,12):step(resumed,opt,rs,i)
            equal_tree(model.state_dict(),resumed.state_dict());equal_tree(optimizer.state_dict(),opt.state_dict())
            equal_tree(final_rng,rng_state());equal_tree(final_stream,rs.state_dict())

    def test_synonymous_accuracy_is_native_codon_recovery(self):
        tok=Tokenizer();groups=torch.tensor(synonymous_groups(tok.vocab));logits=torch.zeros(1,1,90)
        # Both alanine codons are amino-acid-valid, but only GCT is the native target.
        logits[0,0,tok.vocab['a_gcc']]=9.;labels=torch.tensor([[tok.vocab['a_gct']]])
        row=row_statistics(logits,labels,groups)
        self.assertEqual(float(row[0,3]),0.);self.assertEqual(float(row[0,4]),0.)

class GenerationTests(unittest.TestCase):
    def test_generation_precision_is_scoped_and_cpu_uses_highest(self):
        previous=torch.get_float32_matmul_precision()
        try:
            for initial in ('highest','medium'):
                torch.set_float32_matmul_precision(initial)
                with self.assertRaisesRegex(ValueError,'fixture'):
                    with generation_precision('cpu'):
                        self.assertEqual(torch.get_float32_matmul_precision(),'highest')
                        raise ValueError('fixture')
                self.assertEqual(torch.get_float32_matmul_precision(),initial)
            torch.set_float32_matmul_precision('highest')
            with generation_precision('cuda'):
                self.assertEqual(torch.get_float32_matmul_precision(),'medium')
            self.assertEqual(torch.get_float32_matmul_precision(),'highest')
        finally:torch.set_float32_matmul_precision(previous)

    def test_generation_cli_does_not_publish_partial_batch_output(self):
        import generation
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);src=root/'input.jsonl';out=root/'output.jsonl';cp=root/'checkpoint.ckpt';cp.write_text('fixture')
            mapping=root/'map.json';mapping.write_text('{"host":0}')
            cfg={'mapping':str(mapping),'mapping_sha256':'fixture','checkpoints':{}}
            src.write_text(json.dumps({'protein_sequence':'MA','species':0})+'\n'+json.dumps({'protein_sequence':'MX','species':0})+'\n')
            argv=['generation.py','--checkpoint',str(cp),'--input',str(src),'--output',str(out),'--batch-size','1','--device','cpu']
            precision_before=torch.get_float32_matmul_precision()
            with patch('sys.argv',argv),patch.object(generation,'load_run',return_value=cfg),patch.object(generation,'source_path'),\
                 patch.object(generation,'tokenizer_at',return_value=Tokenizer()),patch.object(generation,'read_checkpoint',return_value={'ct2_format':1}),\
                 patch.object(generation,'build_model',return_value=CT2(TinyLM(),28678,.0347)):
                with self.assertRaises(ValueError):generation.main()
            self.assertEqual(torch.get_float32_matmul_precision(),precision_before)
            self.assertFalse(out.exists());self.assertEqual(list(root.glob('*.tmp.*')),[])

    def test_boundaries_terminal_stop_scale_and_invalid_residues(self):
        tok=Tokenizer();m=CT2(TinyLM(),4,.0347)
        records=[{'protein_id':'limit','protein_sequence':'M'+'A'*2044,'species':0}]
        output=generate_batch(m,tok,records,{'a':0,'b':1,'c':2},3)
        self.assertEqual(output[0]['protein_length'],2045)
        validate_generated_dna(output[0]['predicted_dna'],records[0]['protein_sequence'])
        self.assertEqual(len(output[0]['predicted_dna']),3*2046)
        expected=m.model.emb(torch.tensor([[tok.cls_token_id]]))+m.species_embed(torch.tensor([0]))[:,None,:]*.0347
        torch.testing.assert_close(m.model.last_vectors[:,:1],expected)
        for protein in ('M'+'A'*2045,'MX','M*AA'):
            with self.assertRaises(ValueError):generate_batch(m,tok,[{'protein_sequence':protein,'species':0}],{'a':0},3)
        with self.assertRaises(ValueError):generate_batch(m,tok,[{'protein_sequence':'MA','species':'unknown'}],{'a':0},3)

    def test_real_modernbert_checkpoint_strict_load_and_forward(self):
        from transformers import ModernBertConfig,ModernBertForMaskedLM
        tok=Tokenizer();config=ModernBertConfig(vocab_size=90,hidden_size=16,num_hidden_layers=2,num_attention_heads=2,
            intermediate_size=32,max_position_embeddings=2048,pad_token_id=tok.pad_token_id,cls_token_id=tok.cls_token_id,
            sep_token_id=tok.sep_token_id,attn_implementation='sdpa',reference_compile=False)
        m=CT2(ModernBertForMaskedLM(config),28678,.0347)
        cfg={'fingerprint':'fixture','mapping_sha256':'mapping'}
        cp={'ct2_format':1,'fingerprint':'fixture','mapping_sha256':'mapping','model_config':config.to_dict(),
            'species_embed_scale':.0347,'state_dict':m.state_dict()}
        loaded=build_model(cp,tok,cfg)
        record={'protein_sequence':'MACDEFGHIKLMNPQRSTVWY','species':0}
        dna=generate_batch(loaded,tok,[record],{'a':0},1)[0]['predicted_dna']
        validate_generated_dna(dna,record['protein_sequence'])
        cp['state_dict']=dict(cp['state_dict']);del cp['state_dict']['species_embed.weight']
        with self.assertRaises(RuntimeError):build_model(cp,tok,cfg)

if __name__=='__main__':unittest.main()
