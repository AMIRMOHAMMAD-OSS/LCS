#!/usr/bin/env python3
"""Read-only audit of CT2's saved H100 preflight resume comparison.

Place beside the sealed v2 run.json and run:
    python3 ct2_resume_audit.py submit
    python3 ct2_resume_audit.py report

Requests one CPU task (8 cores, 20 minutes) from nef@cpu/qos_cpu-dev.
No GPUs, explicit memory flags, training, source changes, tolerance changes,
or preflight pass stamps. The job reads the three existing smoke checkpoints.
CPU work uses the same H100 software module but does not allocate/use a GPU.
Both submission and inspection preserve the sealed files and training jobs.json.
"""
from __future__ import annotations

import argparse
import fcntl
import json
import math
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time

DEFAULT_RUN = Path('/lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2/ct2_final_20260928_v2')
JOB_NAME = 'ct2_resume_audit'
RTOL, ATOL = 1e-5, 2e-6


def emit(name, value):
    print(name + ':', json.dumps(value, sort_keys=True, allow_nan=False), flush=True)


def setup(root, failed_job):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root))
    from common import load_run
    cfg = load_run(root)
    if cfg.get('version') != 2 or not failed_job.isdigit():
        raise RuntimeError('Expected the sealed v2 installation and a numeric preflight job ID.')
    output = Path(cfg['output']).resolve()
    if not output.is_relative_to(Path('/lustre/fswork')):
        raise RuntimeError('Expected results on WORK.')
    source = output / 'preflight' / 'fullmask512' / ('job_' + failed_job)
    for rel in ('hardware_checks.json', 'reference/step_000016.ckpt', 'reference/step_000032.ckpt',
                'resumed/step_000032.ckpt'):
        if not (source / rel).is_file():
            raise FileNotFoundError(source / rel)
    destination = output / 'diagnostics' / ('resume_audit_' + failed_job)
    emit('SEALED_RUN_VERIFIED', {'fingerprint': cfg['fingerprint'], 'source': str(source)})
    return cfg, source, destination


def request(root, failed_job, runner, digest, fingerprint):
    log = root / 'logs' / (JOB_NAME + '_%j.out')
    cmd = ['sbatch', '--parsable', '--job-name=' + JOB_NAME, '--account=nef@cpu',
           '--partition=cpu_p1', '--qos=qos_cpu-dev', '--nodes=1', '--ntasks=1',
           '--cpus-per-task=8', '--time=00:20:00', '--hint=nomultithread', '--no-requeue',
           '--chdir=' + str(root), '--output=' + str(log), '--error=' + str(log)]
    run = ['bash', str(root / 'runtime_python.sh'), '-u', str(runner), 'run',
           '--run-dir', str(root), '--failed-job', failed_job, '--runner-sha', digest,
           '--fingerprint', fingerprint]
    body = '\n'.join([
        '#!/bin/bash', 'set -euo pipefail', 'module purge', 'module load arch/h100',
        'module load pytorch-gpu/py3/2.6.0',
        'export CUDA_VISIBLE_DEVICES="" OMP_NUM_THREADS=8 MKL_NUM_THREADS=8',
        'export PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1',
        'export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false',
        'export PYTHONPATH="$PWD:$PWD/source${PYTHONPATH:+:$PYTHONPATH}"',
        'exec ' + shlex.join(run), '',
    ])
    return cmd, body, log


def submit(root, failed_job, new_job=False):
    cfg, source, destination = setup(root, failed_job)
    from common import atomic_json, sha
    destination.mkdir(parents=True, exist_ok=True)
    (root / 'logs').mkdir(exist_ok=True)
    receipt_path = destination / 'submission.json'
    with (destination / 'submission.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if receipt_path.exists():
            old = json.loads(receipt_path.read_text())
            if old['fingerprint'] != cfg['fingerprint']:
                raise RuntimeError('Audit receipt belongs to a different sealed run.')
            if old.get('job_id') and not new_job:
                emit('ALREADY_SUBMITTED', {k: old[k] for k in ('job_id', 'log')})
                return
            if not old.get('job_id') and old.get('state') != 'rejected':
                raise RuntimeError('Earlier submission is ambiguous; inspect squeue before retrying.')
        live = subprocess.run(['squeue', '--noheader', '--user=' + str(os.getuid()),
                               '--name=' + JOB_NAME, '--format=%i'],
                              check=True, text=True, capture_output=True)
        if live.stdout.strip():
            raise RuntimeError('An audit is already queued/running: ' + live.stdout.strip())
        runner = Path(__file__).resolve()
        command, body, log = request(root, failed_job, runner, sha(runner), cfg['fingerprint'])
        subprocess.run(['bash', '-n'], input=body, text=True, check=True)
        receipt = {'fingerprint': cfg['fingerprint'], 'job_id': None, 'state': 'submitting',
                   'runner_sha256': sha(runner), 'submitted_at_unix': time.time(),
                   'command': command, 'script': body, 'failed_job': failed_job}
        attempt = destination / ('submission_' + str(time.time_ns()) + '.json')
        atomic_json(receipt_path, receipt)
        atomic_json(attempt, receipt)
        completed = subprocess.run(command, input=body, text=True, capture_output=True)
        match = re.fullmatch(r'(\d+)(?:;[^\s;]+)?', completed.stdout.strip())
        receipt.update(sbatch_returncode=completed.returncode, sbatch_stdout=completed.stdout,
                       sbatch_stderr=completed.stderr, state='ambiguous')
        if completed.returncode == 0 and match:
            receipt.update(job_id=match.group(1), state='submitted', log=str(log).replace('%j', match.group(1)))
        elif completed.returncode and not completed.stdout.strip() and 'Batch job submission failed:' in completed.stderr:
            receipt['state'] = 'rejected'
        atomic_json(receipt_path, receipt)
        atomic_json(attempt, receipt)
        if receipt['state'] != 'submitted':
            raise RuntimeError('Audit submission ' + receipt['state'] + ': ' + completed.stderr + repr(completed.stdout))
        emit('CPU_AUDIT_SUBMITTED', {k: receipt[k] for k in ('job_id', 'log')})
        print('CPU checkpoint inspection only. No GPU, preflight or training job was submitted.', flush=True)


def difference(a, b, origin=None):
    """Chunked, CPU-only statistics. Test closeness in the original tensor dtype."""
    import torch
    if a.shape != b.shape or a.dtype != b.dtype:
        raise ValueError('Compared tensors have different shape or dtype.')
    if origin is not None and (origin.shape != a.shape or origin.dtype != a.dtype):
        raise ValueError('Boundary tensor shape/dtype mismatch.')
    if a.is_complex():
        raise ValueError('Complex checkpoint tensor is not supported.')
    n = a.numel()
    if not a.is_floating_point():
        return {'elements': n, 'dtype': str(a.dtype), 'exact': bool(torch.equal(a, b))}
    flat_a, flat_b = a.reshape(-1), b.reshape(-1)
    flat_origin = origin.reshape(-1) if origin is not None else None
    changed = mismatches = 0
    max_abs = max_ratio = sum_abs = diff_sq = ref_sq = update_sq = 0.
    for start in range(0, n, 262144):
        x, y = flat_a[start:start + 262144], flat_b[start:start + 262144]
        if not torch.isfinite(x).all() or not torch.isfinite(y).all():
            raise FloatingPointError('Nonfinite tensor in checkpoint comparison.')
        changed += int(x.ne(y).sum())
        mismatches += int((~torch.isclose(x, y, rtol=RTOL, atol=ATOL)).sum())
        dx, dy = x.double(), y.double()
        delta = dx - dy
        absolute = delta.abs()
        max_abs = max(max_abs, float(absolute.max()))
        max_ratio = max(max_ratio, float((absolute / (ATOL + RTOL * dy.abs())).max()))
        sum_abs += float(absolute.sum())
        diff_sq += float(delta.square().sum())
        ref_sq += float(dx.square().sum())
        if flat_origin is not None:
            z = flat_origin[start:start + 262144].double()
            if not torch.isfinite(z).all():
                raise FloatingPointError('Nonfinite boundary tensor.')
            update_sq += float((dx - z).square().sum())
    out = {'elements': n, 'dtype': str(a.dtype), 'changed_elements': changed,
           'mismatches_at_original_tolerance': mismatches, 'max_abs': max_abs,
           'mean_abs': sum_abs / n if n else 0., 'rms_difference': math.sqrt(diff_sq / n) if n else 0.,
           'relative_l2': math.sqrt(diff_sq / ref_sq) if ref_sq else None,
           'max_tolerance_ratio': max_ratio, 'difference_l2_squared': diff_sq,
           'reference_l2_squared': ref_sq}
    if origin is not None:
        out.update(reference_update_l2_squared=update_sq,
                   difference_over_reference_update_l2=math.sqrt(diff_sq / update_sq) if update_sq else None)
    return out


def tree_rows(a, b, path='root', origin=None):
    import torch
    if torch.is_tensor(a):
        return [{'path': path, **difference(a, b, origin)}]
    if isinstance(a, dict):
        if not isinstance(b, dict) or a.keys() != b.keys():
            raise ValueError('Key mismatch: ' + path)
        return [row for key in a for row in tree_rows(a[key], b[key], path + '.' + str(key),
                                                    origin[key] if origin is not None else None)]
    if isinstance(a, (list, tuple)):
        if len(a) != len(b):
            raise ValueError('Length mismatch: ' + path)
        return [row for i, (x, y) in enumerate(zip(a, b)) for row in tree_rows(x, y, path + f'[{i}]',
                                                                           origin[i] if origin is not None else None)]
    if a != b:
        raise ValueError(f'Metadata mismatch at {path}: {a!r} vs {b!r}')
    return []


def summarize(rows):
    floating = [r for r in rows if 'max_abs' in r]
    return {'tensor_count': len(rows), 'floating_tensor_count': len(floating),
            'failing_float_tensors': sum(r['mismatches_at_original_tolerance'] > 0 for r in floating),
            'failing_nonfloat_tensors': sum(r.get('exact') is False for r in rows),
            'mismatched_float_elements': sum(r['mismatches_at_original_tolerance'] for r in floating),
            'float_elements': sum(r['elements'] for r in floating),
            'max_abs': max((r['max_abs'] for r in floating), default=0.),
            'worst_12_by_tolerance_ratio': sorted(floating, key=lambda r: r['max_tolerance_ratio'], reverse=True)[:12]}


def audit(root, failed_job, runner_sha, fingerprint):
    cfg, source, destination = setup(root, failed_job)
    from common import sha, atomic_json
    if not runner_sha or sha(__file__) != runner_sha or cfg['fingerprint'] != fingerprint:
        raise RuntimeError('Runner or sealed run changed since submission.')
    job = os.environ.get('SLURM_JOB_ID', '')
    if not job.isdigit() or os.environ.get('SLURM_NTASKS') != '1':
        raise RuntimeError('Use submit to run this inspection on a compute node.')
    import torch
    from checks import check_checkpoint, equal_tree
    torch.set_num_threads(8)
    if torch.__version__.split('+')[0] != '2.6.0':
        raise RuntimeError('Use the reviewed PyTorch 2.6.0 module.')
    report = {'fingerprint': cfg['fingerprint'], 'failed_job': failed_job, 'audit_job': job,
              'scope': 'read_only_CPU_inspection; not a preflight pass',
              'tolerance': {'rtol': RTOL, 'atol': ATOL}, 'torch': torch.__version__,
              'source': str(source), 'runner_sha256': runner_sha}
    checkpoints = []
    report['files'] = []
    for rel, step, mode in (('reference/step_000016.ckpt', 16, 'smoke-reference'),
                            ('reference/step_000032.ckpt', 32, 'smoke-reference'),
                            ('resumed/step_000032.ckpt', 32, 'smoke-resume')):
        path = source / rel
        emit('READING_CHECKPOINT', str(path))
        before = path.stat()
        cp = torch.load(path, map_location='cpu', weights_only=False, mmap=True)
        check_checkpoint(cp, cfg, 0, step, mode)
        checkpoints.append(cp)
        report['files'].append({'path': str(path), 'bytes': before.st_size, 'mtime_ns': before.st_mtime_ns})
    origin, reference, resumed = checkpoints
    equal_tree(reference['rank_states'], resumed['rank_states'])
    equal_tree(reference['model_config'], resumed['model_config'])
    equal_tree(origin['model_config'], reference['model_config'])
    equal_tree(reference['optimizer_parameter_names'], resumed['optimizer_parameter_names'])
    equal_tree(origin['optimizer_parameter_names'], reference['optimizer_parameter_names'])
    count_indices = (1, 3, 4, 5, 6, 7)
    equal_tree([reference['statistics']['totals'][i] for i in count_indices],
               [resumed['statistics']['totals'][i] for i in count_indices])
    report['exact_checks'] = {'rank_streams_and_rng': True, 'serialized_model_config': True,
                              'optimizer_parameter_order': True, 'draw_and_target_counts': True,
                              'all_three_checkpoint_integrity_checks': True}
    emit('EXACT_CHECKS', report['exact_checks'])
    config_keys = ('attention_dropout', 'embedding_dropout', 'mlp_dropout', 'classifier_dropout',
                   'reference_compile', '_attn_implementation', 'deterministic_flash_attn', 'torch_dtype')
    report['saved_execution_settings'] = {k: reference['model_config'].get(k, '<not saved>') for k in config_keys}
    report['execution_note'] = ('Serialized settings are not a record of the kernels used. '
                                'Transformers 4.51.3 ModernBertConfig.to_dict omits reference_compile.')
    emit('SAVED_EXECUTION_SETTINGS', report['saved_execution_settings'])
    model_rows = tree_rows(reference['state_dict'], resumed['state_dict'], origin=origin['state_dict'])
    report['model_tensors'] = model_rows
    report['model_summary'] = summarize(model_rows)
    emit('MODEL_DIFFERENCES', report['model_summary'])
    report['optimizer_tensors'] = tree_rows(reference['optimizer_states'], resumed['optimizer_states'])
    report['optimizer_summary'] = summarize(report['optimizer_tensors'])
    emit('OPTIMIZER_DIFFERENCES', report['optimizer_summary'])
    norms_a, norms_b = reference['statistics']['grad_norms'], resumed['statistics']['grad_norms']
    if len(norms_a) != 32 or len(norms_b) != 32:
        raise ValueError('Expected the complete 32-update gradient histories.')
    equal_tree(norms_a[:16], norms_b[:16])
    equal_tree(origin['statistics']['grad_norms'], norms_a[:16])
    report['gradient_history_after_resume'] = [
        {'step': i + 1, 'reference': norms_a[i], 'resumed': norms_b[i],
         'absolute_difference': abs(norms_a[i] - norms_b[i])} for i in range(16, 32)]
    emit('GRADIENT_HISTORY_AFTER_RESUME', report['gradient_history_after_resume'])
    hardware = json.loads((source / 'hardware_checks.json').read_text())
    if hardware['fingerprint'] != cfg['fingerprint'] or hardware['stage'] != 0:
        raise ValueError('Hardware report belongs to a different run or stage.')
    report['hardware_checks'] = hardware
    emit('HARDWARE_MEMORY', hardware['memory'])
    pattern = re.compile(r'recompile|cache_size_limit|recompile_limit|torch\._dynamo|inductor|autotun|non.?determin', re.I)
    report['compiler_log_matches'] = []
    for suffix in ('out', 'err'):
        path = root / 'logs' / f'ct2_check_fullmask512_{failed_job}.{suffix}'
        if path.exists():
            for line_number, line in enumerate(path.read_text(errors='replace').splitlines(), 1):
                if pattern.search(line):
                    report['compiler_log_matches'].append({'file': path.name, 'line': line_number, 'text': line})
    emit('COMPILER_LOG_MATCHES', report['compiler_log_matches'][:40])
    for item in report['files']:
        stat = Path(item['path']).stat()
        if (stat.st_size, stat.st_mtime_ns) != (item['bytes'], item['mtime_ns']):
            raise RuntimeError('An input checkpoint changed during inspection.')
    setup(root, failed_job)
    path = destination / ('audit_' + job + '.json')
    if path.exists():
        raise FileExistsError(path)
    atomic_json(path, report)
    print('CPU_AUDIT_REPORT:', path, flush=True)
    print('CPU_AUDIT_FINISHED: measurements only; no training or preflight approval.', flush=True)


def report(root, failed_job):
    cfg, source, destination = setup(root, failed_job)
    receipt = json.loads((destination / 'submission.json').read_text())
    if receipt['fingerprint'] != cfg['fingerprint'] or not receipt.get('job_id'):
        raise RuntimeError('No confirmed audit submission for this sealed run.')
    emit('AUDIT_JOB', {k: receipt[k] for k in ('job_id', 'log')})
    path = destination / ('audit_' + receipt['job_id'] + '.json')
    if not path.exists():
        print('NOT_YET_AVAILABLE: check the job log above.')
        return
    item = json.loads(path.read_text())
    if item['fingerprint'] != cfg['fingerprint']:
        raise RuntimeError('Audit belongs to a different sealed run.')
    for key in ('exact_checks', 'saved_execution_settings', 'model_summary', 'optimizer_summary',
                'gradient_history_after_resume', 'compiler_log_matches'):
        emit(key.upper(), item[key])
    print('CPU_AUDIT_REPORT:', path)
    print('Inspection only; no preflight or training was authorized.')


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('action', choices=('submit', 'run', 'report'))
    parser.add_argument('--run-dir', type=Path, default=DEFAULT_RUN)
    parser.add_argument('--failed-job', default='265592')
    parser.add_argument('--new-job', action='store_true')
    parser.add_argument('--runner-sha', help=argparse.SUPPRESS)
    parser.add_argument('--fingerprint', help=argparse.SUPPRESS)
    args = parser.parse_args()
    root = args.run_dir.resolve()
    if args.action == 'submit':
        submit(root, args.failed_job, args.new_job)
    elif args.action == 'run':
        audit(root, args.failed_job, args.runner_sha, args.fingerprint)
    else:
        report(root, args.failed_job)


if __name__ == '__main__':
    main()
