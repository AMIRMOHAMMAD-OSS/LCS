#!/usr/bin/env python3
"""Fail closed on altered inputs, incomplete checkpoints, or non-reproducible stream resumes."""
from __future__ import annotations
import argparse
import json
import math
import os
from datetime import datetime,timezone
from importlib.metadata import version
from pathlib import Path
from common import ROOT, load_run, VERSIONS, STAGES, stage_start, inventory, atomic_json, sha

def inputs(cfg):
    actual={k:version(k).split('+')[0] for k in VERSIONS}
    if actual!=VERSIONS:raise RuntimeError(f'Use the reviewed pytorch-gpu/py3/2.6.0 module; got {actual}')
    if inventory(cfg['data_root'])!=cfg['shards']:raise RuntimeError('Training shard names/sizes/mtimes changed')
    for name,info in cfg['checkpoints'].items():
        p=Path(info['path']);s=p.stat()
        if [s.st_size,s.st_mtime_ns]!=info['stat']:raise RuntimeError(f'Source checkpoint changed: {name}')
    print('CT2_INPUTS_VERIFIED',flush=True)

def equal_tree(a,b,close=False,path='root'):
    import numpy as np
    import torch
    if torch.is_tensor(a):
        if close and a.is_floating_point():torch.testing.assert_close(a,b,rtol=1e-5,atol=2e-6,msg=path)
        elif not torch.equal(a,b):raise ValueError(f'Tensor mismatch: {path}')
    elif isinstance(a,np.ndarray):
        if not np.array_equal(a,b):raise ValueError(f'Array mismatch: {path}')
    elif isinstance(a,dict):
        if a.keys()!=b.keys():raise ValueError(f'Keys mismatch: {path}')
        for k in a:equal_tree(a[k],b[k],close,path+'.'+str(k))
    elif isinstance(a,(list,tuple)):
        if len(a)!=len(b):raise ValueError(f'Length mismatch: {path}')
        for i,(x,y) in enumerate(zip(a,b)):equal_tree(x,y,close,path+f'[{i}]')
    elif a!=b:raise ValueError(f'Value mismatch: {path}: {a!r} vs {b!r}')

def check_checkpoint(cp,cfg,stage,stage_steps,mode=None):
    import torch
    total=stage_start(stage)+stage_steps
    required={'fingerprint':cfg['fingerprint'],'stage':stage,'stage_step':stage_steps,
              'continuation_step':total,'global_step':cfg['source_step']+total,'world_size':8,'ct2_format':1}
    if mode:required['mode']=mode
    for k,value in required.items():
        if cp.get(k)!=value:raise ValueError(f'Checkpoint {k}: {cp.get(k)!r} != {value!r}')
    if cp['schedule']!={'stage':stage,'completed':stage_steps}:raise ValueError('Schedule counter mismatch')
    if len(cp['rank_states'])!=8:raise ValueError('Missing rank state')
    for r,local in enumerate(cp['rank_states']):
        s=local['stream']
        if s['rank']!=r or s['world']!=8 or s['counts']['accepted']!=192*total:raise ValueError('Data-cursor draw mismatch')
        if sum(s['species'].values())!=s['counts']['accepted']:raise ValueError('Species draw counts do not reconcile')
        if s['counts']['examined']!=s['counts']['accepted']+s['counts'].get('excluded',0):raise ValueError('Filter counts do not reconcile')
    for key,tensor in cp['state_dict'].items():
        if tensor.is_floating_point() and not torch.isfinite(tensor).all():raise ValueError(f'Nonfinite model tensor: {key}')
    if len(cp['optimizer_states'])!=1:raise ValueError('Missing optimizer')
    for state in cp['optimizer_states'][0]['state'].values():
        if int(state['step'])!=cfg['source_step']+total:raise ValueError('AdamW step mismatch')
        if any(torch.is_tensor(t) and not torch.isfinite(t).all() for t in state.values()):raise ValueError('Nonfinite optimizer')

def compare(cfg,stage,output):
    import torch
    torch.set_num_threads(8)
    h=json.loads((output/'hardware_checks.json').read_text())
    if h['fingerprint']!=cfg['fingerprint'] or h['stage']!=stage:raise ValueError('Missing matching hardware checks')
    a=torch.load(output/'reference/last.ckpt',weights_only=False,map_location='cpu',mmap=True)
    b=torch.load(output/'resumed/last.ckpt',weights_only=False,map_location='cpu',mmap=True)
    check_checkpoint(a,cfg,stage,32,'smoke-reference');check_checkpoint(b,cfg,stage,32,'smoke-resume')
    equal_tree(a['rank_states'],b['rank_states'])
    equal_tree(a['state_dict'],b['state_dict'],close=True)
    equal_tree(a['optimizer_states'],b['optimizer_states'],close=True)
    equal_tree([a['statistics']['totals'][i] for i in (1,3,4,5,6,7)],
               [b['statistics']['totals'][i] for i in (1,3,4,5,6,7)])
    checks={'fingerprint':cfg['fingerprint'],'stage':stage,'output':str(output),'job_id':os.environ.get('SLURM_JOB_ID'),
        'updates':32,'resume_boundary':16,
        'exact_rng_and_stream_match':True,'weight_and_moment_tolerance':{'rtol':1e-5,'atol':2e-6},
        'comparison_passed':True,'checked_utc':datetime.now(timezone.utc).isoformat()}
    atomic_json(output/'resume_comparison.json',checks)
    atomic_json(ROOT/f'preflight_{STAGES[stage]["name"]}_passed.json',checks)
    print('CT2_PREFLIGHT_PASSED',STAGES[stage]['name'],flush=True)

def completed(cfg,stage):
    import torch
    torch.set_num_threads(8)
    output=Path(cfg['output'])/'training'/STAGES[stage]['name']
    cp=torch.load(output/'last.ckpt',map_location='cpu',weights_only=False,mmap=True)
    check_checkpoint(cp,cfg,stage,STAGES[stage]['steps'],'full')
    review=json.loads((output/'evaluation_latest.json').read_text())
    if review['fingerprint']!=cfg['fingerprint'] or review['continuation_step']!=cp['continuation_step']:raise ValueError('Final review missing')
    done=json.loads((output/'completed.json').read_text())
    if done['continuation_step']!=cp['continuation_step']:raise ValueError('Missing completion record')
    atomic_json(output/'verified_complete.json',{'fingerprint':cfg['fingerprint'],'stage':stage,
        'continuation_step':cp['continuation_step'],'checkpoint_sha256':sha(output/'last.ckpt')})
    print('CT2_COMPLETION_VERIFIED',STAGES[stage]['name'],flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['inputs','compare','completed'])
    p.add_argument('--stage',type=int,choices=range(len(STAGES)));p.add_argument('--output',type=Path);a=p.parse_args();cfg=load_run()
    if a.action=='inputs':inputs(cfg)
    elif a.stage is None:p.error('--stage is required')
    elif a.action=='compare':
        if a.output is None:p.error('--output is required')
        compare(cfg,a.stage,a.output)
    else:completed(cfg,a.stage)
