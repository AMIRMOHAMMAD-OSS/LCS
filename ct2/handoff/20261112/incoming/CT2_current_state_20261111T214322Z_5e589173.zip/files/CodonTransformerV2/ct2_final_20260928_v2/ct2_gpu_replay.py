#!/usr/bin/env python3
"""Isolate CT2 resume divergence on ONE H100 using the existing step-16 checkpoint.

Requires ct2_resume_audit.py already present in the sealed v2 directory.
    python3 ct2_gpu_replay.py submit
    python3 ct2_gpu_replay.py report

One H100 / development QoS / 45-minute limit. No production training or pass
stamp. Replays updates 17--24, checkpointing at 20; a fresh process resumes
21--24. All eight saved data streams are processed sequentially on one GPU,
with the same per-rank microbatches and global token-mean loss. This removes
DDP/NCCL from the experiment; it is NOT an eight-GPU preflight replacement.

Four separate execution profiles: original, no_compile, no_cudnn, controlled.
The controlled profile disables compilation/cuDNN SDPA, enables deterministic
algorithms and full-precision FP32 matmuls/BF16 GEMM reductions. Forward
autocast stays BF16. Training files, hyperparameters and pass criteria remain
unchanged. Each profile runs in fresh processes and writes separate diagnostic
checkpoints on WORK. Approximately 18 GB of output for all four profiles.
"""
from __future__ import annotations

import argparse
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time
import traceback

DEFAULT_RUN = Path('/lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2/ct2_final_20260928_v2')
JOB_NAME = 'ct2_gpu_replay'
PROFILES = ('original', 'no_compile', 'no_cudnn', 'controlled')


def emit(name, value):
    print(name + ':', json.dumps(value, sort_keys=True, allow_nan=False), flush=True)


def setup(root, failed_job):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root))
    import ct2_resume_audit as audit_helper
    cfg, source, _ = audit_helper.setup(root, failed_job)
    output = Path(cfg['output']) / 'diagnostics' / ('gpu_replay_' + failed_job)
    return cfg, source, output


def shell_request(root, failed_job, runner_sha, audit_sha, fingerprint):
    log = root / 'logs' / (JOB_NAME + '_%j.out')
    command = ['sbatch', '--parsable', '--job-name=' + JOB_NAME, '--account=nef@h100',
               '--partition=gpu_p6', '--constraint=h100', '--qos=qos_gpu_h100-dev',
               '--nodes=1', '--ntasks=1', '--gres=gpu:1', '--cpus-per-task=8',
               '--time=00:45:00', '--hint=nomultithread', '--no-requeue',
               '--chdir=' + str(root), '--output=' + str(log), '--error=' + str(log)]
    run = ['srun', '--kill-on-bad-exit=1', 'bash', str(root / 'runtime_python.sh'),
           '-u', str(Path(__file__).resolve()), 'run', '--run-dir', str(root),
           '--failed-job', failed_job, '--runner-sha', runner_sha,
           '--audit-sha', audit_sha, '--fingerprint', fingerprint]
    body = '\n'.join([
        '#!/bin/bash', 'set -euo pipefail', 'module purge', 'module load arch/h100',
        'module load pytorch-gpu/py3/2.6.0',
        'export OMP_NUM_THREADS=8 MKL_NUM_THREADS=8 PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1',
        'export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false',
        'export PYTHONPATH="$PWD:$PWD/source${PYTHONPATH:+:$PYTHONPATH}"',
        'exec ' + shlex.join(run), '',
    ])
    return command, body, log


def submit(root, failed_job, new_job=False):
    cfg, source, output = setup(root, failed_job)
    from common import atomic_json, sha
    output.mkdir(parents=True, exist_ok=True)
    (root / 'logs').mkdir(exist_ok=True)
    receipt_file = output / 'submission.json'
    with (output / 'submission.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if receipt_file.exists():
            old = json.loads(receipt_file.read_text())
            if old['fingerprint'] != cfg['fingerprint']:
                raise RuntimeError('Diagnostic receipt belongs to a different run.')
            if old.get('job_id') and not new_job:
                emit('ALREADY_SUBMITTED', {k: old[k] for k in ('job_id', 'log')})
                return
            if not old.get('job_id') and old.get('state') != 'rejected':
                raise RuntimeError('Earlier submission is ambiguous; inspect squeue before retrying.')
        live = subprocess.run(['squeue', '--noheader', '--user=' + str(os.getuid()),
                               '--name=' + JOB_NAME, '--format=%i'],
                              check=True, text=True, capture_output=True)
        if live.stdout.strip():
            raise RuntimeError('A GPU replay is already queued/running: ' + live.stdout.strip())
        command, body, log = shell_request(root, failed_job, sha(__file__),
                                           sha(root / 'ct2_resume_audit.py'), cfg['fingerprint'])
        subprocess.run(['bash', '-n'], input=body, text=True, check=True)
        receipt = {'fingerprint': cfg['fingerprint'], 'job_id': None, 'state': 'submitting',
                   'submitted_at_unix': time.time(), 'command': command, 'script': body}
        archive = output / ('submission_' + str(time.time_ns()) + '.json')
        atomic_json(receipt_file, receipt)
        atomic_json(archive, receipt)
        result = subprocess.run(command, input=body, text=True, capture_output=True)
        match = re.fullmatch(r'(\d+)(?:;[^\s;]+)?', result.stdout.strip())
        receipt.update(sbatch_returncode=result.returncode, sbatch_stdout=result.stdout,
                       sbatch_stderr=result.stderr, state='ambiguous')
        if result.returncode == 0 and match:
            receipt.update(job_id=match.group(1), state='submitted', log=str(log).replace('%j', match.group(1)))
        elif result.returncode and not result.stdout.strip() and 'Batch job submission failed:' in result.stderr:
            receipt['state'] = 'rejected'
        atomic_json(receipt_file, receipt)
        atomic_json(archive, receipt)
        if receipt['state'] != 'submitted':
            raise RuntimeError('Replay submission ' + receipt['state'] + ': ' + result.stderr + repr(result.stdout))
        emit('ONE_H100_REPLAY_SUBMITTED', {k: receipt[k] for k in ('job_id', 'log')})
        print('Diagnostic only. Four numerical profiles; no production training or preflight approval.', flush=True)


def verify_args(args):
    cfg, source, output = setup(args.run_dir, args.failed_job)
    from common import sha
    if sha(__file__) != args.runner_sha or sha(args.run_dir / 'ct2_resume_audit.py') != args.audit_sha:
        raise RuntimeError('A diagnostic helper changed after submission.')
    if cfg['fingerprint'] != args.fingerprint:
        raise RuntimeError('Sealed configuration changed after submission.')
    job = os.environ.get('SLURM_JOB_ID', '')
    if not job.isdigit() or os.environ.get('SLURM_NTASKS') != '1':
        raise RuntimeError('Use the one-task Slurm submission.')
    return cfg, source, output / ('job_' + job)


def configure(profile):
    import torch
    if profile not in PROFILES:
        raise ValueError(profile)
    controlled = profile == 'controlled'
    if controlled and os.environ.get('CUBLAS_WORKSPACE_CONFIG') != ':4096:8':
        raise RuntimeError('Controlled profile requires its workspace setting before CUDA initialization.')
    torch.set_num_threads(8)
    torch.set_float32_matmul_precision('highest' if controlled else 'medium')
    torch.use_deterministic_algorithms(controlled)
    if profile in ('no_cudnn', 'controlled'):
        torch.backends.cuda.enable_cudnn_sdp(False)
    if controlled:
        torch.backends.cudnn.benchmark = False
        torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False


def execution_settings(model):
    import torch
    return {'reference_compile': model.model.config.reference_compile,
            'attention_implementation': model.model.config._attn_implementation,
            'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
            'float32_matmul_precision': torch.get_float32_matmul_precision(),
            'bf16_reduced_precision_reduction': torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction,
            'cudnn_sdp': torch.backends.cuda.cudnn_sdp_enabled(),
            'flash_sdp': torch.backends.cuda.flash_sdp_enabled(),
            'efficient_sdp': torch.backends.cuda.mem_efficient_sdp_enabled(),
            'math_sdp': torch.backends.cuda.math_sdp_enabled(),
            'cublas_workspace_config': os.environ.get('CUBLAS_WORKSPACE_CONFIG'),
            'forward_autocast': 'bfloat16'}


def batch_digest(batches):
    h = hashlib.sha256()
    for i, batch in enumerate(batches):
        h.update(str(i).encode())
        for key, value in sorted(batch.items()):
            h.update(key.encode())
            h.update(str((tuple(value.shape), str(value.dtype))).encode())
            h.update(value.contiguous().numpy().tobytes())
    return h.hexdigest()


def save_replay(path, model, optimizer, names, streams, cfg, completed, profile, trace):
    from engine import rng_state, atomic_torch_save
    # world_size=1 and mode=kernel-replay deliberately make these unsuitable
    # for train.py, which requires eight ranks and an approved training mode.
    cp = {'ct2_format': 1, 'gpu_replay_format': 1, 'mode': 'kernel-replay', 'world_size': 1,
          'logical_data_ranks': 8, 'fingerprint': cfg['fingerprint'], 'mapping_sha256': cfg['mapping_sha256'],
          'state_dict': model.state_dict(), 'model_config': model.model.config.to_dict(),
          'species_embed_scale': model.scale, 'optimizer_states': [optimizer.state_dict()],
          'optimizer_parameter_names': names, 'global_step': cfg['source_step'] + completed,
          'continuation_step': completed, 'execution_profile': profile,
          'execution_settings': execution_settings(model), 'trace': trace,
          'rank_states': [{'stream': stream.state_dict()} for stream in streams], 'replay_rng': rng_state()}
    atomic_torch_save(path, cp)


def worker(args):
    cfg, source, output = verify_args(args)
    from common import source_path, controls, batch_profile, atomic_json
    from checks import inputs, check_checkpoint
    inputs(cfg)
    source_path(args.run_dir)
    import torch
    configure(args.profile)
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError('Expected exactly one visible GPU.')
    torch.cuda.set_device(0)
    if 'H100' not in torch.cuda.get_device_name(0) or not torch.cuda.is_bf16_supported():
        raise RuntimeError('This replay targets one H100 with native BF16.')
    from model_io import read_checkpoint, tokenizer_at, build_model, optimizer_for
    from engine import seed_all, restore_rng, optimizer_update
    from data_stream import RecordStream
    from augmentation import TrainingCollator
    folder = output / args.profile / args.trajectory
    folder.mkdir(parents=True, exist_ok=False)
    seed_all(cfg['seed'])
    path = (source / 'reference/step_000016.ckpt' if args.trajectory == 'reference'
            else output / args.profile / 'reference/step_000020.ckpt')
    cp = read_checkpoint(path)
    start = 16 if args.trajectory == 'reference' else 20
    if start == 16:
        check_checkpoint(cp, cfg, 0, 16, 'smoke-reference')
    elif (cp.get('gpu_replay_format') != 1 or cp.get('mode') != 'kernel-replay'
          or cp.get('execution_profile') != args.profile or cp.get('continuation_step') != 20
          or cp.get('world_size') != 1 or cp.get('logical_data_ranks') != 8):
        raise RuntimeError('Wrong diagnostic resume checkpoint.')
    tok = tokenizer_at(args.run_dir)
    model = build_model(cp, tok, cfg, torch.device('cuda', 0))
    for key in ('embedding_dropout', 'mlp_dropout', 'attention_dropout', 'classifier_dropout'):
        if getattr(model.model.config, key) != 0.:
            raise RuntimeError('Serial rank replay requires the current zero-dropout model.')
    if args.profile in ('no_compile', 'controlled'):
        model.model.config.reference_compile = False
    optimizer, names = optimizer_for(model, cp)
    mapping = json.loads(Path(cfg['mapping']).read_text())
    paths = [str(Path(cfg['data_root']) / row[0]) for row in cfg['shards']]
    streams = [RecordStream(paths, tok.get_vocab(), mapping, 26678, rank, 8,
                            cfg['seed'], cfg['shuffle_buffer']) for rank in range(8)]
    collators = [TrainingCollator(tok, 26678, cfg['seed'], rank) for rank in range(8)]
    for rank, stream in enumerate(streams):
        stream.load_state_dict(cp['rank_states'][rank]['stream'])
    restore_rng(cp['rank_states'][0]['rng'] if start == 16 else cp['replay_rng'])
    del cp
    trace = []
    for completed in range(start, 24):
        tick = time.monotonic()
        length, probability, lr = controls(0, completed, cfg['seed'])
        micro, accumulate = batch_profile(length, cfg['batch_divisor'])
        batches = [collator(stream.batch(micro, length), length, probability, completed, index)
                   for stream, collator in zip(streams, collators) for index in range(accumulate)]
        digest = batch_digest(batches)
        prof = torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU]) if completed == start else None
        with prof if prof is not None else contextlib.nullcontext():
            metrics, norm = optimizer_update(model, optimizer, batches, torch.device('cuda', 0), lr)
        del batches
        record = {'step': completed + 1, 'input_sha256': digest, 'grad_preclip': norm,
                  'raw_token_loss': (metrics[0] + metrics[2]) / (metrics[1] + metrics[3]),
                  'targets': int(metrics[1] + metrics[3]), 'draws': int(metrics[4]),
                  'length': length, 'microbatch': micro, 'accumulation_per_logical_rank': accumulate,
                  'lr': lr, 'full_mask_probability': probability, 'seconds': time.monotonic() - tick}
        if record['draws'] != 1536 or any(s.counts['accepted'] != (completed + 1) * 192 for s in streams):
            raise RuntimeError('Replay effective batch/cursor accounting changed.')
        if prof is not None:
            record['attention_operators'] = sorted({e.key for e in prof.key_averages()
                                                    if 'attention' in e.key.lower() or 'scaled_dot_product' in e.key.lower()})
            emit('REPLAY_EXECUTION_SETTINGS', {'profile': args.profile, 'trajectory': args.trajectory,
                                               **execution_settings(model), 'attention_operators': record['attention_operators']})
        trace.append(record)
        emit('REPLAY_UPDATE', {'profile': args.profile, 'trajectory': args.trajectory, **record})
        atomic_json(folder / 'trace.json', trace)
        if completed + 1 in (20, 24):
            save_replay(folder / f'step_{completed + 1:06d}.ckpt', model, optimizer, names,
                        streams, cfg, completed + 1, args.profile, trace)
    emit('REPLAY_TRAJECTORY_FINISHED', {'profile': args.profile, 'trajectory': args.trajectory})


def compare_profile(folder, cfg, profile):
    import torch
    from checks import equal_tree
    from ct2_resume_audit import tree_rows, summarize
    torch.set_num_threads(8)
    a = torch.load(folder / 'reference/step_000024.ckpt', map_location='cpu', weights_only=False, mmap=True)
    b = torch.load(folder / 'resumed/step_000024.ckpt', map_location='cpu', weights_only=False, mmap=True)
    c = torch.load(folder / 'reference/step_000020.ckpt', map_location='cpu', weights_only=False, mmap=True)
    for cp, step in ((a, 24), (b, 24), (c, 20)):
        if (cp.get('fingerprint') != cfg['fingerprint'] or cp.get('execution_profile') != profile
            or cp.get('continuation_step') != step or cp.get('gpu_replay_format') != 1
            or cp.get('global_step') != cfg['source_step'] + step):
            raise RuntimeError('Wrong replay result checkpoint.')
        for state in cp['optimizer_states'][0]['state'].values():
            if int(state['step']) != cfg['source_step'] + step:
                raise RuntimeError('AdamW replay step count mismatch.')
    exact = {}
    for key in ('rank_states', 'replay_rng', 'optimizer_parameter_names', 'model_config', 'execution_settings'):
        try:
            equal_tree(a[key], b[key])
            exact[key] = True
        except (ValueError, AssertionError):
            exact[key] = False
    trace_a = {row['step']: row for row in a['trace']}
    trace_b = {row['step']: row for row in b['trace']}
    if set(trace_a) != set(range(17, 25)) or set(trace_b) != set(range(21, 25)):
        raise RuntimeError('Incomplete replay trace.')
    exact['input_batches'] = all(trace_a[i]['input_sha256'] == trace_b[i]['input_sha256'] for i in range(21, 25))
    rows = tree_rows(a['state_dict'], b['state_dict'], origin=c['state_dict'])
    moments = tree_rows(a['optimizer_states'], b['optimizer_states'])
    model_summary, optimizer_summary = summarize(rows), summarize(moments)
    passes = (all(exact.values()) and model_summary['failing_float_tensors'] == 0
              and optimizer_summary['failing_float_tensors'] == 0
              and model_summary['failing_nonfloat_tensors'] == 0 and optimizer_summary['failing_nonfloat_tensors'] == 0)
    return {'profile': profile, 'status': 'measured', 'serial_resume_matches_original_tolerance': passes,
            'tolerance': {'rtol': 1e-5, 'atol': 2e-6}, 'exact_checks': exact,
            'model_summary': model_summary, 'optimizer_summary': optimizer_summary,
            'gradient_history': [{'step': i, 'reference': trace_a[i]['grad_preclip'],
                                  'resumed': trace_b[i]['grad_preclip'] if i in trace_b else None} for i in range(17, 25)],
            'attention_operators': {'reference': trace_a[17].get('attention_operators'),
                                    'resumed': trace_b[21].get('attention_operators')},
            'execution_settings': a['execution_settings']}


def brief(item):
    keys = ('profile', 'status', 'serial_resume_matches_original_tolerance', 'error', 'exact_checks',
            'attention_operators', 'execution_settings', 'gradient_history')
    result = {k: item[k] for k in keys if k in item}
    for key in ('model_summary', 'optimizer_summary'):
        if key in item:
            result[key] = {k: v for k, v in item[key].items() if k != 'worst_12_by_tolerance_ratio'}
    return result


def run(args):
    cfg, source, output = verify_args(args)
    from common import atomic_json
    output.mkdir(parents=True, exist_ok=False)
    summary = {'fingerprint': cfg['fingerprint'], 'source_preflight_job': args.failed_job,
               'scope': 'one_GPU_serial_replay_of_8_logical_data_ranks; no DDP/NCCL validation',
               'certifies_preflight': False, 'state': 'running', 'profiles': []}
    atomic_json(output / 'summary.json', summary)
    for profile in PROFILES:
        try:
            for trajectory in ('reference', 'resumed'):
                env = dict(os.environ)
                if profile == 'controlled':
                    env['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
                cmd = [sys.executable, '-u', str(Path(__file__).resolve()), 'worker',
                       '--run-dir', str(args.run_dir), '--failed-job', args.failed_job,
                       '--profile', profile, '--trajectory', trajectory,
                       '--runner-sha', args.runner_sha, '--audit-sha', args.audit_sha,
                       '--fingerprint', args.fingerprint]
                result = subprocess.run(cmd, env=env)
                if result.returncode:
                    raise RuntimeError(f'{trajectory} exited with code {result.returncode}; see combined log')
            item = compare_profile(output / profile, cfg, profile)
        except Exception as exc:
            traceback.print_exc()
            item = {'profile': profile, 'status': 'error', 'error': str(exc)}
        atomic_json(output / profile / 'comparison.json', item)
        summary['profiles'].append(brief(item))
        atomic_json(output / 'summary.json', summary)
        emit('PROFILE_RESULT', brief(item))
    verify_args(args)
    summary['state'] = 'finished' if all(p['status'] == 'measured' for p in summary['profiles']) else 'finished_with_errors'
    atomic_json(output / 'summary.json', summary)
    print('ONE_GPU_REPLAY_FINISHED: measurements only; eight-GPU preflight has not been approved.', flush=True)
    return 0 if summary['state'] == 'finished' else 2


def report(root, failed_job):
    cfg, source, output = setup(root, failed_job)
    receipt = json.loads((output / 'submission.json').read_text())
    if receipt['fingerprint'] != cfg['fingerprint'] or not receipt.get('job_id'):
        raise RuntimeError('No confirmed replay job for this run.')
    emit('REPLAY_JOB', {k: receipt[k] for k in ('job_id', 'log')})
    path = output / ('job_' + receipt['job_id']) / 'summary.json'
    if not path.exists():
        print('NOT_YET_AVAILABLE: check the combined log above.')
        return
    summary = json.loads(path.read_text())
    if summary['fingerprint'] != cfg['fingerprint']:
        raise RuntimeError('Replay report belongs to a different run.')
    emit('REPLAY_STATE', summary['state'])
    for item in summary['profiles']:
        emit('PROFILE_RESULT', item)
    print('REPORT:', path)
    print('Serial diagnostics only. This cannot approve distributed training.')


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('action', choices=('submit', 'run', 'worker', 'report'))
    p.add_argument('--run-dir', type=Path, default=DEFAULT_RUN)
    p.add_argument('--failed-job', default='265592')
    p.add_argument('--new-job', action='store_true')
    p.add_argument('--profile', choices=PROFILES, help=argparse.SUPPRESS)
    p.add_argument('--trajectory', choices=('reference', 'resumed'), help=argparse.SUPPRESS)
    for flag in ('runner-sha', 'audit-sha', 'fingerprint'):
        p.add_argument('--' + flag, help=argparse.SUPPRESS)
    args = p.parse_args()
    args.run_dir = args.run_dir.resolve()
    if args.action == 'submit':
        submit(args.run_dir, args.failed_job, args.new_job)
    elif args.action == 'worker':
        worker(args)
    elif args.action == 'run':
        return run(args)
    else:
        report(args.run_dir, args.failed_job)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
