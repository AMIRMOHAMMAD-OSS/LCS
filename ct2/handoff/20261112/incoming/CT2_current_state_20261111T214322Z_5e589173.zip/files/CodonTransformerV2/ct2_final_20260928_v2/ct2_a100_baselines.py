#!/usr/bin/env python3
"""Run the sealed CT2 v2 checkpoint comparisons on ONE A100, without training.

Upload this file into ct2_final_20260928_v2, then:
    python3 ct2_a100_baselines.py submit
    python3 ct2_a100_baselines.py report

Requests nef@a100 / gpu_p5 / qos_gpu_a100-dev, one GPU, at most two hours.
Evaluates epoch_6 and epoch_9 on the complete 4096-record, 512-token panel,
plus the sealed native-host and same-protein/multiple-host generation probes.
Uses the existing strict checkpoint loader, scale, collator and evaluator.
Does not exercise WebDataset, optimizer updates, distributed resume, training
memory, or the 1024/2048-token loss panels. This is NOT a preflight pass.
No sealed file, training registry, checkpoint or training pass stamp is changed.
The existing H100 job remains independent. Results/logs stay on WORK; caches
use the existing v2 runtime_python.sh job-local cache policy.

Repeated submit returns the existing receipt. To retry a finished diagnostic,
use submit --new-job; this refuses while another ct2_a100_eval job is active.
An explicit sbatch rejection can be retried with submit after its cause is fixed;
the rejected receipt is preserved. Ambiguous submissions still block retries.
"""
from __future__ import annotations

import argparse
import fcntl
import gc
from importlib.metadata import PackageNotFoundError, version
import json
import os
from pathlib import Path
import platform
import re
import shlex
import subprocess
import sys
import time

DEFAULT_RUN = Path('/lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2/ct2_final_20260928_v2')
JOB_NAME = 'ct2_a100_eval'
CHECKPOINTS = ('epoch_6', 'epoch_9')
RELEVANT_PACKAGES = ('torch', 'transformers', 'lightning', 'tokenizers')
SCOPE = {
    'purpose': 'checkpoint_and_host_comparisons_only',
    'checkpoints': list(CHECKPOINTS), 'loss_panel_lengths': [512],
    'loss_panel_records': 4096, 'full_protein_generation': True,
    'training_updates': 0, 'training_loader_tested': False,
    'distributed_resume_tested': False, 'training_memory_tested': False,
    'certifies_preflight': False, 'submits_training': False,
}


def emit(label, value):
    print(label + ':', json.dumps(value, sort_keys=True, allow_nan=False), flush=True)


def verify_run(root):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root))
    from common import load_run
    cfg = load_run(root)
    if cfg.get('version') != 2 or cfg.get('launch_policy') != 'preflight_only_then_explicit_train':
        raise RuntimeError('This helper requires the sealed v2 installation.')
    required = ('runtime_python.sh', 'evaluation.py', 'generation.py', 'model_io.py',
                'engine.py', 'submit.py', 'source/eval_panel.jsonl', 'source/phase1_support.py')
    if any(name not in cfg['hashes'] for name in required):
        raise RuntimeError('The sealed v2 evaluation/runtime files are missing.')
    emit('SEALED_RUN_VERIFIED', {'directory': str(root), 'fingerprint': cfg['fingerprint']})
    return cfg


def result_base(cfg):
    output = Path(cfg['output']).resolve()
    if not output.is_relative_to(Path('/lustre/fswork')):
        raise RuntimeError('Expected an output directory on WORK: ' + str(output))
    return output / 'diagnostics' / 'a100_baselines'


def receipt_path(cfg):
    return result_base(cfg) / 'latest_submission.json'


def show_receipt(receipt):
    print('A100_EVALUATION_JOB:', receipt['job_id'], flush=True)
    print('LOG:', receipt['log'], flush=True)
    print('RESULTS:', receipt['output'], flush=True)
    print('Evaluation only. No preflight or training job was submitted.', flush=True)


def batch_request(root, runner, runner_sha, fingerprint):
    log = root / 'logs' / (JOB_NAME + '_%j.out')
    command = [
        'sbatch', '--parsable', '--job-name=' + JOB_NAME, '--account=nef@a100',
        '--partition=gpu_p5', '--constraint=a100', '--qos=qos_gpu_a100-dev',
        '--nodes=1', '--ntasks=1', '--ntasks-per-node=1', '--gres=gpu:1',
        # Jean Zay assigns host memory automatically; explicit --mem* is forbidden.
        '--cpus-per-task=8', '--time=02:00:00',
        '--hint=nomultithread', '--no-requeue', '--chdir=' + str(root),
        '--output=' + str(log), '--error=' + str(log),
    ]
    run = ['srun', '--kill-on-bad-exit=1', 'bash', str(root / 'runtime_python.sh'),
           '-u', str(runner), 'run', '--run-dir', str(root),
           '--runner-sha', runner_sha, '--fingerprint', fingerprint]
    body = '\n'.join([
        '#!/bin/bash', 'set -euo pipefail', 'module purge',
        'module load arch/a100', 'module load pytorch-gpu/py3/2.6.0',
        'export PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 TOKENIZERS_PARALLELISM=false',
        'export OMP_NUM_THREADS=8 MKL_NUM_THREADS=8',
        'export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1',
        'export PYTHONPATH="$PWD:$PWD/source${PYTHONPATH:+:$PYTHONPATH}"',
        'exec ' + shlex.join(run), '',
    ])
    return command, body, log


def confirmed_rejection(receipt):
    """Distinguish Slurm's explicit rejection from a lost/ambiguous response."""
    code = receipt.get('sbatch_returncode')
    return (type(code) is int and code != 0 and receipt.get('job_id') is None
            and not receipt.get('sbatch_stdout', '').strip()
            and 'sbatch: error: Batch job submission failed:' in receipt.get('sbatch_stderr', ''))


def rejected_attempt(base, receipt):
    if confirmed_rejection(receipt):
        return receipt
    # The first helper version stored sbatch's response only in this file.
    attempt_path = base / 'submission_attempt.json'
    if not attempt_path.is_file():
        return None
    attempt = json.loads(attempt_path.read_text())
    identity = ('fingerprint', 'runner_sha256', 'submitted_at_unix', 'command', 'script')
    if any(key not in receipt or attempt.get(key) != receipt[key] for key in identity):
        return None
    return attempt if confirmed_rejection(attempt) else None


def submit(root, new_job=False):
    cfg = verify_run(root)
    from common import atomic_json, sha
    base = result_base(cfg)
    base.mkdir(parents=True, exist_ok=True)
    (root / 'logs').mkdir(exist_ok=True)
    receipt_file = receipt_path(cfg)
    # Separate from the full preflight's lock and jobs.json.
    with (base / 'submission.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if receipt_file.exists():
            old = json.loads(receipt_file.read_text())
            if old['fingerprint'] != cfg['fingerprint']:
                raise RuntimeError('Diagnostic receipt belongs to a different sealed run.')
            if old.get('job_id') is None:
                rejected = rejected_attempt(base, old)
                if rejected is None:
                    raise RuntimeError('Earlier submission has no confirmed job ID; inspect squeue and submission_attempt.json before retrying.')
                stamp = int(rejected['submitted_at_unix'] * 1_000_000)
                archive = base / f'rejected_submission_{stamp}.json'
                atomic_json(archive, rejected)
                print('REJECTED_ATTEMPT_PRESERVED:', archive, flush=True)
                print('Earlier sbatch explicitly rejected the request. Checking for active jobs before retrying.', flush=True)
            elif not new_job:
                print('ALREADY_SUBMITTED: returning the existing job; use report for results.')
                show_receipt(old)
                return
        live = subprocess.run(['squeue', '--noheader', '--user=' + str(os.getuid()),
                               '--name=' + JOB_NAME, '--format=%i'],
                              text=True, capture_output=True, check=True)
        if live.stdout.strip():
            raise RuntimeError('An A100 evaluation is already queued/running: ' + live.stdout.strip())
        runner = Path(__file__).resolve()
        command, body, log = batch_request(root, runner, sha(runner), cfg['fingerprint'])
        subprocess.run(['bash', '-n'], input=body, text=True, check=True)
        receipt = {'fingerprint': cfg['fingerprint'], 'runner_sha256': sha(runner),
                   'submitted_at_unix': time.time(), 'job_id': None,
                   'command': command, 'script': body, 'scope': SCOPE}
        atomic_json(base / 'submission_attempt.json', receipt)
        atomic_json(receipt_file, receipt)
        completed = subprocess.run(command, input=body, text=True, capture_output=True)
        receipt['sbatch_returncode'] = completed.returncode
        receipt['sbatch_stdout'] = completed.stdout
        receipt['sbatch_stderr'] = completed.stderr
        atomic_json(base / 'submission_attempt.json', receipt)
        atomic_json(receipt_file, receipt)
        match = re.fullmatch(r'(\d+)(?:;[^\s;]+)?', completed.stdout.strip())
        if completed.returncode or not match:
            if confirmed_rejection(receipt):
                raise RuntimeError('Slurm rejected the request. Correct the reported cause, then rerun submit. sbatch: '
                                   + completed.stderr)
            raise RuntimeError('Submission not confirmed. Inspect squeue before retrying. sbatch: '
                               + completed.stderr + repr(completed.stdout))
        job = match.group(1)
        receipt.update(job_id=job, log=str(log).replace('%j', job),
                       output=str(base / ('job_' + job)))
        atomic_json(receipt_file, receipt)
        atomic_json(base / ('submission_' + job + '.json'), receipt)
        show_receipt(receipt)


def versions():
    from common import VERSIONS
    found = {}
    for package in (*RELEVANT_PACKAGES, 'webdataset'):
        try:
            found[package] = version(package)
        except PackageNotFoundError:
            found[package] = None
    emit('EVALUATION_PACKAGE_VERSIONS', found)
    for package in RELEVANT_PACKAGES:
        actual = found[package]
        if actual is None or actual.split('+')[0] != VERSIONS[package]:
            raise RuntimeError(f'Evaluation dependency mismatch: {package}={actual}, expected {VERSIONS[package]}')
    emit('WEBDATASET_SCOPE', {'installed': found['webdataset'],
                            'h100_training_expected': VERSIONS['webdataset'],
                            'training_loader_used': False,
                            'full_preflight_version_check_unchanged': True})
    return found


def print_evaluation(name, item):
    from submit import host_summary
    print('CHECKPOINT:', name, flush=True)
    for mode, row in item['panels']['512']['modes'].items():
        emit('LOSS', {'input': mode, 'correct': row['conditions']['correct'],
                      'wrong_mean_delta': row['deltas']['wrong_mean']})
    hs = item['generation']['host_sensitivity']
    emit('HOST_SUMMARY', host_summary(hs))
    print('INTERPRETATION:', hs['interpretation'], flush=True)


def run(root, expected_runner, expected_fingerprint):
    cfg = verify_run(root)
    from common import atomic_json, sha, source_path
    if not expected_runner or sha(__file__) != expected_runner:
        raise RuntimeError('Diagnostic runner changed after submission, or was not submitted through this helper.')
    if cfg['fingerprint'] != expected_fingerprint:
        raise RuntimeError('Sealed run changed after submission.')
    job = os.environ.get('SLURM_JOB_ID', '')
    if not job.isdigit() or os.environ.get('SLURM_NTASKS') != '1' or os.environ.get('SLURM_PROCID', '0') != '0':
        raise RuntimeError('Run this diagnostic through its one-task Slurm submission.')
    output = result_base(cfg) / ('job_' + job)
    output.mkdir(parents=True, exist_ok=False)
    info = {'job_id': job, 'fingerprint': cfg['fingerprint'], 'runner_sha256': expected_runner,
            'scope': SCOPE, 'output': str(output), 'started_at_unix': time.time(),
            'checkpoints': cfg['checkpoints'], 'state': 'running'}
    atomic_json(output / 'diagnostic.json', info)
    try:
        info['versions'] = versions()
        source_path(root)
        import torch
        from engine import seed_all
        from evaluation import Evaluator
        from model_io import tokenizer_at, initial_checkpoint, build_model
        if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
            raise RuntimeError('Expected exactly one visible CUDA GPU.')
        torch.cuda.set_device(0)
        device = torch.device('cuda', 0)
        gpu = torch.cuda.get_device_name(0)
        if 'A100' not in gpu or torch.cuda.get_device_capability(0)[0] < 8 or not torch.cuda.is_bf16_supported():
            raise RuntimeError('Expected an A100 with native BF16 support; found ' + gpu)
        torch.set_num_threads(int(os.environ.get('OMP_NUM_THREADS', '8')))
        torch.set_float32_matmul_precision('medium')  # Same GPU setting as engine.initialize().
        seed_all(cfg['seed'])
        info['hardware'] = {'gpu': gpu, 'gpu_memory_bytes': torch.cuda.get_device_properties(0).total_memory,
                            'hostname': platform.node(), 'torch_cuda': torch.version.cuda,
                            'float32_matmul_precision': torch.get_float32_matmul_precision(),
                            'forward_autocast_dtype': 'bfloat16', 'python': sys.version}
        emit('EVALUATION_HARDWARE', info['hardware'])
        emit('EVALUATION_SCOPE', SCOPE)
        tok = tokenizer_at(root)
        evaluator = Evaluator(cfg, tok, root)
        if len(evaluator.rows) != 4096:
            raise RuntimeError('Expected the complete sealed 4096-record panel.')
        atomic_json(output / 'diagnostic.json', info)
        for name in CHECKPOINTS:
            print('LOADING_VERIFIED_CHECKPOINT:', name, flush=True)
            checkpoint = initial_checkpoint(cfg, name)
            model = build_model(checkpoint, tok, cfg, device, name)
            del checkpoint
            item = evaluator.evaluate(model, output / 'baselines' / name, 0, name,
                                      reference=name, long_panels=False, generation=True)
            print_evaluation(name, item)
            del model
            gc.collect()
            torch.cuda.empty_cache()
        verify_run(root)
        info.update(state='complete', finished_at_unix=time.time())
        atomic_json(output / 'diagnostic.json', info)
        print('A100_BASELINES_FINISHED: evaluation only; this is not a preflight pass and no training was submitted.', flush=True)
    except BaseException as exc:
        info.update(state='failed', error=repr(exc), finished_at_unix=time.time())
        atomic_json(output / 'diagnostic.json', info)
        raise


def report(root, job_id=None):
    cfg = verify_run(root)
    if job_id is None:
        receipt = json.loads(receipt_path(cfg).read_text())
        if receipt['fingerprint'] != cfg['fingerprint'] or not receipt.get('job_id'):
            raise RuntimeError('No confirmed diagnostic submission for this sealed run.')
        job_id = receipt['job_id']
    if not job_id.isdigit():
        raise ValueError('Job ID must contain digits only.')
    output = result_base(cfg) / ('job_' + job_id)
    print('A100_EVALUATION_JOB:', job_id)
    print('RESULTS:', output)
    print('LOG:', root / 'logs' / (JOB_NAME + '_' + job_id + '.out'))
    diagnostic = output / 'diagnostic.json'
    if diagnostic.exists():
        info = json.loads(diagnostic.read_text())
        if info['fingerprint'] != cfg['fingerprint']:
            raise RuntimeError('Diagnostic belongs to a different sealed run.')
        emit('DIAGNOSTIC_STATUS', {k: info[k] for k in ('state', 'error', 'scope') if k in info})
    else:
        print('NOT_YET_AVAILABLE: check squeue/sacct and the log above.')
    for name in CHECKPOINTS:
        path = output / 'baselines' / name / 'evaluation_000000.json'
        if not path.exists():
            print('NOT_YET_AVAILABLE:', name)
            continue
        item = json.loads(path.read_text())
        if item['fingerprint'] != cfg['fingerprint'] or item['tag'] != name:
            raise RuntimeError('Evaluation provenance mismatch: ' + str(path))
        print_evaluation(name, item)
    print('Host means weight each tested protein once. There is no biological-quality cutoff.')
    print('Identical argmax DNA can still conceal differences in codon probabilities.')
    print('This report cannot authorize training. The full H100 preflight remains separate.')


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('action', choices=('submit', 'run', 'report'))
    parser.add_argument('--run-dir', type=Path, default=DEFAULT_RUN)
    parser.add_argument('--new-job', action='store_true', help='Explicitly retry a finished diagnostic.')
    parser.add_argument('--job-id', help='Report a particular diagnostic job instead of the latest.')
    parser.add_argument('--runner-sha', help=argparse.SUPPRESS)
    parser.add_argument('--fingerprint', help=argparse.SUPPRESS)
    args = parser.parse_args()
    root = args.run_dir.resolve()
    if args.action == 'submit':
        submit(root, args.new_job)
    elif args.action == 'run':
        run(root, args.runner_sha, args.fingerprint)
    else:
        report(root, args.job_id)


if __name__ == '__main__':
    main()
