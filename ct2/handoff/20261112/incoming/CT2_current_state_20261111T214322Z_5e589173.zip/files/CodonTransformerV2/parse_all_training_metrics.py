import re
import csv
from pathlib import Path

LOG_DIR = Path("preflight_logs")
OUT_DIR = Path("/lustre/fsn1/projects/rech/nef/unh87ms/ct2_metrics_export/parsed_metrics")
OUT_DIR.mkdir(parents=True, exist_ok=True)

patterns = [
    ("stage1", "19_h100_final_*.out"),
    ("stage2", "21_h100_stage2_lr5e5_*.out"),
    ("stage3", "23_h100_stage3_lr2e5_*.out"),
    ("stage4", "30_full_stage4_len2048_*.out"),
    ("dryrun_stage4", "29_dryrun_stage4_len2048_*.out"),
    ("worker_sweep", "27_worker_sweep_len2048_*.out"),
    ("accum_lr_sweep", "28_accum_lr_sweep_len2048_*.out"),
    ("bucket_eval", "31_eval_buckets_*.out"),
]

epoch_pat = re.compile(
    r"Epoch\s+(\d+):\s+100%.*?"
    r"loss=([0-9.]+), lr=([0-9.eE+-]+)"
    r"(?:, test_loss=([0-9.]+), test_acc=([0-9.]+), "
    r"test_top5_acc=([0-9.]+), test_syn_acc=([0-9.]+))?"
)

progress_pat = re.compile(
    r"Epoch\s+(\d+):\s+(\d+)%.*?\|\s*(\d+)/(\d+)\s+\[([^<\]]+)<([^,\]]+),\s*([0-9.]+)it/s.*?"
    r"loss=([0-9.]+).*?lr=([0-9.eE+-]+)"
)

species_pat = re.compile(r"SPECIES_ABLATION_DEBUG\s+(\{.*\})")

all_epoch_rows = []
all_progress_rows = []
species_rows = []

for stage, globpat in patterns:
    for log in sorted(LOG_DIR.glob(globpat)):
        txt = log.read_text(errors="ignore")
        job_match = re.search(r"_(\d+)\.out$", log.name)
        jobid = job_match.group(1) if job_match else ""

        for m in epoch_pat.finditer(txt):
            epoch, loss, lr, tl, acc, top5, syn = m.groups()
            all_epoch_rows.append({
                "stage": stage,
                "log": str(log),
                "jobid": jobid,
                "epoch": epoch,
                "loss": loss,
                "lr": lr,
                "test_loss": tl or "",
                "test_acc": acc or "",
                "test_top5_acc": top5 or "",
                "test_syn_acc": syn or "",
            })

        for m in progress_pat.finditer(txt):
            e, pct, step, total, elapsed, remaining, speed, loss, lr = m.groups()
            all_progress_rows.append({
                "stage": stage,
                "log": str(log),
                "jobid": jobid,
                "epoch": e,
                "percent": pct,
                "step": step,
                "total_steps": total,
                "elapsed": elapsed,
                "remaining": remaining,
                "it_per_s": speed,
                "loss": loss,
                "lr": lr,
            })

        for m in species_pat.finditer(txt):
            species_rows.append({
                "stage": stage,
                "log": str(log),
                "jobid": jobid,
                "species_ablation_debug": m.group(1),
            })

def write_csv(path, rows):
    if not rows:
        path.write_text("")
        return
    keys = list(rows[0].keys())
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)

write_csv(OUT_DIR / "epoch_metrics.csv", all_epoch_rows)
write_csv(OUT_DIR / "progress_metrics.csv", all_progress_rows)
write_csv(OUT_DIR / "species_ablation_debug.csv", species_rows)

print("wrote", OUT_DIR / "epoch_metrics.csv", len(all_epoch_rows), "rows")
print("wrote", OUT_DIR / "progress_metrics.csv", len(all_progress_rows), "rows")
print("wrote", OUT_DIR / "species_ablation_debug.csv", len(species_rows), "rows")
