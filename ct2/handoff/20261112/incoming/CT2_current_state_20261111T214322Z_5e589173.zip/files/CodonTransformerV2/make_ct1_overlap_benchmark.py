import json
import random
import csv
from pathlib import Path

random.seed(123)

TEST_DIR = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/test_set")
OUT = Path("ct1_ct2_overlap_benchmark.csv")

# CT1 organism names copied from README list / common supported names.
# This is intentionally conservative: exact string matching first.
CT1_ORGS = {
    "Arabidopsis thaliana",
    "Bacillus subtilis",
    "Caenorhabditis elegans",
    "Chlamydomonas reinhardtii",
    "Danio rerio",
    "Drosophila melanogaster",
    "Escherichia coli general",
    "Homo sapiens",
    "Mus musculus",
    "Nicotiana tabacum",
    "Pseudomonas putida",
    "Pyrococcus furiosus",
    "Saccharomyces cerevisiae",
    "Saccharolobus solfataricus",
    "Salmonella enterica subsp. enterica serovar Typhimurium str. LT2",
    "Shigella flexneri 2a str. 301",
}

# For first pass, also use broad aliases likely to occur in RefSeq species strings.
ALIASES = {
    "Arabidopsis thaliana": "Arabidopsis thaliana",
    "Bacillus subtilis": "Bacillus subtilis",
    "Caenorhabditis elegans": "Caenorhabditis elegans",
    "Chlamydomonas reinhardtii": "Chlamydomonas reinhardtii",
    "Danio rerio": "Danio rerio",
    "Drosophila melanogaster": "Drosophila melanogaster",
    "Escherichia coli": "Escherichia coli general",
    "Homo sapiens": "Homo sapiens",
    "Mus musculus": "Mus musculus",
    "Nicotiana tabacum": "Nicotiana tabacum",
    "Pseudomonas putida": "Pseudomonas putida",
    "Pyrococcus furiosus": "Pyrococcus furiosus",
    "Saccharomyces cerevisiae": "Saccharomyces cerevisiae",
    "Saccharolobus solfataricus": "Saccharolobus solfataricus",
    "Salmonella enterica": "Salmonella enterica subsp. enterica serovar Typhimurium str. LT2",
    "Shigella flexneri": "Shigella flexneri 2a str. 301",
}

MAX_GENES_PER_ORG = 200
rows = []
matched_files = []

for f in sorted(TEST_DIR.glob("*.json")):
    obj = json.loads(f.read_text())
    species = obj["species"]
    ct1_org = None

    if species in CT1_ORGS:
        ct1_org = species
    else:
        for alias, mapped in ALIASES.items():
            if alias.lower() in species.lower():
                ct1_org = mapped
                break

    if ct1_org is None:
        continue

    genes = list(obj["genes"])
    random.shuffle(genes)
    genes = genes[:MAX_GENES_PER_ORG]

    matched_files.append((f.name, species, ct1_org, len(genes)))

    for g in genes:
        rows.append({
            "genome_id": obj["genome_id"],
            "species": species,
            "ct1_organism": ct1_org,
            "protein_id": g.get("protein_id", ""),
            "protein_sequence": g["protein_sequence"],
            "dna_sequence": g["dna_sequence"],
            "source_json": f.name,
        })

with OUT.open("w", newline="") as fh:
    writer = csv.DictWriter(
        fh,
        fieldnames=[
            "genome_id",
            "species",
            "ct1_organism",
            "protein_id",
            "protein_sequence",
            "dna_sequence",
            "source_json",
        ],
    )
    writer.writeheader()
    writer.writerows(rows)

print("matched_json_files =", len(matched_files))
print("benchmark_rows =", len(rows))
print("output =", OUT)
print()
print("matched examples:")
for x in matched_files[:30]:
    print(x)
