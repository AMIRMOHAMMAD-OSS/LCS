"""Regression checks for replay-driven profile adoption and installation."""
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch
import torch
import execution
import setup
import submit
from common import STAGES, sha, fingerprint, load_run


class ExecutionTests(unittest.TestCase):
    def test_checkpoint_records_and_validates_execution_on_every_rank(self):
        from engine import checkpoint_save
        from checks import check_checkpoint
        from model_io import CT2, optimizer_for
        from test_core import TinyLM
        model=CT2(TinyLM(),4,.0347)
        model.model.config.reference_compile=False
        model.model.config._attn_implementation='sdpa'
        model.model.config.to_dict=lambda:{'hidden_size':8}
        optimizer,names=optimizer_for(model)
        for param in model.parameters():param.grad=torch.ones_like(param)
        optimizer.step()
        stream=SimpleNamespace(state_dict=lambda:{'rank':0,'world':8,'counts':{'accepted':192,'examined':192},'species':{0:192}})
        cfg={'version':3,'fingerprint':'fixture','source_step':0,'mapping_sha256':'mapping'}
        def gather(local):
            result=[copy.deepcopy(local) for _ in range(8)]
            for rank,value in enumerate(result):value['stream']['rank']=rank
            return result
        with tempfile.TemporaryDirectory() as temp,patch.dict(os.environ,{'CUBLAS_WORKSPACE_CONFIG':':4096:8'}), \
             execution.scoped_generation('cpu'),patch('engine.world',return_value=8), \
             patch('engine.gather',side_effect=gather),patch('engine.barrier'):
            path=Path(temp)/'step.ckpt'
            checkpoint_save(path,model,optimizer,names,stream,cfg,0,1,1,{},'smoke-reference')
            cp=torch.load(path,map_location='cpu',weights_only=False)
            check_checkpoint(cp,cfg,0,1,'smoke-reference')
            self.assertEqual(cp['execution_profile'],execution.PROFILE)
            cp['rank_states'][5]['execution_settings']['reference_compile']=True
            with self.assertRaisesRegex(RuntimeError,'profile changed'):check_checkpoint(cp,cfg,0,1,'smoke-reference')

    def test_entire_profile_is_scoped_and_restored_after_exception(self):
        original=execution.snapshot()
        with patch.dict(os.environ,{'CUBLAS_WORKSPACE_CONFIG':':4096:8'}):
            with self.assertRaisesRegex(ValueError,'fixture'):
                with execution.scoped_generation('cuda'):
                    execution.assert_profile()
                    self.assertFalse(torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction)
                    self.assertTrue(torch.are_deterministic_algorithms_enabled())
                    raise ValueError('fixture')
        self.assertEqual(execution.snapshot(),original)

    def test_profile_is_checked_in_saved_metadata_and_running_process(self):
        value=dict(execution.PROFILE)
        execution.validate_snapshot(value)
        for field,replacement in (('reference_compile',True),('deterministic_algorithms',False),
                                  ('float32_matmul_precision','medium'),('cublas_workspace_config',None)):
            changed=dict(value);changed[field]=replacement
            with self.subTest(field=field),self.assertRaisesRegex(RuntimeError,'profile changed'):
                execution.validate_snapshot(changed)
        with patch.dict(os.environ,{'CUBLAS_WORKSPACE_CONFIG':':4096:8'}),execution.scoped_generation('cuda'):
            model=SimpleNamespace(model=SimpleNamespace(config=SimpleNamespace(reference_compile=False,_attn_implementation='sdpa')))
            self.assertEqual(execution.assert_profile(model),execution.PROFILE)
            torch.set_float32_matmul_precision('medium')
            with self.assertRaisesRegex(RuntimeError,'profile changed'):execution.assert_profile(model)

    def test_workspace_is_exported_before_python_on_each_rank(self):
        wrapper=Path(__file__).resolve().parents[1]/'runtime_python.sh'
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);binary=root/'bin';binary.mkdir()
            fake=binary/'python';fake.write_text('#!/bin/bash\nprintf "%s\\n" "$CUBLAS_WORKSPACE_CONFIG"\n');fake.chmod(0o700)
            for rank in ('0','4'):
                env=dict(os.environ,PATH=str(binary)+':'+os.environ['PATH'],SLURM_JOB_ID='fixture',
                         SLURM_PROCID=rank,SLURM_TMPDIR=str(root),CUBLAS_WORKSPACE_CONFIG='wrong')
                result=subprocess.run(['bash',str(wrapper)],env=env,text=True,capture_output=True,check=True)
                self.assertEqual(result.stdout.splitlines()[-1],':4096:8')

    def test_upgrade_preserves_v2_choices_source_and_outputs(self):
        with tempfile.TemporaryDirectory() as temp:
            base=Path(temp);parent=base/'v2';root=base/'v3';parent.mkdir();root.mkdir();(parent/'source').mkdir()
            (parent/'source/species_to_id.json').write_text('{"fixture":0}')
            (parent/'source/tokenizer.json').write_text('{"fixture":true}')
            (parent/'v2.py').write_text('# sealed parent code\n')
            cp=base/'epoch_6.ckpt';cp.write_text('fixture checkpoint, never modified')
            oldout=base/'outputs/v2';oldout.mkdir(parents=True);(oldout/'sentinel').write_text('preserve')
            cfg={'version':2,'source_fingerprint':setup.SOURCE_FINGERPRINT,'source_run':'phase1',
                 'stages':STAGES,'world_size':8,'output':str(oldout),'seed':71,'shuffle_buffer':23,
                 'mapping':str(parent/'source/species_to_id.json'),'mapping_sha256':sha(parent/'source/species_to_id.json'),
                 'initialization':'epoch_6','source_step':56000,'batch_divisor':2,'data_root':'fixture','shards':[],
                 'checkpoints':{'epoch_6':{'path':str(cp),'stat':[cp.stat().st_size,cp.stat().st_mtime_ns],'sha256':sha(cp)}},
                 'comparison_hosts':['fixture'],'launch_policy':'preflight_only_then_explicit_train'}
            cfg['hashes']={str(p.relative_to(parent)):sha(p) for p in parent.rglob('*') if p.is_file()}
            cfg['fingerprint']=fingerprint(cfg);(parent/'run.json').write_text(json.dumps(cfg))
            (parent/'jobs.json').write_text('{"not_copied":true}')
            (parent/'preflight_fullmask512_passed.json').write_text('{"not_copied":true}')
            before={str(p):sha(p) for p in parent.rglob('*') if p.is_file()}
            with patch.object(setup,'WORK_ROOT',base),patch.object(setup,'inventory',return_value=[]):
                setup.from_v2(parent,root)
                with self.assertRaises(FileExistsError):setup.from_v2(parent,root)
            new=load_run(root)
            self.assertEqual(new['version'],3);self.assertEqual(new['execution_profile'],execution.PROFILE)
            for key,value in cfg.items():
                if key not in ('version','output','mapping','hashes','fingerprint'):self.assertEqual(new[key],value)
            self.assertFalse((root/'jobs.json').exists());self.assertFalse((root/'preflight_fullmask512_passed.json').exists())
            self.assertEqual(new['output'],str(base/'outputs/v3'))
            self.assertEqual(before,{str(p):sha(p) for p in parent.rglob('*') if p.is_file()})
            self.assertEqual((oldout/'sentinel').read_text(),'preserve')
            (root/'source/tokenizer.json').write_text('tampered')
            with self.assertRaisesRegex(RuntimeError,'changed'):load_run(root)

    def test_development_qos_validation_falls_back_without_submitting(self):
        calls=[]
        def run(command,**kwargs):
            calls.append(command)
            return subprocess.CompletedProcess(command,1 if '--qos=qos_gpu_h100-dev' in command else 0,'','fixture refusal')
        with patch.object(submit.subprocess,'run',side_effect=run):
            self.assertEqual(submit.preflight_qos(Path('preflight.slurm')),'qos_gpu_h100-t3')
        self.assertEqual(len(calls),2)
        self.assertTrue(all('--test-only' in command and '--parsable' not in command for command in calls))

    def test_live_job_check_ignores_purged_completed_ids(self):
        registry={'submissions':[{'job':'10'},{'job':'11'}]}
        with patch.object(submit.subprocess,'run',return_value=SimpleNamespace(stdout='11\n99\n')) as run:
            self.assertEqual(submit.live_jobs(registry),['11'])
            self.assertNotIn('-j',run.call_args.args[0])

    def test_explicit_sbatch_rejection_can_be_retried(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);cfg={'fingerprint':'fixture','output':str(root/'output')}
            def reject(command,**kwargs):
                return subprocess.CompletedProcess(command,1,'','sbatch: error: Batch job submission failed: fixture')
            with patch.object(submit,'ROOT',root),patch.object(submit,'live_jobs',return_value=[]), \
                 patch.object(submit,'preflight_qos',return_value='qos_gpu_h100-dev'), \
                 patch.object(submit.subprocess,'run',side_effect=reject):
                for action in ('start','retry-preflight'):
                    with self.assertRaisesRegex(RuntimeError,'Slurm rejected'):submit.submit(cfg,action,0)
                    self.assertNotIn('pending_submission',json.loads((root/'jobs.json').read_text()))


if __name__=='__main__':unittest.main()
