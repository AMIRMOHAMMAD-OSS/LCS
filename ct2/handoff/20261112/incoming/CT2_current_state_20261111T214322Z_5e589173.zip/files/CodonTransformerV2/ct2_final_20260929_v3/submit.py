#!/usr/bin/env python3
"""Run preflight first; submit training explicitly after reviewing its results."""
from __future__ import annotations
import argparse
import fcntl
import json
import os
import re
import subprocess
import statistics
from collections import defaultdict
from pathlib import Path
from common import ROOT, STAGES, load_run, atomic_json, stage_index

def live_jobs(registry):
    ids=[item['job'] for item in registry.get('submissions',[]) if item.get('job')]
    if not ids:return []
    # Completed IDs can disappear from squeue. Query the user's active jobs and
    # intersect locally so a purged old ID cannot block a valid train/retry.
    out=subprocess.run(['squeue','-h','--user='+str(os.getuid()),'-o','%i'],check=True,text=True,capture_output=True)
    return sorted(set(ids)&set(out.stdout.split()))

def preflight_qos(script):
    """Ask Slurm to validate both supported queues; --test-only creates no job."""
    failures=[]
    for qos in ('qos_gpu_h100-dev','qos_gpu_h100-t3'):
        result=subprocess.run(['sbatch','--test-only','--qos='+qos,str(script)],text=True,capture_output=True,cwd=ROOT)
        if result.returncode==0:
            print('PREFLIGHT_QOS:',qos,flush=True)
            return qos
        failures.append(qos+': '+result.stderr.strip())
        print('PREFLIGHT_QOS_NOT_ACCEPTED:',failures[-1],flush=True)
    raise RuntimeError('Neither preflight request was accepted by Slurm: '+repr(failures))

def latest_preflight(registry,stage):
    matches=[item for item in registry.get('submissions',[]) if item['stage']==stage and item['kind']=='preflight']
    if not matches:raise RuntimeError('No preflight has been submitted for this stage')
    return matches[-1]

def require_preflight(cfg,registry,stage):
    latest=latest_preflight(registry,stage)
    path=ROOT/f'preflight_{STAGES[stage]["name"]}_passed.json'
    if not path.is_file():raise RuntimeError('Missing GPU preflight pass; inspect status and errors')
    stamp=json.loads(path.read_text())
    expected_output=Path(cfg['output'])/'preflight'/STAGES[stage]['name']/('job_'+latest['job'])
    if (stamp.get('fingerprint')!=cfg['fingerprint'] or stamp.get('stage')!=stage
            or stamp.get('comparison_passed') is not True or stamp.get('job_id')!=latest['job']
            or Path(stamp.get('output',''))!=expected_output):
        raise RuntimeError('Preflight pass does not match this run and its latest submitted preflight')
    if cfg.get('version')==3 and stamp.get('execution_profile')!=cfg['execution_profile']:
        raise RuntimeError('Preflight used a different execution profile')
    result=subprocess.run(['sacct','-X','--noheader','--parsable2','-j',latest['job'],
                           '--format=JobIDRaw,State,ExitCode'],check=True,text=True,capture_output=True)
    states=[line.strip().split('|') for line in result.stdout.splitlines()]
    states=[r for r in states if len(r)>=3 and r[0]==latest['job']]
    if len(states)!=1 or states[0][1:]!=['COMPLETED','0:0']:
        raise RuntimeError('Latest preflight has not been recorded as COMPLETED with ExitCode 0:0; inspect status')
    return stamp

def submit(cfg,action,stage):
    path=ROOT/'jobs.json'
    with (ROOT/'.submission.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        registry=json.loads(path.read_text()) if path.exists() else {'fingerprint':cfg['fingerprint'],'submissions':[]}
        if registry['fingerprint']!=cfg['fingerprint']:raise ValueError('Submission registry belongs to another run')
        if registry.get('pending_submission'):raise RuntimeError('An sbatch result is ambiguous; inspect status and Slurm before retrying')
        if live_jobs(registry):raise RuntimeError('A job is still queued/running for this run; inspect status')
        if action=='start' and path.exists():raise RuntimeError('Already submitted; use status, train, resume, or retry-preflight')
        out=Path(cfg['output'])/'training'/STAGES[stage]['name']
        if (out/'completed.json').exists():raise RuntimeError('This stage is complete; use report or advance')
        if action=='resume':
            if not (out/'last.ckpt').is_file():raise RuntimeError('No checkpoint exists for this stage; use retry-preflight')
        elif (out/'last.ckpt').exists():raise RuntimeError('Existing training checkpoint; use resume')
        if action in ('train','resume'):require_preflight(cfg,registry,stage)
        if stage>0:
            previous=Path(cfg['output'])/'training'/STAGES[stage-1]['name']/'verified_complete.json'
            done=json.loads(previous.read_text())
            if done['fingerprint']!=cfg['fingerprint']:raise RuntimeError('Previous stage is not verified complete')
        kinds=('train',) if action in ('train','resume') else ('preflight',)
        for kind in kinds:
            script=ROOT/f'{kind}_{STAGES[stage]["name"]}.slurm'
            command=['sbatch','--parsable']
            entry={'stage':stage,'kind':kind,'action':action,'script':str(script)}
            if kind=='preflight':
                entry['qos']=preflight_qos(script);command.append('--qos='+entry['qos'])
            registry['pending_submission']=entry;atomic_json(path,registry)
            result=subprocess.run([*command,str(script)],text=True,capture_output=True,cwd=ROOT)
            match=re.fullmatch(r'(\d+)(?:;[^\s;]+)?',result.stdout.strip())
            if result.returncode or not match:
                if result.returncode and not result.stdout.strip() and 'Batch job submission failed:' in result.stderr:
                    registry.pop('pending_submission')
                    registry.setdefault('rejected_submissions',[]).append({**entry,'error':result.stderr})
                    atomic_json(path,registry)
                    raise RuntimeError('Slurm rejected the submission: '+result.stderr)
                raise RuntimeError(f'Ambiguous sbatch response; inspect Slurm before retrying: {result.stdout!r} {result.stderr!r}')
            job=match.group(1)
            registry['submissions'].append({**entry,'job':job});registry.pop('pending_submission');atomic_json(path,registry)
            print(kind.upper()+'_JOB:',job,flush=True)
    print('DIRECTORY:',ROOT);print('OUTPUT:',cfg['output'])
    if kinds==('preflight',):
        print('Only preflight was submitted. No production training job is queued.')
        print('After completion, review submit.py baselines and then explicitly choose submit.py train.')
    else:print('Only the requested training stage will run.')

def status(cfg):
    path=ROOT/'jobs.json'
    if not path.exists():print('No jobs submitted.');return
    registry=json.loads(path.read_text());print(json.dumps(registry,indent=2))
    ids=','.join(item['job'] for item in registry['submissions'])
    if ids:subprocess.run(['sacct','-X','-j',ids,'--format=JobID,JobName,State,Elapsed,ExitCode'],check=True)
    for stage in STAGES:
        if (ROOT/f'preflight_{stage["name"]}_passed.json').exists():print('PREFLIGHT_PASSED:',stage['name'])

def host_summary(hs):
    pairs=defaultdict(list)
    for row in hs.get('paired_host_comparisons',[]):
        pairs[(row['host_a'],row['host_b'])].append(row['codon_disagreement'])
    hosts=defaultdict(list)
    # Each prediction contributes once. Do not overwrite earlier genes or count
    # every repeated appearance of one prediction in different host pairs.
    for row in hs.get('predictions',[]):
        n=row['protein_length'];dna=row['predicted_dna']
        if n:hosts[row['species']].append(sum(x in 'GC' for x in dna[2:3*n:3])/n)
    return {'host_pairs':[{'host_a':a,'host_b':b,'proteins':len(v),
                          'mean_codon_disagreement':statistics.mean(v),'min':min(v),'max':max(v)}
                         for (a,b),v in sorted(pairs.items())],
            'hosts':[{'host':h,'proteins':len(v),'mean_gc3':statistics.mean(v),'min':min(v),'max':max(v)}
                     for h,v in sorted(hosts.items())]}

def baselines(cfg):
    path=ROOT/'jobs.json'
    if not path.exists():raise RuntimeError('No preflight has been submitted')
    registry=json.loads(path.read_text())
    latest=latest_preflight(registry,0)
    directory=Path(cfg['output'])/'preflight'/'fullmask512'/('job_'+latest['job'])/'baselines'
    print('INITIALIZATION_SELECTED:',cfg['initialization'])
    print('BASELINES:',directory)
    for name in ('epoch_6','epoch_9'):
        path=directory/name/'evaluation_000000.json'
        if not path.is_file():print('NOT_YET_AVAILABLE:',name);continue
        item=json.loads(path.read_text())
        if item['fingerprint']!=cfg['fingerprint']:raise ValueError('Baseline belongs to another run')
        print('CHECKPOINT:',name)
        for mode,row in item['panels']['512']['modes'].items():
            print('LOSS:',json.dumps({'input':mode,'correct':row['conditions']['correct'],
                                     'wrong_mean_delta':row['deltas']['wrong_mean']}))
        hs=item['generation']['host_sensitivity']
        print('HOST_SUMMARY:',json.dumps(host_summary(hs)))
        print('INTERPRETATION:',hs['interpretation'])
    print('Means above weight each tested protein equally. No biological-quality cutoff is imposed.')
    print('Host differences show sensitivity; identical argmax outputs can still hide probability changes.')
    print('Reading this report does not submit training or change the selected checkpoint.')

def report(cfg):
    print('Correct synonymous loss = native codon NLL within its amino-acid family. Positive delta favors correct species.')
    print('stage step length input correct_syn wrong_mean_delta 95%CI')
    for stage in STAGES:
        out=Path(cfg['output'])/'training'/stage['name']
        for path in sorted(out.glob('evaluation_[0-9]*.json')):
            item=json.loads(path.read_text())
            for length,panel in item['panels'].items():
                for mode,row in panel['modes'].items():
                    delta=row['deltas']['wrong_mean'];lo,hi=delta['synonymous_95pct_species_bootstrap']
                    print(f"{stage['name']} {item['continuation_step']} {length} {mode} {row['conditions']['correct']['synonymous_loss']:.6f} {delta['synonymous_delta']:+.6f} [{lo:+.6f},{hi:+.6f}]")
        if (out/'progress.json').exists():
            progress=json.loads((out/'progress.json').read_text());stats=progress['statistics'];norms=stats['grad_norms'];v=stats['totals']
            print('TRAINING:',json.dumps({'stage':stage['name'],'draws':int(v[4]),'valid_tokens':int(v[5]),
                'full_mask_target_share':v[3]/(v[1]+v[3]),'full_mask_draw_fraction':v[6]/v[4],
                'clip_fraction':sum(x>.5 for x in norms)/len(norms),'max_gradient':max(norms),
                'updates_per_active_second':len(norms)/stats['active_seconds']}))
        if (out/'verified_complete.json').exists():print('VERIFIED_COMPLETE:',stage['name'])
    print('Detailed native recovery, GC3 and same-protein host comparisons are in evaluation JSON files.')
    print('CSI/species rank and MinMax-18 require the original codon tables/scorer; do not infer them from host disagreement.')

def errors():
    for path in sorted((ROOT/'logs').glob('*'),key=lambda p:p.stat().st_mtime)[-4:]:
        print('\nFILE:',path)
        with path.open(errors='replace') as f:
            from collections import deque
            print(''.join(deque(f,maxlen=100)))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=['start','train','status','baselines','report','errors','resume','advance','retry-preflight'])
    p.add_argument('--stage',choices=[s['name'] for s in STAGES],default='fullmask512');a=p.parse_args();cfg=load_run()
    if a.action=='status':status(cfg)
    elif a.action=='baselines':baselines(cfg)
    elif a.action=='report':report(cfg)
    elif a.action=='errors':errors()
    else:
        stage=stage_index(a.stage)
        if a.action=='start' and stage!=0:p.error('start always launches the first stage')
        if a.action=='advance' and stage==0:p.error('advance requires a later --stage')
        submit(cfg,a.action,stage)
