#!/usr/bin/env python3
"""Train one bounded curriculum stage; resume only at a completed optimizer update."""
from __future__ import annotations
import argparse
import json
import signal
import time
from pathlib import Path
import torch
from torch.nn.parallel import DistributedDataParallel
from common import ROOT, STAGES, controls, batch_profile, stage_start, load_run, atomic_json
from model_io import tokenizer_at, initial_checkpoint, read_checkpoint, build_model, optimizer_for
from data_stream import RecordStream
from augmentation import TrainingCollator
from engine import initialize, rank, world, barrier, seed_all, restore_rng, optimizer_update, checkpoint_save, sum_tensor, gather
from evaluation import Evaluator
from execution import assert_profile

STOP=False
def request_stop(signum,frame):
    global STOP
    STOP=True

def input_checkpoint(cfg,stage,resume=None):
    if resume is not None:return read_checkpoint(resume),None
    if stage==0:return initial_checkpoint(cfg),cfg['initialization']
    previous=Path(cfg['output'])/'training'/STAGES[stage-1]['name']
    completed=json.loads((previous/'completed.json').read_text())
    if completed['fingerprint']!=cfg['fingerprint'] or completed['continuation_step']!=stage_start(stage):
        raise ValueError('Previous stage completion does not match this run')
    return read_checkpoint(previous/'last.ckpt'),None

def run(args):
    signal.signal(signal.SIGUSR1,request_stop);signal.signal(signal.SIGTERM,request_stop)
    cfg=load_run();device=initialize();stage=args.stage;s=STAGES[stage]
    full=args.mode=='full'
    output=Path(args.output) if args.output else Path(cfg['output'])/'training'/s['name']
    stop=args.stop_after or s['steps']
    if not 0<stop<=s['steps']: raise ValueError('Invalid stage stop point')
    if full:
        stamp=json.loads((ROOT/f'preflight_{s["name"]}_passed.json').read_text())
        if stamp['fingerprint']!=cfg['fingerprint'] or stamp['stage']!=stage: raise ValueError('Missing matching GPU preflight')
    if (output/'completed.json').exists():raise RuntimeError('Stage already complete; use report or explicitly advance')
    resume=args.resume
    if resume=='auto':resume=str(output/'last.ckpt') if (output/'last.ckpt').exists() else None
    if resume is None and output.exists() and list(output.glob('*.ckpt')):raise RuntimeError('Existing checkpoints require explicit resume')
    if rank()==0:output.mkdir(parents=True,exist_ok=True)
    barrier();seed_all(cfg['seed'])
    tok=tokenizer_at();checkpoint,historical=input_checkpoint(cfg,stage,resume)
    model=build_model(checkpoint,tok,cfg,device,historical)
    execution=assert_profile(model)
    if rank()==0:print('CT2_EXECUTION_PROFILE',json.dumps(execution,sort_keys=True),flush=True)
    optimizer,names=optimizer_for(model,checkpoint)
    ddp=DistributedDataParallel(model,device_ids=[device.index],broadcast_buffers=False)
    mapping=json.loads(Path(cfg['mapping']).read_text())
    stream=RecordStream([str(Path(cfg['data_root'])/row[0]) for row in cfg['shards']],tok.get_vocab(),mapping,26678,
                         rank(),world(),cfg['seed'],cfg['shuffle_buffer'])
    collator=TrainingCollator(tok,26678,cfg['seed'],rank())
    stats={'totals':[0.]*8,'grad_norms':[],'active_seconds':0.}
    completed=0;total=stage_start(stage)
    if 'ct2_format' in checkpoint:
        if checkpoint['world_size']!=world():raise ValueError('Resume requires the same number of ranks')
        if checkpoint['stage']==stage:
            if full and checkpoint['mode']!='full':raise ValueError('A smoke checkpoint cannot initialize the actual training run')
            if not full and not checkpoint['mode'].startswith('smoke'):raise ValueError('Invalid smoke resume')
            completed=checkpoint['stage_step']
        elif checkpoint['stage']==stage-1 and checkpoint['stage_step']==STAGES[stage-1]['steps']:
            if checkpoint['mode']!='full':raise ValueError('Advance requires an actual completed training stage')
        else:raise ValueError('Checkpoint is not a valid resume or preceding stage')
        total=checkpoint['continuation_step']
        if total!=stage_start(stage)+completed:raise ValueError('Stage and update counters disagree')
        stream.load_state_dict(checkpoint['rank_states'][rank()]['stream'])
        stats=checkpoint['statistics']
        restore_rng(checkpoint['rank_states'][rank()]['rng'])
    else:seed_all(cfg['seed']+rank())
    del checkpoint
    if completed>=stop:raise ValueError('Requested stop point is already reached')
    evaluator=Evaluator(cfg,tok)
    if completed==0:evaluator.evaluate(model,output,total,s['name']+'_entry',reference=historical,long_panels=True)
    # Cache construction/evaluation must not change training RNG (Evaluator isolates it).
    interval=args.eval_interval or 1000;save_interval=args.checkpoint_interval or 2000
    while completed<stop:
        tick=time.monotonic();length,probability,lr=controls(stage,completed,cfg['seed'])
        micro,accumulate=batch_profile(length,cfg['batch_divisor'])
        batches=[collator(stream.batch(micro,length),length,probability,total,i) for i in range(accumulate)]
        metrics,norm=optimizer_update(ddp,optimizer,batches,device,lr)
        assert_profile(model)
        del batches
        completed+=1;total+=1;stats['active_seconds']+=time.monotonic()-tick
        stats['totals']=[a+b for a,b in zip(stats['totals'],metrics)];stats['grad_norms'].append(norm)
        stopping=bool(sum_tensor(torch.tensor(int(STOP),device=device)).item())
        if rank()==0 and (completed==1 or completed%50==0 or stopping):
            print('CT2_TRAIN',json.dumps({'stage':s['name'],'stage_step':completed,'continuation_step':total,
                'source_plus_updates':cfg['source_step']+total,'length':length,'full_mask_probability':probability,
                'lr':lr,'microbatch':micro,'accumulation':accumulate,'grad_preclip':norm,
                'mlm_loss':metrics[0]/metrics[1] if metrics[1] else None,
                'full_mask_loss':metrics[2]/metrics[3] if metrics[3] else None,
                'global_draws':int(stats['totals'][4]),'valid_tokens':int(stats['totals'][5]),
                'update_seconds':time.monotonic()-tick}),flush=True)
        if not stopping and (completed%interval==0 or completed==stop):
            evaluator.evaluate(model,output,total,s['name'],long_panels=True)
        if completed%save_interval==0 or completed==stop or stopping:
            if stream.counts['accepted']!=total*192:raise RuntimeError('Consumed draws do not match optimizer update accounting')
            checkpoint_save(output/f'step_{total:06d}.ckpt',model,optimizer,names,stream,cfg,stage,completed,total,stats,args.mode)
            audits=gather(stream.summary())
            if rank()==0:
                atomic_json(output/'data_audit.json',{'fingerprint':cfg['fingerprint'],'continuation_step':total,'ranks':audits})
                atomic_json(output/'progress.json',{'fingerprint':cfg['fingerprint'],'stage_step':completed,'continuation_step':total,
                    'global_step':cfg['source_step']+total,'statistics':stats,'stopped_by_signal':stopping})
        if stopping:
            if rank()==0:print('CT2_PAUSED_AT_CHECKPOINT',str(output/'last.ckpt'),flush=True)
            barrier();return 99
    if rank()==0:
        atomic_json(output/'completed.json',{'fingerprint':cfg['fingerprint'],'stage':stage,'stage_step':completed,
            'continuation_step':total,'global_step':cfg['source_step']+total,'mode':args.mode})
        print('CT2_STAGE_COMPLETE',s['name'],completed,flush=True)
    barrier();return 0

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--stage',type=int,required=True,choices=range(len(STAGES)))
    p.add_argument('--mode',default='full',choices=['full','smoke-reference','smoke-resume'])
    p.add_argument('--resume',help='auto or exact checkpoint path');p.add_argument('--output')
    p.add_argument('--stop-after',type=int);p.add_argument('--eval-interval',type=int);p.add_argument('--checkpoint-interval',type=int)
    raise SystemExit(run(p.parse_args()))
