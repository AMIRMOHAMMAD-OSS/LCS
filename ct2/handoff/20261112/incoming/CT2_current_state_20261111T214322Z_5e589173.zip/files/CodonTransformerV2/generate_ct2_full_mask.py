#!/usr/bin/env python
"""
Full-mask generation of CT2 predictions on the held-out test set.
Distributed via torchrun. Each rank writes one parquet.

For each test gene:
  - Build input: [CLS] <aa1>_unk ... <aaN>_unk [__unk if stop] [SEP]
  - Add species_embed(species_id) to all token positions
  - Forward, get logits [B, L, V=90]
  - For each codon position: synonymous-restricted argmax over the AA's valid codons
  - Decode and save (genome_id, protein_id, species, native_dna, predicted_dna)
"""
import argparse, json, os, sys
from pathlib import Path
from collections import defaultdict

import torch
import torch.distributed as dist
import torch.nn as nn
import pandas as pd
from tqdm import tqdm
from tokenizers import Tokenizer
from transformers import AutoConfig, AutoModelForMaskedLM


# =============================================================================
# Token bookkeeping
# =============================================================================

def build_token_maps(tokenizer_file):
    tok = Tokenizer.from_file(tokenizer_file)
    vocab = tok.get_vocab()
    out = {
        "cls_id":  vocab["[CLS]"],
        "sep_id":  vocab["[SEP]"],
        "pad_id":  vocab["[PAD]"],
        "mask_id": vocab["[MASK]"],
        "unk_id":  vocab["[UNK]"],
        "aa_unk":  {},          # AA letter -> aa_unk token id
        "codons_by_aa": defaultdict(list),  # AA letter -> [(codon_dna, token_id)]
        "id_to_codon": {},      # token id -> codon DNA string (uppercase)
        "vocab_size": len(vocab),
    }

    for tok_str, tid in vocab.items():
        # Pattern is "<aa>_<tail>" where aa is 1 char (lower) or "_" for stop
        if len(tok_str) >= 5 and tok_str[1] == "_":
            aa, tail = tok_str[0], tok_str[2:]
            aa_key = "*" if aa == "_" else aa.upper()
            if tail == "unk":
                out["aa_unk"][aa_key] = tid
            elif len(tail) == 3 and all(c in "acgt" for c in tail):
                out["codons_by_aa"][aa_key].append((tail.upper(), tid))
                out["id_to_codon"][tid] = tail.upper()

    out["codons_by_aa"] = dict(out["codons_by_aa"])
    return out


def build_codon_masks(token_maps, device):
    """Per-AA boolean mask [V] of valid codon token ids."""
    V = token_maps["vocab_size"]
    masks = {}
    for aa, codons in token_maps["codons_by_aa"].items():
        m = torch.zeros(V, dtype=torch.bool)
        for _dna, tid in codons:
            m[tid] = True
        masks[aa] = m.to(device)
    return masks


# =============================================================================
# Model loading
# =============================================================================

def load_model_and_species(checkpoint_path, num_species, device, hf_model_name):
    print(f"[load] checkpoint: {checkpoint_path}", flush=True)
    ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    sd = ckpt["state_dict"] if "state_dict" in ckpt else ckpt

    # Build inner ModernBertForMaskedLM with vocab override
    config = AutoConfig.from_pretrained(hf_model_name)
    config.vocab_size = 90
    config.pad_token_id = 3
    inner = AutoModelForMaskedLM.from_config(config)

    # Split state dict into the harness components
    model_sd, species_sd = {}, {}
    for k, v in sd.items():
        if k.startswith("model."):
            model_sd[k[len("model."):]] = v
        elif k.startswith("species_embed."):
            species_sd[k[len("species_embed."):]] = v

    miss, unexp = inner.load_state_dict(model_sd, strict=False)
    print(f"[load] inner model: missing={len(miss)} unexpected={len(unexp)}", flush=True)
    if miss[:3]:    print(f"[load]   miss[:3]={miss[:3]}", flush=True)
    if unexp[:3]:   print(f"[load]   unexp[:3]={unexp[:3]}", flush=True)

    species_embed = nn.Embedding(num_species, config.hidden_size)
    species_embed.load_state_dict(species_sd)
    print(f"[load] species_embed: {tuple(species_embed.weight.shape)}", flush=True)

    inner = inner.eval().to(device)
    species_embed = species_embed.eval().to(device)
    return inner, species_embed


# =============================================================================
# Input construction
# =============================================================================

def build_input_for_protein(protein, has_stop, token_maps, max_length):
    """[CLS] <aa>_unk * N [+ __unk if stop] [SEP]"""
    cls_id, sep_id = token_maps["cls_id"], token_maps["sep_id"]
    aa_unk, unk_id = token_maps["aa_unk"], token_maps["unk_id"]

    ids = [cls_id]
    codon_positions, aa_per_pos = [], []

    for aa in protein:
        aa_up = aa.upper()
        tid = aa_unk.get(aa_up, unk_id)
        codon_positions.append(len(ids))
        aa_per_pos.append(aa_up)
        ids.append(tid)

    if has_stop:
        codon_positions.append(len(ids))
        aa_per_pos.append("*")
        ids.append(aa_unk["*"])

    ids.append(sep_id)

    # Truncate: keep [CLS], as many codons as fit, [SEP]
    if len(ids) > max_length:
        keep = max_length - 2
        ids = [cls_id] + ids[1:1 + keep] + [sep_id]
        valid_max = max_length - 1
        codon_positions = [p for p in codon_positions if p < valid_max]
        aa_per_pos = aa_per_pos[:len(codon_positions)]

    return ids, codon_positions, aa_per_pos


# =============================================================================
# Generation
# =============================================================================

@torch.no_grad()
def generate_batch(model, species_embed, batch_records, token_maps,
                   codon_masks, species_to_id, unknown_species_id,
                   max_length, device, neg_inf):
    input_ids_list, codon_pos_list, aa_pos_list, sp_ids, meta_list = [], [], [], [], []

    for rec in batch_records:
        protein = rec["protein_sequence"].rstrip("*_")
        dna = rec["dna_sequence"]
        has_stop = (len(dna) >= 3 * (len(protein) + 1))
        ids, cps, aps = build_input_for_protein(protein, has_stop, token_maps, max_length)
        if not cps:
            continue
        sp_id = species_to_id.get(rec["species"], unknown_species_id)
        input_ids_list.append(ids)
        codon_pos_list.append(cps)
        aa_pos_list.append(aps)
        sp_ids.append(sp_id)
        meta_list.append({
            "species":      rec["species"],
            "genome_id":    rec.get("genome_id", ""),
            "protein_id":   rec.get("protein_id", ""),
            "protein_len":  len(protein),
            "has_stop":     has_stop,
            "native_dna":   dna,
        })

    if not input_ids_list:
        return []

    # Pad
    B = len(input_ids_list)
    Lmax = max(len(s) for s in input_ids_list)
    input_ids = torch.full((B, Lmax), token_maps["pad_id"], dtype=torch.long, device=device)
    attn_mask = torch.zeros((B, Lmax), dtype=torch.long, device=device)
    for j, s in enumerate(input_ids_list):
        L = len(s)
        input_ids[j, :L] = torch.tensor(s, dtype=torch.long, device=device)
        attn_mask[j, :L] = 1

    sp_tensor = torch.tensor(sp_ids, dtype=torch.long, device=device)

    # Forward (same recipe as forward_with_species_conditioning in CT2_eval.py)
    with torch.amp.autocast("cuda", dtype=torch.bfloat16):
        tok_embeds = model.get_input_embeddings()(input_ids)
        sp_vec = species_embed(sp_tensor)
        embeds = tok_embeds + sp_vec[:, None, :]
        out = model(inputs_embeds=embeds, attention_mask=attn_mask)
        logits = out.logits.float()  # [B, L, V]

    # Synonymous-restricted argmax per codon position
    results = []
    id_to_codon = token_maps["id_to_codon"]
    unk_codon = "NNN"
    for j in range(B):
        pred_codons = []
        for pos, aa in zip(codon_pos_list[j], aa_pos_list[j]):
            mask = codon_masks.get(aa)
            if mask is None:
                pred_codons.append(unk_codon)
                continue
            pos_logits = logits[j, pos]
            masked = torch.where(mask, pos_logits, neg_inf)
            tid = int(masked.argmax().item())
            pred_codons.append(id_to_codon.get(tid, unk_codon))
        meta = meta_list[j]
        meta["predicted_dna"] = "".join(pred_codons)
        results.append(meta)

    return results


# =============================================================================
# Test set loading
# =============================================================================

def load_test_records(test_dir, limit=None, rank=0, world_size=1):
    """Flatten all per-genome JSON files into one list of gene records, sharded by rank."""
    files = sorted(Path(test_dir).glob("*.json"))
    records = []
    for fp in files:
        with open(fp) as f:
            obj = json.load(f)
        species = obj.get("species", "unknown")
        genome_id = obj.get("genome_id", fp.stem)
        for gene in obj.get("genes", []):
            rec = dict(gene)
            rec["species"] = species
            rec["genome_id"] = genome_id
            records.append(rec)
            if limit and len(records) >= limit:
                break
        if limit and len(records) >= limit:
            break
    if rank == 0:
        print(f"[data] total records loaded: {len(records)}", flush=True)
    # Shard by rank
    records = records[rank::world_size]
    return records


# =============================================================================
# Main
# =============================================================================

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint",          required=True)
    ap.add_argument("--test_dir",            required=True)
    ap.add_argument("--tokenizer_file",      required=True)
    ap.add_argument("--species_to_id",       required=True)
    ap.add_argument("--out_dir",             required=True)
    ap.add_argument("--tag",                 required=True, help="Used in output filenames")
    ap.add_argument("--max_length",          type=int, default=2048)
    ap.add_argument("--batch_size",          type=int, default=8)
    ap.add_argument("--num_species",         type=int, default=28678)
    ap.add_argument("--unknown_species_id",  type=int, default=26678)
    ap.add_argument("--hf_model_name",       default="answerdotai/ModernBERT-base")
    ap.add_argument("--limit",               type=int, default=None,
                    help="Smoke test: limit total records before sharding")
    args = ap.parse_args()

    rank = int(os.environ.get("RANK", 0))
    world_size = int(os.environ.get("WORLD_SIZE", 1))
    local_rank = int(os.environ.get("LOCAL_RANK", 0))
    if world_size > 1:
        dist.init_process_group(backend="nccl")
    torch.cuda.set_device(local_rank)
    device = torch.device(f"cuda:{local_rank}")

    if rank == 0:
        print(f"[ddp] world_size={world_size}", flush=True)

    # Token maps
    token_maps = build_token_maps(args.tokenizer_file)
    if rank == 0:
        print(f"[tok] vocab_size={token_maps['vocab_size']}", flush=True)
        print(f"[tok] aa_unk keys: {sorted(token_maps['aa_unk'].keys())}", flush=True)
        print(f"[tok] codons_by_aa keys: {sorted(token_maps['codons_by_aa'].keys())}", flush=True)

    # Species map
    with open(args.species_to_id) as f:
        species_to_id = json.load(f)
    if rank == 0:
        print(f"[data] species_to_id entries: {len(species_to_id)}", flush=True)

    # Model + species embed
    model, species_embed = load_model_and_species(
        args.checkpoint, args.num_species, device, args.hf_model_name
    )

    codon_masks = build_codon_masks(token_maps, device)
    neg_inf = torch.tensor(-1e30, dtype=torch.float32, device=device)

    # Records (sharded across ranks)
    records = load_test_records(args.test_dir, limit=args.limit,
                                rank=rank, world_size=world_size)
    print(f"[rank {rank}] records to process: {len(records)}", flush=True)

    # Loop
    out_rows = []
    fail = 0
    for i in tqdm(range(0, len(records), args.batch_size),
                  desc=f"rank {rank}",
                  disable=(rank != 0)):
        batch = records[i:i + args.batch_size]
        try:
            results = generate_batch(
                model, species_embed, batch, token_maps,
                codon_masks, species_to_id, args.unknown_species_id,
                args.max_length, device, neg_inf,
            )
            out_rows.extend(results)
        except Exception as e:
            fail += 1
            if fail <= 5:
                print(f"[rank {rank}] batch {i} failed: {type(e).__name__}: {e}", flush=True)

    # Write rank-local parquet
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"predictions_{args.tag}_rank{rank:02d}.parquet"
    pd.DataFrame(out_rows).to_parquet(out_path, index=False)
    print(f"[rank {rank}] wrote {len(out_rows)} rows to {out_path} (failed batches: {fail})",
          flush=True)

    if world_size > 1:
        dist.barrier()
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
