"""
eval_formal_csi_species_rank_gpu_rare.py

Formal CSI species-rank with rare-mode sensitivity.

Differences from eval_formal_csi_species_rank_gpu.py:

  1. Loops over 3 rare modes ("all", "no_rare_0_001", "no_rare_0_01"),
     applying the exact same parquet-row filter as
     eval_minmax_ct2_stages.py (`use = use[~use[rare_col]]`).

  2. Uses a mask + count-of-used approach instead of a -50 fallback:
        per-(sequence, species) score
          = mean log-weight over codons whose (species, aa, codon)
            survives the rare filter in this species' table.
     The original "-50 if missing" approach would PENALIZE rare codons
     under rare modes rather than FILTER them out, which contradicts
     the MinMax-style rare-drop intent. With mask/n_used, missing /
     filtered codons are simply skipped, exactly as MinMax does.

  3. Where no codon in the sequence has a valid weight for some species,
     that species' score is set to -inf so it ranks at the bottom.
     If the true species itself ends up with no valid codons, true_rank
     is NaN and that row is dropped from the summary aggregates.

NOTE on the "all" mode: in cells where the codon legitimately doesn't
exist in a species' table (very rare in the all-codons case), the score
will use n_used instead of -50 as the original did. So "all"-mode
absolute numbers may differ from the previous rank CSV in those edge
cases. Internal comparability across rare modes is preserved.

Usage:
  python eval_formal_csi_species_rank_gpu_rare.py \\
    --predictions ct1_vs_ct2_all_trunc2046_common_valid_predictions.csv \\
    --codon_table ct2_codon_usage_tables_qc/ct2_train_species_codon_frequencies_clean.parquet \\
    --out_prefix formal_csi_rank_rare_ct1_vs_ct2_all_trunc2046_common_valid \\
    --batch_size 512 --device cuda
"""

import argparse
import math

import numpy as np
import pandas as pd
import torch
from tqdm import tqdm


GENETIC_CODE = {
    "TTT": "F", "TTC": "F", "TTA": "L", "TTG": "L",
    "TCT": "S", "TCC": "S", "TCA": "S", "TCG": "S",
    "TAT": "Y", "TAC": "Y", "TAA": "*", "TAG": "*",
    "TGT": "C", "TGC": "C", "TGA": "*", "TGG": "W",
    "CTT": "L", "CTC": "L", "CTA": "L", "CTG": "L",
    "CCT": "P", "CCC": "P", "CCA": "P", "CCG": "P",
    "CAT": "H", "CAC": "H", "CAA": "Q", "CAG": "Q",
    "CGT": "R", "CGC": "R", "CGA": "R", "CGG": "R",
    "ATT": "I", "ATC": "I", "ATA": "I", "ATG": "M",
    "ACT": "T", "ACC": "T", "ACA": "T", "ACG": "T",
    "AAT": "N", "AAC": "N", "AAA": "K", "AAG": "K",
    "AGT": "S", "AGC": "S", "AGA": "R", "AGG": "R",
    "GTT": "V", "GTC": "V", "GTA": "V", "GTG": "V",
    "GCT": "A", "GCC": "A", "GCA": "A", "GCG": "A",
    "GAT": "D", "GAC": "D", "GAA": "E", "GAG": "E",
    "GGT": "G", "GGC": "G", "GGA": "G", "GGG": "G",
}

SENSE_CODONS = [c for c, aa in GENETIC_CODE.items() if aa != "*"]
CODON_TO_IDX = {c: i for i, c in enumerate(SENSE_CODONS)}
N_CODONS = len(SENSE_CODONS)


def clean_dna(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def count_codons(seq):
    seq = clean_dna(seq)
    v = np.zeros(N_CODONS, dtype=np.float32)
    n = 0
    for i in range(0, len(seq) - 2, 3):
        codon = seq[i:i + 3]
        j = CODON_TO_IDX.get(codon)
        if j is not None:
            v[j] += 1.0
            n += 1
    return v, n


def build_matrices(freq_df, species_list, rare_col):
    """
    logw [N_CODONS, n_species] : log of formal-CSI weight where lookup exists (0 elsewhere)
    mask [N_CODONS, n_species] : 1 where lookup exists after rare filter, else 0
    """
    use = freq_df.copy()
    if rare_col is not None:
        use = use[~use[rare_col]].copy()

    max_freq = (
        use.groupby(["species", "aa"], as_index=False)["frequency"]
        .max()
        .rename(columns={"frequency": "max_frequency"})
    )
    use = use.merge(max_freq, on=["species", "aa"], how="left")
    use["weight"] = use["frequency"] / use["max_frequency"]

    species_to_col = {s: i for i, s in enumerate(species_list)}

    logw = np.zeros((N_CODONS, len(species_list)), dtype=np.float32)
    mask = np.zeros((N_CODONS, len(species_list)), dtype=np.float32)

    for r in tqdm(use.itertuples(index=False), total=len(use),
                  desc=f"matrices [{rare_col or 'all'}]"):
        if pd.isna(r.weight):
            continue
        codon = str(r.codon)
        species = str(r.species)
        w = float(r.weight)
        if codon in CODON_TO_IDX and species in species_to_col and w > 0:
            ci = CODON_TO_IDX[codon]
            si = species_to_col[species]
            logw[ci, si] = float(math.log(w))
            mask[ci, si] = 1.0

    return logw, mask


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--out_prefix", required=True)
    ap.add_argument("--batch_size", type=int, default=512)
    ap.add_argument("--device", default="cuda")
    args = ap.parse_args()

    device = torch.device(args.device if args.device == "cuda" and torch.cuda.is_available() else "cpu")
    print("device:", device, flush=True)

    pred = pd.read_csv(args.predictions, low_memory=False)
    pred = pred[pred["pred_dna"].fillna("").astype(str).str.len() > 0].copy()
    pred = pred.reset_index(drop=True)

    freq = pd.read_parquet(args.codon_table)
    freq["species"] = freq["species"].astype(str)

    species_list = sorted(freq["species"].dropna().unique().tolist())
    species_to_col = {s: i for i, s in enumerate(species_list)}

    print("prediction rows:", len(pred), flush=True)
    print("models:", pred["model"].nunique(), flush=True)
    print("species in codon table (rank universe):", len(species_list), flush=True)

    # Codon counts
    X = np.zeros((len(pred), N_CODONS), dtype=np.float32)
    n_valid = np.zeros(len(pred), dtype=np.int32)
    for i, seq in enumerate(tqdm(pred["pred_dna"], desc="counting codons")):
        v, n = count_codons(seq)
        X[i] = v
        n_valid[i] = n

    true_cols = pred["species"].astype(str).map(species_to_col).fillna(-1).astype(int).to_numpy()
    true_present = (true_cols >= 0) & (n_valid > 0)

    has_eval_id = "eval_id" in pred.columns
    has_bucket = "bucket" in pred.columns
    has_protein_len = "protein_len" in pred.columns

    all_rows = []
    rare_modes = [
        ("all", None),
        ("no_rare_0_001", "rare_lt_0_001"),
        ("no_rare_0_01", "rare_lt_0_01"),
    ]

    for rare_mode, rare_col in rare_modes:
        print("\n" + "=" * 80, flush=True)
        print("RARE MODE:", rare_mode, flush=True)
        print("=" * 80, flush=True)

        logw, mask = build_matrices(freq, species_list, rare_col)
        print(f"  mask coverage: {mask.sum():.0f} / {mask.size} cells ({100 * mask.mean():.4f}%)", flush=True)
        logw_t = torch.tensor(logw, dtype=torch.float32, device=device)
        mask_t = torch.tensor(mask, dtype=torch.float32, device=device)

        for start in tqdm(range(0, len(pred), args.batch_size), desc=f"rank [{rare_mode}]"):
            end = min(start + args.batch_size, len(pred))
            xb = torch.tensor(X[start:end], dtype=torch.float32, device=device)

            sum_logw = xb @ logw_t            # [B, S]
            n_used = xb @ mask_t              # [B, S]
            safe_n = torch.where(n_used > 0, n_used, torch.ones_like(n_used))
            scores = sum_logw / safe_n
            neg_inf = torch.full_like(scores, float("-inf"))
            scores = torch.where(n_used > 0, scores, neg_inf)

            for i in range(end - start):
                row_idx = start + i
                row = {
                    "rare_mode": rare_mode,
                    "row_id": row_idx,
                    "model": pred.loc[row_idx, "model"],
                    "species": pred.loc[row_idx, "species"],
                    "n_species_ranked": len(species_list),
                }

                if not true_present[row_idx]:
                    row.update({
                        "true_species_in_table": bool(true_cols[row_idx] >= 0),
                        "formal_csi_log_true_score": float("nan"),
                        "true_rank": float("nan"),
                        "n_codons_used_own": 0,
                    })
                else:
                    tcol = int(true_cols[row_idx])
                    true_score_t = scores[i, tcol]
                    if not torch.isfinite(true_score_t):
                        row.update({
                            "true_species_in_table": True,
                            "formal_csi_log_true_score": float("nan"),
                            "true_rank": float("nan"),
                            "n_codons_used_own": 0,
                        })
                    else:
                        # rank = 1 + number of species with strictly higher score
                        rank = int((scores[i] > true_score_t).sum().item()) + 1
                        row.update({
                            "true_species_in_table": True,
                            "formal_csi_log_true_score": float(true_score_t.item()),
                            "true_rank": rank,
                            "n_codons_used_own": int(n_used[i, tcol].item()),
                        })

                if has_eval_id:
                    row["eval_id"] = pred.loc[row_idx, "eval_id"]
                if has_bucket:
                    row["bucket"] = pred.loc[row_idx, "bucket"]
                if has_protein_len:
                    row["protein_len"] = pred.loc[row_idx, "protein_len"]
                all_rows.append(row)

    out = pd.DataFrame(all_rows)
    out_seq = f"{args.out_prefix}_by_sequence.csv"
    out.to_csv(out_seq, index=False)

    summary = (
        out.dropna(subset=["true_rank"])
        .groupby(["rare_mode", "model"], as_index=False)
        .agg(
            n=("row_id", "count"),
            mean_true_rank=("true_rank", "mean"),
            median_true_rank=("true_rank", "median"),
            top1_rate=("true_rank", lambda x: (x <= 1).mean()),
            top5_rate=("true_rank", lambda x: (x <= 5).mean()),
            top10_rate=("true_rank", lambda x: (x <= 10).mean()),
            top100_rate=("true_rank", lambda x: (x <= 100).mean()),
            mean_reciprocal_rank=("true_rank", lambda x: (1.0 / x).mean()),
        )
    )
    out_model = f"{args.out_prefix}_summary_by_model.csv"
    summary.to_csv(out_model, index=False)

    print("\n=== FORMAL CSI RANK (rare modes) SUMMARY ===", flush=True)
    print(summary.to_string(index=False), flush=True)
    print("\nwrote:", out_seq, flush=True)
    print("wrote:", out_model, flush=True)


if __name__ == "__main__":
    main()
