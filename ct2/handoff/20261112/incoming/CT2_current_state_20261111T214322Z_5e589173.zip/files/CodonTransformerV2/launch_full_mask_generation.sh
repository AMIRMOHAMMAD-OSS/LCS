#!/bin/bash
# Submit one job per checkpoint. Each runs on its own 4-H100 node so they
# parallelise. Drop --limit for the full run, set LIMIT=1000 for smoke test.

set -euo pipefail
cd /lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2

declare -A CKPTS=(
  [stage4_e7]="/lustre/fsn1/projects/rech/nef/unh87ms/ct2_final/h100_8gpu_stage4_len2048_from_stage3e14_bs56_w2_acc3_lr5e6/epoch_7.ckpt"
  [stage5_e3]="/lustre/fsn1/projects/rech/nef/unh87ms/ct2_final/h100_8gpu_stage5_fullmask30_from_stage4e7_bs32_w2_acc5_lr2e6_884719/epoch_3.ckpt"
  [stage5_cont_e4]="/lustre/fsn1/projects/rech/nef/unh87ms/ct2_final/h100_8gpu_stage5_continue5_fullmask30_from_s5e3_bs32_w2_acc5_lr1e6_1079089/epoch_4.ckpt"
  [stage6_e2]="/lustre/fsn1/projects/rech/nef/unh87ms/ct2_final/h100_8gpu_stage6_from_s5cont_e4_bs32_w2_acc5_lr5e7_multimetric_1269831/epoch_2.ckpt"
)

# Pass LIMIT=1000 as env var for smoke test, e.g.:
#   LIMIT=1000 bash launch_full_mask_generation.sh stage5_cont_e4
# Or no LIMIT for full run.

# Optional positional arg: a single tag to run; otherwise launch all.
TARGET="${1:-}"

for tag in "${!CKPTS[@]}"; do
  if [ -n "$TARGET" ] && [ "$TARGET" != "$tag" ]; then
    continue
  fi
  ckpt="${CKPTS[$tag]}"
  if [ ! -f "$ckpt" ]; then
    echo "WARN: checkpoint missing for $tag — $ckpt"
    continue
  fi
  jobid=$(sbatch --export=ALL,CKPT="$ckpt",TAG="$tag",LIMIT="${LIMIT:-}" \
                 --job-name="ct2gen_$tag" \
                 preflight_slurm/80_ct2_full_mask_generation.slurm | awk '{print $4}')
  echo "submitted $tag → jobid $jobid"
done

echo
squeue -u unh87ms
