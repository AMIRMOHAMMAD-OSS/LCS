from pathlib import Path
import re

OUT = Path("ct2_stage1_stage4_training_setups_clean.md")

search_dirs = [Path("preflight_slurm")]
files = []
for d in search_dirs:
    if d.exists():
        files.extend(sorted(d.glob("*.slurm")))

def extract_python_blocks(text):
    lines = text.splitlines()
    blocks = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if "train_updated.py" in line and ("python" in line or "srun" in line):
            block = [line]
            i += 1
            while i < len(lines):
                block.append(lines[i])
                if not lines[i].rstrip().endswith("\\"):
                    break
                i += 1
            blocks.append("\n".join(block))
        i += 1
    return blocks

def infer_stage(fname, block):
    hay = f"{fname}\n{block}".lower()
    # Prefer checkpoint_dir stage labels over file-name noise.
    for stage in ["stage4", "stage3", "stage2", "stage1"]:
        if stage in hay:
            return stage
    return "unknown"

candidates = []
for f in files:
    text = f.read_text(errors="ignore")
    if "train_updated.py" not in text:
        continue

    for block in extract_python_blocks(text):
        low = block.lower()

        # skip eval-only / comparison / smoke / stage5
        if "--eval_only" in low:
            continue
        if "stage5" in low or "fullmask30" in low or "--full_mask_probability 0.30" in low:
            continue
        if "eval_" in low or "comparison" in low:
            continue

        stage = infer_stage(f, block)
        candidates.append((stage, f, block))

# Keep useful candidates grouped by stage.
by_stage = {s: [] for s in ["stage1", "stage2", "stage3", "stage4", "unknown"]}
for stage, f, block in candidates:
    by_stage.setdefault(stage, []).append((f, block))

with OUT.open("w") as out:
    out.write("# CT2 Stage 1-4 Main Training Setups\n\n")
    for stage in ["stage1", "stage2", "stage3", "stage4"]:
        out.write(f"## {stage.upper()}\n\n")
        items = by_stage.get(stage, [])
        if not items:
            out.write("NOT FOUND in preflight_slurm/*.slurm\n\n")
            continue

        # print all candidates for that stage, because stage1/2 may have retries
        for idx, (f, block) in enumerate(items, 1):
            out.write(f"### Candidate {idx}\n")
            out.write(f"Source: `{f}`\n\n")
            out.write("```bash\n")
            out.write(block.rstrip() + "\n")
            out.write("```\n\n")

print(f"WROTE {OUT}")
print(OUT.read_text())
