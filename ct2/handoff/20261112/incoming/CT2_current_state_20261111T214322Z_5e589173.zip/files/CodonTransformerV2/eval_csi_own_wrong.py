import argparse
import hashlib
from pathlib import Path

import numpy as np
import pandas as pd


GENETIC_CODE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}


DNA_COL_CANDIDATES = [
    "pred_dna", "predicted_dna", "generated_dna", "optimized_dna",
    "prediction", "pred_sequence", "generated_sequence", "output_sequence",
    "dna", "dna_sequence", "nt_sequence", "sequence",
]

SPECIES_COL_CANDIDATES = ["species", "organism", "organism_name", "species_name"]
MODEL_COL_CANDIDATES = ["model", "model_name", "checkpoint"]


def pick_col(df, candidates, required=True, label="column"):
    for c in candidates:
        if c in df.columns:
            return c
    if required:
        raise SystemExit(
            f"Could not find {label}. Candidates={candidates}\n"
            f"Available columns={df.columns.tolist()}"
        )
    return None


def normalize_dna(seq):
    if pd.isna(seq):
        return ""
    return str(seq).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def codons_from_dna(seq):
    seq = normalize_dna(seq)
    n = len(seq) // 3
    out = []
    for i in range(n):
        codon = seq[3 * i:3 * i + 3]
        if len(codon) != 3:
            continue
        if any(c not in "ACGT" for c in codon):
            continue
        aa = GENETIC_CODE.get(codon)
        if aa is None or aa == "*":
            continue
        out.append((aa, codon))
    return out


def stable_wrong_species(species_list, true_species, row_key, n=5):
    candidates = [s for s in species_list if s != true_species]
    if not candidates:
        return []
    h = hashlib.md5(str(row_key).encode("utf-8")).hexdigest()
    seed = int(h[:8], 16)
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(candidates), size=min(n, len(candidates)), replace=False)
    return [candidates[i] for i in idx]


def build_freq_lookup(freq_df, rare_mode):
    d = {}

    use = freq_df
    if rare_mode == "no_rare_0_001":
        use = use[~use["rare_lt_0_001"]]
    elif rare_mode == "no_rare_0_01":
        use = use[~use["rare_lt_0_01"]]

    for r in use.itertuples(index=False):
        d[(r.species, r.aa, r.codon)] = float(r.frequency)

    return d


def score_sequence(codons, species, freq_lookup, eps=1e-9):
    logs = []
    missing = 0

    for aa, codon in codons:
        f = freq_lookup.get((species, aa, codon))
        if f is None:
            missing += 1
            f = eps
        logs.append(np.log(max(f, eps)))

    if not logs:
        return {
            "n_codons_scored": 0,
            "missing_freq_codons": missing,
            "csi_log_mean": np.nan,
            "csi_geomean": np.nan,
        }

    log_mean = float(np.mean(logs))
    return {
        "n_codons_scored": len(logs),
        "missing_freq_codons": missing,
        "csi_log_mean": log_mean,
        "csi_geomean": float(np.exp(log_mean)),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--out_prefix", default="csi_own_wrong")
    ap.add_argument("--wrong_n", type=int, default=5)
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    pred_path = Path(args.predictions)
    table_path = Path(args.codon_table)

    print("Loading predictions:", pred_path)
    pred = pd.read_csv(pred_path)
    if args.limit:
        pred = pred.head(args.limit).copy()

    species_col = pick_col(pred, SPECIES_COL_CANDIDATES, label="species column")
    model_col = pick_col(pred, MODEL_COL_CANDIDATES, required=False, label="model column")
    dna_col = pick_col(pred, DNA_COL_CANDIDATES, label="DNA/generated sequence column")

    if model_col is None:
        pred["model"] = "unknown_model"
        model_col = "model"

    print("prediction rows:", len(pred))
    print("Using species_col:", species_col)
    print("Using model_col:", model_col)
    print("Using dna_col:", dna_col)

    print("Loading codon table:", table_path)
    freq_df = pd.read_parquet(table_path)
    species_list = sorted(freq_df["species"].dropna().unique().tolist())
    species_set = set(species_list)

    print("codon table rows:", len(freq_df))
    print("codon table species:", len(species_list))

    all_results = []

    for rare_mode in ["all", "no_rare_0_001", "no_rare_0_01"]:
        print("Building lookup:", rare_mode)
        freq_lookup = build_freq_lookup(freq_df, rare_mode)

        rows = []
        for idx, r in pred.iterrows():
            true_species = str(r[species_col])
            model = str(r[model_col])
            dna = r[dna_col]
            codons = codons_from_dna(dna)

            own = score_sequence(codons, true_species, freq_lookup)

            wrong_species = stable_wrong_species(
                species_list,
                true_species,
                row_key=f"{idx}_{true_species}_{model}",
                n=args.wrong_n,
            )

            wrong_logs = []
            for ws in wrong_species:
                wrong_logs.append(score_sequence(codons, ws, freq_lookup)["csi_log_mean"])

            wrong_logs = [x for x in wrong_logs if not pd.isna(x)]
            wrong_log_mean = float(np.mean(wrong_logs)) if wrong_logs else np.nan
            wrong_geomean = float(np.exp(wrong_log_mean)) if not pd.isna(wrong_log_mean) else np.nan

            own_log = own["csi_log_mean"]
            own_geo = own["csi_geomean"]

            rows.append({
                "rare_mode": rare_mode,
                "row_id": idx,
                "model": model,
                "species": true_species,
                "species_in_table": true_species in species_set,
                "dna_col": dna_col,
                "n_codons_scored": own["n_codons_scored"],
                "missing_freq_codons_own": own["missing_freq_codons"],
                "csi_log_own": own_log,
                "csi_geomean_own": own_geo,
                "wrong_n": len(wrong_logs),
                "csi_log_wrong_mean": wrong_log_mean,
                "csi_geomean_wrong_mean": wrong_geomean,
                "delta_log_own_minus_wrong": own_log - wrong_log_mean if not pd.isna(own_log) and not pd.isna(wrong_log_mean) else np.nan,
                "ratio_geomean_own_over_wrong": own_geo / wrong_geomean if wrong_geomean and not pd.isna(own_geo) else np.nan,
                "wrong_species_sample": ";".join(wrong_species[:5]),
            })

        res = pd.DataFrame(rows)
        all_results.append(res)

    by_seq = pd.concat(all_results, ignore_index=True)

    out_seq = f"{args.out_prefix}_by_sequence.csv"
    by_seq.to_csv(out_seq, index=False)

    summary_model = (
        by_seq.groupby(["rare_mode", "model"], as_index=False)
        .agg(
            n=("row_id", "count"),
            species_in_table_rate=("species_in_table", "mean"),
            mean_codons_scored=("n_codons_scored", "mean"),
            csi_log_own=("csi_log_own", "mean"),
            csi_log_wrong_mean=("csi_log_wrong_mean", "mean"),
            delta_log_own_minus_wrong=("delta_log_own_minus_wrong", "mean"),
            csi_geomean_own=("csi_geomean_own", "mean"),
            csi_geomean_wrong_mean=("csi_geomean_wrong_mean", "mean"),
            ratio_geomean_own_over_wrong=("ratio_geomean_own_over_wrong", "mean"),
        )
    )

    out_model = f"{args.out_prefix}_summary_by_model.csv"
    summary_model.to_csv(out_model, index=False)

    summary_species = (
        by_seq.groupby(["rare_mode", "model", "species"], as_index=False)
        .agg(
            n=("row_id", "count"),
            mean_codons_scored=("n_codons_scored", "mean"),
            csi_log_own=("csi_log_own", "mean"),
            csi_log_wrong_mean=("csi_log_wrong_mean", "mean"),
            delta_log_own_minus_wrong=("delta_log_own_minus_wrong", "mean"),
            ratio_geomean_own_over_wrong=("ratio_geomean_own_over_wrong", "mean"),
        )
    )

    out_species = f"{args.out_prefix}_summary_by_species.csv"
    summary_species.to_csv(out_species, index=False)

    print()
    print("=== SUMMARY BY MODEL ===")
    print(summary_model.to_string(index=False))
    print()
    print("WROTE")
    print(out_seq)
    print(out_model)
    print(out_species)


if __name__ == "__main__":
    main()
