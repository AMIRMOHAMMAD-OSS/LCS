import json
import sys
import tarfile
from pathlib import Path
from collections import defaultdict, Counter

import pandas as pd

try:
    from tqdm import tqdm
except Exception:
    tqdm = None

TRAIN_DIR = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/train_set_shard")
OUTDIR = Path("ct2_codon_frequency_tables")
OUTDIR.mkdir(exist_ok=True)

STANDARD_BASES = set("ATCG")

GENETIC_CODE = {
    "TTT": "F", "TTC": "F", "TTA": "L", "TTG": "L",
    "TCT": "S", "TCC": "S", "TCA": "S", "TCG": "S",
    "TAT": "Y", "TAC": "Y", "TAA": "*", "TAG": "*",
    "TGT": "C", "TGC": "C", "TGA": "*", "TGG": "W",
    "CTT": "L", "CTC": "L", "CTA": "L", "CTG": "L",
    "CCT": "P", "CCC": "P", "CCA": "P", "CCG": "P",
    "CAT": "H", "CAC": "H", "CAA": "Q", "CAG": "Q",
    "CGT": "R", "CGC": "R", "CGA": "R", "CGG": "R",
    "ATT": "I", "ATC": "I", "ATA": "I", "ATG": "M",
    "ACT": "T", "ACC": "T", "ACA": "T", "ACG": "T",
    "AAT": "N", "AAC": "N", "AAA": "K", "AAG": "K",
    "AGT": "S", "AGC": "S", "AGA": "R", "AGG": "R",
    "GTT": "V", "GTC": "V", "GTA": "V", "GTG": "V",
    "GCT": "A", "GCC": "A", "GCA": "A", "GCG": "A",
    "GAT": "D", "GAC": "D", "GAA": "E", "GAG": "E",
    "GGT": "G", "GGC": "G", "GGA": "G", "GGG": "G",
}


def parse_json_bytes(raw):
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", errors="ignore")
    raw = raw.strip()
    if not raw:
        return []

    try:
        obj = json.loads(raw)
    except Exception:
        return []

    if isinstance(obj, dict):
        if "genes" in obj and isinstance(obj["genes"], list):
            out = []
            species = obj.get("species")
            genome_id = obj.get("genome_id")
            for g in obj["genes"]:
                if isinstance(g, dict):
                    gg = dict(g)
                    gg.setdefault("species", species)
                    gg.setdefault("genome_id", genome_id)
                    out.append(gg)
            return out
        return [obj]

    if isinstance(obj, list):
        return [x for x in obj if isinstance(x, dict)]

    return []


def iter_train_records():
    shards = sorted(TRAIN_DIR.glob("*.tar")) + sorted(TRAIN_DIR.glob("*.tar.gz")) + sorted(TRAIN_DIR.glob("*.tgz"))
    print("train shards:", len(shards), flush=True)

    iterator = tqdm(shards, desc="Scanning TRAIN shards", unit="shard", file=sys.stdout, dynamic_ncols=True, mininterval=10) if tqdm else shards

    for si, shard in enumerate(iterator, 1):
        if tqdm is None and si % 100 == 0:
            print(f"shard {si}/{len(shards)} {shard.name}", flush=True)

        try:
            with tarfile.open(shard, "r:*") as tar:
                for member in tar:
                    if not member.isfile():
                        continue

                    name = member.name.lower()
                    if not (name.endswith(".json") or name.endswith(".jsonl")):
                        continue

                    f = tar.extractfile(member)
                    if f is None:
                        continue

                    raw = f.read()

                    if name.endswith(".jsonl"):
                        for line in raw.decode("utf-8", errors="ignore").splitlines():
                            for rec in parse_json_bytes(line):
                                yield rec
                    else:
                        for rec in parse_json_bytes(raw):
                            yield rec

        except Exception as e:
            print("BAD SHARD", shard, repr(e), flush=True)


def clean_species(x):
    if x is None:
        return "UNKNOWN"
    return str(x)


def count_record(rec, counts_by_species, counts_by_genome, stats):
    species = clean_species(rec.get("species"))
    genome_id = str(rec.get("genome_id") or "UNKNOWN")

    dna = (
        rec.get("dna_sequence")
        or rec.get("dna")
        or rec.get("cds")
        or rec.get("sequence")
        or ""
    )
    protein = (
        rec.get("protein_sequence")
        or rec.get("protein")
        or rec.get("aa_sequence")
        or ""
    )

    dna = str(dna).upper().replace("U", "T")
    protein = str(protein).replace("*", "_")

    n_codons = len(dna) // 3
    if n_codons <= 0:
        stats["missing_or_empty"] += 1
        return

    if protein:
        n = min(n_codons, len(protein))
    else:
        n = n_codons

    for i in range(n):
        codon = dna[3*i:3*i+3]
        if len(codon) != 3 or any(b not in STANDARD_BASES for b in codon):
            stats["bad_codon"] += 1
            continue

        if protein:
            aa = protein[i]
            if aa == "_":
                aa = "*"
        else:
            aa = GENETIC_CODE.get(codon)

        if aa is None:
            stats["unknown_aa"] += 1
            continue

        # Optional consistency check: if protein is present and disagrees with standard table,
        # keep the protein-provided AA because that matches CT2 token construction.
        counts_by_species[(species, aa)][codon] += 1
        stats["codons_counted"] += 1

    stats["records_counted"] += 1


def counts_to_df_species(counts_by_species):
    rows = []
    for (species, aa), counter in counts_by_species.items():
        total = sum(counter.values())
        for codon, count in sorted(counter.items()):
            rows.append({
                "level": "species",
                "species": species,
                "genome_id": "",
                "aa": aa,
                "codon": codon,
                "count": count,
                "aa_total_count": total,
                "frequency": count / total if total else 0.0,
            })
    return pd.DataFrame(rows)


def counts_to_df_genome(counts_by_genome):
    rows = []
    for (genome_id, species, aa), counter in counts_by_genome.items():
        total = sum(counter.values())
        for codon, count in sorted(counter.items()):
            rows.append({
                "level": "genome",
                "species": species,
                "genome_id": genome_id,
                "aa": aa,
                "codon": codon,
                "count": count,
                "aa_total_count": total,
                "frequency": count / total if total else 0.0,
            })
    return pd.DataFrame(rows)


def main():
    counts_by_species = defaultdict(Counter)
    counts_by_genome = None
    stats = Counter()

    for i, rec in enumerate(iter_train_records(), 1):
        count_record(rec, counts_by_species, counts_by_genome, stats)

        if i % 1_000_000 == 0:
            print(
                f"records_seen={i:,} records_counted={stats['records_counted']:,} codons_counted={stats['codons_counted']:,}",
                flush=True,
            )

    print("Final stats:", dict(stats), flush=True)

    species_df = counts_to_df_species(counts_by_species)
    species_df.to_csv(OUTDIR / "ct2_species_codon_frequencies_train.csv", index=False)

    pd.DataFrame([dict(stats)]).to_csv(OUTDIR / "ct2_codon_frequency_build_stats.csv", index=False)

    # Rare codon summaries for threshold choice
    for threshold in [0.001, 0.01]:
        s = species_df.copy()
        s["is_rare"] = s["frequency"] < threshold
        rare_summary = (
            s.groupby(["species", "aa"])
            .agg(
                n_codons=("codon", "count"),
                n_rare=("is_rare", "sum"),
                total_count=("aa_total_count", "max"),
            )
            .reset_index()
        )
        rare_summary["threshold"] = threshold
        rare_summary.to_csv(OUTDIR / f"ct2_species_rare_codon_summary_threshold_{threshold}.csv", index=False)

    print("WROTE:")
    for p in sorted(OUTDIR.glob("*.csv")):
        print(p, p.stat().st_size, flush=True)


if __name__ == "__main__":
    main()
