import argparse
import re
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from tqdm import tqdm
from transformers import AutoTokenizer, BigBirdForMaskedLM

from CodonTransformer.CodonPrediction import predict_dna_sequence


CT1_MODEL_DIR = Path("/linkhome/rech/genjqx01/unh87ms/.cache/huggingface/hub/models--adibvafa--CodonTransformer/snapshots/9744dcc920d813066391fc828d7a590207f148e8")
STOP_CODONS = {"TAA", "TAG", "TGA"}


def clean_dna(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def extract_predicted_dna(x):
    """
    Robustly extract CT1 predicted DNA from DNASequencePrediction.
    Current CT1 returns an object with lowercase .predicted_dna.
    """
    if x is None:
        return ""

    # Best path: CT1 DNASequencePrediction object attribute.
    for attr in [
        "predicted_dna",
        "PREDICTED_DNA",
        "pred_dna",
        "dna",
        "DNA",
        "sequence",
        "optimized_dna",
        "OPTIMIZED_DNA",
    ]:
        if hasattr(x, attr):
            try:
                y = clean_dna(getattr(x, attr))
                if y and set(y).issubset(set("ACGTN")):
                    return y
            except Exception:
                pass

    # Dict-like return.
    if isinstance(x, dict):
        for key in [
            "predicted_dna",
            "PREDICTED_DNA",
            "pred_dna",
            "dna",
            "DNA",
            "sequence",
            "optimized_dna",
            "OPTIMIZED_DNA",
        ]:
            if key in x:
                y = clean_dna(x[key])
                if y and set(y).issubset(set("ACGTN")):
                    return y

    # Tuple/list return.
    if isinstance(x, (list, tuple)):
        for item in x:
            y = extract_predicted_dna(item)
            if y:
                return y

    # Repr/string fallback.
    st = str(x)
    patterns = [
        r"predicted_dna\s*=\s*'([ACGTUNacgtun\s\r\n]+)'",
        r'predicted_dna\s*=\s*"([ACGTUNacgtun\s\r\n]+)"',
        r"PREDICTED_DNA\s*=\s*'([ACGTUNacgtun\s\r\n]+)'",
        r'PREDICTED_DNA\s*=\s*"([ACGTUNacgtun\s\r\n]+)"',
        r"pred_dna\s*=\s*'([ACGTUNacgtun\s\r\n]+)'",
        r'pred_dna\s*=\s*"([ACGTUNacgtun\s\r\n]+)"',
        r"dna\s*=\s*'([ACGTUNacgtun\s\r\n]+)'",
        r'dna\s*=\s*"([ACGTUNacgtun\s\r\n]+)"',
        r"DNA\s*=\s*'([ACGTUNacgtun\s\r\n]+)'",
        r'DNA\s*=\s*"([ACGTUNacgtun\s\r\n]+)"',
    ]

    for pat in patterns:
        m = re.search(pat, st)
        if m:
            y = clean_dna(m.group(1))
            if y and set(y).issubset(set("ACGTN")):
                return y

    # If the whole string is plain DNA.
    y = clean_dna(st)
    if y and set(y).issubset(set("ACGTN")):
        return y

    return ""


def trim_terminal_stop_to_protein_len(seq, protein_len):
    seq = clean_dna(seq)
    target_len = int(protein_len) * 3
    if len(seq) == target_len:
        return seq
    if len(seq) == target_len + 3 and seq[-3:] in STOP_CODONS:
        return seq[:target_len]
    if len(seq) > target_len:
        return seq[:target_len]
    return seq


def gc_content(seq):
    seq = clean_dna(seq)
    if not seq:
        return np.nan
    return sum(1 for c in seq if c in "GC") / len(seq)


def gc3_content(seq):
    seq = clean_dna(seq)
    codons = [seq[i:i+3] for i in range(0, len(seq)-2, 3)]
    if not codons:
        return np.nan
    third = [c[2] for c in codons if len(c) == 3]
    if not third:
        return np.nan
    return sum(1 for c in third if c in "GC") / len(third)


def codon_recovery(native, pred):
    native = clean_dna(native)
    pred = clean_dna(pred)
    n = min(len(native), len(pred)) // 3
    if n == 0:
        return np.nan
    return sum(native[3*i:3*i+3] == pred[3*i:3*i+3] for i in range(n)) / n


def nt_identity(native, pred):
    native = clean_dna(native)
    pred = clean_dna(pred)
    n = min(len(native), len(pred))
    if n == 0:
        return np.nan
    return sum(a == b for a, b in zip(native[:n], pred[:n])) / n


def bucket_len(n):
    n = int(n)
    if n <= 512:
        return "<=512"
    if n <= 1024:
        return "513-1024"
    if n <= 2048:
        return "1025-2048"
    return ">2048"


def make_metrics(row, raw_output, error=""):
    native = clean_dna(row["dna_sequence"])
    pred_raw = extract_predicted_dna(raw_output)
    pred = trim_terminal_stop_to_protein_len(pred_raw, row["protein_len"])

    native_gc = gc_content(native)
    pred_gc = gc_content(pred)
    native_gc3 = gc3_content(native)
    pred_gc3 = gc3_content(pred)

    bad_extract = pred == ""

    return {
        "model": "CT1",
        "eval_id": int(row["eval_id"]),
        "ct1_organism": row["ct1_organism"],
        "ct2_species": row["ct2_species"],
        "species": row["ct2_species"],
        "genome_id": row["genome_id"],
        "gene_id": row["gene_id"],
        "gene_idx": int(row["gene_idx"]),
        "protein_len": int(row["protein_len"]),
        "bucket": bucket_len(row["protein_len"]),
        "native_dna": native,
        "pred_dna": pred,
        "native_dna_len": len(native),
        "pred_dna_len": len(pred),
        "native_gc": native_gc,
        "pred_gc": pred_gc,
        "native_gc3": native_gc3,
        "pred_gc3": pred_gc3,
        "abs_gc_error": abs(pred_gc - native_gc) if not np.isnan(pred_gc) and not np.isnan(native_gc) else np.nan,
        "abs_gc3_error": abs(pred_gc3 - native_gc3) if not np.isnan(pred_gc3) and not np.isnan(native_gc3) else np.nan,
        "codon_recovery": codon_recovery(native, pred),
        "nt_identity": nt_identity(native, pred),
        "translation_valid": len(pred) == 3 * int(row["protein_len"]),
        "error": error if not bad_extract else (error + ";failed_to_extract_predicted_dna"),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--out_csv", required=True)
    ap.add_argument("--chunk_index", type=int, default=0)
    ap.add_argument("--num_chunks", type=int, default=1)
    args = ap.parse_args()

    df = pd.read_csv(args.manifest)
    df = df.iloc[args.chunk_index::args.num_chunks].copy().reset_index(drop=True)

    print("manifest chunk rows:", len(df), flush=True)
    print("chunk_index:", args.chunk_index, "num_chunks:", args.num_chunks, flush=True)
    print("ct1 organisms:", df["ct1_organism"].nunique(), flush=True)
    print("ct2 species:", df["ct2_species"].nunique(), flush=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("device:", device, flush=True)

    tokenizer = AutoTokenizer.from_pretrained(str(CT1_MODEL_DIR), local_files_only=True)
    model = BigBirdForMaskedLM.from_pretrained(str(CT1_MODEL_DIR), local_files_only=True).to(device)
    model.eval()

    rows = []
    for r in tqdm(df.to_dict(orient="records"), total=len(df), desc=f"CT1 chunk {args.chunk_index}"):
        try:
            raw = predict_dna_sequence(
                protein=r["protein_sequence"],
                organism=r["ct1_organism"],
                tokenizer=tokenizer,
                model=model,
                device=device,
            )
            rows.append(make_metrics(r, raw, error=""))
        except Exception as e:
            rows.append(make_metrics(r, "", error=repr(e)))

    out = pd.DataFrame(rows)
    out.to_csv(args.out_csv, index=False)

    ok = out[out["error"].fillna("") == ""]
    summary = (
        ok.groupby("model", as_index=False)
        .agg(
            n=("eval_id", "count"),
            translation_valid=("translation_valid", "mean"),
            codon_recovery=("codon_recovery", "mean"),
            nt_identity=("nt_identity", "mean"),
            abs_gc3_error=("abs_gc3_error", "mean"),
        )
    )
    summary.to_csv(args.out_csv.replace(".csv", "_summary.csv"), index=False)

    print("WROTE", args.out_csv)
    print("rows:", len(out))
    print("ok:", int((out["error"].fillna("") == "").sum()))
    print("fail:", int((out["error"].fillna("") != "").sum()))
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
