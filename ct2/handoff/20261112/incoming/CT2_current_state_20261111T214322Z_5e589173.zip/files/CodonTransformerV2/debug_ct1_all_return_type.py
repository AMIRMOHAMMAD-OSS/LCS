import pandas as pd
import torch
from pathlib import Path
from transformers import AutoTokenizer, BigBirdForMaskedLM
from CodonTransformer.CodonPrediction import predict_dna_sequence

CT1_MODEL_DIR = Path("/linkhome/rech/genjqx01/unh87ms/.cache/huggingface/hub/models--adibvafa--CodonTransformer/snapshots/9744dcc920d813066391fc828d7a590207f148e8")

df = pd.read_csv("ct1_ct2_162species_overlap_manifest_ALL_trunc2048.csv")
print("manifest rows:", len(df))
print(df[["eval_id", "ct1_organism", "protein_len", "original_protein_len", "was_truncated_to_2048"]].head(10).to_string(index=False))

r = df.iloc[0]
print("\nUSING ROW:")
print(r[["eval_id", "ct1_organism", "ct2_species", "protein_len", "protein_sequence"]].to_string())

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("device:", device)

tokenizer = AutoTokenizer.from_pretrained(str(CT1_MODEL_DIR), local_files_only=True)
model = BigBirdForMaskedLM.from_pretrained(str(CT1_MODEL_DIR), local_files_only=True).to(device)
model.eval()

out = predict_dna_sequence(
    protein=r["protein_sequence"],
    organism=r["ct1_organism"],
    tokenizer=tokenizer,
    model=model,
    device=device,
)

print("\nRETURN TYPE:", type(out))
print("\nREPR FIRST 5000:")
print(repr(out)[:5000])

print("\nSTR FIRST 5000:")
print(str(out)[:5000])

print("\nDIR DNA-ish attrs:")
for a in dir(out):
    if any(k in a.lower() for k in ["dna", "seq", "pred", "codon"]):
        try:
            v = getattr(out, a)
            print(a, type(v), repr(v)[:500])
        except Exception as e:
            print(a, "ERR", repr(e))

if isinstance(out, dict):
    print("\nDICT KEYS:", out.keys())
    for k, v in out.items():
        print(k, type(v), repr(v)[:1000])

if isinstance(out, (list, tuple)):
    print("\nLIST/TUPLE LEN:", len(out))
    for i, v in enumerate(out):
        print("IDX", i, type(v), repr(v)[:1000])
