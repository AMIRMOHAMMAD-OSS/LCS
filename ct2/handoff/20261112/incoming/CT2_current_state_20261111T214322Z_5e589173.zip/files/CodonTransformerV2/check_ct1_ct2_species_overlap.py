import argparse
import json
import re
from pathlib import Path
from difflib import SequenceMatcher, get_close_matches

import pandas as pd
from tqdm import tqdm


CT2_SPECIES_TO_ID = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/species_to_id.json")
CT2_TEST_DIR = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/test_set")


def normalize_species_name(x):
    x = str(x).strip().strip("'\"")
    x = x.lower()
    x = x.replace("_", " ")
    x = re.sub(r"[\[\]\(\),;:/|]+", " ", x)
    x = re.sub(r"\s+", " ", x).strip()
    return x


def species_core_name(x):
    x = normalize_species_name(x)
    x = re.sub(r"\b(gca|gcf)\s*\d+(\.\d+)?\b", " ", x)
    x = re.sub(r"\b(atcc|dsm|cbs|nbrc|jcm|nctc|ncimb|usnm|str|strain|substr|isolate|clone)\b", " ", x)
    x = re.sub(r"\b\d+(\.\d+)?\b", " ", x)
    x = re.sub(r"\b[a-z]{1,3}\d+[a-z0-9.-]*\b", " ", x)
    x = re.sub(r"\s+", " ", x).strip()
    toks = x.split()
    if len(toks) >= 2:
        return " ".join(toks[:2])
    return x


def load_ct2_species():
    species = set()

    if CT2_SPECIES_TO_ID.exists():
        obj = json.loads(CT2_SPECIES_TO_ID.read_text())
        if isinstance(obj, dict):
            species.update(str(k).strip() for k in obj.keys())

    if CT2_TEST_DIR.exists():
        for fp in tqdm(sorted(CT2_TEST_DIR.glob("*.json")), desc="reading CT2 test species"):
            try:
                obj = json.loads(fp.read_text(errors="replace"))
                sp = obj.get("species")
                if sp:
                    species.add(str(sp).strip())
            except Exception:
                pass

    return sorted(s for s in species if s)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ct1_csv", required=True)
    ap.add_argument("--species_col", required=True)
    ap.add_argument("--out_prefix", default="ct1_ct2_species_overlap")
    ap.add_argument("--fuzzy_threshold", type=float, default=0.90)
    args = ap.parse_args()

    df = pd.read_csv(args.ct1_csv)
    if args.species_col not in df.columns:
        raise SystemExit(f"Missing column {args.species_col}. Available={df.columns.tolist()}")

    ct1_species = sorted(set(str(x).strip() for x in df[args.species_col].dropna() if str(x).strip()))
    ct2_species = load_ct2_species()

    print("CT1 CSV:", args.ct1_csv)
    print("CT1 species column:", args.species_col)
    print("CT1 species:", len(ct1_species))
    print("CT2 species:", len(ct2_species))

    ct2_exact = set(ct2_species)

    ct2_norm_map = {}
    ct2_core_map = {}
    for sp in ct2_species:
        ct2_norm_map.setdefault(normalize_species_name(sp), []).append(sp)
        ct2_core_map.setdefault(species_core_name(sp), []).append(sp)

    norm_keys = list(ct2_norm_map.keys())
    core_keys = list(ct2_core_map.keys())

    rows = []
    for sp in ct1_species:
        norm = normalize_species_name(sp)
        core = species_core_name(sp)

        status = "unmatched"
        method = ""
        match = ""
        score = 0.0

        if sp in ct2_exact:
            status, method, match, score = "matched", "exact", sp, 1.0
        elif norm in ct2_norm_map:
            status, method, match, score = "matched", "normalized_exact", ct2_norm_map[norm][0], 1.0
        elif core in ct2_core_map:
            status, method, match, score = "matched", "core_genus_species", ct2_core_map[core][0], 0.98
        else:
            close = get_close_matches(norm, norm_keys, n=1, cutoff=args.fuzzy_threshold)
            if close:
                key = close[0]
                status = "matched"
                method = "fuzzy_normalized"
                match = ct2_norm_map[key][0]
                score = SequenceMatcher(None, norm, key).ratio()
            else:
                close = get_close_matches(core, core_keys, n=1, cutoff=args.fuzzy_threshold)
                if close:
                    key = close[0]
                    status = "matched"
                    method = "fuzzy_core"
                    match = ct2_core_map[key][0]
                    score = SequenceMatcher(None, core, key).ratio()

        rows.append({
            "ct1_species": sp,
            "ct1_norm": norm,
            "ct1_core": core,
            "status": status,
            "match_method": method,
            "ct2_species_match": match,
            "match_score": score,
        })

    out = pd.DataFrame(rows)

    out.to_csv(f"{args.out_prefix}_matches.csv", index=False)
    out[out["status"] == "matched"].to_csv(f"{args.out_prefix}_matched_only.csv", index=False)
    out[out["status"] != "matched"].to_csv(f"{args.out_prefix}_unmatched.csv", index=False)

    summary = pd.DataFrame([{
        "ct1_csv": args.ct1_csv,
        "ct1_species_col": args.species_col,
        "ct1_species_n": len(ct1_species),
        "ct2_species_n": len(ct2_species),
        "matched_n": int((out["status"] == "matched").sum()),
        "unmatched_n": int((out["status"] != "matched").sum()),
        "matched_fraction": float((out["status"] == "matched").mean()),
    }])
    summary.to_csv(f"{args.out_prefix}_summary.csv", index=False)

    print("\n=== SUMMARY ===")
    print(summary.to_string(index=False))

    print("\n=== match methods ===")
    print(out["match_method"].replace("", "UNMATCHED").value_counts().to_string())

    print("\n=== unmatched ===")
    unmatched = out[out["status"] != "matched"]
    if len(unmatched):
        print(unmatched[["ct1_species", "ct1_core"]].to_string(index=False))
    else:
        print("none")

    print("\nWROTE:")
    print(f"{args.out_prefix}_matches.csv")
    print(f"{args.out_prefix}_matched_only.csv")
    print(f"{args.out_prefix}_unmatched.csv")
    print(f"{args.out_prefix}_summary.csv")


if __name__ == "__main__":
    main()
