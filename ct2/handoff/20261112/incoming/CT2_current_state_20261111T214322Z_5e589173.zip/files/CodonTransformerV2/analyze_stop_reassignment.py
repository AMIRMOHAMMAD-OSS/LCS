import json
import tarfile
from pathlib import Path
from collections import defaultdict, Counter

import pandas as pd

DATA_DIR = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/train_set_shard")
CSV_PATH = Path("preflight_reports/translation_consistency/translation_consistency_sample10k.csv")
OUT_DIR = Path("preflight_reports/translation_consistency")
OUT_DIR.mkdir(parents=True, exist_ok=True)

STOP_CODONS = {"TAA", "TAG", "TGA"}

df = pd.read_csv(CSV_PATH)

bad_df = df[df["mismatch_rate"] > 0.05].copy()
print(f"Samples with mismatch_rate > 0.05: {len(bad_df)}")

species_stats = defaultdict(lambda: {
    "n_samples": 0,
    "stop_to_aa": Counter(),
    "all_mismatches": Counter(),
})

rows = []

for _, row in bad_df.iterrows():
    shard = row["shard"]
    sample = row["sample"]

    try:
        with tarfile.open(DATA_DIR / shard, "r:gz") as tar:
            f = tar.extractfile(sample)
            if f is None:
                continue
            doc = json.loads(f.read().decode("utf-8", errors="replace"))
    except Exception as e:
        print(f"Could not read {shard} {sample}: {e}")
        continue

    dna = str(doc.get("dna_sequence", "")).upper().replace("U", "T")
    protein = str(doc.get("protein_sequence", "")).upper()
    species = doc.get("species", "UNKNOWN")

    species_stats[species]["n_samples"] += 1

    n = min(len(dna) // 3, len(protein))

    stop_events = Counter()

    for i in range(n):
        codon = dna[3 * i : 3 * i + 3]
        aa = protein[i]
        if aa == "_":
            aa = "*"

        if codon in STOP_CODONS and aa != "*":
            key = f"{codon}->{aa}"
            stop_events[key] += 1
            species_stats[species]["stop_to_aa"][key] += 1

    rows.append({
        "species": species,
        "shard": shard,
        "sample": sample,
        "mismatch_rate": row["mismatch_rate"],
        "checked_codons": row["checked_codons"],
        "mismatches": row["mismatches"],
        "stop_to_aa_total": sum(stop_events.values()),
        "stop_to_aa_events": dict(stop_events),
    })

detail = pd.DataFrame(rows)
detail_path = OUT_DIR / "stop_reassignment_bad_samples.csv"
detail.to_csv(detail_path, index=False)

species_rows = []
for species, stats in species_stats.items():
    total_stop_to_aa = sum(stats["stop_to_aa"].values())
    species_rows.append({
        "species": species,
        "n_bad_samples": stats["n_samples"],
        "total_stop_to_aa": total_stop_to_aa,
        "top_stop_to_aa": stats["stop_to_aa"].most_common(10),
    })

species_df = pd.DataFrame(species_rows).sort_values(
    ["total_stop_to_aa", "n_bad_samples"],
    ascending=False,
)

species_path = OUT_DIR / "stop_reassignment_by_species.csv"
species_df.to_csv(species_path, index=False)

print("\n=== TOP SPECIES WITH STOP->AA EVENTS ===")
print(species_df.head(30).to_string(index=False))

print("\n=== TOP BAD SAMPLES ===")
print(
    detail.sort_values(["stop_to_aa_total", "mismatch_rate"], ascending=False)
    .head(20)[["species", "shard", "sample", "mismatch_rate", "stop_to_aa_total", "stop_to_aa_events"]]
    .to_string(index=False)
)

print("\nSaved:")
print(detail_path)
print(species_path)
