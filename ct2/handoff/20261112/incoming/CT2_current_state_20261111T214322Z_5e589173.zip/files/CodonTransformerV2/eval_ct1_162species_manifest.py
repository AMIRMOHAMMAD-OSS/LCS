import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from tqdm import tqdm
from transformers import AutoTokenizer, BigBirdForMaskedLM

from CodonTransformer.CodonPrediction import predict_dna_sequence


CT1_MODEL_DIR = Path("/linkhome/rech/genjqx01/unh87ms/.cache/huggingface/hub/models--adibvafa--CodonTransformer/snapshots/9744dcc920d813066391fc828d7a590207f148e8")


def clean_dna(x):
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def gc_content(seq):
    seq = clean_dna(seq)
    if not seq:
        return np.nan
    return sum(1 for c in seq if c in "GC") / len(seq)


def gc3_content(seq):
    seq = clean_dna(seq)
    codons = [seq[i:i+3] for i in range(0, len(seq) - 2, 3)]
    if not codons:
        return np.nan
    third = [c[2] for c in codons if len(c) == 3]
    if not third:
        return np.nan
    return sum(1 for c in third if c in "GC") / len(third)


def codon_recovery(native, pred):
    native = clean_dna(native)
    pred = clean_dna(pred)
    n = min(len(native), len(pred)) // 3
    if n == 0:
        return np.nan
    return sum(native[3*i:3*i+3] == pred[3*i:3*i+3] for i in range(n)) / n


def nt_identity(native, pred):
    native = clean_dna(native)
    pred = clean_dna(pred)
    n = min(len(native), len(pred))
    if n == 0:
        return np.nan
    return sum(a == b for a, b in zip(native[:n], pred[:n])) / n


def bucket_len(n):
    n = int(n)
    if n <= 512:
        return "<=512"
    if n <= 1024:
        return "513-1024"
    if n <= 2048:
        return "1025-2048"
    return ">2048"


def make_metrics(row, pred_dna, error=""):
    native = clean_dna(row["dna_sequence"])
    pred = clean_dna(pred_dna)

    native_gc = gc_content(native)
    pred_gc = gc_content(pred)
    native_gc3 = gc3_content(native)
    pred_gc3 = gc3_content(pred)

    translation_valid = len(pred) == 3 * int(row["protein_len"])

    return {
        "model": "CT1",
        "eval_id": int(row["eval_id"]),
        "ct1_organism": row["ct1_organism"],
        "ct2_species": row["ct2_species"],
        "species": row["ct2_species"],
        "genome_id": row["genome_id"],
        "gene_id": row["gene_id"],
        "gene_idx": int(row["gene_idx"]),
        "protein_len": int(row["protein_len"]),
        "bucket": bucket_len(row["protein_len"]),
        "native_dna": native,
        "pred_dna": pred,
        "native_dna_len": len(native),
        "pred_dna_len": len(pred),
        "native_gc": native_gc,
        "pred_gc": pred_gc,
        "native_gc3": native_gc3,
        "pred_gc3": pred_gc3,
        "abs_gc_error": abs(pred_gc - native_gc) if not np.isnan(pred_gc) and not np.isnan(native_gc) else np.nan,
        "abs_gc3_error": abs(pred_gc3 - native_gc3) if not np.isnan(pred_gc3) and not np.isnan(native_gc3) else np.nan,
        "codon_recovery": codon_recovery(native, pred),
        "nt_identity": nt_identity(native, pred),
        "translation_valid": translation_valid,
        "error": error,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default="ct1_ct2_162species_overlap_manifest_n10_len512.csv")
    ap.add_argument("--out_csv", default="ct1_162species_overlap_predictions.csv")
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    df = pd.read_csv(args.manifest)
    if args.limit:
        df = df.head(args.limit).copy()

    print("manifest rows:", len(df), flush=True)
    print("ct1 organisms:", df["ct1_organism"].nunique(), flush=True)
    print("ct2 species:", df["ct2_species"].nunique(), flush=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("device:", device, flush=True)

    tokenizer = AutoTokenizer.from_pretrained(str(CT1_MODEL_DIR), local_files_only=True)
    model = BigBirdForMaskedLM.from_pretrained(str(CT1_MODEL_DIR), local_files_only=True).to(device)
    model.eval()

    rows = []

    for r in tqdm(df.to_dict(orient="records"), total=len(df), desc="CT1 predictions"):
        try:
            pred = predict_dna_sequence(
                protein=r["protein_sequence"],
                organism=r["ct1_organism"],
                tokenizer=tokenizer,
                model=model,
                device=device,
            )
            rows.append(make_metrics(r, pred, error=""))
        except Exception as e:
            rows.append(make_metrics(r, "", error=repr(e)))

    out = pd.DataFrame(rows)
    out.to_csv(args.out_csv, index=False)

    print("WROTE", args.out_csv, flush=True)
    print("rows:", len(out), flush=True)
    print("ok:", int((out["error"].fillna("") == "").sum()), flush=True)
    print("fail:", int((out["error"].fillna("") != "").sum()), flush=True)

    ok = out[out["error"].fillna("") == ""]
    summary = (
        ok.groupby("model", as_index=False)
        .agg(
            n=("eval_id", "count"),
            translation_valid=("translation_valid", "mean"),
            codon_recovery=("codon_recovery", "mean"),
            nt_identity=("nt_identity", "mean"),
            abs_gc3_error=("abs_gc3_error", "mean"),
        )
    )
    summary.to_csv(args.out_csv.replace(".csv", "_summary.csv"), index=False)
    print(summary.to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
