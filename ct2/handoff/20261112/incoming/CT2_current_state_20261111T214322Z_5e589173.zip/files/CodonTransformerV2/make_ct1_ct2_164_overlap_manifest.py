import argparse
import json
from pathlib import Path

import pandas as pd
from tqdm import tqdm


TEST_DIR = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/test_set")


def clean_dna(x):
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def clean_protein(x):
    return str(x).strip().upper().rstrip("*_")


def get_first(d, keys):
    for k in keys:
        if k in d and d[k] not in [None, ""]:
            return d[k]
    return None


def load_test_json(fp):
    obj = json.loads(fp.read_text(errors="replace"))
    species = obj.get("species")
    genome_id = obj.get("genome_id", fp.stem)
    genes = obj.get("genes", [])
    return species, genome_id, genes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mapping", default="ct1_ct2_species_overlap_164_manual_patched.csv")
    ap.add_argument("--out_csv", default="ct1_ct2_162species_overlap_manifest_n10_len512.csv")
    ap.add_argument("--n_per_species", type=int, default=10)
    ap.add_argument("--max_protein_len", type=int, default=512)
    args = ap.parse_args()

    mapping = pd.read_csv(args.mapping)
    mapping = mapping[mapping["status"].eq("matched")].copy()

    print("mapping rows:", len(mapping))
    print("unique CT1 organisms:", mapping["ct1_species"].nunique())
    print("unique CT2 species:", mapping["ct2_species_match"].nunique())

    # Build CT2 species -> json file index.
    species_to_file = {}
    for fp in tqdm(sorted(TEST_DIR.glob("*.json")), desc="indexing CT2 test JSONs"):
        try:
            obj = json.loads(fp.read_text(errors="replace"))
            sp = obj.get("species")
            if sp:
                species_to_file[sp] = fp
        except Exception:
            pass

    rows = []
    missing_files = []

    for m in tqdm(mapping.itertuples(index=False), total=len(mapping), desc="building manifest"):
        ct1_org = m.ct1_species
        ct2_species = m.ct2_species_match

        fp = species_to_file.get(ct2_species)
        if fp is None:
            missing_files.append((ct1_org, ct2_species))
            continue

        species, genome_id, genes = load_test_json(fp)

        used = 0
        for gene_idx, g in enumerate(genes):
            protein = get_first(g, [
                "protein_sequence", "protein", "aa_sequence", "amino_acid_sequence"
            ])
            dna = get_first(g, [
                "dna_sequence", "dna", "cds", "cds_sequence",
                "nt_sequence", "nucleotide_sequence", "sequence"
            ])
            gene_id = get_first(g, [
                "protein_id", "gene_id", "id", "locus_tag", "name"
            ])

            if protein is None or dna is None:
                continue

            protein = clean_protein(protein)
            dna = clean_dna(dna)

            if not protein or not dna:
                continue
            if len(protein) > args.max_protein_len:
                continue
            if len(dna) < 3 * len(protein):
                continue

            # Trim DNA to protein length codons, excluding terminal stop if present.
            dna = dna[:3 * len(protein)]

            rows.append({
                "eval_id": len(rows),
                "ct1_organism": ct1_org,
                "ct2_species": ct2_species,
                "species": ct2_species,
                "genome_id": genome_id,
                "source_json": fp.name,
                "gene_idx": gene_idx,
                "gene_id": gene_id if gene_id is not None else f"{genome_id}_gene{gene_idx}",
                "protein_sequence": protein,
                "dna_sequence": dna,
                "protein_len": len(protein),
                "match_method": m.match_method,
            })

            used += 1
            if used >= args.n_per_species:
                break

    out = pd.DataFrame(rows)
    out.to_csv(args.out_csv, index=False)

    print()
    print("WROTE", args.out_csv)
    print("rows:", len(out))
    print("CT1 organisms:", out["ct1_organism"].nunique() if len(out) else 0)
    print("CT2 species:", out["ct2_species"].nunique() if len(out) else 0)
    print("min protein len:", out["protein_len"].min() if len(out) else None)
    print("max protein len:", out["protein_len"].max() if len(out) else None)

    if missing_files:
        pd.DataFrame(missing_files, columns=["ct1_organism", "ct2_species"]).to_csv(
            args.out_csv.replace(".csv", "_missing_files.csv"),
            index=False,
        )
        print("missing files:", len(missing_files))
    else:
        print("missing files: 0")

    print()
    print(out.groupby("ct1_organism").size().describe().to_string())


if __name__ == "__main__":
    main()
