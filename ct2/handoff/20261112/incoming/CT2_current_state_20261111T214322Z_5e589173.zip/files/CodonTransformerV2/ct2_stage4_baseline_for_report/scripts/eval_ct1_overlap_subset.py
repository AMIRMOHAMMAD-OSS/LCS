import json
import csv
from pathlib import Path
from collections import Counter

import torch
from transformers import AutoTokenizer, BigBirdForMaskedLM
from CodonTransformer.CodonPrediction import predict_dna_sequence
from CodonTransformer.CodonData import get_amino_acid_sequence

FILES_TXT = Path("ct1_supported_overlap_files.txt")
OUT_CSV = Path("ct1_overlap_subset_predictions.csv")
CT1_MODEL_DIR = Path("/linkhome/rech/genjqx01/unh87ms/.cache/huggingface/hub/models--adibvafa--CodonTransformer/snapshots/9744dcc920d813066391fc828d7a590207f148e8")

MAX_GENES_PER_SPECIES = 25
MAX_PROTEIN_LEN = 512

def gc_content(seq):
    seq = seq.upper()
    if not seq:
        return float("nan")
    return (seq.count("G") + seq.count("C")) / len(seq)

def gc3_content(seq):
    seq = seq.upper()
    codons = [seq[i:i+3] for i in range(0, len(seq) - 2, 3)]
    if not codons:
        return float("nan")
    third = [c[2] for c in codons if len(c) == 3]
    return sum(1 for x in third if x in "GC") / len(third)

def codon_recovery(native, pred):
    native = native.upper()
    pred = pred.upper()
    n = min(len(native), len(pred)) // 3
    if n == 0:
        return float("nan")
    ok = 0
    for i in range(n):
        if native[3*i:3*i+3] == pred[3*i:3*i+3]:
            ok += 1
    return ok / n

def nt_identity(native, pred):
    native = native.upper()
    pred = pred.upper()
    n = min(len(native), len(pred))
    if n == 0:
        return float("nan")
    return sum(a == b for a, b in zip(native[:n], pred[:n])) / n

def translate_ok(dna, protein):
    protein = protein.rstrip("*_")
    try:
        aa = get_amino_acid_sequence(dna, stop_symbol="_", return_correct_seq=False)
        aa = str(aa).rstrip("*_")
        return aa == protein
    except Exception:
        return False

def length_bucket(protein_len):
    if protein_len <= 512:
        return "<=512"
    if protein_len <= 1024:
        return "513-1024"
    if protein_len <= 2048:
        return "1025-2048"
    return ">2048"

def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("device:", device)

    tokenizer = AutoTokenizer.from_pretrained(CT1_MODEL_DIR, local_files_only=True)
    model = BigBirdForMaskedLM.from_pretrained(CT1_MODEL_DIR, local_files_only=True).to(device)
    model.eval()

    files = [Path(x.strip()) for x in FILES_TXT.read_text().splitlines() if x.strip()]
    rows = []

    for fp in files:
        obj = json.loads(fp.read_text())
        species = obj["species"]
        genome_id = obj["genome_id"]
        genes = obj.get("genes", [])

        used = 0
        print("SPECIES", species, "genes", len(genes), flush=True)

        for g in genes:
            if used >= MAX_GENES_PER_SPECIES:
                break

            protein = g.get("protein_sequence") or ""
            native_dna = g.get("dna_sequence") or ""

            if not protein or not native_dna:
                continue
            if len(protein) > MAX_PROTEIN_LEN:
                continue

            try:
                out = predict_dna_sequence(
                    protein=protein,
                    organism=species,
                    device=device,
                    tokenizer=tokenizer,
                    model=model,
                    attention_type="original_full",
                    deterministic=True,
                    match_protein=True,
                )
                pred_dna = out.predicted_dna
            except Exception as e:
                rows.append({
                    "model": "CT1",
                    "genome_id": genome_id,
                    "species": species,
                    "protein_id": g.get("protein_id"),
                    "protein_len": len(protein),
                    "bucket": length_bucket(len(protein)),
                    "error": repr(e),
                })
                continue

            rows.append({
                "model": "CT1",
                "genome_id": genome_id,
                "species": species,
                "protein_id": g.get("protein_id"),
                "protein_len": len(protein),
                "bucket": length_bucket(len(protein)),
                "native_dna_len": len(native_dna),
                "pred_dna_len": len(pred_dna),
                "translation_valid": translate_ok(pred_dna, protein),
                "codon_recovery": codon_recovery(native_dna, pred_dna),
                "nt_identity": nt_identity(native_dna, pred_dna),
                "native_gc": gc_content(native_dna),
                "pred_gc": gc_content(pred_dna),
                "native_gc3": gc3_content(native_dna),
                "pred_gc3": gc3_content(pred_dna),
                "abs_gc3_error": abs(gc3_content(native_dna) - gc3_content(pred_dna)),
                "error": "",
            })

            used += 1

        print("USED", species, used, flush=True)

    with OUT_CSV.open("w", newline="") as f:
        keys = sorted(set().union(*[r.keys() for r in rows]))
        front = ["model", "genome_id", "species", "protein_id", "protein_len", "bucket"]
        keys = front + [k for k in keys if k not in front]
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)

    print("wrote", OUT_CSV)
    print("n_rows", len(rows))

    import pandas as pd
    df = pd.read_csv(OUT_CSV)
    ok = df[df["error"].fillna("") == ""].copy()
    print()
    print(ok.groupby("bucket")[["translation_valid", "codon_recovery", "nt_identity", "abs_gc3_error"]].mean())
    print()
    print(ok.groupby("species")[["translation_valid", "codon_recovery", "nt_identity", "abs_gc3_error"]].mean())

if __name__ == "__main__":
    main()
