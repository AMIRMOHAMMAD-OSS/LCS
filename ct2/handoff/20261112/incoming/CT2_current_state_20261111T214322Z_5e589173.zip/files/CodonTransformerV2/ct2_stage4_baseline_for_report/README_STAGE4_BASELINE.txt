CT2 Stage 4 baseline package

Main checkpoint:
stage4_e7
/lustre/fsn1/projects/rech/nef/unh87ms/ct2_final/h100_8gpu_stage4_len2048_from_stage3e14_bs56_w2_acc3_lr5e6/epoch_7.ckpt

Model:
ModernBertForMaskedLM + learned species embedding
n_real_species = 26,678
extra_species_slots = 2,000
n_species_total = 28,678
unknown_species_id = 26,678
max_length = 2048

Training/evaluation notes:
- Stage 4 continued from stage3_e14.
- Stage 4 used max_length=2048.
- Stage 4 global metrics were mostly flat.
- Stage 4 improved long-sequence buckets more than short-sequence buckets.
- Species unknown ablation suggested species conditioning is weak or not clearly captured by current ablation.
- CT1-vs-CT2 comparison is preliminary because CT1 may have seen some CT2 test sequences during its own training.
- CT1 had better native codon recovery / nucleotide identity on the small overlap subset.
- CT2 had better GC3 matching on the same subset.

Length distribution:
Train:
n = 192,457,692
median = 332 aa
mean = 445 aa
p95 = 1160 aa
p99 = 2140 aa
max = 91906 aa

Test:
n = 3,914,371
median = 248 aa
mean = 357 aa
p95 = 969 aa
p99 = 1869 aa
max = 98182 aa

Next planned evaluations:
1. Build organism-specific codon frequency tables from CT2 train data.
2. Compute CSI target-vs-nontarget organism rankings.
3. Add MinMax/local codon usage evaluation.
4. Compare CT1, CT2, native, HFC, BFC baselines.
5. Re-evaluate after Stage 5 if trained.
