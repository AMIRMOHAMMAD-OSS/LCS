#!/usr/bin/env python3
"""Evaluate saved CT2 checkpoints under fixed MLM and protein-only inputs."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import sys

CONDITIONS = ("correct", "wrong", "unknown", "zero")
MODES = ("mlm", "protein_only")
REFERENCE_LOSSES = {"epoch_0": 1.2631813287734985, "epoch_1": 1.2744065523147583,
                    "epoch_2": 1.2935491800308228, "epoch_3": 1.2967557907104492,
                    "epoch_9": 1.208923578262329}
DEFAULT_EPOCHS = tuple(range(10))


def parse_epochs(value):
    if value == "all":
        return DEFAULT_EPOCHS
    try:
        epochs = tuple(int(part) for part in value.split(","))
    except ValueError as error:
        raise argparse.ArgumentTypeError("Use all or comma-separated epoch indices, e.g. 0,2,9") from error
    if not epochs or len(set(epochs)) != len(epochs) or any(epoch not in DEFAULT_EPOCHS for epoch in epochs):
        raise argparse.ArgumentTypeError("Epochs must be unique indices from 0 through 9")
    return tuple(sorted(epochs))


def checkpoint_paths(cfg, epochs):
    full = Path(cfg["output_dir"]) / "full"
    paths = [("initialization", Path(cfg["init_checkpoint"])),
             *[(f"epoch_{epoch}", full / f"epoch_{epoch}.ckpt") for epoch in epochs]]
    for _, path in paths:
        if not path.is_file() or path.stat().st_size == 0:
            raise FileNotFoundError(f"Missing or empty checkpoint: {path}")
    return paths


def atomic_json(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def species_id(raw, mapping, n_real):
    if isinstance(raw, int):
        result = raw
    elif str(raw) in mapping:
        result = int(mapping[str(raw)])
    else:
        # Audit dictionary keys stringify originally numeric species IDs.
        result = int(raw)
    if not 0 <= result < n_real:
        raise ValueError(f"Invalid real species: {raw!r}")
    return result


def coverage_report(output, mapping, n_real, panel_ids, job_id):
    files = sorted((output / "data_audit").glob(f"filter_job{job_id}_rank*_pid*.json"))
    if not files:
        raise FileNotFoundError(f"No audit files for training job {job_id}")
    counts, accepted = Counter(), Counter()
    for path in files:
        report = json.loads(path.read_text())
        counts.update(report["counts"])
        for raw, per_species in report["by_species"].items():
            accepted[species_id(raw, mapping, n_real)] += per_species.get("accepted", 0)
    if counts["accepted"] + counts["excluded"] != counts["examined"]:
        raise ValueError("Audit totals do not reconcile")
    if sum(accepted.values()) != counts["accepted"]:
        raise ValueError("Per-species and overall accepted counts disagree")
    panel_species = set(panel_ids)
    seen = {sid for sid, count in accepted.items() if count > 0}
    result = {
        "scope": "Cumulative processed draws in this job at diagnostic startup; not unique genes, not checkpoint-specific, excludes initialization training history",
        "worker_files": len(files), "counts": dict(counts),
        "real_species_with_accepted_draws": len(seen), "real_species_total": n_real,
        "panel_species_with_accepted_draws": len(panel_species & seen),
        "panel_species_total": len(panel_species),
        "panel_species_without_accepted_draws": sorted(panel_species - seen),
    }
    return result, seen


def synonymous_groups(vocab):
    groups = [-1] * len(vocab)
    group_ids = {}
    for token, index in vocab.items():
        if len(token) == 5 and token[1] == "_" and set(token[2:]) <= set("acgt"):
            aa = token[0]
            groups[index] = group_ids.setdefault(aa, len(group_ids))
    if sum(value >= 0 for value in groups) != 64:
        raise ValueError("Expected exactly 64 paired codon tokens")
    return groups


def row_statistics(logits, labels, groups):
    """Per-record sums over exactly supervised positions; raw and synonymous CE."""
    import torch
    import torch.nn.functional as F
    selected = labels.ne(-100)
    gold = labels[selected]
    values = logits[selected].float()
    if not gold.numel() or (groups[gold] < 0).any():
        raise ValueError("Missing or invalid codon labels")
    if not torch.isfinite(values).all():
        raise FloatingPointError("Nonfinite evaluated logits")
    allowed = groups[None, :].eq(groups[gold, None]) & groups[None, :].ge(0)
    restricted = values.masked_fill(~allowed, float("-inf"))
    row_ids = torch.arange(labels.shape[0], device=labels.device)[:, None].expand_as(labels)[selected]
    columns = (
        torch.ones_like(gold, dtype=torch.float64),
        F.cross_entropy(values, gold, reduction="none").double(),
        F.cross_entropy(restricted, gold, reduction="none").double(),
        values.argmax(-1).eq(gold).double(),
        restricted.argmax(-1).eq(gold).double(),
    )
    result = torch.zeros((labels.shape[0], 5), dtype=torch.float64, device=labels.device)
    for index, column in enumerate(columns):
        result[:, index].scatter_add_(0, row_ids, column)
    if not torch.isfinite(result).all():
        raise FloatingPointError("Nonfinite metric sums")
    return result.cpu()


def aggregate(rows):
    totals = rows.sum(0)
    count = float(totals[0])
    if count <= 0:
        raise ValueError("No supervised targets")
    return {"targets": int(count), "raw_loss": float(totals[1] / count),
            "synonymous_loss": float(totals[2] / count),
            "raw_accuracy": float(totals[3] / count),
            "synonymous_accuracy": float(totals[4] / count)}


def paired_deltas(correct, other, panel_ids, bootstrap=1000):
    """Token-weighted loss difference with a paired bootstrap over species."""
    import torch
    if not torch.equal(correct[:, 0], other[:, 0]):
        raise ValueError("Compared species conditions have different prediction targets")
    keys = sorted(set(panel_ids))
    indices = {sid: index for index, sid in enumerate(keys)}
    clustered = torch.zeros((len(keys), 3), dtype=torch.float64)
    for row, sid in enumerate(panel_ids):
        clustered[indices[sid], 0] += correct[row, 0]
        clustered[indices[sid], 1:] += other[row, 1:3] - correct[row, 1:3]
    generator = torch.Generator().manual_seed(9321)
    samples = torch.randint(len(keys), (bootstrap, len(keys)), generator=generator)
    totals = clustered[samples].sum(1)
    ratios = totals[:, 1:] / totals[:, :1]
    interval = torch.quantile(ratios, torch.tensor([.025, .975], dtype=torch.float64), dim=0)
    observed = clustered.sum(0)
    return {
        "sign": "positive means correct species has lower loss",
        "raw_delta": float(observed[1] / observed[0]),
        "synonymous_delta": float(observed[2] / observed[0]),
        "raw_95pct_species_bootstrap": interval[:, 0].tolist(),
        "synonymous_95pct_species_bootstrap": interval[:, 1].tolist(),
        "bootstrap_replicates": bootstrap,
    }


def embedding_statistics(current, initial, n_real, scale, seen):
    import torch
    current, initial = current.float(), initial.float()
    if current.shape != initial.shape or not torch.isfinite(current).all():
        raise ValueError("Invalid species embedding tensor")
    norms = current.norm(dim=1)
    drift = (current - initial).norm(dim=1)
    relative = drift / initial.norm(dim=1).clamp_min(1e-12)
    real = current[:n_real]
    dispersion = (real - real.mean(0)).square().mean().sqrt()
    result = {
        "real_norm_mean": float(norms[:n_real].mean()), "unknown_norm": float(norms[n_real]),
        "scaled_unknown_norm": float(scale * norms[n_real]),
        "real_relative_drift_median": float(relative[:n_real].median()),
        "real_relative_drift_max": float(relative[:n_real].max()),
        "unknown_relative_drift": float(relative[n_real]),
        "real_coordinate_dispersion_rms": float(dispersion),
    }
    for label, ids in (("seen_this_run", sorted(seen)),
                       ("not_seen_this_run", sorted(set(range(n_real)) - seen))):
        result[label + "_relative_drift_median"] = float(relative[ids].median()) if ids else None
    return result


def build_batches(records, panel_ids, collator, mode, groups):
    import torch
    batches = []
    # Reproduce the original eight-rank panel partition and batch padding.
    for virtual_rank in range(8):
        indices = list(range(virtual_rank, len(records), 8))
        if len(indices) % 8:
            raise ValueError("Panel does not divide into the original validation batches")
        for offset in range(0, len(indices), 8):
            selected = indices[offset:offset + 8]
            batch = collator([{"json": records[index]} for index in selected])
            if batch["species_id"].tolist() != [panel_ids[index] for index in selected]:
                raise ValueError("Correct-species IDs were altered")
            wrong = batch["wrong_species_id"]
            if ((wrong < 0) | (wrong >= collator.unknown_species_id) | wrong.eq(batch["species_id"])).any():
                raise ValueError("Wrong-species IDs are invalid")
            if mode == "protein_only":
                allowed_inputs = {collator.vocab[f"{aa}_unk"] for aa in "acdefghiklmnpqrstvwy"}
                allowed_inputs.add(collator.vocab["__unk"])
                allowed_inputs.update({collator.tokenizer.cls_token_id, collator.tokenizer.sep_token_id, collator.pad_token_id})
                if not set(batch["input_ids"].flatten().tolist()) <= allowed_inputs:
                    raise ValueError("Protein-only inputs still contain a visible codon or generic MASK")
            batches.append((selected, batch))
    if sorted(index for ids, _ in batches for index in ids) != list(range(len(records))):
        raise ValueError("Panel coverage duplicated or lost records")
    return batches


def evaluate(model, species_embed, batches, groups, scale, n_real, size):
    import torch
    device = next(model.parameters()).device
    storage = {condition: torch.zeros((size, 5), dtype=torch.float64) for condition in CONDITIONS}
    with torch.inference_mode():
        for number, (indices, cpu_batch) in enumerate(batches, 1):
            batch = {key: tensor.to(device) for key, tensor in cpu_batch.items()}
            with torch.autocast(device.type, dtype=torch.bfloat16, enabled=device.type == "cuda"):
                token_vectors = model.get_input_embeddings()(batch["input_ids"])
                for condition in CONDITIONS:
                    if condition == "zero":
                        vectors = token_vectors
                    else:
                        ids = (batch["species_id"] if condition == "correct" else
                               batch["wrong_species_id"] if condition == "wrong" else
                               torch.full_like(batch["species_id"], n_real))
                        vectors = token_vectors + scale * species_embed(ids)[:, None, :]
                    logits = model(inputs_embeds=vectors, attention_mask=batch["attention_mask"]).logits
                    storage[condition][indices] = row_statistics(logits, batch["labels"], groups)
            if number % 128 == 0:
                print(f"DIAG_PROGRESS {number}/{len(batches)} batches", flush=True)
    return storage


def make_summary(report):
    lines = ["CT2 checkpoint diagnosis (same fixed 4096-record panel)",
             "Positive wrong-minus-correct loss means correct species helps.",
             "syn_loss restricts predictions to codons preserving the supplied amino acid.",
             "MLM uses the original fixed 15% masking; protein_only hides every codon.",
             "One fixed wrong-species assignment per record; bootstrap resamples species, not masking seeds or wrong assignments.",
             "These exploratory intervals are not corrected for multiple checkpoints or phylogenetic dependence.", ""]
    coverage = report["coverage"]
    lines += [f"Species seen in this job's accepted-draw audit: {coverage['real_species_with_accepted_draws']}/{coverage['real_species_total']}",
              f"Panel species seen in that audit: {coverage['panel_species_with_accepted_draws']}/{coverage['panel_species_total']}",
              "Audit coverage is at diagnostic startup, not historical coverage at each checkpoint.", "",
              "checkpoint\tinput\tcorrect_raw_loss\tunknown_raw_loss\twrong_raw_loss\tzero_raw_loss\tcorrect_syn_loss\twrong_minus_correct_syn\t95pct_species_bootstrap"]
    for checkpoint in report["checkpoints"]:
        for mode, evaluation in checkpoint["evaluation"].items():
            conditions, delta = evaluation["conditions"], evaluation["deltas"]["wrong"]
            ci = delta["synonymous_95pct_species_bootstrap"]
            lines.append("\t".join([checkpoint["name"], mode,
                *[f"{conditions[key]['raw_loss']:.6f}" for key in ("correct", "unknown", "wrong", "zero")],
                f"{conditions['correct']['synonymous_loss']:.6f}", f"{delta['synonymous_delta']:+.6f}",
                f"[{ci[0]:+.6f}, {ci[1]:+.6f}]"]))
    lines += ["", "Other synonymous-loss ablations (positive delta means correct species helps):",
              "checkpoint\tinput\tunknown_syn_loss\tunknown_minus_correct_syn\t95pct_species_bootstrap\tzero_syn_loss\tzero_minus_correct_syn\t95pct_species_bootstrap"]
    for checkpoint in report["checkpoints"]:
        for mode, evaluation in checkpoint["evaluation"].items():
            values = [checkpoint["name"], mode]
            for condition in ("unknown", "zero"):
                delta = evaluation["deltas"][condition]
                ci = delta["synonymous_95pct_species_bootstrap"]
                values += [f"{evaluation['conditions'][condition]['synonymous_loss']:.6f}",
                           f"{delta['synonymous_delta']:+.6f}", f"[{ci[0]:+.6f}, {ci[1]:+.6f}]"]
            lines.append("\t".join(values))
    lines += ["", "Species embedding movement relative to initialization (not a functional test by itself):"]
    for checkpoint in report["checkpoints"]:
        norms = checkpoint["species_embeddings"]
        lines.append(f"{checkpoint['name']}: real median relative drift={norms['real_relative_drift_median']:.6g}; "
                     f"unknown relative drift={norms['unknown_relative_drift']:.6g}; "
                     f"unknown norm={norms['unknown_norm']:.6g}")
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--training-job", default="31897")
    parser.add_argument("--epochs", type=parse_epochs, default=DEFAULT_EPOCHS,
                        help="all (default) or comma-separated zero-based indices, e.g. 0,2,9; initialization is always included")
    args = parser.parse_args()
    run = args.run.resolve()
    if not args.training_job.isdigit():
        parser.error("training-job must be a numeric Slurm job ID")
    if args.output.resolve().is_relative_to(run):
        parser.error("Diagnostic output must be outside the sealed training snapshot")
    args.output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(run))
    import torch
    import transformers
    from transformers import ModernBertConfig, ModernBertForMaskedLM, PreTrainedTokenizerFast
    from phase1_common import load_config, verify_panel
    from phase1_support import FixedEvalCollator
    from phase1_tokens import validate_vocabulary
    if torch.__version__.split("+")[0] != "2.6.0" or transformers.__version__ != "4.51.3":
        raise RuntimeError("Use the training module pytorch-gpu/py3/2.6.0 (torch 2.6.0, transformers 4.51.3)")
    if not torch.cuda.is_available():
        raise RuntimeError("Run this evaluation in the supplied single-GPU Slurm job")
    torch.set_num_threads(8)
    torch.set_float32_matmul_precision("medium")
    torch.manual_seed(123)
    loaded_run, cfg = load_config()
    if loaded_run != run:
        raise RuntimeError("Imported a different run snapshot")
    paths = checkpoint_paths(cfg, args.epochs)
    panel, meta = verify_panel(run, cfg)
    records = [json.loads(line) for line in panel.read_text().splitlines() if line.strip()]
    if len(records) != 4096:
        raise ValueError("Expected the complete 4096-record panel")
    mapping = json.loads(Path(cfg["species_mapping"]).read_text())
    n_real = int(cfg["num_organisms"])
    if cfg["unknown_species_id"] != n_real:
        raise ValueError("Unexpected unknown-species slot")
    panel_ids = [species_id(record["species"], mapping, n_real) for record in records]
    full_output = Path(cfg["output_dir"]) / "full"
    coverage, seen = coverage_report(full_output, mapping, n_real, panel_ids, args.training_job)
    tokenizer = PreTrainedTokenizerFast(tokenizer_file=str(run / "CodonTransformerTokenizer.json"),
        bos_token="[CLS]", eos_token="[SEP]", unk_token="[UNK]", sep_token="[SEP]",
        pad_token="[PAD]", cls_token="[CLS]", mask_token="[MASK]")
    validate_vocabulary(tokenizer.get_vocab())
    groups = torch.tensor(synonymous_groups(tokenizer.get_vocab()), dtype=torch.long)
    batches = {}
    for mode in MODES:
        collator = FixedEvalCollator(tokenizer, species_to_id=mapping, unknown_species_id=n_real,
            max_species_id=n_real + cfg["extra_organisms"], species_dropout_prob=0.,
            species_random_frac=0., mlm_probability=.15, full_mask_probability=float(mode == "protein_only"),
            max_length=512)
        batches[mode] = build_batches(records, panel_ids, collator, mode, groups)
    model_config = ModernBertConfig(vocab_size=len(tokenizer), pad_token_id=tokenizer.pad_token_id,
        sep_token_id=tokenizer.sep_token_id, cls_token_id=tokenizer.cls_token_id,
        max_position_embeddings=2048, attn_implementation="sdpa")
    model = ModernBertForMaskedLM(config=model_config).to("cuda").eval()
    species_embed = torch.nn.Embedding(n_real + cfg["extra_organisms"], model_config.hidden_size).to("cuda").eval()
    groups = groups.to("cuda")
    report = {"version": 2, "created_utc": datetime.now(timezone.utc).isoformat(),
              "selected_epochs": list(args.epochs),
              "run": str(run), "fingerprint": cfg["fingerprint"], "panel_sha256": meta["sha256"],
              "diagnostic_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "environment": {"torch": torch.__version__, "transformers": transformers.__version__,
                              "python": sys.version, "gpu": torch.cuda.get_device_name(0)},
              "species_scale_used": .0347, "coverage": coverage, "checkpoints": [],
              "notes": ["All checkpoints use this run's species scale .0347, including initialization; not a reconstruction of the initialization run's old evaluation",
                        "Protein-only evaluation uses the training 512-token window; it does not estimate expression or full-gene generation quality",
                        "Synonymous loss normalizes only over codons encoding the supplied amino acid; raw loss uses all 90 vocabulary entries",
                        "Exploratory 95% paired species bootstrap, 1000 replicates; no multiplicity correction",
                        "Fixed masks and one fixed wrong-species assignment per record; the bootstrap does not estimate sensitivity to changing these assignments",
                        "Raw and synonymous loss use the same supervised positions. Single-codon amino acids have zero synonymous loss, not a separate position filter",
                        "Evaluation only: no optimizer steps, no checkpoint writes, no training-file edits"]}
    initial_species = None
    for name, path in paths:
        print("DIAG_CHECKPOINT", name, str(path), flush=True)
        before = path.stat()
        checkpoint = torch.load(path, map_location="cpu", weights_only=False, mmap=True)
        state = checkpoint["state_dict"]
        current_species = state["species_embed.weight"]
        hparams = checkpoint.get("hyper_parameters", {})
        if int(hparams.get("unknown_species_id", n_real)) != n_real:
            raise ValueError("Checkpoint has an incompatible unknown-species ID")
        if name != "initialization":
            if int(checkpoint["global_step"]) != (int(name.removeprefix("epoch_")) + 1) * 8000:
                raise ValueError(f"Unexpected checkpoint step for {name}")
            if not math.isclose(float(hparams["species_embed_scale"]), .0347, rel_tol=0., abs_tol=1e-12):
                raise ValueError("Checkpoint conditioning scale does not match this diagnostic")
        if initial_species is None:
            initial_species = current_species.detach().float().clone()
        model.load_state_dict({key[len("model."):]: value for key, value in state.items() if key.startswith("model.")}, strict=True)
        species_embed.load_state_dict({"weight": current_species}, strict=True)
        item = {"name": name, "path": str(path), "file_size": before.st_size, "mtime_ns": before.st_mtime_ns,
                "global_step": int(checkpoint.get("global_step", -1)), "epoch": checkpoint.get("epoch"),
                "checkpoint_species_scale": hparams.get("species_embed_scale"),
                "optimizer_states_present": bool(checkpoint.get("optimizer_states")),
                "scheduler_states_present": bool(checkpoint.get("lr_schedulers")),
                "species_embeddings": embedding_statistics(current_species, initial_species, n_real, .0347, seen),
                "evaluation": {}}
        for mode in MODES:
            print("DIAG_INPUT", name, mode, flush=True)
            rows = evaluate(model, species_embed, batches[mode], groups, .0347, n_real, len(records))
            item["evaluation"][mode] = {
                "conditions": {condition: aggregate(values) for condition, values in rows.items()},
                "deltas": {condition: paired_deltas(rows["correct"], rows[condition], panel_ids)
                           for condition in CONDITIONS if condition != "correct"},
            }
            if mode == "mlm" and name in REFERENCE_LOSSES:
                actual = item["evaluation"][mode]["conditions"]["correct"]["raw_loss"]
                difference = actual - REFERENCE_LOSSES[name]
                item["logged_mlm_reference_loss"] = REFERENCE_LOSSES[name]
                item["mlm_reference_difference"] = difference
                print("DIAG_REFERENCE_DIFFERENCE", name, difference, flush=True)
                if abs(difference) > .002:
                    raise RuntimeError("Diagnostic MLM loss does not reproduce the logged checkpoint result within 0.002; inspect the diagnostic before interpreting its other conditions")
            torch.save({"panel_species_ids": panel_ids, "columns": ["targets", "raw_loss_sum", "synonymous_loss_sum", "raw_correct", "synonymous_correct"],
                        "conditions": rows}, args.output / f"{name}_{mode}_per_record.pt")
        after = path.stat()
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise RuntimeError("Checkpoint changed while it was being evaluated")
        report["checkpoints"].append(item)
        atomic_json(args.output / "results.json", report)
        (args.output / "summary.txt").write_text(make_summary(report))
        del checkpoint, state, current_species, rows
        gc.collect()
    report["completed_utc"] = datetime.now(timezone.utc).isoformat()
    atomic_json(args.output / "results.json", report)
    print(make_summary(report), flush=True)
    print("DIAGNOSTIC_COMPLETE", str(args.output / "results.json"), flush=True)


if __name__ == "__main__":
    main()
