#!/usr/bin/env python3
"""CPU/stdlib checks for checkpoint selection and submission safeguards."""
import argparse
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import diagnose
import submit_diagnostic


class SubmissionTests(unittest.TestCase):
    def test_epoch_selection(self):
        self.assertEqual(diagnose.parse_epochs("all"), tuple(range(10)))
        self.assertEqual(diagnose.parse_epochs("9,0,2"), (0, 2, 9))
        for value in ("", "0,0", "10", "-1", "latest", "0,2,", "0.5"):
            with self.subTest(value=value), self.assertRaises(argparse.ArgumentTypeError):
                diagnose.parse_epochs(value)

    def fixture(self, root):
        run, output, here = root / "run", root / "output", root / "diagnostic"
        run.mkdir()
        (output / "full").mkdir(parents=True)
        here.mkdir()
        initial = root / "initial.ckpt"
        initial.write_bytes(b"checkpoint-placeholder")
        for epoch in range(10):
            (output / "full" / f"epoch_{epoch}.ckpt").write_bytes(b"checkpoint-placeholder")
        cfg = {"output_dir": str(output), "init_checkpoint": str(initial)}
        (run / "run_config.json").write_text(json.dumps(cfg))
        (run / "eval_panel.jsonl").write_text("{}\n")
        return run, output, here, cfg

    def invoke(self, here, run, *args):
        with patch.object(submit_diagnostic, "__file__", str(here / "submit_diagnostic.py")), \
             patch("sys.argv", ["submit_diagnostic.py", *args, "--run", str(run)]), \
             redirect_stdout(io.StringIO()) as printed:
            submit_diagnostic.main()
            return printed.getvalue()

    def test_all_checkpoints_with_initialization_first(self):
        with TemporaryDirectory() as directory:
            _, _, _, cfg = self.fixture(Path(directory))
            paths = diagnose.checkpoint_paths(cfg, diagnose.DEFAULT_EPOCHS)
            self.assertEqual([name for name, _ in paths], ["initialization", *[f"epoch_{i}" for i in range(10)]])
            self.assertEqual(diagnose.REFERENCE_LOSSES["epoch_9"], 1.208923578262329)

    def test_missing_or_empty_final_checkpoint_prevents_submission(self):
        with TemporaryDirectory() as directory:
            run, output, here, _ = self.fixture(Path(directory))
            final = output / "full" / "epoch_9.ckpt"
            for missing in (False, True):
                if missing:
                    final.unlink()
                else:
                    final.write_bytes(b"")
                with patch.object(submit_diagnostic.subprocess, "run") as sbatch, \
                     self.assertRaises(FileNotFoundError):
                    self.invoke(here, run, "start")
                sbatch.assert_not_called()
                self.assertFalse((here / "diagnostic_job.json").exists())

    def test_selected_epochs_reach_sbatch_and_second_start_is_rejected(self):
        with TemporaryDirectory() as directory:
            run, output, here, _ = self.fixture(Path(directory))
            originals = {p: p.read_bytes() for p in run.rglob("*") if p.is_file()}
            originals.update({p: p.read_bytes() for p in output.rglob("*") if p.is_file()})
            reply = SimpleNamespace(stdout="12345;cluster\n", stderr="")
            with patch.object(submit_diagnostic.subprocess, "run", return_value=reply) as sbatch:
                printed = self.invoke(here, run, "start", "--epochs", "0,2,9")
                command = sbatch.call_args.args[0]
                self.assertEqual(command[0], "sbatch")
                self.assertEqual(command[command.index("--epochs") + 1], "0,2,9")
                self.assertEqual(command[command.index("--output") + 1], str(here / "results"))
                self.assertIn("epoch_9", printed)
                job = json.loads((here / "diagnostic_job.json").read_text())
                self.assertEqual(job["epochs"], [0, 2, 9])
                self.assertEqual(job["checkpoint_names"], ["initialization", "epoch_0", "epoch_2", "epoch_9"])
                with self.assertRaises(SystemExit):
                    self.invoke(here, run, "start")
                self.assertEqual(sbatch.call_count, 1)
            self.assertTrue(all(path.read_bytes() == value for path, value in originals.items()))

    def test_report_only_reads_saved_results(self):
        with TemporaryDirectory() as directory:
            run, _, here, _ = self.fixture(Path(directory))
            results = here / "results"
            results.mkdir()
            (results / "results.json").write_text(json.dumps({"completed_utc": "example"}))
            (results / "summary.txt").write_text("epoch_9 protein_only saved-result\n")
            with patch.object(submit_diagnostic.subprocess, "run") as process:
                printed = self.invoke(here, run, "report")
            process.assert_not_called()
            self.assertIn("COMPLETE", printed)
            self.assertIn("saved-result", printed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
