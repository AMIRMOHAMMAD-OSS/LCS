import argparse
import glob
import json
import math
import tarfile
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm


GENETIC_CODE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

SYNONYMOUS_CODONS = defaultdict(list)
for codon, aa in GENETIC_CODE.items():
    if aa != "*":
        SYNONYMOUS_CODONS[aa].append(codon)


def clean_dna(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def clean_protein(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).strip().upper().rstrip("*_")


def iter_codons(seq):
    seq = clean_dna(seq)
    for i in range(0, len(seq) - 2, 3):
        codon = seq[i:i+3]
        if len(codon) != 3 or any(c not in "ACGT" for c in codon):
            continue
        aa = GENETIC_CODE.get(codon)
        if aa is None or aa == "*":
            continue
        yield aa, codon


def read_records_from_shard(path):
    with tarfile.open(path, "r:gz") as tar:
        for member in tar:
            if not member.isfile():
                continue
            if not member.name.endswith((".json", ".jsonl")):
                continue

            f = tar.extractfile(member)
            if f is None:
                continue

            raw = f.read().decode("utf-8", errors="replace").strip()
            if not raw:
                continue

            if member.name.endswith(".jsonl"):
                for line in raw.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        yield json.loads(line)
                    except Exception:
                        continue
            else:
                try:
                    obj = json.loads(raw)
                except Exception:
                    continue

                if isinstance(obj, list):
                    for x in obj:
                        yield x
                else:
                    yield obj


def normalize_record(rec):
    if not isinstance(rec, dict):
        return None

    species = rec.get("species")
    genome_id = rec.get("genome_id", "")
    protein_id = rec.get("protein_id", "")
    dna = rec.get("dna_sequence")
    protein = rec.get("protein_sequence")

    if species is None or dna is None or protein is None:
        return None

    dna = clean_dna(dna)
    protein = clean_protein(protein)

    if not dna or not protein:
        return None

    need = 3 * len(protein)
    if len(dna) < need:
        return None

    return str(species), str(genome_id), str(protein_id), dna[:need], len(protein)


def build_formal_csi_weights(codon_table):
    freq = pd.read_parquet(codon_table)

    max_freq = (
        freq.groupby(["species", "aa"], as_index=False)["frequency"]
        .max()
        .rename(columns={"frequency": "max_frequency"})
    )

    use = freq.merge(max_freq, on=["species", "aa"], how="left")
    use["weight"] = use["frequency"] / use["max_frequency"]

    weights = {}
    for r in tqdm(use.itertuples(index=False), total=len(use), desc="building formal CSI weights"):
        weights[(str(r.species), str(r.aa), str(r.codon))] = float(r.weight)

    return weights


def geomean_weight(seq, species, weights):
    logs = []
    total = 0
    missing = 0

    for aa, codon in iter_codons(seq):
        total += 1
        w = weights.get((species, aa, codon))
        if w is None or w <= 0:
            missing += 1
            continue
        logs.append(math.log(w))

    if not logs:
        return np.nan, total, missing

    return float(math.exp(sum(logs) / len(logs))), total, missing


def score_training_batches(shards, target_species, csi_weights, cache_dir, shards_per_batch):
    cache_dir.mkdir(parents=True, exist_ok=True)

    columns = [
        "species",
        "genome_id",
        "protein_id",
        "dna",
        "protein_len",
        "formal_csi",
        "codons_total",
        "missing_weight_frac",
    ]

    n_batches = math.ceil(len(shards) / shards_per_batch)

    for b in range(n_batches):
        start = b * shards_per_batch
        end = min((b + 1) * shards_per_batch, len(shards))
        out = cache_dir / f"train_topcsi_batch_{b:04d}.parquet"

        if out.exists():
            print(f"batch {b+1}/{n_batches}: exists, skipping {out}")
            continue

        rows = []
        seen = 0
        kept = 0

        for spath in tqdm(shards[start:end], desc=f"batch {b+1}/{n_batches} shards {start}:{end}"):
            for rec in read_records_from_shard(spath):
                seen += 1
                norm = normalize_record(rec)
                if norm is None:
                    continue

                species, genome_id, protein_id, dna, protein_len = norm

                if species not in target_species:
                    continue

                csi, total, missing = geomean_weight(dna, species, csi_weights)
                if pd.isna(csi):
                    continue

                rows.append({
                    "species": species,
                    "genome_id": genome_id,
                    "protein_id": protein_id,
                    "dna": dna,
                    "protein_len": protein_len,
                    "formal_csi": csi,
                    "codons_total": total,
                    "missing_weight_frac": missing / max(total, 1),
                })
                kept += 1

        df = pd.DataFrame(rows, columns=columns)
        df.to_parquet(out, index=False)
        print(f"wrote {out} rows={len(df)} seen={seen} kept={kept}")


def load_scored_training(cache_dir):
    files = sorted(cache_dir.glob("train_topcsi_batch_*.parquet"))
    if not files:
        raise SystemExit(f"No cache parquet files found in {cache_dir}")

    dfs = []
    for f in files:
        df = pd.read_parquet(f)
        if len(df):
            dfs.append(df)

    if not dfs:
        raise SystemExit("All cache parquet files are empty. Species names may not match.")

    return pd.concat(dfs, ignore_index=True)


def select_top10(scored, top_frac):
    selected = []

    for species, g in scored.groupby("species", sort=False):
        g = g.sort_values("formal_csi", ascending=False)
        n_top = max(1, int(math.ceil(top_frac * len(g))))
        selected.append(g.head(n_top))

    return pd.concat(selected, ignore_index=True)


def build_cai_weights(top_ref, pseudocount):
    counts = defaultdict(float)
    species_set = sorted(top_ref["species"].astype(str).unique())

    for species in species_set:
        for aa, codons in SYNONYMOUS_CODONS.items():
            for codon in codons:
                counts[(species, aa, codon)] += pseudocount

    for r in tqdm(top_ref.itertuples(index=False), total=len(top_ref), desc="counting top10CSI reference codons"):
        species = str(r.species)
        for aa, codon in iter_codons(r.dna):
            counts[(species, aa, codon)] += 1.0

    max_by_species_aa = defaultdict(float)
    for (species, aa, codon), count in counts.items():
        if count > max_by_species_aa[(species, aa)]:
            max_by_species_aa[(species, aa)] = count

    weights = {}
    for key, count in counts.items():
        species, aa, codon = key
        mx = max_by_species_aa[(species, aa)]
        if mx > 0:
            weights[key] = count / mx

    return weights


def cai_score(seq, species, weights):
    logs = []
    total = 0
    missing = 0

    for aa, codon in iter_codons(seq):
        total += 1
        w = weights.get((species, aa, codon))
        if w is None or w <= 0:
            missing += 1
            continue
        logs.append(math.log(w))

    if not logs:
        return np.nan, total, missing

    return float(math.exp(sum(logs) / len(logs))), total, missing


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--shard_glob", required=True)
    ap.add_argument("--out_prefix", required=True)
    ap.add_argument("--shards_per_batch", type=int, default=250)
    ap.add_argument("--top_frac", type=float, default=0.10)
    ap.add_argument("--pseudocount", type=float, default=1.0)
    args = ap.parse_args()

    pred = pd.read_csv(args.predictions, low_memory=False)
    pred = pred[pred["pred_dna"].fillna("").astype(str).str.len() > 0].copy()

    target_species = set(pred["species"].astype(str).unique())
    print("prediction rows:", len(pred))
    print("models:", pred["model"].nunique())
    print("target species:", len(target_species))

    shards = sorted(glob.glob(args.shard_glob))
    print("shards:", len(shards))
    if not shards:
        raise SystemExit("No shards matched shard_glob")

    csi_weights = build_formal_csi_weights(args.codon_table)

    cache_dir = Path(f"{args.out_prefix}_cache")
    score_training_batches(shards, target_species, csi_weights, cache_dir, args.shards_per_batch)

    scored = load_scored_training(cache_dir)
    scored.to_parquet(f"{args.out_prefix}_train_genes_scored_by_csi.parquet", index=False)

    print("scored train genes:", len(scored))
    print("scored species:", scored["species"].nunique())
    print("missing target species:", sorted(target_species - set(scored["species"].astype(str).unique()))[:30])

    top_ref = select_top10(scored, args.top_frac)
    top_ref.to_parquet(f"{args.out_prefix}_top10csi_train_reference_genes.parquet", index=False)

    ref_summary = (
        top_ref.groupby("species", as_index=False)
        .agg(
            top_ref_genes=("dna", "count"),
            mean_ref_csi=("formal_csi", "mean"),
            mean_ref_len=("protein_len", "mean"),
        )
    )
    ref_summary.to_csv(f"{args.out_prefix}_top10csi_train_reference_summary_by_species.csv", index=False)

    print("top reference genes:", len(top_ref))
    print("top reference species:", top_ref["species"].nunique())

    cai_weights = build_cai_weights(top_ref, args.pseudocount)

    rows = []
    for r in tqdm(pred.itertuples(index=False), total=len(pred), desc="scoring CAI-top10CSI-train"):
        species = str(r.species)
        score, total, missing = cai_score(r.pred_dna, species, cai_weights)
        rows.append({
            "model": r.model,
            "eval_id": r.eval_id,
            "species": species,
            "bucket": getattr(r, "bucket", ""),
            "protein_len": getattr(r, "protein_len", np.nan),
            "cai_top10csi_train": score,
            "codons_total": total,
            "codons_missing_weight": missing,
            "missing_weight_frac": missing / max(total, 1),
        })

    out = pd.DataFrame(rows)
    out.to_csv(f"{args.out_prefix}_by_sequence.csv", index=False)

    summary = (
        out.groupby("model", as_index=False)
        .agg(
            n=("eval_id", "count"),
            cai_top10csi_train=("cai_top10csi_train", "mean"),
            missing_weight_frac=("missing_weight_frac", "mean"),
        )
    )
    summary.to_csv(f"{args.out_prefix}_summary_by_model.csv", index=False)

    print("\n=== CAI-top10CSI-train summary ===")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
