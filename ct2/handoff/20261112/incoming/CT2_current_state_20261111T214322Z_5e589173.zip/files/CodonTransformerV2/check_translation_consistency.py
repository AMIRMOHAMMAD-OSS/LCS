import json
import random
import tarfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

DATA_DIR = Path("/lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/train_set_shard")
OUT_DIR = Path("preflight_reports/translation_consistency")
OUT_DIR.mkdir(parents=True, exist_ok=True)

N_SAMPLES = 10_000
RANDOM_SEED = 123
MAX_SHARDS_TO_SCAN = 400

CODON_TO_AA = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L","TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*","TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L","CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q","CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M","ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K","AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V","GCT":"A","GCC":"GCC".replace("GCC","A"),"GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E","GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

AMBIG_AA = {"X", "B", "Z", "J", "U", "O"}

def check_pair(dna, protein):
    dna = str(dna).upper().replace("U", "T")
    protein = str(protein).upper()
    dna = dna[: (len(dna) // 3) * 3]

    n_codons = min(len(dna) // 3, len(protein))
    checked = 0
    mismatches = 0
    skipped = 0

    for i in range(n_codons):
        codon = dna[3*i:3*i+3]
        aa = protein[i]
        if aa == "_":
            aa = "*"
        if "N" in codon or aa in AMBIG_AA:
            skipped += 1
            continue
        expected = CODON_TO_AA.get(codon)
        if expected is None:
            skipped += 1
            continue
        checked += 1
        if aa != expected:
            mismatches += 1

    mismatch_rate = mismatches / checked if checked else None
    return {
        "dna_len": len(dna),
        "protein_len": len(protein),
        "n_codons_compared": n_codons,
        "checked_codons": checked,
        "skipped_codons": skipped,
        "mismatches": mismatches,
        "mismatch_rate": mismatch_rate,
    }

random.seed(RANDOM_SEED)

shards = sorted(DATA_DIR.glob("shard-*.tar.gz"))
random.shuffle(shards)
shards = shards[:MAX_SHARDS_TO_SCAN]

rows = []
seen = 0

for shard in shards:
    if seen >= N_SAMPLES:
        break
    try:
        with tarfile.open(shard, "r:gz") as tar:
            members = [m for m in tar if m.isfile() and m.name.endswith(".json")]
            random.shuffle(members)

            for m in members:
                if seen >= N_SAMPLES:
                    break
                f = tar.extractfile(m)
                if f is None:
                    continue

                try:
                    doc = json.loads(f.read().decode("utf-8", errors="replace"))
                except Exception:
                    continue

                dna = doc.get("dna_sequence") or doc.get("seq") or doc.get("dna") or doc.get("sequence")
                protein = doc.get("protein_sequence")

                if dna is None or protein is None:
                    rows.append({
                        "shard": shard.name,
                        "sample": m.name,
                        "has_dna": dna is not None,
                        "has_protein": protein is not None,
                        "mismatch_rate": None,
                        "checked_codons": 0,
                        "mismatches": None,
                    })
                    seen += 1
                    continue

                r = check_pair(dna, protein)
                r.update({
                    "shard": shard.name,
                    "sample": m.name,
                    "has_dna": True,
                    "has_protein": True,
                    "species": doc.get("species"),
                })
                rows.append(r)
                seen += 1

    except Exception as e:
        print(f"BAD_SHARD {shard}: {e}")

df = pd.DataFrame(rows)
csv_path = OUT_DIR / "translation_consistency_sample10k.csv"
df.to_csv(csv_path, index=False)

valid = df[df["mismatch_rate"].notna()].copy()

summary = {
    "samples_total": len(df),
    "samples_with_valid_check": len(valid),
    "missing_dna": int((df["has_dna"] == False).sum()) if "has_dna" in df else 0,
    "missing_protein": int((df["has_protein"] == False).sum()) if "has_protein" in df else 0,
    "mean_mismatch_rate": float(valid["mismatch_rate"].mean()) if len(valid) else None,
    "median_mismatch_rate": float(valid["mismatch_rate"].median()) if len(valid) else None,
    "p95_mismatch_rate": float(valid["mismatch_rate"].quantile(0.95)) if len(valid) else None,
    "frac_rate_eq_0": float((valid["mismatch_rate"] == 0).mean()) if len(valid) else None,
    "frac_rate_gt_0_05": float((valid["mismatch_rate"] > 0.05).mean()) if len(valid) else None,
    "frac_rate_gt_0_20": float((valid["mismatch_rate"] > 0.20).mean()) if len(valid) else None,
}

summary_path = OUT_DIR / "translation_consistency_summary.json"
summary_path.write_text(json.dumps(summary, indent=2))

plt.figure(figsize=(8, 5))
plt.hist(valid["mismatch_rate"], bins=50)
plt.xlabel("DNA → protein mismatch rate")
plt.ylabel("Number of samples")
plt.title("Translation consistency mismatch-rate histogram")
plt.tight_layout()
plt.savefig(OUT_DIR / "mismatch_rate_histogram.png", dpi=200)
plt.close()

plt.figure(figsize=(8, 5))
plt.hist(valid["checked_codons"], bins=50)
plt.xlabel("Checked codons per sample")
plt.ylabel("Number of samples")
plt.title("Checked codon count distribution")
plt.tight_layout()
plt.savefig(OUT_DIR / "checked_codons_histogram.png", dpi=200)
plt.close()

print("DONE")
print(json.dumps(summary, indent=2))
print(f"CSV: {csv_path}")
print(f"PLOTS: {OUT_DIR}")
