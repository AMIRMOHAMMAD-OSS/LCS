import csv
import gc
from pathlib import Path

import pandas as pd
import torch
from tqdm import tqdm

import eval_ct2_overlap_subset as base


MANIFEST = Path("ct2_full_species_eval_manifest_n1.csv")
CKPT_TSV = Path("ct2_stage_checkpoints.tsv")
OUTDIR = Path("ct2_full_species_stage_predictions")
OUTDIR.mkdir(exist_ok=True)


def read_stage_checkpoints(path):
    rows = []
    with path.open() as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith("model"):
                continue

            # Accept both real TSV and whitespace-separated rows.
            parts = line.split()
            if len(parts) < 2:
                continue

            model = parts[0]
            ckpt = parts[1]
            rows.append((model, ckpt))

    return rows


def main():
    df = pd.read_csv(MANIFEST)
    stages = read_stage_checkpoints(CKPT_TSV)

    print("manifest:", MANIFEST)
    print("rows:", len(df))
    print("species:", df["species"].nunique())
    print("stages:", stages)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("device:", device)

    species_to_id = base.load_species_to_id(base.SPECIES_TO_ID_PATH)

    summary_rows = []

    for model_name, ckpt in stages:
        ckpt = str(ckpt)
        out_csv = OUTDIR / f"{model_name}_full_species_predictions.csv"

        if out_csv.exists() and out_csv.stat().st_size > 0:
            print("SKIP existing:", out_csv)
            continue

        print()
        print("=" * 100)
        print("MODEL:", model_name)
        print("CKPT:", ckpt)
        print("OUT:", out_csv)
        print("=" * 100)

        # Patch the global checkpoint path used by base.load_ct2().
        base.CKPT = ckpt

        loaded = base.load_ct2(device)

        if isinstance(loaded, tuple) and len(loaded) == 5:
            tokenizer, harness, id_to_token, aa_to_mask_id, aa_to_codon_ids = loaded
        elif isinstance(loaded, tuple) and len(loaded) == 2:
            tokenizer, harness = loaded
            id_to_token, aa_to_mask_id, aa_to_codon_ids = base.build_vocab_maps(tokenizer)
        else:
            raise ValueError(f"Unexpected load_ct2 return: type={type(loaded)} len={len(loaded) if isinstance(loaded, tuple) else 'NA'}")

        harness.eval()

        fieldnames = [
            "model",
            "eval_id",
            "species",
            "genome_id",
            "gene_id",
            "gene_idx",
            "protein_len",
            "bucket",
            "native_dna",
            "pred_dna",
            "translation_valid",
            "codon_recovery",
            "nt_identity",
            "native_gc3",
            "pred_gc3",
            "abs_gc3_error",
            "error",
        ]

        n_ok = 0
        n_fail = 0

        with out_csv.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()

            for r in tqdm(df.itertuples(index=False), total=len(df), desc=model_name):
                protein = str(r.protein_sequence)
                species = str(r.species)
                native_dna = str(r.dna_sequence)

                row = {
                    "model": model_name,
                    "eval_id": int(r.eval_id),
                    "species": species,
                    "genome_id": str(r.genome_id),
                    "gene_id": str(getattr(r, "gene_id", "")),
                    "gene_idx": int(r.gene_idx),
                    "protein_len": int(r.protein_len),
                    "bucket": base.length_bucket(int(r.protein_len)),
                    "native_dna": native_dna,
                    "pred_dna": "",
                    "translation_valid": "",
                    "codon_recovery": "",
                    "nt_identity": "",
                    "native_gc3": "",
                    "pred_gc3": "",
                    "abs_gc3_error": "",
                    "error": "",
                }

                try:
                    pred = base.ct2_predict_dna(
                        protein,
                        species,
                        tokenizer=tokenizer,
                        harness=harness,
                        species_to_id=species_to_id,
                        id_to_token=id_to_token,
                        aa_to_mask_id=aa_to_mask_id,
                        aa_to_codon_ids=aa_to_codon_ids,
                        device=device,
                    )

                    row["pred_dna"] = pred

                    # Translation validity here means length-compatible generated DNA.
                    row["translation_valid"] = int(len(pred) == 3 * len(base.clean_protein(protein)))

                    row["codon_recovery"] = base.codon_recovery(native_dna, pred)
                    row["nt_identity"] = base.nt_identity(native_dna, pred)
                    row["native_gc3"] = base.gc3_content(native_dna)
                    row["pred_gc3"] = base.gc3_content(pred)

                    if row["native_gc3"] == row["native_gc3"] and row["pred_gc3"] == row["pred_gc3"]:
                        row["abs_gc3_error"] = abs(float(row["native_gc3"]) - float(row["pred_gc3"]))

                    n_ok += 1

                except Exception as e:
                    row["error"] = repr(e)
                    n_fail += 1

                writer.writerow(row)

        print("wrote:", out_csv)
        print("ok:", n_ok)
        print("fail:", n_fail)

        tmp = pd.read_csv(out_csv)
        ok = tmp[tmp["error"].fillna("") == ""].copy()

        summary = {
            "model": model_name,
            "n": len(tmp),
            "ok": len(ok),
            "fail": len(tmp) - len(ok),
            "translation_valid": ok["translation_valid"].mean() if len(ok) else float("nan"),
            "codon_recovery": ok["codon_recovery"].mean() if len(ok) else float("nan"),
            "nt_identity": ok["nt_identity"].mean() if len(ok) else float("nan"),
            "abs_gc3_error": ok["abs_gc3_error"].mean() if len(ok) else float("nan"),
        }
        summary_rows.append(summary)

        print("summary:", summary)

        del tokenizer, harness, id_to_token, aa_to_mask_id, aa_to_codon_ids
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    if summary_rows:
        sdf = pd.DataFrame(summary_rows)
        sdf.to_csv(OUTDIR / "ct2_stage_full_species_prediction_summary.csv", index=False)
        print()
        print("=== PREDICTION SUMMARY ===")
        print(sdf.to_string(index=False))

    print("DONE")


if __name__ == "__main__":
    main()
