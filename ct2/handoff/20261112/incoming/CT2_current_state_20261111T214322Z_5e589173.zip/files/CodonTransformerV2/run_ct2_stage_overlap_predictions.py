from pathlib import Path
import subprocess
import re
import sys

MANIFEST = Path("ct2_stage_checkpoints.tsv")
TEMPLATE = Path("eval_ct2_overlap_subset.py")
OUTDIR = Path("ct2_stage_overlap_predictions")
OUTDIR.mkdir(exist_ok=True)

if not TEMPLATE.exists():
    raise SystemExit("Missing eval_ct2_overlap_subset.py")

template = TEMPLATE.read_text()

rows = []
for line in MANIFEST.read_text().splitlines():
    if not line.strip() or line.startswith("model\t"):
        continue
    model, ckpt = line.split("\t")
    rows.append((model, ckpt))

for model, ckpt in rows:
    out_csv = OUTDIR / f"{model}_overlap_predictions.csv"
    script = OUTDIR / f"eval_{model}_overlap.py"

    s = template

    # Patch checkpoint.
    s = re.sub(
        r'CKPT\s*=\s*["\'].*?["\']',
        f'CKPT = "{ckpt}"',
        s,
        count=1,
    )

    # Patch output CSV if present.
    s = re.sub(
        r'OUT_CSV\s*=\s*Path\(["\'].*?["\']\)',
        f'OUT_CSV = Path("{out_csv}")',
        s,
        count=1,
    )
    s = re.sub(
        r'OUT_CSV\s*=\s*["\'].*?["\']',
        f'OUT_CSV = "{out_csv}"',
        s,
        count=1,
    )

    # Patch model label strings where possible.
    s = s.replace('CT2_stage4_e7', model)
    s = s.replace('"CT2"', f'"{model}"')

    # Add a final model-label correction after CSV write if possible.
    if "to_csv" in s and "pd.read_csv" not in s[-500:]:
        s += f'''

# Force model label for downstream comparison
try:
    import pandas as _pd
    _out = Path("{out_csv}")
    if _out.exists():
        _df = _pd.read_csv(_out)
        _df["model"] = "{model}"
        _df.to_csv(_out, index=False)
        print("FORCED_MODEL_LABEL", "{model}", _out)
except Exception as _e:
    print("MODEL_LABEL_PATCH_WARNING", repr(_e))
'''

    script.write_text(s)
    print("RUN", model)
    print(" script:", script)
    print(" ckpt:", ckpt)
    print(" out:", out_csv)

    subprocess.run([sys.executable, str(script)], check=True)

print("DONE all stage predictions")
