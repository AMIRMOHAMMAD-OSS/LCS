import torch
from model_io import read_checkpoint

CKPT="/lustre/fswork/projects/rech/nef/unh87ms/ct2_retrain/ct2_production_20260930_v4/training/fullmask512/last.ckpt"

cp=read_checkpoint(CKPT)

for k,v in cp.items():
    if isinstance(v,(int,float,str,bool)):
        print(k,":",v)

print("keys:",cp.keys())
