#!/bin/bash
set -euo pipefail

module purge
module load pytorch-gpu/py3/2.6.0

export PYTHONPATH=$PWD:${PYTHONPATH:-}
export SCRATCH=/lustre/fsn1/projects/rech/nef/unh87ms
export XDG_CACHE_HOME="$SCRATCH/.cache"
export HF_HOME="$SCRATCH/huggingface"
export TORCH_HOME="$SCRATCH/torch"
export TMPDIR="$SCRATCH/tmp"
export TRITON_CACHE_DIR="$SCRATCH/triton_cache"
export DEEPSPEED_TMP_DIR="$SCRATCH/deepspeed_tmp"
mkdir -p "$XDG_CACHE_HOME" "$HF_HOME" "$TORCH_HOME" "$TMPDIR" "$TRITON_CACHE_DIR" "$DEEPSPEED_TMP_DIR"

mkdir -p deepspeed
cat > deepspeed/__init__.py <<'PY'
__version__ = "0.0.0"
class DeepSpeedEngine:
    pass
PY

python train_updated.py \
  --dataroot /lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/train_set_shard \
  --shard_pattern "shard-{000000..000499}.tar.gz" \
  --tokenizer_file /lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2/CodonTransformerTokenizer.json \
  --species_to_id_path /lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/species_to_id.json \
  --test_json_dir /lustre/fsn1/projects/rech/nef/unh87ms/codon_project/data/CT2_data/test_set \
  --limit_test_batches 5 \
  --num_organisms 26678 \
  --extra_organisms 2000 \
  --unknown_species_id 26678 \
  --species_dropout_prob 0.05 \
  --mlm_probability 0.15 \
  --max_length 512 \
  --attn_implementation sdpa \
  --learning_rate 1e-4 \
  --max_epochs 1 \
  --batch_size 2 \
  --test_batch_size 2 \
  --num_workers 2 \
  --limit_train_batches 20 \
  --log_every_n_steps 1 \
  --accelerator gpu \
  --devices 1 \
  --strategy auto \
  --precision bf16-mixed \
  --checkpoint_dir /lustre/fsn1/projects/rech/nef/unh87ms/ct2_preflight/a100_step01 \
  --save_interval 1 \
  --seed 123
