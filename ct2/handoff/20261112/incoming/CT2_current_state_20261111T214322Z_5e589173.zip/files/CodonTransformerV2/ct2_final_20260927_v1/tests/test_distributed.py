"""A real two-process Gloo check of uneven-token distributed accumulation."""
import copy
import os
import tempfile
import unittest
from pathlib import Path
import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel
from test_core import Tokenizer,TinyLM
from model_io import CT2,optimizer_for
from phase1_tokens import prepare_sequence
from augmentation import TrainingCollator
from engine import optimizer_update,seed_all

def batch():
    tok=Tokenizer();rows=[]
    for i,n in enumerate((1,3,5,8,10)):
        rows.append({'species_id':i%3,'prepared':prepare_sequence('ATG'+'GCT'*n+'TAA','M'+'A'*n,tok.vocab)})
    return TrainingCollator(tok,3)(rows,512,1.,0,0)

def worker(rank,rendezvous,output):
    torch.set_num_threads(1)
    dist.init_process_group('gloo',init_method='file://'+rendezvous,rank=rank,world_size=2)
    seed_all(44);model=CT2(TinyLM(),4,.0347);opt,_=optimizer_for(model);ddp=DistributedDataParallel(model)
    b=batch();spans=((0,1),(1,2)) if rank==0 else ((2,3),(3,5))
    parts=[{k:v[a:z].clone() for k,v in b.items()} for a,z in spans]
    optimizer_update(ddp,opt,parts,torch.device('cpu'),1e-4)
    if rank==0:torch.save(model.state_dict(),output)
    dist.barrier();dist.destroy_process_group()

class DistributedTests(unittest.TestCase):
    @unittest.skipUnless(os.environ.get('CT2_RUN_DDP_TESTS')=='1','Socket-based DDP test is mandatory in the GPU preflight; local sandbox disallows sockets')
    def test_ddp_matches_global_token_mean(self):
        with tempfile.TemporaryDirectory() as d:
            rendezvous=str(Path(d)/'init');output=str(Path(d)/'result.pt')
            mp.spawn(worker,args=(rendezvous,output),nprocs=2,join=True)
            seed_all(44);model=CT2(TinyLM(),4,.0347);opt,_=optimizer_for(model)
            optimizer_update(model,opt,[batch()],torch.device('cpu'),1e-4)
            actual=torch.load(output,weights_only=True)
            for key,value in model.state_dict().items():torch.testing.assert_close(value,actual[key],atol=1e-7,rtol=1e-6)

if __name__=='__main__':unittest.main()
