"""Complete one-pass synonymous decoding using checkpoint-native conditioning scale."""
from __future__ import annotations
import argparse
import itertools
import json
import os
from pathlib import Path
import torch
from common import ROOT, load_run, resolve_species, atomic_json, sha, source_path
from engine import autocast
from model_io import tokenizer_at, initial_checkpoint, read_checkpoint, build_model
from strict_generation import checked_protein, decode_logits
from phase1_tokens import STANDARD_CODE

@torch.inference_mode()
def generate_batch(model,tokenizer,records,mapping,n_real=26678):
    device=next(model.parameters()).device; vocab=tokenizer.get_vocab()
    proteins=[]; species=[]; rows=[]
    for record in records:
        protein=checked_protein(record['protein_sequence'])
        sid=resolve_species(record['species'],mapping,n_real)
        row=[tokenizer.cls_token_id]+[vocab[f'{aa.lower()}_unk'] for aa in protein]+[vocab['__unk'],tokenizer.sep_token_id]
        if len(row)>model.model.config.max_position_embeddings:
            raise ValueError(f"Protein {record.get('protein_id','?')!r} has {len(protein)} residues; maximum is 2045, no truncation")
        proteins.append(protein);species.append(sid);rows.append(row)
    if not rows: return []
    ids=torch.full((len(rows),max(map(len,rows))),tokenizer.pad_token_id,dtype=torch.long,device=device)
    mask=torch.zeros_like(ids)
    for i,row in enumerate(rows): ids[i,:len(row)]=torch.tensor(row,device=device);mask[i,:len(row)]=1
    training=model.training; model.eval()
    try:
        with autocast(device): logits=model(ids,mask,torch.tensor(species,device=device))
        result=[]
        for i,(protein,sid) in enumerate(zip(proteins,species)):
            dna=decode_logits(logits[i,1:len(protein)+2],protein,vocab)
            result.append({**records[i],'protein_sequence':protein,'species_id':sid,'predicted_dna':dna,
                'protein_length':len(protein),'species_embed_scale':model.scale,'translation_matches':True,
                'terminal_stop_included':True,'genetic_code':'standard','decoding':'synonymous_argmax'})
        return result
    finally: model.train(training)

def gc3(dna):
    codons=[dna[i:i+3] for i in range(0,len(dna),3)]
    codons=[c for c in codons if c in STANDARD_CODE and STANDARD_CODE[c]!='*']
    return sum(c[2] in 'GC' for c in codons)/len(codons) if codons else None

def comparison_stats(prediction):
    dna=prediction['predicted_dna']; native=''.join(prediction.get('dna_sequence','').upper().split()).replace('U','T')
    known=[]
    for i,aa in enumerate(prediction['protein_sequence']):
        codon=native[3*i:3*i+3]
        if STANDARD_CODE.get(codon)==aa: known.append((codon,dna[3*i:3*i+3]))
    gc_pairs=[(native[3*i:3*i+3],dna[3*i:3*i+3]) for i in range(len(prediction['protein_sequence']))
              if native[3*i:3*i+3] in STANDARD_CODE and STANDARD_CODE[native[3*i:3*i+3]]!='*']
    native_gc=sum(a[2] in 'GC' for a,b in gc_pairs)/len(gc_pairs) if gc_pairs else None
    matched_gc=sum(b[2] in 'GC' for a,b in gc_pairs)/len(gc_pairs) if gc_pairs else None
    return {'known_native_positions':len(known),'native_codon_recovery':sum(a==b for a,b in known)/len(known) if known else None,
            'predicted_gc3':gc3(dna),'native_gc3':native_gc,'predicted_gc3_at_known_native_positions':matched_gc,
            'gc3_comparison_positions':len(gc_pairs),
            'gc3_absolute_error':abs(matched_gc-native_gc) if gc_pairs else None}

def compare_hosts(model,tokenizer,records,mapping,hosts):
    requests=[{**r,'native_species':r['species'],'species':host} for r in records for host in hosts]
    predictions=[]
    for i in range(0,len(requests),4): predictions.extend(generate_batch(model,tokenizer,requests[i:i+4],mapping))
    paired=[]
    for i,record in enumerate(records):
        group=predictions[i*len(hosts):(i+1)*len(hosts)]
        for a,b in itertools.combinations(group,2):
            ca=[a['predicted_dna'][j:j+3] for j in range(0,len(a['predicted_dna'])-3,3)]
            cb=[b['predicted_dna'][j:j+3] for j in range(0,len(b['predicted_dna'])-3,3)]
            paired.append({'protein_id':record.get('protein_id'),'host_a':a['species'],'host_b':b['species'],
                           'codon_disagreement':sum(x!=y for x,y in zip(ca,cb))/len(ca),
                           'gc3_a':gc3(a['predicted_dna']),'gc3_b':gc3(b['predicted_dna'])})
    return {'predictions':predictions,'paired_host_comparisons':paired,
            'interpretation':'Different outputs demonstrate sensitivity, not correctness, expression gains, or an optimal host profile.'}

def read_inputs(path,species=None):
    if path.suffix.lower() in ('.fa','.fasta','.faa'):
        if species is None: raise ValueError('FASTA requires --species with an exact mapping name')
        key=None;parts=[]
        with path.open() as f:
            for raw in f:
                line=raw.strip()
                if not line: continue
                if line.startswith('>'):
                    if key is not None: yield {'protein_id':key,'protein_sequence':''.join(parts),'species':species}
                    key=line[1:].strip();parts=[]
                    if not key: raise ValueError('Empty FASTA header')
                else:
                    if key is None: raise ValueError('FASTA sequence before header')
                    parts.append(line)
            if key is not None: yield {'protein_id':key,'protein_sequence':''.join(parts),'species':species}
    else:
        with path.open() as f:
            for line in f:
                if line.strip():
                    doc=json.loads(line)
                    if species is not None: doc['species']=species
                    yield doc

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint',required=True,help='epoch_6, epoch_9, or this run\'s continuation checkpoint path')
    p.add_argument('--input',required=True,type=Path);p.add_argument('--output',required=True,type=Path)
    p.add_argument('--species');p.add_argument('--batch-size',type=int,default=4)
    p.add_argument('--device',default='cuda',choices=['cuda','cpu']);a=p.parse_args()
    if a.batch_size<1: p.error('batch-size must be positive')
    torch.set_float32_matmul_precision('medium')
    cfg=load_run();source_path();tok=tokenizer_at();mapping=json.loads(Path(cfg['mapping']).read_text())
    historical=a.checkpoint if a.checkpoint in cfg['checkpoints'] else None
    checkpoint=initial_checkpoint(cfg,historical) if historical else read_checkpoint(a.checkpoint)
    if not historical and 'ct2_format' not in checkpoint: raise ValueError('Use epoch_6 or epoch_9 for a historical checkpoint')
    model=build_model(checkpoint,tok,cfg,a.device,historical); del checkpoint
    path=Path(cfg['checkpoints'][historical]['path']) if historical else Path(a.checkpoint)
    metadata={'checkpoint':str(path),'checkpoint_sha256':sha(path),'species_scale':model.scale,'mapping_sha256':cfg['mapping_sha256'],
              'input':str(a.input.resolve()),'input_sha256':sha(a.input)}
    if a.output.exists() or a.output.with_suffix(a.output.suffix+'.meta.json').exists(): raise FileExistsError(a.output)
    a.output.parent.mkdir(parents=True,exist_ok=True);temp=a.output.with_name(a.output.name+f'.tmp.{os.getpid()}');count=0
    try:
        records=iter({**record,'input_record_index':i} for i,record in enumerate(read_inputs(a.input,a.species)))
        with temp.open('x') as out:
            while True:
                batch=list(itertools.islice(records,a.batch_size))
                if not batch: break
                for result in generate_batch(model,tok,batch,mapping): out.write(json.dumps(result)+'\n');count+=1
            if count==0: raise ValueError('No input proteins')
            out.flush();os.fsync(out.fileno())
        # Exclusive publication; failures never leave a deceptively complete output file.
        os.link(temp,a.output)
        atomic_json(a.output.with_suffix(a.output.suffix+'.meta.json'),{**metadata,'records':count,'all_translation_checks_passed':True})
    finally:temp.unlink(missing_ok=True)
    print('GENERATED',count,a.output)

if __name__=='__main__': main()
