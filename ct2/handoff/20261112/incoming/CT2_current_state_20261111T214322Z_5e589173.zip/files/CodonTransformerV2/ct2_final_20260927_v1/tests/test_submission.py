import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import submit
from setup import scripts

class SubmissionTests(unittest.TestCase):
    def test_start_is_single_stage_dependency_and_duplicate_is_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);calls=[]
            def fake(command,**kwargs):
                calls.append(command)
                return SimpleNamespace(stdout='' if command[0]=='squeue' else str(100+len(calls))+'\n')
            cfg={'fingerprint':'f','output':str(root/'output')}
            with patch.object(submit,'ROOT',root),patch.object(submit.subprocess,'run',side_effect=fake):
                submit.submit(cfg,'start',0)
                with self.assertRaisesRegex(RuntimeError,'Already submitted'):submit.submit(cfg,'start',0)
            jobs=json.loads((root/'jobs.json').read_text())['submissions']
            self.assertEqual([j['stage'] for j in jobs],[0,0]);self.assertEqual([j['kind'] for j in jobs],['preflight','train'])
            self.assertIn('--dependency=afterok:101',calls[1])
            self.assertIn('--kill-on-invalid-dep=yes',calls[1])

    def test_ambiguous_submission_cannot_be_retried(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);cfg={'fingerprint':'f','output':str(root/'output')}
            with patch.object(submit,'ROOT',root),patch.object(submit.subprocess,'run',return_value=SimpleNamespace(stdout='unrecognized')):
                with self.assertRaisesRegex(RuntimeError,'Ambiguous'):submit.submit(cfg,'start',0)
                with self.assertRaisesRegex(RuntimeError,'ambiguous'):submit.submit(cfg,'retry-preflight',0)

    def test_all_generated_shell_scripts_parse(self):
        import subprocess
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for stage in range(5):
                for name,body in scripts(root,root/'output',stage).items():
                    path=root/name;path.write_text(body);subprocess.run(['bash','-n',str(path)],check=True)
                    self.assertIn('srun --kill-on-bad-exit=1',body)
                    self.assertIn('--ntasks-per-node=4',body)

if __name__=='__main__':unittest.main()
