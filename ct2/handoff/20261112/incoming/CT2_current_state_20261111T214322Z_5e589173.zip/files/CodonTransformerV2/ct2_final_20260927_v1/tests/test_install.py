import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import setup
from common import sha,fingerprint,load_run

class InstallTests(unittest.TestCase):
    def test_install_copies_seals_and_never_overwrites_phase1(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);source=base/'phase1';root=base/'continuation';source.mkdir();root.mkdir()
            bundle=Path(__file__).resolve().parents[1]
            for name in ('phase1_tokens.py','strict_generation.py'):
                shutil.copy2(bundle/name,root/name);shutil.copy2(bundle/name,source/name)
            mapping={f'species_{i}':i for i in range(26678)}
            for i,name in enumerate(('Escherichia coli str. K-12 substr. MG1655','Homo sapiens',
                    'Saccharomyces cerevisiae S288C','Plasmodium falciparum 3D7','Streptomyces test')):
                del mapping[f'species_{i}'];mapping[name]=i
            mapping_file=base/'mapping.json';mapping_file.write_text(json.dumps(mapping))
            outputs=base/'outputs/phase1';(outputs/'full').mkdir(parents=True)
            for epoch in (6,9):
                with (outputs/f'full/epoch_{epoch}.ckpt').open('wb') as f:f.truncate(1_000_000_001)
            rows=[{'eval_key':str(i),'species':i%26678,'protein_id':str(i),'protein_sequence':'MA','dna_sequence':'ATGGCTTAA'} for i in range(4096)]
            (source/'eval_panel.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
            cfg={'code_hashes':{n:sha(source/n) for n in ('phase1_tokens.py','strict_generation.py')},
                 'species_mapping':str(mapping_file),'species_mapping_sha256':sha(mapping_file),
                 'data_root':'/fixture','output_dir':str(outputs)}
            cfg['fingerprint']=fingerprint(cfg);(source/'run_config.json').write_text(json.dumps(cfg))
            (source/'eval_panel_meta.json').write_text(json.dumps({'fingerprint':cfg['fingerprint'],'samples':4096,'sha256':sha(source/'eval_panel.jsonl')}))
            before=sha(source/'run_config.json')
            def hash_file(p):return 'fixture_checkpoint_hash' if Path(p).suffix=='.ckpt' else sha(p)
            with patch.object(setup,'SOURCE_FINGERPRINT',cfg['fingerprint']),patch.object(setup,'inventory',return_value=[]),patch.object(setup,'sha',side_effect=hash_file):
                setup.setup(source,'epoch_9',1,root)
                with self.assertRaises(FileExistsError):setup.setup(source,'epoch_9',1,root)
            installed=load_run(root);self.assertEqual(installed['source_step'],80000)
            self.assertEqual(sha(source/'run_config.json'),before)
            self.assertEqual(installed['comparison_hosts'][-1],'Streptomyces test')
            (root/'source/phase1_tokens.py').write_text('tampered')
            with self.assertRaisesRegex(RuntimeError,'changed'):load_run(root)

if __name__=='__main__':unittest.main()
