#!/usr/bin/env python3
"""Diagnose CT2's two failed CPU gradient tests; never submit training.

Upload this file to Jean Zay and run:
    python3 ct2_numerics_diagnostic.py submit

The default run directory is the existing ct2_final_20260927_v1 installation.
The diagnostic requests one H100 node / one GPU for at most ten minutes so the
CPU math libraries and node type match the failed preflight. The tests use CPU.
No CT2 source, configuration, checkpoint, or preflight stamp is modified.
Original assertion tolerances are retained in every diagnostic case.
"""
from __future__ import annotations

import argparse
import copy
import functools
import json
import os
from pathlib import Path
import platform
import shlex
import subprocess
import sys
import unittest
from unittest.mock import patch

DEFAULT_RUN = Path('/lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2/ct2_final_20260927_v1')
CASES = ('original_cold', 'original_after_modernbert', 'highest_no_mkldnn', 'fp64_toy')


def emit(label, value):
    print(label + ': ' + json.dumps(value, sort_keys=True), flush=True)


def add_paths(root):
    for path in (root, root / 'tests'):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))


def verify_run(root):
    add_paths(root)
    from common import load_run
    cfg = load_run(root)
    emit('SEALED_RUN_VERIFIED', {'directory': str(root), 'fingerprint': cfg['fingerprint']})
    return cfg


def configure(root, case):
    add_paths(root)
    import torch
    torch.set_num_threads(1)
    if case in ('highest_no_mkldnn', 'fp64_toy'):
        torch.set_float32_matmul_precision('highest')
        torch.backends.mkldnn.enabled = False
    if case == 'fp64_toy':
        # Only the synthetic TinyLM and its species embedding use float64.
        # The installed optimizer_update still computes cross-entropy in float32.
        import test_core
        original = test_core.CT2

        def double_toy(model, *args, **kwargs):
            result = original(model, *args, **kwargs)
            return result.double() if isinstance(model, test_core.TinyLM) else result

        test_core.CT2 = double_toy
        import test_distributed
        test_distributed.CT2 = double_toy


def ddp_worker(rank, rendezvous, output, *, root, case):
    # Spawn does not inherit Python backend flags or in-memory test patches.
    configure(Path(root), case)
    from test_distributed import worker
    worker(rank, rendezvous, output)


def summary(reference, actual, rtol=1e-5, atol=1e-7):
    import torch
    a, b = reference.detach().double(), actual.detach().double()
    diff = (a - b).abs()
    return {
        'max_abs': float(diff.max()),
        'relative_l2': float(torch.linalg.vector_norm(a - b) / torch.linalg.vector_norm(a).clamp_min(1e-30)),
        'mismatches': int((diff > atol + rtol * a.abs()).sum()),
        'elements': a.numel(),
    }


def gradient_probe():
    """Compare engine gradients to a separate float64 log-softmax reference."""
    import torch
    import test_core as tc
    from augmentation import TrainingCollator
    from engine import optimizer_update, seed_all
    from model_io import optimizer_for
    from phase1_tokens import prepare_sequence

    seed_all(87)
    tok = tc.Tokenizer()
    base = tc.CT2(tc.TinyLM(), 4, .0347)
    rows = [
        {'prepared': prepare_sequence('ATG' + 'GCT' * n + 'TAA', 'M' + 'A' * n, tok.vocab),
         'species_id': i % 3}
        for i, n in enumerate((1, 8, 2, 7, 3))
    ]
    batch = TrainingCollator(tok, 3)(rows, 512, 1., 0, 0)
    spans = (((0, 1), (1, 2)), ((2, 3), (3, 5)))
    parts = [[{k: v[a:z].clone() for k, v in batch.items()} for a, z in rank_spans]
             for rank_spans in spans]
    counts = [sum(int(p['labels'].ne(-100).sum()) for p in rank_parts) for rank_parts in parts]
    total = sum(counts)

    def forward(model, b):
        return model(b['input_ids'], b['attention_mask'], b['species_id'])

    with torch.no_grad():
        whole = forward(base, batch)
        split = torch.cat([forward(base, p) for ps in parts for p in ps])
        oracle_logits = forward(copy.deepcopy(base).double(), batch)
    emit('PROBE_SETUP', {'device': str(next(base.parameters()).device),
                        'parameter_dtype': str(next(base.parameters()).dtype),
                        'logits_dtype': str(whole.dtype), 'targets_per_rank': counts,
                        'targets_total': total, 'dropout': 0.0})
    emit('LOGITS_WHOLE_VS_SPLIT', summary(whole, split))
    emit('LOGITS_VS_FP64', summary(oracle_logits, whole))

    oracle = copy.deepcopy(base).double()
    valid = batch['labels'].ne(-100)
    logits = forward(oracle, batch)[valid]
    labels = batch['labels'][valid]
    loss = -logits.log_softmax(-1).gather(1, labels[:, None]).mean()
    loss.backward()

    whole_model = copy.deepcopy(base)
    optimizer, _ = optimizer_for(whole_model)
    with patch.object(optimizer, 'step'):
        optimizer_update(whole_model, optimizer, [batch], torch.device('cpu'), 1e-4, clip=1e10)

    rank_gradients = []
    for ps in parts:
        model = copy.deepcopy(base)
        optimizer, _ = optimizer_for(model)

        def reduction(t):
            return torch.tensor(total, dtype=t.dtype, device=t.device) if t.ndim == 0 else t

        with patch('engine.world', return_value=2), patch('engine.sum_tensor', side_effect=reduction), \
                patch.object(optimizer, 'step'):
            optimizer_update(model, optimizer, ps, torch.device('cpu'), 1e-4, clip=1e10)
        rank_gradients.append(dict((name, p.grad.detach().clone()) for name, p in model.named_parameters()))

    oracle_params = dict(oracle.named_parameters())
    for name, p in whole_model.named_parameters():
        averaged = (rank_gradients[0][name] + rank_gradients[1][name]) / 2
        emit('GRADIENT', {'parameter': name,
                         'whole_vs_rank_average': summary(p.grad, averaged),
                         'whole_vs_independent_fp64': summary(oracle_params[name].grad, p.grad),
                         'rank_average_vs_independent_fp64': summary(oracle_params[name].grad, averaged)})


def run_case(root, case, run_ddp=True):
    os.environ['CT2_RUN_DDP_TESTS'] = '1' if run_ddp else '0'
    configure(root, case)
    import torch
    import test_core
    import test_distributed
    emit('CASE', case)
    if case != 'original_cold':
        # The failed preflight imported/ran ModernBERT before the gradient tests.
        warmup = unittest.TestSuite([test_core.GenerationTests('test_real_modernbert_checkpoint_strict_load_and_forward')])
        result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(warmup)
        emit('MODERNBERT_WARMUP', {'passed': result.wasSuccessful()})
    emit('PRECISION_STATE', {'float32_matmul_precision': torch.get_float32_matmul_precision(),
                             'mkldnn_enabled': torch.backends.mkldnn.enabled,
                             'default_dtype': str(torch.get_default_dtype()),
                             'threads': torch.get_num_threads(),
                             'cpu_autocast': torch.is_autocast_enabled('cpu')})
    gradient_probe()
    suite = unittest.TestSuite([
        test_core.TrainingTests('test_unequal_rank_target_weighting_before_ddp_average'),
        test_core.TrainingTests('test_accumulation_uses_global_token_mean'),
        test_distributed.DistributedTests('test_ddp_matches_global_token_mean'),
    ])
    adapted_worker = functools.partial(ddp_worker, root=str(root), case=case)
    with patch.object(test_distributed, 'worker', adapted_worker):
        result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(suite)
    emit('CASE_RESULT', {'case': case, 'passed': result.wasSuccessful(), 'tests': result.testsRun,
                         'failures': len(result.failures), 'errors': len(result.errors),
                         'skipped': len(result.skipped), 'original_tolerances': True})
    return 0 if result.wasSuccessful() else 1


def run_all(root):
    verify_run(root)
    import torch
    emit('ENVIRONMENT', {'hostname': platform.node(), 'python': sys.version, 'torch': torch.__version__,
                         'machine': platform.machine(), 'cuda_build': torch.version.cuda,
                         'cpu_capability': torch.backends.cpu.get_cpu_capability(),
                         'slurm_job_id': os.environ.get('SLURM_JOB_ID')})
    prefixes = ('MKL_', 'ONEDNN_', 'DNNL_', 'OPENBLAS_', 'OMP_', 'ATEN_', 'TORCH_ALLOW_', 'NVIDIA_TF32_')
    emit('MATH_ENVIRONMENT', {k: v for k, v in os.environ.items() if k.startswith(prefixes)})
    print(torch.__config__.show(), flush=True)
    codes = {}
    for case in CASES:
        env = dict(os.environ, CT2_RUN_DDP_TESTS='1')
        if case in ('highest_no_mkldnn', 'fp64_toy'):
            env.pop('ONEDNN_DEFAULT_FPMATH_MODE', None)
            env.pop('DNNL_DEFAULT_FPMATH_MODE', None)
        completed = subprocess.run([sys.executable, '-u', str(Path(__file__).resolve()), 'case',
                                    '--run-dir', str(root), '--case', case], env=env, check=False)
        codes[case] = completed.returncode
    verify_run(root)
    emit('DIAGNOSTIC_EXIT_CODES', codes)
    print('DIAGNOSTIC_COLLECTION_FINISHED: this is not a preflight pass; no training was submitted.', flush=True)


def submit_diagnostic(root):
    verify_run(root)
    script = Path(__file__).resolve()
    log = root / 'logs' / 'ct2_numerics_%j.out'
    if not log.parent.is_dir():
        raise FileNotFoundError(log.parent)
    body = '\n'.join([
        '#!/bin/bash', 'set -euo pipefail',
        'module purge', 'module load arch/h100', 'module load pytorch-gpu/py3/2.6.0',
        'export PYTHONUNBUFFERED=1 TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=1 MKL_NUM_THREADS=1',
        'export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TMPDIR=/tmp',
        'exec python -u ' + shlex.quote(str(script)) + ' run --run-dir ' + shlex.quote(str(root)), '',
    ])
    command = ['sbatch', '--parsable', '--job-name=ct2_numerics', '--account=nef@h100',
               '--partition=gpu_p6', '--constraint=h100', '--nodes=1', '--ntasks=1',
               '--gres=gpu:1', '--cpus-per-task=8', '--time=00:10:00', '--hint=nomultithread',
               '--chdir=' + str(root), '--output=' + str(log), '--error=' + str(log)]
    result = subprocess.run(command, input=body, text=True, capture_output=True, check=True)
    job = result.stdout.strip().split(';')[0]
    if not job.isdigit():
        raise RuntimeError('Unrecognized submission response; inspect squeue before retrying: ' + repr(result.stdout))
    print('DIAGNOSTIC_JOB:', job)
    print('LOG:', str(log).replace('%j', job))
    print('This job only diagnoses CPU tests. No preflight or training job was submitted.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('submit', 'run', 'case'))
    parser.add_argument('--run-dir', type=Path, default=DEFAULT_RUN)
    parser.add_argument('--case', choices=CASES)
    args = parser.parse_args()
    root = args.run_dir.resolve()
    if args.action == 'submit':
        submit_diagnostic(root)
    elif args.action == 'run':
        run_all(root)
    else:
        if args.case is None:
            parser.error('--case is required with case')
        return run_case(root, args.case)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
