#!/usr/bin/env python3
"""Submit an initial preflight + stage, resume an interrupted stage, or explicitly advance."""
from __future__ import annotations
import argparse
import fcntl
import json
import subprocess
from pathlib import Path
from common import ROOT, STAGES, load_run, atomic_json, stage_index

def live_jobs(registry):
    ids=[item['job'] for item in registry.get('submissions',[]) if item.get('job')]
    if not ids:return []
    out=subprocess.run(['squeue','-h','-j',','.join(ids),'-o','%i'],check=True,text=True,capture_output=True)
    return out.stdout.split()

def submit(cfg,action,stage):
    path=ROOT/'jobs.json'
    with (ROOT/'.submission.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        registry=json.loads(path.read_text()) if path.exists() else {'fingerprint':cfg['fingerprint'],'submissions':[]}
        if registry['fingerprint']!=cfg['fingerprint']:raise ValueError('Submission registry belongs to another run')
        if registry.get('pending_submission'):raise RuntimeError('An sbatch result is ambiguous; inspect status and Slurm before retrying')
        if live_jobs(registry):raise RuntimeError('A job is still queued/running for this run; inspect status')
        if action=='start' and path.exists():raise RuntimeError('Already submitted; use status, resume, or retry-preflight')
        out=Path(cfg['output'])/'training'/STAGES[stage]['name']
        if (out/'completed.json').exists():raise RuntimeError('This stage is complete; use report or advance')
        if action=='resume':
            if not (out/'last.ckpt').is_file():raise RuntimeError('No checkpoint exists for this stage; use retry-preflight')
            if not (ROOT/f'preflight_{STAGES[stage]["name"]}_passed.json').exists():raise RuntimeError('Missing GPU preflight')
        elif (out/'last.ckpt').exists():raise RuntimeError('Existing training checkpoint; use resume')
        if stage>0:
            previous=Path(cfg['output'])/'training'/STAGES[stage-1]['name']/'verified_complete.json'
            done=json.loads(previous.read_text())
            if done['fingerprint']!=cfg['fingerprint']:raise RuntimeError('Previous stage is not verified complete')
        kinds=('train',) if action=='resume' else ('preflight','train')
        dependency=None
        for kind in kinds:
            script=ROOT/f'{kind}_{STAGES[stage]["name"]}.slurm'
            command=['sbatch','--parsable']
            if dependency:command+=['--kill-on-invalid-dep=yes','--dependency=afterok:'+dependency]
            entry={'stage':stage,'kind':kind,'action':action,'script':str(script)}
            registry['pending_submission']=entry;atomic_json(path,registry)
            result=subprocess.run([*command,str(script)],check=True,text=True,capture_output=True,cwd=ROOT)
            job=result.stdout.strip().split(';')[0]
            if not job.isdigit():raise RuntimeError(f'Ambiguous sbatch response: {result.stdout!r}')
            registry['submissions'].append({**entry,'job':job});registry.pop('pending_submission');atomic_json(path,registry)
            dependency=job;print(kind.upper()+'_JOB:',job,flush=True)
    print('DIRECTORY:',ROOT);print('OUTPUT:',cfg['output']);print('Only the requested stage will run.')

def status(cfg):
    path=ROOT/'jobs.json'
    if not path.exists():print('No jobs submitted.');return
    registry=json.loads(path.read_text());print(json.dumps(registry,indent=2))
    ids=','.join(item['job'] for item in registry['submissions'])
    if ids:subprocess.run(['sacct','-X','-j',ids,'--format=JobID,JobName,State,Elapsed,ExitCode'],check=True)
    for stage in STAGES:
        if (ROOT/f'preflight_{stage["name"]}_passed.json').exists():print('PREFLIGHT_PASSED:',stage['name'])

def report(cfg):
    print('Correct synonymous loss = native codon NLL within its amino-acid family. Positive delta favors correct species.')
    print('stage step length input correct_syn wrong_mean_delta 95%CI')
    for stage in STAGES:
        out=Path(cfg['output'])/'training'/stage['name']
        for path in sorted(out.glob('evaluation_[0-9]*.json')):
            item=json.loads(path.read_text())
            for length,panel in item['panels'].items():
                for mode,row in panel['modes'].items():
                    delta=row['deltas']['wrong_mean'];lo,hi=delta['synonymous_95pct_species_bootstrap']
                    print(f"{stage['name']} {item['continuation_step']} {length} {mode} {row['conditions']['correct']['synonymous_loss']:.6f} {delta['synonymous_delta']:+.6f} [{lo:+.6f},{hi:+.6f}]")
        if (out/'progress.json').exists():
            progress=json.loads((out/'progress.json').read_text());stats=progress['statistics'];norms=stats['grad_norms'];v=stats['totals']
            print('TRAINING:',json.dumps({'stage':stage['name'],'draws':int(v[4]),'valid_tokens':int(v[5]),
                'full_mask_target_share':v[3]/(v[1]+v[3]),'full_mask_draw_fraction':v[6]/v[4],
                'clip_fraction':sum(x>.5 for x in norms)/len(norms),'max_gradient':max(norms),
                'updates_per_active_second':len(norms)/stats['active_seconds']}))
        if (out/'verified_complete.json').exists():print('VERIFIED_COMPLETE:',stage['name'])
    print('Detailed native recovery, GC3 and same-protein host comparisons are in evaluation JSON files.')
    print('CSI/species rank and MinMax-18 require the original codon tables/scorer; do not infer them from host disagreement.')

def errors():
    for path in sorted((ROOT/'logs').glob('*'),key=lambda p:p.stat().st_mtime)[-4:]:
        print('\nFILE:',path)
        with path.open(errors='replace') as f:
            from collections import deque
            print(''.join(deque(f,maxlen=100)))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=['start','status','report','errors','resume','advance','retry-preflight'])
    p.add_argument('--stage',choices=[s['name'] for s in STAGES],default='fullmask512');a=p.parse_args();cfg=load_run()
    if a.action=='status':status(cfg)
    elif a.action=='report':report(cfg)
    elif a.action=='errors':errors()
    else:
        stage=stage_index(a.stage)
        if a.action=='start' and stage!=0:p.error('start always launches the first stage')
        if a.action=='advance' and stage==0:p.error('advance requires a later --stage')
        submit(cfg,a.action,stage)
