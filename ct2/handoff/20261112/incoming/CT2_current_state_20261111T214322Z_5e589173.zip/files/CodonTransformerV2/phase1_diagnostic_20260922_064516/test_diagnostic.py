#!/usr/bin/env python3
"""Small CPU checks for the diagnostic's conditioning and loss calculations."""
import json
import math
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

import torch
from diagnose import (aggregate, coverage_report, embedding_statistics, evaluate,
                      paired_deltas, row_statistics, synonymous_groups)


class DiagnosticTests(unittest.TestCase):
    def test_raw_and_restricted_predictions_and_ignored_positions(self):
        groups = torch.tensor([0, 0, 1, 1, -1])
        labels = torch.tensor([[0, -100, 2], [1, 3, -100]])
        for dtype in (torch.float32, torch.bfloat16):
            logits = torch.zeros((2, 3, 5), dtype=dtype)
            logits[:, :, 4] = 9  # Non-codon wins unrestricted argmax.
            for row, column in labels.ne(-100).nonzero().tolist():
                logits[row, column, labels[row, column]] = 2
            logits[0, 1] = float("nan")  # Unsupervised positions are never reduced.
            result = row_statistics(logits, labels, groups)
            self.assertEqual(result[:, 0].tolist(), [2., 2.])
            metrics = aggregate(result)
            self.assertEqual(metrics["raw_accuracy"], 0.)
            self.assertEqual(metrics["synonymous_accuracy"], 1.)
            self.assertAlmostEqual(metrics["synonymous_loss"], math.log1p(math.exp(-2)), places=6)

    def test_nonfinite_supervised_logits_and_invalid_labels_fail(self):
        groups = torch.tensor([0, 0, -1])
        logits = torch.zeros((1, 1, 3))
        with self.assertRaises(ValueError):
            row_statistics(logits, torch.tensor([[2]]), groups)
        logits[0, 0, 0] = float("inf")
        with self.assertRaises(FloatingPointError):
            row_statistics(logits, torch.tensor([[0]]), groups)

    def test_paired_species_bootstrap_uses_target_weights_and_sign(self):
        counts = torch.tensor([10., 1., 100.], dtype=torch.float64)
        correct = torch.zeros((3, 5), dtype=torch.float64)
        correct[:, 0], correct[:, 1], correct[:, 2] = counts, counts, counts * .5
        other = correct.clone()
        other[:, 1] += counts * .2
        other[:, 2] += counts * .3
        result = paired_deltas(correct, other, [0, 0, 1], bootstrap=128)
        self.assertAlmostEqual(result["raw_delta"], .2)
        self.assertAlmostEqual(result["synonymous_delta"], .3)
        for value in result["synonymous_95pct_species_bootstrap"]:
            self.assertAlmostEqual(value, .3)
        swapped = paired_deltas(other, correct, [0, 0, 1], bootstrap=128)
        self.assertAlmostEqual(swapped["synonymous_delta"], -.3)
        other[0, 0] += 1
        with self.assertRaises(ValueError):
            paired_deltas(correct, other, [0, 0, 1])

    def test_coverage_handles_names_and_numeric_ids_and_checks_totals(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            audit = output / "data_audit"
            audit.mkdir()
            path = audit / "filter_job31897_rank0_pid100.json"
            report = {"counts": {"examined": 7, "accepted": 5, "excluded": 2},
                      "by_species": {"species_a": {"accepted": 3}, "1": {"accepted": 2}}}
            path.write_text(json.dumps(report))
            result, seen = coverage_report(output, {"species_a": 0, "species_b": 1, "species_c": 2}, 3, [0, 2], "31897")
            self.assertEqual(seen, {0, 1})
            self.assertEqual(result["panel_species_with_accepted_draws"], 1)
            report["counts"]["accepted"] += 1
            path.write_text(json.dumps(report))
            with self.assertRaises(ValueError):
                coverage_report(output, {"species_a": 0}, 3, [0], "31897")

    def test_embedding_report_separates_unknown_and_real_rows(self):
        initial = torch.ones((4, 3))
        current = initial.clone()
        current[2] *= 2
        result = embedding_statistics(current, initial, 2, .5, {0})
        self.assertEqual(result["real_relative_drift_median"], 0.)
        self.assertAlmostEqual(result["unknown_relative_drift"], 1.)

    def test_four_condition_forward_changes_species_without_training(self):
        class Model(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.tokens = torch.nn.Embedding(4, 4)
                with torch.no_grad():
                    self.tokens.weight.zero_()

            def get_input_embeddings(self):
                return self.tokens

            def forward(self, *, inputs_embeds, attention_mask):
                return SimpleNamespace(logits=inputs_embeds)

        model = Model().eval()
        species = torch.nn.Embedding.from_pretrained(torch.tensor([[3., 0, 0, 0], [0., 3, 0, 0], [0., 0, 0, 0]]), freeze=False).eval()
        before = species.weight.detach().clone()
        batch = {"input_ids": torch.tensor([[0]]), "attention_mask": torch.tensor([[1]]),
                 "labels": torch.tensor([[0]]), "species_id": torch.tensor([0]),
                 "wrong_species_id": torch.tensor([1])}
        rows = evaluate(model, species, [([0], batch)], torch.tensor([0, 0, 1, -1]), 1., 2, 1)
        self.assertLess(aggregate(rows["correct"])["raw_loss"], aggregate(rows["wrong"])["raw_loss"])
        self.assertTrue(torch.equal(rows["unknown"], rows["zero"]))
        self.assertTrue(torch.equal(before, species.weight))
        self.assertIsNone(species.weight.grad)

    def test_standard_alphabet_groups_exclude_unknown_tokens(self):
        # A complete synthetic 90-token vocabulary, independent of numeric order.
        import itertools
        codons = ["".join(parts) for parts in itertools.product("tcag", repeat=3)]
        aas = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"
        words = ["[PAD]", "[CLS]", "[SEP]", "[MASK]", "[UNK]"]
        words += [f"{aa}_unk" for aa in "_acdefghiklmnpqrstvwy"]
        words += [f"{'_' if aa == '*' else aa.lower()}_{codon}" for aa, codon in zip(aas, codons)]
        vocab = {token: index for index, token in enumerate(words)}
        self.assertEqual(len(vocab), 90)
        groups = synonymous_groups(vocab)
        self.assertEqual(groups[vocab["m_unk"]], -1)
        self.assertEqual(groups[vocab["__taa"]], groups[vocab["__tag"]])
        self.assertNotEqual(groups[vocab["m_atg"]], groups[vocab["v_gtg"]])


if __name__ == "__main__":
    torch.set_num_threads(2)
    unittest.main(verbosity=2)
