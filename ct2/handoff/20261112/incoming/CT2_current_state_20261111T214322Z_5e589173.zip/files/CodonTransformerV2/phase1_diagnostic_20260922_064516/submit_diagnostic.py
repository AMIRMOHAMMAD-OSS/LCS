#!/usr/bin/env python3
"""Submit or inspect the separate CT2 checkpoint evaluation."""
import argparse
from collections import deque
import fcntl
import json
from pathlib import Path
import re
import subprocess

DEFAULT_RUN = "/lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2/phase1_runs/phase1_final_20260921_190347"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("start", "status", "report"))
    parser.add_argument("--run", default=DEFAULT_RUN, type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    jobfile = here / "diagnostic_job.json"
    if args.action == "start":
        lock = (here / ".submission.lock").open("a")
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        if jobfile.exists() or (here / "results").exists():
            raise SystemExit("This diagnostic already has a submission/results. Use status or report.")
        cfg = json.loads((args.run / "run_config.json").read_text())
        full = Path(cfg["output_dir"]) / "full"
        for path in [args.run / "eval_panel.jsonl", Path(cfg["init_checkpoint"]),
                     *[full / f"epoch_{epoch}.ckpt" for epoch in range(3)]]:
            if not path.is_file():
                raise FileNotFoundError(path)
        result = subprocess.run(["sbatch", "--parsable", f"--chdir={here}",
            f"--output={here}/diagnostic_%j.out", f"--error={here}/diagnostic_%j.err",
            str(here / "diagnostic.slurm"), "--run", str(args.run.resolve()),
            "--output", str(here / "results"), "--training-job", "31897"],
            text=True, capture_output=True, check=True)
        if result.stderr.strip():
            print(result.stderr.strip())
        match = re.fullmatch(r"\s*(\d+)(?:;[\w.-]+)?\s*", result.stdout)
        if not match:
            raise SystemExit("Unrecognized sbatch reply; inspect squeue before retrying: " + result.stdout)
        info = {"job_id": match[1], "run": str(args.run.resolve())}
        jobfile.write_text(json.dumps(info, indent=2) + "\n")
        print("DIAGNOSTIC_JOB:", info["job_id"])
        print("DIRECTORY:", here)
        print("RESULT:", here / "results" / "summary.txt")
    elif args.action == "status":
        info = json.loads(jobfile.read_text())
        subprocess.run(["sacct", "-X", "-j", info["job_id"], "--format=JobID,State,Elapsed,ExitCode"], check=True)
        subprocess.run(["squeue", "-j", info["job_id"]], check=False)
    else:
        result = here / "results" / "results.json"
        if result.exists():
            report = json.loads(result.read_text())
            print("COMPLETE" if report.get("completed_utc") else "PARTIAL RESULT; diagnostic has not finished")
            print((result.parent / "summary.txt").read_text())
        else:
            print("No result yet. Check status and the diagnostic log below.")
        if jobfile.exists():
            info = json.loads(jobfile.read_text())
            for suffix in ("out", "err"):
                path = here / f"diagnostic_{info['job_id']}.{suffix}"
                if path.exists() and (not result.exists() or suffix == "err"):
                    print("LOG:", path)
                    with path.open(errors="replace") as stream:
                        print("".join(deque(stream, maxlen=15)))


if __name__ == "__main__":
    main()
