import argparse
import hashlib
import math
import multiprocessing as mp

import numpy as np
import pandas as pd
from tqdm import tqdm


GENETIC_CODE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

G_WEIGHT = None
G_SPECIES = None
G_RARE_MODE = None
G_WRONG_N = None


def clean_dna(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def stable_wrong_species(target, all_species, n):
    pool = [s for s in all_species if s != target]
    if not pool:
        return []
    h = hashlib.md5(str(target).encode()).hexdigest()
    seed = int(h[:8], 16)
    rng = np.random.default_rng(seed)
    n = min(n, len(pool))
    idx = rng.choice(len(pool), size=n, replace=False)
    return [pool[i] for i in idx]


def build_weight_lookup(freq_df, rare_mode):
    use = freq_df.copy()

    if rare_mode == "no_rare_0_001":
        use = use[~use["rare_lt_0_001"]].copy()
    elif rare_mode == "no_rare_0_01":
        use = use[~use["rare_lt_0_01"]].copy()

    max_freq = (
        use.groupby(["species", "aa"], as_index=False)["frequency"]
        .max()
        .rename(columns={"frequency": "max_frequency"})
    )
    use = use.merge(max_freq, on=["species", "aa"], how="left")
    use["weight"] = use["frequency"] / use["max_frequency"]

    lookup = {}
    for r in tqdm(use.itertuples(index=False), total=len(use), desc=f"CAI lookup {rare_mode}"):
        lookup[(r.species, r.aa, r.codon)] = float(r.weight)

    return lookup


def cai_for_species(seq, species, weight_lookup):
    seq = clean_dna(seq)
    logs = []
    missing = 0
    total = 0

    for i in range(0, len(seq) - 2, 3):
        codon = seq[i:i+3]
        if len(codon) != 3 or any(c not in "ACGT" for c in codon):
            continue

        aa = GENETIC_CODE.get(codon)
        if aa is None or aa == "*":
            continue

        total += 1
        w = weight_lookup.get((species, aa, codon))

        if w is None or w <= 0:
            missing += 1
            continue

        logs.append(math.log(w))

    if not logs:
        return np.nan, total, missing

    return float(math.exp(sum(logs) / len(logs))), total, missing


def init_worker(weight_lookup, species_list, rare_mode, wrong_n):
    global G_WEIGHT, G_SPECIES, G_RARE_MODE, G_WRONG_N
    G_WEIGHT = weight_lookup
    G_SPECIES = species_list
    G_RARE_MODE = rare_mode
    G_WRONG_N = wrong_n


def score_row(item):
    idx, rec = item

    model = str(rec["model"])
    species = str(rec["species"])
    pred_dna = rec["pred_dna"]

    own, total, missing = cai_for_species(pred_dna, species, G_WEIGHT)

    wrong_species = stable_wrong_species(species, G_SPECIES, G_WRONG_N)
    wrong_vals = []
    for ws in wrong_species:
        v, _, _ = cai_for_species(pred_dna, ws, G_WEIGHT)
        if not pd.isna(v):
            wrong_vals.append(v)

    wrong_mean = float(np.mean(wrong_vals)) if wrong_vals else np.nan
    ratio = own / wrong_mean if wrong_mean and not pd.isna(own) and not pd.isna(wrong_mean) else np.nan
    delta_log = math.log(own) - math.log(wrong_mean) if own and wrong_mean and own > 0 and wrong_mean > 0 else np.nan

    return {
        "rare_mode": G_RARE_MODE,
        "row_id": idx,
        "model": model,
        "species": species,
        "bucket": rec.get("bucket", ""),
        "protein_len": rec.get("protein_len", np.nan),
        "cai_own": own,
        "cai_wrong_mean": wrong_mean,
        "ratio_cai_own_over_wrong": ratio,
        "delta_log_cai_own_minus_wrong": delta_log,
        "codons_total": total,
        "codons_missing_weight": missing,
        "missing_weight_frac": missing / max(total, 1),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--out_prefix", default="cai_own_wrong")
    ap.add_argument("--wrong_n", type=int, default=5)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--chunksize", type=int, default=100)
    args = ap.parse_args()

    pred = pd.read_csv(args.predictions)
    pred = pred[pred["pred_dna"].fillna("").astype(str).str.len() > 0].copy()

    freq = pd.read_parquet(args.codon_table)
    species_list = sorted(freq["species"].dropna().astype(str).unique().tolist())

    print("prediction rows:", len(pred))
    print("models:", pred["model"].nunique())
    print("codon table species:", len(species_list))
    print("wrong_n:", args.wrong_n)

    records = list(pred.to_dict(orient="index").items())
    all_results = []

    for rare_mode in ["all", "no_rare_0_001", "no_rare_0_01"]:
        print("\n" + "=" * 80)
        print("RARE MODE:", rare_mode)
        print("=" * 80)

        weight_lookup = build_weight_lookup(freq, rare_mode)

        with mp.Pool(
            processes=args.workers,
            initializer=init_worker,
            initargs=(weight_lookup, species_list, rare_mode, args.wrong_n),
        ) as pool:
            rows = list(
                tqdm(
                    pool.imap(score_row, records, chunksize=args.chunksize),
                    total=len(records),
                    desc=f"CAI {rare_mode}",
                )
            )

        mode_df = pd.DataFrame(rows)
        partial = f"{args.out_prefix}_{rare_mode}_by_sequence.csv"
        mode_df.to_csv(partial, index=False)
        print("wrote partial:", partial)

        all_results.append(mode_df)

    out = pd.concat(all_results, ignore_index=True)
    out.to_csv(f"{args.out_prefix}_by_sequence.csv", index=False)

    summary = (
        out.groupby(["rare_mode", "model"], as_index=False)
        .agg(
            n=("row_id", "count"),
            cai_own=("cai_own", "mean"),
            cai_wrong_mean=("cai_wrong_mean", "mean"),
            ratio_cai_own_over_wrong=("ratio_cai_own_over_wrong", "mean"),
            delta_log_cai_own_minus_wrong=("delta_log_cai_own_minus_wrong", "mean"),
            missing_weight_frac=("missing_weight_frac", "mean"),
        )
    )
    summary.to_csv(f"{args.out_prefix}_summary_by_model.csv", index=False)

    print("\n=== SUMMARY ===")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
