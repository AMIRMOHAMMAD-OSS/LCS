__version__ = "0.0.0"
class DeepSpeedEngine:
    pass
