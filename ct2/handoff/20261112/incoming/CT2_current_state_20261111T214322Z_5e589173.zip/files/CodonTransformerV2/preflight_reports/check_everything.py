import os, json, glob, importlib, traceback
from pathlib import Path

print("=== BASIC ===")
print("cwd:", os.getcwd())
print("python:", os.sys.executable)
print("python version:", os.sys.version)

print("\n=== PACKAGE IMPORTS ===")
mods = [
    "torch",
    "transformers",
    "tokenizers",
    "webdataset",
    "pytorch_lightning",
    "codontransformer2",
    "codontransformer2.dataset.collators",
    "codontransformer2.dataset.constants",
]
for m in mods:
    try:
        mod = importlib.import_module(m)
        print("[OK]", m, getattr(mod, "__version__", ""))
    except Exception as e:
        print("[FAIL]", m, repr(e))
        traceback.print_exc()

print("\n=== MODERNBERT CHECK ===")
try:
    import transformers
    print("transformers:", transformers.__version__)
    names = dir(transformers)
    hits = [x for x in names if "Modern" in x or "modern" in x]
    print("ModernBERT-related names:", hits[:50])
    from transformers import AutoConfig, AutoModelForMaskedLM
    print("[OK] AutoConfig / AutoModelForMaskedLM import")
except Exception as e:
    print("[FAIL] ModernBERT check:", repr(e))
    traceback.print_exc()

print("\n=== TOKENIZER CHECK ===")
try:
    from transformers import PreTrainedTokenizerFast
    tok_path = "CodonTransformerTokenizer.json"
    tok = PreTrainedTokenizerFast(tokenizer_file=tok_path)
    print("[OK] tokenizer loaded:", tok_path)
    print("vocab size:", len(tok))
    print("pad:", tok.pad_token, tok.pad_token_id)
    print("mask:", tok.mask_token, tok.mask_token_id)
    print("all special ids:", tok.all_special_ids)
    out = tok(["ATG GAA TTT TAA"], return_tensors="pt", padding=True)
    print("sample input_ids:", out["input_ids"])
except Exception as e:
    print("[FAIL] tokenizer:", repr(e))
    traceback.print_exc()

print("\n=== COLLATOR CHECK ===")
try:
    from transformers import PreTrainedTokenizerFast
    from codontransformer2.dataset.collators import MaskedTokenizerCollator

    tok = PreTrainedTokenizerFast(tokenizer_file="CodonTransformerTokenizer.json")

    species_to_id = None
    if Path("species_to_id.json").exists():
        with open("species_to_id.json") as f:
            species_to_id = json.load(f)
        print("species_to_id loaded:", len(species_to_id))

    collator = MaskedTokenizerCollator(
        tok,
        species_to_id=species_to_id,
        unknown_species_id=0,
        max_species_id=len(species_to_id) if species_to_id else None,
        species_dropout_prob=0.0,
        mlm_probability=0.15,
    )

    examples = [
        {"json": json.dumps({"dna_sequence": "ATGGAATTTTAA", "species": next(iter(species_to_id)) if species_to_id else "0"}).encode()},
        {"json": json.dumps({"seq": "ATGCCCGGGAAA", "species": "unknown_species"}).encode()},
    ]

    batch = collator(examples)
    print("[OK] collator output keys:", batch.keys())
    for k, v in batch.items():
        try:
            print(k, tuple(v.shape), v.dtype)
        except Exception:
            print(k, type(v))
    print("input_ids:", batch["input_ids"])
    print("labels:", batch["labels"])
    print("species_id:", batch["species_id"])
except Exception as e:
    print("[FAIL] collator:", repr(e))
    traceback.print_exc()

print("\n=== DATASET CANDIDATES ===")
roots = [
    "/lustre/fswork/projects/rech/nef/unh87ms",
    "/lustre/fsn1/projects/rech/nef/unh87ms",
]
patterns = ["*.tar", "*.jsonl", "*.jsonl.gz", "*.parquet"]
for root in roots:
    for pat in patterns:
        files = glob.glob(os.path.join(root, "**", pat), recursive=True)
        print(root, pat, "count:", len(files))
        for x in files[:20]:
            print(" ", x)

print("\n=== TRAIN HELP ===")
for script in ["train.py", "train_updated.py"]:
    print("\n---", script, "--help ---")
    os.system(f"python {script} --help")
