import time
from pathlib import Path

import pandas as pd
import torch
from transformers import AutoTokenizer, BigBirdForMaskedLM
from CodonTransformer.CodonPrediction import predict_dna_sequence


IN_CSV = Path("ct1_ct2_overlap_benchmark_clean.csv")
OUT_CSV = Path("ct1_overlap_predictions.csv")
ERR_CSV = Path("ct1_overlap_errors.csv")

df = pd.read_csv(IN_CSV)

done_ids = set()
if OUT_CSV.exists():
    old = pd.read_csv(OUT_CSV)
    if "row_id" in old.columns:
        done_ids = set(old["row_id"].astype(int).tolist())
        print(f"Resuming: already completed {len(done_ids)} rows")

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("device =", device)

print("Loading CT1 tokenizer/model...")
tokenizer = AutoTokenizer.from_pretrained("adibvafa/CodonTransformer", local_files_only=True)
model = BigBirdForMaskedLM.from_pretrained("adibvafa/CodonTransformer", local_files_only=True).to(device)
model.eval()
print("loaded")

out_exists = OUT_CSV.exists()
err_exists = ERR_CSV.exists()

pred_rows = []
err_rows = []

start = time.time()

for row_id, row in df.iterrows():
    if row_id in done_ids:
        continue

    protein = str(row["protein_sequence"])
    organism = str(row["ct1_organism"])

    try:
        with torch.no_grad():
            pred = predict_dna_sequence(
                protein=protein,
                organism=organism,
                device=device,
                tokenizer=tokenizer,
                model=model,
                attention_type="original_full",
                deterministic=True,
                match_protein=True,
            )

        dna = getattr(pred, "predicted_dna", None)
        if dna is None:
            dna = getattr(pred, "dna_sequence", None)
        if dna is None:
            dna = getattr(pred, "dna", None)

        pred_rows.append({
            "row_id": row_id,
            "genome_id": row["genome_id"],
            "species": row["species"],
            "ct1_organism": organism,
            "protein_id": row["protein_id"],
            "protein_len": len(protein),
            "true_dna_len": len(str(row["dna_sequence"])),
            "ct1_pred_dna_len": len(dna) if dna else -1,
            "true_dna": row["dna_sequence"],
            "ct1_pred_dna": dna,
        })

    except Exception as e:
        err_rows.append({
            "row_id": row_id,
            "genome_id": row.get("genome_id", ""),
            "species": row.get("species", ""),
            "ct1_organism": organism,
            "protein_id": row.get("protein_id", ""),
            "error": repr(e),
        })

    if len(pred_rows) >= 25:
        pd.DataFrame(pred_rows).to_csv(
            OUT_CSV,
            mode="a",
            header=not out_exists,
            index=False,
        )
        out_exists = True
        pred_rows = []

    if len(err_rows) >= 10:
        pd.DataFrame(err_rows).to_csv(
            ERR_CSV,
            mode="a",
            header=not err_exists,
            index=False,
        )
        err_exists = True
        err_rows = []

    if (row_id + 1) % 50 == 0:
        elapsed = time.time() - start
        print(f"processed row_id={row_id+1}/{len(df)} elapsed_min={elapsed/60:.1f}", flush=True)

if pred_rows:
    pd.DataFrame(pred_rows).to_csv(
        OUT_CSV,
        mode="a",
        header=not out_exists,
        index=False,
    )

if err_rows:
    pd.DataFrame(err_rows).to_csv(
        ERR_CSV,
        mode="a",
        header=not err_exists,
        index=False,
    )

print("DONE")
print("output =", OUT_CSV)
print("errors =", ERR_CSV)
