import argparse
import glob
import json
import math
import multiprocessing as mp
import tarfile
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

GENETIC_CODE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

G_CSI_WEIGHTS = None

def clean_dna(x):
    if x is None:
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")

def clean_protein(x):
    if x is None:
        return ""
    return str(x).strip().upper().rstrip("*_")

def iter_codons(seq):
    seq = clean_dna(seq)
    for i in range(0, len(seq) - 2, 3):
        codon = seq[i:i+3]
        if len(codon) != 3 or any(c not in "ACGT" for c in codon):
            continue
        aa = GENETIC_CODE.get(codon)
        if aa is None or aa == "*":
            continue
        yield aa, codon

def read_records_from_shard(path):
    with tarfile.open(path, "r:gz") as tar:
        for member in tar:
            if not member.isfile():
                continue
            if not member.name.endswith((".json", ".jsonl")):
                continue
            f = tar.extractfile(member)
            if f is None:
                continue
            raw = f.read().decode("utf-8", errors="replace").strip()
            if not raw:
                continue
            if member.name.endswith(".jsonl"):
                for line in raw.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        yield json.loads(line)
                    except Exception:
                        continue
            else:
                try:
                    obj = json.loads(raw)
                except Exception:
                    continue
                if isinstance(obj, list):
                    for x in obj:
                        yield x
                else:
                    yield obj

def normalize_record(rec):
    if not isinstance(rec, dict):
        return None
    species = rec.get("species")
    genome_id = rec.get("genome_id", "")
    protein_id = rec.get("protein_id", "")
    dna = rec.get("dna_sequence")
    protein = rec.get("protein_sequence")
    if species is None or dna is None or protein is None:
        return None
    dna = clean_dna(dna)
    protein = clean_protein(protein)
    if not dna or not protein:
        return None
    need = 3 * len(protein)
    if len(dna) < need:
        return None
    return str(species), str(genome_id), str(protein_id), dna[:need], len(protein)

def build_formal_csi_weights(codon_table):
    freq = pd.read_parquet(codon_table)
    freq["species"] = freq["species"].astype(str)
    print(f"codon table rows: {len(freq)}, species: {freq['species'].nunique()}", flush=True)

    max_freq = (
        freq.groupby(["species", "aa"], as_index=False)["frequency"]
        .max()
        .rename(columns={"frequency": "max_frequency"})
    )
    use = freq.merge(max_freq, on=["species", "aa"], how="left")
    use["weight"] = use["frequency"] / use["max_frequency"]

    weights = {}
    for r in tqdm(use.itertuples(index=False), total=len(use), desc="building CSI weights"):
        weights[(str(r.species), str(r.aa), str(r.codon))] = float(r.weight)
    return weights

def geomean_weight(seq, species, weights):
    logs = []
    total = 0
    missing = 0
    for aa, codon in iter_codons(seq):
        total += 1
        w = weights.get((species, aa, codon))
        if w is None or w <= 0:
            missing += 1
            continue
        logs.append(math.log(w))
    if not logs:
        return np.nan, total, missing
    return float(math.exp(sum(logs) / len(logs))), total, missing

def init_worker(csi_weights):
    global G_CSI_WEIGHTS
    G_CSI_WEIGHTS = csi_weights

def process_shard(spath):
    rows = []
    seen = 0
    kept = 0
    for rec in read_records_from_shard(spath):
        seen += 1
        norm = normalize_record(rec)
        if norm is None:
            continue
        species, genome_id, protein_id, dna, protein_len = norm
        csi, total, missing = geomean_weight(dna, species, G_CSI_WEIGHTS)
        if pd.isna(csi):
            continue
        rows.append({
            "species": species,
            "genome_id": genome_id,
            "protein_id": protein_id,
            "dna": dna,
            "protein_len": protein_len,
            "formal_csi": csi,
            "codons_total": total,
            "missing_weight_frac": missing / max(total, 1),
        })
        kept += 1
    return rows, seen, kept

def score_batches(shards, csi_weights, cache_dir, shards_per_batch, workers, chunksize):
    cache_dir.mkdir(parents=True, exist_ok=True)
    columns = ["species", "genome_id", "protein_id", "dna", "protein_len",
               "formal_csi", "codons_total", "missing_weight_frac"]
    n_batches = math.ceil(len(shards) / shards_per_batch)

    for b in range(n_batches):
        start = b * shards_per_batch
        end = min((b + 1) * shards_per_batch, len(shards))
        out = cache_dir / f"all_species_topcsi_batch_{b:04d}.parquet"

        if out.exists():
            print(f"batch {b+1}/{n_batches}: exists, skipping", flush=True)
            continue

        batch_shards = shards[start:end]
        rows = []
        total_seen = 0
        total_kept = 0

        print(f"\n=== batch {b+1}/{n_batches} shards {start}:{end} workers={workers} ===", flush=True)

        with mp.Pool(processes=workers, initializer=init_worker, initargs=(csi_weights,)) as pool:
            for shard_rows, seen, kept in tqdm(
                pool.imap_unordered(process_shard, batch_shards, chunksize=chunksize),
                total=len(batch_shards),
                desc=f"batch {b+1}/{n_batches}",
            ):
                rows.extend(shard_rows)
                total_seen += seen
                total_kept += kept

        df = pd.DataFrame(rows, columns=columns)
        df.to_parquet(out, index=False)
        print(f"wrote {out} rows={len(df)} seen={total_seen} kept={total_kept}", flush=True)

def load_scored(cache_dir):
    files = sorted(cache_dir.glob("all_species_topcsi_batch_*.parquet"))
    if not files:
        raise SystemExit(f"No cache files in {cache_dir}")
    dfs = [pd.read_parquet(f) for f in files]
    return pd.concat([d for d in dfs if len(d)], ignore_index=True)

def select_top(scored, top_frac, min_genes_per_species):
    selected = []
    for species, g in scored.groupby("species", sort=False):
        if len(g) < min_genes_per_species:
            continue
        g = g.sort_values("formal_csi", ascending=False)
        n_top = max(1, int(math.ceil(top_frac * len(g))))
        selected.append(g.head(n_top))
    if not selected:
        raise SystemExit("No species passed min_genes_per_species filter")
    return pd.concat(selected, ignore_index=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--shard_glob", required=True)
    ap.add_argument("--out_prefix", required=True)
    ap.add_argument("--shards_per_batch", type=int, default=250)
    ap.add_argument("--top_frac", type=float, default=0.10)
    ap.add_argument("--min_genes_per_species", type=int, default=10)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--chunksize", type=int, default=4)
    args = ap.parse_args()

    shards = sorted(glob.glob(args.shard_glob))
    print(f"shards: {len(shards)}", flush=True)
    if not shards:
        raise SystemExit("No shards matched")

    csi_weights = build_formal_csi_weights(args.codon_table)

    cache_dir = Path(f"{args.out_prefix}_cache")
    score_batches(shards, csi_weights, cache_dir,
                  args.shards_per_batch, args.workers, args.chunksize)

    scored = load_scored(cache_dir)
    scored.to_parquet(f"{args.out_prefix}_all_train_genes_scored.parquet", index=False)
    print(f"scored: {len(scored)} genes across {scored['species'].nunique()} species", flush=True)

    top_ref = select_top(scored, args.top_frac, args.min_genes_per_species)
    top_ref.to_parquet(f"{args.out_prefix}_top10csi_all_species_reference.parquet", index=False)

    summary = (
        top_ref.groupby("species", as_index=False)
        .agg(top_ref_genes=("dna", "count"),
             mean_ref_csi=("formal_csi", "mean"),
             mean_ref_len=("protein_len", "mean"))
    )
    summary.to_csv(f"{args.out_prefix}_top10csi_all_species_summary.csv", index=False)

    print(f"\ntop reference: {len(top_ref)} genes across {top_ref['species'].nunique()} species", flush=True)
    print(f"min/median/max genes per species: {summary['top_ref_genes'].min()} / {summary['top_ref_genes'].median():.0f} / {summary['top_ref_genes'].max()}", flush=True)

if __name__ == "__main__":
    main()
