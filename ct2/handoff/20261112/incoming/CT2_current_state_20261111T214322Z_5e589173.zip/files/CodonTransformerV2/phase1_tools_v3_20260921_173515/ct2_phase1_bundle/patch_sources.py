"""Small, guarded transformations of the three reviewed CT2 source files."""
from __future__ import annotations
import ast
import hashlib


def ast_hash(text):
    return hashlib.sha256(ast.dump(ast.parse(text), include_attributes=False).encode()).hexdigest()


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError(f"Patch anchor is not unique: {old[:100]!r}")
    return text.replace(old, new, 1)


def patch_trainer(text):
    text = replace_once(text,
        "from codontransformer2.dataset.collators import MaskedTokenizerCollator",
        "from phase1_support import (CheckedCollator as MaskedTokenizerCollator, FixedEvalCollator, "
        "FixedEvalDataset, Phase1Diagnostics, validate_species_mapping, RecordFilter)")
    text = replace_once(text, "    pin_memory = bool(args.pin_memory and torch.cuda.is_available())",
        "    train_data = train_data.select(RecordFilter(\n"
        "        collator.vocab, species_to_id, unknown_species_id,\n"
        "        Path(args.checkpoint_dir) / 'data_audit', args.train_max_length,\n"
        "    ))\n\n"
        "    pin_memory = bool(args.pin_memory and torch.cuda.is_available())")
    text = replace_once(text, "    species_to_id = load_species_to_id(species_to_id_path)",
        "    species_to_id = load_species_to_id(species_to_id_path)\n"
        "    validate_species_mapping(species_to_id, n_real_species, unknown_species_id)")
    text = replace_once(text, "    eval_collator = MaskedTokenizerCollator(", "    eval_collator = FixedEvalCollator(")
    text = replace_once(text, "        test_ds = OrganismPerJSONGenesDataset(args.test_json_dir)",
        "        test_ds = FixedEvalDataset(args.eval_panel)\n"
        "        expected_batches = len(test_ds) // (args.test_batch_size or args.batch_size)\n"
        "        if len(test_ds) % (args.test_batch_size or args.batch_size) or args.limit_test_batches != expected_batches:\n"
        "            raise ValueError('Evaluate the entire fixed panel with equal full batches on all ranks.')")
    text = replace_once(text, "    callbacks: List[pl.Callback] = []", 
        "    callbacks: List[pl.Callback] = [Phase1Diagnostics(args.limit_train_batches, args.stop_after_first_epoch)]")
    text = replace_once(text, "    callbacks.append(EpochCheckpoint(args.save_interval, args.checkpoint_dir))",
        "    callbacks.append(pl.callbacks.ModelCheckpoint(\n"
        "        dirpath=args.checkpoint_dir, filename='epoch_{epoch}', auto_insert_metric_name=False,\n"
        "        every_n_epochs=1, save_top_k=-1, save_last=True, save_on_train_epoch_end=True,\n"
        "    ))")
    text = replace_once(text, "        enable_checkpointing=True,", 
        "        enable_checkpointing=True,\n        num_sanity_val_steps=0,")
    text = replace_once(text, "ckpt = torch.load(args.init_from_checkpoint, map_location=\"cpu\")",
        "ckpt = torch.load(args.init_from_checkpoint, map_location=\"cpu\", weights_only=False)")
    text = replace_once(text, 'ALLOWED = ("species_embed", "codon_id_to_aa_id")', 'ALLOWED = ("codon_id_to_aa_id",)')
    text = replace_once(text, "    def training_step(self, batch, batch_idx):\n", 
        "    def training_step(self, batch, batch_idx):\n"
        "        if batch['input_ids'].numel() == 0 or not batch['labels'].ne(-100).any():\n"
        "            raise ValueError('Empty training batch or zero prediction targets.')\n")
    text = replace_once(text, "        self.log_dict(\n            {\"loss\": out.loss, \"lr\": self._get_lr()},", 
        "        if not torch.isfinite(out.loss):\n"
        "            raise FloatingPointError('Nonfinite training loss; aborting all ranks via srun.')\n"
        "        self.log_dict(\n            {\"loss\": out.loss, \"lr\": self._get_lr()},")
    clip = '''    def configure_gradient_clipping(self, optimizer, gradient_clip_val=None, gradient_clip_algorithm=None):
        if getattr(gradient_clip_algorithm, "value", gradient_clip_algorithm) not in (None, "norm"):
            raise ValueError("Phase 1 requires norm clipping.")
        params = [p for group in optimizer.param_groups for p in group["params"] if p.grad is not None]
        norm = torch.nn.utils.clip_grad_norm_(params, float(gradient_clip_val), error_if_nonfinite=True)
        self.log("grad_norm_preclip", norm.detach(), on_step=True, on_epoch=False, prog_bar=True, sync_dist=False)
        if self.global_rank == 0 and self.global_step % self.trainer.log_every_n_steps == 0:
            print("PHASE1_GRAD", self.global_step, float(norm), flush=True)

'''
    text = replace_once(text, "    def on_validation_start(self):", clip + "    def on_validation_start(self):")
    start = text.index("    @torch.no_grad()\n    def validation_step")
    end = text.index("    def configure_optimizers(self):", start)
    text = text[:start] + '''    @torch.no_grad()
    def validation_step(self, batch, batch_idx):
        n_targets = int(batch["labels"].ne(-100).sum())
        if n_targets <= 0:
            raise ValueError("Evaluation batch has zero prediction targets.")
        # Every selected label must be a codon with a valid amino-acid mapping.
        selected_labels = batch["labels"][batch["labels"].ne(-100)]
        if (self.codon_id_to_aa_id[selected_labels] < 0).any():
            raise ValueError("Evaluation contains supervised tokens absent from TOKEN2MASK.")
        m = evaluate_mlm_batch(
            model=self.model, species_embed=self.species_embed, batch=batch,
            topk=self.hparams.eval_topk, codon_id_to_aa_id=self.codon_id_to_aa_id,
            synonym_topk=self.hparams.synonym_topk, prefix="test",
            species_embed_scale=self.hparams.species_embed_scale,
        )
        # Lightning reduces weighted sums and counts across batches and ranks.
        self.log_dict(m, on_step=False, on_epoch=True, prog_bar=True,
                      sync_dist=True, batch_size=n_targets)
        ab = evaluate_species_ablations(
            model=self.model, species_embed=self.species_embed, batch=batch,
            unknown_species_id=self.hparams.unknown_species_id,
            topk=self.hparams.eval_topk, prefix="test",
            species_embed_scale=self.hparams.species_embed_scale,
        )
        self.log_dict(ab, on_step=False, on_epoch=True, prog_bar=False,
                      sync_dist=True, batch_size=n_targets)

''' + text[end:]
    text = replace_once(text, '            print(f"\\nCheckpoint saved: {path}\\n")',
        '            if trainer.is_global_zero:\n                print(f"\\nCheckpoint saved: {path}\\n", flush=True)')
    text = replace_once(text, '    p.add_argument("--test_json_dir", type=str, default=None,',
        '    p.add_argument("--eval_panel", type=str, required=True)\n'
        '    p.add_argument("--stop_after_first_epoch", action="store_true")\n'
        '    p.add_argument("--test_json_dir", type=str, default=None,')
    ast.parse(text)
    return text


def patch_eval(text):
    text = text.replace(".to(logits.dtype)", ".float()")
    text = replace_once(text, "        logits.view(B * L, V),", "        logits.float().reshape(B * L, V),")
    old = '''    n_species = int(species_embed.num_embeddings)
    off = torch.randint(1, n_species, (B,), device=device)
    wrong_ids = (batch["species_id"] + off) % n_species'''
    new = '''    n_species = int(unknown_species_id)  # real IDs only; reserved slots are not organisms
    if n_species < 2:
        raise ValueError("Need at least two real species for ablations.")
    if "wrong_species_id" in batch:
        wrong_ids = batch["wrong_species_id"]
    else:
        # With no fixed panel, still sample only real IDs and exclude each known true ID.
        true_ids = batch["species_id"]
        known = (true_ids >= 0) & (true_ids < n_species)
        candidate = torch.randint(0, n_species - 1, (B,), device=device)
        different = candidate + (candidate >= true_ids).long()
        fallback = torch.randint(0, n_species, (B,), device=device)
        wrong_ids = torch.where(known, different, fallback)
    if ((wrong_ids < 0) | (wrong_ids >= n_species) | (wrong_ids == batch["species_id"])).any():
        raise ValueError("Invalid wrong-species assignment.")'''
    text = replace_once(text, old, new)
    ast.parse(text)
    return text
