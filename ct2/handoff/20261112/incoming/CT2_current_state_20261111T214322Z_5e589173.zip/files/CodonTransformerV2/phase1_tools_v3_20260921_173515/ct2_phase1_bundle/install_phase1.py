#!/usr/bin/env python3
"""Create a reviewed, isolated CT2 Phase-1 source snapshot. Does not submit jobs."""
from __future__ import annotations
import argparse
import ast
import difflib
import json
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from patch_sources import ast_hash, patch_eval, patch_trainer
from phase1_common import config_fingerprint, file_sha
from phase1_tokens import TOKEN_POLICY

DEFAULT_ROOT = "/lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2"
DEFAULT_DATA = "/lustre/fswork/projects/rech/nef/unh87ms/codon_project/data/CT2_data/training_shards_webdataset"
DEFAULT_INIT = "/lustre/fswork/projects/rech/nef/unh87ms/ct2_retrain/stage1_bs192_len512_lr15e4/epoch_1.ckpt"
DEFAULT_OUTPUT_PARENT = "/lustre/fswork/projects/rech/nef/unh87ms/ct2_retrain"
RUNTIME_FILES = ["phase1_support.py", "phase1_common.py", "phase1_prepare.py", "phase1_launch.py", "test_phase1.py", "submit_phase1.py", "phase1_tokens.py", "precheck_phase1.py", "test_phase1_tokens.py", "phase1_records.py", "phase1_panel.py", "strict_generation.py", "regression_examples.json"]


def slurm_text(run, preflight):
    name = "ct2_p1_check" if preflight else "ct2_p1_final"
    prefix = "preflight" if preflight else "train"
    duration = "01:00:00" if preflight else "20:00:00"
    body = """python -u precheck_phase1.py
python -u phase1_prepare.py
python -u test_phase1.py
srun --kill-on-bad-exit=1 python -u phase1_launch.py --mode smoke-first
srun --kill-on-bad-exit=1 python -u phase1_launch.py --mode smoke-resume
python -u phase1_prepare.py --stamp
""" if preflight else """srun --kill-on-bad-exit=1 python -u phase1_launch.py --mode full "$@"
"""
    return f"""#!/bin/bash
#SBATCH --job-name={name}
#SBATCH -A nef@h100
#SBATCH --partition=gpu_p6
#SBATCH -C h100
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=4
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=8
#SBATCH --time={duration}
#SBATCH --hint=nomultithread
#SBATCH --chdir={run}
#SBATCH --output={run}/logs/{prefix}_%j.out
#SBATCH --error={run}/logs/{prefix}_%j.err
set -euo pipefail
cd '{run}'
exec 9> '.{prefix}.lock'
flock -n 9 || {{ echo 'Another {prefix} job for this run is active.' >&2; exit 75; }}
module purge
module load arch/h100
module load pytorch-gpu/py3/2.6.0
export PYTHONPATH="$PWD${{PYTHONPATH:+:$PYTHONPATH}}"
export PYTHONUNBUFFERED=1
export TOKENIZERS_PARALLELISM=false
export OMP_NUM_THREADS=8
export XDG_CACHE_HOME=/lustre/fsn1/projects/rech/nef/unh87ms/.cache
export HF_HOME=/lustre/fsn1/projects/rech/nef/unh87ms/huggingface
export TORCH_HOME=/lustre/fsn1/projects/rech/nef/unh87ms/torch
export TMPDIR=/tmp
mkdir -p "$XDG_CACHE_HOME" "$HF_HOME" "$TORCH_HOME"
{body}"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=DEFAULT_ROOT)
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--data-root", default=DEFAULT_DATA)
    parser.add_argument("--init", default=DEFAULT_INIT)
    parser.add_argument("--output-parent", default=DEFAULT_OUTPUT_PARENT)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parent
    root, run, data = Path(args.root).resolve(), Path(args.run_dir).resolve(), Path(args.data_root).resolve()
    init = Path(args.init).resolve()
    if not re.fullmatch(r"phase1_final_[0-9]{8}_[0-9]{6}", run.name):
        parser.error("Run directory name must be phase1_final_YYYYMMDD_HHMMSS.")
    if run.parent != root / "phase1_runs":
        parser.error("--run-dir must be directly inside ROOT/phase1_runs/.")
    for path in (root, run, data, init, Path(args.output_parent)):
        if re.search(r"[^A-Za-z0-9_./-]", str(path)):
            parser.error("Paths must contain only letters, digits, underscores, dots, hyphens and slashes.")
    if run.exists():
        raise FileExistsError(f"Run already exists; it will not be overwritten: {run}")
    output = Path(args.output_parent).resolve() / run.name
    if output.exists():
        raise FileExistsError(f"Output directory already exists: {output}")
    expected = json.loads((bundle / "reviewed_sources.json").read_text())
    sources = {}
    for relative, expected_hash in expected.items():
        source = (root / relative).read_text()
        if ast_hash(source) != expected_hash:
            raise RuntimeError(f"Source differs from the reviewed upload: {relative}. Stop and share the current file; no installation was made.")
        sources[relative] = source
    required = [init, root / "CodonTransformerTokenizer.json", data / "species_to_id.json", data / "test_sets_by_organism"]
    for path in required:
        if not path.exists():
            raise FileNotFoundError(path)
    missing_shards = [str(data / f"shard-{i:06d}.tar.gz") for i in range(5874) if not (data / f"shard-{i:06d}.tar.gz").is_file()]
    if missing_shards:
        raise FileNotFoundError(f"Missing training shards (first ten): {missing_shards[:10]}")
    patched = {
        "train_phase1_final.py": patch_trainer(sources["train_updated_curriculum.py"]),
        "codontransformer2/eval/CT2_eval.py": patch_eval(sources["codontransformer2/eval/CT2_eval.py"]),
    }
    for source in patched.values():
        ast.parse(source)
    print("SOURCE_AND_PATH_CHECKS_PASSED", flush=True)
    print("Initialization checkpoint:", init)
    print("New run directory:", run)
    print("New output directory:", output)
    if args.check_only:
        return

    run.mkdir(parents=True, exist_ok=False)
    (run / "logs").mkdir()
    shutil.copytree(root / "codontransformer2", run / "codontransformer2",
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.ckpt", "*.pt", ".git"))
    shutil.copy2(root / "CodonTransformerTokenizer.json", run / "CodonTransformerTokenizer.json")
    for relative, source in sources.items():
        backup = run / "originals" / relative
        backup.parent.mkdir(parents=True, exist_ok=True)
        backup.write_text(source)
    for relative, source in patched.items():
        (run / relative).write_text(source)
    for filename in RUNTIME_FILES:
        shutil.copy2(bundle / filename, run / filename)
    diff = []
    for old, new in (("train_updated_curriculum.py", "train_phase1_final.py"),
                     ("codontransformer2/eval/CT2_eval.py", "codontransformer2/eval/CT2_eval.py")):
        diff.extend(difflib.unified_diff(sources[old].splitlines(True), patched[new].splitlines(True), fromfile="original/" + old, tofile="final/" + new))
    (run / "changes.diff").write_text("".join(diff))
    stat = init.stat()
    config = {
        "created_utc": datetime.now(timezone.utc).isoformat(), "source_root": str(root),
        "data_root": str(data), "species_mapping": str(data / "species_to_id.json"),
        "species_mapping_sha256": file_sha(data / "species_to_id.json"),
        "test_json_dir": str(data / "test_sets_by_organism"), "init_checkpoint": str(init),
        "init_size": stat.st_size, "init_mtime_ns": stat.st_mtime_ns, "output_dir": str(output),
        "num_organisms": 26678, "extra_organisms": 2000, "unknown_species_id": 26678,
        "seed": 123, "eval_species": 1024, "eval_genes_per_species": 4,
        "bundle_version": "3-protein-preserving", "token_policy": TOKEN_POLICY,
    }
    for preflight in (True, False):
        path = run / ("preflight.slurm" if preflight else "train.slurm")
        path.write_text(slurm_text(run, preflight))
        subprocess.run(["bash", "-n", str(path)], check=True)
    code_paths = [run / name for name in RUNTIME_FILES] + [run / "train_phase1_final.py", run / "CodonTransformerTokenizer.json"]
    code_paths += list((run / "codontransformer2").rglob("*.py"))
    code_paths += [run / "preflight.slurm", run / "train.slurm"]
    config["code_hashes"] = {str(path.relative_to(run)): file_sha(path) for path in sorted(set(code_paths))}
    config["fingerprint"] = config_fingerprint(config)
    (run / "run_config.json").write_text(json.dumps(config, indent=2, sort_keys=True) + "\n")
    print("INSTALLATION_COMPLETE", run, flush=True)
    print("Original source and checkpoints were preserved. No Slurm job has been submitted.", flush=True)


if __name__ == "__main__":
    main()
