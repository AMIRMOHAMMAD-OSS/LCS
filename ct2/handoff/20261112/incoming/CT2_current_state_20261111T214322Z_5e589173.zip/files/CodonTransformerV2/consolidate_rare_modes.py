"""
Consolidate per-rare-mode summary CSVs and verify rare_mode='all' reproduces
the existing unfiltered numbers. The verification step is the trust anchor.
"""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


COMMON_PREFIX = "ct1_vs_ct2_all_trunc2046_common_valid"

SPECS = [
    {
        "name": "CSI own/wrong",
        "new_prefix":    f"formal_csi_own_wrong_{COMMON_PREFIX}",
        "old_summary":   f"formal_csi_own_wrong_{COMMON_PREFIX}_summary_by_model.csv",
        "out_summary":   f"formal_csi_own_wrong_{COMMON_PREFIX}_summary_by_model_RARE.csv",
        "check_cols": [
            "formal_csi_own",
            "formal_csi_wrong_mean",
            "ratio_formal_csi_own_over_wrong",
            "delta_log_formal_csi_own_minus_wrong",
        ],
    },
    {
        "name": "CSI rank",
        "new_prefix":    f"formal_csi_rank_{COMMON_PREFIX}",
        "old_summary":   f"formal_csi_rank_{COMMON_PREFIX}_summary_by_model.csv",
        "out_summary":   f"formal_csi_rank_{COMMON_PREFIX}_summary_by_model_RARE.csv",
        "check_cols": [
            "mean_true_rank",
            "median_true_rank",
            "top1_rate",
            "top5_rate",
            "top10_rate",
            "top100_rate",
            "mean_reciprocal_rank",
        ],
    },
    {
        "name": "CAI",
        "new_prefix":    f"cai_top10csi_train_w8_{COMMON_PREFIX}",
        "old_summary":   f"cai_top10csi_train_w8_{COMMON_PREFIX}_summary_by_model.csv",
        "out_summary":   f"cai_top10csi_train_w8_{COMMON_PREFIX}_summary_by_model_RARE.csv",
        "check_cols": [
            "cai_top10csi_train",
        ],
    },
]


def verify_all_matches_existing(new_all_df, old_df, check_cols, name, tol):
    merged = new_all_df.merge(old_df, on="model", suffixes=("_new", "_old"), how="outer", indicator=True)
    if (merged["_merge"] != "both").any():
        rows = merged[merged["_merge"] != "both"][["model", "_merge"]]
        print(f"  [{name}] MODEL MISMATCH between new (rare_mode=all) and existing summary:")
        print(rows.to_string(index=False))
        return False, None

    all_ok = True
    diffs = []
    for col in check_cols:
        col_new, col_old = f"{col}_new", f"{col}_old"
        if col_new not in merged.columns or col_old not in merged.columns:
            print(f"  [{name}] missing column {col} in one of the summaries; skipping check.")
            continue
        d = (merged[col_new] - merged[col_old]).abs()
        d_max = float(np.nanmax(d.values)) if len(d) else 0.0
        diffs.append((col, d_max))
        if d_max > tol:
            worst = merged.loc[d.idxmax(), ["model", col_new, col_old]]
            print(f"  [{name}] {col}: max abs diff {d_max:.6g} > tol {tol:.0e}. Worst row: {worst.to_dict()}")
            all_ok = False
    return all_ok, diffs


def consolidate_metric(spec, tol):
    name = spec["name"]
    print(f"\n=== {name} ===")

    summaries = []
    for rare in ["all", "no_rare_0_001", "no_rare_0_01"]:
        p = Path(f"{spec['new_prefix']}_{rare}_summary_by_model.csv")
        if not p.exists():
            raise SystemExit(f"  Missing summary file: {p}")
        df = pd.read_csv(p)
        if "rare_mode" not in df.columns:
            df["rare_mode"] = rare
        summaries.append(df)
        print(f"  loaded {p}: rows={len(df)}")

    new_all = summaries[0]

    old_summary_path = Path(spec["old_summary"])
    if not old_summary_path.exists():
        print(f"  WARNING: existing summary {old_summary_path} not found; skipping verification.")
        ok = True
    else:
        old_df = pd.read_csv(old_summary_path)
        ok, _ = verify_all_matches_existing(
            new_all_df=new_all, old_df=old_df,
            check_cols=spec["check_cols"], name=name, tol=tol,
        )

    if not ok:
        print(f"  [{name}] CONSISTENCY CHECK FAILED. Aborting consolidation for this metric.")
        return False

    print(f"  [{name}] consistency check passed (rare_mode=all reproduces existing summary).")

    combined = pd.concat(summaries, ignore_index=True)
    cols = ["rare_mode"] + [c for c in combined.columns if c != "rare_mode"]
    combined = combined[cols]

    out = Path(spec["out_summary"])
    combined.to_csv(out, index=False)
    print(f"  wrote {out}: rows={len(combined)}")
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tol", type=float, default=1e-5)
    args = ap.parse_args()

    print("Consolidating per-rare-mode summaries with consistency check.")
    print(f"Tolerance: {args.tol}")

    overall_ok = True
    for spec in SPECS:
        ok = consolidate_metric(spec, args.tol)
        overall_ok = overall_ok and ok

    if overall_ok:
        print("\nALL METRIC FAMILIES CONSOLIDATED AND VERIFIED.")
    else:
        print("\nONE OR MORE METRIC FAMILIES FAILED VERIFICATION. See output above.")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
