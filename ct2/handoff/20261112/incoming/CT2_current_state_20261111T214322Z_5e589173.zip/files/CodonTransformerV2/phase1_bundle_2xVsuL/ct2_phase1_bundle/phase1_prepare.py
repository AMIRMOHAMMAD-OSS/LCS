from __future__ import annotations
import argparse
import json
import math
import os
import random
import sys
from datetime import datetime, timezone
from pathlib import Path

from phase1_common import file_sha, load_config, verify_panel


def make_panel(run, cfg):
    import torch
    import lightning.pytorch as pl
    import transformers
    import webdataset
    from transformers import PreTrainedTokenizerFast
    from phase1_support import CheckedCollator, stable_seed, validate_species_mapping

    print("PHASE1_ENVIRONMENT", json.dumps({
        "python": sys.executable, "torch": torch.__version__, "lightning": pl.__version__,
        "transformers": transformers.__version__, "webdataset": webdataset.__version__,
    }), flush=True)
    if (run / "eval_panel.jsonl").exists():
        _, meta = verify_panel(run, cfg)
        print("Using existing fixed evaluation panel:", meta, flush=True)
        return
    mapping = json.loads(Path(cfg["species_mapping"]).read_text())
    mapping = {str(k): int(v) for k, v in mapping.items()}
    validate_species_mapping(mapping, cfg["num_organisms"], cfg["unknown_species_id"])
    tokenizer = PreTrainedTokenizerFast(
        tokenizer_file=str(run / "CodonTransformerTokenizer.json"),
        bos_token="[CLS]", eos_token="[SEP]", unk_token="[UNK]", sep_token="[SEP]",
        pad_token="[PAD]", cls_token="[CLS]", mask_token="[MASK]",
    )
    collator = CheckedCollator(tokenizer, species_to_id=mapping,
        unknown_species_id=cfg["unknown_species_id"],
        max_species_id=cfg["num_organisms"] + cfg["extra_organisms"],
        mlm_probability=0.15, max_length=512)
    files = sorted(p for p in Path(cfg["test_json_dir"]).glob("*.json") if not p.name.startswith("._"))
    random.Random(cfg["seed"]).shuffle(files)
    selected = []
    seen_species = set()
    too_few_genes = 0
    for path in files:
        org = json.loads(path.read_text())
        sid = collator._to_species_id(org.get("species"))
        if sid in seen_species:
            continue
        genes = org.get("genes", [])
        if len(genes) < cfg["eval_genes_per_species"]:
            too_few_genes += 1
            continue
        indices = list(range(len(genes)))
        random.Random(stable_seed("genes:" + path.name)).shuffle(indices)
        for index in indices[:cfg["eval_genes_per_species"]]:
            gene = genes[index]
            record = {
                "species": org.get("species"), "genome_id": org.get("genome_id"),
                "protein_id": gene.get("protein_id"), "dna_sequence": gene.get("dna_sequence"),
                "protein_sequence": gene.get("protein_sequence"),
                "eval_key": f"{path.name}:{index}:{gene.get('protein_id', '')}",
            }
            try:
                collator([{"json": json.dumps(record).encode()}])
            except Exception as exc:
                raise RuntimeError(f"Evaluation-data preflight failed at {path}, gene index {index}: {exc}") from exc
            selected.append(record)
        seen_species.add(sid)
        if len(seen_species) == cfg["eval_species"]:
            break
    if len(seen_species) != cfg["eval_species"]:
        raise RuntimeError(f"Found only {len(seen_species)} distinct mapped species with enough genes.")
    # Interleave organisms in batches; the exact ordered records are now frozen.
    random.Random(cfg["seed"] + 1).shuffle(selected)
    panel = run / "eval_panel.jsonl"
    temp = panel.with_suffix(".tmp")
    temp.write_text("".join(json.dumps(row) + "\n" for row in selected))
    temp.replace(panel)
    meta = {
        "fingerprint": cfg["fingerprint"], "samples": len(selected),
        "distinct_species": len(seen_species), "genes_per_species": cfg["eval_genes_per_species"],
        "skipped_organisms_with_too_few_genes": too_few_genes,
        "sha256": file_sha(panel),
    }
    (run / "eval_panel_meta.json").write_text(json.dumps(meta, indent=2) + "\n")
    print("PHASE1_PANEL", json.dumps(meta, sort_keys=True), flush=True)


def stamp_preflight(run, cfg):
    import torch
    panel, meta = verify_panel(run, cfg)
    checkpoint = Path(cfg["output_dir"]) / "smoke" / "last.ckpt"
    ckpt = torch.load(checkpoint, map_location="cpu", weights_only=False)
    if int(ckpt["global_step"]) != 128:
        raise RuntimeError(f"Resume test did not end at global_step 128: {ckpt.get('global_step')}")
    metrics = json.loads((checkpoint.parent / "validation_latest.json").read_text())
    if metrics.get("global_step") != 128 or not all(math.isfinite(float(v)) for v in metrics.values()):
        raise RuntimeError("Smoke validation is missing or nonfinite.")
    if not ckpt.get("optimizer_states") or not ckpt.get("lr_schedulers"):
        raise RuntimeError("Checkpoint is missing optimizer/scheduler state.")
    stamp = {
        "fingerprint": cfg["fingerprint"], "panel_sha256": meta["sha256"],
        "global_step": 128, "distributed_ranks": 8, "resume_test": "passed",
        "time_utc": datetime.now(timezone.utc).isoformat(),
        "job_id": os.environ.get("SLURM_JOB_ID"), "metrics": metrics,
    }
    (run / "preflight_passed.json").write_text(json.dumps(stamp, indent=2) + "\n")
    print("PREFLIGHT_PASSED", json.dumps(stamp, sort_keys=True), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--stamp", action="store_true")
    args = parser.parse_args()
    run, cfg = load_config()
    if args.stamp:
        stamp_preflight(run, cfg)
    else:
        make_panel(run, cfg)
