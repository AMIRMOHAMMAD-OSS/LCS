#!/bin/bash
set -euo pipefail
module purge
module load arch/h100
module load pytorch-gpu/py3/2.6.0
export PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 TOKENIZERS_PARALLELISM=false
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
export OMP_NUM_THREADS=8
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd /lustre/fswork/projects/rech/nef/unh87ms/CT2_Production_20261027
export MASTER_ADDR="$(scontrol show hostnames "$SLURM_JOB_NODELIST" | sed -n '1p')"
export MASTER_PORT="$((15000 + SLURM_JOB_ID % 40000))"
bash /lustre/fswork/projects/rech/nef/unh87ms/CT2_Production_20261027/runtime_python.sh -u /lustre/fswork/projects/rech/nef/unh87ms/CT2_Production_20261027/production_workflow.py run --run-dir /lustre/fswork/projects/rech/nef/unh87ms/ct2_retrain/ct2_production_release/20261027T172237473097Z_35bee105 --task /lustre/fswork/projects/rech/nef/unh87ms/ct2_retrain/ct2_production_release/20261027T172237473097Z_35bee105/jobs/job_53d240f19663/task.json
