#!/bin/bash
set -euo pipefail
module purge
module load pytorch-gpu/py3/2.6.0
export PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 TOKENIZERS_PARALLELISM=false
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd /lustre/fswork/projects/rech/nef/unh87ms/CT2_Production_20261027
bash /lustre/fswork/projects/rech/nef/unh87ms/CT2_Production_20261027/runtime_python.sh -u /lustre/fswork/projects/rech/nef/unh87ms/CT2_Production_20261027/production_workflow.py run --run-dir /lustre/fswork/projects/rech/nef/unh87ms/ct2_retrain/ct2_production_release/20261027T172237473097Z_35bee105 --task /lustre/fswork/projects/rech/nef/unh87ms/ct2_retrain/ct2_production_release/20261027T172237473097Z_35bee105/jobs/job_9db65ec1c95f/task.json
