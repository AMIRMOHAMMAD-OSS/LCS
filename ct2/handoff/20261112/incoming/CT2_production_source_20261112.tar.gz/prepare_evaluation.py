#!/usr/bin/env python3
"""Freeze separate current and exact historical evaluation cohorts; never rescan training."""
from __future__ import annotations
import argparse
from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile

from policy_fixture.source.phase1_tokens import (
    AMINO_ACIDS, STANDARD_CODE, normalize_protein, prepare_sequence,
)

HERE = Path(__file__).resolve().parent
BASE = Path('/lustre/fswork/projects/rech/nef/unh87ms')
REPO_REL = Path('CodonTransformerV2/ct2_production_20260930_v4')
CURRENT_PROTOCOL = 'current_full_sequence_windowed_stop_v1'
LEGACY_PROTOCOL = 'legacy_fixed_prefix2046_no_stop_v1'
SCHEMA = 'ct2-evaluation-inputs-v1'
SOURCE_HASHES = {
    'mapping': 'dfd742bf20bf4aeeeeee9802dbffb7d88a7809eb365ea9f8c3b3866a3e9b1290',
    'tokenizer': 'b3b6b599da88789460e4bf37fb0b168bbac83f5b56413a15130ed95a2a5478c8',
    'current_panel': 'a9d5cf2535ba1370c41993ef02a3f98a980e924223d762a67ee38edb1e7f33ba',
    'frozen_reference': 'f0cbb82170ca3322036f544aa0cae0beccfd0f72ab7e3aae2737ff24ac7e6325',
    'reference_manifest': 'dee19c61785bd719cd0ecc872a31fda8dd0c7aee2a2f23318ab22f8c585130ea',
    'legacy_cohort': 'f7fae2663da7fdf5dd4d6922f8c7dbb639dd258928fff5c7786bc9e7b82926ab',
    'legacy_provenance': 'bfc68e6173aa148504c149182f6c8fdf8325b2373994d2e7d56f51c0e6423e31',
    'codon_table': '613297647956794aaadc680e7010d1ec9617dda21851eda4b7ffcf54fdbe66ec',
}
LEGACY_JSONL_SHA256 = '6f38e777da2330a9a5916090fd71c5a634995cabd2b953a98bfdd420f002ee1f'
LEGACY_IDSET_SHA256 = 'cd37d4174f89f1b9f5f1e994f5ad29c1946d8c2c9a698f40e4cae7d5dfcda4f6'


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def digest(value): return hashlib.sha256(canonical(value)).hexdigest()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()


def strict_json(raw):
    def unique(items):
        result = {}
        for key, value in items:
            if key in result: raise ValueError('Duplicate JSON field: ' + key)
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON: ' + value)))


def read_json(path): return strict_json(Path(path).read_text())


def fingerprint(path, expected=None):
    path = Path(path).resolve()
    before = path.stat(); actual = sha(path); after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError('Input changed while hashing: ' + str(path))
    if expected is not None and actual != expected:
        raise ValueError('Reviewed input SHA256 mismatch: ' + str(path))
    return {'path': str(path), 'sha256': actual, 'bytes': after.st_size}


def jsonl(path, compressed=False):
    opener = gzip.open if compressed else open
    with opener(path, 'rt', encoding='utf-8') as stream:
        for number, line in enumerate(stream, 1):
            if not line.strip(): raise ValueError(f'Empty cohort row at {path}:{number}')
            yield strict_json(line)


def current_rows(path, mapping, vocab):
    """Apply the exact existing QC without shortening or silently dropping rows."""
    result = []
    for number, source in enumerate(jsonl(path)):
        protein = normalize_protein(source['protein_sequence'])
        dna = ''.join(source['dna_sequence'].split()).upper().replace('U', 'T')
        prepared = prepare_sequence(dna, protein, vocab)
        species = source['species']
        if species not in mapping: raise ValueError('Unmapped current-panel species: ' + species)
        if not prepared.target_positions: raise ValueError('Current-panel record has no known targets')
        key = str(source['eval_key'])
        if not key: raise ValueError('Empty current-panel eval_key')
        result.append(dict(eval_id='current:' + key, cohort='current_panel', species=species,
            species_id=mapping[species], protein_sequence=protein, native_dna=dna,
            source_eval_id=key, source_protocol=CURRENT_PROTOCOL,
            source_protein_length=len(protein), source_was_truncated=False,
            native_known_target_positions=list(prepared.target_positions),
            native_ignored_positions=list(prepared.ignored_positions),
            native_qc_status='accepted', generation_terminal_stop=True,
            genome_id=source.get('genome_id'), protein_id=source.get('protein_id'),
            source_record_index=number))
    validate_rows(result, mapping, 'current_panel')
    return result


def validate_rows(rows, mapping, cohort):
    if not rows or len({r['eval_id'] for r in rows}) != len(rows):
        raise ValueError('Empty cohort or duplicate eval_id: ' + cohort)
    if len({r['source_eval_id'] for r in rows}) != len(rows):
        raise ValueError('Duplicate source ID: ' + cohort)
    protocol = CURRENT_PROTOCOL if cohort == 'current_panel' else LEGACY_PROTOCOL
    for row in rows:
        protein = row['protein_sequence']; n = len(protein)
        if (not protein or set(protein) - AMINO_ACIDS or row['cohort'] != cohort
            or row['source_protocol'] != protocol or row['species'] not in mapping
            or row['species_id'] != mapping[row['species']]):
            raise ValueError('Invalid cohort row identity, protein or species')
        known, ignored = row['native_known_target_positions'], row['native_ignored_positions']
        limit = n + (cohort == 'current_panel')
        if (any(type(i) is not int for i in known + ignored) or known != sorted(set(known))
            or ignored != sorted(set(ignored)) or set(known) & set(ignored)
            or set(known) | set(ignored) != set(range(limit))):
            raise ValueError('Native target masks are not a complete disjoint partition')
        if cohort == 'legacy_common_valid':
            if n > 2046 or len(row['native_dna']) != 3 * n:
                raise ValueError('Historical prefix/body-only framing changed')
            actual = [i for i, aa in enumerate(protein)
                      if STANDARD_CODE.get(row['native_dna'][3*i:3*i+3]) == aa]
            if actual != known: raise ValueError('Legacy known positions changed')


def legacy_rows(path, mapping):
    h = hashlib.sha256()
    with gzip.open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''): h.update(block)
    if h.hexdigest() != LEGACY_JSONL_SHA256: raise ValueError('Legacy decoded cohort SHA256 changed')
    rows = list(jsonl(path, compressed=True))
    validate_rows(rows, mapping, 'legacy_common_valid')
    ids = sorted(row['source_eval_id'] for row in rows)
    if digest(ids) != LEGACY_IDSET_SHA256 or len(rows) != 25465:
        raise ValueError('Legacy common-valid ID set changed')
    for row in rows: row['generation_terminal_stop'] = False
    return rows


def add_fixed_wrong_hosts(rows, mapping):
    """A fixed other host from this complete cohort; unchanged across epochs."""
    hosts = sorted({row['species'] for row in rows})
    if len(hosts) < 2: raise ValueError('Host-control cohort requires at least two species')
    for row in rows:
        options = [host for host in hosts if host != row['species']]
        index = int(digest(['wrong-host-v1', row['eval_id']])[:16], 16) % len(options)
        row['wrong_species'] = options[index]
        row['wrong_species_id'] = mapping[options[index]]
    return hosts


def cohort_summary(rows, reference):
    supported = set(reference['species'])
    hosts = {row['species'] for row in rows}
    return dict(records=len(rows), species_count=len(hosts),
        cai_supported_records=sum(row['species'] in supported for row in rows),
        cai_supported_species=len(hosts & supported),
        cai_unsupported_records=sum(row['species'] not in supported for row in rows),
        cai_unsupported_species=sorted(hosts - supported),
        native_qc_status_counts=dict(Counter(row['native_qc_status'] for row in rows)),
        maximum_protein_length=max(len(row['protein_sequence']) for row in rows),
        source_truncated_records=sum(row['source_was_truncated'] for row in rows),
        protocol=rows[0]['source_protocol'],
        eval_id_sha256=digest([row['eval_id'] for row in rows]))


def source_paths(project_root):
    base = Path(project_root).resolve(); repo = base / REPO_REL
    return {'mapping': repo / 'source/species_to_id.json',
            'tokenizer': repo / 'source/CodonTransformerTokenizer.json',
            'current_panel': repo / 'source/eval_panel.jsonl',
            'codon_table': base / 'CodonTransformerV2/ct2_codon_usage_tables_qc/ct2_train_species_codon_frequencies_clean.parquet',
            'frozen_reference': HERE / 'reviewed_preflight/references/frozen_reference.json',
            'reference_manifest': HERE / 'reviewed_preflight/references/reference_manifest.json',
            'legacy_cohort': HERE / 'evaluation_assets/legacy_common_valid.jsonl.gz',
            'legacy_provenance': HERE / 'evaluation_assets/legacy_cohort_provenance.json'}


def validate_prepared_inputs(directory):
    """Revalidate identities and file bytes without regenerating or copying cohorts."""
    directory = Path(directory).resolve(); manifest = read_json(directory / 'evaluation_manifest.json')
    if (manifest.get('schema') != SCHEMA or manifest.get('status') != 'EVALUATION_INPUTS_READY'
        or manifest.get('identity_sha256') != digest({k:v for k,v in manifest.items() if k != 'identity_sha256'})
        or manifest.get('preparer_sha256') != sha(__file__)):
        raise ValueError('Evaluation manifest identity/status changed')
    if set(manifest.get('sources', {})) != set(SOURCE_HASHES):
        raise ValueError('Required evaluation sources are missing or changed')
    for name, entry in manifest['sources'].items():
        if fingerprint(entry['path'], SOURCE_HASHES.get(name)) != entry:
            raise ValueError('Prepared evaluation source changed: ' + name)
    for entry in manifest['cohorts']:
        if entry['path'] != str(directory / (entry['name'] + '.jsonl')):
            raise ValueError('Unexpected cohort path')
        if sha(entry['path']) != entry['sha256']: raise ValueError('Prepared cohort bytes changed')
    if [entry['name'] for entry in manifest['cohorts']] != ['current_panel','legacy_common_valid']:
        raise ValueError('Missing or reordered evaluation cohorts')
    if [entry['records'] for entry in manifest['cohorts']] != [4096,25465]:
        raise ValueError('Evaluation denominators changed')
    if [(entry['protocol'],entry['species_count'],entry['cai_supported_records'],entry['cai_supported_species'])
        for entry in manifest['cohorts']] != [(CURRENT_PROTOCOL,1024,36,9),(LEGACY_PROTOCOL,159,25465,159)]:
        raise ValueError('Evaluation protocols or CAI-support denominators changed')
    for name in ('codon_table','mapping','tokenizer'):
        if manifest[name] != manifest['sources'][name]:
            raise ValueError('Evaluation resource receipt mismatch: '+name)
    if manifest['frozen_reference']['path'] != str(directory / 'frozen_reference.json'):
        raise ValueError('Unexpected frozen-reference path')
    if sha(manifest['frozen_reference']['path']) != SOURCE_HASHES['frozen_reference']:
        raise ValueError('Prepared frozen reference changed')
    if (manifest['reference_manifest']['path'] != str(directory/'reference_manifest.json')
        or sha(manifest['reference_manifest']['path']) != SOURCE_HASHES['reference_manifest']):
        raise ValueError('Prepared frozen-reference receipt changed')
    receipt=read_json(manifest['reference_manifest']['path'])
    if (receipt.get('status')!='COMPLETE' or receipt.get('frozen_reference_sha256')!=SOURCE_HASHES['frozen_reference']
        or receipt.get('identity_sha256')!=manifest['frozen_reference']['identity_sha256']):
        raise ValueError('Frozen-reference receipt does not bind this reference')
    if manifest['legacy_provenance'] != read_json(manifest['sources']['legacy_provenance']['path']):
        raise ValueError('Historical cohort provenance changed')
    return manifest


def prepare(project_root, output):
    output = Path(output).resolve()
    if output.exists(): return validate_prepared_inputs(output)
    paths = source_paths(project_root)
    sources = {name:fingerprint(path, SOURCE_HASHES.get(name)) for name,path in paths.items()}
    mapping = read_json(paths['mapping']); vocab = read_json(paths['tokenizer'])['model']['vocab']
    if set(mapping.values()) != set(range(26678)): raise ValueError('Real-species mapping changed')
    reference = read_json(paths['frozen_reference'])
    if reference.get('status') != 'LEGACY_REFERENCE_FROZEN' or len(reference['species']) != 159:
        raise ValueError('Unexpected frozen CAI reference')
    current = current_rows(paths['current_panel'], mapping, vocab)
    legacy = legacy_rows(paths['legacy_cohort'], mapping)
    if (len(current) != 4096 or len({r['species'] for r in current}) != 1024
        or len({r['species'] for r in legacy}) != 159):
        raise ValueError('Reviewed cohort counts changed')
    provenance = read_json(paths['legacy_provenance'])
    if (provenance.get('selected_records') != 25465 or provenance.get('selected_idset_sha256') != LEGACY_IDSET_SHA256
        or provenance.get('legacy_cohort_gzip_sha256') != SOURCE_HASHES['legacy_cohort']
        or provenance.get('legacy_cohort_jsonl_sha256') != LEGACY_JSONL_SHA256):
        raise ValueError('Legacy cohort provenance disagrees with frozen content')
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix='.' + output.name + '.', dir=output.parent))
    try:
        cohorts = []
        for rows in (current,legacy):
            hosts = add_fixed_wrong_hosts(rows,mapping); name = rows[0]['cohort']
            path = temporary / (name + '.jsonl')
            with path.open('wb') as stream:
                for row in rows: stream.write(canonical(row) + b'\n')
                stream.flush(); os.fsync(stream.fileno())
            cohorts.append(dict(name=name,path=str(output/path.name),sha256=sha(path),
                wrong_host_universe=hosts,**cohort_summary(rows,reference)))
        if [(c['cai_supported_records'],c['cai_supported_species']) for c in cohorts] != [(36,9),(25465,159)]:
            raise ValueError('Reviewed CAI support changed')
        shutil.copyfile(paths['frozen_reference'], temporary/'frozen_reference.json')
        shutil.copyfile(paths['reference_manifest'], temporary/'reference_manifest.json')
        for name,path in paths.items():
            if fingerprint(path,SOURCE_HASHES.get(name)) != sources[name]:
                raise ValueError('Source changed during cohort preparation: '+name)
        overlap = len({(r['species'],r['protein_sequence'],r['native_dna']) for r in current}
                      & {(r['species'],r['protein_sequence'],r['native_dna']) for r in legacy})
        manifest = dict(schema=SCHEMA,status='EVALUATION_INPUTS_READY',preparer_sha256=sha(__file__),
            project_root=str(Path(project_root).resolve()),sources=sources,cohorts=cohorts,
            frozen_reference={'path':str(output/'frozen_reference.json'),'sha256':SOURCE_HASHES['frozen_reference'],
                              'identity_sha256':reference['identity_sha256']},
            reference_manifest={'path':str(output/'reference_manifest.json'),
                                'sha256':SOURCE_HASHES['reference_manifest']},
            codon_table=sources['codon_table'],mapping=sources['mapping'],tokenizer=sources['tokenizer'],
            cross_cohort_exact_record_overlap=overlap,legacy_provenance=provenance,
            controls={'unknown_species_id':26678,'wrong_host_rule':'First 16 hex digits of SHA256(canonical JSON [wrong-host-v1, eval_id]) modulo sorted other-host count',
                      'training_wrong_species_probability':0},
            limitations=['Current and legacy cohorts are reported separately; never pool their denominators.',
                'Current full sequences are windowed at inference; legacy cohort retains historical prefix lengths and no-stop framing.',
                'Legacy cohort selection was already conditioned on historical common-valid outputs; it is a fixed comparison cohort, not unbiased whole-test-set performance.',
                '304 legacy records fail current native-DNA training QC; they remain in the cohort with explicit native target masks and QC flags.',
                'Historical reported metrics may use other arithmetic or generation protocols; cohort identity alone does not prove metric parity.',
                'Only 36/4096 current-panel records have this legacy CAI reference; unsupported cases must remain in reported denominators.'])
        manifest['identity_sha256']=digest(manifest)
        (temporary/'evaluation_manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True,allow_nan=False)+'\n')
        os.rename(temporary,output)
    finally:
        if temporary.exists(): shutil.rmtree(temporary)
    return validate_prepared_inputs(output)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root',type=Path,default=BASE)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(argv)
    result=prepare(args.project_root,args.out)
    print('EVALUATION_INPUTS_STATUS='+result['status'])
    print('EVALUATION_MANIFEST='+str(args.out.resolve()/'evaluation_manifest.json'))
    return 0


if __name__=='__main__': raise SystemExit(main())
