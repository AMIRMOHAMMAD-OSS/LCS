"""Explicit clipping policy for the finite CT2 trainer and matched ablations.

The supervised-target normalization and accumulation are the reviewed update
arithmetic. Clipping is an explicit experiment setting; None means no clipping.
Torch imports are deferred so policy helpers remain importable on a CPU host.
"""
from __future__ import annotations
import contextlib
import math


def validate_clip(value):
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        raise ValueError('Gradient clipping must be a finite positive number or None')
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise ValueError('Gradient clipping must be a finite positive number or None')
    return value


def parse_clip(text):
    return None if str(text).lower() == 'none' else validate_clip(float(text))


def _world():
    import torch.distributed as dist
    return dist.get_world_size() if dist.is_available() and dist.is_initialized() else 1


def _reduce(value, op=None):
    import torch.distributed as dist
    if _world() > 1:
        dist.all_reduce(value, op=dist.ReduceOp.SUM if op is None else op)
    return value


def _require_health(condition, device, label):
    import torch
    import torch.distributed as dist
    flag = torch.as_tensor(condition, device=device, dtype=torch.int32)
    _reduce(flag, dist.ReduceOp.MIN)
    if not bool(flag.item()):
        raise FloatingPointError(label)


def clip_gradients(parameters, clip_value):
    """Check the total gradient norm even when no norm cap is requested."""
    import torch
    clip_value = validate_clip(clip_value)
    parameters = list(parameters)
    try:
        norm = torch.nn.utils.clip_grad_norm_(parameters,
            float('inf') if clip_value is None else clip_value,
            error_if_nonfinite=True)
    except RuntimeError as error:
        if 'non-finite' in str(error).lower() or 'nonfinite' in str(error).lower():
            raise FloatingPointError('Nonfinite gradient norm') from error
        raise
    norm_value = float(norm)
    if not math.isfinite(norm_value):
        raise FloatingPointError('Nonfinite gradient norm')
    factor = 1. if clip_value is None else min(1., clip_value / (norm_value + 1e-6))
    return norm_value, factor


def _parameter_group(name):
    while name.startswith('module.'):
        name = name[len('module.'):]
    return 'species' if name.startswith('species_embed.') else 'backbone'


def snapshot_parameters(module):
    return {name: value.detach().clone() for name, value in module.named_parameters()}


def gradient_statistics(module):
    """Pre-clipping group norms; active species rows mean nonzero current gradient."""
    import torch
    groups = {'backbone': [], 'species': [], 'species_active_rows': [], 'token_embedding': []}
    active_species_rows = {}
    for name, parameter in module.named_parameters():
        if parameter.grad is None:
            continue
        grad = parameter.grad.detach()
        if grad.is_sparse:
            grad = grad.to_dense()
        g2 = grad.double().square().sum()
        p2 = parameter.detach().double().square().sum()
        groups[_parameter_group(name)].append(torch.stack((g2, p2)))
        if name.endswith('tok_embeddings.weight'):
            groups['token_embedding'].append(torch.stack((g2, p2)))
        if _parameter_group(name) == 'species':
            if grad.ndim != 2:
                raise ValueError('Species diagnostic expects a row embedding matrix')
            active_species_rows[name] = grad.ne(0).any(dim=1)
            groups['species_active_rows'].append(torch.stack((g2,
                parameter.detach()[active_species_rows[name]].double().square().sum())))
    result = {}
    for group, values in groups.items():
        g2, p2 = torch.stack(values).sum(0).cpu().tolist() if values else (0., 0.)
        if not all(math.isfinite(v) and v >= 0 for v in (g2, p2)):
            raise FloatingPointError('Nonfinite gradient-group norm: ' + group)
        result[group] = {'gradient_l2': math.sqrt(g2), 'parameter_l2': math.sqrt(p2),
                         'gradient_over_parameter_l2': math.sqrt(g2 / p2) if p2 else None}
    result['token_embedding']['subset_of'] = 'backbone'
    result['species']['active_rows'] = sum(int(mask.sum()) for mask in active_species_rows.values())
    result['species']['active_definition'] = 'Rows with nonzero current pre-clipping gradient'
    result['species_active_rows']['active_rows'] = result['species']['active_rows']
    result['species_active_rows']['active_definition'] = result['species']['active_definition']
    return result, active_species_rows


def parameter_update_statistics(module, before, active_species_rows=None):
    """Actual optimizer weight changes, including AdamW and weight decay."""
    import torch
    sums = {'backbone': [], 'species': [], 'species_active_rows': [], 'token_embedding': []}
    for name, parameter in module.named_parameters():
        if name not in before or before[name].shape != parameter.shape:
            raise ValueError('Parameter snapshot differs from the current model')
        old = before[name]
        # Accumulate in float64, in bounded chunks to avoid a second full-model
        # double precision allocation on H100 during the diagnostic.
        old_flat, new_flat = old.reshape(-1), parameter.detach().reshape(-1)
        delta_sq = torch.zeros((), device=parameter.device, dtype=torch.float64)
        old_sq = torch.zeros_like(delta_sq)
        for first in range(0, parameter.numel(), 1048576):
            a = old_flat[first:first + 1048576].double()
            b = new_flat[first:first + 1048576].double()
            delta_sq += (b - a).square().sum()
            old_sq += a.square().sum()
        pair = torch.stack((delta_sq, old_sq))
        sums[_parameter_group(name)].append(pair)
        if name.endswith('tok_embeddings.weight'):
            sums['token_embedding'].append(pair)
        if active_species_rows is not None and name in active_species_rows:
            mask = active_species_rows[name]
            a, b = old[mask].double(), parameter.detach()[mask].double()
            sums['species_active_rows'].append(torch.stack(((b-a).square().sum(), a.square().sum())))
    if set(before) != {name for name, _ in module.named_parameters()}:
        raise ValueError('Parameter snapshot has extra tensors')
    result = {}
    for group, values in sums.items():
        if not values:
            result[group] = {'parameter_l2_before': 0., 'update_l2': 0.,
                             'relative_update_l2': None, 'parameter_tensors': 0}
            continue
        delta_sq, old_sq = torch.stack(values).sum(0).cpu().tolist()
        if not all(math.isfinite(v) and v >= 0 for v in (delta_sq, old_sq)):
            raise FloatingPointError('Nonfinite actual parameter update: ' + group)
        delta, old_norm = math.sqrt(delta_sq), math.sqrt(old_sq)
        result[group] = {'parameter_l2_before': old_norm, 'update_l2': delta,
                         'relative_update_l2': delta / old_norm if old_norm else None,
                         'parameter_tensors': len(values)}
    result['token_embedding']['subset_of'] = 'backbone'
    result['species_active_rows']['active_rows'] = sum(int(mask.sum()) for mask in (active_species_rows or {}).values())
    result['species_active_rows']['active_definition'] = 'Rows with nonzero current pre-clipping gradient'
    return result


def _tensor_health(tensors, device):
    import torch
    flags = [torch.isfinite(t.detach()).all().to(device=device)
             for t in tensors if torch.is_tensor(t) and (t.is_floating_point() or t.is_complex())]
    return torch.stack(flags).all() if flags else torch.ones((), dtype=torch.bool, device=device)


def _state_tensors(value):
    if isinstance(value, dict):
        for item in value.values():
            yield from _state_tensors(item)
    elif isinstance(value, (tuple, list)):
        for item in value:
            yield from _state_tensors(item)
    else:
        yield value


def optimizer_update(module, optimizer, batches, device, lr, clip_value, *, measure_update=False):
    """Return (metrics, preclip_norm, factor, local_targets, update_statistics).

    Loss is globally normalized over every labeled token across all accumulated
    microbatches. DDP averages gradients, hence the world-size compensation.
    Finite-loss/parameter/optimizer checks apply to both clipped and unclipped
    branches. Production callers must pass their explicit clipping selection.
    """
    import torch
    clip_value = validate_clip(clip_value)
    if not math.isfinite(float(lr)) or float(lr) <= 0:
        raise ValueError('Learning rate must be finite and positive')
    if not batches:
        raise ValueError('An update must contain microbatches')
    local_count = sum(int(batch['labels'].ne(-100).sum()) for batch in batches)
    total = torch.tensor(local_count, dtype=torch.int64, device=device)
    _reduce(total)
    if int(total) <= 0:
        raise ValueError('An optimizer update has no global supervised targets')
    for group in optimizer.param_groups:
        group['lr'] = float(lr)
    optimizer.zero_grad(set_to_none=True)
    scale = _world() / int(total)
    metrics = torch.zeros(9, dtype=torch.float64, device=device)
    module.train()
    for index, cpu in enumerate(batches):
        batch = {key: value.to(device) for key, value in cpu.items()}
        context = (module.no_sync() if index < len(batches) - 1 and hasattr(module, 'no_sync')
                   else contextlib.nullcontext())
        with context:
            amp = torch.autocast('cuda', dtype=torch.bfloat16) if device.type == 'cuda' else contextlib.nullcontext()
            with amp:
                logits = module(batch['input_ids'], batch['attention_mask'], batch['species_id'])
            losses = torch.nn.functional.cross_entropy(
                logits.float().reshape(-1, logits.shape[-1]), batch['labels'].reshape(-1),
                ignore_index=-100, reduction='none').reshape_as(batch['labels'])
            loss = losses.sum() * scale
            _require_health(torch.isfinite(loss), device, 'Nonfinite supervised loss')
            loss.backward()
        with torch.no_grad():
            for kind, rows in enumerate((~batch['full'] & batch['real'], batch['full'] & batch['real'])):
                mask = rows[:, None] & batch['labels'].ne(-100)
                metrics[2 * kind] += losses.detach()[mask].double().sum()
                metrics[2 * kind + 1] += mask.sum()
            metrics[4] += batch['real'].sum()
            metrics[5] += (batch['attention_mask'] * batch['real'][:, None]).sum()
            metrics[6] += batch['full'].sum()
            metrics[7] += batch['unknown'].sum()
            metrics[8] += batch['record_first'].sum()
    grad_details, active_rows = gradient_statistics(module) if measure_update else (None, None)
    norm, factor = clip_gradients(module.parameters(), clip_value)
    before = snapshot_parameters(module) if measure_update else None
    optimizer.step()
    _require_health(_tensor_health(module.parameters(), device), device, 'Nonfinite model parameter after optimizer step')
    _require_health(_tensor_health(_state_tensors(optimizer.state), device), device,
                    'Nonfinite optimizer state after optimizer step')
    details = {'clip_value': clip_value, 'model_finite': True, 'optimizer_finite': True}
    if before is not None:
        details['preclip_gradient_groups'] = grad_details
        details['actual_parameter_update'] = parameter_update_statistics(module, before, active_rows)
    _reduce(metrics)
    if int(metrics[1] + metrics[3]) != int(total):
        raise RuntimeError('Reported target count differs from the normalization denominator')
    return metrics.cpu().tolist(), norm, factor, local_count, details
