import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import production_trainer as trainer
from compare_transition import compare_pair


def tiny_plan():
    source = {'checkpoint_sha256': trainer.SOURCE_CHECKPOINT_SHA256, 'repo': '/reviewed/source'}
    return {'identity': 'plan', 'source': source, 'stages': [
        {'steps': n, 'windows': 80, 'records': 40, 'known_targets': 800}
        for n in (10, 12, 14, 16)]}


def checkpoint(updates=3, branch='reference'):
    plan = tiny_plan()
    stage = (updates - 1) // 2; step = (updates - 1) % 2 + 1
    statistics = trainer.blank_statistics()
    for index in range(stage + 1):
        statistics[index].update(updates=2 if index < stage else step,
            real_windows=80, physical_records=40, known_targets=800,
            partial_targets=100, full_targets=200, partial_loss_sum=45.,
            full_loss_sum=90., grad_norm_sum=1., grad_norm_sq_sum=.5,
            grad_norm_max=.5, clipping_factor_sum=2.)
    states = [{'rank': rank, 'rng': {'test': [1, 2, 3]}, 'stream': {
        'committed_windows': 10, 'committed_records': 5, 'committed_known_targets': 100,
        'next_active_lanes': [0], 'lanes': [{'validated_complete': False}]}}
        for rank in range(8)]
    return dict(format=trainer.FORMAT, mode='qualification', branch=branch,
        plan_identity='plan', release_id='release', trainer_identity='trainer',
        stage=stage, stage_step=step, stage_complete=step == 2, completed_updates=updates,
        source={**plan['source'], 'imported_model_only': True, 'optimizer_age_at_import': 0,
                'source_global_step': 120000}, world_size=8,
        padding_policy='fixed_stage_max_length', lr_policy=copy.deepcopy(trainer.LR_POLICY),
        clip_value=.5, full_dataset_verified=False, production_resume_allowed=False,
        statistics=statistics, rank_states=states, state_dict={'weight': [1., 2.]},
        optimizer_state={'moment': [0.1, 0.2]}, model_config={'hidden_size': 768},
        species_embed_scale=.0347, optimizer_parameter_names=[['weight']],
        execution_settings={'deterministic': True}, ddp_policy={'fixed': True}, runtime_versions={})


class ScheduleTests(unittest.TestCase):
    def test_warmup_and_continuous_stage_endpoints(self):
        self.assertAlmostEqual(trainer.learning_rate(0, 1, 171696), 2e-6)
        self.assertAlmostEqual(trainer.learning_rate(0, 1000, 171696), 2e-5)
        self.assertAlmostEqual(trainer.learning_rate(0, 171696, 171696), 5e-6)
        self.assertAlmostEqual(trainer.learning_rate(1, 1, 153428), 5e-6)
        self.assertAlmostEqual(trainer.learning_rate(1, 153428, 153428), 2e-6)
        self.assertAlmostEqual(trainer.learning_rate(3, 150302, 150302), 1e-7)
        rates = [trainer.learning_rate(1, n, 20) for n in range(1, 21)]
        self.assertEqual(rates, sorted(rates, reverse=True))

    def test_qualification_has_explicit_compressed_schedule(self):
        self.assertEqual(trainer.effective_steps(tiny_plan(), 'qualification'), [2, 2, 2, 2])
        self.assertEqual(trainer.learning_rate(0, 1, 2), 2e-5)
        self.assertEqual(trainer.learning_rate(0, 2, 2), 5e-6)
        with self.assertRaises(ValueError): trainer.learning_rate(0, 0, 2)

    def test_statistics_count_selected_and_known_targets_separately(self):
        stat = trainer.blank_statistics()[0]
        trainer.add_statistics(stat, [2., 3., 4., 5., 2., 12., 1., 0., 1.], 1., .5, 10)
        self.assertEqual((stat['updates'], stat['known_targets'], stat['partial_targets'], stat['full_targets']), (1, 10, 3, 5))
        self.assertEqual(stat['clipped_updates'], 1)
        with self.assertRaises(ValueError): trainer.add_statistics(stat, [0., 99., 0., 0., 1., 1., 0., 0., 1.], .1, 1., 1)


class ProgressTests(unittest.TestCase):
    def setUp(self):
        self.identity = patch.object(trainer, 'trainer_identity', return_value='trainer')
        self.identity.start(); self.addCleanup(self.identity.stop)

    def test_midstage_and_boundary_resume_positions(self):
        cp = checkpoint(3)
        trainer.validate_progress(cp, tiny_plan(), 'qualification', 'release', .5)
        self.assertEqual(trainer.resume_position(cp, None, 'qualification'), (1, 1, False))
        cp = checkpoint(2)
        self.assertEqual(trainer.resume_position(cp, 1, 'production'), (1, 0, True))
        with self.assertRaises(ValueError): trainer.resume_position(cp, 0, 'production')
        with self.assertRaises(ValueError): trainer.resume_position(checkpoint(8), None, 'qualification')

    def test_rejects_mode_age_and_clip_drift(self):
        cp = checkpoint()
        with self.assertRaises(ValueError): trainer.validate_progress(cp, tiny_plan(), 'production', 'release')
        with self.assertRaises(ValueError): trainer.validate_progress(cp, tiny_plan(), 'qualification', 'release', None)
        cp['completed_updates'] = 4
        with self.assertRaises(ValueError): trainer.validate_progress(cp, tiny_plan(), 'qualification', 'release')
        cp = checkpoint(); cp['clip_value'] = float('nan')
        with self.assertRaises(ValueError): trainer.validate_progress(cp, tiny_plan(), 'qualification', 'release')

    def test_rejects_uncommitted_or_fabricated_coverage(self):
        cp = checkpoint(); cp['statistics'][1]['real_windows'] += 1
        with self.assertRaises(ValueError): trainer.validate_progress(cp, tiny_plan(), 'qualification', 'release')
        cp = checkpoint(); cp['full_dataset_verified'] = True
        with self.assertRaises(ValueError): trainer.validate_progress(cp, tiny_plan(), 'qualification', 'release')
        states = checkpoint()['rank_states']; stat = checkpoint()['statistics'][1]
        with self.assertRaises(ValueError): trainer.reconcile_streams(states, stat, tiny_plan()['stages'][1], complete=True)

    def test_transition_comparison_requires_rng_and_count_equality(self):
        a, b = checkpoint(), checkpoint(branch='split')
        self.assertTrue(compare_pair(a, b, 3, 'split', tiny_plan(), 'release')['exact_equality'])
        b['rank_states'][4]['rng']['test'][0] = 8
        self.assertEqual(compare_pair(a, b, 3, 'split', tiny_plan(), 'release')['status'], 'FAIL')
        b = checkpoint(branch='split'); b['statistics'][0]['partial_targets'] += 1
        self.assertEqual(compare_pair(a, b, 3, 'split', tiny_plan(), 'release')['status'], 'FAIL')

    def test_transition_comparison_tracks_tolerance_separately(self):
        import numpy as np
        a, b = checkpoint(8), checkpoint(8, 'resume')
        a['state_dict']['weight'] = np.array([1., 2.])
        b['state_dict']['weight'] = np.array([1., 3.])
        report = compare_pair(a, b, 8, 'resume', tiny_plan(), 'release')
        self.assertEqual(report['status'], 'FAIL')
        self.assertFalse(report['exact_equality'])


class RetentionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / 'train'; (self.root / 'checkpoints').mkdir(parents=True)

    def make_checkpoint(self, age, complete=False, release='release'):
        path = trainer.checkpoint_path(self.root, age)
        path.write_bytes(f'checkpoint-{age}'.encode())
        receipt = dict(format=trainer.FORMAT, mode='production', path=str(path), sha256=trainer.sha(path),
            bytes=path.stat().st_size, completed_updates=age, stage_complete=complete,
            plan_identity='plan', trainer_identity='trainer', release_id=release)
        trainer.atomic_json(path.with_suffix(path.suffix + '.sha256.json'), receipt)
        return receipt

    def test_keep_three_intermediates_and_all_endpoints(self):
        rows = [self.make_checkpoint(i) for i in (2, 4, 6, 8)]
        endpoint = self.make_checkpoint(9, complete=True)
        foreign = self.make_checkpoint(1, release='foreign')
        removed = trainer.prune_owned_intermediates(self.root, endpoint)
        self.assertEqual(removed, [rows[0]['path']])
        for row in rows[1:] + [endpoint, foreign]: self.assertTrue(Path(row['path']).exists())
        self.assertTrue((self.root / 'retention.jsonl').is_file())

    def test_protect_evaluation_reference(self):
        rows = [self.make_checkpoint(i) for i in (2, 4, 6, 8)]
        evaldir = self.root.parent / 'evaluation'; evaldir.mkdir()
        trainer.atomic_json(evaldir / 'evaluation_manifest.json', {'checkpoint_path': rows[0]['path']})
        self.assertEqual(trainer.prune_owned_intermediates(self.root, rows[-1]), [])

    def test_corrupt_latest_or_fallback_blocks_deletion(self):
        rows = [self.make_checkpoint(i) for i in (2, 4, 6, 8)]
        Path(rows[2]['path']).write_bytes(b'corrupt')
        with self.assertRaises(ValueError): trainer.prune_owned_intermediates(self.root, rows[-1])
        self.assertTrue(Path(rows[0]['path']).exists())


if __name__ == '__main__': unittest.main()
