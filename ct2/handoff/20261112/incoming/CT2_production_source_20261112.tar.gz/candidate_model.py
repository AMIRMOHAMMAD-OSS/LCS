"""Provenance-preserving, weights-only import for an isolated CT2 preflight.

This module never rewrites the old run fingerprint or imports its Adam moments.
Torch/Transformers imports are deferred so provenance helpers can be CPU-tested.
"""
from __future__ import annotations
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path

SOURCE_CHECKPOINT_SHA256 = 'adbdca83862853a05df956b92f43c1fe3b2286d0fea2209b7c8c6ed0c4dd0e28'
SOURCE_FINGERPRINT = 'a9b9a2f2e55ffdc6b96ae4d7269056b3d0541761e979466f2c0a5c7d0e70e105'
SOURCE_FILES = {
    'run.json': '66174cfcd8f26b37e17429fb4f435830125ec0af0ccd8bc23135aec19d7a801b',
    'source/species_to_id.json': 'dfd742bf20bf4aeeeeee9802dbffb7d88a7809eb365ea9f8c3b3866a3e9b1290',
    'source/CodonTransformerTokenizer.json': 'b3b6b599da88789460e4bf37fb0b168bbac83f5b56413a15130ed95a2a5478c8',
}
UNKNOWN_SPECIES = 26678
N_SPECIES = 28678
SPECIES_SCALE = .0347


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def canonical_identity(value):
    return hashlib.sha256(json.dumps({k: v for k, v in value.items() if k != 'identity'},
        sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def validate_plan_identity(plan):
    if plan.get('identity') != canonical_identity(plan):
        raise ValueError('Finite plan identity does not match its contents')
    if plan.get('world_size', 8) != 8:
        raise ValueError('This candidate requires exactly eight ranks')
    if plan.get('padding_policy') != 'fixed_stage_max_length':
        raise ValueError('This candidate requires fixed stage-max-length padding')


def validate_source_metadata(checkpoint, source):
    if source.get('checkpoint_sha256') != SOURCE_CHECKPOINT_SHA256:
        raise ValueError('Preflight source is not the reviewed immutable 40k checkpoint')
    if source.get('source_fingerprint') != SOURCE_FINGERPRINT:
        raise ValueError('Unexpected old-run fingerprint in source provenance')
    expected = {'ct2_format': 1, 'fingerprint': SOURCE_FINGERPRINT, 'global_step': 120000,
                'continuation_step': 40000, 'stage': 0, 'stage_step': 40000,
                'mapping_sha256': SOURCE_FILES['source/species_to_id.json']}
    for key, value in expected.items():
        if checkpoint.get(key) != value:
            raise ValueError('Source checkpoint metadata mismatch: ' + key)
    if not math.isclose(float(checkpoint.get('species_embed_scale', float('nan'))), SPECIES_SCALE,
                        rel_tol=0, abs_tol=1e-12):
        raise ValueError('The source species scale must remain paired with its weights')
    if not isinstance(checkpoint.get('model_config'), dict):
        raise ValueError('Source checkpoint has no explicit model configuration')


def validate_repo(source):
    repo = Path(source['repo'])
    declared = {'run.json': source.get('run_json_sha256'),
                'source/species_to_id.json': source.get('mapping_sha256'),
                'source/CodonTransformerTokenizer.json': source.get('tokenizer_sha256')}
    for relative, expected in SOURCE_FILES.items():
        if declared[relative] != expected or sha(repo / relative) != expected:
            raise ValueError('Source policy identity changed: ' + relative)
    cfg = json.loads((repo / 'run.json').read_text())
    fingerprint = hashlib.sha256(json.dumps({k: v for k, v in cfg.items() if k != 'fingerprint'},
                                           sort_keys=True).encode()).hexdigest()
    if cfg.get('fingerprint') != SOURCE_FINGERPRINT or fingerprint != SOURCE_FINGERPRINT:
        raise ValueError('The original run configuration fingerprint is invalid')
    return repo, cfg


def runtime_versions():
    import torch
    actual = {'torch': torch.__version__, 'transformers': importlib.metadata.version('transformers'),
              'numpy': importlib.metadata.version('numpy'), 'cuda': torch.version.cuda,
              'cudnn': torch.backends.cudnn.version()}
    if actual['torch'].split('+')[0] != '2.6.0' or actual['transformers'] != '4.51.3':
        raise RuntimeError('Use the reviewed torch 2.6.0 / transformers 4.51.3 environment: ' + repr(actual))
    return actual


def tokenizer_at(repo):
    from transformers import PreTrainedTokenizerFast
    tokenizer = PreTrainedTokenizerFast(tokenizer_file=str(Path(repo) / 'source/CodonTransformerTokenizer.json'),
        bos_token='[CLS]', eos_token='[SEP]', cls_token='[CLS]', sep_token='[SEP]',
        pad_token='[PAD]', unk_token='[UNK]', mask_token='[MASK]')
    vocab = tokenizer.get_vocab()
    if len(vocab) != 90 or set(vocab.values()) != set(range(90)):
        raise ValueError('Unexpected tokenizer vocabulary')
    if tokenizer('m_atg __taa', add_special_tokens=True)['input_ids'] != [
            tokenizer.cls_token_id, vocab['m_atg'], vocab['__taa'], tokenizer.sep_token_id]:
        raise ValueError('Unexpected tokenizer framing')
    return tokenizer


def build_from_state(model_config, state_dict, scale, tokenizer, device):
    import torch
    from transformers import ModernBertConfig, ModernBertForMaskedLM
    config = ModernBertConfig(**model_config)
    required = {'vocab_size': 90, 'hidden_size': 768, 'num_hidden_layers': 22,
                'num_attention_heads': 12, 'max_position_embeddings': 2048}
    for name, expected in required.items():
        if getattr(config, name) != expected:
            raise ValueError('Unexpected source architecture: ' + name)
    if not math.isclose(float(scale), SPECIES_SCALE, rel_tol=0, abs_tol=1e-12):
        raise ValueError('Species scaling differs from source checkpoint')
    config._attn_implementation = 'sdpa'
    config.reference_compile = False

    class CT2(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.model = ModernBertForMaskedLM(config)
            self.species_embed = torch.nn.Embedding(N_SPECIES, config.hidden_size)
            self.scale = float(scale)

        def forward(self, input_ids, attention_mask, species_id):
            vectors = self.model.get_input_embeddings()(input_ids)
            vectors = vectors + self.species_embed(species_id)[:, None, :] * self.scale
            return self.model(inputs_embeds=vectors, attention_mask=attention_mask).logits

    model = CT2()
    model.load_state_dict(state_dict, strict=True)
    for name, tensor in model.state_dict().items():
        if tensor.is_floating_point() and not torch.isfinite(tensor).all():
            raise FloatingPointError('Nonfinite model tensor: ' + name)
    return model.to(device)


def load_source(plan, device, verify_checkpoint_hash=True):
    import torch
    source = plan['source']
    repo, _ = validate_repo(source)
    path = Path(source['checkpoint'])
    before = path.stat()
    if verify_checkpoint_hash and sha(path) != SOURCE_CHECKPOINT_SHA256:
        raise ValueError('Source checkpoint SHA256 differs from reviewed 40k checkpoint')
    checkpoint = torch.load(path, map_location='cpu', weights_only=False, mmap=True)
    validate_source_metadata(checkpoint, source)
    from execution_profile import PROFILE, validate_snapshot
    if checkpoint.get('execution_profile') != PROFILE:
        raise ValueError('Source checkpoint arithmetic profile changed')
    validate_snapshot(checkpoint.get('execution_settings', {}))
    tokenizer = tokenizer_at(repo)
    model = build_from_state(checkpoint['model_config'], checkpoint['state_dict'],
                             checkpoint['species_embed_scale'], tokenizer, device)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError('Source checkpoint changed during import')
    provenance = dict(source, imported_model_only=True, source_global_step=checkpoint['global_step'],
                      optimizer_age_at_import=0, source_stat=[after.st_size, after.st_mtime_ns])
    return model, tokenizer, provenance


def new_optimizer(model):
    import torch
    optimizer = torch.optim.AdamW([
        {'params': list(model.model.parameters()), 'weight_decay': .01},
        {'params': list(model.species_embed.parameters()), 'weight_decay': 0.},
    ], lr=2e-5, betas=(.9, .999), eps=1e-8, amsgrad=False)
    names = [[f'model.{n}' for n, _ in model.model.named_parameters()], ['species_embed.weight']]
    return optimizer, names
