#!/usr/bin/env python3
"""Qualify CT2, explicitly select clipping, and submit one bounded job at a time."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import uuid
import zipfile

HERE = Path(__file__).resolve().parent
BASE = Path('/lustre/fswork/projects/rech/nef/unh87ms')
REPO = BASE / 'CodonTransformerV2/ct2_production_20260930_v4'
EVIDENCE = HERE / 'reviewed_preflight'
EVIDENCE_DIGEST = '374435166e73d5ab04c45f2cf7f35fc775807d4c0450b53e3e8e5303df480d8e'
PLAN_ID = '6bbb3d44ff93c640193930f1324271f0abf4f41828656cd1b04bd4edeb92c819'
STAGE_STEPS = [171696, 153428, 145546, 150302]
CAPS = ('0.5', '1.0', 'none')
MINIMUM_FREE_BYTES = 75 * 1024**3
SCHEDULE = {'schema': 'ct2-stage-cosine-v1', 'anchors': [2e-5, 5e-6, 2e-6, 1e-6, 1e-7],
            'initial_warmup_updates': 1000, 'initial_warmup_start': 2e-6,
            'scope': 'Production proposal; not claimed sweep-optimal'}


def now(): return datetime.now(timezone.utc).isoformat()
def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result: raise ValueError('Duplicate JSON key: ' + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda x: (_ for _ in ()).throw(ValueError('Nonfinite JSON value: ' + x)))
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''): h.update(part)
    return h.hexdigest()
def atomic(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as f:
            json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)
            f.write('\n'); f.flush(); os.fsync(f.fileno())
        os.replace(temp, path)
    finally: Path(temp).unlink(missing_ok=True)
def immutable(path, value):
    path = Path(path)
    if path.exists():
        if read(path) != value: raise RuntimeError('Refusing to replace immutable file: ' + str(path))
    else: atomic(path, value)
def clip_value(token):
    if token == 'none': return None
    value = float(token)
    if not math.isfinite(value) or value not in (.5, 1.): raise ValueError('Select 0.5, 1.0 or none')
    return value
def clip_token(value): return 'none' if value is None else ('0.5' if value == .5 else '1.0')
def cap_folder(token): return 'clip_' + token.replace('.', 'p')
def safe_child(parent, relative):
    relative = Path(relative)
    if relative.is_absolute() or '..' in relative.parts: raise ValueError('Unsafe relative report path')
    path = parent / relative
    if any((parent / Path(*relative.parts[:n])).is_symlink() for n in range(1, len(relative.parts) + 1)):
        raise ValueError('Symlinked report path is not allowed')
    return path


def code_hashes():
    files = [p for p in HERE.iterdir() if p.is_file() and p.suffix in {'.py', '.json', '.sh', '.gz'}
             and p.name not in {'LAST_RUN.json', 'package_manifest.json'} and not p.name.startswith('local_')]
    for name in ('policy_fixture', 'metric_policy_fixture', 'reviewed_preflight', 'evaluation_assets'):
        files += [p for p in (HERE / name).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    return {str(p.relative_to(HERE)): sha(p) for p in sorted(files)}


def verify_reviewed_evidence():
    files = {str(p.relative_to(EVIDENCE)): sha(p) for p in sorted(EVIDENCE.rglob('*')) if p.is_file()}
    if digest(files) != EVIDENCE_DIGEST: raise RuntimeError('Reviewed GPU/CPU evidence bundle changed')
    from finite_plan import validate_plan
    plan = validate_plan(read(EVIDENCE / 'finite_plan.json'))
    if plan['identity'] != PLAN_ID or [s['steps'] for s in plan['stages']] != STAGE_STEPS:
        raise RuntimeError('The reviewed four-pass plan differs')
    request = read(EVIDENCE / 'request.json')
    old_tests = read(EVIDENCE / 'cpu_package_tests.json')
    if old_tests.get('code_hashes') != request.get('code_hashes') or old_tests.get('status') != 'PASS':
        raise RuntimeError('Prior package test identity is inconsistent')
    for key in ('skipped_count', 'failures_count', 'errors_count', 'expected_failures_count', 'unexpected_successes_count'):
        if old_tests.get(key) != 0: raise RuntimeError('Prior CPU test gate failed: ' + key)
    for name, expected in request['code_hashes'].items():
        p = HERE / name
        if p.is_file() and sha(p) != expected:
            raise RuntimeError('An audited base implementation changed: ' + name)
    cpu = read(EVIDENCE / 'cpu_status.json')
    if cpu.get('status') != 'CPU_READY' or cpu.get('exit_code') != 0: raise RuntimeError('Prior CPU gate failed')
    bound = {'finite_plan.json': 'plan_sha256', 'references/reference_manifest.json': 'reference_manifest_sha256',
             'source_checkpoint.json': 'source_checkpoint_receipt_sha256', 'cpu_loader_replay.json': 'loader_replay_sha256',
             'cpu_model_probe.json': 'cpu_model_probe_sha256', 'cpu_package_tests.json': 'package_tests_sha256'}
    for name, key in bound.items():
        if sha(EVIDENCE / name) != cpu[key]: raise RuntimeError('Prior CPU report identity differs: ' + name)
    ref = read(EVIDENCE / 'references/reference_manifest.json')
    if ref.get('frozen_reference_sha256') != sha(EVIDENCE / 'references/frozen_reference.json'):
        raise RuntimeError('Reviewed frozen CAI reference changed')
    gpu = read(EVIDENCE / 'gpu_status.json')
    if gpu.get('status') != 'GPU_PREFLIGHT_FINISHED' or gpu.get('exit_code') != 0:
        raise RuntimeError('Prior GPU gate did not finish')
    for stage in range(4):
        report = read(safe_child(EVIDENCE, gpu['attempt']) / f'stage_{stage}/comparison.json')
        if (report.get('status') != 'PASS' or report.get('exact_equality') is not True
            or report.get('plan_identity') != PLAN_ID or report.get('stage') != stage
            or set(report.get('pairs', {})) != {'16', '32'}
            or any(pair.get('status') != 'PASS' or pair.get('exact_equality') is not True
                   for pair in report['pairs'].values())):
            raise RuntimeError('Reviewed GPU replay is not an exact pass at stage ' + str(stage))
    return plan


def verify_remote_inputs(plan, hash_checkpoint=False):
    from candidate_model import validate_repo
    import census
    validate_repo(plan['source']); census.Policy(REPO)
    receipt = read(EVIDENCE / 'source_checkpoint.json')
    cp = Path(plan['source']['checkpoint']); st = cp.stat()
    if (st.st_size, st.st_mtime_ns) != (receipt['bytes'], receipt['mtime_ns']):
        raise RuntimeError('Source checkpoint metadata changed after the reviewed preflight')
    if hash_checkpoint and sha(cp) != plan['source']['checkpoint_sha256']:
        raise RuntimeError('Source checkpoint bytes changed')
    data = Path(plan['data_root'])
    for row in plan['shards']:
        st = (data / row['name']).stat()
        if (st.st_size, st.st_mtime_ns) != (row['bytes'], row['mtime_ns']):
            raise RuntimeError('Census shard metadata changed: ' + row['name'])


def dependency_check():
    versions = {name: importlib.metadata.version(name) for name in ('torch', 'transformers', 'numpy', 'pandas', 'pyarrow')}
    if versions['torch'].split('+')[0] != '2.6.0' or versions['transformers'] != '4.51.3':
        raise RuntimeError('The reviewed Torch 2.6.0 / Transformers 4.51.3 environment is required')
    return versions


def package_tests(output):
    import unittest
    report = {'schema': 'ct2-production-package-tests-v1', 'status': 'FAIL', 'code_hashes': code_hashes()}
    try:
        suite = unittest.TestLoader().discover(str(HERE), pattern='test_*.py', top_level_dir=str(HERE))
        count = suite.countTestCases()
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        report.update(discovered=count, tests_run=result.testsRun, skipped=len(result.skipped),
            errors=len(result.errors), failures=len(result.failures), expected_failures=len(result.expectedFailures),
            unexpected_successes=len(result.unexpectedSuccesses))
        if (result.wasSuccessful() and result.testsRun == count and count > 0
            and not result.skipped and not result.expectedFailures): report['status'] = 'PASS'
    except Exception as e: report['error'] = type(e).__name__ + ': ' + str(e)
    atomic(output, report)
    return 0 if report['status'] == 'PASS' else 1


def require_package_tests(report):
    if (report.get('schema') != 'ct2-production-package-tests-v1' or report.get('status') != 'PASS'
        or report.get('code_hashes') != code_hashes() or type(report.get('discovered')) is not int
        or report['discovered'] < 1 or report.get('tests_run') != report['discovered']
        or any(report.get(key) != 0 for key in ('skipped', 'errors', 'failures', 'expected_failures', 'unexpected_successes'))):
        raise RuntimeError('Every package test must execute and pass; skipped tests are not allowed')


def require_disk(run, tag):
    usage = shutil.disk_usage(run)
    report = {'status': 'PASS' if usage.free >= MINIMUM_FREE_BYTES else 'FAIL', 'checked_utc': now(),
        'free_bytes': usage.free, 'minimum_free_bytes': MINIMUM_FREE_BYTES, 'quota_checked': False,
        'note': 'Filesystem availability does not verify personal or project quota.'}
    atomic(run / (tag + '_disk.json'), report)
    if report['status'] != 'PASS': raise RuntimeError('At least 75 GiB filesystem free space is required; quotas are separate')


def current_run(arg=None): return Path(arg or read(HERE / 'LAST_RUN.json')['run_dir']).resolve()
def request_at(run):
    request = read(run / 'request.json')
    if request.get('schema') != 'ct2-production-request-v1' or request.get('code_hashes') != code_hashes():
        raise RuntimeError('The package changed after this run was created; preserve the run and prepare a separate one')
    if request.get('reviewed_evidence_digest') != EVIDENCE_DIGEST or request.get('plan_identity') != PLAN_ID:
        raise RuntimeError('Run request differs from reviewed evidence')
    return request
def command(script, *args, check=True):
    return subprocess.run([sys.executable, str(HERE / script), *map(str, args)], cwd=HERE, check=check)
def distributed(script, *args, check=True):
    return subprocess.run(['srun', '--kill-on-bad-exit=1', 'bash', str(HERE / 'runtime_python.sh'),
        '-u', str(HERE / script), *map(str, args)], cwd=HERE, check=check)


def require_prepared(run):
    request_at(run)
    report = read(run / 'prepare_status.json')
    if report.get('status') != 'PREPARATION_COMPLETE' or report.get('exit_code') != 0:
        raise RuntimeError('CPU preparation has not passed')
    for name, key in [('finite_plan.json', 'plan_sha256'), ('package_tests.json', 'package_tests_sha256'),
                      ('evaluation_inputs/evaluation_manifest.json', 'evaluation_manifest_sha256')]:
        if sha(run / name) != report.get(key): raise RuntimeError('Prepared result changed: ' + name)
    require_package_tests(read(run / 'package_tests.json'))
    from prepare_evaluation import validate_prepared_inputs
    inputs = validate_prepared_inputs(run / 'evaluation_inputs')
    if inputs.get('status') != 'EVALUATION_INPUTS_READY': raise RuntimeError('Evaluation cohorts are not ready')
    return inputs


def require_ablation(path, stage, token):
    report = read(path)
    if (report.get('schema') != 'ct2-clipping-ablation-v1' or report.get('status') not in {'HEALTHY_FINISHED', 'UNHEALTHY'}
        or report.get('plan_identity') != PLAN_ID or report.get('stage') != stage
        or report.get('clip_value') != clip_value(token) or report.get('requested_updates') != 128
        or report.get('training_ready') is not False or report.get('production_resume_allowed') is not False
        or report.get('source', {}).get('checkpoint_sha256') != read(EVIDENCE / 'finite_plan.json')['source']['checkpoint_sha256']):
        raise RuntimeError('Clipping ablation identity/status failed: ' + str(path))
    if report.get('completed_updates') != len(report.get('updates', [])):
        raise RuntimeError('Clipping ablation update records are incomplete')
    if report['status'] == 'HEALTHY_FINISHED':
        if report['completed_updates'] != 128: raise RuntimeError('Healthy ablation did not complete all requested updates')
        for key in ('host_probe_before', 'host_probe_after'):
            probe = report.get(key, {})
            if (probe.get('schema') != 'ct2-quick-host-probe-v1' or probe.get('status') != 'PASS'
                or set(probe.get('conditions', {})) != {'own', 'unknown', 'wrong'}):
                raise RuntimeError('A healthy ablation lacks a complete host-conditioning probe')
    return report


def require_matched_ablation(reports):
    for stage in (0, 3):
        group = [reports[(stage, token)] for token in CAPS]
        protocols = {r.get('data_protocol_identity') for r in group}
        if len(protocols) != 1 or None in protocols: raise RuntimeError('Ablation data protocols differ across clipping values')
        longest = max(group, key=lambda r: len(r['updates']))['updates']
        for report in group:
            for left, right in zip(report['updates'], longest):
                if not left.get('global_batch_sha256') or left['global_batch_sha256'] != right.get('global_batch_sha256'):
                    raise RuntimeError('Ablation branches consumed different batches/masks')
            pending = report.get('pending_batch_sha256')
            if pending is not None and len(report['updates']) < len(longest):
                if pending != longest[len(report['updates'])].get('global_batch_sha256'):
                    raise RuntimeError('Unhealthy ablation failed on a different pending batch')


def require_transition(path, release_id, token):
    report = read(path)
    if (report.get('schema') != 'ct2-transition-comparison-v1' or report.get('status') != 'PASS'
        or report.get('plan_identity') != PLAN_ID or report.get('release_id') != release_id
        or report.get('clip_value') != clip_value(token) or set(report.get('pairs', {})) != {'3', '8'}
        or report.get('source_checkpoint_sha256') != read(EVIDENCE / 'finite_plan.json')['source']['checkpoint_sha256']
        or report.get('cross_update_identity', {}).get('status') != 'PASS'
        or any(pair.get('status') != 'PASS' for pair in report['pairs'].values())):
        raise RuntimeError('Stage-transition replay comparison failed')
    return report


def require_evaluation(directory, inputs, checkpoint_sha, release_id, qualification):
    from epoch_evaluation import REQUIRED_METRICS
    path = directory / 'evaluation_manifest.json'; report = read(path)
    expected_status = 'QUALIFICATION_EVALUATION_COMPLETE' if qualification else 'EVALUATION_COMPLETE'
    if (report.get('schema') != 'ct2-epoch-evaluation-v1' or report.get('status') != expected_status
        or report.get('qualification') is not qualification or report.get('plan_identity') != PLAN_ID
        or report.get('release_id') != release_id or report.get('checkpoint', {}).get('sha256') != checkpoint_sha
        or report.get('input_identity') != inputs['identity_sha256']
        or report.get('requested_records', 0) <= 0 or report.get('processed_records') != report.get('requested_records')
        or report.get('requested_by_cohort') != report.get('processed_by_cohort')
        or set(report.get('conditions', [])) != {'own', 'unknown', 'wrong', 'native', 'hfc'}
        or set(report.get('required_metrics', [])) != set(REQUIRED_METRICS)
        or set(report.get('completed_metrics', [])) != set(REQUIRED_METRICS)):
        raise RuntimeError('Required epoch evaluation is incomplete or bound to another model/cohort')
    outputs = report.get('outputfiles', {})
    if set(outputs) != {'summary.json', 'by_species.jsonl'}:
        raise RuntimeError('Evaluation summary or per-species output is missing')
    for name, expected in outputs.items():
        if expected != sha(safe_child(directory, name)):
            raise RuntimeError('Evaluation summary or per-species output changed')
    input_directory = Path(inputs['frozen_reference']['path']).parent
    if report.get('input_manifest_sha256') != sha(input_directory / 'evaluation_manifest.json'):
        raise RuntimeError('Evaluation input manifest bytes changed')
    if report.get('reference_sha256') != inputs['frozen_reference']['sha256']:
        raise RuntimeError('Evaluation used a different CAI reference')
    ranks = report.get('rank_reports', [])
    if sorted(row.get('rank', -1) for row in ranks) != list(range(8)):
        raise RuntimeError('Evaluation lacks exactly eight rank reports')
    for row in ranks:
        for key in ('predictions', 'metrics'):
            part = row.get(key, {})
            if not part.get('path') or sha(safe_child(directory, part['path'])) != part.get('sha256'):
                raise RuntimeError('Evaluation rank data changed: ' + key)
    if not qualification:
        expected = {row['name']: row['records'] for row in inputs['cohorts']}
        if report.get('requested_by_cohort') != expected:
            raise RuntimeError('Full evaluation does not cover both complete fixed cohorts')
    return report


def require_qualified(run):
    inputs = require_prepared(run)
    status = read(run / 'qualification_status.json')
    if status.get('status') != 'QUALIFICATION_COMPLETE' or status.get('exit_code') != 0:
        raise RuntimeError('Qualification has not finished')
    attempt = safe_child(run, status['attempt'])
    report = read(attempt / 'qualification_report.json')
    if (sha(attempt / 'qualification_report.json') != status.get('qualification_report_sha256')
        or report.get('schema') != 'ct2-release-qualification-v1' or report.get('plan_identity') != PLAN_ID
        or set(report.get('candidates', {})) != set(CAPS)):
        raise RuntimeError('Qualification report is incomplete or changed')
    for relative, expected in report['report_hashes'].items():
        if sha(safe_child(attempt, relative)) != expected: raise RuntimeError('Qualification detail report changed: ' + relative)
    return inputs, report


def prepare_release(run, token):
    guard_submissions(run)
    inputs, qualification = require_qualified(run)
    token = clip_token(clip_value(token))
    if qualification['candidates'][token].get('selectable') is not True:
        raise RuntimeError('This clipping value did not pass both healthy ablations, transition replay and metric qualification')
    value = {'schema': 'ct2-production-release-v1', 'plan_identity': PLAN_ID, 'code_hashes': code_hashes(),
        'clip_value': clip_value(token), 'clip_token': token, 'selection': 'explicit_user_command',
        'qualification_status_sha256': sha(run / 'qualification_status.json'),
        'evaluation_input_identity': inputs['identity_sha256'], 'schedule': SCHEDULE,
        'updates': STAGE_STEPS, 'total_updates': sum(STAGE_STEPS), 'production_starts_after_full_baseline': True}
    value['release_id'] = digest(value)
    immutable(run / 'release.json', value)
    print('RELEASE_ID=' + value['release_id']); print('SELECTED_CLIP=' + token)
    print('No job submitted. submit-next will first run the full baseline evaluation.')


def require_release(run):
    inputs, qualified = require_qualified(run)
    release = read(run / 'release.json')
    if (release.get('schema') != 'ct2-production-release-v1'
        or release.get('release_id') != digest({k: v for k, v in release.items() if k != 'release_id'})
        or release.get('code_hashes') != code_hashes() or release.get('plan_identity') != PLAN_ID
        or release.get('evaluation_input_identity') != inputs['identity_sha256']
        or release.get('qualification_status_sha256') != sha(run / 'qualification_status.json')
        or release.get('schedule') != SCHEDULE or release.get('updates') != STAGE_STEPS
        or qualified['candidates'].get(release.get('clip_token'), {}).get('selectable') is not True
        or release.get('clip_value') != clip_value(release['clip_token'])):
        raise RuntimeError('Production release identity/selected clipping is invalid')
    return inputs, release


def checkpoint_receipt(run, release, check_bytes=False):
    receipt = read(run / 'train/last.json')
    path = Path(receipt['path']).resolve()
    if not path.is_relative_to((run / 'train/checkpoints').resolve()): raise RuntimeError('Training checkpoint is outside this run')
    stage = receipt.get('stage'); step = receipt.get('stage_step')
    if (receipt.get('mode') != 'production' or receipt.get('plan_identity') != PLAN_ID
        or receipt.get('release_id') != release['release_id'] or type(stage) is not int or not 0 <= stage < 4
        or receipt.get('clip_value') != release['clip_value']
        or type(step) is not int or not 0 < step <= STAGE_STEPS[stage]
        or receipt.get('completed_updates') != sum(STAGE_STEPS[:stage]) + step
        or bool(receipt.get('stage_complete')) != (step == STAGE_STEPS[stage])):
        raise RuntimeError('Training checkpoint counters or release identity are invalid')
    if receipt['stage_complete'] and receipt.get('full_dataset_verified') is not True:
        raise RuntimeError('Completed epoch lacks finite-data coverage verification')
    if not path.is_file() or (check_bytes and sha(path) != receipt['sha256']):
        raise RuntimeError('Training checkpoint is missing or changed')
    return receipt


def require_epoch_history(run, inputs, release):
    """A final completion claim requires all retained epoch checkpoints/reports."""
    completed = 0
    for stage, steps in enumerate(STAGE_STEPS):
        completed += steps
        checkpoint = run / 'train/checkpoints' / f'update_{completed:09d}.ckpt'
        receipt = read(checkpoint.with_suffix(checkpoint.suffix + '.sha256.json'))
        if (receipt.get('path') != str(checkpoint.resolve()) or receipt.get('mode') != 'production'
            or receipt.get('plan_identity') != PLAN_ID or receipt.get('release_id') != release['release_id']
            or receipt.get('clip_value') != release['clip_value'] or receipt.get('stage') != stage
            or receipt.get('stage_step') != steps or receipt.get('completed_updates') != completed
            or receipt.get('stage_complete') is not True or receipt.get('full_dataset_verified') is not True
            or not checkpoint.is_file() or checkpoint.stat().st_size != receipt.get('bytes')):
            raise RuntimeError('A retained epoch boundary checkpoint/receipt is missing or inconsistent')
        require_evaluation(run / f'evaluations/epoch_{stage + 1}', inputs, receipt['sha256'], release['release_id'], False)


def next_action(run):
    inputs, release = require_release(run)
    source = read(run / 'finite_plan.json')['source']
    baseline = run / 'evaluations/baseline'
    if not (baseline / 'evaluation_manifest.json').exists(): return {'kind': 'baseline'}
    require_evaluation(baseline, inputs, source['checkpoint_sha256'], release['release_id'], False)
    if not (run / 'train/last.json').exists(): return {'kind': 'train', 'stage': 0, 'resume': None}
    receipt = checkpoint_receipt(run, release)
    stage = receipt['stage']
    if not receipt['stage_complete']: return {'kind': 'train', 'stage': stage, 'resume': receipt['path']}
    evaluation = run / f'evaluations/epoch_{stage + 1}'
    if not (evaluation / 'evaluation_manifest.json').exists():
        return {'kind': 'evaluate', 'stage': stage, 'checkpoint': receipt['path'], 'checkpoint_sha256': receipt['sha256']}
    require_evaluation(evaluation, inputs, receipt['sha256'], release['release_id'], False)
    if stage == 3:
        require_epoch_history(run, inputs, release)
        return {'kind': 'complete'}
    return {'kind': 'train', 'stage': stage + 1, 'resume': receipt['path']}


def run_preparation(run, status):
    plan = verify_reviewed_evidence(); verify_remote_inputs(plan, hash_checkpoint=True)
    atomic(run / 'dependencies.json', dependency_check())
    command('production_workflow.py', 'package-tests', '--run-dir', run)
    require_package_tests(read(run / 'package_tests.json'))
    immutable(run / 'finite_plan.json', plan)
    command('prepare_evaluation.py', '--project-root', BASE, '--out', run / 'evaluation_inputs')
    from prepare_evaluation import validate_prepared_inputs
    manifest = validate_prepared_inputs(run / 'evaluation_inputs')
    if manifest.get('status') != 'EVALUATION_INPUTS_READY': raise RuntimeError('Evaluation preparation did not finish')
    status.update(status='PREPARATION_COMPLETE', plan_sha256=sha(run / 'finite_plan.json'),
        package_tests_sha256=sha(run / 'package_tests.json'),
        evaluation_manifest_sha256=sha(run / 'evaluation_inputs/evaluation_manifest.json'))


def run_qualification(run, status):
    inputs = require_prepared(run); require_disk(run, 'qualification_execution')
    attempt = 'qualification_' + uuid.uuid4().hex[:12]; out = run / attempt; out.mkdir()
    status['attempt'] = attempt; atomic(run / 'qualification_status.json', status)
    plan_path = run / 'finite_plan.json'; report_hashes = {}; ablations = {}
    for stage in (0, 3):
        for token in CAPS:
            directory = out / 'ablations' / f'stage_{stage}' / cap_folder(token)
            distributed('clipping_ablation.py', '--plan', plan_path, '--stage', stage,
                '--clip', token, '--updates', 128, '--output', directory)
            path = directory / 'ablation_report.json'
            ablations[(stage, token)] = require_ablation(path, stage, token)
            report_hashes[str(path.relative_to(out))] = sha(path)
    require_matched_ablation(ablations)
    candidates = {}
    for token in CAPS:
        entry = {'selectable': False, 'clip_value': clip_value(token), 'reasons': []}
        candidates[token] = entry
        if any(ablations[(stage, token)]['status'] != 'HEALTHY_FINISHED' for stage in (0, 3)):
            entry['reasons'].append('Unhealthy clipping-ablation branch'); continue
        target = out / 'transitions' / cap_folder(token)
        release_id = digest({'request_sha256': sha(run / 'request.json'), 'qualification_clip': token})
        try:
            for branch in ('reference', 'split', 'resume'):
                directory = target / branch
                args = ['--plan', plan_path, '--output', directory, '--mode', 'qualification',
                        '--branch', branch, '--release-id', release_id, '--clip', token]
                if branch == 'resume': args += ['--resume', target / 'split/checkpoints/update_000000003.ckpt']
                distributed('production_trainer.py', *args)
                report_hashes[str((directory / 'trainer_report.json').relative_to(out))] = sha(directory / 'trainer_report.json')
            compare = target / 'transition_comparison.json'
            command('compare_transition.py', '--reference3', target / 'reference/checkpoints/update_000000003.ckpt',
                '--split3', target / 'split/checkpoints/update_000000003.ckpt',
                '--reference8', target / 'reference/checkpoints/update_000000008.ckpt',
                '--resumed8', target / 'resume/checkpoints/update_000000008.ckpt',
                '--plan', plan_path, '--release-id', release_id, '--output', compare)
            require_transition(compare, release_id, token)
            report_hashes[str(compare.relative_to(out))] = sha(compare)
            checkpoint = target / 'resume/checkpoints/update_000000008.ckpt'
            evaluation = target / 'evaluation'
            distributed('epoch_evaluation.py', '--checkpoint', checkpoint, '--inputs', run / 'evaluation_inputs',
                '--output', evaluation, '--plan', plan_path, '--release-id', release_id, '--qualification')
            require_evaluation(evaluation, inputs, sha(checkpoint), release_id, True)
            for name in ('evaluation_manifest.json', 'summary.json'):
                report_hashes[str((evaluation / name).relative_to(out))] = sha(evaluation / name)
            entry.update(selectable=True, transition_status='PASS', evaluation_status='PASS')
        except Exception as error:
            entry['reasons'].append(type(error).__name__ + ': ' + str(error))
    report = {'schema': 'ct2-release-qualification-v1', 'status': 'QUALIFICATION_COMPLETE',
        'plan_identity': PLAN_ID, 'candidates': candidates, 'report_hashes': report_hashes,
        'automatic_selection': False, 'production_training_enabled': False,
        'interpretation': 'All clipping candidates attempted; only individually selectable candidates passed every required gate.'}
    atomic(out / 'qualification_report.json', report)
    status.update(status='QUALIFICATION_COMPLETE', qualification_report_sha256=sha(out / 'qualification_report.json'),
        selectable_clips=[token for token in CAPS if candidates[token]['selectable']])


def run_production_action(run, task, status):
    inputs, release = require_release(run); require_disk(run, 'production_execution')
    action = next_action(run)
    if action != task['action']: raise RuntimeError('The next training/evaluation action changed since submission')
    kind = action['kind']; plan_path = run / 'finite_plan.json'
    if kind == 'train':
        if action['resume']: checkpoint_receipt(run, release, check_bytes=True)
        args = ['--plan', plan_path, '--output', run / 'train', '--mode', 'production',
                '--stage', action['stage'], '--release-id', release['release_id'], '--clip', release['clip_token'],
                '--soft-seconds', 69000, '--checkpoint-every', 2000]
        if action['resume']: args += ['--resume', action['resume']]
        distributed('production_trainer.py', *args)
        receipt = checkpoint_receipt(run, release, check_bytes=True)
        report = read(run / 'train/trainer_report.json')
        if (report.get('schema') != 'ct2-production-trainer-report-v1' or report.get('mode') != 'production'
            or report.get('status') not in {'CHECKPOINTED_FOR_CONTINUATION', 'STAGE_COMPLETE_AWAITING_EVALUATION', 'CURRICULUM_COMPLETE'}
            or report.get('release_id') != release['release_id'] or report.get('plan_identity') != PLAN_ID
            or report.get('completed_updates') != receipt['completed_updates']):
            raise RuntimeError('Training job lacks a consistent checkpoint/report')
        status.update(status=report['status'], completed_updates=receipt['completed_updates'], stage=receipt['stage'])
    else:
        if kind == 'baseline':
            checkpoint = Path(read(plan_path)['source']['checkpoint']); expected_sha = read(plan_path)['source']['checkpoint_sha256']
            directory = run / 'evaluations/baseline'
        else:
            checkpoint = Path(action['checkpoint']); expected_sha = action['checkpoint_sha256']
            directory = run / f'evaluations/epoch_{action["stage"] + 1}'
        distributed('epoch_evaluation.py', '--checkpoint', checkpoint, '--inputs', run / 'evaluation_inputs',
            '--output', directory, '--plan', plan_path, '--release-id', release['release_id'])
        require_evaluation(directory, inputs, expected_sha, release['release_id'], False)
        status.update(status='BASELINE_EVALUATION_COMPLETE' if kind == 'baseline' else 'EPOCH_EVALUATION_COMPLETE',
            evaluation_manifest=str(directory / 'evaluation_manifest.json'))


def execute(run, task_path):
    request_at(run); task = read(task_path)
    if not os.environ.get('SLURM_JOB_ID'): raise RuntimeError('Use a submitted Slurm job for execution')
    if task.get('request_sha256') != sha(run / 'request.json'): raise RuntimeError('Task request binding changed')
    kind = task['action']['kind']
    path = run / ('prepare_status.json' if kind == 'prepare' else 'qualification_status.json' if kind == 'qualification' else 'last_job_status.json')
    status = {'status': 'RUNNING', 'kind': kind, 'job_id': os.environ['SLURM_JOB_ID'], 'started_utc': now(),
              'production_training_enabled': kind == 'train', 'task': str(task_path)}
    with (run / '.execution.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        atomic(path, status)
        try:
            plan = verify_reviewed_evidence(); verify_remote_inputs(plan)
            dependency_check()
            if kind == 'prepare': run_preparation(run, status)
            elif kind == 'qualification': run_qualification(run, status)
            else: run_production_action(run, task, status)
            status.update(exit_code=0, finished_utc=now()); result = 0
        except Exception as error:
            status.update(status='FAILED', exit_code=1, error=type(error).__name__ + ': ' + str(error), finished_utc=now()); result = 1
        atomic(path, status); atomic(task_path.parent / 'execution_status.json', status)
        try: export_results(run)
        except Exception as error:
            status.update(export_error=type(error).__name__ + ': ' + str(error), exit_code=1); atomic(path, status)
            atomic(task_path.parent / 'execution_status.json', status)
            print('EXPORT_FAILED=' + str(error), file=sys.stderr)
            result = 1
        print('STATUS=' + status['status'], flush=True)
        if status.get('error'): print(status['error'], file=sys.stderr)
        return result


def script_text(run, task_path, cpu):
    lines = ['#!/bin/bash', 'set -euo pipefail', 'module purge']
    if not cpu: lines += ['module load arch/h100']
    lines += ['module load pytorch-gpu/py3/2.6.0',
        'export PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 TOKENIZERS_PARALLELISM=false',
        'export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8',
        'export OMP_NUM_THREADS=' + ('1' if cpu else '8'), 'export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1',
        'cd ' + shlex.quote(str(HERE))]
    if not cpu:
        lines += ['export MASTER_ADDR="$(scontrol show hostnames "$SLURM_JOB_NODELIST" | sed -n \'1p\')"',
                  'export MASTER_PORT="$((15000 + SLURM_JOB_ID % 40000))"']
    lines += ['bash ' + shlex.quote(str(HERE / 'runtime_python.sh')) + ' -u ' + shlex.quote(str(HERE / 'production_workflow.py'))
              + ' run --run-dir ' + shlex.quote(str(run)) + ' --task ' + shlex.quote(str(task_path))]
    return '\n'.join(lines) + '\n'


def sbatch_args(job, kind):
    cpu = kind == 'prepare'; hours = '02:00:00' if kind in {'prepare', 'qualification'} else '20:00:00'
    shared = ['--job-name=ct2_' + kind, '--time=' + hours, '--hint=nomultithread', '--chdir=' + str(HERE),
              '--output=' + str(job / 'slurm-%j.out'), '--error=' + str(job / 'slurm-%j.err')]
    if cpu: return shared + ['--account=nef@cpu', '--partition=cpu_p1', '--qos=qos_cpu-t3', '--nodes=1', '--ntasks=1', '--cpus-per-task=8']
    return shared + ['--account=nef@h100', '--partition=gpu_p6', '--constraint=h100', '--qos=qos_gpu_h100-t3',
                     '--nodes=2', '--ntasks-per-node=4', '--gres=gpu:4', '--cpus-per-task=8']


def guard_submissions(run):
    active = subprocess.run(['squeue', '--noheader', '--user', str(os.getuid()), '--format=%i'],
                            capture_output=True, text=True, check=True)
    jobs = set(active.stdout.split())
    for path in sorted((run / 'jobs').glob('*/submission.json')):
        row = read(path)
        if row.get('status') in {'SUBMITTING', 'AMBIGUOUS'}: raise RuntimeError('Unresolved submission: ' + str(path))
        if row.get('job_id') in jobs: raise RuntimeError('A job for this run is already queued/running: ' + row['job_id'])


def submit(action, run_arg=None):
    with (HERE / '.submission.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        last = HERE / 'LAST_RUN.json'
        if last.exists(): guard_submissions(current_run())
        if action == 'prepare' and not run_arg:
            verify_reviewed_evidence()
            run = BASE / 'ct2_retrain/ct2_production_release' / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ') + '_' + uuid.uuid4().hex[:8])
            run.mkdir(parents=True, exist_ok=False)
            atomic(run / 'request.json', {'schema': 'ct2-production-request-v1', 'created_utc': now(),
                'code_hashes': code_hashes(), 'reviewed_evidence_digest': EVIDENCE_DIGEST, 'plan_identity': PLAN_ID,
                'initial_production_training_enabled': False})
        else:
            run = current_run(run_arg); guard_submissions(run); request_at(run)
        atomic(last, {'run_dir': str(run)})
        if action == 'prepare':
            if (run / 'prepare_status.json').exists() and read(run / 'prepare_status.json').get('status') == 'PREPARATION_COMPLETE':
                raise RuntimeError('CPU preparation already passed')
            choice = {'kind': 'prepare'}
        elif action == 'qualification':
            require_prepared(run)
            if (run / 'release.json').exists(): raise RuntimeError('A release was selected; do not replace its qualification')
            if (run / 'qualification_status.json').exists() and read(run / 'qualification_status.json').get('status') == 'QUALIFICATION_COMPLETE':
                raise RuntimeError('Qualification already finished; inspect clipping results and select a release')
            choice = {'kind': 'qualification'}
        else:
            choice = next_action(run)
            if choice['kind'] == 'complete': print('FOUR_PASSES_AND_ALL_EPOCH_EVALUATIONS_COMPLETE'); return
        if choice['kind'] != 'prepare': require_disk(run, 'submission')
        job = run / 'jobs' / ('job_' + uuid.uuid4().hex[:12]); job.mkdir(parents=True)
        task = {'schema': 'ct2-production-task-v1', 'action': choice, 'request_sha256': sha(run / 'request.json'), 'created_utc': now()}
        task_path = job / 'task.json'; atomic(task_path, task)
        script = job / 'job.sh'; script.write_text(script_text(run, task_path, choice['kind'] == 'prepare'))
        args = sbatch_args(job, choice['kind']); receipt = job / 'submission.json'
        checked = subprocess.run(['sbatch', '--test-only', *args, str(script)], capture_output=True, text=True)
        if checked.returncode:
            atomic(receipt, {'status': 'REJECTED_TEST_ONLY', 'stdout': checked.stdout, 'stderr': checked.stderr})
            raise RuntimeError('Slurm rejected the resource request: ' + checked.stderr)
        atomic(receipt, {'status': 'SUBMITTING', 'submitted_utc': now()})
        result = subprocess.run(['sbatch', '--parsable', *args, str(script)], capture_output=True, text=True)
        match = re.fullmatch(r'(\d+)(?:;[^\s;]+)?', result.stdout.strip())
        record = {'stdout': result.stdout, 'stderr': result.stderr, 'returncode': result.returncode, 'submitted_utc': now(), 'action': choice}
        if result.returncode or not match:
            record['status'] = 'AMBIGUOUS'; atomic(receipt, record)
            raise RuntimeError('Submission has no confirmed job ID; inspect ' + str(receipt))
        record.update(status='SUBMITTED', job_id=match.group(1)); atomic(receipt, record)
        print('RUN=' + str(run)); print('JOB=' + record['job_id']); print('ACTION=' + choice['kind'])


def export_names(run):
    names = ['request.json', 'prepare_status.json', 'qualification_status.json', 'last_job_status.json',
             'finite_plan.json', 'package_tests.json', 'dependencies.json', 'release.json',
             'evaluation_inputs/evaluation_manifest.json', 'evaluation_inputs/reference_manifest.json',
             'train/last.json', 'train/trainer_report.json',
             'qualification_execution_disk.json', 'production_execution_disk.json', 'submission_disk.json']
    q = read(run / 'qualification_status.json') if (run / 'qualification_status.json').exists() else {}
    if q.get('attempt'):
        attempt = safe_child(run, q['attempt'])
        names += [str((attempt / 'qualification_report.json').relative_to(run))]
        for stage in (0, 3):
            for token in CAPS: names += [str((attempt / 'ablations' / f'stage_{stage}' / cap_folder(token) / 'ablation_report.json').relative_to(run))]
        for token in CAPS:
            target = attempt / 'transitions' / cap_folder(token)
            names += [str((target / name).relative_to(run)) for name in (
                'transition_comparison.json', 'reference/trainer_report.json', 'split/trainer_report.json',
                'resume/trainer_report.json', 'evaluation/evaluation_manifest.json', 'evaluation/summary.json')]
    for cohort in ('baseline', 'epoch_1', 'epoch_2', 'epoch_3', 'epoch_4'):
        names += [f'evaluations/{cohort}/{name}' for name in ('evaluation_manifest.json', 'summary.json')]
    return sorted(set(names))


def export_results(run):
    names = export_names(run)
    fd, temp = tempfile.mkstemp(prefix='.export.', dir=run); os.close(fd)
    destination = run / 'production_results.zip'; total = 0; exported_hashes = {}
    try:
        with zipfile.ZipFile(temp, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for relative in names:
                path = safe_child(run, relative)
                if not path.is_file(): continue
                with path.open('rb') as f: raw = f.read(30 * 1024**2 + 1)
                total += len(raw)
                if len(raw) > 30 * 1024**2 or total > 100 * 1024**2: raise RuntimeError('Bounded report export size exceeded')
                archive.writestr(relative, raw)
                exported_hashes[relative] = hashlib.sha256(raw).hexdigest()
        os.replace(temp, destination)
    finally: Path(temp).unlink(missing_ok=True)
    atomic(run / 'export_receipt.json', {'sha256': sha(destination), 'created_utc': now(),
        'report_file_hashes': exported_hashes,
        'phase_status_hashes': {name: sha(run / name) for name in
            ('prepare_status.json', 'qualification_status.json', 'last_job_status.json') if (run / name).is_file()}})
    print('RESULTS_ZIP=' + str(destination)); return destination


def current_export(run):
    if not (run / 'export_receipt.json').is_file() or not (run / 'production_results.zip').is_file(): return False
    receipt = read(run / 'export_receipt.json')
    phases = {name: sha(run / name) for name in ('prepare_status.json', 'qualification_status.json', 'last_job_status.json')
              if (run / name).is_file()}
    reports = {name: sha(safe_child(run, name)) for name in export_names(run) if safe_child(run, name).is_file()}
    return (receipt.get('sha256') == sha(run / 'production_results.zip')
        and receipt.get('phase_status_hashes') == phases and receipt.get('report_file_hashes') == reports)


def refresh_export(run):
    # A completed computation with an export-only failure can be recovered by
    # explicitly regenerating its archive. Computational failures remain failed.
    previous = {}
    for name in ('prepare_status.json', 'qualification_status.json', 'last_job_status.json'):
        path = run / name
        if not path.is_file(): continue
        value = read(path)
        if value.get('export_error') and not value.get('error') and value.get('status') != 'FAILED':
            previous[path] = value
            updated = dict(value); updated.pop('export_error'); updated['exit_code'] = 0
            atomic(path, updated)
    try: return export_results(run)
    except Exception:
        for path, value in previous.items(): atomic(path, value)
        raise


def status(run):
    print('RUN=' + str(run))
    for name in ('prepare_status.json', 'qualification_status.json', 'last_job_status.json'):
        if (run / name).exists(): print(name + ' ' + json.dumps(read(run / name), sort_keys=True))
    if (run / 'release.json').exists():
        release = read(run / 'release.json'); print('SELECTED_CLIP=' + release['clip_token']); print('RELEASE_ID=' + release['release_id'])
    else: print('PRODUCTION_RELEASE=NOT_SELECTED')
    submissions = [read(p) for p in sorted((run / 'jobs').glob('*/submission.json'))]
    ids = [r['job_id'] for r in submissions if r.get('job_id')]
    if ids:
        result = subprocess.run(['sacct', '-j', ','.join(ids), '--format=JobID,JobName,State,ExitCode,Elapsed', '--parsable2'], capture_output=True, text=True)
        print((result.stdout or result.stderr)[-20000:])
    if (run / 'production_results.zip').exists():
        print(('RESULTS_ZIP=' if current_export(run) else 'PREVIOUS_RESULTS_ZIP=') + str(run / 'production_results.zip'))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['submit-prepare', 'submit-qualification', 'prepare-release', 'submit-next', 'status', 'export', 'run', 'package-tests'])
    parser.add_argument('--run-dir', type=Path); parser.add_argument('--task', type=Path); parser.add_argument('--clip')
    args = parser.parse_args(argv)
    try:
        if args.action.startswith('submit-'): submit(args.action[7:], args.run_dir); return 0
        run = current_run(args.run_dir)
        if args.action == 'run':
            if args.task is None: raise ValueError('--task is required')
            return execute(run, args.task)
        if args.action == 'package-tests': return package_tests(run / 'package_tests.json')
        if args.action == 'prepare-release':
            if args.clip is None: raise ValueError('An explicit --clip 0.5, 1.0 or none is required')
            with (HERE / '.submission.lock').open('a') as lock:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                prepare_release(run, args.clip)
        elif args.action == 'export': refresh_export(run)
        else: status(run)
        return 0
    except Exception as error:
        print('WORKFLOW_ERROR=' + type(error).__name__ + ': ' + str(error), file=sys.stderr); return 1


if __name__ == '__main__': raise SystemExit(main())
