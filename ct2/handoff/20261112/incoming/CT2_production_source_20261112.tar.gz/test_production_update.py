import copy
import math
import unittest

import clipping_ablation as a
import production_update as u

try:
    import torch
except ImportError:
    torch = None


class ClippingPolicyTests(unittest.TestCase):
    def test_cap_must_be_explicit_finite_positive_or_none(self):
        self.assertIsNone(u.parse_clip('none'))
        self.assertEqual(u.parse_clip('0.5'), .5)
        self.assertEqual(u.parse_clip('1'), 1.)
        for value in (True, False, 0., -1., float('nan'), float('inf'), '0.5'):
            with self.subTest(value=value), self.assertRaises((ValueError, TypeError)):
                u.validate_clip(value)

    def test_empty_and_finite_summary(self):
        self.assertEqual(a.distribution([])['count'], 0)
        value = a.distribution([1., 7., 4.])
        self.assertEqual((value['min'], value['median'], value['max'], value['mean']), (1.,4.,7.,4.))
        with self.assertRaises(FloatingPointError):
            a.distribution([1.,float('nan')])

    def test_host_probe_requires_all_three_conditions(self):
        condition = {'full_targets': 10, 'full_ce': 1.2, 'partial_targets': 3, 'partial_ce': 1.1}
        report = {'schema': 'ct2-quick-host-probe-v1', 'status':'PASS', 'panel_sha256':'a',
                  'selected_identity_sha256':'b', 'conditions':{key:dict(condition) for key in ('own','unknown','wrong')}}
        a.require_probe(report)
        bad=copy.deepcopy(report);bad['conditions'].pop('wrong')
        with self.assertRaises(ValueError): a.require_probe(bad)
        bad=copy.deepcopy(report);bad['conditions']['own']['full_ce']=float('inf')
        with self.assertRaises(FloatingPointError): a.require_probe(bad)

    def test_summary_does_not_label_null_relative_updates_as_zero(self):
        self.assertEqual(a.summarize([])['actual_parameter_updates']['species_active_rows']['relative_update_l2']['count'], 0)


@unittest.skipIf(torch is None, 'Torch unavailable locally; actual CPU gate must execute these tests')
class ClippingTorchTests(unittest.TestCase):
    def test_global_cap_preserves_relative_gradient_components(self):
        p=torch.nn.Parameter(torch.tensor([1.,2.]));p.grad=torch.tensor([3.,4.])
        norm,factor=u.clip_gradients([p],1.)
        self.assertEqual(norm,5.)
        torch.testing.assert_close(p.grad,torch.tensor([3.,4.])*factor)
        self.assertAlmostEqual(float(p.grad[0]/p.grad[1]),.75,places=6)

    def test_no_cap_preserves_gradients_but_checks_nonfinite(self):
        p=torch.nn.Parameter(torch.tensor([1.,2.]));p.grad=torch.tensor([3.,4.])
        norm,factor=u.clip_gradients([p],None)
        self.assertEqual((norm,factor),(5.,1.))
        self.assertTrue(torch.equal(p.grad,torch.tensor([3.,4.])))
        p.grad[0]=float('inf')
        with self.assertRaises(FloatingPointError):u.clip_gradients([p],None)

    def test_actual_update_tracks_active_species_rows(self):
        class Model(torch.nn.Module):
            def __init__(self):
                super().__init__();self.backbone=torch.nn.Linear(2,2,bias=False);self.species_embed=torch.nn.Embedding(3,2)
        model=Model()
        with torch.no_grad():
            model.backbone.weight.fill_(1.);model.species_embed.weight.fill_(2.)
        model.backbone.weight.grad=torch.ones_like(model.backbone.weight)
        model.species_embed.weight.grad=torch.tensor([[0.,0.],[3.,4.],[0.,0.]])
        gd,masks=u.gradient_statistics(model)
        before=u.snapshot_parameters(model)
        opt=torch.optim.SGD(model.parameters(),lr=.1);opt.step()
        delta=u.parameter_update_statistics(model,before,masks)
        self.assertEqual(gd['species_active_rows']['active_rows'],1)
        self.assertAlmostEqual(gd['species_active_rows']['parameter_l2'],math.sqrt(8.))
        self.assertAlmostEqual(delta['species_active_rows']['update_l2'],.5,places=6)
        self.assertAlmostEqual(delta['species_active_rows']['relative_update_l2'],.5/math.sqrt(8.),places=6)
        self.assertGreater(delta['species_active_rows']['relative_update_l2'],delta['species']['relative_update_l2'])

    @staticmethod
    def model():
        class Model(torch.nn.Module):
            def __init__(self):
                super().__init__();self.tok_embeddings=torch.nn.Embedding(3,3);self.species_embed=torch.nn.Embedding(2,3)
            def forward(self, ids, mask, species):
                return self.tok_embeddings(ids)+self.species_embed(species)[:,None,:]
        torch.manual_seed(71)
        return Model()

    @staticmethod
    def batch(labels):
        labels=torch.tensor(labels)
        rows=labels.shape[0]
        return {'input_ids':torch.tensor([[0,1]]*rows),'attention_mask':torch.ones(rows,2,dtype=torch.long),
                'species_id':torch.zeros(rows,dtype=torch.long),'labels':labels,
                'full':torch.zeros(rows,dtype=torch.bool),'real':torch.ones(rows,dtype=torch.bool),
                'unknown':torch.zeros(rows,dtype=torch.bool),'record_first':torch.ones(rows,dtype=torch.bool)}

    def test_accumulated_loss_uses_targets_not_microbatch_means(self):
        left=self.model();right=copy.deepcopy(left)
        a1=torch.optim.SGD(left.parameters(),lr=.1);a2=torch.optim.SGD(right.parameters(),lr=.1)
        first=self.batch([[0,-100]]);second=self.batch([[1,2]])
        combined={k:torch.cat((first[k],second[k]),dim=0) for k in first}
        m1,*_=u.optimizer_update(left,a1,[first,second],torch.device('cpu'),.1,None)
        m2,*_=u.optimizer_update(right,a2,[combined],torch.device('cpu'),.1,None)
        self.assertEqual(m1[1]+m1[3],3)
        for x,y in zip(left.parameters(),right.parameters()):torch.testing.assert_close(x,y,atol=1e-7,rtol=1e-6)
        self.assertAlmostEqual(m1[0],m2[0],places=6)

    def test_dummy_batch_does_not_add_targets_or_records(self):
        model=self.model();opt=torch.optim.SGD(model.parameters(),lr=.1)
        real=self.batch([[1,2]]);dummy=self.batch([[-100,-100]])
        dummy['real'].fill_(False);dummy['record_first'].fill_(False)
        metrics,norm,factor,targets,details=u.optimizer_update(model,opt,[real,dummy],torch.device('cpu'),.1,.5,measure_update=True)
        self.assertEqual((targets,metrics[4],metrics[8]),(2,1.,1.))
        self.assertTrue(details['model_finite'] and details['optimizer_finite'])
        self.assertGreater(details['actual_parameter_update']['token_embedding']['update_l2'],0.)

    def test_batch_trace_binds_labels_hosts_and_order(self):
        batch=self.batch([[1,2]])
        raw=[[{'identity':'gene1:window0'}]]
        one=a.batch_digest(raw,[batch]);self.assertEqual(one,a.batch_digest(raw,[copy.deepcopy(batch)]))
        changed=copy.deepcopy(batch);changed['species_id'][0]=1
        self.assertNotEqual(one,a.batch_digest(raw,[changed]))
        changed=copy.deepcopy(batch);changed['labels'][0,0]=2
        self.assertNotEqual(one,a.batch_digest(raw,[changed]))
        self.assertNotEqual(one,a.batch_digest([[{'identity':'gene2:window0'}]],[batch]))


if __name__ == '__main__': unittest.main()
