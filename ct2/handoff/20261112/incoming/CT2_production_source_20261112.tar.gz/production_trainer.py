#!/usr/bin/env python3
"""Finite CT2 stages with optimizer carry, committed-stream restart and immutable saves.

Production invocations run one explicitly selected stage. Stage evaluation and
submission authorization belong to production_workflow.py. Qualification uses
the same update/transition/save code with two real-data prefix updates per stage;
those prefixes never claim full-data coverage and cannot resume production.
"""
from __future__ import annotations
import argparse
import copy
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import sys
import time
import uuid

from candidate_model import (SOURCE_CHECKPOINT_SHA256, build_from_state, load_source,
    new_optimizer, sha, tokenizer_at, validate_plan_identity, validate_repo)
from candidate_collator import CandidateCollator
from gpu_preflight import (atomic_json, ddp_policy, gather, initialize,
    rank0_action, restore_rng, rng_state, seed_all, stage_spec, verify_optimizer)

FORMAT = 'ct2-production-v1'
LR_POLICY = {'schema': 'ct2-stage-cosine-v1', 'anchors': [2e-5, 5e-6, 2e-6, 1e-6, 1e-7],
             'initial_warmup_updates': 1000, 'initial_warmup_start': 2e-6,
             'scope': 'Production proposal; not claimed sweep-optimal'}
QUALIFICATION_STEPS = [2, 2, 2, 2]
STAT_KEYS = ('updates', 'real_windows', 'physical_records', 'known_targets',
    'partial_targets', 'full_targets', 'partial_loss_sum', 'full_loss_sum',
    'tokens_seen', 'full_windows', 'unknown_windows', 'clipped_updates',
    'grad_norm_sum', 'grad_norm_sq_sum', 'grad_norm_max', 'clipping_factor_sum')
IDENTITY_FILES = ('production_trainer.py', 'candidate_model.py', 'candidate_collator.py',
    'gpu_preflight.py', 'finite_pipeline.py', 'finite_plan.py', 'census.py',
    'derive_budget.py', 'execution_profile.py', 'production_update.py')


def trainer_identity():
    root = Path(__file__).resolve().parent
    values = {name: sha(root / name) for name in IDENTITY_FILES}
    return hashlib.sha256(json.dumps(values, sort_keys=True).encode()).hexdigest()


def effective_steps(plan, mode):
    if mode == 'qualification': return list(QUALIFICATION_STEPS)
    if mode == 'production': return [int(stage['steps']) for stage in plan['stages']]
    raise ValueError('Unknown trainer mode')


def learning_rate(stage, stage_step, steps):
    """Rate for the next update, numbered one through the stage's fixed budget."""
    if not 0 <= stage < 4 or type(stage_step) is not int or not 1 <= stage_step <= steps:
        raise ValueError('Invalid scheduler position')
    anchors = LR_POLICY['anchors']; start, finish = anchors[stage:stage + 2]
    if steps < 3:
        # Qualification exercises explicit transitions, not a compressed claim
        # about the production schedule's 1000-update warmup.
        fraction = (stage_step - 1) / max(steps - 1, 1)
    elif stage == 0:
        warm = min(LR_POLICY['initial_warmup_updates'], steps - 1)
        if stage_step <= warm:
            fraction = (stage_step - 1) / max(warm - 1, 1)
            return LR_POLICY['initial_warmup_start'] + fraction * (start - LR_POLICY['initial_warmup_start'])
        fraction = (stage_step - warm) / (steps - warm)
    else:
        fraction = (stage_step - 1) / max(steps - 1, 1)
    return finish + (start - finish) * .5 * (1. + math.cos(math.pi * fraction))


def blank_statistics():
    return [{key: 0 for key in STAT_KEYS} for _ in range(4)]


def add_statistics(stat, metrics, norm, factor, known_targets):
    if len(metrics) != 9 or not all(math.isfinite(float(x)) for x in [*metrics, norm, factor]):
        raise ValueError('Nonfinite or malformed update metrics')
    if norm < 0 or not 0 < factor <= 1 or type(known_targets) is not int or known_targets < 1:
        raise ValueError('Invalid gradient/target metric')
    increments = dict(updates=1, partial_loss_sum=metrics[0], partial_targets=int(metrics[1]),
        full_loss_sum=metrics[2], full_targets=int(metrics[3]), real_windows=int(metrics[4]),
        tokens_seen=int(metrics[5]), full_windows=int(metrics[6]), unknown_windows=int(metrics[7]),
        physical_records=int(metrics[8]), known_targets=known_targets,
        clipped_updates=int(factor < 1.), grad_norm_sum=norm,
        grad_norm_sq_sum=norm * norm, clipping_factor_sum=factor)
    for key, value in increments.items(): stat[key] += value
    stat['grad_norm_max'] = max(stat['grad_norm_max'], norm)
    if stat['partial_targets'] + stat['full_targets'] > stat['known_targets']:
        raise ValueError('Selected targets exceed visited known-target opportunities')


def validate_progress(checkpoint, plan, mode, release_id, expected_clip='unchecked'):
    if checkpoint.get('format') != FORMAT or checkpoint.get('mode') != mode:
        raise ValueError('Checkpoint format/mode mismatch; qualification is never production')
    if checkpoint.get('plan_identity') != plan['identity'] or checkpoint.get('release_id') != release_id:
        raise ValueError('Checkpoint plan/release identity changed')
    if checkpoint.get('trainer_identity') != trainer_identity() or checkpoint.get('lr_policy') != LR_POLICY:
        raise ValueError('Trainer code or learning-rate policy changed')
    if checkpoint.get('world_size') != 8 or checkpoint.get('padding_policy') != 'fixed_stage_max_length':
        raise ValueError('World size or padding policy changed')
    if 'clip_value' not in checkpoint or (checkpoint['clip_value'] is not None and
            (type(checkpoint['clip_value']) not in (int, float) or not math.isfinite(checkpoint['clip_value']) or checkpoint['clip_value'] <= 0)):
        raise ValueError('Missing or invalid explicit gradient clipping policy')
    if expected_clip != 'unchecked' and checkpoint['clip_value'] != expected_clip:
        raise ValueError('Gradient clipping policy changed across restart')
    stage, step = checkpoint.get('stage'), checkpoint.get('stage_step')
    steps = effective_steps(plan, mode)
    if type(stage) is not int or not 0 <= stage < 4 or type(step) is not int or not 1 <= step <= steps[stage]:
        raise ValueError('Invalid stage progress')
    if checkpoint.get('stage_complete') is not (step == steps[stage]):
        raise ValueError('Stage completion marker disagrees with its update budget')
    if checkpoint.get('completed_updates') != sum(steps[:stage]) + step:
        raise ValueError('Global optimizer age disagrees with stage progress')
    if checkpoint.get('full_dataset_verified') is not (mode == 'production' and step == steps[stage]):
        raise ValueError('Full-dataset completion claim is invalid')
    if checkpoint.get('production_resume_allowed') is not (mode == 'production'):
        raise ValueError('Checkpoint production-resume marker disagrees with its mode')
    source = checkpoint.get('source', {})
    if source.get('checkpoint_sha256') != SOURCE_CHECKPOINT_SHA256 or source.get('imported_model_only') is not True:
        raise ValueError('Missing weights-only source provenance')
    if source.get('optimizer_age_at_import') != 0 or source.get('source_global_step') != 120000:
        raise ValueError('Source and current optimizer ages are confused')
    if any(source.get(k) != v for k, v in plan['source'].items()):
        raise ValueError('Checkpoint source provenance differs from the finite plan')
    stats = checkpoint.get('statistics')
    if not isinstance(stats, list) or len(stats) != 4:
        raise ValueError('Missing bounded stage statistics')
    for i, stat in enumerate(stats):
        if set(stat) != set(STAT_KEYS) or any(not isinstance(x, (int, float)) or not math.isfinite(x) or x < 0 for x in stat.values()):
            raise ValueError('Malformed stage statistics')
        expected_updates = steps[i] if i < stage else step if i == stage else 0
        if stat['updates'] != expected_updates:
            raise ValueError('Stage statistics have an inconsistent update count')
        if mode == 'production' and (i < stage or i == stage and checkpoint['stage_complete']):
            for key, plan_key in [('real_windows', 'windows'), ('physical_records', 'records'), ('known_targets', 'known_targets')]:
                if stat[key] != plan['stages'][i][plan_key]:
                    raise ValueError('Completed stage coverage does not match census: ' + key)
    states = checkpoint.get('rank_states')
    if not isinstance(states, list) or len(states) != 8 or [s.get('rank') for s in states] != list(range(8)):
        raise ValueError('Missing or reordered rank checkpoint states')
    reconcile_streams(states, stats[stage], plan['stages'][stage],
                      complete=(mode == 'production' and checkpoint['stage_complete']))
    return checkpoint


def reconcile_streams(states, stat, spec, complete=False):
    for stream_key, stat_key in [('committed_windows', 'real_windows'),
            ('committed_records', 'physical_records'), ('committed_known_targets', 'known_targets')]:
        if sum(row['stream'][stream_key] for row in states) != stat[stat_key]:
            raise ValueError('Committed loader count differs from trained count: ' + stat_key)
    if complete:
        if any(row['stream']['next_active_lanes'] or
               any(not lane['validated_complete'] for lane in row['stream']['lanes']) for row in states):
            raise ValueError('A completed production stage has unvalidated data lanes')
        for key, plan_key in [('real_windows', 'windows'), ('physical_records', 'records'), ('known_targets', 'known_targets')]:
            if stat[key] != spec[plan_key]: raise ValueError('Full-pass coverage differs from census: ' + key)


def resume_position(checkpoint, requested_stage, mode):
    if checkpoint is None:
        if mode == 'production' and requested_stage != 0: raise ValueError('Fresh production starts at stage 0')
        return 0, 0, False
    stage, step = checkpoint['stage'], checkpoint['stage_step']
    boundary = checkpoint['stage_complete']
    if boundary: stage, step = stage + 1, 0
    if stage >= 4: raise ValueError('The curriculum is already complete')
    if mode == 'production' and requested_stage != stage:
        raise ValueError('Explicit stage does not match checkpoint continuation')
    return stage, step, boundary


def checkpoint_path(output, completed):
    return Path(output) / 'checkpoints' / f'update_{completed:09d}.ckpt'


def read_checkpoint(path):
    import torch
    path = Path(path).resolve()
    receipt_path = path.with_suffix(path.suffix + '.sha256.json')
    receipt = json.loads(receipt_path.read_text())
    if receipt.get('path') != str(path) or receipt.get('sha256') != sha(path):
        raise ValueError('Checkpoint checksum receipt is absent or invalid')
    return torch.load(path, map_location='cpu', weights_only=False, mmap=True)


def prune_owned_intermediates(output, latest):
    """Keep three intermediates and every stage endpoint in this new run only."""
    output = Path(output)
    directory = output / 'checkpoints'
    if latest['mode'] != 'production': return []
    if output.is_symlink() or directory.is_symlink() or not directory.is_dir():
        raise ValueError('Refusing retention through a symlinked checkpoint directory')
    directory = directory.resolve()
    owned = []
    for receipt_path in directory.glob('update_*.ckpt.sha256.json'):
        if receipt_path.is_symlink(): continue
        receipt = json.loads(receipt_path.read_text())
        path = Path(receipt.get('path', ''))
        if (receipt.get('format') != FORMAT or receipt.get('mode') != 'production'
            or any(receipt.get(k) != latest[k] for k in ('plan_identity', 'release_id', 'trainer_identity'))
            or path.parent != directory or path.is_symlink() or not path.is_file()
            or receipt_path != path.with_suffix(path.suffix + '.sha256.json')
            or type(receipt.get('completed_updates')) is not int
            or type(receipt.get('stage_complete')) is not bool):
            continue
        owned.append((receipt, path, receipt_path))
    intermediates = sorted((row for row in owned if not row[0]['stage_complete']),
                           key=lambda row: row[0]['completed_updates'], reverse=True)
    if len(intermediates) <= 3: return []
    protected = {str(path) for _, path, _ in intermediates[:3]}
    protected.add(latest['path'])
    # Evaluation only uses stage endpoints in the standard workflow. Protect any
    # additionally referenced local checkpoint, rather than assuming this.
    manifests = list(output.parent.glob('**/evaluation_manifest.json'))
    if len(manifests) > 128: return []  # A crowded/custom layout is left untouched.
    def paths_in(value):
        if isinstance(value, dict):
            for key, child in value.items():
                if key in {'checkpoint', 'checkpoint_path', 'path'} and isinstance(child, str):
                    protected.add(child)
                paths_in(child)
        elif isinstance(value, list):
            for child in value: paths_in(child)
    for manifest in manifests:
        if manifest.is_symlink() or manifest.stat().st_size > 4 * 1024 * 1024: return []
        paths_in(json.loads(manifest.read_text()))
    verified = []
    for receipt, path, _ in owned:
        if str(path) == latest['path'] or str(path) in protected:
            if path.stat().st_size != receipt['bytes'] or sha(path) != receipt['sha256']:
                raise ValueError('Retained latest/fallback checkpoint failed integrity verification')
            verified.append(str(path))
    if latest['path'] not in verified or len(verified) < 2:
        raise ValueError('Retention requires a verified latest checkpoint and fallback')
    removed = []
    for receipt, path, receipt_path in intermediates[3:]:
        if str(path) in protected: continue
        if path.stat().st_size != receipt['bytes'] or sha(path) != receipt['sha256']: continue
        record = {'action': 'remove_owned_intermediate', 'checkpoint': str(path),
            'sha256': receipt['sha256'], 'completed_updates': receipt['completed_updates'],
            'kept_latest': latest['path'], 'kept_verified_fallbacks': verified,
            'policy': 'newest_three_intermediates_plus_all_stage_endpoints'}
        with (output / 'retention.jsonl').open('a') as log:
            log.write(json.dumps(record, sort_keys=True) + '\n'); log.flush(); os.fsync(log.fileno())
        path.unlink(); receipt_path.unlink(); removed.append(str(path))
    return removed


def save_checkpoint(output, model, optimizer, names, pipeline, plan, mode, branch,
                    stage, stage_step, completed, statistics, source, versions,
                    policy, release_id, clip_value):
    import torch
    import torch.distributed as dist
    from execution_profile import assert_profile
    states = gather({'rank': dist.get_rank(), 'stream': pipeline.state_dict(), 'rng': rng_state()})
    complete = stage_step == effective_steps(plan, mode)[stage]
    reconcile_streams(states, statistics[stage], plan['stages'][stage], mode == 'production' and complete)
    verify_optimizer(optimizer, completed, names, names)
    value = {'format': FORMAT, 'mode': mode, 'branch': branch, 'plan_identity': plan['identity'],
        'release_id': release_id, 'trainer_identity': trainer_identity(),
        'stage': stage, 'stage_step': stage_step, 'stage_complete': complete,
        'completed_updates': completed, 'source': source, 'world_size': 8,
        'state_dict': model.state_dict(), 'model_config': model.model.config.to_dict(),
        'species_embed_scale': model.scale, 'optimizer_state': optimizer.state_dict(),
        'optimizer_parameter_names': names, 'rank_states': states,
        'execution_settings': assert_profile(model), 'ddp_policy': policy,
        'padding_policy': 'fixed_stage_max_length', 'statistics': copy.deepcopy(statistics),
        'runtime_versions': versions, 'lr_policy': copy.deepcopy(LR_POLICY),
        'clip_value': clip_value,
        'full_dataset_verified': mode == 'production' and complete,
        'production_resume_allowed': mode == 'production'}
    validate_progress(value, plan, mode, release_id, clip_value)
    path = checkpoint_path(output, completed)
    def write():
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists(): raise FileExistsError('Immutable checkpoint already exists: ' + str(path))
        temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
        try:
            with temporary.open('xb') as stream:
                torch.save(value, stream); stream.flush(); os.fsync(stream.fileno())
            os.link(temporary, path)  # Atomic publication without overwriting any checkpoint.
        finally:
            temporary.unlink(missing_ok=True)
        receipt = {'path': str(path.resolve()), 'sha256': sha(path), 'bytes': path.stat().st_size,
            'format': FORMAT, 'mode': mode, 'plan_identity': plan['identity'], 'release_id': release_id,
            'trainer_identity': value['trainer_identity'], 'stage': stage, 'stage_step': stage_step,
            'stage_complete': complete, 'completed_updates': completed,
            'clip_value': clip_value,
            'full_dataset_verified': value['full_dataset_verified']}
        atomic_json(path.with_suffix(path.suffix + '.sha256.json'), receipt)
        atomic_json(Path(output) / 'last.json', receipt)
        prune_owned_intermediates(output, receipt)
        return receipt
    return rank0_action(write)


def _all_stop(local_stop, device):
    import torch
    import torch.distributed as dist
    flag = torch.tensor(int(local_stop), dtype=torch.int64, device=device)
    dist.all_reduce(flag, op=dist.ReduceOp.MAX)
    return bool(flag)


def _open_pipeline(plan, stage, rank, checkpoint_state=None):
    from finite_pipeline import FinitePipeline
    stream = FinitePipeline(plan, stage, rank, resume_state=checkpoint_state)
    expected = sum(not row['validated_complete'] for row in stream.state_dict()['lanes'])
    workers = list(stream.worker_pids.values())
    if len(workers) != expected or len(workers) != len(set(workers)) or any(type(p) is not int or p <= 0 for p in workers):
        stream.close(); raise RuntimeError('Actual worker count differs from uncompleted planned lanes')
    return stream


def run(args):
    import torch
    import torch.distributed as dist
    from torch.nn.parallel import DistributedDataParallel
    from execution_profile import assert_profile, validate_snapshot
    from finite_plan import validate_plan
    from production_update import optimizer_update
    start = time.monotonic()
    plan = json.loads(Path(args.plan).read_text()); validate_plan(plan); validate_plan_identity(plan)
    for stage in range(4): stage_spec(plan, stage)
    steps = effective_steps(plan, args.mode)
    device, rank, versions, hosts = initialize()
    output = Path(args.output).resolve(); lock = None; pipeline = None; update_log = None
    stop_request = [False]
    def request_stop(*_): stop_request[0] = True
    for signum in (signal.SIGTERM, signal.SIGUSR1): signal.signal(signum, request_stop)
    def prepare():
        nonlocal lock
        output.mkdir(parents=True, exist_ok=True)
        lock = (output / '.trainer.lock').open('a')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if not args.resume and (output / 'last.json').exists():
            raise FileExistsError('Output already contains a training checkpoint; use its verified resume path')
        if args.mode == 'production' and args.resume:
            last = json.loads((output / 'last.json').read_text())
            if last.get('path') != str(args.resume.resolve()):
                raise ValueError('Production must continue its current last.json checkpoint; stale/forked resumes are not implicit')
        if args.mode == 'qualification' and (output / 'trainer_report.json').exists():
            raise FileExistsError('Qualification branch output already exists')
    rank0_action(prepare)
    invocation = rank0_action(lambda: uuid.uuid4().hex[:12])
    update_log_name = 'updates_' + invocation + '.jsonl'
    def open_update_log():
        nonlocal update_log
        update_log = (output / update_log_name).open('x', buffering=1)
    rank0_action(open_update_log)
    stats, completed = blank_statistics(), 0
    checkpoint = None; last_receipt = None
    try:
        if args.resume:
            checkpoint = read_checkpoint(args.resume)
            validate_progress(checkpoint, plan, args.mode, args.release_id, args.clip)
            if checkpoint.get('runtime_versions') != versions:
                raise ValueError('Runtime versions changed across checkpoint restart')
            repo, _ = validate_repo(plan['source']); tokenizer = tokenizer_at(repo)
            validate_snapshot(checkpoint['execution_settings'])
            model = build_from_state(checkpoint['model_config'], checkpoint['state_dict'],
                checkpoint['species_embed_scale'], tokenizer, device)
            source = checkpoint['source']; completed = checkpoint['completed_updates']
            stats = copy.deepcopy(checkpoint['statistics'])
        else:
            if rank0_action(lambda: sha(plan['source']['checkpoint'])) != SOURCE_CHECKPOINT_SHA256:
                raise ValueError('Initial source checkpoint checksum changed')
            model, tokenizer, source = load_source(plan, device, verify_checkpoint_hash=False)
        if any(item != source for item in gather(source)): raise ValueError('Ranks loaded different source provenance')
        optimizer, names = new_optimizer(model)
        if checkpoint:
            optimizer.load_state_dict(checkpoint['optimizer_state'])
            verify_optimizer(optimizer, completed, names, checkpoint['optimizer_parameter_names'])
        elif optimizer.state:
            raise ValueError('Fresh curriculum optimizer unexpectedly has moments')
        ddp = DistributedDataParallel(model, device_ids=[device.index],
            find_unused_parameters=True, static_graph=False, broadcast_buffers=False)
        policy = ddp_policy(ddp)
        if any(item != policy for item in gather(policy)): raise ValueError('Ranks created different DDP bucket policies')
        if checkpoint and checkpoint['ddp_policy'] != policy: raise ValueError('DDP policy changed across restart')
        stage, stage_step, boundary = resume_position(checkpoint, args.stage, args.mode)
        pending_rng = checkpoint['rank_states'][rank]['rng'] if checkpoint else None
        pending_stream = checkpoint['rank_states'][rank]['stream'] if checkpoint and not boundary else None
        del checkpoint
        run_stages = [stage] if args.mode == 'production' else list(range(stage, 4))
        torch.cuda.reset_peak_memory_stats(device)
        worker_reports = []
        outcome = None
        for stage in run_stages:
            spec = plan['stages'][stage]
            pipeline = _open_pipeline(plan, stage, rank, pending_stream)
            worker_reports.append(gather({'rank': rank, 'stage': stage,
                'configured_workers': spec['num_workers'], 'active_workers': len(pipeline.worker_pids)}))
            collator = CandidateCollator(tokenizer, seed=plan['seed'], rank=rank, stage=stage,
                                        unknown_probability=spec['unknown_species_probability'])
            if pending_rng is None: seed_all(plan['seed'] + rank)
            else: restore_rng(pending_rng)
            pending_rng = pending_stream = None
            while stage_step < steps[stage]:
                tick = time.monotonic(); batches = []; local_known = 0
                for micro in range(spec['accumulation']):
                    rows = pipeline.next_batch(); local_known += sum(row['known_targets'] for row in rows)
                    batches.append(collator(rows, spec['max_length'], spec['full_mask_probability'], stage_step, micro))
                lr = learning_rate(stage, stage_step + 1, steps[stage])
                metrics, norm, factor, local_targets, update_diagnostics = optimizer_update(
                    ddp, optimizer, batches, device, lr, args.clip, measure_update=False)
                del batches
                known = torch.tensor(local_known, dtype=torch.int64, device=device); dist.all_reduce(known)
                stage_step += 1; completed += 1
                add_statistics(stats[stage], metrics, norm, factor, int(known))
                assert_profile(model)
                if ddp_policy(ddp) != policy: raise RuntimeError('Audited DDP policy changed during training')
                stopped = _all_stop(stop_request[0] or time.monotonic() - start >= args.soft_seconds, device)
                stage_complete = stage_step == steps[stage]
                split_stop = args.mode == 'qualification' and args.branch == 'split' and completed == 3
                save = (stage_complete or stopped or split_stop or completed % args.checkpoint_every == 0
                        or args.mode == 'qualification' and completed == 3)
                if rank == 0:
                    record = {'completed_updates': completed, 'stage': stage, 'stage_step': stage_step,
                        'learning_rate': lr, 'preclip_norm': norm, 'clipping_factor': factor,
                        'clip_value': args.clip,
                        'partial_loss_sum': metrics[0], 'full_loss_sum': metrics[2],
                        'partial_targets': int(metrics[1]), 'full_targets': int(metrics[3]),
                        'partial_ce': metrics[0] / metrics[1] if metrics[1] else None,
                        'full_ce': metrics[2] / metrics[3] if metrics[3] else None,
                        'global_ce': (metrics[0] + metrics[2]) / (metrics[1] + metrics[3]),
                        'full_target_share': metrics[3] / (metrics[1] + metrics[3]),
                        'real_windows': int(metrics[4]), 'physical_records': int(metrics[8]),
                        'full_windows': int(metrics[6]), 'unknown_windows': int(metrics[7]),
                        'known_targets': int(known), 'update_seconds': time.monotonic() - tick}
                    update_log.write(json.dumps(record, allow_nan=False) + '\n')
                    if completed % 50 == 0 or save:
                        print('CT2_PRODUCTION_UPDATE ' + json.dumps(record), flush=True)
                if save:
                    if rank == 0:
                        update_log.flush(); os.fsync(update_log.fileno())
                    last_receipt = save_checkpoint(output, model, optimizer, names, pipeline, plan,
                        args.mode, args.branch, stage, stage_step, completed, stats, source,
                        versions, policy, args.release_id, args.clip)
                if stopped or split_stop:
                    outcome = 'QUALIFICATION_SPLIT_COMPLETE' if split_stop else 'CHECKPOINTED_FOR_CONTINUATION'
                    break
            if outcome: break
            if args.mode == 'production':
                outcome = 'CURRICULUM_COMPLETE' if stage == 3 else 'STAGE_COMPLETE_AWAITING_EVALUATION'
                break
            # Worker construction at the next length is an implementation detail,
            # never a new training seed. Restore the exact pre-transition RNG.
            pending_rng = rng_state()
            pipeline.close(); pipeline = None; stage_step = 0
        if outcome is None: outcome = 'QUALIFICATION_BRANCH_COMPLETE'
        memory = gather({'rank': rank, 'peak_allocated_bytes': torch.cuda.max_memory_allocated(device),
            'peak_reserved_bytes': torch.cuda.max_memory_reserved(device)})
        if last_receipt is None: raise RuntimeError('Trainer completed without a committed checkpoint')
        report = {'schema': 'ct2-production-trainer-report-v1', 'status': outcome, 'mode': args.mode,
            'branch': args.branch, 'plan_identity': plan['identity'], 'release_id': args.release_id,
            'trainer_identity': trainer_identity(), 'stage': last_receipt['stage'],
            'update_log': update_log_name,
            'stage_step': last_receipt['stage_step'], 'completed_updates': completed,
            'source': source, 'checkpoint': last_receipt, 'statistics': stats,
            'runtime_versions': versions, 'topology': hosts, 'ddp_policy': policy,
            'memory': memory, 'workers': worker_reports, 'lr_policy': LR_POLICY,
            'clip_value': args.clip,
            'full_dataset_verified': last_receipt['full_dataset_verified'],
            'training_ready': False, 'scope': 'Production stages require external epoch-evaluation gates; qualification uses real-data prefixes only.'}
        rank0_action(lambda: atomic_json(output / 'trainer_report.json', report))
        dist.barrier()
        return report
    finally:
        if pipeline is not None: pipeline.close()
        if update_log is not None: update_log.close()
        if lock is not None: lock.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--mode', choices=['production', 'qualification'], required=True)
    parser.add_argument('--release-id', required=True)
    parser.add_argument('--clip', required=True, help='Explicit positive norm cap or none; immutable across resume')
    parser.add_argument('--stage', type=int, choices=range(4))
    parser.add_argument('--branch', choices=['reference', 'split', 'resume'], default='reference')
    parser.add_argument('--resume', type=Path)
    parser.add_argument('--soft-seconds', type=float, default=6600.)
    parser.add_argument('--checkpoint-every', type=int, default=2000)
    args = parser.parse_args(argv)
    try:
        args.clip = None if args.clip.lower() == 'none' else float(args.clip)
        if args.clip is not None and (not math.isfinite(args.clip) or args.clip <= 0): raise ValueError()
    except ValueError: parser.error('--clip must be a positive finite number or none')
    if args.mode == 'production' and args.stage is None: parser.error('Production requires an explicit --stage')
    if args.mode == 'qualification' and ((args.branch == 'resume') != bool(args.resume)):
        parser.error('Qualification resume branch requires --resume; other branches prohibit it')
    if not args.release_id or not math.isfinite(args.soft_seconds) or args.soft_seconds < 60 or args.checkpoint_every < 1:
        parser.error('Invalid release identity, soft walltime or checkpoint interval')
    try:
        report = run(args)
        print('CT2_TRAINER_STATUS=' + report['status'], flush=True)
        return 0
    except Exception as error:
        if os.environ.get('SLURM_PROCID', '0') == '0':
            atomic_json(args.output / 'trainer_failure.json', {'status': 'FAILED',
                'error': type(error).__name__ + ': ' + str(error), 'mode': args.mode,
                'training_ready': False})
        print(type(error).__name__ + ': ' + str(error), file=sys.stderr, flush=True)
        return 1
    finally:
        try:
            import torch.distributed as dist
            if dist.is_initialized(): dist.destroy_process_group()
        except ImportError:
            pass


if __name__ == '__main__': raise SystemExit(main())
