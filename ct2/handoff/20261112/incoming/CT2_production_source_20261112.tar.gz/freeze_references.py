#!/usr/bin/env python3
"""Freeze the retained historical CAI reference; never scan training shards."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import fcntl
import hashlib
import itertools
import json
import math
import numbers
import os
from pathlib import Path
import sys
import tempfile

BASE = Path('/lustre/fswork/projects/rech/nef/unh87ms')
PREFIX = 'cai_top10csi_train_w8_ct1_vs_ct2_all_trunc2046_common_valid'
RARE_PREFIX = 'cai_top10csi_train_w8_rare_ct1_vs_ct2_all_trunc2046_common_valid'
PATHS = {
    'standard_selected': f'CodonTransformerV2/{PREFIX}_top10csi_train_reference_genes.parquet',
    'rare_selected': f'CodonTransformerV2/{RARE_PREFIX}_top10csi_train_reference_genes.parquet',
    'standard_summary': f'CodonTransformerV2/{PREFIX}_top10csi_train_reference_summary_by_species.csv',
    'rare_summary': f'CodonTransformerV2/{RARE_PREFIX}_top10csi_train_reference_summary_by_species.csv',
    'codon_table': 'CodonTransformerV2/ct2_codon_usage_tables_qc/ct2_train_species_codon_frequencies_clean.parquet',
    'mapping': 'CodonTransformerV2/ct2_production_20260930_v4/source/species_to_id.json',
    'panel': 'CodonTransformerV2/ct2_production_20260930_v4/source/eval_panel.jsonl',
}
SUMMARY_SHA256 = '5a9501802cc18b76567df6d8fcba3ba42b7f0c618bb5d43bec328f3066f9df47'
SCRIPT_HASHES = {
    'eval_cai_top10csi_train_reference_safe_w8.py': '5b4cfe3c891c23697ce67d8c80fa3535f7bb1796c5dcf0a47975f8b3f406d099',
    'eval_cai_top10csi_train_reference_safe_w8_rare.py': '8138e2ed596b1df475c698598bac869d2016e8e5f983a7e705ec7c3b550e36d9',
}
CODE = dict(zip((''.join(x) for x in itertools.product('TCAG', repeat=3)),
                'FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG'))
SENSE_CODONS = sorted(c for c, aa in CODE.items() if aa != '*')
IUPAC = set('ACGTRYSWKMBDHVN')
SELECTED_COLUMNS = ['species', 'genome_id', 'protein_id', 'dna', 'protein_len',
                    'formal_csi', 'codons_total', 'missing_weight_frac']
TABLE_COLUMNS = ['species', 'aa', 'codon', 'frequency', 'rare_lt_0_001', 'rare_lt_0_01']
SCHEMA = 'ct2-frozen-legacy-cai-v1'


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def atomic_json(path, value):
    path = Path(path)
    with tempfile.NamedTemporaryFile(mode='w', dir=path.parent, prefix='.' + path.name + '.', delete=False) as f:
        temporary = Path(f.name)
        try:
            json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)
            f.write('\n'); f.flush(); os.fsync(f.fileno())
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def reject_json_constant(value):
    raise ValueError('Nonfinite JSON constant: ' + value)


def json_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


def parse_json(text):
    return json.loads(text, parse_constant=reject_json_constant, object_pairs_hook=json_object)


def fingerprint(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError('Required regular source file missing or symlinked: ' + str(path))
    before = path.stat()
    digest = sha(path)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns, before.st_ino, before.st_dev) != (
            after.st_size, after.st_mtime_ns, after.st_ino, after.st_dev):
        raise ValueError('Source changed during hashing: ' + str(path))
    return {'path': str(path.resolve()), 'size_bytes': after.st_size,
            'mtime_ns': after.st_mtime_ns, 'sha256': digest}


def checked_sources(project, expected_summary_hash, expected_script_hashes):
    sources = {key: fingerprint(project / rel) for key, rel in PATHS.items()}
    for key in ('standard_summary', 'rare_summary'):
        if sources[key]['sha256'] != expected_summary_hash:
            raise ValueError('Historical reference summary differs from the inspected evidence: ' + key)
    for name, expected in expected_script_hashes.items():
        entry = fingerprint(project / 'CodonTransformerV2' / name)
        if entry['sha256'] != expected:
            raise ValueError('Legacy scorer differs from the audited source: ' + name)
        sources['scorer:' + name] = entry
    return sources


def recheck_sources(sources):
    for key, before in sources.items():
        if fingerprint(Path(before['path'])) != before:
            raise ValueError('Source changed during reference freeze: ' + key)


def read_parquet(path):
    try:
        import pandas as pd
        return pd.read_parquet(path)
    except ImportError as error:
        raise RuntimeError('Reference freezing requires pandas plus a Parquet engine (pyarrow or fastparquet) in the CPU job environment.') from error


def positive_integer(value, name, allow_zero=False):
    if isinstance(value, bool) or not isinstance(value, numbers.Integral):
        raise ValueError(name + ' must be an integer')
    value = int(value)
    if value < (0 if allow_zero else 1):
        raise ValueError(name + ' is outside its allowed range')
    return value


def finite_number(value, name, low=None, high=None):
    if isinstance(value, bool) or not isinstance(value, numbers.Real) or not math.isfinite(value):
        raise ValueError(name + ' must be a finite number')
    value = float(value)
    if (low is not None and value < low) or (high is not None and value > high):
        raise ValueError(name + ' is outside its allowed range')
    return value


def load_summary(path, expected_species, expected_records):
    with Path(path).open(newline='') as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != ['species', 'top_ref_genes', 'mean_ref_csi', 'mean_ref_len']:
            raise ValueError('Unexpected historical reference summary schema')
        rows = {}
        for row in reader:
            host = row['species']
            if not host or host in rows:
                raise ValueError('Empty or duplicate species in historical summary')
            count = int(row['top_ref_genes'])
            if str(count) != row['top_ref_genes'] or count <= 0:
                raise ValueError('Invalid selected-record count in historical summary')
            csi, length = float(row['mean_ref_csi']), float(row['mean_ref_len'])
            if not math.isfinite(csi) or not 0 < csi <= 1 or not math.isfinite(length) or length <= 0:
                raise ValueError('Invalid mean in historical summary')
            rows[host] = {'top_ref_genes': count, 'mean_ref_csi': csi, 'mean_ref_len': length}
    if len(rows) != expected_species or sum(r['top_ref_genes'] for r in rows.values()) != expected_records:
        raise ValueError('Historical summary host/record totals do not match the inspected evidence')
    return rows


def load_mapping(path):
    mapping = parse_json(Path(path).read_text())
    if not isinstance(mapping, dict) or not mapping:
        raise ValueError('Species mapping must be a nonempty JSON object')
    if any(not isinstance(k, str) or not k or type(v) is not int or v < 0 for k, v in mapping.items()):
        raise ValueError('Invalid species mapping entry')
    if set(mapping.values()) != set(range(len(mapping))):
        raise ValueError('Species mapping IDs must be unique and contiguous from zero')
    return mapping


def validate_table(frame, reference_hosts, mapping):
    if not set(TABLE_COLUMNS).issubset(frame.columns) or frame.empty:
        raise ValueError('Codon table is empty or missing required columns')
    table = frame[TABLE_COLUMNS]
    if table.isna().any().any():
        raise ValueError('Null value in required codon-table columns')
    if table.duplicated(['species', 'aa', 'codon']).any() or table.duplicated(['species', 'codon']).any():
        raise ValueError('Duplicate codon-table key')
    from pandas.api.types import is_bool_dtype
    for name in ('rare_lt_0_001', 'rare_lt_0_01'):
        if not is_bool_dtype(table[name]):
            raise ValueError('Rare flags must be Boolean: ' + name)
    selected = defaultdict(dict)
    table_hosts = set()
    for row in table.itertuples(index=False):
        host, aa, codon = row.species, row.aa, row.codon
        if not isinstance(host, str) or not host or host != host.strip():
            raise ValueError('Malformed species in codon table')
        table_hosts.add(host)
        if not isinstance(codon, str) or codon not in CODE or aa != CODE[codon]:
            raise ValueError('Malformed codon/amino-acid pair in codon table')
        frequency = finite_number(row.frequency, 'codon frequency', low=0)
        if bool(row.rare_lt_0_001) and not bool(row.rare_lt_0_01):
            raise ValueError('Inconsistent nested rare-codon flags')
        if host in reference_hosts and aa != '*':
            selected[host][codon] = {'frequency': frequency, 'rare_001': bool(row.rare_lt_0_001),
                                     'rare_01': bool(row.rare_lt_0_01)}
    for host in reference_hosts:
        if set(selected[host]) != set(SENSE_CODONS):
            raise ValueError('Missing sense-codon table entries for reference species: ' + host)
    for host, values in selected.items():
        maxima = defaultdict(float)
        for codon, row in values.items():
            maxima[CODE[codon]] = max(maxima[CODE[codon]], row['frequency'])
        for codon, row in values.items():
            maximum = maxima[CODE[codon]]
            row['formal_weight'] = row['frequency'] / maximum if maximum > 0 else None
    return selected, {'rows': len(table), 'species_count': len(table_hosts),
                      'species_outside_current_mapping_count': len(table_hosts - set(mapping)),
                      'species_outside_current_mapping_examples': sorted(table_hosts - set(mapping))[:20],
                      'reference_host_sense_codons_complete': True}


def normalize_selected(frame, summary, mapping, table):
    if not set(SELECTED_COLUMNS).issubset(frame.columns) or frame.empty:
        raise ValueError('Selected reference is empty or missing required columns')
    use = frame[SELECTED_COLUMNS]
    if use.isna().any().any():
        raise ValueError('Null value in selected-reference columns')
    accum = {host: {'selected_records': 0, 'raw_codon_counts': Counter(),
                    'ambiguous_codons_skipped': 0, 'stop_codons_skipped': 0,
                    'csi_sum': 0.0, 'protein_len_sum': 0} for host in summary}
    row_hashes, gene_ids = Counter(), Counter()
    normalized_dna_rows = 0
    for row in use.itertuples(index=False):
        host = row.species
        if not isinstance(host, str) or host not in summary or host not in mapping:
            raise ValueError('Unmapped or unexpected selected-reference species')
        if not isinstance(row.genome_id, str) or not isinstance(row.protein_id, str):
            raise ValueError('Selected gene identifiers must retain their string representation')
        if not isinstance(row.dna, str) or not row.dna:
            raise ValueError('Selected DNA must be a nonempty string')
        dna = row.dna.upper().replace('U', 'T').replace(' ', '').replace('\n', '').replace('\r', '')
        if set(dna) - IUPAC:
            raise ValueError('Malformed selected DNA: non-IUPAC bases or unsupported whitespace')
        protein_len = positive_integer(row.protein_len, 'protein_len')
        if len(dna) != 3 * protein_len:
            raise ValueError('Selected DNA length differs from 3*protein_len; no silent retruncation')
        csi = finite_number(row.formal_csi, 'formal_csi', low=0, high=1)
        if csi == 0:
            raise ValueError('Selected formal CSI must be positive')
        stored_codons = positive_integer(row.codons_total, 'codons_total')
        stored_missing = finite_number(row.missing_weight_frac, 'missing_weight_frac', low=0, high=1)
        observed = Counter()
        ambiguous = stops = 0
        for index in range(0, len(dna), 3):
            codon = dna[index:index + 3]
            aa = CODE.get(codon)
            if aa is None:
                ambiguous += 1
            elif aa == '*':
                stops += 1
            else:
                observed[codon] += 1
        total = sum(observed.values())
        if total != stored_codons:
            raise ValueError('Selected stored codons_total disagrees with legacy sense-codon count')
        logs, scored, missing = [], 0, 0
        for codon, count in observed.items():
            weight = table[host][codon]['formal_weight']
            if weight is None or weight <= 0:
                missing += count
            else:
                scored += count
                logs.append(count * math.log(weight))
        if not scored:
            raise ValueError('Selected reference row has no supported positive CSI weights')
        recomputed = math.exp(math.fsum(logs) / scored)
        if not math.isclose(recomputed, csi, rel_tol=1e-9, abs_tol=1e-12):
            raise ValueError('Selected formal CSI differs from current codon table; historical table/reference provenance needs inspection')
        if not math.isclose(missing / total, stored_missing, rel_tol=1e-9, abs_tol=1e-12):
            raise ValueError('Selected missing-weight fraction disagrees with current codon table')
        values = [host, row.genome_id, row.protein_id, dna, protein_len, csi, stored_codons, stored_missing]
        row_hashes[hashlib.sha256(canonical(values)).hexdigest()] += 1
        gene_ids[(host, row.genome_id, row.protein_id)] += 1
        normalized_dna_rows += int(dna != row.dna)
        a = accum[host]
        a['selected_records'] += 1; a['raw_codon_counts'].update(observed)
        a['ambiguous_codons_skipped'] += ambiguous; a['stop_codons_skipped'] += stops
        a['csi_sum'] += csi; a['protein_len_sum'] += protein_len
    for host, a in accum.items():
        expected = summary[host]
        if a['selected_records'] != expected['top_ref_genes']:
            raise ValueError('Selected records disagree with historical per-host summary: ' + host)
        n = a['selected_records']
        if not math.isclose(a['csi_sum'] / n, expected['mean_ref_csi'], rel_tol=1e-9, abs_tol=1e-12):
            raise ValueError('Selected mean CSI disagrees with historical summary: ' + host)
        if not math.isclose(a['protein_len_sum'] / n, expected['mean_ref_len'], rel_tol=1e-9, abs_tol=1e-9):
            raise ValueError('Selected mean protein length disagrees with historical summary: ' + host)
    metadata = {
        'rows': len(use), 'species_count': len(accum),
        'record_multiset_sha256': hashlib.sha256(canonical(sorted(row_hashes.items()))).hexdigest(),
        'duplicate_exact_rows': sum(n - 1 for n in row_hashes.values()),
        'duplicate_gene_id_rows': sum(n - 1 for n in gene_ids.values()),
        'normalized_dna_rows': normalized_dna_rows,
        'stored_formal_csi_revalidated_against_frozen_codon_table': True,
        'multiset_definition': 'SHA256 of sorted (canonical normalized eight-field row SHA256, multiplicity) pairs; duplicates retained',
    }
    return accum, metadata


def freeze_species(accum, table):
    species = {}
    for host in sorted(accum):
        a = accum[host]
        raw = {codon: int(a['raw_codon_counts'][codon]) for codon in SENSE_CODONS}
        maxima = defaultdict(int)
        for codon, count in raw.items():
            maxima[CODE[codon]] = max(maxima[CODE[codon]], count + 1)
        species[host] = {
            'selected_records': a['selected_records'], 'raw_codon_counts': raw,
            'weights': {codon: (raw[codon] + 1) / maxima[CODE[codon]] for codon in SENSE_CODONS},
            'rare_masks': {
                'no_rare_0_001': [c for c in SENSE_CODONS if table[host][c]['rare_001']],
                'no_rare_0_01': [c for c in SENSE_CODONS if table[host][c]['rare_01']],
            },
            'legacy_ambiguous_codons_skipped': a['ambiguous_codons_skipped'],
            'legacy_stop_codons_skipped': a['stop_codons_skipped'],
        }
    return species


def evaluation_support(path, mapping, supported):
    inverse = {v: k for k, v in mapping.items()}
    hosts = Counter()
    with Path(path).open() as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip(): continue
            doc = parse_json(line)
            if not isinstance(doc, dict): raise ValueError('Evaluation panel record must be an object')
            value = doc.get('species')
            if isinstance(value, str) and value in mapping:
                host = value
            elif type(value) is int and value in inverse:
                host = inverse[value]
            else:
                raise ValueError('Unmapped evaluation species at line ' + str(line_number))
            hosts[host] += 1
    if not hosts: raise ValueError('Evaluation panel is empty')
    return {'requested_records': sum(hosts.values()), 'requested_species_count': len(hosts),
            'supported_records': sum(n for h, n in hosts.items() if h in supported),
            'supported_species_count': len(set(hosts) & set(supported)),
            'supported_species': sorted(set(hosts) & set(supported)),
            'unsupported_species': sorted(set(hosts) - set(supported)),
            'note': 'Unsupported hosts remain explicitly unscored by this legacy CAI reference; never replace their weights by another host.'}


def freeze(project, out, *, parquet_reader=None, expected_summary_hash=SUMMARY_SHA256,
           expected_species=159, expected_records=114315, expected_script_hashes=None):
    project, out = Path(project).resolve(), Path(out)
    if out.is_symlink(): raise ValueError('Reference output directory must not be a symlink')
    out = out.resolve(); out.mkdir(parents=True, exist_ok=True)
    with (out / '.freeze.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        scripts = SCRIPT_HASHES if expected_script_hashes is None else expected_script_hashes
        sources = checked_sources(project, expected_summary_hash, scripts)
        identity = {'schema': SCHEMA, 'sources': sources, 'freezer_sha256': sha(__file__),
                    'expected_summary_sha256': expected_summary_hash, 'expected_species': expected_species,
                    'expected_records': expected_records, 'pseudocount': 1.0}
        identity_sha = hashlib.sha256(canonical(identity)).hexdigest()
        report_path, manifest_path = out / 'frozen_reference.json', out / 'reference_manifest.json'
        if report_path.is_symlink() or manifest_path.is_symlink():
            raise ValueError('Reference output must not be symlinked')
        if report_path.exists() or manifest_path.exists():
            if not report_path.is_file() or not manifest_path.is_file():
                raise ValueError('Incomplete previous freeze; preserve it and choose a fresh output directory')
            manifest = parse_json(manifest_path.read_text())
            if manifest.get('identity_sha256') != identity_sha:
                raise ValueError('Frozen reference source/configuration changed; use a separately versioned output')
            if manifest.get('status') != 'COMPLETE' or manifest.get('frozen_reference_sha256') != sha(report_path):
                raise ValueError('Frozen reference output integrity failure')
            report = parse_json(report_path.read_text())
            if report.get('identity_sha256') != identity_sha or report.get('schema') != SCHEMA:
                raise ValueError('Frozen reference identity does not match its receipt')
            return report
        mapping = load_mapping(project / PATHS['mapping'])
        summary = load_summary(project / PATHS['standard_summary'], expected_species, expected_records)
        rare_summary = load_summary(project / PATHS['rare_summary'], expected_species, expected_records)
        if summary != rare_summary: raise ValueError('Standard and rare historical summaries differ')
        if not set(summary).issubset(mapping): raise ValueError('Historical reference species absent from current mapping')
        reader = read_parquet if parquet_reader is None else parquet_reader
        table, table_metadata = validate_table(reader(project / PATHS['codon_table']), set(summary), mapping)
        standard, standard_metadata = normalize_selected(reader(project / PATHS['standard_selected']), summary, mapping, table)
        rare, rare_metadata = normalize_selected(reader(project / PATHS['rare_selected']), summary, mapping, table)
        if standard_metadata['record_multiset_sha256'] != rare_metadata['record_multiset_sha256']:
            raise ValueError('Standard and rare selected-reference multisets differ; do not silently merge their historical metrics')
        species = freeze_species(standard, table)
        if species != freeze_species(rare, table): raise ValueError('Standard and rare frozen weights disagree')
        support = evaluation_support(project / PATHS['panel'], mapping, set(species))
        report = {
            'schema': SCHEMA, 'status': 'LEGACY_REFERENCE_FROZEN', 'training_ready': False,
            'created_utc': datetime.now(timezone.utc).isoformat(), 'identity_sha256': identity_sha,
            'identity': identity, 'selected_reference': standard_metadata,
            'rare_selected_reference': rare_metadata, 'standard_rare_multisets_equal': True,
            'codon_table': table_metadata, 'evaluation_support': support,
            'pseudocount': 1.0, 'codon_amino_acids': {c: CODE[c] for c in SENSE_CODONS},
            'species': species,
            'rules': {
                'reference_population': 'Retained historical selected native-training records; not newly selected from current QC corpus',
                'weight': '(raw selected sense-codon count + 1) / max over synonymous codons of (raw count + 1)',
                'sequence_cai': 'exp(mean(log(positive available weights))) over valid sense codons after optional requested-host rare mask',
                'summary': 'Legacy arithmetic mean of per-sequence CAI; publish attempted/valid/reference-supported/scored denominators separately',
                'rare_modes': 'all, no_rare_0_001, no_rare_0_01 reuse identical weights; masks apply only when scoring predictions',
                'alternative_starts': 'Standard genetic code, as in legacy scorer; GTG counts as Val, with no protein-aware reinterpretation',
                'duplicates': 'Preserved with multiplicity; row and gene-ID duplicate counts are reported',
            },
            'limitations': [
                'The historical full-corpus scan and top-10% selection completeness remain unverified. This freezes retained evidence, not a proof of its original selection.',
                'No training shards, merged scored-training Parquet or cache batches were rescanned or used to fill gaps.',
                'Selected DNA is checked structurally and its stored CSI revalidated; strict protein translation QC cannot be reconstructed because this artifact has no protein sequence.',
                'Historical input normalization differs from the current training QC. A newly QC-selected or broader-host reference requires a separate version.',
                'Current-panel host support is explicit; unsupported hosts must not be silently dropped from reported evaluation denominators.',
                'This is reference preparation, not generation, epoch scoring, GPU preflight or training authorization.',
            ],
        }
        recheck_sources(sources)
        atomic_json(report_path, report)
        atomic_json(manifest_path, {'schema': 'ct2-reference-freeze-receipt-v1', 'status': 'COMPLETE',
                                   'identity_sha256': identity_sha, 'frozen_reference_sha256': sha(report_path),
                                   'training_ready': False})
        return report


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project-root', type=Path, default=BASE)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args(argv)
    try:
        reused = (args.out / 'reference_manifest.json').is_file()
        result = freeze(args.project_root, args.out)
        print('REFERENCE_STATUS=' + result['status'])
        print('REFERENCE_REUSED=' + str(reused).lower())
        print('FROZEN_REFERENCE=' + str(args.out.resolve() / 'frozen_reference.json'))
        print('REFERENCE_SPECIES=' + str(result['selected_reference']['species_count']))
        print('PANEL_SUPPORTED_SPECIES=' + str(result['evaluation_support']['supported_species_count']))
        print('TRAINING_READY=false')
        return 0
    except Exception as error:
        print('REFERENCE_FREEZE_FAILED=' + type(error).__name__ + ': ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
