from __future__ import annotations
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import prepare_evaluation as p


class CohortTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.mapping = {'species A': 0, 'species B': 1, 'species C': 2}
        self.vocab = json.loads((p.HERE/'policy_fixture/source/CodonTransformerTokenizer.json').read_text())['model']['vocab']

    def current(self, rows):
        source = self.root/'panel.jsonl'
        source.write_text(''.join(json.dumps(r)+'\n' for r in rows))
        return p.current_rows(source,self.mapping,self.vocab)

    def record(self, dna='ATGGCTTAA', protein='MA', key='gene-1', species='species A'):
        return dict(species=species,dna_sequence=dna,protein_sequence=protein,eval_key=key)

    def test_unknown_native_positions_retained(self):
        row = self.current([self.record('GTGNNNTAA')])[0]
        self.assertEqual(row['native_known_target_positions'],[2])
        self.assertEqual(row['native_ignored_positions'],[0,1])
        self.assertEqual(row['protein_sequence'],'MA')
        self.assertTrue(row['generation_terminal_stop'])

    def test_current_mismatch_is_not_silently_removed(self):
        with self.assertRaisesRegex(ValueError,'translation_mismatch'):
            self.current([self.record('ATGTTTTAA')])

    def test_current_duplicate_source_id_rejected(self):
        with self.assertRaisesRegex(ValueError,'duplicate eval_id'):
            self.current([self.record(),self.record()])

    def test_long_current_protein_is_not_truncated(self):
        row=self.current([self.record('ATG'+'GCT'*2046+'TAA','M'+'A'*2046)])[0]
        self.assertEqual(len(row['protein_sequence']),2047)
        self.assertEqual(row['source_protein_length'],2047)
        self.assertFalse(row['source_was_truncated'])

    def legacy(self):
        return dict(eval_id='legacy:7',source_eval_id='7',cohort='legacy_common_valid',
            species='species A',species_id=0,protein_sequence='MA',native_dna='ATGTTT',
            source_protocol=p.LEGACY_PROTOCOL,source_protein_length=2,source_was_truncated=False,
            native_known_target_positions=[0],native_ignored_positions=[1],
            native_qc_status='legacy_retained_translation_mismatch')

    def test_legacy_native_mismatch_keeps_complete_record(self):
        row=self.legacy()
        p.validate_rows([row],self.mapping,'legacy_common_valid')
        self.assertEqual(row['native_dna'],'ATGTTT')
        self.assertEqual(row['protein_sequence'],'MA')

    def test_legacy_mismatch_cannot_be_marked_known(self):
        row=self.legacy();row['native_known_target_positions']=[0,1];row['native_ignored_positions']=[]
        with self.assertRaisesRegex(ValueError,'known positions'):
            p.validate_rows([row],self.mapping,'legacy_common_valid')

    def test_native_masks_must_cover_each_position_once(self):
        row=self.legacy();row['native_ignored_positions']=[]
        with self.assertRaisesRegex(ValueError,'complete disjoint partition'):
            p.validate_rows([row],self.mapping,'legacy_common_valid')

    def test_fixed_wrong_host_reproducible_and_different(self):
        rows=self.current([self.record(key=str(i),species=name) for i,name in enumerate(self.mapping)])
        other=copy.deepcopy(rows)
        p.add_fixed_wrong_hosts(rows,self.mapping)
        p.add_fixed_wrong_hosts(other,self.mapping)
        self.assertEqual(rows,other)
        self.assertTrue(all(r['species']!=r['wrong_species'] for r in rows))
        self.assertTrue(all(self.mapping[r['wrong_species']]==r['wrong_species_id'] for r in rows))

    def test_reference_denominators_include_unsupported_hosts(self):
        rows=self.current([self.record(key=str(i),species=name) for i,name in enumerate(self.mapping)])
        summary=p.cohort_summary(rows,{'species':{'species A':{}}})
        self.assertEqual(summary['records'],3)
        self.assertEqual(summary['cai_supported_records'],1)
        self.assertEqual(summary['cai_unsupported_records'],2)
        self.assertEqual(summary['cai_unsupported_species'],['species B','species C'])

    def test_hash_mismatch_rejected(self):
        path=self.root/'file';path.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'SHA256 mismatch'):
            p.fingerprint(path,'0'*64)

    def test_json_duplicate_keys_rejected(self):
        with self.assertRaisesRegex(ValueError,'Duplicate JSON'):
            p.strict_json('{"species":"A","species":"B"}')

    def test_packaged_legacy_identity_and_denominators(self):
        mapping=p.read_json(p.HERE/'policy_fixture/source/species_to_id.json')
        asset=p.HERE/'evaluation_assets/legacy_common_valid.jsonl.gz'
        self.assertEqual(p.sha(asset),p.SOURCE_HASHES['legacy_cohort'])
        rows=p.legacy_rows(asset,mapping)
        self.assertEqual(len(rows),25465)
        self.assertEqual(len({r['species'] for r in rows}),159)
        self.assertEqual(sum(r['native_qc_status']!='accepted' for r in rows),304)
        self.assertEqual(sum(r['source_was_truncated'] for r in rows),204)
        self.assertTrue(all(not r['generation_terminal_stop'] for r in rows))


if __name__=='__main__': unittest.main()
