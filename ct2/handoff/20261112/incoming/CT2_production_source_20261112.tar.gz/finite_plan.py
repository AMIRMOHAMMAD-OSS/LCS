#!/usr/bin/env python3
"""Build an immutable finite-pass lane plan from all completed census receipts."""
from __future__ import annotations

import argparse
import heapq
import json
from pathlib import Path
import random
import re

import census
from derive_budget import validate_summary, _integers

BASE = Path('/lustre/fswork/projects/rech/nef/unh87ms')
CHECKPOINT = BASE / 'ct2_retrain/ct2_production_20260930_v4/training/fullmask512/step_040000.ckpt'
CHECKPOINT_SHA256 = 'adbdca83862853a05df956b92f43c1fe3b2286d0fea2209b7c8c6ed0c4dd0e28'
SOURCE_FINGERPRINT = 'a9b9a2f2e55ffdc6b96ae4d7269056b3d0541761e979466f2c0a5c7d0e70e105'
STAGES = ((512, .05, 192, 1, 1, 2e-5), (1024, .10, 56, 3, 2, 5e-6),
          (1536, .20, 56, 3, 2, 2e-6), (2048, .30, 32, 5, 2, 1e-6))


def strict_json(path):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            if key in value: raise ValueError('Duplicate JSON key: ' + key)
            value[key] = item
        return value
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError('Nonfinite JSON: ' + x)))


def nonnegative(value, name):
    if type(value) is not int or value < 0:
        raise ValueError('Expected a nonnegative integer: ' + name)
    return value


def seed_for(seed, stage, label):
    return int(census.digest([seed, stage, label])[:16], 16)


def make_stages(shards, seed, world_size):
    """Largest-first balancing, with recorded deterministic within-lane shuffling."""
    stages = []
    for index, (length, full_mask, micro, accum, workers, lr) in enumerate(STAGES):
        lanes = [dict(id=i, rank=i // workers, worker=i % workers, shard_ids=[],
                      windows=0, records=0, known_targets=0, batches=0)
                 for i in range(world_size * workers)]
        shuffled = list(range(len(shards)))
        random.Random(seed_for(seed, index, 'assignment-ties')).shuffle(shuffled)
        order = sorted(shuffled, key=lambda sid: -shards[sid]['by_length'][str(length)]['windows'])
        heap = [(0, lane['id']) for lane in lanes]
        heapq.heapify(heap)
        for sid in order:
            _, lane_id = heapq.heappop(heap)
            lane, count = lanes[lane_id], shards[sid]['by_length'][str(length)]
            lane['shard_ids'].append(sid)
            for key in ('windows', 'records', 'known_targets'): lane[key] += count[key]
            heapq.heappush(heap, (lane['windows'], lane_id))
        for lane in lanes:
            random.Random(seed_for(seed, index, 'lane-order:' + str(lane['id']))).shuffle(lane['shard_ids'])
            lane['batches'] = (lane['windows'] + micro - 1) // micro
        rank_batches = [sum(lane['batches'] for lane in lanes if lane['rank'] == rank)
                        for rank in range(world_size)]
        steps = max((n + accum - 1) // accum for n in rank_batches)
        stages.append(dict(index=index, max_length=length, full_mask_probability=full_mask,
            unknown_species_probability=.02, wrong_real_species_probability=0.,
            partial_mlm_probability=.15, batch_per_gpu=micro, accumulation=accum,
            num_workers=workers, world_size=world_size, learning_rate_preflight=lr,
            steps=steps, rank_batches=rank_batches, rank_real_windows=[
                sum(lane['windows'] for lane in lanes if lane['rank'] == r) for r in range(world_size)],
            rank_padding_microbatches=[steps * accum - n for n in rank_batches],
            windows=sum(lane['windows'] for lane in lanes),
            records=sum(lane['records'] for lane in lanes),
            known_targets=sum(lane['known_targets'] for lane in lanes), lanes=lanes))
    return stages


def validate_plan(plan):
    if plan.get('schema') != 'ct2-finite-plan-v1' or plan.get('training_ready') is not False:
        raise ValueError('Unsupported finite plan or invalid training-ready marker')
    if plan.get('shuffle_buffer') != 1024 or type(plan.get('shuffle_buffer')) is not int:
        raise ValueError('Finite plan requires a 1024-record per-shard shuffle buffer')
    if plan.get('padding_policy') != 'fixed_stage_max_length':
        raise ValueError('Finite plan requires fixed stage-max-length padding')
    if plan.get('identity') != census.digest({k: v for k, v in plan.items() if k != 'identity'}):
        raise ValueError('Finite plan identity mismatch')
    world = nonnegative(plan['world_size'], 'world_size')
    if not 1 <= world <= 64: raise ValueError('Invalid world size')
    if type(plan['seed']) is not int: raise ValueError('Seed must be an integer')
    if plan.get('source_policy_hashes') != census.EXPECTED_POLICY:
        raise ValueError('Finite plan token policy differs from audited policy')
    if not Path(plan['data_root']).is_absolute() or not Path(plan['source']['repo']).is_absolute():
        raise ValueError('Finite plan requires absolute source/data paths')
    for key in ('census_identity', 'content_identity'):
        if not re.fullmatch('[0-9a-f]{64}', str(plan.get(key, ''))): raise ValueError('Invalid ' + key)
    shards = plan['shards']
    if not shards: raise ValueError('Finite plan has no shards')
    for sid, row in enumerate(shards):
        if row['name'] != f'shard-{sid:06d}.tar.gz': raise ValueError('Invalid shard name/order')
        if nonnegative(row['bytes'], 'bytes') == 0: raise ValueError('Empty shard')
        nonnegative(row['mtime_ns'], 'mtime_ns')
        if not re.fullmatch('[0-9a-f]{64}', str(row['compressed_sha256'])): raise ValueError('Invalid shard hash')
        if set(row['by_length']) != {'512', '1024', '1536', '2048'}: raise ValueError('Missing shard length counts')
        for value in row['by_length'].values():
            for key in ('windows', 'records', 'known_targets'): nonnegative(value[key], key)
            if not value['records'] <= value['windows'] <= value['known_targets']:
                raise ValueError('Invalid per-shard windows/record/target counts')
    if census.digest([[s['name'], s['compressed_sha256']] for s in shards]) != plan['content_identity']:
        raise ValueError('Finite plan content identity mismatch')
    if plan['stages'] != make_stages(shards, plan['seed'], world):
        raise ValueError('Finite plan lane assignment, settings or counters differ from policy')
    return plan


def build_plan(census_dir, repo, seed=123, world_size=8):
    census_dir, repo = Path(census_dir).resolve(), Path(repo).resolve()
    if type(seed) is not int or type(world_size) is not int or not 1 <= world_size <= 64:
        raise ValueError('Invalid seed/world size')
    policy = census.Policy(repo)
    run_path = repo / 'run.json'
    run = strict_json(run_path)
    if run.get('fingerprint') != SOURCE_FINGERPRINT or policy.common.fingerprint(run) != SOURCE_FINGERPRINT:
        raise ValueError('Source run fingerprint differs from the reviewed production source')
    summary_path, manifest_path = census_dir / 'census_summary.json', census_dir / 'census_manifest.json'
    summary, manifest = strict_json(summary_path), strict_json(manifest_path)
    validate_summary(summary)
    identity_inputs = manifest['identity_inputs']
    if manifest.get('identity') != census.digest(identity_inputs) or manifest['identity'] != summary['census_identity']:
        raise ValueError('Census manifest identity mismatch')
    if (identity_inputs.get('format') != census.FORMAT or identity_inputs.get('scanner_version') != census.SCANNER_VERSION
        or identity_inputs.get('scanner_sha256') != census.file_sha(census.__file__)
        or identity_inputs.get('policy_files') != census.EXPECTED_POLICY
        or identity_inputs.get('lengths') != list(census.LENGTHS)):
        raise ValueError('Census scanner/policy identity differs from the audited census')
    rows, data = identity_inputs['inventory'], Path(identity_inputs['data_root'])
    if not data.is_absolute() or len(rows) != summary['expected_shards']:
        raise ValueError('Invalid census data root/inventory count')
    if census.inventory(data, len(rows)) != rows:
        raise ValueError('Training shard inventory changed since the census')
    aggregate, shards, content_rows = census.empty_counts(), [], []
    for row in rows:
        receipt_file = census.receipt_path(census_dir, row['name'])
        receipt = strict_json(receipt_file)
        if (receipt.get('format') != census.FORMAT or receipt.get('status') != 'COMPLETE'
            or receipt.get('census_identity') != manifest['identity'] or receipt.get('file') != row
            or receipt.get('compressed_bytes_read') != row['bytes']
            or not re.fullmatch('[0-9a-f]{64}', str(receipt.get('compressed_sha256', '')))):
            raise ValueError('Incomplete, changed or invalid shard receipt: ' + row['name'])
        counts = receipt['counts']
        _integers(counts)
        census.validate_counts(counts)
        census.merge_counts(aggregate, counts)
        content_rows.append([row['name'], receipt['compressed_sha256']])
        shards.append(dict(row, compressed_sha256=receipt['compressed_sha256'],
            by_length={str(length): dict(windows=counts['proposed_windows'][str(length)]['target_bearing_windows'],
                records=counts['full_gene']['accepted_records'],
                known_targets=counts['proposed_windows'][str(length)]['known_target_opportunities'])
                for length in census.LENGTHS}))
    if aggregate != summary['counts']:
        raise ValueError('Aggregated shard receipts differ from the completed census summary')
    if census.digest(content_rows) != summary['content_identity_sha256']:
        raise ValueError('Shard content identity differs from the completed census')
    plan = dict(schema='ct2-finite-plan-v1', training_ready=False,
        shuffle_buffer=1024, padding_policy='fixed_stage_max_length',
        purpose='Candidate preflight only; production training is not enabled',
        seed=seed, world_size=world_size, data_root=str(data),
        source=dict(repo=str(repo), checkpoint=str(CHECKPOINT), checkpoint_sha256=CHECKPOINT_SHA256,
            source_fingerprint=SOURCE_FINGERPRINT, species_embed_scale=.0347,
            mapping_sha256=census.file_sha(repo / 'source/species_to_id.json'),
            tokenizer_sha256=census.file_sha(repo / 'source/CodonTransformerTokenizer.json'),
            run_json_sha256=census.file_sha(run_path)),
        source_policy_hashes=dict(census.EXPECTED_POLICY), census_identity=manifest['identity'],
        content_identity=summary['content_identity_sha256'],
        census_summary_sha256=census.file_sha(summary_path), census_manifest_sha256=census.file_sha(manifest_path),
        shards=shards, stages=make_stages(shards, seed, world_size),
        semantics=dict(record_unit='Physical eligible JSON records, not deduplicated biological genes',
            window_policy='Nonoverlapping max_length-2 token windows; omit windows with no known target',
            shuffle_policy='Seeded largest-first shard balancing; seeded lane shard order; per-shard record shuffle resets and drains',
            tail_policy='Round-robin active lanes, incomplete final lane microbatches retained, exhausted ranks use zero-loss dummy batches',
            optimizer_policy='Fresh optimizer for candidate import; carry state across stages/resume; historical age is separate',
            lr_policy='Constant candidate preflight rates only; no production warmup/horizon is authorized',
            checkpoint_verification='Source checkpoint hash is declared here; the CPU/GPU launcher must verify actual bytes before model import',
            reuse_verification='Plan construction validates receipt hashes and current shard size/mtime; full content rehash occurs in the finite reader'))
    plan['identity'] = census.digest(plan)
    return validate_plan(plan)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--census-dir', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--seed', type=int, default=123)
    args = parser.parse_args(argv)
    if args.out.exists(): raise FileExistsError('Plan output already exists; preserve its identity: ' + str(args.out))
    plan = build_plan(args.census_dir, args.repo, args.seed)
    census.atomic_json(args.out, plan)
    print('FINITE_PLAN=' + str(args.out.resolve()))
    print('FINITE_PLAN_IDENTITY=' + plan['identity'])
    print('FINITE_STAGE_UPDATES=' + json.dumps([stage['steps'] for stage in plan['stages']]))
    print('TRAINING_READY=false')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
