#!/usr/bin/env python3
"""Derive a provisional four-pass CT2 exposure budget from a complete census."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re

from census import atomic_json, validate_counts, utc_now

STAGES = ((512, .05, 192, 1, 1), (1024, .10, 56, 3, 2),
          (1536, .20, 56, 3, 2), (2048, .30, 32, 5, 2))
BUCKET_UPPERS = (510, 512, 1022, 1024, 1534, 1536, 2045, 2046, 2048)


def ratio(numerator, denominator):
    return numerator / denominator if denominator else None


def _integers(value, path='counts'):
    if isinstance(value, dict):
        for key, child in value.items():
            if key != 'rejection_examples':
                _integers(child, path + '.' + key)
    elif type(value) is not int or value < 0:
        raise ValueError('Expected a nonnegative integer at ' + path)


def validate_summary(summary):
    if summary.get('format') != 'ct2-census-v1' or summary.get('status') != 'COMPLETE':
        raise ValueError('A COMPLETE ct2-census-v1 summary is required')
    for field in ('census_identity', 'content_identity_sha256'):
        if not isinstance(summary.get(field), str) or re.fullmatch('[0-9a-f]{64}', summary[field]) is None:
            raise ValueError('Missing or malformed ' + field)
    expected, complete = summary.get('expected_shards'), summary.get('completed_shards')
    if type(expected) is not int or expected < 1 or type(complete) is not int or complete != expected:
        raise ValueError('Expected/completed shard counts do not agree')
    if summary.get('missing_receipts') != [] or summary.get('invalid_receipts_or_changed_files') != []:
        raise ValueError('Unresolved missing or invalid census receipts')
    counts = summary['counts']
    _integers(counts)
    if set(counts['current_prefix']) != {'512', '1024', '1536', '2048'} or set(counts['proposed_windows']) != {'512', '1024', '1536', '2048'}:
        raise ValueError('All four prescribed context lengths are required')
    validate_counts(counts)
    full = counts['full_gene']
    if full['accepted_records'] < 1 or full['known_target_opportunities'] < 1:
        raise ValueError('No usable full-gene training population')
    if full['accepted_records'] > counts['prepare_accepted_records']:
        raise ValueError('Full-gene acceptance exceeds preparation acceptance')
    bins = full['protein_length_buckets']
    allowed = {'<=' + str(n) for n in BUCKET_UPPERS} | {'>2048'}
    if set(bins) - allowed or sum(bins.values()) != full['accepted_records']:
        raise ValueError('Protein length histogram is invalid or incomplete')
    for length, _, _, _, _ in STAGES:
        prefix, windows = counts['current_prefix'][str(length)], counts['proposed_windows'][str(length)]
        if prefix['accepted_records'] > full['accepted_records']:
            raise ValueError('Prefix acceptance exceeds full-gene acceptance')
        if prefix['known_target_opportunities'] > full['known_target_opportunities'] or prefix['sequence_positions_exposed'] > full['sequence_positions']:
            raise ValueError('Prefix exposure exceeds full-gene exposure')
        if prefix['amino_acid_positions_exposed'] > full['amino_acid_positions']:
            raise ValueError('Prefix amino-acid exposure exceeds full-gene exposure')
        if not full['accepted_records'] <= windows['target_bearing_windows'] <= full['known_target_opportunities']:
            raise ValueError('Target-bearing window count is inconsistent')
        if windows['sequence_positions_in_zero_target_windows'] > full['ignored_positions']:
            raise ValueError('A purported zero-target window contains known targets')
        if windows['amino_acid_positions_exposed'] > full['amino_acid_positions']:
            raise ValueError('Window amino-acid exposure exceeds full-gene exposure')


def above_aa_threshold(histogram, threshold):
    # Thresholds used here are existing boundaries, so no interpolation is used.
    if threshold not in BUCKET_UPPERS:
        raise ValueError('Requested threshold is not a census histogram boundary')
    return sum(histogram.get('<=' + str(upper), 0) for upper in BUCKET_UPPERS if upper > threshold) + histogram.get('>2048', 0)


def derive(summary, summary_sha256):
    validate_summary(summary)
    counts, stages = summary['counts'], []
    full = counts['full_gene']
    for index, (length, full_probability, batch, accumulation, workers) in enumerate(STAGES, 1):
        windows, prefix = counts['proposed_windows'][str(length)], counts['current_prefix'][str(length)]
        n_windows = windows['target_bearing_windows']
        effective_batch = 8 * batch * accumulation
        lost_known = full['known_target_opportunities'] - prefix['known_target_opportunities']
        long_aa = above_aa_threshold(full['protein_length_buckets'], length)
        stages.append({
            'pass': index, 'max_model_tokens': length, 'sequence_token_capacity': length - 2,
            'complete_protein_capacity_if_stop_retained': length - 3,
            'full_mask_probability': full_probability, 'partial_mlm_selection_probability': .15,
            'unknown_species_probability': .02, 'wrong_real_species_probability': 0,
            'world_size': 8, 'batch_per_gpu': batch, 'accumulate_grad_batches': accumulation,
            'training_workers_per_gpu': workers, 'nominal_effective_batch_windows': effective_batch,
            'eligible_physical_records_visited': full['accepted_records'],
            'all_windows_including_zero_target_windows': windows['all_windows'],
            'training_windows': n_windows, 'zero_target_windows_omitted': windows['zero_target_windows'],
            'sequence_positions_in_omitted_zero_target_windows': windows['sequence_positions_in_zero_target_windows'],
            'known_target_opportunities_exposed': windows['known_target_opportunities'],
            'known_target_opportunity_coverage_fraction': ratio(windows['known_target_opportunities'], full['known_target_opportunities']),
            'sequence_positions_exposed': windows['sequence_positions_exposed'],
            'amino_acid_positions_exposed': windows['amino_acid_positions_exposed'],
            'physical_records_longer_than_sequence_capacity': windows['records_longer_than_capacity'],
            'fraction_records_longer_than_sequence_capacity': ratio(windows['records_longer_than_capacity'], full['accepted_records']),
            'protein_aa_length_greater_than_model_token_limit': {
                'aa_threshold': length, 'records': long_aa, 'fraction': ratio(long_aa, full['accepted_records']),
                'note': 'AA-only histogram threshold, distinct from the actual token budget including special and stop tokens.',
            },
            'current_prefix_comparison': {
                'accepted_records': prefix['accepted_records'],
                'full_gene_eligible_records_excluded_by_prefix_filter': full['accepted_records'] - prefix['accepted_records'],
                'known_target_opportunities_exposed': prefix['known_target_opportunities'],
                'known_target_opportunities_not_exposed': lost_known,
                'fraction_known_target_opportunities_not_exposed': ratio(lost_known, full['known_target_opportunities']),
                'sequence_positions_not_exposed': full['sequence_positions'] - prefix['sequence_positions_exposed'],
                'amino_acid_positions_not_exposed': full['amino_acid_positions'] - prefix['amino_acid_positions_exposed'],
                'note': 'Includes both prefix truncation and full-gene-eligible records rejected because no target remains in their prefix.',
            },
            'nominal_optimizer_updates': (n_windows + effective_batch - 1) // effective_batch,
            'nominal_update_formula': 'ceil(training_windows / (world_size * batch_per_gpu * accumulation))',
            'exact_ddp_optimizer_updates': None,
            'exact_lr_schedule': None,
        })
    return {
        'format': 'ct2-four-pass-budget-v1', 'status': 'COUNT_BACKED_PROVISIONAL',
        'training_launch_ready': False, 'created_utc': utc_now(),
        'source_census_identity': summary['census_identity'],
        'source_census_summary_sha256': summary_sha256,
        'training_shards_content_identity_sha256': summary['content_identity_sha256'],
        'census_completed_shards': summary['completed_shards'],
        'raw_physical_json_records': counts['json_records'],
        'eligible_physical_records_per_pass': full['accepted_records'],
        'full_gene_exclusions_by_reason': full['exclusions_by_reason'],
        'complete_passes_in_restarted_curriculum': 4,
        'total_physical_record_visits': 4 * full['accepted_records'],
        'total_training_window_visits': sum(stage['training_windows'] for stage in stages),
        'total_known_target_opportunities': 4 * full['known_target_opportunities'],
        'sum_nominal_optimizer_updates': sum(stage['nominal_optimizer_updates'] for stage in stages),
        'stages': stages,
        'definitions_and_limits': [
            'A physical record is a JSON member in an enumerated training shard; biological duplicate genes/sequences across shards were not deduplicated.',
            'Four passes visit every full-gene-eligible physical record four times and expose each known target position once per pass via nonoverlapping windows.',
            'Zero-target windows are omitted and counted; this does not claim every ignored amino-acid/codon position is exposed.',
            'Known target opportunities are available codon labels before random masking; they are not actual supervised targets or unique biological codons.',
            'Nominal updates assume globally packed windows. Exact rank/worker assignment, uneven tails, zero-weight padding and accumulation normalization remain unimplemented.',
            'Do not use nominal update counts as a finalized scheduler horizon or proof of replay correctness.',
            'Prior checkpoint exposure is additional history, not part of these four counted passes.',
            'Learning-rate/warmup duration, initialization choice, loader implementation and GPU preflight remain required before training.',
        ],
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--summary', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args(argv)
    raw = args.summary.read_bytes()
    result = derive(json.loads(raw), hashlib.sha256(raw).hexdigest())
    atomic_json(args.out, result)
    print('BUDGET_STATUS=' + result['status'])
    print('TRAINING_LAUNCH_READY=false')
    print('FOUR_PASS_BUDGET=' + str(args.out))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
