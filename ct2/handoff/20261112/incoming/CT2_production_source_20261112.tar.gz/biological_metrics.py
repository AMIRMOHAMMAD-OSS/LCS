"""Frozen-reference CT2 biological scoring, with explicit scoring denominators.

Legacy CSI/rank/MinMax conventions are named separately from new positional
and requested-host-masked definitions. No sequence is silently truncated.
"""
from __future__ import annotations

from collections import defaultdict
import hashlib
import itertools
import json
import math
from pathlib import Path

import numpy as np

CODE = dict(zip((''.join(x) for x in itertools.product('TCAG', repeat=3)),
                'FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG'))
CODONS = sorted(c for c, aa in CODE.items() if aa != '*')
CODON_INDEX = {c: i for i, c in enumerate(CODONS)}
AA_COLUMNS = {aa: np.array([i for i, c in enumerate(CODONS) if CODE[c] == aa])
              for aa in sorted(set(CODE.values()) - {'*'})}
MODES = ('all', 'no_rare_0_001', 'no_rare_0_01')
RARE_COLUMNS = {'no_rare_0_001': 'rare_lt_0_001', 'no_rare_0_01': 'rare_lt_0_01'}
EPS = 1e-9
WINDOW = 18
REQUIRED_METRICS = (
    'generation_valid', 'codon_recovery', 'predicted_gc3', 'gc3_absolute_error',
    'formal_csi_own', 'formal_csi_wrong_mean', 'formal_csi_delta_log',
    'formal_rank_legacy', 'raw_frequency_rank_legacy', 'formal_rank_requested_mask',
    'cai_legacy_top10', 'minmax_positional_mae', 'minmax_positional_rmse',
    'minmax_positional_corr', 'minmax_positional_dtw_normalized',
    'minmax_legacy_mae', 'minmax_legacy_rmse', 'minmax_legacy_corr',
    'minmax_legacy_dtw_normalized',
)


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def clean_dna(value):
    return ''.join(str(value or '').upper().split()).replace('U', 'T')


def codon_list(dna):
    dna = clean_dna(dna)
    return [dna[i:i + 3] for i in range(0, len(dna) - 2, 3)]


def codon_counts(dna):
    values = np.zeros(61, dtype=np.float64)
    for codon in codon_list(dna):
        if codon in CODON_INDEX: values[CODON_INDEX[codon]] += 1
    return values


def finite(value):
    return float(value) if value is not None and math.isfinite(float(value)) else None


def generation_valid(dna, protein, terminal_stop_included=True):
    """Explicit terminal-stop protocol, standard-code identity, no ambiguity."""
    if type(terminal_stop_included) is not bool: raise ValueError('Terminal-stop protocol must be Boolean')
    dna = clean_dna(dna)
    protein = str(protein).strip().upper()
    codons = codon_list(dna)
    extra = int(terminal_stop_included)
    return (bool(protein) and all(aa in AA_COLUMNS for aa in protein)
            and len(dna) == 3 * (len(protein) + extra)
            and len(codons) == len(protein) + extra
            and (not terminal_stop_included or CODE.get(codons[-1]) == '*')
            and all(CODE.get(c) == aa for c, aa in zip(codons[:len(protein)], protein)))


def rolling_profile(values, window=WINDOW):
    """Preserve positions: a window containing an unscored codon stays NaN."""
    values = np.asarray(values, dtype=np.float64)
    if not len(values): return np.array([], dtype=np.float64)
    if len(values) < window:
        return np.array([values.mean() if np.isfinite(values).all() else np.nan])
    mask = np.isfinite(values)
    sums = np.convolve(np.where(mask, values, 0.), np.ones(window) / window, mode='valid')
    complete = np.convolve(mask.astype(np.int32), np.ones(window, dtype=np.int32), mode='valid') == window
    sums[~complete] = np.nan
    return sums


def legacy_rolling_profile(values, window=WINDOW):
    # Preserve the historical float32 convolution path for numerical parity.
    values = np.asarray(values, dtype=np.float32)
    values = values[np.isfinite(values)]
    if not len(values): return values
    if len(values) < window: return np.array([float(np.mean(values))], dtype=np.float32)
    return np.convolve(values, np.ones(window, dtype=np.float32) / float(window), mode='valid').astype(np.float32)


def dtw_symmetric2(a, b):
    """Exact unbanded symmetric2, normalized by N+M, using bounded O(M) memory.

    The recurrence is the vectorized NumPy fallback used by the retained
    legacy evaluator. There is no downsampling or window/band approximation.
    """
    a, b = np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64)
    if not len(a) or not len(b): return None, None
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError('DTW requires finite values; positional gaps must be split first')
    if a.shape == b.shape and np.array_equal(a, b): return 0., 0.
    previous = np.cumsum(np.abs(a[0] - b))
    for value in a[1:]:
        cost = np.abs(value - b)
        base = np.empty(len(b), dtype=np.float64)
        base[0] = previous[0] + cost[0]
        base[1:] = np.minimum(previous[:-1] + 2 * cost[1:], previous[1:] + cost[1:])
        sums = np.empty(len(b), dtype=np.float64)
        sums[0] = 0.
        sums[1:] = np.cumsum(cost[1:])
        previous = sums + np.minimum.accumulate(base - sums)
    distance = float(previous[-1])
    # Row cumsum cancellation can cause tiny negatives for equal/near-equal data.
    if distance < 0 and distance > -1e-8: distance = 0.
    if not math.isfinite(distance) or distance < 0: raise FloatingPointError('Invalid DTW distance')
    return distance, distance / (len(a) + len(b))


def safe_corr(a, b):
    if len(a) < 2 or np.std(a) == 0 or np.std(b) == 0: return None
    return finite(np.corrcoef(a, b)[0, 1])


def profile_comparison(native, predicted, positional=True):
    n = min(len(native), len(predicted))
    native, predicted = np.asarray(native), np.asarray(predicted)
    joint = np.isfinite(native[:n]) & np.isfinite(predicted[:n])
    a, b = native[:n][joint], predicted[:n][joint]
    out = {'points': int(joint.sum()), 'possible_points': n,
           'mae': None, 'rmse': None, 'corr': None, 'dtw': None,
           'dtw_normalized': None, 'dtw_segments': 0}
    if len(a):
        difference = b - a
        out.update(mae=float(np.abs(difference).mean()),
                   rmse=float(np.sqrt(np.mean(difference ** 2))), corr=safe_corr(a, b))
    if positional:
        # Warping cannot jump across a missing/rare position. Score contiguous
        # runs of joint valid windows and normalize by their total N+M.
        edges = np.diff(np.r_[False, joint, False].astype(np.int8))
        starts, ends = np.flatnonzero(edges == 1), np.flatnonzero(edges == -1)
        distance = 0.
        for start, end in zip(starts, ends):
            d, _ = dtw_symmetric2(predicted[start:end], native[start:end]); distance += d
        if len(a): out.update(dtw=distance, dtw_normalized=distance / (2 * len(a)), dtw_segments=len(starts))
    else:
        d, nd = dtw_symmetric2(predicted, native)
        out.update(dtw=d, dtw_normalized=nd, dtw_segments=int(d is not None))
    return out


class MetricEngine:
    """Load once per scoring rank; score bounded batches using float64 matrices."""

    def __init__(self, codon_table_path, frozen_reference_path, wrong_species_universe):
        import pandas as pd
        reference_path = Path(frozen_reference_path)
        reference = json.loads(reference_path.read_text())
        receipt = json.loads((reference_path.parent / 'reference_manifest.json').read_text())
        if (receipt.get('status') != 'COMPLETE' or receipt.get('frozen_reference_sha256') != file_sha(reference_path)
                or receipt.get('identity_sha256') != reference.get('identity_sha256')):
            raise ValueError('Frozen reference file does not match its completed manifest')
        if (reference.get('schema') != 'ct2-frozen-legacy-cai-v1'
                or reference.get('status') != 'LEGACY_REFERENCE_FROZEN'
                or hashlib.sha256(canonical(reference['identity'])).hexdigest() != reference.get('identity_sha256')):
            raise ValueError('Frozen CAI reference identity/status is invalid')
        expected = reference['identity']['sources']['codon_table']['sha256']
        if file_sha(codon_table_path) != expected: raise ValueError('Codon table differs from the frozen reference')
        frame = pd.read_parquet(codon_table_path)
        self._initialize(frame, reference, wrong_species_universe)
        self.table_sha256 = expected
        self.reference_sha256 = file_sha(frozen_reference_path)

    @classmethod
    def from_frame(cls, frame, reference, wrong_species_universe):
        """In-memory constructor for analytical tests; file workflow uses __init__."""
        result = cls.__new__(cls)
        result._initialize(frame, reference, wrong_species_universe)
        result.table_sha256 = result.reference_sha256 = None
        return result

    def _initialize(self, frame, reference, wrong_species_universe):
        import pandas as pd
        required = {'species', 'aa', 'codon', 'frequency', 'rare_lt_0_001', 'rare_lt_0_01'}
        if not required.issubset(frame.columns) or frame.empty: raise ValueError('Invalid codon-table schema')
        if frame[list(required)].isna().any().any() or frame.duplicated(['species', 'codon']).any():
            raise ValueError('Null or duplicate codon-table entry')
        if not frame['species'].map(lambda x: isinstance(x, str) and bool(x)).all(): raise ValueError('Invalid host name')
        if not frame['codon'].map(lambda c: c in CODON_INDEX).all(): raise ValueError('Non-sense codon in table')
        if any(CODE[c] != aa for c, aa in zip(frame.codon, frame.aa)): raise ValueError('Table amino-acid annotation differs from standard code')
        freq = frame.frequency.to_numpy(dtype=np.float64)
        if not np.isfinite(freq).all() or (freq < 0).any(): raise ValueError('Invalid codon frequency')
        for col in RARE_COLUMNS.values():
            if not pd.api.types.is_bool_dtype(frame[col]): raise ValueError('Rare flags must be Boolean')
        self.species = sorted(frame.species.unique().tolist())
        self.species_index = {host: i for i, host in enumerate(self.species)}
        self.reference = reference
        self.reference_hosts = reference.get('species', {})
        for host, ref in self.reference_hosts.items():
            if (set(ref.get('weights', {})) != set(CODONS)
                    or any(not isinstance(w, (int, float)) or not math.isfinite(w) or not 0 < w <= 1
                           for w in ref['weights'].values())):
                raise ValueError('Invalid frozen CAI weights for ' + host)
            for mode in MODES[1:]:
                if not set(ref.get('rare_masks', {}).get(mode, [])).issubset(CODONS):
                    raise ValueError('Invalid frozen CAI rare mask')
        self.frequency = frame.pivot(index='species', columns='codon', values='frequency').reindex(index=self.species, columns=CODONS).to_numpy(dtype=np.float64)
        self.present = np.isfinite(self.frequency)
        self.rare = {'all': np.zeros_like(self.present)}
        for mode, col in RARE_COLUMNS.items():
            self.rare[mode] = frame.pivot(index='species', columns='codon', values=col).reindex(index=self.species, columns=CODONS).fillna(False).to_numpy(dtype=bool)
        self.formal, self.mask, self.rank_formal, self.raw_rank, self.minmax = {}, {}, {}, {}, {}
        for mode in MODES:
            keep = self.present & ~self.rare[mode]
            weights = np.full_like(self.frequency, np.nan)
            mm = np.full_like(self.frequency, np.nan)
            for cols in AA_COLUMNS.values():
                values = self.frequency[:, cols]
                active = keep[:, cols]
                count = active.sum(axis=1)
                maximum = np.max(np.where(active, values, -np.inf), axis=1)
                minimum = np.min(np.where(active, values, np.inf), axis=1)
                mean = np.sum(np.where(active, values, 0.), axis=1) / np.maximum(count, 1)
                denom = np.where(values >= mean[:, None], maximum[:, None] - mean[:, None], mean[:, None] - minimum[:, None])
                scores = np.divide(100 * (values - mean[:, None]), denom, out=np.zeros_like(values), where=(denom > 0))
                scores[(count <= 1) | (maximum == minimum), :] = 0.
                mm[:, cols] = np.where(active, scores, np.nan)
                weights[:, cols] = np.divide(values, maximum[:, None], out=np.full_like(values, np.nan), where=(active & (maximum[:, None] > 0)))
            positive = keep & (weights > 0) & np.isfinite(weights)
            logs = np.zeros_like(weights)
            np.log(weights, out=logs, where=positive)
            self.formal[mode] = logs.T.copy()
            self.mask[mode] = positive.T.astype(np.float64)
            self.rank_formal[mode] = np.where(positive, logs, -50.).T.copy()
            self.raw_rank[mode] = np.log(np.where(keep, np.maximum(self.frequency, EPS), EPS)).T.copy()
            self.minmax[mode] = mm
        if isinstance(wrong_species_universe, dict):
            universes = wrong_species_universe
        else: universes = {'*': wrong_species_universe}
        self.universes = {}
        for cohort, hosts in universes.items():
            hosts = sorted(set(hosts))
            missing = set(hosts) - self.species_index.keys()
            if missing: raise ValueError('Wrong-host universe includes hosts absent from table: ' + str(sorted(missing)[:5]))
            self.universes[str(cohort)] = np.array([self.species_index[h] for h in hosts], dtype=np.int64)

    def metadata(self):
        return dict(schema='ct2-biological-metrics-v1', table_sha256=self.table_sha256,
            frozen_reference_sha256=self.reference_sha256, ranked_species=len(self.species),
            reference_hosts=len(self.reference_hosts), modes=list(MODES), minmax_window=WINDOW,
            dtw='exact unbanded symmetric2, distance/(N+M); NumPy row-vectorized O(M) memory',
            rank_ties='1 + number of strictly greater log scores; float64 CPU arithmetic',
            legacy_formal_rank='all mode reproduces the retained formula: unscored log weight -50 and all sense codons in denominator; rare modes extend that formula with candidate-host filters and were not provided by the old formal rank script',
            legacy_raw_rank='candidate-host rare filters; missing/zero entries log(1e-9); all sense codons in denominator',
            requested_mask_rank='remove requested-host rare codons once; compare same retained positions against unfiltered all-host formal weights, missing=-50',
            own_wrong='legacy host-specific rare filters and scored denominators; wrong CSI is exp(mean(other-host mean log weights))',
            positional_minmax='18-codon original-position windows; every codon must be scored; DTW is segmented at joint missing windows',
            legacy_minmax='remove rare/missing codons independently before rolling; MAE compares common prefix; DTW uses both full compressed profiles',
            cai='retained top-CSI training selection, pseudocount1 weights; no weight substitution for unsupported hosts',
            hfc_ties='Highest requested-host synonymous frequency; lexicographically first codon on exact ties. This is an explicit baseline, not a claim of identical historical tie-breaking.',
            wrong_host_universes={k: [self.species[i] for i in v] for k, v in self.universes.items()},
            note='Float64 ranks are numerically more stable but close legacy float32 score ties can differ. Compare named definitions, cohorts and denominators.')

    def baseline_records(self, own_records):
        result = []
        for record in own_records:
            if record.get('requested_condition', 'own') != 'own': continue
            host = record.get('native_species', record.get('species'))
            protein = record['protein_sequence']
            if host not in self.species_index: raise ValueError('HFC baseline host absent from table: ' + str(host))
            sid = self.species_index[host]
            chosen = {}
            for aa, cols in AA_COLUMNS.items():
                available = [int(i) for i in cols if self.present[sid, i] and self.frequency[sid, i] > 0]
                if available: chosen[aa] = CODONS[max(available, key=lambda i: (self.frequency[sid, i], -i))]
            if any(aa not in chosen for aa in protein): raise ValueError('HFC lacks a positive synonymous codon for this protein')
            native = dict(record, requested_condition='native', predicted_dna=record['native_dna'])
            hfc = dict(record, requested_condition='hfc', predicted_dna=''.join(chosen[aa] for aa in protein)
                       + ('TAA' if record.get('terminal_stop_included', True) else ''))
            result.extend((native, hfc))
        return result

    def _sequence_fields(self, record):
        host = record.get('native_species', record.get('species'))
        protein = str(record.get('protein_sequence', '')).strip().upper()
        native = codon_list(record.get('native_dna', ''))
        dna = record.get('predicted_dna', record.get('pred_dna', ''))
        pred = codon_list(dna)
        known = [(i, c) for i, c in enumerate(native[:len(protein)]) if CODE.get(c) == protein[i]]
        compared = [(a, pred[i]) for i, a in known if i < len(pred) and pred[i] in CODON_INDEX]
        matched = sum(a == b for a, b in compared)
        native_gc = sum(a[2] in 'GC' for a, _ in compared) / len(compared) if compared else None
        pred_matched_gc = sum(b[2] in 'GC' for _, b in compared) / len(compared) if compared else None
        sense_pred = [c for c in pred if c in CODON_INDEX]
        condition = record.get('requested_condition', 'own')
        valid = generation_valid(dna, protein, record.get('terminal_stop_included', True))
        result = dict(eval_id=str(record['eval_id']), cohort=str(record.get('cohort', 'panel')),
            model=str(record.get('model', 'ct2')), species=host, requested_condition=condition,
            protein_length=len(protein), generation_valid=valid,
            terminal_stop_included=record.get('terminal_stop_included', True),
            codon_table_supported=host in self.species_index, cai_reference_supported=host in self.reference_hosts,
            predicted_sense_codons=len(sense_pred), native_known_positions=len(known),
            codon_recovery_positions=len(compared), recovered_codons=matched,
            codon_recovery=matched / len(compared) if compared else None,
            predicted_gc3=sum(c[2] in 'GC' for c in sense_pred) / len(sense_pred) if sense_pred else None,
            native_gc3_at_compared_positions=native_gc, predicted_gc3_at_compared_positions=pred_matched_gc,
            gc3_absolute_error=abs(native_gc - pred_matched_gc) if compared else None)
        # Native baselines can contain ambiguous native positions; score their
        # known sense codons and retain the explicit strict-validity denominator.
        if not valid and condition != 'native':
            for name in ('codon_recovery', 'predicted_gc3', 'native_gc3_at_compared_positions',
                         'predicted_gc3_at_compared_positions', 'gc3_absolute_error'): result[name] = None
        return result, native, pred, bool(valid or condition == 'native')

    def _minmax(self, native, pred, protein, sid, mode):
        lookup = self.minmax[mode][sid]
        def raw(codons): return np.array([lookup[CODON_INDEX[c]] if c in CODON_INDEX else np.nan for c in codons])
        a, b = raw(native), raw(pred)
        # The new positional metric excludes native codons that do not encode
        # the supplied protein. Preserve those original codons in legacy output.
        pa = np.full(len(protein), np.nan); pb = np.full(len(protein), np.nan)
        for i, aa in enumerate(protein):
            if i < len(native) and CODE.get(native[i]) == aa: pa[i] = a[i]
            if i < len(pred) and CODE.get(pred[i]) == aa: pb[i] = b[i]
        positional = profile_comparison(rolling_profile(pa), rolling_profile(pb), positional=True)
        legacy = profile_comparison(legacy_rolling_profile(a), legacy_rolling_profile(b), positional=False)
        native_codons = sum(c in CODON_INDEX for c in native)
        predicted_codons = sum(c in CODON_INDEX for c in pred)
        native_scored, pred_scored = int(np.isfinite(a).sum()), int(np.isfinite(b).sum())
        result = dict(native_minmax_scored_codons=native_scored, pred_minmax_scored_codons=pred_scored,
                      native_minmax_missing_fraction=(native_codons - native_scored) / max(native_codons, 1),
                      pred_minmax_missing_fraction=(predicted_codons - pred_scored) / max(predicted_codons, 1),
                      native_positional_minmax_scored_codons=int(np.isfinite(pa).sum()),
                      pred_positional_minmax_scored_codons=int(np.isfinite(pb).sum()),
                      native_minmax_mean=finite(a[np.isfinite(a)].mean()) if np.isfinite(a).any() else None,
                      pred_minmax_mean=finite(b[np.isfinite(b)].mean()) if np.isfinite(b).any() else None)
        result['abs_mean_minmax_diff'] = abs(result['native_minmax_mean'] - result['pred_minmax_mean']) if result['native_minmax_mean'] is not None and result['pred_minmax_mean'] is not None else None
        for label, scores in [('positional', positional), ('legacy', legacy)]:
            result.update({'minmax_' + label + '_' + key: value for key, value in scores.items()})
        return result

    def score_batch(self, records):
        """Return three named rare-mode rows per attempted generated record."""
        records = list(records)
        if len(records) > 64: raise ValueError('Use bounded scoring batches of at most 64 records')
        if not records: return []
        parsed = [self._sequence_fields(r) for r in records]
        counts = np.stack([codon_counts(r.get('predicted_dna', r.get('pred_dna', ''))) for r in records])
        total = counts.sum(axis=1)
        result = []
        for mode in MODES:
            denominators = counts @ self.mask[mode]
            logs = np.divide(counts @ self.formal[mode], denominators,
                             out=np.full_like(denominators, np.nan), where=denominators > 0)
            legacy_rank_logs = (counts @ self.rank_formal[mode]) / np.maximum(total[:, None], 1)
            raw_rank_logs = (counts @ self.raw_rank[mode]) / np.maximum(total[:, None], 1)
            masked = counts.copy()
            for i, (fields, _, _, _) in enumerate(parsed):
                sid = self.species_index.get(fields['species'])
                if sid is not None: masked[i, self.rare[mode][sid]] = 0
            masked_n = masked.sum(axis=1)
            masked_logs = (masked @ self.rank_formal['all']) / np.maximum(masked_n[:, None], 1)
            for i, (fields, native, pred, score_allowed) in enumerate(parsed):
                row = dict(fields, rare_mode=mode)
                for key in REQUIRED_METRICS:
                    row.setdefault(key, None)
                row.update(formal_csi_codons_used=0, formal_csi_wrong_hosts_used=0,
                           cai_codons_used=0, cai_rare_skipped=0, cai_missing_weights=0,
                           rank_species=len(self.species), requested_mask_rank_codons=int(masked_n[i]))
                sid = self.species_index.get(fields['species'])
                if score_allowed and sid is not None and total[i] > 0:
                    universe = self.universes.get(fields['cohort'], self.universes.get('*'))
                    if universe is None: raise ValueError('No frozen wrong-host universe for cohort ' + fields['cohort'])
                    own_log = finite(logs[i, sid])
                    wrong = logs[i, universe[universe != sid]]
                    wrong = wrong[np.isfinite(wrong)]
                    wrong_log = float(wrong.mean()) if len(wrong) else None
                    row.update(formal_csi_own=math.exp(own_log) if own_log is not None else None,
                        formal_csi_wrong_mean=math.exp(wrong_log) if wrong_log is not None else None,
                        formal_csi_own_log=own_log, formal_csi_wrong_mean_log=wrong_log,
                        formal_csi_delta_log=own_log - wrong_log if own_log is not None and wrong_log is not None else None,
                        formal_csi_codons_used=int(denominators[i, sid]), formal_csi_wrong_hosts_used=len(wrong))
                    row['formal_csi_ratio'] = math.exp(row['formal_csi_delta_log']) if row['formal_csi_delta_log'] is not None else None
                    for prefix, values, n in [('formal_rank_legacy', legacy_rank_logs[i], total[i]),
                                             ('raw_frequency_rank_legacy', raw_rank_logs[i], total[i]),
                                             ('formal_rank_requested_mask', masked_logs[i], masked_n[i])]:
                        rank = 1 + int((values > values[sid]).sum()) if n else None
                        row[prefix] = rank
                        row[prefix + '_log_score'] = float(values[sid]) if n else None
                        row[prefix + '_reciprocal'] = 1 / rank if rank is not None else None
                        for cutoff in (1, 5, 10, 100): row[prefix + '_top' + str(cutoff)] = float(rank <= cutoff) if rank is not None else None
                    ref = self.reference_hosts.get(fields['species'])
                    if ref is not None:
                        exclude = set(ref.get('rare_masks', {}).get(mode, []))
                        weighted = []
                        for codon, count in zip(CODONS, counts[i]):
                            if not count: continue
                            if codon in exclude: row['cai_rare_skipped'] += int(count); continue
                            weight = ref['weights'].get(codon)
                            if weight is None or not math.isfinite(weight) or weight <= 0:
                                row['cai_missing_weights'] += int(count); continue
                            weighted.append((int(count), math.log(weight)))
                        row['cai_codons_used'] = sum(n for n, _ in weighted)
                        if weighted:
                            row['cai_legacy_top10'] = math.exp(sum(n * log for n, log in weighted) / row['cai_codons_used'])
                    else: row['cai_missing_weights'] = int(total[i])
                    row.update(self._minmax(native, pred, records[i]['protein_sequence'], sid, mode))
                result.append(row)
        return result


def length_bucket(length):
    if length <= 509: return '0001-0509'
    if length <= 1021: return '0510-1021'
    if length <= 1533: return '1022-1533'
    if length <= 2045: return '1534-2045'
    return '2046-plus'


def summarize(rows):
    """Streaming macro/pooled summaries; no generated DNA or per-gene rows kept."""
    groups = {}
    counts = 0
    def new(): return {'attempted': 0, 'valid': 0, 'table_supported': 0, 'reference_supported': 0,
                       'codon_matches': 0, 'codon_positions': 0,
                       'metrics': {key: [0, 0., {}] for key in REQUIRED_METRICS if key != 'generation_valid'}}
    def add(state, row):
        state['attempted'] += 1
        state['valid'] += int(row['generation_valid'])
        state['table_supported'] += int(row['codon_table_supported'])
        state['reference_supported'] += int(row['cai_reference_supported'])
        if row['codon_recovery'] is not None:
            state['codon_matches'] += row['recovered_codons']; state['codon_positions'] += row['codon_recovery_positions']
        for key, value in row.items():
            if key in {'protein_length', 'recovered_codons', 'codon_recovery_positions', 'native_known_positions',
                       'generation_valid', 'codon_table_supported', 'cai_reference_supported'}: continue
            if value is None or isinstance(value, bool) or not isinstance(value, (int, float)): continue
            if not math.isfinite(value): raise ValueError('Nonfinite published metric: ' + key)
            acc = state['metrics'].setdefault(key, [0, 0., {}])
            acc[0] += 1; acc[1] += value
            if key in {'formal_rank_legacy', 'raw_frequency_rank_legacy', 'formal_rank_requested_mask'}:
                acc[2][int(value)] = acc[2].get(int(value), 0) + 1
    for row in rows:
        if any(k not in row for k in REQUIRED_METRICS): raise ValueError('Incomplete biological metric row')
        counts += 1
        key = (row['cohort'], row['model'], row['requested_condition'], row['rare_mode'])
        group = groups.setdefault(key, {'total': new(), 'species': {}, 'length': {}})
        add(group['total'], row)
        add(group['species'].setdefault(row['species'], new()), row)
        add(group['length'].setdefault(length_bucket(row['protein_length']), new()), row)
    def finish(state):
        def metric_summary(values):
            count, total, histogram = values
            result = {'scored': count, 'unscored': state['attempted'] - count, 'mean': total / count if count else None}
            if histogram:
                targets = ((count - 1) // 2, count // 2)
                running, medians = 0, []
                for value, n in sorted(histogram.items()):
                    medians.extend(value for target in targets if running <= target < running + n)
                    running += n
                result['median'] = sum(medians) / 2
            return result
        results = dict(attempted=state['attempted'], strict_valid_generations=state['valid'],
            validity_rate=state['valid'] / state['attempted'] if state['attempted'] else None,
            table_supported=state['table_supported'], cai_reference_supported=state['reference_supported'],
            pooled_codon_recovery=state['codon_matches'] / state['codon_positions'] if state['codon_positions'] else None,
            pooled_codon_recovery_positions=state['codon_positions'],
            metrics={k: metric_summary(v) for k, v in sorted(state['metrics'].items())})
        results['geometric_sequence_csi'] = {}
        for key in ('formal_csi_own_log', 'formal_csi_wrong_mean_log'):
            if key in results['metrics']:
                value = results['metrics'][key]
                results['geometric_sequence_csi'][key] = dict(scored=value['scored'],
                    unscored=value['unscored'], geometric_mean=math.exp(value['mean']) if value['mean'] is not None else None)
        return results
    result = []
    for key, group in sorted(groups.items()):
        hosts = {host: finish(value) for host, value in sorted(group['species'].items())}
        macro_values = defaultdict(list)
        for host in hosts.values():
            for metric, values in host['metrics'].items():
                if values['mean'] is not None: macro_values[metric].append(values['mean'])
                else: macro_values[metric]  # Retain the all-unscored metric with an empty host list.
        result.append(dict(zip(('cohort', 'model', 'requested_condition', 'rare_mode'), key),
            **finish(group['total']), species_attempted=len(hosts),
            macro_by_species={m: {'species_scored': len(v), 'species_unscored': len(hosts) - len(v),
                                 'mean': sum(v) / len(v) if v else None} for m, v in sorted(macro_values.items())},
            by_species=hosts, by_length={k: finish(v) for k, v in sorted(group['length'].items())}))
    return {'schema': 'ct2-biological-summary-v1', 'metric_rows': counts, 'groups': result,
            'definitions': {'sequence_mean': 'Arithmetic mean over scored sequences; scored/unscored counts explicit',
                            'macro_by_species': 'Unweighted arithmetic mean of host-specific sequence means',
                            'pooled_codon_recovery': 'Total recovered known codons / total compared known positions',
                            'rare_mode_rows': 'Each attempted generation appears once in each of three rare modes'}}
