#!/usr/bin/env python3
"""Discarded eight-H100 replay and tail/memory probes for finite CT2 windows.

This executable has no production-training mode. Each length is independently
initialized from the reviewed 40k model, with a fresh AdamW optimizer. Only the
split/resume branch imports this candidate's own optimizer and committed loader.
"""
from __future__ import annotations
import argparse
import contextlib
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import random
import sys
import time

from candidate_model import (SOURCE_CHECKPOINT_SHA256, build_from_state, canonical_identity,
                             load_source, new_optimizer, runtime_versions, sha, tokenizer_at,
                             validate_plan_identity, validate_repo)
from candidate_collator import CandidateCollator

FORMAT = 'ct2-finite-preflight-v1'
EXPECTED_BUCKET_BYTES = [103443816, 30680064, 29500416, 30680064, 29500416,
    30680064, 29500416, 30680064, 29500416, 30680064, 29500416, 30680064,
    29500416, 30680064, 29500416, 7357440]
STAGE_GEOMETRY = [(512, .05, 192, 1, 1, 2e-5), (1024, .10, 56, 3, 2, 5e-6),
                  (1536, .20, 56, 3, 2, 2e-6), (2048, .30, 32, 5, 2, 1e-6)]


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name('.' + path.name + '.' + str(os.getpid()))
    try:
        with tmp.open('w') as stream:
            json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
            stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def stage_spec(plan, stage):
    if not 0 <= stage < 4:
        raise ValueError('Stage must be in 0..3')
    spec = plan['stages'][stage]
    length, full, micro, accumulation, workers, lr = STAGE_GEOMETRY[stage]
    expected = dict(max_length=length, full_mask_probability=full, batch_per_gpu=micro,
                    accumulation=accumulation, num_workers=workers, learning_rate_preflight=lr)
    for key, value in expected.items():
        if spec.get(key) != value:
            raise ValueError('Candidate stage geometry changed: ' + key)
    return spec


def initialize():
    import torch
    import torch.distributed as dist
    from execution_profile import configure
    configure()
    if not torch.cuda.is_available():
        raise RuntimeError('Use the dedicated eight-H100 Slurm preflight allocation')
    rank = int(os.environ['SLURM_PROCID'])
    world = int(os.environ['SLURM_NTASKS'])
    local = int(os.environ['SLURM_LOCALID'])
    if world != 8 or not 0 <= rank < world:
        raise RuntimeError('The preflight requires exactly eight distributed ranks')
    index = 0 if torch.cuda.device_count() == 1 else local
    torch.cuda.set_device(index)
    device = torch.device('cuda', index)
    if 'H100' not in torch.cuda.get_device_name(device):
        raise RuntimeError('The requested candidate geometry must be checked on H100 GPUs')
    dist.init_process_group('nccl', rank=rank, world_size=world, timeout=timedelta(minutes=15))
    torch.set_num_threads(int(os.environ.get('OMP_NUM_THREADS', '8')))
    hosts = gather({'rank': rank, 'host': os.uname().nodename, 'device': index,
                    'visible': os.environ.get('CUDA_VISIBLE_DEVICES')})
    if len({(h['host'], h['device'], h['visible']) for h in hosts}) != 8:
        raise RuntimeError('Distributed GPU binding is not one GPU per rank')
    counts = {}
    for h in hosts:
        counts[h['host']] = counts.get(h['host'], 0) + 1
    if sorted(counts.values()) != [4, 4]:
        raise RuntimeError('Use the intended topology: two H100 nodes, four ranks per node')
    versions = runtime_versions()
    all_versions = gather(versions)
    if any(value != versions for value in all_versions):
        raise RuntimeError('Ranks have different runtime versions')
    return device, rank, versions, hosts


def gather(value):
    import torch.distributed as dist
    values = [None] * dist.get_world_size()
    dist.all_gather_object(values, value)
    return values


def rank0_action(action):
    """Propagate preparation failures before another rank enters a barrier."""
    import torch.distributed as dist
    result = [None]
    if dist.get_rank() == 0:
        try:
            result[0] = {'ok': True, 'value': action()}
        except Exception as error:
            result[0] = {'ok': False, 'error': type(error).__name__ + ': ' + str(error)}
    dist.broadcast_object_list(result, src=0)
    if not result[0]['ok']:
        raise RuntimeError(result[0]['error'])
    return result[0].get('value')


def seed_all(seed):
    import numpy as np
    import torch
    random.seed(seed); np.random.seed(seed % 2**32); torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def rng_state():
    import numpy as np
    import torch
    return {'python': random.getstate(), 'numpy': np.random.get_state(),
            'torch': torch.get_rng_state(), 'cuda': torch.cuda.get_rng_state()}


def restore_rng(value):
    import numpy as np
    import torch
    random.setstate(value['python']); np.random.set_state(value['numpy'])
    torch.set_rng_state(value['torch']); torch.cuda.set_rng_state(value['cuda'])


def ddp_policy(ddp):
    actual = {'find_unused_parameters': bool(ddp.find_unused_parameters),
              'static_graph': bool(ddp.static_graph), 'broadcast_buffers': bool(ddp.broadcast_buffers)}
    if actual != dict(find_unused_parameters=True, static_graph=False, broadcast_buffers=False):
        raise RuntimeError('Candidate DDP constructor flags differ from the audited policy')
    # Observational PyTorch 2.6 reducer logging; missing instrumentation fails this
    # preflight instead of pretending a bucket-layout check was performed.
    sizes = ddp._get_ddp_logging_data().get('bucket_sizes')
    if isinstance(sizes, str):
        sizes = [int(x.strip()) for x in sizes.split(',') if x.strip()]
    if not isinstance(sizes, (list, tuple)) or list(sizes) != EXPECTED_BUCKET_BYTES:
        raise RuntimeError('Ordered DDP bucket byte sizes differ: ' + repr(sizes))
    actual['ordered_bucket_bytes'] = list(sizes)
    return actual


def optimizer_update(module, optimizer, batches, device, lr):
    """Globally normalize once over all supervised tokens in the update."""
    import torch
    import torch.distributed as dist
    local_count = sum(int(batch['labels'].ne(-100).sum()) for batch in batches)
    total = torch.tensor(local_count, dtype=torch.int64, device=device)
    dist.all_reduce(total)
    if int(total) <= 0:
        raise ValueError('An optimizer update has no global supervised targets')
    for group in optimizer.param_groups:
        group['lr'] = lr
    optimizer.zero_grad(set_to_none=True)
    scale = dist.get_world_size() / int(total)
    metrics = torch.zeros(9, dtype=torch.float64, device=device)
    module.train()
    for index, cpu in enumerate(batches):
        batch = {key: value.to(device) for key, value in cpu.items()}
        context = module.no_sync() if index < len(batches) - 1 else contextlib.nullcontext()
        with context:
            with torch.autocast('cuda', dtype=torch.bfloat16):
                logits = module(batch['input_ids'], batch['attention_mask'], batch['species_id'])
            losses = torch.nn.functional.cross_entropy(
                logits.float().reshape(-1, logits.shape[-1]), batch['labels'].reshape(-1),
                ignore_index=-100, reduction='none').reshape_as(batch['labels'])
            loss = losses.sum() * scale
            if not torch.isfinite(loss):
                raise FloatingPointError('Nonfinite supervised loss')
            loss.backward()
        with torch.no_grad():
            for kind, rows in enumerate((~batch['full'] & batch['real'], batch['full'] & batch['real'])):
                mask = rows[:, None] & batch['labels'].ne(-100)
                metrics[2 * kind] += losses.detach()[mask].double().sum()
                metrics[2 * kind + 1] += mask.sum()
            metrics[4] += batch['real'].sum()
            metrics[5] += (batch['attention_mask'] * batch['real'][:, None]).sum()
            metrics[6] += batch['full'].sum()
            metrics[7] += batch['unknown'].sum()
            metrics[8] += batch['record_first'].sum()
    norm = torch.nn.utils.clip_grad_norm_(module.parameters(), .5, error_if_nonfinite=True)
    optimizer.step()
    dist.all_reduce(metrics)
    # Existing clip_grad_norm_ uses epsilon 1e-6 when computing the factor.
    factor = min(1., .5 / (float(norm) + 1e-6))
    if int(metrics[1] + metrics[3]) != int(total):
        raise RuntimeError('Reported target count differs from the normalization denominator')
    return metrics.cpu().tolist(), float(norm), factor, local_count


def verify_optimizer(optimizer, completed, names, saved_names):
    import torch
    if names != saved_names or len(optimizer.param_groups) != 2:
        raise ValueError('Candidate optimizer parameter order/group identity changed')
    for index, group in enumerate(optimizer.param_groups):
        if (tuple(group['betas']) != (.9, .999) or group['eps'] != 1e-8
                or group.get('amsgrad', False) or group['weight_decay'] != (.01 if index == 0 else 0.)):
            raise ValueError('Candidate optimizer hyperparameters changed')
        for parameter in group['params']:
            state = optimizer.state.get(parameter)
            if not state or float(state['step']) != completed:
                raise ValueError('Candidate AdamW age differs from its completed update count')
            for key in ('exp_avg', 'exp_avg_sq'):
                if state[key].shape != parameter.shape or not torch.isfinite(state[key]).all():
                    raise ValueError('Invalid candidate optimizer moment: ' + key)


def save_checkpoint(output, model, optimizer, names, pipeline, plan, stage, branch,
                    completed, statistics, provenance, versions, policy):
    import torch
    import torch.distributed as dist
    from execution_profile import assert_profile
    states = gather({'rank': dist.get_rank(), 'stream': pipeline.state_dict(), 'rng': rng_state()})
    if sum(state['stream']['committed_windows'] for state in states) != int(statistics['totals'][4]):
        raise RuntimeError('Committed window count differs from trained real-window count')
    if sum(state['stream']['committed_records'] for state in states) != statistics['physical_records']:
        raise RuntimeError('Committed physical-record count differs from trained record starts')
    if sum(state['stream']['committed_known_targets'] for state in states) < statistics['totals'][1] + statistics['totals'][3]:
        raise RuntimeError('Supervised targets exceed committed known-target opportunities')
    verify_optimizer(optimizer, completed, names, names)
    settings = assert_profile(model)
    path = Path(output) / f'update_{completed:06d}.ckpt'
    def write():
        value = {'format': FORMAT, 'plan_identity': plan['identity'], 'stage': stage,
                 'branch': branch, 'completed_updates': completed, 'source': provenance,
                 'world_size': 8, 'state_dict': model.state_dict(),
                 'model_config': model.model.config.to_dict(), 'species_embed_scale': model.scale,
                 'optimizer_state': optimizer.state_dict(), 'optimizer_parameter_names': names,
                 'rank_states': states, 'execution_settings': settings, 'ddp_policy': policy,
                 'padding_policy': 'fixed_stage_max_length',
                 'statistics': statistics, 'runtime_versions': versions,
                 'training_ready': False, 'production_resume_allowed': False}
        temporary = path.with_name('.' + path.name + '.' + str(os.getpid()))
        try:
            with temporary.open('wb') as stream:
                torch.save(value, stream); stream.flush(); os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)
        return str(path)
    rank0_action(write)
    return path


def validate_resume(checkpoint, plan, stage):
    if (checkpoint.get('format') != FORMAT or checkpoint.get('plan_identity') != plan['identity']
            or checkpoint.get('stage') != stage or checkpoint.get('branch') != 'split'
            or checkpoint.get('completed_updates') != 16 or checkpoint.get('world_size') != 8
            or checkpoint.get('production_resume_allowed') is not False):
        raise ValueError('Resume requires this stage/plan\'s own 16-update split checkpoint')
    if checkpoint.get('source', {}).get('checkpoint_sha256') != SOURCE_CHECKPOINT_SHA256:
        raise ValueError('Resume source provenance differs from the reviewed checkpoint')
    if any(checkpoint['source'].get(key) != value for key, value in plan['source'].items()):
        raise ValueError('Resume source metadata differs from the finite plan')
    if checkpoint.get('padding_policy') != 'fixed_stage_max_length':
        raise ValueError('Resume padding policy differs from this candidate')
    if (checkpoint.get('source', {}).get('imported_model_only') is not True
            or checkpoint['source'].get('source_global_step') != 120000
            or checkpoint['source'].get('optimizer_age_at_import') != 0):
        raise ValueError('Resume checkpoint lacks weights-only import provenance')
    if len(checkpoint.get('rank_states', [])) != 8:
        raise ValueError('Resume checkpoint lacks all eight rank states')
    for rank, state in enumerate(checkpoint['rank_states']):
        if state.get('rank') != rank:
            raise ValueError('Resume rank state order is invalid')


def run(args):
    import torch
    import torch.distributed as dist
    from torch.nn.parallel import DistributedDataParallel
    from execution_profile import assert_profile, validate_snapshot
    from finite_pipeline import FinitePipeline
    plan = json.loads(Path(args.plan).read_text())
    validate_plan_identity(plan)
    spec = stage_spec(plan, args.stage)
    device, rank, versions, hosts = initialize()
    output = Path(args.output).resolve()
    def prepare_output():
        if output.exists() and any(output.iterdir()):
            raise FileExistsError('Refusing to overwrite candidate branch output: ' + str(output))
        output.mkdir(parents=True, exist_ok=True)
    rank0_action(prepare_output)
    if args.branch == 'resume' and not args.resume:
        raise ValueError('--resume is required for the resume branch')
    if args.branch != 'resume' and args.resume:
        raise ValueError('Only the resume branch accepts a candidate checkpoint')
    seed = int(plan.get('seed', 123))
    completed = 0
    statistics = dict(totals=[0.] * 8, grad_norms=[], clipping_factors=[], clip_count=0,
                      physical_records=0, active_seconds=0.)
    checkpoint = None
    pipeline = None
    try:
        if args.branch == 'resume':
            checkpoint = torch.load(args.resume, map_location='cpu', weights_only=False, mmap=True)
            validate_resume(checkpoint, plan, args.stage)
            repo, _ = validate_repo(plan['source'])
            tokenizer = tokenizer_at(repo)
            validate_snapshot(checkpoint['execution_settings'])
            model = build_from_state(checkpoint['model_config'], checkpoint['state_dict'],
                                     checkpoint['species_embed_scale'], tokenizer, device)
            provenance = checkpoint['source']
            completed = checkpoint['completed_updates']
            statistics = copy.deepcopy(checkpoint['statistics'])
        else:
            # Hash once on rank zero, then bind each rank's load to the same file.
            actual = rank0_action(lambda: sha(plan['source']['checkpoint']))
            if actual != SOURCE_CHECKPOINT_SHA256:
                raise ValueError('Source checkpoint hash differs from the reviewed 40k file')
            model, tokenizer, provenance = load_source(plan, device, verify_checkpoint_hash=False)
        if any(value != provenance for value in gather(provenance)):
            raise ValueError('Ranks loaded different source provenance')
        optimizer, names = new_optimizer(model)
        if checkpoint is not None:
            optimizer.load_state_dict(checkpoint['optimizer_state'])
            verify_optimizer(optimizer, completed, names, checkpoint['optimizer_parameter_names'])
        ddp = DistributedDataParallel(model, device_ids=[device.index],
            find_unused_parameters=True, static_graph=False, broadcast_buffers=False)
        policy = ddp_policy(ddp)
        if any(value != policy for value in gather(policy)):
            raise ValueError('Ranks created different DDP policies/bucket sizes')
        if checkpoint is not None and checkpoint['ddp_policy'] != policy:
            raise ValueError('DDP policy changed on restart')
        pipeline = FinitePipeline(plan, args.stage, rank,
                                  resume_state=checkpoint['rank_states'][rank]['stream'] if checkpoint else None)
        workers = list(pipeline.worker_pids.values())
        if (len(workers) != spec['num_workers'] or len(set(workers)) != len(workers)
                or any(type(pid) is not int or pid <= 0 for pid in workers)):
            raise RuntimeError('Actual preprocessing worker count differs from the stage plan')
        worker_observations = gather({'rank': rank, 'host': os.uname().nodename,
                                      'worker_pids': workers, 'num_workers': len(workers)})
        collator = CandidateCollator(tokenizer, seed=seed, rank=rank, stage=args.stage)
        if checkpoint is not None:
            restore_rng(checkpoint['rank_states'][rank]['rng'])
        else:
            seed_all(seed + 100003 * args.stage + rank)
        del checkpoint
        torch.cuda.reset_peak_memory_stats(device)
        stop = 16 if args.branch == 'split' else 32
        update_records = []
        while completed < stop:
            tick = time.monotonic()
            batches = [collator(pipeline.next_batch(), spec['max_length'],
                                spec['full_mask_probability'], completed, micro)
                       for micro in range(spec['accumulation'])]
            metrics, norm, factor, local_targets = optimizer_update(
                ddp, optimizer, batches, device, spec['learning_rate_preflight'])
            del batches
            completed += 1
            statistics['totals'] = [a + b for a, b in zip(statistics['totals'], metrics[:8])]
            statistics['physical_records'] += int(metrics[8])
            statistics['grad_norms'].append(norm)
            statistics['clipping_factors'].append(factor)
            statistics['clip_count'] += int(factor < 1.)
            statistics['active_seconds'] += time.monotonic() - tick
            assert_profile(model)
            current_policy = ddp_policy(ddp)
            if current_policy != policy:
                raise RuntimeError('DDP bucket byte sizes changed within the candidate branch')
            rank_observations = gather({'rank': rank, 'local_targets': local_targets,
                                        'ddp_policy': current_policy})
            if rank == 0:
                record = {'update': completed, 'global_targets': int(metrics[1] + metrics[3]),
                          'real_windows': int(metrics[4]), 'physical_records': int(metrics[8]),
                          'preclip_norm': norm, 'clipping_factor': factor,
                          'update_seconds': time.monotonic() - tick, 'ranks': rank_observations}
                update_records.append(record)
                print('CT2_FINITE_PREFLIGHT_UPDATE ' + json.dumps(record), flush=True)
            if completed in (16, 32):
                save_checkpoint(output, model, optimizer, names, pipeline, plan, args.stage,
                                args.branch, completed, statistics, provenance, versions, policy)
        memory = gather({'rank': rank, 'peak_allocated_bytes': torch.cuda.max_memory_allocated(device),
                         'peak_reserved_bytes': torch.cuda.max_memory_reserved(device),
                         'gpu': torch.cuda.get_device_name(device)})
        if rank == 0:
            atomic_json(output / 'branch_report.json', {
                'status': 'BRANCH_COMPLETE_NOT_REPLAY_GATE', 'plan_identity': plan['identity'],
                'stage': args.stage, 'branch': args.branch, 'completed_updates': completed,
                'fresh_optimizer': args.branch != 'resume', 'source': provenance,
                'runtime_versions': versions, 'topology': hosts, 'memory': memory,
                'padding_policy': 'fixed_stage_max_length', 'workers': worker_observations,
                'ddp_policy': policy, 'statistics': statistics, 'updates': update_records,
                'training_ready': False, 'production_resume_allowed': False,
                'limitation': 'Must compare reference/split/resume checkpoints and pass synthetic full-width/tail probes.'})
        dist.barrier()
    finally:
        if pipeline is not None:
            pipeline.close()


def probe(args):
    """Full-width capacity and uneven-rank zero-loss normalization checks."""
    import torch
    import torch.distributed as dist
    from torch.nn.parallel import DistributedDataParallel
    from execution_profile import assert_profile
    plan = json.loads(Path(args.plan).read_text())
    validate_plan_identity(plan); spec = stage_spec(plan, args.stage)
    device, rank, versions, hosts = initialize()
    output = Path(args.output).resolve()
    def prepare():
        if output.exists() and any(output.iterdir()):
            raise FileExistsError('Refusing to overwrite probe output')
        output.mkdir(parents=True, exist_ok=True)
    rank0_action(prepare)
    actual = rank0_action(lambda: sha(plan['source']['checkpoint']))
    if actual != SOURCE_CHECKPOINT_SHA256:
        raise ValueError('Wrong source checkpoint SHA256')
    model, tokenizer, provenance = load_source(plan, device, verify_checkpoint_hash=False)
    optimizer, names = new_optimizer(model)
    ddp = DistributedDataParallel(model, device_ids=[device.index],
        find_unused_parameters=True, static_graph=False, broadcast_buffers=False)
    policy = ddp_policy(ddp)
    seed_all(int(plan.get('seed', 123)) + 100003 * args.stage + rank)
    collator = CandidateCollator(tokenizer, seed=int(plan.get('seed', 123)), rank=rank, stage=args.stage)
    tokens = [tokenizer.get_vocab()['m_atg']] * (spec['max_length'] - 2)
    rows = [{'token_ids': tokens, 'species_id': (rank * spec['batch_per_gpu'] + i) % 26678,
             'identity': f'synthetic:{rank}:{i}', 'record_first': True}
            for i in range(spec['batch_per_gpu'])]
    reports = []
    torch.cuda.reset_peak_memory_stats(device)
    for update, mode in enumerate(('full_width_candidate_mix', 'full_width_all_fullmask', 'uneven_rank_tail')):
        active = mode != 'uneven_rank_tail' or rank == 0
        probability = 1. if mode != 'full_width_candidate_mix' else spec['full_mask_probability']
        batches = [collator(rows if active else [], spec['max_length'], probability, update, micro)
                   for micro in range(spec['accumulation'])]
        metrics, norm, factor, local_targets = optimizer_update(
            ddp, optimizer, batches, device, spec['learning_rate_preflight'])
        expected_rows = (8 if mode != 'uneven_rank_tail' else 1) * spec['batch_per_gpu'] * spec['accumulation']
        if int(metrics[4]) != expected_rows or int(metrics[8]) != expected_rows:
            raise RuntimeError('Dummy tail padding was counted as real training data')
        if mode != 'full_width_candidate_mix':
            expected_targets = expected_rows * (spec['max_length'] - 2)
            if int(metrics[1] + metrics[3]) != expected_targets:
                raise RuntimeError('Full-width/tail supervised target count is incorrect')
        if not active and local_targets != 0:
            raise RuntimeError('An exhausted rank supplied nonzero targets')
        assert_profile(model)
        if ddp_policy(ddp) != policy:
            raise RuntimeError('DDP policy changed during tail/memory probes')
        reports.append({'mode': mode, 'global_metrics': metrics, 'preclip_norm': norm,
                        'clipping_factor': factor, 'ranks': gather({'rank': rank, 'local_targets': local_targets})})
        del batches
    memory = gather({'rank': rank, 'peak_allocated_bytes': torch.cuda.max_memory_allocated(device),
                     'peak_reserved_bytes': torch.cuda.max_memory_reserved(device),
                     'gpu': torch.cuda.get_device_name(device)})
    if rank == 0:
        atomic_json(output / 'probe_report.json', {'status': 'MEMORY_AND_TAIL_PROBES_PASS',
            'plan_identity': plan['identity'], 'stage': args.stage, 'source': provenance,
            'runtime_versions': versions, 'topology': hosts, 'ddp_policy': policy,
            'padding_policy': 'fixed_stage_max_length',
            'probes': reports, 'memory': memory, 'discarded_optimizer_updates': 3,
            'training_ready': False, 'production_resume_allowed': False})
    dist.barrier()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True, type=Path)
    parser.add_argument('--stage', required=True, type=int, choices=range(4))
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--branch', choices=('reference', 'split', 'resume'))
    parser.add_argument('--resume', type=Path)
    parser.add_argument('--probe', action='store_true')
    args = parser.parse_args(argv)
    if args.probe:
        if args.branch or args.resume:
            parser.error('--probe cannot be combined with --branch/--resume')
    elif not args.branch:
        parser.error('--branch is required unless --probe is selected')
    try:
        (probe if args.probe else run)(args)
        return 0
    except Exception as error:
        print('CT2_GPU_PREFLIGHT_FAILED ' + type(error).__name__ + ': ' + str(error), file=sys.stderr, flush=True)
        return 1
    finally:
        # Clean shutdown on success and normal Python failures. The launcher also
        # uses srun --kill-on-bad-exit so one failing rank terminates the job step.
        import torch.distributed as dist
        if dist.is_available() and dist.is_initialized():
            dist.destroy_process_group()


if __name__ == '__main__':
    raise SystemExit(main())
