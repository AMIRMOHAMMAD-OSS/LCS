"""Finite plan consistency, corpus binding, and exact lane-tail accounting."""
from __future__ import annotations
import copy
import io
import json
from pathlib import Path
import shutil
import tarfile
import tempfile
import unittest
from unittest.mock import patch

import census
import finite_plan as fp

HERE = Path(__file__).resolve().parent


def write_shard(path, documents):
    with tarfile.open(path, 'w:gz') as archive:
        for i, doc in enumerate(documents):
            raw = json.dumps(doc).encode()
            member = tarfile.TarInfo(f'{i:06d}.json'); member.size = len(raw)
            archive.addfile(member, io.BytesIO(raw))


def make_fixture(root):
    repo, data, out = root / 'repo', root / 'data', root / 'census'
    shutil.copytree(HERE / 'policy_fixture', repo, ignore=shutil.ignore_patterns('__pycache__'))
    data.mkdir(); out.mkdir()
    policy = census.Policy(repo)
    config = {'source': 'synthetic-fixture'}
    config['fingerprint'] = policy.common.fingerprint(config)
    (repo / 'run.json').write_text(json.dumps(config))
    short = {'dna_sequence': 'ATGGCTTAA', 'protein_sequence': 'MA', 'species': 0}
    long = {'dna_sequence': 'ATG' + 'GCT' * 620 + 'TAA', 'protein_sequence': 'M' + 'A' * 620, 'species': 1}
    bad = {'dna_sequence': 'ATGG', 'protein_sequence': 'M', 'species': 0}
    for i, docs in enumerate(([short] * 195 + [long], [short] * 62, [bad])):
        write_shard(data / f'shard-{i:06d}.tar.gz', docs)
    rows = census.inventory(data, 3)
    manifest = census.prepare_manifest(out, census.make_manifest(repo, data, rows))
    for row in rows: census.scan_shard(data, row, out, manifest['identity'], policy)
    census.summarize(out, manifest)
    return repo, data, out, config['fingerprint']


class FinitePlanTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='finite-plan-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo, self.data, self.out, self.fingerprint = make_fixture(self.root)

    def build(self, **kwargs):
        with patch.object(fp, 'SOURCE_FINGERPRINT', self.fingerprint):
            return fp.build_plan(self.out, self.repo, world_size=2, **kwargs)

    def test_exact_partition_counts_and_lane_tail_steps(self):
        plan = self.build()
        self.assertIs(fp.validate_plan(plan), plan)
        self.assertFalse(plan['training_ready'])
        self.assertEqual(plan['shuffle_buffer'], 1024)
        self.assertEqual(plan['padding_policy'], 'fixed_stage_max_length')
        self.assertEqual([s['num_workers'] for s in plan['stages']], [1, 2, 2, 2])
        self.assertEqual([s['windows'] for s in plan['stages']], [259, 258, 258, 258])
        self.assertEqual([s['records'] for s in plan['stages']], [258] * 4)
        for stage in plan['stages']:
            assigned = [i for lane in stage['lanes'] for i in lane['shard_ids']]
            self.assertEqual(sorted(assigned), [0, 1, 2])
            self.assertEqual(len(assigned), len(set(assigned)))
            self.assertEqual(sum(stage['rank_real_windows']), stage['windows'])
            self.assertEqual(stage['steps'], max((n + stage['accumulation'] - 1) // stage['accumulation']
                                                for n in stage['rank_batches']))
            self.assertTrue(all(n >= 0 for n in stage['rank_padding_microbatches']))
        first = plan['stages'][0]
        self.assertEqual(sorted(first['rank_batches']), [1, 2])
        self.assertEqual(first['steps'], 2)

    def test_deterministic_identity_and_changed_seed(self):
        a, b, c = self.build(), self.build(), self.build(seed=124)
        self.assertEqual(a, b)
        self.assertNotEqual(a['identity'], c['identity'])

    def test_plan_rejects_changed_geometry_even_when_resealed(self):
        plan = self.build()
        plan['stages'][0]['steps'] += 1
        plan['identity'] = census.digest({k: v for k, v in plan.items() if k != 'identity'})
        with self.assertRaisesRegex(ValueError, 'assignment, settings or counters'):
            fp.validate_plan(plan)

    def test_plan_requires_explicit_padding_and_shuffle_policy(self):
        for key, value in [('padding_policy', 'dynamic'), ('shuffle_buffer', 128)]:
            with self.subTest(key=key):
                plan = self.build(); plan[key] = value
                plan['identity'] = census.digest({k: v for k, v in plan.items() if k != 'identity'})
                with self.assertRaises(ValueError): fp.validate_plan(plan)
                del plan[key]
                plan['identity'] = census.digest({k: v for k, v in plan.items() if k != 'identity'})
                with self.assertRaises(ValueError): fp.validate_plan(plan)

    def test_missing_or_failed_receipt_is_rejected(self):
        path = census.receipt_path(self.out, 'shard-000001.tar.gz')
        receipt = json.loads(path.read_text()); receipt['status'] = 'ERROR'
        path.write_text(json.dumps(receipt))
        with self.assertRaisesRegex(ValueError, 'receipt'): self.build()
        path.unlink()
        with self.assertRaises(FileNotFoundError): self.build()

    def test_count_change_cannot_hide_behind_complete_status(self):
        path = census.receipt_path(self.out, 'shard-000001.tar.gz')
        receipt = json.loads(path.read_text())
        receipt['counts']['full_gene']['max_protein_length'] += 1000
        path.write_text(json.dumps(receipt))
        with self.assertRaisesRegex(ValueError, 'Aggregated shard receipts'): self.build()

    def test_changed_content_hash_is_rejected(self):
        path = census.receipt_path(self.out, 'shard-000001.tar.gz')
        receipt = json.loads(path.read_text()); receipt['compressed_sha256'] = '0' * 64
        path.write_text(json.dumps(receipt))
        with self.assertRaisesRegex(ValueError, 'content identity'): self.build()

    def test_input_stat_drift_and_source_policy_drift_are_rejected(self):
        path = self.data / 'shard-000001.tar.gz'
        with path.open('ab') as f: f.write(b'changed')
        with self.assertRaisesRegex(ValueError, 'inventory changed'): self.build()
        (self.repo / 'common.py').write_text('# changed\n')
        with self.assertRaisesRegex(ValueError, 'Policy files differ'): self.build()

    def test_manifest_and_source_fingerprint_drift_are_rejected(self):
        path = self.out / 'census_manifest.json'
        doc = json.loads(path.read_text()); doc['identity_inputs']['scanner_version'] = 99
        path.write_text(json.dumps(doc))
        with self.assertRaisesRegex(ValueError, 'manifest identity'): self.build()
        (self.repo / 'run.json').write_text('{"fingerprint":"changed"}')
        with self.assertRaisesRegex(ValueError, 'Source run fingerprint'): self.build()

    def test_duplicate_json_and_incomplete_summary_are_rejected(self):
        path = self.out / 'census_summary.json'
        original = path.read_text()
        path.write_text('{"status":"COMPLETE","status":"INCOMPLETE"}')
        with self.assertRaisesRegex(ValueError, 'Duplicate JSON key'): self.build()
        doc = json.loads(original); doc['status'] = 'INCOMPLETE'
        path.write_text(json.dumps(doc))
        with self.assertRaisesRegex(ValueError, 'COMPLETE'): self.build()


if __name__ == '__main__':
    unittest.main()
