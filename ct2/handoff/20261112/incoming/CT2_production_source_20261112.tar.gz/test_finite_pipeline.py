"""Real spawn-worker coverage, integrity, tails, and committed-cursor replay."""
from __future__ import annotations
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import finite_plan as fp
from finite_pipeline import FinitePipeline
from test_finite_plan import make_fixture


class FinitePipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='finite-pipeline-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo, self.data, self.census, fingerprint = make_fixture(self.root)
        with patch.object(fp, 'SOURCE_FINGERPRINT', fingerprint):
            self.plan = fp.build_plan(self.census, self.repo, world_size=1)

    def run_all(self, stage, resume=None, prefetch=2, plan=None, rank=0):
        batches = []
        with FinitePipeline(plan or self.plan, stage, rank, resume_state=resume, prefetch=prefetch) as stream:
            while True:
                batch = stream.next_batch()
                if not batch: break
                batches.append(batch)
            state = stream.state_dict()
        return batches, state

    def test_full_long_record_coverage_and_incomplete_microbatch(self):
        batches, state = self.run_all(0)
        records = [r for batch in batches for r in batch]
        self.assertEqual([len(b) for b in batches], [192, 67])
        self.assertEqual(len(records), 259)
        self.assertEqual(len({r['identity'] for r in records}), 259)
        self.assertEqual(sum(r['record_first'] for r in records), 258)
        self.assertEqual(sum(r['known_targets'] for r in records), self.plan['stages'][0]['known_targets'])
        long_windows = [r for r in records if ':0:000195.json:' in r['identity']]
        self.assertEqual([len(r['token_ids']) for r in long_windows], [510, 112])
        self.assertEqual([r['record_first'] for r in long_windows], [True, False])
        self.assertEqual(sum(r['known_targets'] for r in long_windows), 622)
        self.assertTrue(all(s['validated_complete'] for s in state['lanes']))
        self.assertEqual(state['committed_records'], 258)

    def test_multiworker_replay_ignores_prefetch_and_preserves_rr_rotation(self):
        expected, endpoint = self.run_all(1, prefetch=3)
        with FinitePipeline(self.plan, 1, 0, prefetch=3) as stream:
            first = stream.next_batch()
            saved = stream.state_dict()
            self.assertEqual(len(stream.worker_pids), 2)
            self.assertEqual(saved['committed_batches'], 1)
            self.assertEqual(saved['next_active_lanes'], [1, 0])
        suffix, resumed = self.run_all(1, resume=json.loads(json.dumps(saved)), prefetch=1)
        self.assertEqual([first] + suffix, expected)
        self.assertEqual(resumed, endpoint)

    def test_resume_after_one_lane_exhausts(self):
        expected, endpoint = self.run_all(1)
        prefix = []
        with FinitePipeline(self.plan, 1, 0) as stream:
            for _ in range(4): prefix.append(stream.next_batch())
            state = stream.state_dict()
            self.assertEqual(len(state['next_active_lanes']), 1)
        suffix, resumed = self.run_all(1, resume=state)
        self.assertEqual(prefix + suffix, expected)
        self.assertEqual(resumed, endpoint)

    def test_resume_completed_pass_has_no_worker_or_extra_records(self):
        _, endpoint = self.run_all(1)
        with FinitePipeline(self.plan, 1, 0, resume_state=endpoint) as stream:
            self.assertEqual(stream.worker_pids, {})
            self.assertEqual(stream.next_batch(), [])
            self.assertEqual(stream.state_dict(), endpoint)

    def test_empty_lane_and_rank_tails_are_explicit(self):
        config = json.loads((self.repo/'run.json').read_text())
        with patch.object(fp, 'SOURCE_FINGERPRINT', config['fingerprint']):
            plan = fp.build_plan(self.census, self.repo, world_size=2)
        all_records = []
        for rank in range(2):
            batches, endpoint = self.run_all(1, plan=plan, rank=rank)
            all_records.extend(r for batch in batches for r in batch)
            self.assertEqual(len(batches), plan['stages'][1]['rank_batches'][rank])
            self.assertTrue(all(s['validated_complete'] for s in endpoint['lanes']))
        self.assertEqual(len(all_records), 258)
        self.assertEqual(len({r['identity'] for r in all_records}), 258)

    def test_changed_shard_fails_before_its_final_batch_is_exposed(self):
        path = self.data/'shard-000000.tar.gz'
        with path.open('ab') as f: f.write(b'changed')
        with FinitePipeline(self.plan, 0, 0) as stream:
            with self.assertRaisesRegex(RuntimeError, 'metadata changed'):
                while stream.next_batch(): pass

    def test_tampered_cursor_and_plan_are_rejected(self):
        with FinitePipeline(self.plan, 1, 0) as stream:
            stream.next_batch(); saved = stream.state_dict()
        bad = copy.deepcopy(saved); bad['lanes'][0]['cursor']['window_offset'] += 1
        with self.assertRaisesRegex(ValueError, 'cursor does not match'):
            FinitePipeline(self.plan, 1, 0, resume_state=bad)
        bad = copy.deepcopy(saved); bad['committed_windows'] += 1
        with self.assertRaisesRegex(ValueError, 'Rank count does not match'):
            FinitePipeline(self.plan, 1, 0, resume_state=bad)
        plan = copy.deepcopy(self.plan); plan['seed'] += 1
        with self.assertRaisesRegex(ValueError, 'identity mismatch'):
            FinitePipeline(plan, 1, 0)

    def test_source_policy_drift_rejected_before_spawning(self):
        (self.repo/'common.py').write_text('# changed\n')
        with self.assertRaisesRegex(ValueError, 'Policy files differ'):
            FinitePipeline(self.plan, 0, 0)


if __name__ == '__main__':
    unittest.main()
