from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import random
import tempfile
import unittest
from unittest import mock
import epoch_evaluation as e
HERE=Path(__file__).resolve().parent
TORCH=importlib.util.find_spec('torch') is not None

def policy():
    spec=importlib.util.spec_from_file_location('_ct2_eval_test_tokens',HERE/'policy_fixture/source/phase1_tokens.py')
    value=importlib.util.module_from_spec(spec)
    import sys
    sys.modules[spec.name]=value;spec.loader.exec_module(value);return value

def vocabulary():
    return json.loads((HERE/'policy_fixture/source/CodonTransformerTokenizer.json').read_text())['model']['vocab']

def record(name='example',protein='MA',dna='ATGGCTTAA',cohort='current_panel'):
    return dict(eval_id=name,cohort=cohort,species='host-a',species_id=0,protein_sequence=protein,native_dna=dna)

class PureEvaluationTests(unittest.TestCase):
    def test_window_coverage(self):
        for count in (1,2045,2046,2047,28439):
            ranges=e.window_ranges(count)
            self.assertEqual([p for a,b in ranges for p in range(a,b)],list(range(count)))
            self.assertTrue(all(b-a<=2046 for a,b in ranges))
        self.assertEqual(e.window_ranges(2046),[(0,2046)])
        self.assertEqual(e.window_ranges(2047),[(0,2046),(2046,2047)])
    def test_wrong_host(self):
        for own in range(15):
            value=e.wrong_species_id('fixed-record',own,15)
            self.assertNotEqual(value,own);self.assertIn(value,range(15))
            self.assertEqual(value,e.wrong_species_id('fixed-record',own,15))
        with self.assertRaises(ValueError):e.wrong_species_id('x',1,1)
    def test_translation_and_stop_protocol(self):
        self.assertTrue(e.validate_prediction('ATGGCTTAA','MA'))
        self.assertTrue(e.validate_prediction('ATGGCT','MA',False))
        for dna,stop in [('ATGGCT',True),('GTGGCTTAA',True),('ATGNNNTAA',True),('ATGGCTTAA',False)]:
            with self.assertRaises(ValueError):e.validate_prediction(dna,'MA',stop)
    def test_current_unknown_positions(self):
        row=record(dna='GTGNNNTAA')
        aa,ids,targets=e.prepared_content(row,vocabulary(),policy())
        self.assertEqual(aa,'MA');self.assertEqual(len(ids),3);self.assertEqual(targets,{2})
        row['native_known_target_positions']=[0,1,2]
        with self.assertRaises(ValueError):e.prepared_content(row,vocabulary(),policy())
    def test_legacy_qc_rows_retained(self):
        row=record(dna='GTGNNN',cohort='legacy_common_valid')
        aa,ids,targets=e.prepared_content(row,vocabulary(),policy())
        self.assertEqual(aa,'MA');self.assertEqual(len(ids),2);self.assertEqual(targets,set())
        row=record(protein='M'*2046,dna='ATG'*2046,cohort='legacy_common_valid')
        _,ids,targets=e.prepared_content(row,vocabulary(),policy())
        self.assertEqual(len(ids),2046);self.assertEqual(len(targets),2046)
    def test_qualification_contains_longest(self):
        rows=[record(str(i),'M'*(i+1),'ATG'*(i+1)+'TAA') for i in range(20)]
        result=e.qualification_subset(rows)
        self.assertEqual(len(result),12);self.assertEqual(result[-1]['eval_id'],'19')
        rows[0]['protein_sequence']='M'*50
        result=e.qualification_subset(rows)
        self.assertEqual(len({r['eval_id'] for r in result}),12);self.assertIn('0',[r['eval_id'] for r in result])
        with self.assertRaises(ValueError):e.qualification_subset(rows[:11])
    def test_ce_denominators(self):
        total=e.empty_ce()
        e.add_ce(total,dict(full_ce_sum=6.,full_targets=3,full_correct=2,partial_ce_sum=1.,partial_targets=1,partial_correct=1))
        e.add_ce(total,dict(full_ce_sum=2.,full_targets=1,full_correct=0,partial_ce_sum=0.,partial_targets=0,partial_correct=0))
        value=e.finish_ce(total)
        self.assertEqual(value['full_ce'],2.);self.assertEqual(value['full_accuracy'],.5)
        self.assertIsNone(e.finish_ce(e.empty_ce())['full_ce'])
    def test_input_integrity(self):
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp);cohorts=[]
            for name in ('current_panel','legacy_common_valid'):
                path=directory/(name+'.jsonl')
                rows=[record(name+str(i),'M'*(i+1),'ATG'*(i+1)+'TAA',name) for i in range(14)]
                path.write_text(''.join(json.dumps(row)+'\n' for row in rows))
                cohorts.append(dict(name=name,path=path.name,sha256=e.sha(path),records=14,species_count=1))
            manifest=dict(cohorts=cohorts)
            (directory/'evaluation_manifest.json').write_text(json.dumps(manifest))
            with mock.patch('prepare_evaluation.validate_prepared_inputs',return_value=manifest):
                _,rows,requested,universe=e.load_inputs(directory,True)
            self.assertEqual(len(rows),24);self.assertEqual(requested,{'current_panel':12,'legacy_common_valid':12})
            self.assertEqual(universe['legacy_common_valid'],['host-a'])
            (directory/'current_panel.jsonl').write_text('{}\n')
            with mock.patch('prepare_evaluation.validate_prepared_inputs',return_value=manifest):
                with self.assertRaises(ValueError):e.load_inputs(directory,True)

    def test_request_namespace_reuse_requires_identical_inputs(self):
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp)/'evaluation'
            request={'checkpoint_sha256':'abc','input_identity':'fixed'}
            identity=e.prepare_output(directory,request)
            self.assertEqual(identity,e.prepare_output(directory,request))
            with self.assertRaises(ValueError):e.prepare_output(directory,dict(request,checkpoint_sha256='changed'))

    def test_committed_rank_reuse_is_hash_and_count_bound(self):
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp)
            prediction=directory/'predictions_rank_00.jsonl';prediction.write_text('{}\n')
            metric=directory/'metrics_rank_00.jsonl';metric.write_text('{}\n')
            counts={'current_panel':1,'legacy_common_valid':1}
            report={'rank':0,'request_identity':'fixed','processed_by_cohort':counts,'prediction_rows':10,'metric_rows':30,
                    'predictions':{'path':prediction.name,'sha256':e.sha(prediction)},'metrics':{'path':metric.name,'sha256':e.sha(metric)},
                    'ce':{cohort:{condition:e.empty_ce() for condition in e.CONDITIONS} for cohort in counts},
                    'host_sensitivity':{cohort:{condition:dict(e.empty_sensitivity(),records=1) for condition in e.CONDITIONS} for cohort in counts}}
            e.atomic_json(directory/'rank_00.json',report)
            self.assertEqual(e.validated_rank_report(directory,0,'fixed',counts),report)
            with self.assertRaises(ValueError):e.validated_rank_report(directory,0,'other',counts)
            prediction.write_text('changed')
            with self.assertRaises(ValueError):e.validated_rank_report(directory,0,'fixed',counts)

    def test_partial_rank_outputs_preserved_before_retry(self):
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp)
            partial=directory/'predictions_rank_00.jsonl';partial.write_text('partial-data')
            e.preserve_partial_rank(directory,0)
            self.assertFalse(partial.exists())
            saved=list((directory/'interrupted').rglob('predictions_rank_00.jsonl'))
            self.assertEqual(len(saved),1);self.assertEqual(saved[0].read_text(),'partial-data')
            (directory/'rank_00.json').write_text('{}')
            with self.assertRaises(ValueError):e.preserve_partial_rank(directory,0)

    def test_prepared_wrong_host_is_used_and_verified(self):
        row=dict(record(),wrong_species='host-b',wrong_species_id=1)
        self.assertEqual(e.conditioning(row,{'host-a':0,'host-b':1})['wrong'],1)
        row['wrong_species_id']=0
        with self.assertRaises(ValueError):e.conditioning(row,{'host-a':0,'host-b':1})

    def test_rank_wait_does_not_enter_collective(self):
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp)
            for rank in range(8):e.atomic_json(directory/f'rank_{rank:02d}.json',{'rank':rank,'request_identity':'fixed'})
            e.wait_for_rank_reports(directory,'fixed',timeout_seconds=0)
            with self.assertRaises(ValueError):e.wait_for_rank_reports(directory,'changed',timeout_seconds=0)
            (directory/'rank_07.json').unlink()
            with self.assertRaises(TimeoutError):e.wait_for_rank_reports(directory,'fixed',timeout_seconds=0)

    def test_sensitivity_retains_sequence_and_logit_denominators(self):
        total=e.empty_sensitivity()
        for difference,absolute,values in [(.25,8.,4),(.75,2.,6)]:
            e.add_sensitivity(total,{'codon_disagreement_vs_own':difference,
                                    'full_logit_absolute_difference_sum_vs_own':absolute,
                                    'full_logit_values_compared_vs_own':values})
        value=e.finish_sensitivity(total)
        self.assertEqual(value['mean_sequence_codon_disagreement_vs_own'],.5)
        self.assertEqual(value['mean_abs_full_logits_vs_own'],1.)

@unittest.skipUnless(TORCH,'Torch is required; the remote CPU gate permits no skipped tests')
class TorchEvaluationTests(unittest.TestCase):
    @staticmethod
    def objects():
        import torch
        class Tokenizer:
            def __init__(self):
                self.vocab=vocabulary()
                for field,word in [('cls_token_id','[CLS]'),('sep_token_id','[SEP]'),('pad_token_id','[PAD]'),('mask_token_id','[MASK]')]:setattr(self,field,self.vocab[word])
            def get_vocab(self):return self.vocab
        class Model(torch.nn.Module):
            def __init__(self):super().__init__();self.anchor=torch.nn.Parameter(torch.zeros(1))
            def forward(self,ids,attention,species):
                values=torch.arange(90,device=ids.device).float()[None,None,:]/100
                return (values+species[:,None,None].float()*values*1e-5+self.anchor).expand(len(ids),ids.shape[1],90)
        return Model(),Tokenizer()
    def test_matched_target_conditions(self):
        model,tok=self.objects();model.eval()
        rows=e.evaluate_record(model,tok,record(),{'host-a':0,'host-b':1},policy(),maximum=8)
        self.assertEqual([r['requested_condition'] for r in rows],list(e.CONDITIONS))
        self.assertEqual([r['ce']['full_targets'] for r in rows],[3,3,3])
        self.assertEqual(len({r['ce']['partial_targets'] for r in rows}),1)
        self.assertGreater(rows[1]['full_logit_absolute_difference_sum_vs_own'],0)
        self.assertEqual(rows[0]['codon_disagreement_vs_own'],0)
        for r in rows:self.assertTrue(e.validate_prediction(r['predicted_dna'],'MA'))
        self.assertEqual(rows,e.evaluate_record(model,tok,record(),{'host-a':0,'host-b':1},policy(),maximum=8))
    def test_legacy_2046_no_stop_single_window(self):
        model,tok=self.objects();model.eval()
        row=record(protein='M'*2046,dna='ATG'*2046,cohort='legacy_common_valid')
        rows=e.evaluate_record(model,tok,row,{'host-a':0,'host-b':1},policy())
        self.assertTrue(all(r['window_count']==1 and len(r['predicted_dna'])==6138 and r['terminal_stop_included'] is False for r in rows))
        self.assertTrue(all(r['ce']['full_targets']==2046 for r in rows))
    def test_legacy_without_any_known_native_targets(self):
        model,tok=self.objects();model.eval()
        rows=e.evaluate_record(model,tok,record(dna='GTGNNN',cohort='legacy_common_valid'),{'host-a':0,'host-b':1},policy(),maximum=8)
        self.assertTrue(all(r['ce']['full_ce'] is None and r['ce']['partial_targets']==0 for r in rows))
        self.assertTrue(all(e.validate_prediction(r['predicted_dna'],'MA',False) for r in rows))
    def test_rng_and_mode_restore_on_error(self):
        import numpy as np
        import torch
        model,_=self.objects();model.train()
        before=(random.getstate(),np.random.get_state(),torch.get_rng_state().clone())
        with self.assertRaises(RuntimeError):
            with e.preserve_rng_and_mode(model):
                self.assertFalse(model.training)
                random.random();np.random.rand();torch.rand(5)
                raise RuntimeError('probe failure')
        self.assertTrue(model.training);self.assertEqual(before[0],random.getstate())
        self.assertTrue(np.array_equal(before[1][1],np.random.get_state()[1]));self.assertTrue(torch.equal(before[2],torch.get_rng_state()))

if __name__=='__main__':unittest.main()
