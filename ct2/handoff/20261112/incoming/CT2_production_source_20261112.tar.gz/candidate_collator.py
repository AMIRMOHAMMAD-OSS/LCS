"""Protein-preserving masking for finite CT2 windows and zero-loss tail padding."""
from __future__ import annotations
import hashlib
import itertools

CODE = dict(zip((''.join(x) for x in itertools.product('TCAG', repeat=3)),
                'FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG'))


def stable_seed(value):
    return int.from_bytes(hashlib.sha256(value.encode()).digest()[:8], 'big') % (2**63 - 1)


def codon_token(codon):
    aa = CODE[codon]
    return '__' + codon.lower() if aa == '*' else aa.lower() + '_' + codon.lower()


def validate_windows(rows, length, vocab_size=90):
    if type(length) is not int or length < 3:
        raise ValueError('Invalid context length')
    for row in rows:
        tokens = row.get('token_ids')
        if not isinstance(tokens, list) or not 0 < len(tokens) <= length - 2:
            raise ValueError('Window would require truncation or has no content')
        if any(type(x) is not int or not 0 <= x < vocab_size for x in tokens):
            raise ValueError('Invalid token ID in window')
        if type(row.get('species_id')) is not int or not 0 <= row['species_id'] < 26678:
            raise ValueError('Invalid real-species ID in window')
        if not isinstance(row.get('identity'), str) or not row['identity']:
            raise ValueError('Window lacks a stable identity')


class CandidateCollator:
    def __init__(self, tokenizer, seed=123, rank=0, stage=0, unknown_probability=.02):
        import torch
        if not 0 <= unknown_probability <= 1:
            raise ValueError('Invalid species dropout probability')
        self.tokenizer, self.seed, self.rank, self.stage = tokenizer, seed, rank, stage
        self.unknown_probability = float(unknown_probability)
        self.vocab = tokenizer.get_vocab()
        self.mask = torch.arange(len(self.vocab))
        self.eligible = torch.zeros(len(self.vocab), dtype=torch.bool)
        self.synonyms = {}
        for codon, aa in CODE.items():
            index = self.vocab[codon_token(codon)]
            self.eligible[index] = True
            self.mask[index] = self.vocab['__unk' if aa == '*' else aa.lower() + '_unk']
            self.synonyms[index] = [self.vocab[codon_token(c)] for c, a in CODE.items() if a == aa]

    def __call__(self, windows, length, full_probability, update, microbatch):
        import torch
        if not 0 <= full_probability <= 1:
            raise ValueError('Invalid full-mask probability')
        validate_windows(windows, length, len(self.vocab))
        real = bool(windows)
        # An empty rank still participates in DDP. Its forward/backward traverses
        # every model parameter but contributes no label, token or record count.
        if not real:
            windows = [{'token_ids': [self.vocab['m_atg']], 'species_id': 0,
                        'identity': 'zero-loss-padding', 'record_first': False}]
        rows = [[self.tokenizer.cls_token_id, *r['token_ids'], self.tokenizer.sep_token_id] for r in windows]
        # Keep the tested tensor-width policy explicit. Dynamic batch padding
        # would change arithmetic/kernel shapes and requires a new replay check.
        width = length
        original = torch.full((len(rows), width), self.tokenizer.pad_token_id, dtype=torch.long)
        attention = torch.zeros_like(original)
        for i, row in enumerate(rows):
            original[i, :len(row)] = torch.tensor(row)
            attention[i, :len(row)] = 1
        eligible = self.eligible[original] & attention.bool()
        if not real:
            eligible.zero_()
        elif not eligible.any(dim=1).all():
            raise ValueError('An accepted training window has no known codon target')
        stream = f'{self.seed}:{self.stage}:{self.rank}:{update}:{microbatch}'
        gen = torch.Generator().manual_seed(stable_seed('mlm:' + stream))
        selected = (torch.rand(original.shape, generator=gen) < .15) & eligible
        if real:
            for i in range(len(rows)):
                if not selected[i].any():
                    ids = eligible[i].nonzero().flatten()
                    selected[i, ids[torch.randint(len(ids), (1,), generator=gen)]] = True
        replaced = (torch.rand(original.shape, generator=gen) < .8) & selected
        generic = (torch.rand(original.shape, generator=gen) < .5) & selected & ~replaced
        synonymous = (torch.rand(original.shape, generator=gen) < .5) & selected & ~replaced & ~generic
        inputs = original.clone()
        inputs[replaced] = self.mask[original[replaced]]
        inputs[generic] = self.tokenizer.mask_token_id
        for b, p in synonymous.nonzero().tolist():
            choices = self.synonyms[int(original[b, p])]
            inputs[b, p] = choices[int(torch.randint(len(choices), (1,), generator=gen))]
        gen = torch.Generator().manual_seed(stable_seed('full:' + stream))
        full = (torch.rand((len(rows),), generator=gen) < full_probability) & real
        full_positions = full[:, None] & eligible
        inputs[full_positions] = self.mask[original[full_positions]]
        selected |= full_positions
        truth = torch.tensor([r['species_id'] for r in windows], dtype=torch.long)
        gen = torch.Generator().manual_seed(stable_seed('species:' + stream))
        unknown = (torch.rand(truth.shape, generator=gen) < self.unknown_probability) & real
        return {'input_ids': inputs, 'attention_mask': attention,
                'labels': torch.where(selected, original, -100),
                'species_id': torch.where(unknown, 26678, truth), 'full': full, 'unknown': unknown,
                'real': torch.full((len(rows),), real, dtype=torch.bool),
                'record_first': torch.tensor([bool(r.get('record_first')) and real for r in windows])}
