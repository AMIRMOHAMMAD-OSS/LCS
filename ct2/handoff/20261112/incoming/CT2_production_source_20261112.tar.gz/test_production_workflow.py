import copy
import json
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import production_workflow as w


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.run = Path(self.temp.name)

    def write(self, name, value):
        path = self.run / name
        w.atomic(path, value)
        return path

    def test_reviewed_evidence_is_exact_and_plan_has_expected_budget(self):
        plan = w.verify_reviewed_evidence()
        self.assertEqual(sum(s['steps'] for s in plan['stages']), 620972)

    def test_modified_evidence_digest_blocks(self):
        with patch.object(w, 'EVIDENCE_DIGEST', '0' * 64):
            with self.assertRaisesRegex(RuntimeError, 'bundle changed'): w.verify_reviewed_evidence()

    def test_clip_choice_is_explicit_and_finite(self):
        self.assertIsNone(w.clip_value('none'))
        self.assertEqual(w.clip_value('1'), 1.)
        for value in ('nan', 'inf', '-1', '0', '2'):
            with self.assertRaises(ValueError): w.clip_value(value)

    def _tests_report(self):
        return dict(schema='ct2-production-package-tests-v1', status='PASS', code_hashes={},
                    discovered=3, tests_run=3, skipped=0, errors=0, failures=0,
                    expected_failures=0, unexpected_successes=0)

    def test_remote_package_skips_fail_gate(self):
        report = self._tests_report()
        with patch.object(w, 'code_hashes', return_value={}):
            w.require_package_tests(report)
            for key in ('skipped', 'errors', 'failures', 'expected_failures', 'unexpected_successes'):
                bad = dict(report, **{key: 1})
                with self.assertRaises(RuntimeError): w.require_package_tests(bad)

    def test_missing_or_empty_test_suite_fails_gate(self):
        with patch.object(w, 'code_hashes', return_value={}):
            for fields in ({'tests_run': 2}, {'discovered': 0, 'tests_run': 0}, {'code_hashes': {'x': 'changed'}}):
                with self.assertRaises(RuntimeError): w.require_package_tests(dict(self._tests_report(), **fields))

    def test_disk_requirement_is_filesystem_only(self):
        with patch.object(w.shutil, 'disk_usage', return_value=SimpleNamespace(free=w.MINIMUM_FREE_BYTES)):
            w.require_disk(self.run, 'test')
        self.assertFalse(w.read(self.run / 'test_disk.json')['quota_checked'])
        with patch.object(w.shutil, 'disk_usage', return_value=SimpleNamespace(free=w.MINIMUM_FREE_BYTES - 1)):
            with self.assertRaises(RuntimeError): w.require_disk(self.run, 'test')

    def ablation(self, stage=0, token='0.5', count=128, status='HEALTHY_FINISHED'):
        probe = {'schema': 'ct2-quick-host-probe-v1', 'status': 'PASS',
                 'conditions': {name: {} for name in ('own', 'unknown', 'wrong')}}
        return dict(schema='ct2-clipping-ablation-v1', status=status, plan_identity=w.PLAN_ID,
            stage=stage, clip_value=w.clip_value(token), requested_updates=128, completed_updates=count,
            training_ready=False, production_resume_allowed=False,
            source={'checkpoint_sha256': w.read(w.EVIDENCE / 'finite_plan.json')['source']['checkpoint_sha256']},
            host_probe_before=probe, host_probe_after=probe,
            data_protocol_identity='stage_' + str(stage),
            updates=[{'global_batch_sha256': 'batch_' + str(i)} for i in range(count)])

    def test_healthy_ablation_requires_full_updates_and_host_controls(self):
        report = self.ablation(); path = self.write('ablation.json', report)
        w.require_ablation(path, 0, '0.5')
        for field, value in [('completed_updates', 127), ('plan_identity', 'other'), ('clip_value', 1.),
                             ('host_probe_after', {'status': 'PASS'}), ('status', 'FAILED')]:
            self.write('ablation.json', dict(report, **{field: value}))
            with self.assertRaises(RuntimeError): w.require_ablation(path, 0, '0.5')

    def test_unhealthy_ablation_is_reportable_without_being_healthy(self):
        report = self.ablation(count=4, status='UNHEALTHY')
        report.pop('host_probe_after')
        result = w.require_ablation(self.write('ablation.json', report), 0, '0.5')
        self.assertEqual(result['status'], 'UNHEALTHY')

    def test_ablation_batch_or_protocol_mismatch_fails(self):
        reports = {(stage, token): self.ablation(stage, token) for stage in (0, 3) for token in w.CAPS}
        w.require_matched_ablation(reports)
        bad = copy.deepcopy(reports); bad[(0, 'none')]['updates'][30]['global_batch_sha256'] = 'wrong'
        with self.assertRaisesRegex(RuntimeError, 'different batches'): w.require_matched_ablation(bad)
        bad = copy.deepcopy(reports); bad[(3, '1.0')]['data_protocol_identity'] = 'wrong'
        with self.assertRaisesRegex(RuntimeError, 'protocols differ'): w.require_matched_ablation(bad)

    def transition(self):
        return {'schema': 'ct2-transition-comparison-v1', 'status': 'PASS', 'plan_identity': w.PLAN_ID,
            'release_id': 'release', 'clip_value': .5, 'pairs': {'3': {'status': 'PASS'}, '8': {'status': 'PASS'}},
            'cross_update_identity': {'status': 'PASS'},
            'source_checkpoint_sha256': w.read(w.EVIDENCE / 'finite_plan.json')['source']['checkpoint_sha256']}

    def test_transition_requires_both_pairs_and_cross_update_binding(self):
        good = self.transition(); path = self.write('transition.json', good)
        w.require_transition(path, 'release', '0.5')
        for changes in ({'pairs': {'3': {'status': 'PASS'}}}, {'release_id': 'other'}, {'clip_value': None},
                        {'cross_update_identity': {'status': 'FAIL'}}):
            self.write('transition.json', dict(good, **changes))
            with self.assertRaises(RuntimeError): w.require_transition(path, 'release', '0.5')

    def evaluation(self, qualification=False):
        directory = self.run / 'eval'; directory.mkdir()
        summary = self.write('eval/summary.json', {'result': 1})
        species = directory / 'by_species.jsonl'; species.write_text('{}\n')
        inputs_path = self.write('inputs/evaluation_manifest.json', {'identity': 'inputs'})
        ranks = []
        for rank in range(8):
            row = {'rank': rank}
            for kind in ('predictions', 'metrics'):
                path = directory / f'{kind}_{rank}.jsonl'; path.write_text('{}\n')
                row[kind] = {'path': path.name, 'sha256': w.sha(path)}
            ranks.append(row)
        report = {'schema': 'ct2-epoch-evaluation-v1',
            'status': 'QUALIFICATION_EVALUATION_COMPLETE' if qualification else 'EVALUATION_COMPLETE',
            'qualification': qualification, 'plan_identity': w.PLAN_ID, 'release_id': 'release',
            'checkpoint': {'sha256': 'model'}, 'input_identity': 'inputs', 'requested_records': 5, 'processed_records': 5,
            'requested_by_cohort': {'current': 2, 'legacy': 3}, 'processed_by_cohort': {'current': 2, 'legacy': 3},
            'conditions': ['own', 'unknown', 'wrong', 'native', 'hfc'], 'required_metrics': ['m'], 'completed_metrics': ['m'],
            'rank_reports': ranks, 'outputfiles': {'summary.json': w.sha(summary), 'by_species.jsonl': w.sha(species)},
            'input_manifest_sha256': w.sha(inputs_path), 'reference_sha256': 'ref'}
        self.write('eval/evaluation_manifest.json', report)
        inputs = {'identity_sha256': 'inputs', 'cohorts': [{'name': 'current', 'records': 2}, {'name': 'legacy', 'records': 3}],
                  'frozen_reference': {'path': str(inputs_path.parent / 'frozen_reference.json'), 'sha256': 'ref'}}
        return directory, inputs, report

    def test_evaluation_binds_complete_cohorts_metrics_and_part_hashes(self):
        directory, inputs, report = self.evaluation()
        module = SimpleNamespace(REQUIRED_METRICS=['m'])
        with patch.dict(sys_modules(), {'epoch_evaluation': module}):
            w.require_evaluation(directory, inputs, 'model', 'release', False)
            for changes in ({'completed_metrics': []}, {'processed_records': 4}, {'qualification': True},
                            {'checkpoint': {'sha256': 'other'}}, {'rank_reports': report['rank_reports'][:7]}):
                self.write('eval/evaluation_manifest.json', dict(report, **changes))
                with self.assertRaises(RuntimeError): w.require_evaluation(directory, inputs, 'model', 'release', False)
            self.write('eval/evaluation_manifest.json', report)
            (directory / 'metrics_0.jsonl').write_text('changed')
            with self.assertRaisesRegex(RuntimeError, 'rank data changed'): w.require_evaluation(directory, inputs, 'model', 'release', False)

    def test_full_evaluation_cannot_report_a_small_subset_as_complete(self):
        directory, inputs, report = self.evaluation()
        inputs['cohorts'][1]['records'] = 25000
        with patch.dict(sys_modules(), {'epoch_evaluation': SimpleNamespace(REQUIRED_METRICS=['m'])}):
            with self.assertRaisesRegex(RuntimeError, 'both complete fixed cohorts'):
                w.require_evaluation(directory, inputs, 'model', 'release', False)

    def receipt(self, stage=0, step=4, complete=False):
        path = self.run / f'train/checkpoints/update_{step}.ckpt'; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(b'model')
        r = {'path': str(path), 'sha256': w.sha(path), 'mode': 'production', 'plan_identity': w.PLAN_ID,
             'release_id': 'release', 'clip_value': .5, 'stage': stage, 'stage_step': step,
             'completed_updates': sum(w.STAGE_STEPS[:stage]) + step, 'stage_complete': complete,
             'full_dataset_verified': complete}
        self.write('train/last.json', r); return r

    def test_checkpoint_boundary_requires_complete_data_and_same_clip(self):
        release = {'release_id': 'release', 'clip_value': .5}
        row = self.receipt(); w.checkpoint_receipt(self.run, release, check_bytes=True)
        row['clip_value'] = None; self.write('train/last.json', row)
        with self.assertRaises(RuntimeError): w.checkpoint_receipt(self.run, release)
        row = self.receipt(step=w.STAGE_STEPS[0], complete=True)
        row['full_dataset_verified'] = False; self.write('train/last.json', row)
        with self.assertRaisesRegex(RuntimeError, 'coverage verification'): w.checkpoint_receipt(self.run, release)

    def test_next_action_enforces_baseline_then_epoch_evaluation(self):
        release = {'release_id': 'release', 'clip_value': .5}
        self.write('finite_plan.json', {'source': {'checkpoint_sha256': 'source'}})
        with patch.object(w, 'require_release', return_value=({}, release)), patch.object(w, 'require_evaluation') as evaluate:
            self.assertEqual(w.next_action(self.run), {'kind': 'baseline'})
            self.write('evaluations/baseline/evaluation_manifest.json', {})
            self.assertEqual(w.next_action(self.run), {'kind': 'train', 'stage': 0, 'resume': None})
            row = self.receipt(step=w.STAGE_STEPS[0], complete=True)
            self.assertEqual(w.next_action(self.run)['kind'], 'evaluate')
            self.write('evaluations/epoch_1/evaluation_manifest.json', {})
            self.assertEqual(w.next_action(self.run), {'kind': 'train', 'stage': 1, 'resume': row['path']})
            self.assertGreaterEqual(evaluate.call_count, 4)

    def test_final_completion_requires_all_four_retained_epoch_reports(self):
        release = {'release_id': 'release', 'clip_value': .5}
        self.write('finite_plan.json', {'source': {'checkpoint_sha256': 'source'}})
        self.write('evaluations/baseline/evaluation_manifest.json', {})
        self.write('evaluations/epoch_4/evaluation_manifest.json', {})
        self.receipt(stage=3, step=w.STAGE_STEPS[3], complete=True)
        with patch.object(w, 'require_release', return_value=({}, release)), patch.object(w, 'require_evaluation'), \
             patch.object(w, 'require_epoch_history', side_effect=RuntimeError('missing epoch 1')) as history:
            with self.assertRaisesRegex(RuntimeError, 'missing epoch 1'): w.next_action(self.run)
            history.assert_called_once()

    def test_unhealthy_or_unqualified_clip_cannot_be_selected(self):
        report = {'candidates': {token: {'selectable': False} for token in w.CAPS}}
        with patch.object(w, 'guard_submissions'), patch.object(w, 'require_qualified', return_value=({}, report)):
            with self.assertRaisesRegex(RuntimeError, 'did not pass'): w.prepare_release(self.run, 'none')
        self.assertFalse((self.run / 'release.json').exists())

    def test_release_selection_does_not_submit_a_job(self):
        report = {'candidates': {token: {'selectable': token == '1.0'} for token in w.CAPS}}
        self.write('qualification_status.json', {'status': 'QUALIFICATION_COMPLETE'})
        with patch.object(w, 'guard_submissions'), patch.object(w, 'require_qualified', return_value=({'identity_sha256': 'i'}, report)), \
             patch.object(w, 'code_hashes', return_value={}), patch.object(w.subprocess, 'run') as sub:
            w.prepare_release(self.run, '1.0')
            sub.assert_not_called()
        self.assertEqual(w.read(self.run / 'release.json')['clip_value'], 1.0)

    def test_queue_and_ambiguous_submissions_are_blocked(self):
        path = self.write('jobs/job_x/submission.json', {'status': 'SUBMITTED', 'job_id': '10'})
        with patch.object(w.subprocess, 'run', return_value=SimpleNamespace(stdout='10\n')):
            with self.assertRaisesRegex(RuntimeError, 'queued/running'): w.guard_submissions(self.run)
        w.atomic(path, {'status': 'AMBIGUOUS'})
        with patch.object(w.subprocess, 'run', return_value=SimpleNamespace(stdout='')):
            with self.assertRaisesRegex(RuntimeError, 'Unresolved'): w.guard_submissions(self.run)

    def test_job_resources_are_bounded_and_scripts_parse(self):
        for kind in ('prepare', 'qualification', 'baseline', 'train', 'evaluate'):
            args = w.sbatch_args(self.run, kind)
            self.assertIn('--time=' + ('02:00:00' if kind in ('prepare', 'qualification') else '20:00:00'), args)
            if kind != 'prepare':
                self.assertIn('--nodes=2', args); self.assertIn('--ntasks-per-node=4', args)
            subprocess.run(['bash', '-n'], input=w.script_text(self.run, self.run / 'task.json', kind == 'prepare'), text=True, check=True)

    def test_export_excludes_raw_predictions_weights_and_arbitrary_json(self):
        self.write('request.json', {})
        self.write('private_gene_sequences.json', {'dna': 'AAA'})
        self.write('evaluations/baseline/evaluation_manifest.json', {})
        self.write('evaluations/baseline/predictions_rank_00.jsonl', {'dna': 'AAA'})
        (self.run / 'model.ckpt').write_bytes(b'weights')
        archive = w.export_results(self.run)
        import zipfile
        with zipfile.ZipFile(archive) as z:
            self.assertEqual(set(z.namelist()), {'request.json', 'evaluations/baseline/evaluation_manifest.json'})

    def test_symlinked_export_path_is_rejected(self):
        outside = self.run / 'outside.json'; outside.write_text('{}')
        (self.run / 'request.json').symlink_to(outside)
        with self.assertRaisesRegex(ValueError, 'Symlinked'): w.export_results(self.run)

    def test_phase_change_marks_previous_archive_stale(self):
        self.write('prepare_status.json', {'status': 'RUNNING'})
        w.export_results(self.run)
        self.assertTrue(w.current_export(self.run))
        self.write('prepare_status.json', {'status': 'PREPARATION_COMPLETE'})
        self.assertFalse(w.current_export(self.run))

    def test_new_release_or_checkpoint_invalidates_export_even_without_status_change(self):
        self.write('qualification_status.json', {'status': 'QUALIFICATION_COMPLETE'})
        w.export_results(self.run)
        self.assertTrue(w.current_export(self.run))
        self.write('release.json', {'clip_value': None})
        self.assertFalse(w.current_export(self.run))
        w.export_results(self.run)
        self.write('train/last.json', {'completed_updates': 2000})
        self.assertFalse(w.current_export(self.run))

    def test_release_schedule_matches_the_actual_trainer_policy(self):
        from production_trainer import LR_POLICY
        self.assertEqual(w.SCHEDULE, LR_POLICY)

    def test_export_only_failure_can_recover_but_computation_failure_cannot(self):
        self.write('prepare_status.json', {'status': 'PREPARATION_COMPLETE', 'exit_code': 1, 'export_error': 'disk'})
        self.write('last_job_status.json', {'status': 'FAILED', 'exit_code': 1, 'error': 'model', 'export_error': 'disk'})
        w.refresh_export(self.run)
        self.assertEqual(w.read(self.run / 'prepare_status.json')['exit_code'], 0)
        self.assertEqual(w.read(self.run / 'last_job_status.json')['exit_code'], 1)
        self.assertTrue(w.current_export(self.run))


def sys_modules():
    import sys
    return sys.modules


if __name__ == '__main__': unittest.main()
