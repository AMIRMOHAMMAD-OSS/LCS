#!/usr/bin/env python3
"""Finite CT2 corpus census. Reads training shards; never loads a checkpoint or GPU."""
from __future__ import annotations

import argparse
from bisect import bisect_left
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import sys
import tarfile
import tempfile

BASE = Path('/lustre/fswork/projects/rech/nef/unh87ms')
DEFAULT_REPO = BASE / 'CodonTransformerV2/ct2_production_20260930_v4'
DEFAULT_DATA = BASE / 'codon_project/data/CT2_data/training_shards_webdataset'
LENGTHS = (512, 1024, 1536, 2048)
EXPECTED_POLICY = {
    'data_stream.py': '5941a054ff1949f1f446b8a5a459e6078c1e836bc64e2d9c77e7dc92b738e445',
    'common.py': '4b6aac91118c1458296faee9c981bd90dcbd8098463a811d128cb973183bd635',
    'source/phase1_tokens.py': '64f81ce5236f73fa2018aabb490a5e23a1820a6e7e613f0931de73c94a15a086',
    'source/CodonTransformerTokenizer.json': 'b3b6b599da88789460e4bf37fb0b168bbac83f5b56413a15130ed95a2a5478c8',
    'source/species_to_id.json': 'dfd742bf20bf4aeeeeee9802dbffb7d88a7809eb365ea9f8c3b3866a3e9b1290',
}
MAX_JSON_BYTES = 16 * 1024 * 1024
FORMAT = 'ct2-census-v1'
SCANNER_VERSION = 1


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as f:
            json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        Path(tmp).unlink(missing_ok=True)


def snapshot(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError('Expected a regular, non-symlink file: ' + str(path))
    stat = path.stat()
    return {'name': path.name, 'bytes': stat.st_size, 'mtime_ns': stat.st_mtime_ns}


def _module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module  # dataclasses requires a registered module.
    spec.loader.exec_module(module)
    return module


class Policy:
    def __init__(self, repo):
        self.repo = Path(repo).resolve()
        actual = {relative: file_sha(self.repo / relative) for relative in EXPECTED_POLICY}
        if actual != EXPECTED_POLICY:
            changed = [name for name in EXPECTED_POLICY if actual[name] != EXPECTED_POLICY[name]]
            raise ValueError('Policy files differ from the reviewed export: ' + ', '.join(changed))
        self.token = _module(self.repo / 'source/phase1_tokens.py', '_ct2_census_tokens')
        self.common = _module(self.repo / 'common.py', '_ct2_census_common')
        self.vocab = json.loads((self.repo / 'source/CodonTransformerTokenizer.json').read_text())['model']['vocab']
        self.mapping = json.loads((self.repo / 'source/species_to_id.json').read_text())
        self.n_real = len(self.mapping)
        self.token.validate_vocabulary(self.vocab)
        self.common.validate_mapping(self.mapping, self.n_real)


def inventory(data, expected_shards):
    data = Path(data).resolve()
    if expected_shards < 1:
        raise ValueError('expected_shards must be positive')
    names = sorted(p.name for p in data.glob('shard-*.tar.gz'))
    expected = [f'shard-{i:06d}.tar.gz' for i in range(expected_shards)]
    if names != expected:
        missing, extra = sorted(set(expected) - set(names)), sorted(set(names) - set(expected))
        raise ValueError(f'Shard inventory mismatch: expected={expected_shards}, found={len(names)}, '
                         f'missing={missing[:10]}, extra={extra[:10]}')
    rows = [snapshot(data / name) for name in names]
    if any(row['bytes'] <= 0 for row in rows):
        raise ValueError('Empty shard in inventory')
    return rows


def make_manifest(repo, data, rows):
    identity = {
        'format': FORMAT, 'scanner_version': SCANNER_VERSION,
        'scanner_sha256': file_sha(__file__),
        'policy_files': EXPECTED_POLICY, 'lengths': list(LENGTHS),
        'data_root': str(Path(data).resolve()), 'inventory': rows,
        'full_gene_policy': 'same prepare_sequence; require_supervision(None)',
        'window_policy': 'nonoverlapping L-2 token windows; count only windows with at least one known target',
    }
    return {'identity': digest(identity), 'identity_inputs': identity,
            'repo': str(Path(repo).resolve()), 'created_utc': utc_now()}


def prepare_manifest(out, proposed):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    (out / 'receipts').mkdir(exist_ok=True)
    with (out / '.manifest.lock').open('a+') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        path = out / 'census_manifest.json'
        if path.exists():
            existing = json.loads(path.read_text())
            if existing.get('identity') != proposed['identity']:
                raise ValueError('Census output belongs to a different inventory or policy; use a new output directory')
            return existing
        atomic_json(path, proposed)
        return proposed


def empty_stage():
    return {
        'accepted_records': 0, 'excluded_records': 0, 'exclusions_by_reason': {},
        'known_target_opportunities': 0, 'sequence_positions_exposed': 0,
        'amino_acid_positions_exposed': 0, 'events_on_accepted_records': {},
        'accepted_by_species': {},
    }


def empty_windows():
    return {
        'all_windows': 0, 'target_bearing_windows': 0, 'zero_target_windows': 0,
        'records_longer_than_capacity': 0,
        'sequence_positions_exposed': 0, 'sequence_positions_in_zero_target_windows': 0,
        'amino_acid_positions_exposed': 0, 'known_target_opportunities': 0,
        'target_bearing_windows_by_species': {},
    }


def empty_counts():
    return {
        'json_records': 0, 'prepare_accepted_records': 0, 'prepare_rejected_records': 0,
        'prepare_exclusions_by_reason': {}, 'rejection_examples': [],
        'full_gene': {
            'accepted_records': 0, 'excluded_records': 0, 'exclusions_by_reason': {},
            'sequence_positions': 0, 'amino_acid_positions': 0,
            'known_target_opportunities': 0, 'ignored_positions': 0,
            'events_on_accepted_records': {}, 'accepted_by_species': {},
            'protein_length_buckets': {}, 'max_protein_length': 0,
        },
        'current_prefix': {str(n): empty_stage() for n in LENGTHS},
        'proposed_windows': {str(n): empty_windows() for n in LENGTHS},
    }


def inc(counter, key, n=1):
    key = str(key)
    counter[key] = counter.get(key, 0) + n


def add_events(counter, events):
    for key, value in events.items():
        inc(counter, key, value)


def length_bucket(n):
    for upper in (510, 512, 1022, 1024, 1534, 1536, 2045, 2046, 2048):
        if n <= upper:
            return '<=' + str(upper)
    return '>2048'


def count_record(doc, key, policy, counts):
    """Uses the exact production species resolver and sequence policy."""
    if not isinstance(doc, dict):
        raise ValueError('Training record must be a JSON object')
    sid = policy.common.resolve_species(doc.get('species'), policy.mapping, policy.n_real)
    counts['json_records'] += 1
    dna = doc.get('dna_sequence') or doc.get('seq') or doc.get('dna') or doc.get('sequence')
    try:
        prepared = policy.token.prepare_sequence(dna, doc.get('protein_sequence'), policy.vocab)
    except policy.token.RecordRejected as error:
        counts['prepare_rejected_records'] += 1
        inc(counts['prepare_exclusions_by_reason'], error.reason)
        if len(counts['rejection_examples']) < 12:
            counts['rejection_examples'].append({'member': key, 'reason': error.reason})
        for stage in [counts['full_gene'], *counts['current_prefix'].values()]:
            stage['excluded_records'] += 1
            inc(stage['exclusions_by_reason'], error.reason)
        return
    counts['prepare_accepted_records'] += 1
    targets = prepared.target_positions
    sequence_len = len(targets) + len(prepared.ignored_positions)
    protein_len = sequence_len - 1  # Reviewed policy always appends one stop token.
    for length in LENGTHS:
        stage = counts['current_prefix'][str(length)]
        try:
            policy.token.require_supervision(prepared, length)
        except policy.token.RecordRejected as error:
            stage['excluded_records'] += 1
            inc(stage['exclusions_by_reason'], error.reason)
        else:
            stage['accepted_records'] += 1
            limit = min(sequence_len, length - 2)
            stage['known_target_opportunities'] += bisect_left(targets, limit)
            stage['sequence_positions_exposed'] += limit
            stage['amino_acid_positions_exposed'] += min(protein_len, limit)
            add_events(stage['events_on_accepted_records'], prepared.events)
            inc(stage['accepted_by_species'], sid)
    full = counts['full_gene']
    try:
        policy.token.require_supervision(prepared, None)
    except policy.token.RecordRejected as error:
        full['excluded_records'] += 1
        inc(full['exclusions_by_reason'], error.reason)
        return
    full['accepted_records'] += 1
    full['sequence_positions'] += sequence_len
    full['amino_acid_positions'] += protein_len
    full['known_target_opportunities'] += len(targets)
    full['ignored_positions'] += len(prepared.ignored_positions)
    full['max_protein_length'] = max(full['max_protein_length'], protein_len)
    inc(full['protein_length_buckets'], length_bucket(protein_len))
    inc(full['accepted_by_species'], sid)
    add_events(full['events_on_accepted_records'], prepared.events)
    for length in LENGTHS:
        capacity = length - 2
        windows = counts['proposed_windows'][str(length)]
        n_windows = (sequence_len + capacity - 1) // capacity
        target_windows = {position // capacity for position in targets}
        exposed = sum(min(sequence_len, (w + 1) * capacity) - w * capacity for w in target_windows)
        aa_exposed = sum(max(0, min(protein_len, (w + 1) * capacity) - w * capacity) for w in target_windows)
        windows['all_windows'] += n_windows
        windows['records_longer_than_capacity'] += int(sequence_len > capacity)
        windows['target_bearing_windows'] += len(target_windows)
        windows['zero_target_windows'] += n_windows - len(target_windows)
        windows['sequence_positions_exposed'] += exposed
        windows['amino_acid_positions_exposed'] += aa_exposed
        windows['sequence_positions_in_zero_target_windows'] += sequence_len - exposed
        windows['known_target_opportunities'] += len(targets)
        inc(windows['target_bearing_windows_by_species'], sid, len(target_windows))


class HashingReader:
    def __init__(self, handle):
        self.handle = handle
        self.hasher = hashlib.sha256()
        self.bytes_read = 0

    def read(self, size=-1):
        block = self.handle.read(size)
        self.hasher.update(block)
        self.bytes_read += len(block)
        return block


_POLICY = None


def init_worker(repo):
    global _POLICY
    _POLICY = Policy(repo)


def receipt_path(out, name):
    return Path(out) / 'receipts' / (name + '.json')


def validate_counts(counts):
    records = counts['json_records']
    if counts['prepare_accepted_records'] + counts['prepare_rejected_records'] != records:
        raise ValueError('Inconsistent preparation counts')
    full = counts['full_gene']
    for stage in [full, *counts['current_prefix'].values()]:
        if stage['accepted_records'] + stage['excluded_records'] != records:
            raise ValueError('Inconsistent eligibility counts')
        if sum(stage['accepted_by_species'].values()) != stage['accepted_records']:
            raise ValueError('Inconsistent per-species record counts')
        if sum(stage['exclusions_by_reason'].values()) != stage['excluded_records']:
            raise ValueError('Inconsistent exclusion reasons')
    if full['known_target_opportunities'] + full['ignored_positions'] != full['sequence_positions']:
        raise ValueError('Inconsistent full-sequence positions')
    for windows in counts['proposed_windows'].values():
        if not 0 <= windows['records_longer_than_capacity'] <= full['accepted_records']:
            raise ValueError('Inconsistent long-record counts')
        if windows['all_windows'] < full['accepted_records'] + windows['records_longer_than_capacity']:
            raise ValueError('Inconsistent long-record window counts')
        if windows['target_bearing_windows'] + windows['zero_target_windows'] != windows['all_windows']:
            raise ValueError('Inconsistent window counts')
        if windows['sequence_positions_exposed'] + windows['sequence_positions_in_zero_target_windows'] != full['sequence_positions']:
            raise ValueError('Window positions do not cover full-sequence population')
        if windows['known_target_opportunities'] != full['known_target_opportunities']:
            raise ValueError('Windowing lost known target positions')
        if sum(windows['target_bearing_windows_by_species'].values()) != windows['target_bearing_windows']:
            raise ValueError('Inconsistent per-species window counts')


def valid_receipt(path, row, identity, verify_content=False, data=None):
    try:
        receipt = json.loads(Path(path).read_text())
        valid = (receipt['status'] == 'COMPLETE' and receipt['census_identity'] == identity
                 and receipt['file'] == row and receipt['compressed_bytes_read'] == row['bytes']
                 and re.fullmatch('[0-9a-f]{64}', receipt['compressed_sha256']) is not None)
        if valid and verify_content:
            valid = file_sha(Path(data) / row['name']) == receipt['compressed_sha256']
        if valid:
            validate_counts(receipt['counts'])
        return receipt if valid else None
    except (OSError, ValueError, KeyError, TypeError):
        return None


def scan_shard(data, row, out, identity, policy=None):
    policy = policy or _POLICY
    if policy is None:
        raise RuntimeError('Worker policy was not initialized')
    path = Path(data) / row['name']
    if snapshot(path) != row:
        raise RuntimeError('Shard changed after inventory: ' + str(path))
    counts = empty_counts()
    seen = set()
    with path.open('rb') as raw:
        hashed = HashingReader(raw)
        with gzip.GzipFile(fileobj=hashed, mode='rb') as uncompressed:
            with tarfile.open(fileobj=uncompressed, mode='r|') as archive:
                for member in archive:
                    if not member.isfile() or not member.name.endswith('.json'):
                        continue
                    if member.name in seen:
                        raise ValueError('Duplicate JSON member: ' + row['name'] + ':' + member.name)
                    seen.add(member.name)
                    if member.size > MAX_JSON_BYTES:
                        raise ValueError('Oversized JSON record: ' + member.name)
                    handle = archive.extractfile(member)
                    if handle is None:
                        raise ValueError('Unreadable JSON tar member: ' + member.name)
                    doc = json.loads(handle.read())
                    count_record(doc, member.name, policy, counts)
            # tar iteration may stop before gzip EOF; draining verifies the gzip CRC
            # and incorporates every compressed byte into the identity hash.
            while uncompressed.read(1024 * 1024):
                pass
        while hashed.read(1024 * 1024):
            pass
    if not seen:
        raise ValueError('Shard has no JSON records: ' + str(path))
    if snapshot(path) != row:
        raise RuntimeError('Shard changed during census: ' + str(path))
    if hashed.bytes_read != row['bytes']:
        raise RuntimeError('Compressed byte count mismatch: ' + str(path))
    validate_counts(counts)
    receipt = {'format': FORMAT, 'status': 'COMPLETE', 'census_identity': identity,
               'file': row, 'compressed_sha256': hashed.hasher.hexdigest(),
               'compressed_bytes_read': hashed.bytes_read, 'completed_utc': utc_now(), 'counts': counts}
    atomic_json(receipt_path(out, row['name']), receipt)
    return {'name': row['name'], 'records': counts['json_records'], 'status': 'COMPLETE'}


def merge_counts(total, counts):
    """Merge known count schema, avoiding accidental summation of maximum lengths."""
    for key, value in counts.items():
        if isinstance(value, dict):
            if key not in total:
                total[key] = {}
            merge_counts(total[key], value)
        elif isinstance(value, list):
            if key == 'rejection_examples':
                total.setdefault(key, [])
                total[key].extend(value[:max(0, 20 - len(total[key]))])
        elif key == 'max_protein_length':
            total[key] = max(total.get(key, 0), value)
        else:
            total[key] = total.get(key, 0) + value


def summarize(out, manifest, verify_reused=False):
    out = Path(out)
    rows = manifest['identity_inputs']['inventory']
    data = Path(manifest['identity_inputs']['data_root'])
    aggregate, missing, invalid, content_rows = empty_counts(), [], [], []
    for row in rows:
        if snapshot(data / row['name']) != row:
            invalid.append(row['name'] + ': source metadata changed')
            continue
        path = receipt_path(out, row['name'])
        receipt = valid_receipt(path, row, manifest['identity'], verify_reused, data)
        if receipt is None:
            (invalid if path.exists() else missing).append(row['name'])
            continue
        merge_counts(aggregate, receipt['counts'])
        content_rows.append([row['name'], receipt['compressed_sha256']])
    complete = not missing and not invalid and len(content_rows) == len(rows)
    validate_counts(aggregate)
    summary = {
        'format': FORMAT, 'status': 'COMPLETE' if complete else 'INCOMPLETE',
        'census_identity': manifest['identity'], 'updated_utc': utc_now(),
        'expected_shards': len(rows), 'completed_shards': len(content_rows),
        'missing_receipts': missing, 'invalid_receipts_or_changed_files': invalid,
        'content_identity_sha256': digest(content_rows) if complete else None,
        'counts': aggregate,
        'scope': 'All declared shard files and JSON records' if complete else 'Partial corpus; do not derive a full-pass training budget',
        'definitions': {
            'records': 'Physical JSON records. Duplicate JSON member names within one shard are fatal.',
            'biological_duplicates': 'Not checked across shards or by DNA/protein/gene ID; accepted records are not proven unique biological genes.',
            'current_prefix': 'Exact existing prepare_sequence plus require_supervision(max_length), keeping first max_length-2 sequence positions.',
            'full_gene': 'Exact existing prepare_sequence plus require_supervision(None). Includes one true or unknown terminal-stop token.',
            'proposed_windows': 'Nonoverlapping max_length-2 sequence-token windows of full-gene-eligible records. Only target-bearing windows are counted as training windows.',
            'known_target_opportunities': 'Known codons available to supervise before random MLM/full-mask selection; not actual supervised targets.',
            'coverage': 'All known target opportunities are covered by proposed windows; zero-target windows and their omitted positions are separately reported.',
            'species_counts': 'Resolved real-species integer IDs using exact common.resolve_species.',
            'length_buckets': 'Mutually exclusive first matching upper bound, measured in protein amino acids, excluding appended stop.',
            'receipt_reuse': 'Bound to source/config and shard size/mtime. Stored compressed SHA is from original scan; --verify-reused-content rehashes retained files.',
            'not_training_readiness': 'A complete census does not validate loader replay, model training, evaluation correctness or GPU preflight.',
        },
    }
    atomic_json(out / 'census_summary.json', summary)
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=DEFAULT_REPO)
    parser.add_argument('--data', type=Path, default=DEFAULT_DATA)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=2)
    parser.add_argument('--expected-shards', type=int, default=5874)
    parser.add_argument('--task-index', type=int, default=0)
    parser.add_argument('--task-count', type=int, default=1)
    parser.add_argument('--max-shards', type=int)
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--summarize-only', action='store_true')
    parser.add_argument('--verify-reused-content', action='store_true')
    args = parser.parse_args(argv)
    if not 1 <= args.workers <= 64:
        parser.error('--workers must be in 1..64; use the CPU allocation requested for this job')
    if args.task_count < 1 or not 0 <= args.task_index < args.task_count:
        parser.error('Invalid task partition')
    if args.max_shards is not None and args.max_shards < 1:
        parser.error('--max-shards must be positive')
    if args.prepare_only and args.summarize_only:
        parser.error('Choose only one mode')
    Policy(args.repo)
    rows = inventory(args.data, args.expected_shards)
    manifest = prepare_manifest(args.out, make_manifest(args.repo, args.data, rows))
    if args.prepare_only:
        print('CENSUS_MANIFEST=' + str(args.out / 'census_manifest.json'))
        print('CENSUS_STATUS=PREPARED_NOT_SCANNED')
        return 0
    if args.summarize_only:
        result = summarize(args.out, manifest, args.verify_reused_content)
        print('CENSUS_STATUS=' + result['status'])
        print('CENSUS_SUMMARY=' + str(args.out / 'census_summary.json'))
        return 0 if result['status'] == 'COMPLETE' else 2
    selected = rows[args.task_index::args.task_count]
    if args.max_shards is not None:
        selected = selected[:args.max_shards]
    pending, reused = [], 0
    for row in selected:
        receipt = valid_receipt(receipt_path(args.out, row['name']), row, manifest['identity'],
                                args.verify_reused_content, args.data)
        if receipt:
            reused += 1
        else:
            pending.append(row)
    errors = []
    with ProcessPoolExecutor(max_workers=args.workers, initializer=init_worker, initargs=(str(args.repo),)) as executor:
        futures = {executor.submit(scan_shard, str(args.data), row, str(args.out), manifest['identity']): row for row in pending}
        for future in as_completed(futures):
            row = futures[future]
            try:
                progress = future.result()
            except Exception as error:
                message = {'name': row['name'], 'status': 'ERROR', 'error_type': type(error).__name__, 'error': str(error)[:1500]}
                errors.append(message)
                atomic_json(receipt_path(args.out, row['name']), dict(message, census_identity=manifest['identity'], file=row))
                print(json.dumps(message), flush=True)
            else:
                print(json.dumps(progress), flush=True)
    # Parallel array tasks use a separate summary gate. A single-task full run
    # must establish complete coverage before returning success.
    task = {'status': 'FAILED' if errors else 'PASS', 'census_identity': manifest['identity'],
            'task_index': args.task_index, 'task_count': args.task_count,
            'requested_shards': len(selected), 'reused_shards': reused,
            'scanned_shards': len(pending) - len(errors), 'errors': errors,
            'scope': 'Requested task only; run --summarize-only to establish complete corpus coverage',
            'completed_utc': utc_now()}
    atomic_json(args.out / f'task_{args.task_index:04d}_status.json', task)
    print('CENSUS_TASK_STATUS=' + task['status'])
    if args.task_count == 1:
        result = summarize(args.out, manifest, False)
        print('CENSUS_STATUS=' + result['status'])
        print('CENSUS_SUMMARY=' + str(args.out / 'census_summary.json'))
        if errors:
            return 1
        if args.max_shards is not None:
            print('CENSUS_SCOPE=LIMITED_SCAN_NOT_A_FULL_CORPUS_GATE')
            return 0
        return 0 if result['status'] == 'COMPLETE' else 2
    print('CENSUS_SCOPE=TASK_ONLY_REQUIRES_SUMMARY_GATE')
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
