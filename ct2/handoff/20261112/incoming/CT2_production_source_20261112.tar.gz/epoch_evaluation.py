#!/usr/bin/env python3
"""Fixed-cohort, full-sequence evaluation for CT2 baseline and completed epochs.

This is a separate distributed process. It does not change training RNG or data
cursors. Predictions retain explicit conditioning and windowing provenance.
"""
from __future__ import annotations
import argparse
import contextlib
import fcntl
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import random
import sys
import time
import uuid

from candidate_collator import CODE, CandidateCollator, codon_token, stable_seed
from candidate_model import (SOURCE_CHECKPOINT_SHA256, build_from_state, load_source,
                             sha, tokenizer_at, validate_plan_identity)
from gpu_preflight import atomic_json, gather, initialize, rank0_action
from biological_metrics import REQUIRED_METRICS

SCHEMA = 'ct2-epoch-evaluation-v1'
CONDITIONS = ('own', 'unknown', 'wrong')
ALL_CONDITIONS = (*CONDITIONS, 'native', 'hfc')
UNKNOWN_SPECIES = 26678
EVALUATION_LENGTH = 2048
QUALIFICATION_RECORDS_PER_COHORT = 12
CURRENT_PANEL_SHA256 = 'a9d5cf2535ba1370c41993ef02a3f98a980e924223d762a67ee38edb1e7f33ba'
PROTOCOL = {
    'generation': 'single_forward_synonymous_argmax_per_nonoverlapping_window',
    'sequence_scope': 'all_supplied_residues_plus_one_terminal_stop',
    'max_tokens': EVALUATION_LENGTH, 'content_tokens': EVALUATION_LENGTH - 2,
    'framing': 'CLS,content,SEP; terminal stop occurs only at end of full sequence',
    'padding': 'fixed_max_tokens', 'truncation': 'none', 'sampling': False,
    'conditioning': 'own,unknown,fixed_hash_selected_wrong_real_species',
    'partial_mlm': 'fixed_per_record_window_15pct_80_10_5_5; at_least_one_known_target_if_any',
    'cross_entropy': 'raw_90_token_logits_on_known_native_targets; synonymous_constraint_only_for_generation',
    'comparability': 'Identical across CT2 curriculum epochs; historical published generation protocols remain separately identified.'}
LEGACY_PROTOCOL = dict(PROTOCOL,
    sequence_scope='fixed_historical_request_up_to_2046_residues_without_stop',
    framing='CLS,up_to_2046_amino_acid_tokens,SEP; no_terminal_stop_token',
    truncation='historical_request_was_already_capped; no_additional_evaluator_truncation',
    comparability='Historical common-valid request IDs and no-stop framing; source model and conditioning differ.')


def now():
    return datetime.now(timezone.utc).isoformat()


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def strict_read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate JSON key: ' + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON value')))


def window_ranges(content_length, maximum=EVALUATION_LENGTH):
    if type(content_length) is not int or content_length < 1:
        raise ValueError('Expected positive full-sequence content length')
    if type(maximum) is not int or maximum < 3:
        raise ValueError('Invalid maximum token length')
    width = maximum - 2
    return [(start, min(start + width, content_length)) for start in range(0, content_length, width)]


def wrong_species_id(eval_id, own_id, n_real=26678):
    if not isinstance(eval_id, str) or not eval_id or type(own_id) is not int or not 0 <= own_id < n_real or n_real < 2:
        raise ValueError('Invalid deterministic wrong-host request')
    selected = stable_seed('ct2-eval-wrong-host-v1:' + eval_id) % (n_real - 1)
    return selected + (selected >= own_id)


def validate_prediction(dna, protein, terminal_stop=True):
    if not isinstance(dna, str) or set(dna) - set('ACGT') or len(dna) != 3 * (len(protein) + int(terminal_stop)):
        raise ValueError('Generated DNA characters/length are invalid')
    codons = [dna[i:i+3] for i in range(0, len(dna), 3)]
    body = codons[:-1] if terminal_stop else codons
    if (terminal_stop and CODE[codons[-1]] != '*') or ''.join(CODE[c] for c in body) != protein:
        raise ValueError('Generated DNA does not exactly preserve the requested protein and terminal stop')
    return True


def conditioning(record, mapping):
    own = record.get('species_id', mapping.get(record['species']))
    if type(own) is not int or mapping.get(record['species']) != own:
        raise ValueError('Evaluation species identity differs from pinned mapping')
    if 'wrong_species_id' in record or 'wrong_species' in record:
        wrong = record.get('wrong_species_id')
        if (type(wrong) is not int or wrong == own
            or mapping.get(record.get('wrong_species')) != wrong):
            raise ValueError('Prepared fixed wrong-host identity is invalid')
    else:
        # Used only by the independently pinned quick clipping probe. Full
        # epoch cohorts carry their frozen wrong-host assignments explicitly.
        wrong = wrong_species_id(str(record['eval_id']), own, len(mapping))
    return {'own': own, 'unknown': UNKNOWN_SPECIES, 'wrong': wrong}


def prepared_content(record, vocab, token_policy):
    protein = token_policy.normalize_protein(record['protein_sequence'])
    if record['cohort'] == 'legacy_common_valid':
        if len(protein) > 2046 or set(protein) - set('ACDEFGHIKLMNPQRSTVWY'):
            raise ValueError('Legacy request exceeds the pinned historical protein protocol')
        native = ''.join(record['native_dna'].split()).upper().replace('U', 'T')
        tokens, targets, ignored = [], [], []
        for position, residue in enumerate(protein):
            codon = native[3*position:3*position+3]
            if CODE.get(codon) == residue:
                tokens.append(vocab[codon_token(codon)]); targets.append(position)
            else:
                tokens.append(vocab[residue.lower() + '_unk']); ignored.append(position)
        for key, observed in [('native_known_target_positions', targets), ('native_ignored_positions', ignored)]:
            if key in record and list(record[key]) != observed:
                raise ValueError('Legacy native alignment positions changed: ' + key)
        return protein, tokens, set(targets)
    prepared = token_policy.prepare_sequence(record['native_dna'], protein, vocab)
    tokens = [vocab[word] for word in prepared.text.split()]
    if len(tokens) != len(protein) + 1:
        raise ValueError('Prepared native sequence does not preserve all protein positions')
    for key, observed in [('native_known_target_positions', list(prepared.target_positions)),
                          ('native_ignored_positions', list(prepared.ignored_positions))]:
        if key in record and list(record[key]) != observed:
            raise ValueError('Prepared evaluation target positions changed: ' + key)
    return protein, tokens, set(prepared.target_positions)


def empty_ce():
    return dict(full_ce_sum=0.0, full_targets=0, full_correct=0,
                partial_ce_sum=0.0, partial_targets=0, partial_correct=0)


def finish_ce(value):
    result = dict(value)
    for kind in ('full', 'partial'):
        n = result[kind + '_targets']
        result[kind + '_ce'] = result[kind + '_ce_sum'] / n if n else None
        result[kind + '_accuracy'] = result[kind + '_correct'] / n if n else None
    return result


def add_ce(total, value):
    for key in empty_ce():
        total[key] += value[key]


def empty_sensitivity():
    return dict(records=0, codon_disagreement_fraction_sum=0., raw_full_logit_absolute_difference_sum=0.,
                raw_full_logit_values=0)


def add_sensitivity(total, prediction):
    total['records'] += 1
    total['codon_disagreement_fraction_sum'] += prediction['codon_disagreement_vs_own']
    total['raw_full_logit_absolute_difference_sum'] += prediction['full_logit_absolute_difference_sum_vs_own']
    total['raw_full_logit_values'] += prediction['full_logit_values_compared_vs_own']


def finish_sensitivity(value):
    return dict(value,
        mean_sequence_codon_disagreement_vs_own=value['codon_disagreement_fraction_sum']/value['records'] if value['records'] else None,
        mean_abs_full_logits_vs_own=value['raw_full_logit_absolute_difference_sum']/value['raw_full_logit_values'] if value['raw_full_logit_values'] else None)


def evaluate_record(model, tokenizer, record, mapping, token_policy, *, maximum=EVALUATION_LENGTH):
    """Return three conditioned predictions and CE counts; never truncate input."""
    import torch
    vocab = tokenizer.get_vocab()
    protein, native, target_positions = prepared_content(record, vocab, token_policy)
    conditions = conditioning(record, mapping)
    reverse_species = {value: key for key, value in mapping.items()}
    device = next(model.parameters()).device
    collator = CandidateCollator(tokenizer, seed=20261027, rank=0, stage=0, unknown_probability=0.)
    terminal_stop = record['cohort'] != 'legacy_common_valid'
    aa = protein + ('*' if terminal_stop else '')
    allowed = {residue: [vocab[codon_token(codon)] for codon, value in CODE.items() if value == residue]
               for residue in set(aa)}
    reverse = {v: k[-3:].upper() for k, v in vocab.items() if len(k) == 5 and k[-3:].upper() in CODE}
    dna_parts = {condition: [] for condition in CONDITIONS}
    totals = {condition: empty_ce() for condition in CONDITIONS}
    logit_differences = {condition: [0.0, 0] for condition in CONDITIONS}
    ranges = window_ranges(len(native), maximum)
    for window_index, (start, end) in enumerate(ranges):
        framed = [tokenizer.cls_token_id, *native[start:end], tokenizer.sep_token_id]
        original = torch.full((1, maximum), tokenizer.pad_token_id, dtype=torch.long)
        attention = torch.zeros_like(original)
        original[0, :len(framed)] = torch.tensor(framed)
        attention[0, :len(framed)] = 1
        labels = torch.full_like(original, -100)
        for p in range(start, end):
            if p in target_positions:
                labels[0, p - start + 1] = native[p]
        full_ids = original.clone()
        for p in range(start, end):
            full_ids[0, p - start + 1] = vocab['__unk' if aa[p] == '*' else aa[p].lower() + '_unk']
        if (labels != -100).any():
            partial = collator([{'token_ids': native[start:end], 'species_id': conditions['own'],
                                'identity': str(record['eval_id']) + ':' + str(window_index)}],
                               maximum, 0., stable_seed('ct2-eval-mask:' + str(record['eval_id']) + ':' + str(window_index)), 0)
            partial_ids, partial_labels = partial['input_ids'], partial['labels']
        else:
            partial_ids, partial_labels = original, labels
        species_ids = torch.tensor([conditions[c] for c in CONDITIONS], device=device)
        mask = attention.expand(3, -1).to(device)
        for kind, inputs, target in [('full', full_ids, labels), ('partial', partial_ids, partial_labels)]:
            inputs = inputs.expand(3, -1).to(device)
            target = target.expand(3, -1).to(device)
            autocast = torch.autocast(device_type='cuda', dtype=torch.bfloat16) if device.type == 'cuda' else contextlib.nullcontext()
            with torch.inference_mode(), autocast:
                logits = model(inputs, mask, species_ids)
            if logits.shape != (3, maximum, len(vocab)) or not torch.isfinite(logits).all():
                raise FloatingPointError('Evaluation logits have invalid shape or nonfinite values')
            losses = torch.nn.functional.cross_entropy(logits.float().reshape(-1, len(vocab)),
                                                       target.reshape(-1), ignore_index=-100,
                                                       reduction='none').reshape(3, maximum)
            for j, condition in enumerate(CONDITIONS):
                selected = target[j] != -100
                totals[condition][kind + '_ce_sum'] += float(losses[j, selected].double().sum())
                totals[condition][kind + '_targets'] += int(selected.sum())
                totals[condition][kind + '_correct'] += int((logits[j].argmax(-1)[selected] == target[j, selected]).sum())
                if kind == 'full':
                    sense_count = max(0, min(end, len(protein)) - start)
                    if sense_count:
                        delta = (logits[j, 1:sense_count+1].float() - logits[0, 1:sense_count+1].float()).abs()
                        logit_differences[condition][0] += float(delta.double().sum())
                        logit_differences[condition][1] += int(delta.numel())
                    for local, residue in enumerate(aa[start:end], 1):
                        ids = allowed[residue]
                        choice = ids[int(logits[j, local, ids].float().argmax())]
                        dna_parts[condition].append(reverse[choice])
    predictions = []
    for condition in CONDITIONS:
        dna = ''.join(dna_parts[condition])
        validate_prediction(dna, protein, terminal_stop)
        predictions.append({**record, 'protein_sequence': protein,
            'requested_condition': condition, 'conditioned_species_id': conditions[condition],
            'conditioned_species': '[UNKNOWN]' if condition == 'unknown' else reverse_species[conditions[condition]],
            'predicted_dna': dna, 'generation_valid': True, 'terminal_stop_included': terminal_stop,
            'generation_protocol': dict(PROTOCOL if terminal_stop else LEGACY_PROTOCOL, max_tokens=maximum, content_tokens=maximum-2),
            'window_count': len(ranges), 'known_native_targets': len(target_positions),
            'full_logit_absolute_difference_sum_vs_own': logit_differences[condition][0],
            'full_logit_values_compared_vs_own': logit_differences[condition][1],
            'ce': finish_ce(totals[condition])})
    own = predictions[0]['predicted_dna'][:len(protein)*3]
    for row in predictions:
        body = row['predicted_dna'][:len(protein)*3]
        row['codon_disagreement_vs_own'] = sum(own[p:p+3] != body[p:p+3]
                                               for p in range(0, len(own), 3)) / len(protein)
    return predictions


@contextlib.contextmanager
def preserve_rng_and_mode(model):
    import numpy as np
    import torch
    states = (random.getstate(), np.random.get_state(), torch.get_rng_state(),
              torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None, model.training)
    try:
        model.eval()
        yield
    finally:
        random.setstate(states[0]); np.random.set_state(states[1]); torch.set_rng_state(states[2])
        if states[3] is not None:
            torch.cuda.set_rng_state_all(states[3])
        model.train(states[4])


def quick_host_probe(model, tokenizer, plan, stage=0, max_records=12):
    """Small matched-host CE probe for clipping experiments; no distributed calls."""
    from census import Policy
    if not 0 <= stage < 4 or type(max_records) is not int or not 1 <= max_records <= 32:
        raise ValueError('Invalid bounded host-probe request')
    repo = Path(plan['source']['repo'])
    panel = repo / 'source/eval_panel.jsonl'
    if sha(panel) != CURRENT_PANEL_SHA256:
        raise ValueError('Current fixed evaluation panel changed')
    policy = Policy(repo)
    rows, selected_hosts = [], set()
    with panel.open() as stream:
        for index, line in enumerate(stream):
            if not line.strip():
                continue
            row = json.loads(line)
            if row['species'] in selected_hosts:
                continue
            selected_hosts.add(row['species'])
            rows.append({'eval_id': 'current:' + row['eval_key'], 'cohort': 'current_panel',
                         'species': row['species'], 'species_id': policy.mapping[row['species']],
                         'protein_sequence': row['protein_sequence'], 'native_dna': row['dna_sequence']})
            if len(rows) == max_records:
                break
    if len(rows) != max_records:
        raise ValueError('Insufficient records in fixed host-probe panel')
    module = model.module if hasattr(model, 'module') else model
    aggregate = {condition: empty_ce() for condition in CONDITIONS}
    disagreement = {condition: 0. for condition in CONDITIONS}
    logit_differences = {condition: [0.0, 0] for condition in CONDITIONS}
    maximum = plan['stages'][stage]['max_length']
    with preserve_rng_and_mode(module):
        for row in rows:
            for prediction in evaluate_record(module, tokenizer, row, policy.mapping, policy.token, maximum=maximum):
                condition = prediction['requested_condition']
                add_ce(aggregate[condition], prediction['ce'])
                disagreement[condition] += prediction['codon_disagreement_vs_own']
                logit_differences[condition][0] += prediction['full_logit_absolute_difference_sum_vs_own']
                logit_differences[condition][1] += prediction['full_logit_values_compared_vs_own']
    return {'schema': 'ct2-quick-host-probe-v1', 'status': 'PASS', 'panel_sha256': CURRENT_PANEL_SHA256,
            'selected_eval_ids': [r['eval_id'] for r in rows], 'selected_identity_sha256': canonical_sha(rows),
            'length': maximum, 'max_records': max_records, 'selected_species_count': len(selected_hosts),
            'conditions': {condition: dict(finish_ce(value), mean_codon_disagreement_vs_own=disagreement[condition]/len(rows),
                           mean_abs_full_logits_vs_own=logit_differences[condition][0]/logit_differences[condition][1],
                           full_logit_values_compared=logit_differences[condition][1])
                           for condition, value in aggregate.items()},
            'protocol': dict(PROTOCOL, max_tokens=maximum, content_tokens=maximum-2),
            'scope': 'First fixed record from each of 12 distinct current-panel hosts; not the complete biological evaluation.'}


def qualification_subset(rows, count=QUALIFICATION_RECORDS_PER_COHORT):
    """Include the longest request, plus a stable prefix, without duplicates."""
    if len(rows) < count or count < 1:
        raise ValueError('Insufficient records for qualification subset')
    longest = max(range(len(rows)), key=lambda index: len(rows[index]['protein_sequence']))
    indices = list(range(count - 1))
    if longest in indices:
        indices.append(count - 1)
    else:
        indices.append(longest)
    return [rows[index] for index in indices]


def load_inputs(directory, qualification=False):
    """Read pinned cohort files without treating arbitrary files as inputs."""
    directory = Path(directory).resolve()
    manifest_path = directory / 'evaluation_manifest.json'
    from prepare_evaluation import validate_prepared_inputs
    manifest = validate_prepared_inputs(directory)
    cohorts = manifest.get('cohorts')
    if not isinstance(cohorts, list) or {c.get('name') for c in cohorts} != {'current_panel', 'legacy_common_valid'}:
        raise ValueError('Both current and fixed legacy evaluation cohorts are required')
    rows, requested, universe = [], {}, {}
    seen = set()
    for cohort in cohorts:
        name = cohort['name']
        path = Path(cohort['path'])
        if not path.is_absolute():
            path = directory / path
        path = path.resolve()
        if directory not in path.parents or path.is_symlink() or sha(path) != cohort['sha256']:
            raise ValueError('Cohort path or SHA identity mismatch: ' + name)
        all_rows = []
        with path.open() as stream:
            for line in stream:
                if not line.strip():
                    continue
                row = json.loads(line)
                for key in ('eval_id', 'species', 'species_id', 'protein_sequence', 'native_dna'):
                    if key not in row:
                        raise ValueError('Cohort row lacks ' + key)
                if row.get('cohort') != name or (name, row['eval_id']) in seen:
                    raise ValueError('Cohort identity mismatch or repeated eval_id')
                seen.add((name, row['eval_id']))
                all_rows.append(row)
        if len(all_rows) != cohort['records'] or not all_rows:
            raise ValueError('Cohort count differs from its manifest')
        universe[name] = sorted({row['species'] for row in all_rows})
        if len(universe[name]) != cohort['species_count']:
            raise ValueError('Cohort species count mismatch')
        selected = qualification_subset(all_rows) if qualification else all_rows
        if qualification and len(selected) != QUALIFICATION_RECORDS_PER_COHORT:
            raise ValueError('Qualification cohort contains fewer than 12 records')
        requested[name] = len(selected)
        rows.extend(selected)
    return manifest, rows, requested, universe


def prepare_output(output, request):
    """Bind a restart namespace to exact inputs; committed parts are reusable."""
    output = Path(output)
    identity = canonical_sha(request)
    if output.exists():
        previous = strict_read(output / 'request.json')
        if previous.get('identity') != identity or {k:v for k,v in previous.items() if k not in ('identity','started_utc')} != request:
            raise ValueError('Existing evaluation output belongs to a different request')
    else:
        output.mkdir(parents=True)
        atomic_json(output / 'request.json', dict(request, identity=identity, started_utc=now()))
    return identity


def validated_rank_report(output, rank, request_identity, expected_counts):
    output = Path(output)
    path = output / f'rank_{rank:02d}.json'
    if not path.exists():
        return None
    report = strict_read(path)
    n = sum(expected_counts.values())
    if (report.get('rank') != rank or report.get('request_identity') != request_identity
        or report.get('processed_by_cohort') != expected_counts
        or report.get('prediction_rows') != 5*n or report.get('metric_rows') != 15*n):
        raise ValueError('Committed rank report differs from its evaluation request')
    for key, expected in [('predictions',f'predictions_rank_{rank:02d}.jsonl'),
                          ('metrics',f'metrics_rank_{rank:02d}.jsonl')]:
        item = report.get(key,{})
        if item.get('path') != expected or (output/expected).is_symlink() or sha(output/expected) != item.get('sha256'):
            raise ValueError('Committed evaluation rank part changed: ' + expected)
    for cohort in expected_counts:
        if set(report.get('ce',{}).get(cohort,{})) != set(CONDITIONS):
            raise ValueError('Committed CE report lacks conditioning controls')
        for condition in CONDITIONS:
            value = report['ce'][cohort][condition]
            if set(value) != set(empty_ce()) or any(not isinstance(v,(int,float)) or not math.isfinite(v) or v<0 for v in value.values()):
                raise ValueError('Invalid committed CE counts')
        controls = report.get('host_sensitivity',{}).get(cohort,{})
        if set(controls) != set(CONDITIONS):
            raise ValueError('Committed host-sensitivity controls are incomplete')
        for value in controls.values():
            if set(value) != set(empty_sensitivity()) or value['records'] != expected_counts[cohort]:
                raise ValueError('Host-sensitivity denominator differs from requested cohort')
            if any(not isinstance(v,(int,float)) or not math.isfinite(v) or v<0 for v in value.values()):
                raise ValueError('Invalid committed host-sensitivity values')
    return report


def preserve_partial_rank(output, rank):
    """Move only this evaluator's uncommitted rank files out of the way."""
    output = Path(output)
    if (output/f'rank_{rank:02d}.json').exists():
        raise ValueError('A committed rank result must be validated, never overwritten')
    partial = [output/name for name in (f'predictions_rank_{rank:02d}.jsonl',f'metrics_rank_{rank:02d}.jsonl')
               if (output/name).exists()]
    if partial:
        destination = output/'interrupted'/('rank_'+str(rank)+'_'+uuid.uuid4().hex)
        destination.mkdir(parents=True)
        for path in partial:
            if path.is_symlink():
                raise ValueError('Refusing symlinked partial evaluation output')
            path.rename(destination/path.name)


def wait_for_rank_reports(output, request_identity, *, timeout_seconds=24*3600):
    """Wait without an outstanding NCCL collective while CPU scoring differs.

    A resumed evaluation can have seven complete ranks and one long outstanding
    rank. Entering all_gather immediately would otherwise inherit the training
    NCCL timeout. Slurm's kill-on-bad-exit handles failed worker processes.
    """
    output = Path(output)
    started = time.monotonic()
    while True:
        paths = [output/f'rank_{rank:02d}.json' for rank in range(8)]
        if all(path.is_file() for path in paths):
            for rank,path in enumerate(paths):
                report = strict_read(path)
                if report.get('rank') != rank or report.get('request_identity') != request_identity:
                    raise ValueError('Final rank report belongs to a different evaluation request')
            return
        if time.monotonic()-started >= timeout_seconds:
            raise TimeoutError('Evaluation rank completion wait exceeded its walltime bound')
        time.sleep(5)


def load_evaluation_model(checkpoint_path, plan, device, qualification, release_id):
    import torch
    path = Path(checkpoint_path)
    observed = sha(path)
    if observed == SOURCE_CHECKPOINT_SHA256:
        if path.resolve() != Path(plan['source']['checkpoint']).resolve():
            raise ValueError('Baseline checkpoint path differs from the reviewed source')
        model, tokenizer, source = load_source(plan, device, verify_checkpoint_hash=False)
        metadata = dict(path=str(path.resolve()), sha256=observed, format='ct2-source-baseline',
                        mode='baseline', stage=None, completed_updates=0, release_id=release_id,
                        plan_identity=plan['identity'], source=source)
    else:
        from production_trainer import read_checkpoint, validate_progress
        checkpoint = read_checkpoint(path)
        validate_progress(checkpoint, plan, 'qualification' if qualification else 'production', release_id)
        if checkpoint.get('format') != 'ct2-production-v1' or checkpoint.get('plan_identity') != plan['identity']:
            raise ValueError('Unsupported production checkpoint or plan')
        if not release_id or checkpoint.get('release_id') != release_id:
            raise ValueError('Production checkpoint release identity mismatch')
        if qualification:
            if (checkpoint.get('mode') != 'qualification' or checkpoint.get('stage') != 3
                or checkpoint.get('stage_step') != 2 or checkpoint.get('completed_updates') != 8
                or checkpoint.get('stage_complete') is not True):
                raise ValueError('Qualification evaluation requires the complete four-length transition endpoint')
        elif (checkpoint.get('mode') != 'production' or checkpoint.get('stage_complete') is not True
              or checkpoint.get('full_dataset_verified') is not True):
            raise ValueError('Full epoch evaluation requires a verified complete production epoch')
        if checkpoint.get('source', {}).get('checkpoint_sha256') != SOURCE_CHECKPOINT_SHA256:
            raise ValueError('Production checkpoint source lineage mismatch')
        from execution_profile import PROFILE, validate_snapshot
        validate_snapshot(checkpoint.get('execution_settings', {}))
        tokenizer = tokenizer_at(plan['source']['repo'])
        model = build_from_state(checkpoint['model_config'], checkpoint['state_dict'],
                                 checkpoint['species_embed_scale'], tokenizer, device)
        metadata = {key: checkpoint.get(key) for key in ('format', 'mode', 'stage', 'stage_step',
                    'completed_updates', 'release_id', 'plan_identity', 'trainer_identity', 'stage_complete',
                    'full_dataset_verified', 'source', 'clip_value')}
        metadata.update(path=str(path.resolve()), sha256=observed)
        del checkpoint
    model.eval()
    return model, tokenizer, metadata


def json_lines(path):
    with Path(path).open() as stream:
        for line in stream:
            if line.strip():
                yield json.loads(line)


def write_line(stream, value):
    stream.write(json.dumps(value, sort_keys=True, allow_nan=False) + '\n')


def run(args):
    import torch
    import torch.distributed as dist
    from census import Policy
    from biological_metrics import MetricEngine, REQUIRED_METRICS, summarize
    device, rank, versions, topology = initialize()
    started = time.monotonic()
    plan = strict_read(args.plan)
    validate_plan_identity(plan)
    manifest, records, requested, universe = load_inputs(args.inputs, args.qualification)
    input_hash = sha(Path(args.inputs) / 'evaluation_manifest.json')
    input_identity = manifest['identity_sha256']
    output = args.output.resolve()
    checkpoint_sha256 = rank0_action(lambda: sha(args.checkpoint))
    request = {'schema': SCHEMA, 'checkpoint': str(args.checkpoint.resolve()),
               'checkpoint_sha256': checkpoint_sha256,
               'input_manifest_sha256': input_hash, 'input_identity': input_identity,
               'plan_identity': plan['identity'], 'release_id': args.release_id,
               'qualification': args.qualification, 'requested_by_cohort': requested,
               'selected_eval_ids_sha256': canonical_sha([(r['cohort'],r['eval_id']) for r in records]),
               'protocols': {'current_panel': PROTOCOL, 'legacy_common_valid': LEGACY_PROTOCOL}}
    lock_holder = []
    def prepare():
        identity = prepare_output(output, request)
        handle = (output/'.evaluation.lock').open('a')
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        lock_holder.append(handle)
        return identity
    request_identity = rank0_action(prepare)
    model, tokenizer, checkpoint = load_evaluation_model(args.checkpoint, plan, device, args.qualification, args.release_id)
    observed = gather(checkpoint['sha256'])
    if len(set(observed)) != 1 or observed[0] != checkpoint_sha256:
        raise RuntimeError('Ranks loaded different checkpoint identities')
    policy = Policy(plan['source']['repo'])
    frozen_path = Path(args.inputs) / 'frozen_reference.json'
    if not frozen_path.is_file():
        raise FileNotFoundError('Evaluation preparation must supply frozen_reference.json')
    frozen = strict_read(frozen_path)
    codon_table = Path(frozen['identity']['sources']['codon_table']['path'])
    if sha(codon_table) != frozen['identity']['sources']['codon_table']['sha256']:
        raise ValueError('Frozen codon table changed')
    engine = MetricEngine(codon_table, frozen_path, wrong_species_universe=universe)
    prediction_path = output / f'predictions_rank_{rank:02d}.jsonl'
    metrics_path = output / f'metrics_rank_{rank:02d}.jsonl'
    expected_counts = {name: sum(1 for index,row in enumerate(records) if index % 8 == rank and row['cohort']==name)
                       for name in requested}
    rank_report = validated_rank_report(output, rank, request_identity, expected_counts)
    if rank_report is None:
        preserve_partial_rank(output, rank)
        counters = {name: 0 for name in requested}
        count_predictions = count_metrics = 0
        ce_summary = {name: {condition: empty_ce() for condition in CONDITIONS} for name in requested}
        host_sensitivity = {name: {condition: empty_sensitivity() for condition in CONDITIONS} for name in requested}
        pending = []
        def score_pending(metric_stream):
            nonlocal count_metrics
            if not pending:
                return
            scored = engine.score_batch(pending)
            if len(scored) != len(pending) * 3:
                raise RuntimeError('Biological scorer did not emit all three rare modes per prediction')
            for row in scored:
                if any(name not in row for name in REQUIRED_METRICS):
                    raise RuntimeError('Biological scorer omitted a required metric field')
                write_line(metric_stream, row)
                count_metrics += 1
            pending.clear()
        with prediction_path.open('x') as predictions, metrics_path.open('x') as metrics:
            for index, record in enumerate(records):
                if index % 8 != rank:
                    continue
                generated = evaluate_record(model, tokenizer, record, policy.mapping, policy.token)
                if [row['requested_condition'] for row in generated] != list(CONDITIONS):
                    raise RuntimeError('Conditioned generation is incomplete')
                baselines = engine.baseline_records([generated[0]])
                if sorted(row['requested_condition'] for row in baselines) != ['hfc', 'native']:
                    raise RuntimeError('Native and HFC baseline records are required')
                for baseline in baselines:
                    for key in ('ce', 'conditioned_species_id', 'conditioned_species', 'codon_disagreement_vs_own',
                                'full_logit_absolute_difference_sum_vs_own', 'full_logit_values_compared_vs_own'):
                        baseline.pop(key, None)
                    try:
                        validate_prediction(baseline['predicted_dna'], baseline['protein_sequence'],
                                            baseline['cohort'] != 'legacy_common_valid')
                        baseline['generation_valid'] = True
                    except ValueError:
                        baseline['generation_valid'] = False
                        if baseline['requested_condition'] != 'native':
                            raise
                for row in generated:
                    add_ce(ce_summary[record['cohort']][row['requested_condition']], row['ce'])
                    add_sensitivity(host_sensitivity[record['cohort']][row['requested_condition']], row)
                for row in [*generated, *baselines]:
                    write_line(predictions, row); count_predictions += 1; pending.append(row)
                counters[record['cohort']] += 1
                if len(pending) >= 40:
                    score_pending(metrics)
                if sum(counters.values()) % 32 == 0:
                    print(json.dumps({'rank': rank, 'phase': 'EVALUATION', 'processed_records': sum(counters.values())}), flush=True)
            score_pending(metrics)
            for stream in (predictions, metrics):
                stream.flush(); os.fsync(stream.fileno())
        rank_report = {'rank': rank, 'request_identity': request_identity, 'processed_by_cohort': counters, 'prediction_rows': count_predictions,
                       'metric_rows': count_metrics, 'ce': ce_summary, 'host_sensitivity': host_sensitivity,
                       'predictions': {'path': prediction_path.name, 'sha256': sha(prediction_path)},
                       'metrics': {'path': metrics_path.name, 'sha256': sha(metrics_path)},
                       'seconds': time.monotonic() - started,
                       'peak_cuda_allocated_bytes': torch.cuda.max_memory_allocated(device),
                       'peak_cuda_reserved_bytes': torch.cuda.max_memory_reserved(device)}
        atomic_json(output / f'rank_{rank:02d}.json', rank_report)
    wait_for_rank_reports(output, request_identity)
    reports = gather(rank_report)
    def finish():
        processed = {name: sum(row['processed_by_cohort'][name] for row in reports) for name in requested}
        if processed != requested:
            raise RuntimeError('Evaluation omitted or duplicated requested records')
        if any(row['prediction_rows'] != 5*sum(row['processed_by_cohort'].values()) or
               row['metric_rows'] != 15*sum(row['processed_by_cohort'].values()) for row in reports):
            raise RuntimeError('Prediction/metric denominators are incomplete')
        rows = itertools.chain.from_iterable(json_lines(output / row['metrics']['path']) for row in reports)
        summary = summarize(rows)
        species_path = output/'by_species.jsonl'
        species_temp = output/('.by_species.'+str(os.getpid())+'.tmp')
        try:
            with species_temp.open('x') as stream:
                for group in summary['groups']:
                    names = {key:group[key] for key in ('cohort','model','requested_condition','rare_mode')}
                    for species,values in group.pop('by_species').items():
                        write_line(stream, dict(names,species=species,**values))
                stream.flush(); os.fsync(stream.fileno())
            os.replace(species_temp,species_path)
        finally:
            species_temp.unlink(missing_ok=True)
        summary['metric_definitions'] = engine.metadata()
        summary['by_species_file'] = {'path':species_path.name,'sha256':sha(species_path)}
        combined_ce = {name: {} for name in requested}
        combined_sensitivity = {name: {} for name in requested}
        for name in requested:
            for condition in CONDITIONS:
                total = empty_ce()
                for row in reports:
                    add_ce(total, row['ce'][name][condition])
                combined_ce[name][condition] = finish_ce(total)
                sensitivity = empty_sensitivity()
                for row in reports:
                    for key in sensitivity:
                        sensitivity[key] += row['host_sensitivity'][name][condition][key]
                combined_sensitivity[name][condition] = finish_sensitivity(sensitivity)
        summary['fixed_mask_cross_entropy'] = combined_ce
        summary['paired_host_sensitivity'] = combined_sensitivity
        summary['requested_by_cohort'] = requested
        summary['generation_protocols'] = {'current_panel': PROTOCOL, 'legacy_common_valid': LEGACY_PROTOCOL}
        summary['scope'] = 'bounded_qualification' if args.qualification else 'complete_fixed_cohorts'
        atomic_json(output / 'summary.json', summary)
        result = {'schema': SCHEMA, 'status': 'QUALIFICATION_EVALUATION_COMPLETE' if args.qualification else 'EVALUATION_COMPLETE',
                  'checkpoint': checkpoint, 'input_manifest_sha256': input_hash, 'input_identity': input_identity,
                  'plan_identity': plan['identity'], 'release_id': args.release_id, 'qualification': args.qualification,
                  'requested_records': sum(requested.values()), 'processed_records': sum(processed.values()),
                  'requested_by_cohort': requested, 'processed_by_cohort': processed,
                  'conditions': list(ALL_CONDITIONS), 'required_metrics': list(REQUIRED_METRICS),
                  'completed_metrics': list(REQUIRED_METRICS),
                  'protocols': {'current_panel': PROTOCOL, 'legacy_common_valid': LEGACY_PROTOCOL},
                  'request_identity': request_identity,
                  'outputfiles': {'summary.json': sha(output / 'summary.json'), 'by_species.jsonl':sha(species_path)}, 'rank_reports': reports,
                  'runtime_versions': versions, 'topology': topology, 'finished_utc': now(),
                  'reference_sha256': sha(frozen_path), 'reference_identity': frozen['identity_sha256'],
                  'cai_support_note': 'Legacy reference is limited to its retained hosts; unsupported scores retain explicit denominators.',
                  'training_ready': False}
        atomic_json(output / 'evaluation_manifest.json', result)
        print('EVALUATION_STATUS=' + result['status'], flush=True)
    rank0_action(finish)
    for handle in lock_holder:
        handle.close()
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--release-id', required=True)
    parser.add_argument('--qualification', action='store_true')
    args = parser.parse_args(argv)
    try:
        return run(args)
    except Exception as error:
        print('EVALUATION_ERROR=' + type(error).__name__ + ': ' + str(error), file=sys.stderr, flush=True)
        return 1
    finally:
        try:
            import torch.distributed as dist
            if dist.is_available() and dist.is_initialized():
                dist.destroy_process_group()
        except Exception:
            pass


if __name__ == '__main__':
    raise SystemExit(main())
