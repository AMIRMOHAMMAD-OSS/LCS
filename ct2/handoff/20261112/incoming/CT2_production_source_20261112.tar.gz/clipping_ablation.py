#!/usr/bin/env python3
"""Matched eight-H100 clipping experiment; all updates are disposable.

Each invocation starts from the same reviewed 40k model weights, fresh AdamW,
data cursor and training RNG. The clip cap is the only intended branch change.
Learning rates are the constant stage preflight rates, not the production LR
schedule. A healthy short branch does not establish a full-training optimum.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import sys
import time

from candidate_model import SOURCE_CHECKPOINT_SHA256, load_source, new_optimizer, sha, validate_plan_identity
from candidate_collator import CandidateCollator
from gpu_preflight import (atomic_json, ddp_policy, gather, initialize, rank0_action,
                           seed_all, stage_spec)
from production_update import optimizer_update, parse_clip

SCHEMA = 'ct2-clipping-ablation-v1'


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def distribution(values):
    values = list(values)
    if not values:
        return {'count': 0, 'min': None, 'median': None, 'max': None, 'mean': None}
    if not all(math.isfinite(float(v)) for v in values):
        raise FloatingPointError('Nonfinite ablation summary input')
    return {'count': len(values), 'min': min(values), 'median': statistics.median(values),
            'max': max(values), 'mean': statistics.mean(values)}


def branch_protocol(plan, stage, updates):
    here = Path(__file__).resolve().parent
    spec = stage_spec(plan, stage)
    return {'plan_identity': plan['identity'], 'stage': stage, 'seed': plan['seed'],
            'updates': updates, 'learning_rate': spec['learning_rate_preflight'],
            'learning_rate_policy': 'Constant audited preflight rate; not production schedule',
            'source_checkpoint_sha256': SOURCE_CHECKPOINT_SHA256,
            'initialization': 'Same source weights; fresh AdamW; stream begins at zero',
            'input_program_sha256': {name: sha(here/name) for name in (
                'finite_pipeline.py', 'candidate_collator.py', 'finite_plan.py')},
            'probe_records': 12}


def batch_digest(raw_batches, collated_batches):
    """Hash actual record order and every model/loss input without exporting DNA."""
    h = hashlib.sha256()
    for raw, batch in zip(raw_batches, collated_batches):
        h.update(canonical_hash([row['identity'] for row in raw]).encode())
        for name in sorted(batch):
            tensor = batch[name].detach().cpu().contiguous()
            h.update(canonical_hash([name, str(tensor.dtype), list(tensor.shape)]).encode())
            h.update(tensor.numpy().tobytes())
    return h.hexdigest()


def require_probe(report):
    if (report.get('schema') != 'ct2-quick-host-probe-v1' or report.get('status') != 'PASS'
        or not report.get('panel_sha256') or not report.get('selected_identity_sha256')
        or set(report.get('conditions', {})) != {'own', 'unknown', 'wrong'}):
        raise ValueError('The fixed host probe is missing or invalid')
    for item in report['conditions'].values():
        for mode in ('full', 'partial'):
            if (not isinstance(item.get(mode+'_targets'), int) or item[mode+'_targets'] <= 0
                or not isinstance(item.get(mode+'_ce'), (int, float))
                or not math.isfinite(item[mode+'_ce'])):
                raise FloatingPointError('The fixed host probe has invalid CE or target counts')


def summarize(records):
    result = {'completed_updates': len(records),
        'preclip_norm': distribution(row['preclip_norm'] for row in records),
        'clipping_factor': distribution(row['clipping_factor'] for row in records),
        'clipped_updates': sum(row['clipping_factor'] < 1 for row in records),
        'global_ce': distribution(row['global_ce'] for row in records),
        'partial_ce': distribution(row['partial_ce'] for row in records if row['partial_ce'] is not None),
        'full_ce': distribution(row['full_ce'] for row in records if row['full_ce'] is not None),
        'update_seconds': distribution(row['update_seconds'] for row in records),
        'preclip_gradient_groups': {}, 'actual_parameter_updates': {}}
    for group in ('backbone', 'species', 'species_active_rows', 'token_embedding'):
        result['preclip_gradient_groups'][group] = {
            key: distribution(row['update_statistics']['preclip_gradient_groups'][group][key]
                for row in records if row['update_statistics']['preclip_gradient_groups'][group][key] is not None)
            for key in ('gradient_l2', 'parameter_l2', 'gradient_over_parameter_l2')}
        result['actual_parameter_updates'][group] = {
            key: distribution(row['update_statistics']['actual_parameter_update'][group][key]
                for row in records if row['update_statistics']['actual_parameter_update'][group][key] is not None)
            for key in ('update_l2', 'parameter_l2_before', 'relative_update_l2')}
    return result


def _save_model(path, model, plan, stage, clip_value, completed, source):
    import torch
    temporary = path.with_name('.'+path.name+'.'+str(os.getpid()))
    try:
        value = {'format': SCHEMA, 'training_ready': False, 'production_resume_allowed': False,
                 'plan_identity': plan['identity'], 'stage': stage, 'clip_value': clip_value,
                 'completed_updates': completed, 'source': source,
                 'model_config': model.model.config.to_dict(),
                 'species_embed_scale': model.scale,
                 'state_dict': {name: tensor.detach().cpu() for name,tensor in model.state_dict().items()},
                 'scope': 'Disposable clipping ablation model; no production optimizer or stream state'}
        torch.save(value, temporary)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}


def run(args):
    import torch
    import torch.distributed as dist
    from torch.nn.parallel import DistributedDataParallel
    from execution_profile import assert_profile
    from finite_pipeline import FinitePipeline
    from epoch_evaluation import quick_host_probe
    plan = json.loads(args.plan.read_text())
    validate_plan_identity(plan)
    if args.stage not in (0, 3) or args.updates != 128:
        raise ValueError('This matched experiment requires stage 0 or 3 and exactly 128 updates')
    clip_value = parse_clip(args.clip)
    if clip_value not in (None, .5, 1.):
        raise ValueError('This matched experiment compares only 0.5, 1.0 and none')
    spec = stage_spec(plan, args.stage)
    protocol = branch_protocol(plan, args.stage, args.updates)
    device, rank, versions, hosts = initialize()
    output = args.output.resolve()
    prepared = False
    pipeline = None
    records = []
    report = {'schema': SCHEMA, 'status': 'FAILED', 'training_ready': False,
              'production_resume_allowed': False, 'plan_identity': plan['identity'],
              'stage': args.stage, 'max_length': spec['max_length'], 'clip_value': clip_value,
              'requested_updates': args.updates, 'completed_updates': 0,
              'batch_trace_sha256': hashlib.sha256().hexdigest(),
              'started_utc': datetime.now(timezone.utc).isoformat(),
              'data_protocol': protocol, 'data_protocol_identity': canonical_hash(protocol),
              'update_program_sha256': sha(Path(__file__).with_name('production_update.py')),
              'runtime_versions': versions, 'topology': hosts,
              'limitations': ['128 updates from a common source are not a full-training optimum test.',
                  'Global clipping scales the joint gradient; it does not directly select species gradients.',
                  'AdamW moments can change parameter update effects, so actual weight deltas are reported.',
                  'Constant preflight learning rates are used; production warmup/decay is not tested here.',
                  'Twelve held-out records are a diagnostic, not a biological benchmark.']}
    try:
        def prepare():
            if output.exists() and any(output.iterdir()):
                raise FileExistsError('Refusing to overwrite clipping experiment: '+str(output))
            output.mkdir(parents=True, exist_ok=True)
        rank0_action(prepare)
        prepared = True
        actual = rank0_action(lambda: sha(plan['source']['checkpoint']))
        if actual != SOURCE_CHECKPOINT_SHA256:
            raise ValueError('Source checkpoint does not match the reviewed model')
        model, tokenizer, source = load_source(plan, device, verify_checkpoint_hash=False)
        if any(item != source for item in gather(source)):
            raise ValueError('Ranks loaded different source provenance')
        report['source'] = source
        optimizer, _ = new_optimizer(model)
        if optimizer.state:
            raise ValueError('Clipping experiment requires fresh optimizer state')
        ddp = DistributedDataParallel(model, device_ids=[device.index],
            find_unused_parameters=True, static_graph=False, broadcast_buffers=False)
        policy = ddp_policy(ddp)
        report['ddp_policy'] = policy
        pipeline = FinitePipeline(plan, args.stage, rank)
        workers = list(pipeline.worker_pids.values())
        if len(workers) != spec['num_workers'] or len(set(workers)) != len(workers) or any(pid <= 0 for pid in workers):
            raise RuntimeError('Unexpected preprocessing worker count')
        report['workers'] = gather({'rank': rank, 'num_workers': len(workers), 'worker_pids': workers})
        report['host_probe_before'] = rank0_action(lambda: quick_host_probe(model, tokenizer, plan, args.stage, max_records=12))
        require_probe(report['host_probe_before'])
        collator = CandidateCollator(tokenizer, seed=int(plan['seed']), rank=rank, stage=args.stage)
        seed_all(int(plan['seed']) + 100003 * args.stage + rank)
        torch.cuda.reset_peak_memory_stats(device)
        trace = hashlib.sha256()
        for update in range(args.updates):
            started = time.monotonic()
            raw_batches = [pipeline.next_batch() for _ in range(spec['accumulation'])]
            batches = [collator(rows, spec['max_length'], spec['full_mask_probability'], update, micro)
                       for micro, rows in enumerate(raw_batches)]
            observations = gather({'rank': rank, 'batch_sha256': batch_digest(raw_batches, batches)})
            global_batch_sha = canonical_hash(observations)
            report['pending_batch_sha256'] = global_batch_sha
            del raw_batches
            metrics, norm, factor, local_targets, details = optimizer_update(
                ddp, optimizer, batches, device, spec['learning_rate_preflight'], clip_value,
                measure_update=True)
            del batches
            rank_targets = gather({'rank': rank, 'targets': local_targets})
            if sum(item['targets'] for item in rank_targets) != int(metrics[1]+metrics[3]):
                raise RuntimeError('Ablation targets differ from the global loss denominator')
            assert_profile(model)
            if ddp_policy(ddp) != policy:
                raise RuntimeError('DDP policy changed during clipping experiment')
            trace.update(global_batch_sha.encode())
            row = {'update': update+1, 'global_batch_sha256': global_batch_sha,
                   'global_targets': int(metrics[1]+metrics[3]),
                   'global_ce': (metrics[0]+metrics[2])/(metrics[1]+metrics[3]),
                   'partial_ce': metrics[0]/metrics[1] if metrics[1] else None,
                   'full_ce': metrics[2]/metrics[3] if metrics[3] else None,
                   'partial_targets': int(metrics[1]), 'full_targets': int(metrics[3]),
                   'real_windows': int(metrics[4]), 'physical_records': int(metrics[8]),
                   'preclip_norm': norm, 'clipping_factor': factor,
                   'update_statistics': details, 'update_seconds': time.monotonic()-started}
            records.append(row)
            report['completed_updates'] = update+1
            report['batch_trace_sha256'] = trace.hexdigest()
            report.pop('pending_batch_sha256', None)
            if rank == 0 and ((update+1) % 16 == 0 or update == 0):
                print('CT2_CLIPPING_PROGRESS '+json.dumps({k:row[k] for k in ('update','global_ce','preclip_norm','clipping_factor')}) ,flush=True)
        report['host_probe_after'] = rank0_action(lambda: quick_host_probe(model, tokenizer, plan, args.stage, max_records=12))
        require_probe(report['host_probe_after'])
        for key in ('panel_sha256', 'selected_identity_sha256', 'length'):
            if report['host_probe_before'][key] != report['host_probe_after'][key]:
                raise ValueError('The before/after host probe changed its fixed cohort')
        report['model_checkpoint'] = rank0_action(lambda: _save_model(output/'final_model.ckpt',
            model, plan, args.stage, clip_value, args.updates, source))
        report['memory'] = gather({'rank': rank, 'peak_allocated_bytes': torch.cuda.max_memory_allocated(device),
                                  'peak_reserved_bytes': torch.cuda.max_memory_reserved(device)})
        report['status'] = 'HEALTHY_FINISHED'
    except FloatingPointError as error:
        report.update(status='UNHEALTHY', error=type(error).__name__+': '+str(error))
    except Exception as error:
        # rank0_action broadcasts the text of a root-only host-probe exception.
        unhealthy = 'FloatingPointError:' in str(error)
        report.update(status='UNHEALTHY' if unhealthy else 'FAILED', error=type(error).__name__+': '+str(error))
    finally:
        if pipeline is not None:
            pipeline.close()
        report['updates'] = records
        report['summary'] = summarize(records)
        report['finished_utc'] = datetime.now(timezone.utc).isoformat()
        if prepared and rank == 0:
            atomic_json(output/'ablation_report.json', report)
            print('CT2_CLIPPING_STATUS='+report['status'], flush=True)
    return 0 if report['status'] in {'HEALTHY_FINISHED', 'UNHEALTHY'} else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--stage', type=int, choices=(0,3), required=True)
    parser.add_argument('--clip', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--updates', type=int, default=128)
    args = parser.parse_args(argv)
    try:
        return run(args)
    except Exception as error:
        print('CT2_CLIPPING_FAILED '+type(error).__name__+': '+str(error), file=sys.stderr, flush=True)
        return 1
    finally:
        import torch.distributed as dist
        if dist.is_available() and dist.is_initialized():
            dist.destroy_process_group()


if __name__ == '__main__':
    raise SystemExit(main())
