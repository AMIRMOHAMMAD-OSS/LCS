#!/usr/bin/env python3
"""Import the reviewed source weights and check a tiny CPU forward before queuing GPUs."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

from candidate_model import load_source, new_optimizer, runtime_versions, validate_plan_identity
from gpu_preflight import atomic_json


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    report = {'status': 'FAIL', 'training_ready': False, 'cuda_used': False,
              'scope': 'Source identity, strict weight import, fresh optimizer and tiny CPU forward only.'}
    try:
        import torch
        plan = json.loads(args.plan.read_text())
        validate_plan_identity(plan)
        versions = runtime_versions()
        torch.set_num_threads(2)
        from execution_profile import configure
        configure(require_workspace=False)
        model, tokenizer, provenance = load_source(plan, 'cpu', verify_checkpoint_hash=True)
        optimizer, names = new_optimizer(model)
        if optimizer.state or optimizer.state_dict()['state']:
            raise RuntimeError('Weights-only import unexpectedly initialized historical optimizer moments')
        vocab = tokenizer.get_vocab()
        ids = torch.tensor([[tokenizer.cls_token_id, vocab['m_unk'], vocab['a_unk'],
                             vocab['__unk'], tokenizer.sep_token_id]] * 2)
        model.eval()
        with torch.no_grad():
            logits = model(ids, torch.ones_like(ids), torch.tensor([0, 26678]))
        if tuple(logits.shape) != (2, 5, 90) or not torch.isfinite(logits).all():
            raise RuntimeError('Tiny CPU forward has an invalid shape or nonfinite outputs')
        if any(parameter.device.type != 'cpu' for parameter in model.parameters()):
            raise RuntimeError('The CPU import probe unexpectedly used a different device')
        report.update(status='CPU_MODEL_IMPORT_PASS', plan_identity=plan['identity'],
                      source=provenance, runtime_versions=versions,
                      model_parameter_count=sum(p.numel() for p in model.parameters()),
                      optimizer_groups=[{'parameter_tensors': len(group['params']),
                                         'weight_decay': group['weight_decay'],
                                         'betas': list(group['betas']), 'eps': group['eps']}
                                        for group in optimizer.param_groups],
                      optimizer_parameter_names_sha256=hashlib.sha256(json.dumps(names).encode()).hexdigest(),
                      fresh_optimizer_state_entries=0, forward_shape=list(logits.shape),
                      padding_policy='fixed_stage_max_length')
    except Exception as error:
        report['error'] = type(error).__name__ + ': ' + str(error)
    atomic_json(args.output, report)
    print('CPU_MODEL_PROBE=' + report['status'])
    print('TRAINING_READY=false')
    return 0 if report['status'] == 'CPU_MODEL_IMPORT_PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
