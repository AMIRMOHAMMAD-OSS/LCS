#!/usr/bin/env python3
"""Compare full finite-loader GPU preflight checkpoints; never clear production."""
from __future__ import annotations

import argparse
from collections.abc import Mapping
from datetime import datetime, timezone
import gc
import json
import math
import numbers
import os
from pathlib import Path
import re
import tempfile

FORMAT = 'ct2-finite-preflight-v1'
RTOL, ATOL = 1e-5, 2e-6
AUDITED_BUCKET_BYTES = [103443816, 30680064, 29500416, 30680064, 29500416,
                       30680064, 29500416, 30680064, 29500416, 30680064,
                       29500416, 30680064, 29500416, 30680064, 29500416, 7357440]
REQUIRED = {
    'format', 'plan_identity', 'stage', 'branch', 'completed_updates', 'source',
    'world_size', 'state_dict', 'model_config', 'species_embed_scale',
    'optimizer_state', 'optimizer_parameter_names', 'rank_states',
    'execution_settings', 'ddp_policy', 'statistics', 'padding_policy', 'runtime_versions',
}
OBSERVATIONAL_TOP = {
    'created_utc', 'started_utc', 'finished_utc', 'timestamp', 'job_id',
    'elapsed_seconds', 'active_seconds', 'hardware_observations',
}
OBSERVATIONAL_STATS = {
    'active_seconds', 'elapsed_seconds', 'update_seconds', 'peak_allocated_bytes',
    'peak_reserved_bytes', 'timing', 'timings',
}
EXACT_FIELDS = ('format', 'plan_identity', 'stage', 'source', 'world_size',
                'model_config', 'species_embed_scale', 'optimizer_parameter_names',
                'execution_settings', 'ddp_policy', 'completed_updates', 'padding_policy', 'runtime_versions')
COUNT_INDEXES = (1, 3, 4, 5, 6, 7)


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as handle:
            json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write('\n'); handle.flush(); os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        Path(tmp).unlink(missing_ok=True)


def validate_header(checkpoint, updates, branch):
    if not isinstance(checkpoint, Mapping):
        raise ValueError('Checkpoint must be a mapping')
    missing = REQUIRED - set(checkpoint)
    if missing:
        raise ValueError('Missing checkpoint fields: ' + ', '.join(sorted(missing)))
    if checkpoint['format'] != FORMAT:
        raise ValueError('Only isolated finite-preflight checkpoints may be compared')
    if checkpoint['branch'] != branch:
        raise ValueError(f'Expected branch {branch!r}, got {checkpoint["branch"]!r}')
    if type(checkpoint['completed_updates']) is not int or checkpoint['completed_updates'] != updates:
        raise ValueError(f'Expected {updates} completed fresh-optimizer updates')
    if type(checkpoint['world_size']) is not int or checkpoint['world_size'] != 8:
        raise ValueError('Preflight requires eight ranks')
    if type(checkpoint['stage']) is not int or checkpoint['stage'] not in range(4):
        raise ValueError('Stage must be an integer in 0..3')
    if not re.fullmatch(r'[a-f0-9]{64}', str(checkpoint['plan_identity'])):
        raise ValueError('Missing canonical plan identity')
    source = checkpoint['source']
    if not isinstance(source, Mapping) or not re.fullmatch(r'[a-f0-9]{64}', str(source.get('checkpoint_sha256', ''))):
        raise ValueError('Missing original checkpoint provenance')
    if not isinstance(checkpoint['model_config'], Mapping) or not checkpoint['model_config']:
        raise ValueError('Missing complete model configuration')
    scale = checkpoint['species_embed_scale']
    if isinstance(scale, bool) or not isinstance(scale, numbers.Real) or not math.isfinite(scale) or not math.isclose(scale, .0347, rel_tol=0, abs_tol=1e-12):
        raise ValueError('Unexpected species embedding scale')
    ranks = checkpoint['rank_states']
    if not isinstance(ranks, list) or len(ranks) != 8:
        raise ValueError('Expected all eight rank states')
    for expected_rank, state in enumerate(ranks):
        if not isinstance(state, Mapping) or type(state.get('rank')) is not int or state['rank'] != expected_rank:
            raise ValueError('Rank states must be complete and ordered')
        if not isinstance(state.get('stream'), Mapping):
            raise ValueError('Missing committed finite-stream state')
        if not isinstance(state.get('rng'), Mapping) or set(state['rng']) != {'python', 'numpy', 'torch', 'cuda'}:
            raise ValueError('Incomplete rank RNG snapshot')
    statistics = checkpoint['statistics']
    if not isinstance(statistics, Mapping) or len(statistics.get('totals', [])) != 8:
        raise ValueError('Missing eight accumulated loss/count totals')
    if len(statistics.get('grad_norms', [])) != updates:
        raise ValueError('Gradient history must include every completed update')
    for index in COUNT_INDEXES:
        value = statistics['totals'][index]
        if isinstance(value, bool) or not isinstance(value, numbers.Real) or not math.isfinite(value) or value < 0 or value != int(value):
            raise ValueError('Invalid accumulated count at statistics.totals[' + str(index) + ']')
    for field in ('state_dict', 'optimizer_state', 'execution_settings', 'ddp_policy'):
        if not isinstance(checkpoint[field], Mapping) or not checkpoint[field]:
            raise ValueError('Missing ' + field)
    expected_policy = {'find_unused_parameters': True, 'static_graph': False,
                       'broadcast_buffers': False, 'ordered_bucket_bytes': AUDITED_BUCKET_BYTES}
    if checkpoint['ddp_policy'] != expected_policy:
        raise ValueError('The audited fixed-bucket DDP policy was not observed')
    if checkpoint['padding_policy'] != 'fixed_stage_max_length':
        raise ValueError('The preflight must exercise fixed maximum-length padding')
    versions = checkpoint['runtime_versions']
    if not isinstance(versions, Mapping) or str(versions.get('torch', '')).split('+')[0] != '2.6.0' or versions.get('transformers') != '4.51.3':
        raise ValueError('Unexpected Torch/Transformers versions')


class Comparison:
    """Complete traversal, bounded diagnostics, exact differences separate from failures."""
    def __init__(self, torch_module=None):
        self.torch = torch_module
        try:
            import numpy
        except ImportError:
            numpy = None
        self.numpy = numpy
        self.counters = dict(tensors_compared=0, tensor_exact_mismatches=0,
                             tensor_tolerance_failures=0, numpy_exact_mismatches=0,
                             numeric_exact_mismatches=0, numeric_tolerance_failures=0,
                             metadata_mismatches=0, nonfinite_values=0)
        self.examples = []
        self.max_finite_abs = 0.0

    def event(self, kind, path, detail):
        self.counters[kind] += 1
        if len(self.examples) < 100:
            self.examples.append({'kind': kind, 'path': path, 'detail': str(detail)[:1200]})

    def tensor(self, value):
        return self.torch is not None and self.torch.is_tensor(value)

    def array(self, value):
        return self.numpy is not None and isinstance(value, self.numpy.ndarray)

    def health(self, value, path):
        if self.tensor(value):
            if (value.is_floating_point() or value.is_complex()) and not bool(self.torch.isfinite(value).all()):
                self.event('nonfinite_values', path, 'Tensor contains a nonfinite value')
        elif self.array(value):
            if value.dtype.kind in 'fc' and not bool(self.numpy.isfinite(value).all()):
                self.event('nonfinite_values', path, 'NumPy array contains a nonfinite value')
        elif isinstance(value, Mapping):
            for key, child in value.items(): self.health(child, path + '.' + str(key))
        elif isinstance(value, (list, tuple)):
            for index, child in enumerate(value): self.health(child, path + '[' + str(index) + ']')
        elif isinstance(value, numbers.Real) and not isinstance(value, (bool, numbers.Integral)):
            if not math.isfinite(value): self.event('nonfinite_values', path, 'Nonfinite scalar')

    def compare(self, a, b, *, close=False, path='root'):
        if self.tensor(a) or self.tensor(b):
            if not (self.tensor(a) and self.tensor(b)):
                self.event('metadata_mismatches', path, 'Tensor/non-tensor mismatch'); return
            self.counters['tensors_compared'] += 1
            if a.shape != b.shape or a.dtype != b.dtype or a.layout != b.layout:
                self.event('metadata_mismatches', path, 'Tensor shape, dtype or layout differs'); return
            if self.torch.equal(a, b): return
            self.event('tensor_exact_mismatches', path, 'Tensor values are not exactly equal')
            if a.is_floating_point() or a.is_complex():
                if a.numel():
                    finite = self.torch.isfinite(a) & self.torch.isfinite(b)
                    if bool(finite.any()):
                        maximum = float((a[finite].to(self.torch.float64) - b[finite].to(self.torch.float64)).abs().max())
                        self.max_finite_abs = max(self.max_finite_abs, maximum)
                if close:
                    try:
                        self.torch.testing.assert_close(a, b, rtol=RTOL, atol=ATOL, equal_nan=False)
                        return
                    except AssertionError as error:
                        self.event('tensor_tolerance_failures', path, error); return
            self.event('tensor_tolerance_failures', path, 'Exact equality required')
            return
        if self.array(a) or self.array(b):
            if not (self.array(a) and self.array(b)) or a.shape != b.shape or a.dtype != b.dtype:
                self.event('metadata_mismatches', path, 'NumPy type/shape/dtype mismatch'); return
            if not self.numpy.array_equal(a, b):
                self.event('numpy_exact_mismatches', path, 'Exact NumPy equality required')
            return
        if isinstance(a, Mapping) or isinstance(b, Mapping):
            if not (isinstance(a, Mapping) and isinstance(b, Mapping)):
                self.event('metadata_mismatches', path, 'Mapping/non-mapping mismatch'); return
            if set(a) != set(b): self.event('metadata_mismatches', path, 'Mapping keys differ')
            for key in a.keys() & b.keys(): self.compare(a[key], b[key], close=close, path=path + '.' + str(key))
            return
        if isinstance(a, (list, tuple)) or isinstance(b, (list, tuple)):
            if type(a) is not type(b) or len(a) != len(b):
                self.event('metadata_mismatches', path, 'Sequence type or length differs'); return
            for index, (x, y) in enumerate(zip(a, b)):
                self.compare(x, y, close=close, path=path + '[' + str(index) + ']')
            return
        if isinstance(a, numbers.Real) and isinstance(b, numbers.Real) and not isinstance(a, bool) and not isinstance(b, bool):
            if a == b: return
            self.event('numeric_exact_mismatches', path, 'Numeric scalar values differ')
            if close and not (isinstance(a, numbers.Integral) or isinstance(b, numbers.Integral)):
                if math.isfinite(a) and math.isfinite(b) and abs(a - b) <= ATOL + RTOL * abs(b): return
            self.event('numeric_tolerance_failures', path, 'Exact or numeric tolerance comparison failed')
            return
        if type(a) is not type(b) or a != b:
            self.event('metadata_mismatches', path, 'Scalar metadata differs')

    def result(self):
        failures = ('tensor_tolerance_failures', 'numpy_exact_mismatches',
                    'numeric_tolerance_failures', 'metadata_mismatches', 'nonfinite_values')
        passed = all(self.counters[key] == 0 for key in failures)
        exact_keys = ('tensor_exact_mismatches', 'numpy_exact_mismatches', 'numeric_exact_mismatches', 'metadata_mismatches', 'nonfinite_values')
        return dict(status='PASS' if passed else 'FAIL', exact_equality=all(self.counters[key] == 0 for key in exact_keys),
                    counts=self.counters, max_finite_abs=self.max_finite_abs, examples=self.examples,
                    examples_truncated=sum(v for k, v in self.counters.items() if k != 'tensors_compared') > len(self.examples))


def validate_tensor_state(checkpoint, torch_module):
    if not checkpoint['state_dict'] or not all(torch_module.is_tensor(x) for x in checkpoint['state_dict'].values()):
        raise ValueError('Model state must contain tensors')
    optimizer = checkpoint['optimizer_state']
    if set(optimizer) != {'state', 'param_groups'} or not isinstance(optimizer['state'], Mapping):
        raise ValueError('Unexpected optimizer state schema')
    names, groups = checkpoint['optimizer_parameter_names'], optimizer['param_groups']
    if not isinstance(names, list) or len(names) != 2 or not isinstance(groups, list) or len(groups) != 2:
        raise ValueError('Expected backbone and species AdamW parameter groups')
    ids = []
    for group, group_names in zip(groups, names):
        if len(group.get('params', [])) != len(group_names): raise ValueError('Optimizer names/group size mismatch')
        if tuple(group.get('betas', ())) != (.9, .999) or group.get('eps') != 1e-8 or group.get('amsgrad', False):
            raise ValueError('Unexpected AdamW settings')
        ids.extend(group['params'])
        for name in group_names:
            if name not in checkpoint['state_dict']: raise ValueError('Optimizer name absent from model state: ' + name)
    if len(ids) != len(set(ids)) or set(ids) != set(optimizer['state']):
        raise ValueError('Optimizer state must cover every parameter once')
    if groups[0].get('weight_decay') != .01 or groups[1].get('weight_decay') != 0.:
        raise ValueError('Unexpected AdamW decay groups')
    for identifier, name in zip(ids, [n for group in names for n in group]):
        state, weight = optimizer['state'][identifier], checkpoint['state_dict'][name]
        if set(state) != {'step', 'exp_avg', 'exp_avg_sq'}: raise ValueError('Unexpected AdamW moment schema')
        step = state['step']
        if not torch_module.is_tensor(step) or step.numel() != 1 or float(step) != checkpoint['completed_updates']:
            raise ValueError('AdamW age differs from completed fresh-optimizer updates')
        for moment in ('exp_avg', 'exp_avg_sq'):
            if not torch_module.is_tensor(state[moment]) or state[moment].shape != weight.shape:
                raise ValueError('Invalid AdamW moment shape')
    for rank_state in checkpoint['rank_states']:
        for kind in ('torch', 'cuda'):
            rng = rank_state['rng'][kind]
            if not torch_module.is_tensor(rng) or rng.dtype != torch_module.uint8 or rng.ndim != 1 or not rng.numel():
                raise ValueError('Incomplete ' + kind + ' RNG snapshot')


def compare_pair(a, b, *, updates, second_branch, torch_module=None):
    validate_header(a, updates, 'reference'); validate_header(b, updates, second_branch)
    if torch_module is not None:
        validate_tensor_state(a, torch_module); validate_tensor_state(b, torch_module)
    result = Comparison(torch_module)
    result.health(a, 'reference'); result.health(b, second_branch)
    for field in EXACT_FIELDS: result.compare(a[field], b[field], path=field)
    result.compare(a['rank_states'], b['rank_states'], path='rank_states')
    for field in ('state_dict', 'optimizer_state'):
        result.compare(a[field], b[field], close=True, path=field)
    sa, sb = a['statistics'], b['statistics']
    result.compare([sa['totals'][i] for i in COUNT_INDEXES], [sb['totals'][i] for i in COUNT_INDEXES], path='statistics.count_totals')
    result.compare([sa['totals'][i] for i in (0, 2)], [sb['totals'][i] for i in (0, 2)], close=True, path='statistics.loss_totals')
    result.compare(sa['grad_norms'], sb['grad_norms'], close=True, path='statistics.grad_norms')
    extra_stats_a = {k: v for k, v in sa.items() if k not in OBSERVATIONAL_STATS | {'totals', 'grad_norms'}}
    extra_stats_b = {k: v for k, v in sb.items() if k not in OBSERVATIONAL_STATS | {'totals', 'grad_norms'}}
    result.compare(extra_stats_a, extra_stats_b, close=True, path='statistics.extra')
    result.compare({k: v for k, v in a.items() if k not in REQUIRED | OBSERVATIONAL_TOP},
                   {k: v for k, v in b.items() if k not in REQUIRED | OBSERVATIONAL_TOP}, path='extra_checkpoint_metadata')
    answer = result.result()
    answer.update(completed_updates=updates, reference_branch='reference', compared_branch=second_branch,
                  excluded_top_level_fields=sorted((set(a) | set(b)) & OBSERVATIONAL_TOP),
                  excluded_statistics_fields=sorted((set(sa) | set(sb)) & OBSERVATIONAL_STATS))
    return answer


def run_comparisons(paths, output):
    report = dict(schema='ct2-finite-preflight-comparison-v1', status='FAIL', training_ready=False,
                  created_utc=datetime.now(timezone.utc).isoformat(),
                  tolerance={'rtol': RTOL, 'atol': ATOL, 'formula': 'abs(reference-resumed) <= atol + rtol*abs(resumed)'},
                  inputs={k: str(Path(v).resolve()) for k, v in paths.items()}, pairs={}, errors=[],
                  scope='Short instrumented replay only. Does not authorize production or validate the complete curriculum.')
    try:
        import torch
        shared = None
        for updates, ref_key, second_key, branch in ((16, 'reference16', 'split16', 'split'), (32, 'reference32', 'resumed32', 'resume')):
            a = torch.load(paths[ref_key], map_location='cpu', weights_only=False, mmap=True)
            b = torch.load(paths[second_key], map_location='cpu', weights_only=False, mmap=True)
            report['pairs'][str(updates)] = compare_pair(a, b, updates=updates, second_branch=branch, torch_module=torch)
            identity = {key: a[key] for key in ('plan_identity', 'stage', 'source', 'model_config', 'species_embed_scale', 'execution_settings', 'ddp_policy', 'padding_policy', 'runtime_versions')}
            if shared is None:
                shared = identity
                report.update(plan_identity=shared['plan_identity'], stage=shared['stage'],
                              source_checkpoint_sha256=shared['source']['checkpoint_sha256'])
            else:
                cross = Comparison(torch)
                cross.compare(shared, identity, path='cross_update_identity')
                report['cross_update_identity'] = cross.result()
            del a, b; gc.collect()
        if all(pair['status'] == 'PASS' for pair in report['pairs'].values()) and report.get('cross_update_identity', {}).get('status') == 'PASS':
            report['status'] = 'PASS'
        report['exact_equality'] = report['status'] == 'PASS' and all(pair['exact_equality'] for pair in report['pairs'].values())
    except Exception as error:
        report['errors'].append({'type': type(error).__name__, 'message': str(error)[:3000]})
    atomic_json(output, report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('reference16', 'split16', 'reference32', 'resumed32'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    report = run_comparisons({name: getattr(args, name) for name in ('reference16', 'split16', 'reference32', 'resumed32')}, args.output)
    print('PREFLIGHT_COMPARISON=' + report['status'])
    print('TRAINING_READY=false')
    print('COMPARISON_REPORT=' + str(args.output.resolve()))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
