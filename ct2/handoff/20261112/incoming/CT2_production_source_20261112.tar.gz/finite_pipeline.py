"""Finite, explicitly ordered multiprocessing CT2 window pipeline.

Workers may read ahead, but only batch cursors accepted by the parent enter a
checkpoint. Restoring a cursor reconstructs the deterministic record shuffle of
at most the current compressed shard in each lane. No Torch dependency.
"""
from __future__ import annotations

from bisect import bisect_left
from collections import deque
import copy
import gzip
import hashlib
import json
import multiprocessing as mp
from pathlib import Path
import queue
import random
import tarfile

from census import EXPECTED_POLICY, HashingReader, MAX_JSON_BYTES, Policy, digest, snapshot

STATE_SCHEMA = 'ct2-finite-stream-state-v1'


def _check_plan(plan):
    from finite_plan import validate_plan
    validate_plan(plan)
    if plan.get('schema') != 'ct2-finite-plan-v1':
        raise ValueError('Unsupported finite data plan')
    if plan.get('identity') != digest({k: v for k, v in plan.items() if k != 'identity'}):
        raise ValueError('Finite data plan identity mismatch')
    if plan.get('source_policy_hashes') != EXPECTED_POLICY:
        raise ValueError('Finite data plan has a different token/species policy')


def _raw_records(path, row):
    """Verify the declared compressed object while streaming its JSON members."""
    expected = {k: row[k] for k in ('name', 'bytes', 'mtime_ns')}
    if snapshot(path) != expected:
        raise RuntimeError('Shard metadata changed: ' + str(path))
    seen = set()
    with Path(path).open('rb') as handle:
        hashed = HashingReader(handle)
        with gzip.GzipFile(fileobj=hashed, mode='rb') as uncompressed:
            with tarfile.open(fileobj=uncompressed, mode='r|') as archive:
                for member in archive:
                    if not member.isfile() or not member.name.endswith('.json'):
                        continue
                    if member.name in seen:
                        raise ValueError('Duplicate JSON member: ' + member.name)
                    seen.add(member.name)
                    if member.size > MAX_JSON_BYTES:
                        raise ValueError('Oversized JSON member: ' + member.name)
                    raw = archive.extractfile(member)
                    if raw is None:
                        raise ValueError('Unreadable JSON member: ' + member.name)
                    doc = json.loads(raw.read())
                    if not isinstance(doc, dict):
                        raise ValueError('Training JSON member must be an object')
                    yield member.name, doc
            while uncompressed.read(1024 * 1024):
                pass
        while hashed.read(1024 * 1024):
            pass
    if not seen:
        raise ValueError('Shard contains no JSON records: ' + str(path))
    if (snapshot(path) != expected or hashed.bytes_read != row['bytes']
            or hashed.hasher.hexdigest() != row['compressed_sha256']):
        raise RuntimeError('Shard content or metadata changed: ' + str(path))


def _shuffled_records(path, row, seed, buffer_size):
    """Bounded record shuffle, deliberately drained/reset at each shard."""
    rng = random.Random(seed)
    source = _raw_records(path, row)
    buffer = []
    try:
        for _ in range(buffer_size):
            try:
                buffer.append(next(source))
            except StopIteration:
                break
        source_ended = False
        while buffer:
            index = rng.randrange(len(buffer))
            result = buffer[index]
            if not source_ended:
                try:
                    buffer[index] = next(source)
                except StopIteration:
                    source_ended = True
                    buffer.pop(index)
            else:
                buffer.pop(index)
            yield result
    finally:
        source.close()


def _shard_windows(plan, stage_index, shard_id, policy):
    stage = plan['stages'][stage_index]
    row = plan['shards'][shard_id]
    capacity = stage['max_length'] - 2
    expected = row['by_length'][str(stage['max_length'])]
    seed_text = f"finite-record-shuffle:{plan['seed']}:{stage_index}:{shard_id}"
    seed = int.from_bytes(hashlib.sha256(seed_text.encode()).digest()[:8], 'big')
    counts = dict(windows=0, records=0, known_targets=0)
    source = _shuffled_records(Path(plan['data_root']) / row['name'], row,
                               seed, plan.get('shuffle_buffer', 1024))
    try:
        for key, doc in source:
            sid = policy.common.resolve_species(doc.get('species'), policy.mapping, policy.n_real)
            dna = doc.get('dna_sequence') or doc.get('seq') or doc.get('dna') or doc.get('sequence')
            try:
                prepared = policy.token.prepare_sequence(dna, doc.get('protein_sequence'), policy.vocab)
                policy.token.require_supervision(prepared, None)
            except policy.token.RecordRejected:
                continue
            token_ids = [policy.vocab[token] for token in prepared.text.split()]
            target_positions = prepared.target_positions
            target_windows = sorted({position // capacity for position in target_positions})
            counts['records'] += 1
            for ordinal, window in enumerate(target_windows):
                start = window * capacity
                end = min(len(token_ids), start + capacity)
                targets = bisect_left(target_positions, end) - bisect_left(target_positions, start)
                if targets <= 0:
                    raise RuntimeError('Target-free window entered finite stream')
                counts['windows'] += 1
                counts['known_targets'] += targets
                yield dict(token_ids=token_ids[start:end], species_id=sid,
                           identity=f'{stage_index}:{shard_id}:{key}:{start}:{end}',
                           record_first=ordinal == 0, known_targets=targets,
                           shard_id=shard_id, sequence_positions=end-start,
                           amino_acid_positions=max(0, min(end, len(token_ids)-1)-start))
    finally:
        source.close()
    if counts != {k: expected[k] for k in counts}:
        raise RuntimeError(f'Shard window counts differ from census: {row["name"]}: {counts}')


def _lane_windows(plan, stage_index, lane, cursor, policy):
    shard_pos, skipped = cursor['shard_pos'], cursor['window_offset']
    for position in range(shard_pos, len(lane['shard_ids'])):
        shard_id = lane['shard_ids'][position]
        count = 0
        source = _shard_windows(plan, stage_index, shard_id, policy)
        try:
            for count, record in enumerate(source, 1):
                if position == shard_pos and count <= skipped:
                    continue
                yield record, dict(shard_pos=position, window_offset=count)
        finally:
            source.close()
        if position == shard_pos and count < skipped:
            raise RuntimeError('Saved window cursor exceeds shard output')


def _put(result_queue, stop, value):
    while not stop.is_set():
        try:
            result_queue.put(value, timeout=.25)
            return True
        except queue.Full:
            pass
    return False


def _worker(plan, stage_index, lane, repo, saved, result_queue, stop):
    source = None
    try:
        policy = Policy(repo)
        stage = plan['stages'][stage_index]
        micro = stage['batch_per_gpu']
        state = copy.deepcopy(saved)
        source = _lane_windows(plan, stage_index, lane, state['cursor'], policy)
        if state['committed_batches'] == lane['batches']:
            # Includes zero-window lanes. Exhausting the iterator validates any
            # assigned rejected-only shard before reporting a complete lane.
            try:
                next(source)
            except StopIteration:
                pass
            else:
                raise RuntimeError('Census-empty lane produced a training window')
            state['cursor'] = dict(shard_pos=len(lane['shard_ids']), window_offset=0)
            state['validated_complete'] = True
            _put(result_queue, stop, dict(kind='empty_complete', state=state))
            return
        for batch_index in range(state['committed_batches'], lane['batches']):
            if stop.is_set():
                return
            wanted = min(micro, lane['windows'] - state['committed_windows'])
            records = []
            for _ in range(wanted):
                try:
                    record, cursor = next(source)
                except StopIteration:
                    raise RuntimeError('Lane exhausted before its census window count') from None
                records.append(record)
                state['cursor'] = cursor
            state['committed_batches'] += 1
            state['committed_windows'] += len(records)
            state['committed_records'] += sum(r['record_first'] for r in records)
            state['committed_known_targets'] += sum(r['known_targets'] for r in records)
            if batch_index + 1 == lane['batches']:
                # Finish all gzip/hash/count checks before exposing the final
                # real batch to the training process.
                try:
                    next(source)
                except StopIteration:
                    pass
                else:
                    raise RuntimeError('Lane has more training windows than its census')
                if (state['committed_windows'] != lane['windows']
                        or state['committed_records'] != lane['records']
                        or state['committed_known_targets'] != lane['known_targets']):
                    raise RuntimeError('Lane totals differ from census')
                state['cursor'] = dict(shard_pos=len(lane['shard_ids']), window_offset=0)
                state['validated_complete'] = True
            if not _put(result_queue, stop, dict(kind='batch', records=records,
                                               state=copy.deepcopy(state))):
                return
    except BaseException as error:
        _put(result_queue, stop, dict(kind='error', error=type(error).__name__ + ': ' + str(error)[:2000]))
    finally:
        if source is not None:
            source.close()
        result_queue.close()
        result_queue.join_thread()


def _initial_lane_state(lane):
    return dict(worker=lane['worker'], committed_batches=0, committed_windows=0,
                committed_records=0, committed_known_targets=0,
                cursor=dict(shard_pos=0, window_offset=0), validated_complete=False)


class FinitePipeline:
    """One training rank's finite lanes, consumed in deterministic round robin."""

    def __init__(self, plan, stage_index, rank, repo=None, resume_state=None, prefetch=2):
        _check_plan(plan)
        if type(stage_index) is not int or not 0 <= stage_index < len(plan['stages']):
            raise ValueError('Invalid stage index')
        if type(prefetch) is not int or not 1 <= prefetch <= 8:
            raise ValueError('prefetch must be in 1..8')
        self.plan, self.stage_index, self.rank = plan, stage_index, rank
        self.stage = plan['stages'][stage_index]
        if type(rank) is not int or not 0 <= rank < plan['world_size']:
            raise ValueError('Invalid rank')
        self.repo = str(Path(repo or plan['source']['repo']).resolve())
        Policy(self.repo)  # Fail before starting children on policy drift.
        self.lanes = sorted((lane for lane in self.stage['lanes'] if lane['rank'] == rank),
                            key=lambda lane: lane['worker'])
        if [lane['worker'] for lane in self.lanes] != list(range(self.stage['num_workers'])):
            raise ValueError('Plan does not have the declared worker lanes')
        if resume_state is None:
            self.states = {lane['worker']: _initial_lane_state(lane) for lane in self.lanes}
            self.active = deque(lane['worker'] for lane in self.lanes if lane['batches'])
        else:
            self._restore(resume_state)
        self._context = mp.get_context('spawn')
        self._stop = self._context.Event()
        self._queues, self._processes = {}, {}
        self._empty_pending = []
        self.closed = False
        try:
            for lane in self.lanes:
                worker = lane['worker']
                state = self.states[worker]
                if state['validated_complete']:
                    continue
                channel = self._context.Queue(maxsize=prefetch)
                process = self._context.Process(target=_worker, name=f'ct2-r{rank}-w{worker}',
                    args=(plan, stage_index, lane, self.repo, state, channel, self._stop))
                process.start()
                self._queues[worker] = channel
                self._processes[worker] = process
                if state['committed_batches'] == lane['batches']:
                    self._empty_pending.append(worker)
        except BaseException:
            self.close()
            raise

    def _restore(self, saved):
        expected = dict(schema=STATE_SCHEMA, plan_identity=self.plan['identity'],
                        stage_index=self.stage_index, rank=self.rank,
                        world_size=self.plan['world_size'], num_workers=self.stage['num_workers'])
        if any(saved.get(k) != v for k, v in expected.items()):
            raise ValueError('Finite stream resume identity/geometry mismatch')
        rows = saved.get('lanes')
        if not isinstance(rows, list) or len(rows) != len(self.lanes):
            raise ValueError('Finite stream is missing lane states')
        self.states = {}
        for lane, row in zip(self.lanes, rows):
            row = copy.deepcopy(row)
            worker = lane['worker']
            if row.get('worker') != worker:
                raise ValueError('Finite stream lane order changed')
            for name in ('committed_batches', 'committed_windows', 'committed_records', 'committed_known_targets'):
                if type(row.get(name)) is not int or row[name] < 0:
                    raise ValueError('Invalid finite stream count: ' + name)
            n_batches = row['committed_batches']
            if (n_batches > lane['batches']
                    or row['committed_windows'] != min(n_batches*self.stage['batch_per_gpu'], lane['windows'])
                    or row['committed_records'] > lane['records']
                    or row['committed_known_targets'] > lane['known_targets']):
                raise ValueError('Finite stream counts disagree with its plan')
            cursor = row.get('cursor', {})
            pos, offset = cursor.get('shard_pos'), cursor.get('window_offset')
            if (type(pos) is not int or type(offset) is not int or pos < 0
                    or pos > len(lane['shard_ids']) or offset < 0):
                raise ValueError('Invalid finite shard cursor')
            length = str(self.stage['max_length'])
            preceding = sum(self.plan['shards'][i]['by_length'][length]['windows']
                            for i in lane['shard_ids'][:pos])
            if pos == len(lane['shard_ids']):
                if offset != 0:
                    raise ValueError('Exhausted lane has nonzero shard offset')
            elif offset > self.plan['shards'][lane['shard_ids'][pos]]['by_length'][length]['windows']:
                raise ValueError('Saved window offset exceeds shard')
            if preceding + offset != row['committed_windows']:
                raise ValueError('Finite cursor does not match committed window count')
            if type(row.get('validated_complete')) is not bool:
                raise ValueError('Missing lane completion marker')
            if row['validated_complete'] and (n_batches != lane['batches'] or pos != len(lane['shard_ids'])
                    or row['committed_records'] != lane['records']
                    or row['committed_known_targets'] != lane['known_targets']):
                raise ValueError('Invalid completed lane')
            self.states[worker] = row
        active = saved.get('next_active_lanes')
        required = {lane['worker'] for lane in self.lanes
                    if self.states[lane['worker']]['committed_batches'] < lane['batches']}
        if (not isinstance(active, list) or any(type(w) is not int for w in active)
                or len(set(active)) != len(active) or set(active) != required):
            raise ValueError('Finite stream active-lane schedule is invalid')
        self.active = deque(active)
        if saved.get('committed_batches') != sum(s['committed_batches'] for s in self.states.values()):
            raise ValueError('Rank batch counter does not match lanes')
        for key in ('committed_windows', 'committed_records', 'committed_known_targets'):
            if saved.get(key) != sum(s[key] for s in self.states.values()):
                raise ValueError('Rank count does not match lanes: ' + key)

    def _receive(self, worker):
        while True:
            try:
                message = self._queues[worker].get(timeout=1.)
                break
            except queue.Empty:
                if not self._processes[worker].is_alive():
                    raise RuntimeError(f'Finite data worker {worker} exited without a result; '
                                       f'exitcode={self._processes[worker].exitcode}')
        if message.get('kind') == 'error':
            raise RuntimeError(f'Finite data worker {worker}: {message["error"]}')
        return message

    def next_batch(self):
        if self.closed:
            raise RuntimeError('Finite pipeline is closed')
        for worker in self._empty_pending:
            message = self._receive(worker)
            if message.get('kind') != 'empty_complete' or not message['state']['validated_complete']:
                raise RuntimeError('Empty lane did not complete validation')
            self.states[worker] = message['state']
        self._empty_pending = []
        if not self.active:
            return []
        worker = self.active.popleft()
        message = self._receive(worker)
        if message.get('kind') != 'batch':
            raise RuntimeError('Expected a finite worker batch')
        previous, current = self.states[worker], message['state']
        records = message['records']
        if (current['committed_batches'] != previous['committed_batches'] + 1
                or current['committed_windows'] != previous['committed_windows'] + len(records)
                or not 0 < len(records) <= self.stage['batch_per_gpu']):
            raise RuntimeError('Finite worker skipped or duplicated a batch')
        self.states[worker] = current
        lane = self.lanes[worker]
        if current['committed_batches'] < lane['batches']:
            self.active.append(worker)
        elif not current['validated_complete']:
            raise RuntimeError('Final lane batch lacks completed integrity checks')
        return records

    def state_dict(self):
        states = [self.states[lane['worker']] for lane in self.lanes]
        return copy.deepcopy(dict(schema=STATE_SCHEMA, plan_identity=self.plan['identity'],
            stage_index=self.stage_index, rank=self.rank, world_size=self.plan['world_size'],
            num_workers=self.stage['num_workers'], next_active_lanes=list(self.active), lanes=states,
            committed_batches=sum(s['committed_batches'] for s in states),
            committed_windows=sum(s['committed_windows'] for s in states),
            committed_records=sum(s['committed_records'] for s in states),
            committed_known_targets=sum(s['committed_known_targets'] for s in states)))

    @property
    def worker_pids(self):
        return {worker: process.pid for worker, process in self._processes.items()}

    def close(self):
        if getattr(self, 'closed', True):
            return
        self.closed = True
        self._stop.set()
        for process in self._processes.values():
            process.join(timeout=1.)
            if process.is_alive():
                process.terminate()
                process.join(timeout=5.)
            if process.is_alive():
                process.kill()
                process.join(timeout=5.)
        for channel in self._queues.values():
            channel.close()
            channel.cancel_join_thread()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

