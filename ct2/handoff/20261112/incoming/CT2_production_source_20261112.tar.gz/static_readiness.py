#!/usr/bin/env python3
"""Read-only CT2 source integrity and implementation review; never a training gate.

Exit 0 means the source snapshot was intact and readable. The report may still
say REVIEW_REQUIRED with production blockers. Exit 1 means snapshot integrity
or required structure failed. No checkpoint or training shard contents are read.
"""
from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sys

DEFAULT_REPO = Path('/lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2/ct2_production_20260930_v4')
DEFAULT_EXPECTED = Path(__file__).resolve().with_name('expected_snapshot.json')
REQUIRED = ('run.json', 'common.py', 'train.py', 'preflight.py', 'checks.py',
            'model_io.py', 'engine.py', 'data_stream.py', 'augmentation.py',
            'source/species_to_id.json', 'source/CodonTransformerTokenizer.json')
SHA_PATTERN = re.compile(r'^[0-9a-f]{64}$')
MAX_SOURCE_BYTES = 16 * 1024 * 1024


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def strict_json(data):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('Duplicate JSON key: ' + str(key))
            result[key] = value
        return result

    def constant(value):
        raise ValueError('Nonfinite JSON number: ' + value)

    return json.loads(data, object_pairs_hook=pairs, parse_constant=constant)


def safe_relative(root, relative):
    relative = Path(relative)
    if relative.is_absolute() or '..' in relative.parts or not relative.parts:
        raise ValueError('Unsafe source-relative path: ' + str(relative))
    path = root / relative
    for component in [path, *path.parents]:
        if component == root.parent:
            break
        if component.is_symlink():
            raise ValueError('Symlinked source path: ' + str(relative))
    return path


def read_source(path):
    if not path.is_file():
        raise ValueError('Not a regular file')
    before = path.stat()
    if before.st_size > MAX_SOURCE_BYTES:
        raise ValueError('Source file exceeds bounded read limit')
    with path.open('rb') as handle:
        data = handle.read(MAX_SOURCE_BYTES + 1)
        after = os.fstat(handle.fileno())
    if len(data) > MAX_SOURCE_BYTES:
        raise ValueError('Source file grew beyond read limit')
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
        raise ValueError('Source changed during read')
    return data


def fingerprint(cfg):
    return sha_bytes(json.dumps({k: v for k, v in cfg.items() if k != 'fingerprint'}, sort_keys=True).encode())


def ddp_calls(tree):
    result = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = node.func.id if isinstance(node.func, ast.Name) else getattr(node.func, 'attr', None)
        if name != 'DistributedDataParallel':
            continue
        declared = {}
        for keyword in node.keywords:
            if keyword.arg in ('find_unused_parameters', 'static_graph', 'broadcast_buffers'):
                try:
                    declared[keyword.arg] = ast.literal_eval(keyword.value)
                except (ValueError, TypeError):
                    declared[keyword.arg] = 'dynamic_expression'
        result.append({'line': node.lineno, 'declared_flags': declared,
                       'audited_candidate_explicitly_installed': declared == {
                           'find_unused_parameters': True, 'static_graph': False, 'broadcast_buffers': False}})
    return result


def review(repo, expected, export_snapshot=False):
    repo = Path(repo).absolute()
    report = {'schema': 'ct2-static-review-v1', 'utc': datetime.now(timezone.utc).isoformat(),
              'repo': str(repo), 'scope': 'exported-source integrity and static inspection only',
              'export_snapshot_mode': bool(export_snapshot), 'training_ready': False,
              'snapshot_integrity_passed': False, 'production_integrity_passed': False,
              'errors': [], 'production_blockers': [], 'observations': [], 'files': [],
              'limitations': ['No GPU, model forward/backward, checkpoint tensor or data coverage validation was performed.',
                  'Exit 0 only permits further read-only preparation with this intact source snapshot; it is not authorization to train.',
                  'Static inspection does not certify runtime imports or numerical behavior.',
                  'Prior replay evidence cannot validate a changed source, worker pipeline, curriculum or initialization.']}
    errors = report['errors']
    if not isinstance(expected, dict) or expected.get('schema') != 'ct2-source-snapshot-v1' or not isinstance(expected.get('files'), dict):
        errors.append({'code': 'invalid_expected_snapshot', 'detail': 'Expected a ct2-source-snapshot-v1 file map'})
        report['status'] = 'SNAPSHOT_FAILED'
        return report
    expected_files = expected['files']
    report['expected_export'] = {k: expected.get(k) for k in ('export_filename', 'export_sha256')}
    source_bytes, trees, json_docs = {}, {}, {}
    for relative, wanted in expected_files.items():
        row = {'path': relative, 'expected_sha256': wanted}
        report['files'].append(row)
        try:
            if not isinstance(wanted, str) or not SHA_PATTERN.fullmatch(wanted):
                raise ValueError('Invalid expected SHA256')
            path = safe_relative(repo, relative)
            data = read_source(path)
            row['actual_sha256'] = sha_bytes(data)
            if row['actual_sha256'] != wanted:
                raise ValueError('Source differs from the supplied evidence snapshot')
            source_bytes[relative] = data
            if relative.endswith('.py'):
                trees[relative] = ast.parse(data, filename=relative)
            elif relative.endswith('.json'):
                json_docs[relative] = strict_json(data)
            elif relative.endswith('.jsonl'):
                for number, line in enumerate(data.splitlines(), 1):
                    if line.strip():
                        doc = strict_json(line)
                        if not isinstance(doc, dict):
                            raise ValueError('JSONL row is not an object at line ' + str(number))
            row['status'] = 'match_and_parse_passed'
        except (OSError, ValueError, TypeError, SyntaxError, UnicodeError) as error:
            row['status'] = 'failed'
            errors.append({'code': 'snapshot_file_failed', 'path': relative, 'detail': str(error)})
    for relative in REQUIRED:
        if relative not in source_bytes:
            errors.append({'code': 'required_source_unverified', 'path': relative})
    cfg = json_docs.get('run.json')
    if not isinstance(cfg, dict):
        errors.append({'code': 'missing_run_object'})
    else:
        report['run_fingerprint'] = cfg.get('fingerprint')
        if cfg.get('fingerprint') != fingerprint(cfg):
            errors.append({'code': 'run_fingerprint_invalid'})
        if not isinstance(cfg.get('hashes'), dict) or not isinstance(cfg.get('stages'), list):
            errors.append({'code': 'invalid_run_structure'})
        else:
            seals = {'checked': 0, 'mismatches': [], 'missing_or_unreadable': [], 'not_in_export': []}
            for relative, wanted in cfg['hashes'].items():
                try:
                    if not isinstance(wanted, str) or not SHA_PATTERN.fullmatch(wanted):
                        raise ValueError('Invalid sealed SHA256')
                    path = safe_relative(repo, relative)
                    if export_snapshot and relative not in expected_files and not path.exists():
                        seals['not_in_export'].append(relative)
                        continue
                    data = source_bytes.get(relative)
                    if data is None:
                        data = read_source(path)
                    seals['checked'] += 1
                    if sha_bytes(data) != wanted:
                        seals['mismatches'].append({'path': relative, 'sealed_sha256': wanted, 'actual_sha256': sha_bytes(data)})
                except (OSError, ValueError, TypeError) as error:
                    seals['missing_or_unreadable'].append({'path': relative, 'detail': str(error)})
            report['production_seal'] = seals
            report['production_integrity_passed'] = not any(seals[k] for k in ('mismatches', 'missing_or_unreadable', 'not_in_export'))
            if seals['mismatches'] or seals['missing_or_unreadable']:
                report['production_blockers'].append({'code': 'existing_production_seal_would_fail',
                    'detail': 'common.load_run verifies every sealed file before running. Restore the exact reviewed original or create a separately validated new run; do not overwrite old proof.'})
            if seals['not_in_export']:
                report['observations'].append({'code': 'export_does_not_contain_all_sealed_files', 'paths': seals['not_in_export'],
                    'detail': 'Absence from this export does not establish absence on Jean Zay.'})
        report['current_run'] = {k: cfg.get(k) for k in ('version', 'production_revision', 'world_size', 'source_step',
                'initialization', 'optimizer_initialization', 'batch_divisor', 'shuffle_buffer', 'stages', 'runtime')}
        mapping = json_docs.get('source/species_to_id.json')
        if not isinstance(mapping, dict) or len(mapping) != 26678 or any(type(v) is not int for v in mapping.values()) or set(mapping.values()) != set(range(26678)):
            errors.append({'code': 'species_mapping_invalid'})
        if source_bytes.get('source/species_to_id.json') is not None and sha_bytes(source_bytes['source/species_to_id.json']) != cfg.get('mapping_sha256'):
            errors.append({'code': 'species_mapping_hash_mismatch'})
        tok = json_docs.get('source/CodonTransformerTokenizer.json', {})
        vocab = tok.get('model', {}).get('vocab', {}) if isinstance(tok, dict) else {}
        if not isinstance(vocab, dict) or len(vocab) != 90 or any(type(v) is not int for v in vocab.values()) or set(vocab.values()) != set(range(90)):
            errors.append({'code': 'tokenizer_vocab_structure_invalid'})
        elif any(vocab.get(name) != value for name, value in {'[UNK]': 0, '[CLS]': 1, '[SEP]': 2, '[PAD]': 3, '[MASK]': 4}.items()):
            errors.append({'code': 'tokenizer_special_ids_changed'})
    report['ddp_constructors'] = {relative: ddp_calls(trees[relative]) for relative in ('train.py', 'preflight.py') if relative in trees}
    if any(not calls or not all(row['audited_candidate_explicitly_installed'] for row in calls)
           for calls in report['ddp_constructors'].values()):
        report['production_blockers'].append({'code': 'fixed_bucket_candidate_not_explicitly_installed',
            'detail': 'Both training and memory preflight must use and revalidate the audited DDP policy. The exported constructors do not contain its explicit flags.'})
    # These are implementation requirements established by source review, not inferred runtime failures.
    report['production_blockers'].extend([
        {'code': 'finite_four_pass_pipeline_not_implemented', 'detail': 'Current RecordStream cycles indefinitely per rank, uses one process per rank, and reads prefixes. It is not the requested finite multiworker window pipeline.'},
        {'code': 'requested_curriculum_not_implemented', 'detail': 'Current common.STAGES and batch_profile encode the old five-stage update schedule and omit1536. New worker, masking and true-pass settings require new code and run identity.'},
        {'code': 'draw_and_optimizer_counters_must_change', 'detail': 'Current train/checks assume192 accepted records per rank per optimizer update and AdamW step=source_step+continuation_step. Do not relabel counters when batch geometry or optimizer initialization changes.'},
        {'code': 'complete_epoch_biological_evaluation_not_integrated', 'detail': 'Generation and all historical biological metric scorers need an explicit frozen-reference/cohort integration before launch.'},
        {'code': 'new_gpu_production_preflight_required', 'detail': 'CPU source integrity and a prior isolated audit do not validate the new training implementation.'}
    ])
    report['observations'].extend([
        {'code': 'current_species_dropout', 'detail': 'The reviewed augmentation.py uses0.12 unknown-species probability. The requested0.02 is not installed in this snapshot.'},
        {'code': 'current_loss_and_clipping', 'detail': 'engine.optimizer_update sums CE, scales by world/global supervised targets and clips accumulated gradients at0.5; retain correct normalization when changing batching.'},
        {'code': 'current_checkpoint_import', 'detail': 'model_io imports existing AdamW moments and checks global_step agreement; species scale is constrained to0.0347. A weights-only restart needs an explicit new initialization path.'},
        {'code': 'checks_diagnostic_change', 'detail': 'Exported checks.py adds mismatch diagnostics and re-raises assert_close at rtol1e-5/atol2e-6. This does not loosen tolerances, but differs from the sealed hash.'}
    ])
    report['snapshot_integrity_passed'] = not errors
    report['status'] = 'REVIEW_REQUIRED' if not errors else 'SNAPSHOT_FAILED'
    return report


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp.' + str(os.getpid()))
    try:
        with temporary.open('w') as handle:
            json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write('\n')
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=DEFAULT_REPO)
    parser.add_argument('--expected', type=Path, default=DEFAULT_EXPECTED)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--export-snapshot', action='store_true', help='Local export only: distinguish omitted sealed files from missing remote files')
    args = parser.parse_args(argv)
    try:
        expected = strict_json(args.expected.read_bytes())
        report = review(args.repo, expected, args.export_snapshot)
    except (OSError, ValueError, TypeError) as error:
        report = {'schema': 'ct2-static-review-v1', 'status': 'SNAPSHOT_FAILED',
                  'snapshot_integrity_passed': False, 'training_ready': False, 'errors': [{'code': 'review_failed', 'detail': str(error)}]}
    atomic_json(args.output, report)
    print('STATIC_REVIEW_STATUS=' + report['status'])
    print('SNAPSHOT_INTEGRITY_PASSED=' + str(report['snapshot_integrity_passed']).lower())
    print('TRAINING_READY=false')
    print('STATIC_REVIEW_REPORT=' + str(args.output.absolute()))
    return 0 if report['snapshot_integrity_passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
