"""Pure comparator gates plus full tensor checks when CPU Torch is available."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import compare_preflight as cp


def checkpoint(updates=16, branch='reference'):
    return dict(format=cp.FORMAT, plan_identity='a'*64, stage=0, branch=branch,
                completed_updates=updates, source={'checkpoint_sha256': 'b'*64},
                world_size=8, state_dict={'model.p': [1.0], 'species_embed.weight': [2.0]},
                model_config={'vocab_size': 90, 'hidden_size': 768}, species_embed_scale=.0347,
                optimizer_state={'state': {'p': 1}},
                optimizer_parameter_names=[['model.p'], ['species_embed.weight']],
                rank_states=[dict(rank=r, stream={'cursor': 100, 'identity': 's'},
                                  rng={'python': [1], 'numpy': [2], 'torch': [3], 'cuda': [4]}) for r in range(8)],
                execution_settings={'profile': 'controlled_v1'},
                ddp_policy={'find_unused_parameters': True, 'static_graph': False, 'broadcast_buffers': False,
                            'ordered_bucket_bytes': cp.AUDITED_BUCKET_BYTES.copy()},
                padding_policy='fixed_stage_max_length', runtime_versions={'torch': '2.6.0+cu124', 'transformers': '4.51.3'},
                statistics={'totals': [1., 100., 2., 200., 32., 400., 2., 1.],
                            'grad_norms': [1.]*updates, 'clip_count': updates, 'physical_records': 32,
                            'clipping_factors': [.5]*updates, 'active_seconds': 2.})


class MetadataTests(unittest.TestCase):
    def test_matching_state_passes_while_observational_timing_differs(self):
        a = checkpoint(); b = copy.deepcopy(a); b['branch'] = 'split'
        b['statistics']['active_seconds'] = 123.; b['job_id'] = 'new'; a['job_id'] = 'old'
        result = cp.compare_pair(a, b, updates=16, second_branch='split')
        self.assertEqual(result['status'], 'PASS'); self.assertTrue(result['exact_equality'])
        self.assertFalse(result['examples_truncated'])

    def test_count_and_cursor_differences_are_exact_failures(self):
        for field in ('count', 'cursor'):
            with self.subTest(field=field):
                a = checkpoint(); b = copy.deepcopy(a); b['branch'] = 'split'
                if field == 'count': b['statistics']['physical_records'] += 1
                else: b['rank_states'][7]['stream']['cursor'] += 1
                result = cp.compare_pair(a, b, updates=16, second_branch='split')
                self.assertEqual(result['status'], 'FAIL')

    def test_numeric_tolerance_is_asymmetric_and_exact_difference_retained(self):
        c = cp.Comparison(); c.compare(1.000003, 1., close=True)
        result = c.result(); self.assertEqual(result['status'], 'PASS'); self.assertFalse(result['exact_equality'])
        c = cp.Comparison(); c.compare(1.001, 1., close=True)
        self.assertEqual(c.result()['status'], 'FAIL')

    def test_nonfinite_values_fail_even_when_equal(self):
        for value in (float('inf'), float('-inf'), float('nan')):
            c = cp.Comparison(); c.health({'value': value}, 'a'); c.compare(value, value, close=True)
            self.assertEqual(c.result()['status'], 'FAIL')

    def test_nonfinite_observational_timing_is_health_failure(self):
        a = checkpoint(); b = copy.deepcopy(a); b['branch'] = 'split'
        b['statistics']['active_seconds'] = float('inf')
        self.assertEqual(cp.compare_pair(a, b, updates=16, second_branch='split')['status'], 'FAIL')

    def test_branch_update_and_rank_integrity_are_required(self):
        for field, value in [('branch', 'resume'), ('completed_updates', 15), ('world_size', 1), ('stage', True), ('source', {})]:
            a = checkpoint(); a[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError): cp.validate_header(a, 16, 'reference')
        a = checkpoint(); a['rank_states'][7]['rank'] = 0
        with self.assertRaises(ValueError): cp.validate_header(a, 16, 'reference')

    def test_incomplete_rng_and_gradient_history_rejected(self):
        a = checkpoint(); del a['rank_states'][0]['rng']['cuda']
        with self.assertRaises(ValueError): cp.validate_header(a, 16, 'reference')
        a = checkpoint(); a['statistics']['grad_norms'].pop()
        with self.assertRaises(ValueError): cp.validate_header(a, 16, 'reference')

    def test_wrong_buckets_padding_or_versions_fail_independently_of_equality(self):
        for field, value in [('padding_policy', 'dynamic'), ('runtime_versions', {'torch': '2.8.0', 'transformers': '4.51.3'})]:
            a = checkpoint(); a[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError): cp.validate_header(a, 16, 'reference')
        a = checkpoint(); a['ddp_policy']['ordered_bucket_bytes'][0] += 1
        with self.assertRaises(ValueError): cp.validate_header(a, 16, 'reference')

    def test_unknown_checkpoint_state_is_compared_not_silently_ignored(self):
        a = checkpoint(); b = copy.deepcopy(a); b['branch'] = 'split'
        a['future_counter'] = 1; b['future_counter'] = 2
        self.assertEqual(cp.compare_pair(a, b, updates=16, second_branch='split')['status'], 'FAIL')

    def test_arrays_require_exact_values_dtype_and_finiteness(self):
        try: import numpy as np
        except ImportError: self.skipTest('NumPy unavailable')
        c = cp.Comparison(); c.compare(np.array([1], dtype=np.uint32), np.array([2], dtype=np.uint32), close=True)
        self.assertEqual(c.result()['status'], 'FAIL')
        c = cp.Comparison(); c.health(np.array([np.inf]), 'rng')
        self.assertEqual(c.result()['status'], 'FAIL')

    def test_missing_dependency_produces_failed_report_not_exception_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp)/'report.json'
            with mock.patch.dict('sys.modules', {'torch': None}):
                result = cp.run_comparisons({k: Path(tmp)/k for k in ('reference16','split16','reference32','resumed32')}, output)
            self.assertEqual(result['status'], 'FAIL'); self.assertFalse(result['training_ready'])
            self.assertTrue(result['errors']); self.assertEqual(json.loads(output.read_text())['status'], 'FAIL')


HAS_TORCH = importlib.util.find_spec('torch') is not None


@unittest.skipUnless(HAS_TORCH, 'CPU Torch unavailable; run in pinned Jean Zay environment before GPU submission')
class TensorTests(unittest.TestCase):
    def make(self, branch='reference'):
        import torch
        a = checkpoint(branch=branch)
        a['state_dict'] = {'model.p': torch.ones(2), 'species_embed.weight': torch.ones(3, 2)}
        a['optimizer_state'] = {
            'state': {i: {'step': torch.tensor(16.), 'exp_avg': torch.zeros_like(w), 'exp_avg_sq': torch.ones_like(w)}
                      for i, w in enumerate(a['state_dict'].values())},
            'param_groups': [{'params': [i], 'betas': (.9,.999), 'eps': 1e-8, 'amsgrad': False,
                              'weight_decay': .01 if i == 0 else 0., 'lr': 2e-5} for i in range(2)]}
        for state in a['rank_states']:
            state['rng']['torch'] = torch.get_rng_state(); state['rng']['cuda'] = torch.get_rng_state()
        return a

    def test_full_state_close_diff_and_failure(self):
        import torch
        a = self.make(); b = copy.deepcopy(a); b['branch'] = 'split'
        b['state_dict']['model.p'][0] += 3e-6
        result = cp.compare_pair(a, b, updates=16, second_branch='split', torch_module=torch)
        self.assertEqual(result['status'], 'PASS'); self.assertFalse(result['exact_equality'])
        b['optimizer_state']['state'][1]['exp_avg'][0, 0] += .001
        self.assertEqual(cp.compare_pair(a, b, updates=16, second_branch='split', torch_module=torch)['status'], 'FAIL')

    def test_wrong_optimizer_age_rejected(self):
        import torch
        a = self.make(); a['optimizer_state']['state'][0]['step'] = torch.tensor(15.)
        with self.assertRaises(ValueError): cp.validate_tensor_state(a, torch)

    def test_aligned_nan_cannot_pass(self):
        import torch
        a = self.make(); b = copy.deepcopy(a); b['branch'] = 'split'
        a['state_dict']['model.p'][0] = float('nan'); b['state_dict']['model.p'][0] = float('nan')
        self.assertEqual(cp.compare_pair(a, b, updates=16, second_branch='split', torch_module=torch)['status'], 'FAIL')


if __name__ == '__main__': unittest.main()
