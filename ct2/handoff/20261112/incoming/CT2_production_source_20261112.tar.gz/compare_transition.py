#!/usr/bin/env python3
"""Compare the new trainer's split/restart across changing stage lengths."""
from __future__ import annotations
import argparse
import gc
import json
from pathlib import Path

from compare_preflight import Comparison, validate_tensor_state
from gpu_preflight import atomic_json
from production_trainer import read_checkpoint, trainer_identity, validate_progress

EXACT_FIELDS = ('format', 'mode', 'plan_identity', 'release_id', 'trainer_identity',
    'stage', 'stage_step', 'stage_complete', 'completed_updates', 'source', 'world_size',
    'model_config', 'species_embed_scale', 'optimizer_parameter_names', 'execution_settings',
    'ddp_policy', 'padding_policy', 'runtime_versions', 'lr_policy', 'clip_value',
    'full_dataset_verified', 'production_resume_allowed')
FLOAT_STATS = {'partial_loss_sum', 'full_loss_sum', 'grad_norm_sum', 'grad_norm_sq_sum',
               'grad_norm_max', 'clipping_factor_sum'}


def compare_pair(a, b, updates, branch, plan, release_id, torch_module=None):
    for value in (a, b):
        validate_progress(value, plan, 'qualification', release_id)
        if value['completed_updates'] != updates:
            raise ValueError('Unexpected qualification checkpoint age')
        if torch_module is not None: validate_tensor_state(value, torch_module)
    if a.get('branch') != 'reference' or b.get('branch') != branch:
        raise ValueError('Qualification branch identity mismatch')
    if updates == 3 and (a['stage'], a['stage_step'], a['stage_complete']) != (1, 1, False):
        raise ValueError('Split does not occur inside the second stage')
    if updates == 8 and (a['stage'], a['stage_step'], a['stage_complete']) != (3, 2, True):
        raise ValueError('Final checkpoint did not cross all four length stages')
    comparison = Comparison(torch_module)
    comparison.health(a, 'reference'); comparison.health(b, branch)
    for key in EXACT_FIELDS: comparison.compare(a[key], b[key], path=key)
    comparison.compare(a['rank_states'], b['rank_states'], path='rank_states')
    for key in ('state_dict', 'optimizer_state'):
        comparison.compare(a[key], b[key], close=True, path=key)
    for stage in range(4):
        for key in a['statistics'][stage]:
            comparison.compare(a['statistics'][stage][key], b['statistics'][stage][key],
                               close=key in FLOAT_STATS, path=f'statistics.{stage}.{key}')
    expected = set(EXACT_FIELDS) | {'branch', 'rank_states', 'state_dict', 'optimizer_state', 'statistics'}
    comparison.compare({k: v for k, v in a.items() if k not in expected},
                       {k: v for k, v in b.items() if k not in expected}, path='extra_fields')
    result = comparison.result()
    result.update(completed_updates=updates, compared_branch=branch)
    return result


def run(paths, plan_path, release_id, output):
    report = {'schema': 'ct2-transition-comparison-v1', 'status': 'FAIL', 'pairs': {},
        'release_id': release_id, 'trainer_identity': trainer_identity(),
        'inputs': {k: str(Path(v).resolve()) for k, v in paths.items()},
        'errors': [], 'training_ready': False,
        'scope': 'Two actual-data prefix updates per stage; carries optimizer and RNG across lengths; not a full finite-pass coverage test.'}
    try:
        import torch
        from finite_plan import validate_plan
        plan = json.loads(Path(plan_path).read_text()); validate_plan(plan)
        report['plan_identity'] = plan['identity']
        shared = None
        for updates, first, second, branch in ((3, 'reference3', 'split3', 'split'),
                                              (8, 'reference8', 'resumed8', 'resume')):
            a, b = read_checkpoint(paths[first]), read_checkpoint(paths[second])
            report['pairs'][str(updates)] = compare_pair(a, b, updates, branch, plan, release_id, torch)
            identity = {key: a[key] for key in EXACT_FIELDS if key not in
                        {'stage', 'stage_step', 'stage_complete', 'completed_updates'}}
            if shared is None:
                shared = identity
                report['clip_value'] = a['clip_value']
                report['source_checkpoint_sha256'] = a['source']['checkpoint_sha256']
            else:
                comparison = Comparison(torch)
                comparison.compare(shared, identity, path='cross_update_identity')
                report['cross_update_identity'] = comparison.result()
            del a, b; gc.collect()
        if all(value['status'] == 'PASS' for value in report['pairs'].values()) and report['cross_update_identity']['status'] == 'PASS':
            report['status'] = 'PASS'
        report['exact_equality'] = report['status'] == 'PASS' and all(x['exact_equality'] for x in report['pairs'].values())
    except Exception as error:
        report['errors'].append({'type': type(error).__name__, 'message': str(error)})
    atomic_json(output, report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('reference3', 'split3', 'reference8', 'resumed8', 'plan', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--release-id', required=True)
    args = parser.parse_args(argv)
    report = run({name: getattr(args, name) for name in ('reference3', 'split3', 'reference8', 'resumed8')},
                 args.plan, args.release_id, args.output)
    print('TRANSITION_COMPARISON=' + report['status'])
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__': raise SystemExit(main())
