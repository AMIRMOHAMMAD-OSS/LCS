"""Candidate identity tests plus CPU Torch collator tests when Torch is present."""
import contextlib
import copy
import io
import json
from pathlib import Path
import unittest

import candidate_collator as c
import candidate_model as m
import gpu_preflight as g

try:
    import torch
except ImportError:
    torch = None


def source():
    return dict(checkpoint_sha256=m.SOURCE_CHECKPOINT_SHA256, source_fingerprint=m.SOURCE_FINGERPRINT)


def plan():
    value = {'world_size': 8, 'padding_policy': 'fixed_stage_max_length', 'source': source(),
             'stages': [dict(max_length=n, full_mask_probability=p, batch_per_gpu=b,
                             accumulation=a, num_workers=w, learning_rate_preflight=lr)
                        for n, p, b, a, w, lr in g.STAGE_GEOMETRY]}
    value['identity'] = m.canonical_identity(value)
    return value


class IdentityTests(unittest.TestCase):
    def test_plan_identity_and_padding_are_required(self):
        value = plan(); m.validate_plan_identity(value)
        value['stages'][0]['num_workers'] = 2
        with self.assertRaisesRegex(ValueError, 'identity'):
            m.validate_plan_identity(value)
        value['identity'] = m.canonical_identity(value)
        with self.assertRaisesRegex(ValueError, 'geometry'):
            g.stage_spec(value, 0)
        value.pop('padding_policy'); value['identity'] = m.canonical_identity(value)
        with self.assertRaisesRegex(ValueError, 'padding'):
            m.validate_plan_identity(value)

    def test_source_identity_is_not_relabelled_for_new_plan(self):
        cp = dict(ct2_format=1, fingerprint=m.SOURCE_FINGERPRINT, global_step=120000,
                  continuation_step=40000, stage=0, stage_step=40000,
                  mapping_sha256=m.SOURCE_FILES['source/species_to_id.json'],
                  species_embed_scale=.0347, model_config={'hidden_size': 768})
        before = copy.deepcopy(cp)
        m.validate_source_metadata(cp, source())
        self.assertEqual(cp, before)
        cp['fingerprint'] = plan()['identity']
        with self.assertRaisesRegex(ValueError, 'fingerprint'):
            m.validate_source_metadata(cp, source())

    def test_historical_optimizer_age_and_species_scale_cannot_be_relabelled(self):
        cp = dict(ct2_format=1, fingerprint=m.SOURCE_FINGERPRINT, global_step=120000,
                  continuation_step=40000, stage=0, stage_step=40000,
                  mapping_sha256=m.SOURCE_FILES['source/species_to_id.json'],
                  species_embed_scale=.0347, model_config={})
        for field, changed in [('global_step', 0), ('stage_step', 32), ('species_embed_scale', 1.)]:
            bad = dict(cp, **{field: changed})
            with self.subTest(field=field), self.assertRaises(ValueError):
                m.validate_source_metadata(bad, source())

    def test_window_validation_prevents_truncation_and_bad_hosts(self):
        row = {'token_ids': [5, 6], 'species_id': 0, 'identity': 's0:r0:w0'}
        c.validate_windows([row], 4)
        for bad in [dict(row, token_ids=[5, 6, 7]), dict(row, species_id=26678),
                    dict(row, species_id=True), dict(row, token_ids=[True]), dict(row, identity='')]:
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                c.validate_windows([bad], 4)

    def test_standard_code_and_deterministic_seed(self):
        self.assertEqual(len(c.CODE), 64)
        self.assertEqual(c.codon_token('ATG'), 'm_atg')
        self.assertEqual(c.codon_token('TAA'), '__taa')
        self.assertEqual(c.stable_seed('seed'), c.stable_seed('seed'))
        self.assertNotEqual(c.stable_seed('seed'), c.stable_seed('seed2'))

    def test_audited_ddp_flags_and_layout_fail_closed(self):
        class FakeDDP:
            find_unused_parameters = True
            static_graph = False
            broadcast_buffers = False
            def _get_ddp_logging_data(self):
                return {'bucket_sizes': ', '.join(map(str, g.EXPECTED_BUCKET_BYTES))}
        ddp = FakeDDP()
        self.assertEqual(g.ddp_policy(ddp)['ordered_bucket_bytes'], g.EXPECTED_BUCKET_BYTES)
        ddp.find_unused_parameters = False
        with self.assertRaisesRegex(RuntimeError, 'flags'):
            g.ddp_policy(ddp)
        ddp.find_unused_parameters = True
        ddp._get_ddp_logging_data = lambda: {'bucket_sizes': '123'}
        with self.assertRaisesRegex(RuntimeError, 'bucket'):
            g.ddp_policy(ddp)

    def test_resume_requires_own_split_checkpoint_and_import_provenance(self):
        p = plan()
        cp = dict(format=g.FORMAT, plan_identity=p['identity'], stage=0, branch='split',
                  completed_updates=16, world_size=8, production_resume_allowed=False,
                  padding_policy='fixed_stage_max_length',
                  source=dict(p['source'], imported_model_only=True, source_global_step=120000,
                              optimizer_age_at_import=0), rank_states=[{'rank': r} for r in range(8)])
        g.validate_resume(cp, p, 0)
        for key, value in [('branch', 'reference'), ('completed_updates', 15),
                           ('production_resume_allowed', True), ('padding_policy', 'dynamic')]:
            with self.subTest(key=key), self.assertRaises(ValueError):
                g.validate_resume(dict(cp, **{key: value}), p, 0)

    def test_driver_has_no_full_training_mode(self):
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            g.main(['--plan', 'unused.json', '--stage', '0', '--output', 'unused', '--branch', 'full'])


class FakeTokenizer:
    def __init__(self):
        path = Path(__file__).parent / 'policy_fixture/source/CodonTransformerTokenizer.json'
        self.vocab = json.loads(path.read_text())['model']['vocab']
        self.cls_token_id = self.vocab['[CLS]']; self.sep_token_id = self.vocab['[SEP]']
        self.pad_token_id = self.vocab['[PAD]']; self.mask_token_id = self.vocab['[MASK]']
    def get_vocab(self): return self.vocab


@unittest.skipIf(torch is None, 'Torch unavailable locally; run these CPU tests in the reviewed Jean Zay environment')
class CollatorTorchTests(unittest.TestCase):
    def setUp(self):
        self.tok = FakeTokenizer(); self.v = self.tok.vocab
        self.rows = [dict(token_ids=[self.v['m_atg'], self.v['g_ggt'], self.v['a_unk'], self.v['__taa']],
                          species_id=i, identity=f'row:{i}', record_first=True) for i in range(8)]

    def test_fullmask_keeps_aa_identity_and_does_not_supervise_unknown(self):
        collator = c.CandidateCollator(self.tok, unknown_probability=0.)
        batch = collator(self.rows, 32, 1., 0, 0)
        self.assertEqual(tuple(batch['input_ids'].shape), (8, 32))
        self.assertTrue(torch.equal(batch['input_ids'][:, 1:5],
            torch.tensor([[self.v['m_unk'], self.v['g_unk'], self.v['a_unk'], self.v['__unk']]] * 8)))
        self.assertEqual(int(batch['labels'].ne(-100).sum()), 24)
        self.assertTrue((batch['labels'][:, 3] == -100).all())
        self.assertTrue((batch['labels'][:, 5:] == -100).all())

    def test_masking_is_repeatable_and_does_not_consume_training_rng(self):
        collator = c.CandidateCollator(self.tok)
        before = torch.get_rng_state().clone()
        a = collator(self.rows, 32, .05, 15, 2)
        b = collator(self.rows, 32, .05, 15, 2)
        self.assertTrue(torch.equal(before, torch.get_rng_state()))
        self.assertTrue(all(torch.equal(a[key], b[key]) for key in a))
        self.assertTrue(a['labels'].ne(-100).any(dim=1).all())

    def test_species_dropout_is_independent_and_never_wrong_real_host(self):
        collator = c.CandidateCollator(self.tok, unknown_probability=.5)
        a = collator(self.rows, 32, 0., 0, 0)
        b = collator(self.rows, 32, 1., 0, 0)
        self.assertTrue(torch.equal(a['species_id'], b['species_id']))
        truth = torch.arange(8)
        self.assertTrue(((a['species_id'] == truth) | (a['species_id'] == 26678)).all())

    def test_dummy_is_framed_but_has_no_targets_or_real_counts(self):
        batch = c.CandidateCollator(self.tok)([], 512, 1., 0, 0)
        self.assertEqual(tuple(batch['input_ids'].shape), (1, 512))
        self.assertEqual(int(batch['attention_mask'].sum()), 3)
        self.assertEqual(int(batch['labels'].ne(-100).sum()), 0)
        self.assertEqual(int(batch['real'].sum() + batch['record_first'].sum()), 0)
        self.assertFalse(batch['full'].any() or batch['unknown'].any())

    def test_zero_target_window_is_rejected_before_forward(self):
        rows = [dict(token_ids=[self.v['a_unk']], species_id=0, identity='unknown')]
        with self.assertRaisesRegex(ValueError, 'known codon'):
            c.CandidateCollator(self.tok)(rows, 512, .05, 0, 0)


if __name__ == '__main__':
    unittest.main()
