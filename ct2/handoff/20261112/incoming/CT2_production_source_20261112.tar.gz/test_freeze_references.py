"""Independent CPU tests of frozen legacy CAI semantics and provenance guards."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import itertools
import json
from pathlib import Path
import tempfile
import unittest

import pandas as pd

import freeze_references as fr


# Independent standard code, not the implementation's codon map.
CODE = dict(zip((''.join(x) for x in itertools.product('TCAG', repeat=3)),
                'FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG'))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class FreezeReferenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.project = self.root / 'project'
        self.out = self.root / 'frozen'
        self.paths = {k: self.project / v for k, v in fr.PATHS.items()}
        for path in self.paths.values():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b'parquet source placeholder: ' + path.name.encode())
        self.paths['mapping'].write_text(json.dumps({'hostA': 0, 'hostB': 1, 'hostC': 2}))
        self.paths['panel'].write_text(''.join(json.dumps({'species': s, 'protein_sequence': 'MA'}) + '\n'
                                             for s in ('hostA', 'hostB', 'hostC')))
        self.summary = pd.DataFrame([
            {'species': 'hostA', 'top_ref_genes': 2, 'mean_ref_csi': 1.0, 'mean_ref_len': 4.0},
            {'species': 'hostB', 'top_ref_genes': 1, 'mean_ref_csi': 1.0, 'mean_ref_len': 4.0},
        ])
        for key in ('standard_summary', 'rare_summary'):
            self.summary.to_csv(self.paths[key], index=False)
        first = dict(species='hostA', genome_id='gA', protein_id='pA', dna='ATGGCTGCTGCC',
                     protein_len=4, formal_csi=1.0, codons_total=4, missing_weight_frac=0.0)
        second = dict(species='hostB', genome_id='gB', protein_id='pB', dna='ATGGCGNNNTAA',
                      protein_len=4, formal_csi=1.0, codons_total=2, missing_weight_frac=0.0)
        self.selected = pd.DataFrame([first, deepcopy(first), second])
        self.rare_selected = self.selected.iloc[::-1].copy().reset_index(drop=True)
        self.table = pd.DataFrame([
            dict(species=host, aa=aa, codon=codon, frequency=1.0,
                 rare_lt_0_001=False, rare_lt_0_01=False)
            for host in ('hostA', 'hostB', 'hostC') for codon, aa in CODE.items() if aa != '*'
        ])
        # These rare codons are not present in the selected host-A DNA; the
        # selected rows' formal CSI remains exactly one.
        mask = (self.table.species == 'hostA') & (self.table.codon == 'GCA')
        self.table.loc[mask, ['frequency', 'rare_lt_0_001', 'rare_lt_0_01']] = [.0005, True, True]
        mask = (self.table.species == 'hostA') & (self.table.codon == 'GCG')
        self.table.loc[mask, ['frequency', 'rare_lt_0_01']] = [.005, True]
        self.script_hashes = {}
        for name in fr.SCRIPT_HASHES:
            path = self.project / 'CodonTransformerV2' / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('# audited source fixture\n' + '# ' + name + '\n')
            self.script_hashes[name] = digest(path)

    def reader(self, path):
        path = Path(path)
        for key, frame in [('standard_selected', self.selected), ('rare_selected', self.rare_selected),
                           ('codon_table', self.table)]:
            if path == self.paths[key]:
                return frame.copy(deep=True)
        raise AssertionError('Unexpected Parquet read: ' + str(path))

    def freeze(self):
        return fr.freeze(self.project, self.out, parquet_reader=self.reader,
                         expected_summary_hash=digest(self.paths['standard_summary']),
                         expected_species=2, expected_records=3,
                         expected_script_hashes=self.script_hashes)

    def test_legacy_formula_counts_duplicates_and_skips_ambiguous_stop_codons(self):
        report = self.freeze()
        a, b = report['species']['hostA'], report['species']['hostB']
        self.assertEqual(a['selected_records'], 2)
        self.assertEqual(a['raw_codon_counts']['GCT'], 4)
        self.assertEqual(a['raw_codon_counts']['GCC'], 2)
        self.assertEqual(a['raw_codon_counts']['ATG'], 2)
        self.assertEqual(a['raw_codon_counts']['GCA'], 0)
        self.assertEqual(len(a['raw_codon_counts']), 61)
        self.assertEqual(a['weights']['GCT'], 1.0)
        self.assertAlmostEqual(a['weights']['GCC'], 3 / 5)
        self.assertAlmostEqual(a['weights']['GCA'], 1 / 5)
        self.assertEqual(a['weights']['ATG'], 1.0)
        self.assertEqual(sum(b['raw_codon_counts'].values()), 2)
        self.assertNotIn('TAA', b['raw_codon_counts'])
        self.assertEqual(report['selected_reference']['duplicate_exact_rows'], 1)
        self.assertEqual(report['selected_reference']['duplicate_gene_id_rows'], 1)

    def test_rare_masks_and_unsupported_panel_hosts_are_explicit(self):
        report = self.freeze()
        masks = report['species']['hostA']['rare_masks']
        self.assertEqual(set(masks['no_rare_0_001']), {'GCA'})
        self.assertEqual(set(masks['no_rare_0_01']), {'GCA', 'GCG'})
        support = report['evaluation_support']
        self.assertEqual(support['requested_records'], 3)
        self.assertEqual(support['supported_records'], 2)
        self.assertEqual(support['unsupported_species'], ['hostC'])

    def test_legacy_normalization_matches_rna_case_and_literal_whitespace(self):
        self.selected.loc[0, 'dna'] = 'aug gcu\ngcu gcc\r'
        report = self.freeze()
        self.assertEqual(report['species']['hostA']['raw_codon_counts']['GCT'], 4)

    def test_malformed_species_dna_length_and_nonfinite_csi_are_rejected(self):
        original = self.selected.copy(deep=True)
        for field, value in [('species', None), ('dna', 'ATGGC?GCTGCC'),
                             ('dna', 'ATG'), ('formal_csi', float('nan'))]:
            with self.subTest(field=field, value=value):
                self.selected = original.copy(deep=True)
                self.selected.loc[0, field] = value
                with self.assertRaises((ValueError, RuntimeError)):
                    self.freeze()
        self.selected = original

    def test_standard_and_rare_selected_membership_must_match(self):
        self.rare_selected.loc[0, 'protein_id'] = 'different-historical-reference'
        with self.assertRaises((ValueError, RuntimeError)):
            self.freeze()

    def test_actual_selected_csi_is_checked_against_codon_table(self):
        mask = (self.table.species == 'hostA') & (self.table.codon == 'GCC')
        self.table.loc[mask, 'frequency'] = .1
        with self.assertRaises((ValueError, RuntimeError)):
            self.freeze()

    def test_duplicate_table_rows_invalid_aa_nonboolean_rare_flags_are_rejected(self):
        original = self.table.copy(deep=True)
        cases = [pd.concat([original, original.iloc[:1]], ignore_index=True),
                 original.assign(aa=['X', *original.aa.tolist()[1:]]),
                 original.assign(rare_lt_0_001='False')]
        for index, frame in enumerate(cases):
            with self.subTest(case=index):
                self.table = frame
                with self.assertRaises((ValueError, RuntimeError)):
                    self.freeze()
        self.table = original

    def test_unknown_panel_species_and_missing_table_support_are_rejected(self):
        panel = self.paths['panel'].read_text()
        self.paths['panel'].write_text(json.dumps({'species': 'unmapped-host'}) + '\n')
        with self.assertRaises((ValueError, RuntimeError)):
            self.freeze()
        self.paths['panel'].write_text(panel)
        self.table = self.table.loc[~((self.table.species == 'hostA') & (self.table.codon == 'GCA'))].copy()
        with self.assertRaises((ValueError, RuntimeError)):
            self.freeze()

    def test_summary_counts_and_means_must_match_selected_rows(self):
        changed = self.summary.copy(deep=True)
        changed.loc[0, 'mean_ref_len'] = 99.0
        changed.to_csv(self.paths['standard_summary'], index=False)
        changed.to_csv(self.paths['rare_summary'], index=False)
        with self.assertRaises((ValueError, RuntimeError)):
            self.freeze()

    def test_same_inputs_reuse_without_rewriting_and_changed_source_is_rejected(self):
        first = self.freeze()
        before = {name: (self.out / name).read_bytes()
                  for name in ('frozen_reference.json', 'reference_manifest.json')}
        again = self.freeze()
        self.assertEqual(first['species'], again['species'])
        for name, content in before.items():
            self.assertEqual((self.out / name).read_bytes(), content)
        self.paths['standard_selected'].write_bytes(b'different source bytes')
        with self.assertRaises((ValueError, RuntimeError, FileExistsError)):
            self.freeze()
        for name, content in before.items():
            self.assertEqual((self.out / name).read_bytes(), content)

    def test_changed_scoring_source_is_rejected(self):
        path = self.project / 'CodonTransformerV2' / next(iter(self.script_hashes))
        path.write_text('# unexpected edit\n')
        with self.assertRaises((ValueError, RuntimeError)):
            self.freeze()

    def test_selected_stored_codon_count_and_missing_fraction_are_validated(self):
        original = self.selected.copy(deep=True)
        for field, value in [('codons_total', 3), ('missing_weight_frac', .25)]:
            with self.subTest(field=field):
                self.selected = original.copy(deep=True)
                self.selected.loc[0, field] = value
                with self.assertRaises((ValueError, RuntimeError)):
                    self.freeze()
        self.selected = original

    def test_source_mutation_during_read_prevents_publication(self):
        def mutating_reader(path):
            result = self.reader(path)
            if Path(path) == self.paths['standard_selected']:
                self.paths['standard_selected'].write_bytes(b'changed while being read')
            return result
        with self.assertRaises((ValueError, RuntimeError)):
            fr.freeze(self.project, self.out, parquet_reader=mutating_reader,
                      expected_summary_hash=digest(self.paths['standard_summary']),
                      expected_species=2, expected_records=3,
                      expected_script_hashes=self.script_hashes)
        self.assertFalse((self.out / 'frozen_reference.json').exists())
        self.assertFalse((self.out / 'reference_manifest.json').exists())

    def test_modified_frozen_weights_are_rejected_on_reuse(self):
        self.freeze()
        path = self.out / 'frozen_reference.json'
        report = json.loads(path.read_text())
        report['species']['hostA']['weights']['GCC'] = .999
        path.write_text(json.dumps(report))
        with self.assertRaises((ValueError, RuntimeError)):
            self.freeze()


if __name__ == '__main__':
    unittest.main()
