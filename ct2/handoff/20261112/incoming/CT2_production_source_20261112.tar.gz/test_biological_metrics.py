"""Analytical and retained-legacy parity tests for biological metric definitions."""
from __future__ import annotations

from copy import deepcopy
import importlib.util
import json
import math
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd

import biological_metrics as bm


def fixtures():
    rows = [dict(species=host, aa=aa, codon=c, frequency=.2,
                 rare_lt_0_001=False, rare_lt_0_01=False)
            for host in ('a', 'b', 'c') for c, aa in bm.CODE.items() if aa != '*']
    frame = pd.DataFrame(rows)
    for host, freqs in [('a', [.8, .19, .0095, .0005]), ('b', [.19, .8, .0005, .0095])]:
        for codon, freq in zip(('GCT', 'GCC', 'GCA', 'GCG'), freqs):
            mask = (frame.species == host) & (frame.codon == codon)
            frame.loc[mask, ['frequency', 'rare_lt_0_001', 'rare_lt_0_01']] = [freq, freq < .001, freq < .01]
    ref = {'species': {host: {'weights': {codon: (.25 if codon == 'GCC' else 1.) for codon in bm.CODONS},
                              'rare_masks': {'no_rare_0_001': ['GCG'] if host == 'a' else ['GCA'],
                                             'no_rare_0_01': ['GCA', 'GCG']}}
                       for host in ('a', 'b')}}
    return frame, ref


def record(protein='AAAA', native='GCTGCTGCTGCT', predicted='GCCGCCGCCGCCTAA', host='a', condition='own'):
    return dict(eval_id='toy', cohort='toy', model='ct2', species=host,
                requested_condition=condition, protein_sequence=protein,
                native_dna=native, predicted_dna=predicted)


def legacy_module(name):
    path = Path(__file__).parent / 'metric_policy_fixture' / name
    spec = importlib.util.spec_from_file_location('legacy_' + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    # The CSI fixture only uses Torch in main(); CPU build_matrices is NumPy.
    progress = types.ModuleType('tqdm'); progress.tqdm = lambda iterable, **kwargs: iterable
    with patch.dict(sys.modules, {'torch': sys.modules.get('torch', types.ModuleType('torch')), 'tqdm': progress}):
        spec.loader.exec_module(module)
    return module


class BiologicalMetricTests(unittest.TestCase):
    def setUp(self):
        self.frame, self.ref = fixtures()
        self.engine = bm.MetricEngine.from_frame(self.frame, self.ref, {'toy': ['a', 'b', 'c']})

    def test_formal_csi_rank_and_cai_have_analytical_values(self):
        row = self.engine.score_batch([record()])[0]
        self.assertAlmostEqual(row['formal_csi_own'], .19 / .8)
        self.assertAlmostEqual(row['formal_csi_wrong_mean'], 1.)
        self.assertAlmostEqual(row['formal_csi_delta_log'], math.log(.19 / .8))
        self.assertEqual(row['formal_rank_legacy'], 3)
        self.assertEqual(row['raw_frequency_rank_legacy'], 3)
        self.assertAlmostEqual(row['cai_legacy_top10'], .25)
        self.assertEqual(row['formal_csi_codons_used'], 4)
        self.assertEqual(row['cai_codons_used'], 4)
        self.assertEqual(row['codon_recovery'], 0.)
        self.assertTrue(row['generation_valid'])

    def test_rank_ties_are_strict_greater_without_arbitrary_tie_break(self):
        r = record(protein='MMMM', native='ATG' * 4, predicted='ATG' * 4 + 'TAA')
        row = self.engine.score_batch([r])[0]
        self.assertEqual(row['formal_rank_legacy'], 1)
        self.assertEqual(row['raw_frequency_rank_legacy'], 1)
        self.assertEqual(row['formal_rank_requested_mask'], 1)

    def test_unsupported_cai_is_unscored_and_preserved_in_denominator(self):
        rows = self.engine.score_batch([record(host='c')])
        self.assertEqual(len(rows), 3)
        self.assertTrue(all(r['cai_legacy_top10'] is None for r in rows))
        self.assertTrue(all(not r['cai_reference_supported'] for r in rows))
        result = bm.summarize(iter(rows))
        for group in result['groups']:
            self.assertEqual(group['attempted'], 1)
            self.assertEqual(group['cai_reference_supported'], 0)
            self.assertEqual(group['metrics']['cai_legacy_top10'], {'scored': 0, 'unscored': 1, 'mean': None})
            self.assertEqual(group['macro_by_species']['cai_legacy_top10'],
                             {'species_scored': 0, 'species_unscored': 1, 'mean': None})
            self.assertEqual(group['by_species']['c']['metrics']['cai_legacy_top10']['scored'], 0)

    def test_requested_host_rare_mask_applies_same_positions_to_every_rank_host(self):
        r = record(native='GCG' * 4, predicted='GCG' * 4 + 'TAA')
        rows = {x['rare_mode']: x for x in self.engine.score_batch([r])}
        self.assertIsNotNone(rows['all']['formal_rank_requested_mask'])
        for mode in bm.MODES[1:]:
            self.assertEqual(rows[mode]['requested_mask_rank_codons'], 0)
            self.assertIsNone(rows[mode]['formal_rank_requested_mask'])
            self.assertIsNone(rows[mode]['formal_csi_own'])
            self.assertIsNone(rows[mode]['cai_legacy_top10'])
            self.assertEqual(rows[mode]['cai_rare_skipped'], 4)
            self.assertIsNotNone(rows[mode]['formal_rank_legacy'])

    def test_legacy_own_wrong_matrices_match_retained_source(self):
        legacy = legacy_module('eval_formal_csi_own_wrong_rare.py')
        for mode in bm.MODES:
            logs, mask = legacy.build_matrices(self.frame, self.engine.species, bm.RARE_COLUMNS.get(mode))
            indices = [legacy.CODON_TO_IDX[c] for c in bm.CODONS]
            np.testing.assert_allclose(self.engine.formal[mode], logs[indices], rtol=2e-7, atol=1e-7)
            np.testing.assert_array_equal(self.engine.mask[mode], mask[indices])

    def test_minmax_legacy_matches_both_retained_scorers(self):
        legacy = legacy_module('eval_minmax_ct2_stages.py')
        dtw = legacy_module('eval_minmax_dtw_ct2_stages.py')
        native = 'ATG' + 'GCTGCCGCAGCG' * 8
        predicted = 'ATG' + 'GCGGCAGCCGCT' * 8 + 'TAA'
        protein = 'M' + 'A' * 32
        actual = {x['rare_mode']: x for x in self.engine.score_batch([record(protein, native, predicted)])}
        for mode in bm.MODES:
            freq, stats = legacy.build_minmax_tables(self.frame, mode)
            old = legacy.compare_minmax(native, predicted, 'a', freq, stats, 18)
            row = actual[mode]
            self.assertAlmostEqual(row['minmax_legacy_mae'], old['profile_mae'], places=4)
            self.assertAlmostEqual(row['minmax_legacy_rmse'], old['profile_rmse'], places=4)
            ar, _, _ = legacy.minmax_raw_scores(native, 'a', freq, stats)
            br, _, _ = legacy.minmax_raw_scores(predicted, 'a', freq, stats)
            distance, normalized = dtw.dtw_pair(legacy.rolling_mean(br, 18), legacy.rolling_mean(ar, 18))
            self.assertAlmostEqual(row['minmax_legacy_dtw'], distance, places=4)
            self.assertAlmostEqual(row['minmax_legacy_dtw_normalized'], normalized, places=5)

    def test_dtw_matches_independent_small_dynamic_program(self):
        def reference(a, b):
            values = np.full((len(a), len(b)), np.inf)
            values[0, 0] = abs(a[0] - b[0])
            for i in range(len(a)):
                for j in range(len(b)):
                    if i == 0 and j == 0: continue
                    cost = abs(a[i] - b[j])
                    choices = []
                    if i: choices.append(values[i - 1, j] + cost)
                    if j: choices.append(values[i, j - 1] + cost)
                    if i and j: choices.append(values[i - 1, j - 1] + 2 * cost)
                    values[i, j] = min(choices)
            return values[-1, -1]
        rng = np.random.default_rng(7)
        for n in range(1, 8):
            for m in range(1, 8):
                a, b = rng.normal(size=n), rng.normal(size=m)
                distance, normalized = bm.dtw_symmetric2(a, b)
                self.assertAlmostEqual(distance, reference(a, b), places=12)
                self.assertAlmostEqual(normalized, distance / (n + m), places=12)

    def test_positional_profile_retains_holes_and_dtw_cannot_jump_them(self):
        a = np.array([0., 1., np.nan, 10., 11.])
        b = np.array([2., 2., np.nan, 12., 12.])
        result = bm.profile_comparison(a, b)
        d1, _ = bm.dtw_symmetric2(b[:2], a[:2]); d2, _ = bm.dtw_symmetric2(b[3:], a[3:])
        self.assertEqual(result['points'], 4)
        self.assertEqual(result['dtw_segments'], 2)
        self.assertAlmostEqual(result['dtw'], d1 + d2)
        self.assertAlmostEqual(result['dtw_normalized'], (d1 + d2) / 8)
        p = bm.rolling_profile([1., np.nan, 3., 4.], 2)
        self.assertTrue(np.isnan(p[:2]).all())
        self.assertEqual(p[2], 3.5)

    def test_native_translation_mismatch_is_excluded_only_from_new_positional_metrics(self):
        r = record(protein='AAAA', native='GCTGTTGCTGCT', predicted='GCC' * 4 + 'TAA')
        row = self.engine.score_batch([r])[0]
        self.assertEqual(row['native_known_positions'], 3)
        self.assertEqual(row['codon_recovery_positions'], 3)
        self.assertEqual(row['native_minmax_scored_codons'], 4)
        self.assertEqual(row['native_positional_minmax_scored_codons'], 3)
        self.assertIsNone(row['minmax_positional_mae'])
        self.assertIsNotNone(row['minmax_legacy_mae'])

    def test_generation_invalid_is_retained_but_not_scored_as_successful(self):
        r = record(predicted='GCC' * 3 + 'TAA')
        rows = self.engine.score_batch([r])
        self.assertTrue(all(not x['generation_valid'] for x in rows))
        self.assertTrue(all(x['formal_csi_own'] is None and x['codon_recovery'] is None for x in rows))
        for group in bm.summarize(rows)['groups']:
            self.assertEqual(group['attempted'], 1)
            self.assertEqual(group['strict_valid_generations'], 0)

    def test_legacy_no_stop_protocol_is_explicit_and_hfc_respects_it(self):
        r = record(predicted='GCC' * 4)
        self.assertFalse(self.engine.score_batch([r])[0]['generation_valid'])
        r['terminal_stop_included'] = False
        self.assertTrue(self.engine.score_batch([r])[0]['generation_valid'])
        native, hfc = self.engine.baseline_records([r])
        self.assertEqual(hfc['predicted_dna'], 'GCT' * 4)
        self.assertTrue(self.engine.score_batch([hfc])[0]['generation_valid'])

    def test_native_and_hfc_baselines_keep_cohort_and_identifiers(self):
        native, hfc = self.engine.baseline_records([record()])
        self.assertEqual(native['predicted_dna'], record()['native_dna'])
        self.assertEqual(hfc['predicted_dna'], 'GCT' * 4 + 'TAA')
        self.assertEqual(hfc['eval_id'], 'toy')
        self.assertEqual(hfc['cohort'], 'toy')
        row = self.engine.score_batch([hfc])[0]
        self.assertEqual(row['formal_csi_own'], 1.)
        self.assertEqual(row['codon_recovery'], 1.)

    def test_streaming_aggregation_has_pooled_macro_and_rank_median(self):
        rows = self.engine.score_batch([record(), record(host='c')])
        result = bm.summarize(iter(rows))
        group = next(x for x in result['groups'] if x['rare_mode'] == 'all')
        self.assertEqual(group['attempted'], 2)
        self.assertEqual(group['species_attempted'], 2)
        self.assertEqual(group['cai_reference_supported'], 1)
        self.assertEqual(group['metrics']['cai_legacy_top10']['scored'], 1)
        self.assertEqual(group['metrics']['cai_legacy_top10']['unscored'], 1)
        self.assertEqual(group['macro_by_species']['cai_legacy_top10']['species_scored'], 1)
        self.assertEqual(group['pooled_codon_recovery_positions'], 8)
        self.assertIn('median', group['metrics']['formal_rank_legacy'])
        json.dumps(result, allow_nan=False)

    def test_invalid_tables_weights_and_unknown_wrong_universe_are_rejected(self):
        duplicate = pd.concat((self.frame, self.frame.iloc[:1]))
        with self.assertRaises(ValueError): bm.MetricEngine.from_frame(duplicate, self.ref, ['a'])
        with self.assertRaises(ValueError): bm.MetricEngine.from_frame(self.frame, self.ref, ['absent'])
        ref = deepcopy(self.ref); ref['species']['a']['weights']['GCT'] = float('nan')
        with self.assertRaises(ValueError): bm.MetricEngine.from_frame(self.frame, ref, ['a'])
        with self.assertRaises(ValueError): bm.summarize([{}])


if __name__ == '__main__': unittest.main()
