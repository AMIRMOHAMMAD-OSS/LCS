#!/usr/bin/env python3
"""Read a preflight report without printing its molecule-ID audit.

Standard-library only, suitable for login-node inspection. This command does
not authorize a submission or modify a report. Exit 0 means report status PASS;
exit 1 means another status or an unreadable report.
"""
from __future__ import annotations

import argparse
from collections import deque
import json
from pathlib import Path


def read_json(path):
    return json.loads(Path(path).read_text())


def bounded(value, depth=0):
    if depth > 5:
        return "[nested details omitted; retained in original report]"
    if isinstance(value, dict):
        return {str(k): bounded(v, depth + 1) for k, v in list(value.items())[:30]}
    if isinstance(value, list):
        out = [bounded(v, depth + 1) for v in value[:8]]
        if len(value) > 8:
            out.append({"additional_items_omitted": len(value) - 8})
        return out
    if isinstance(value, str) and len(value) > 1000:
        return value[:1000] + " [truncated]"
    return value


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report", type=Path)
    args = parser.parse_args(argv)
    try:
        report = read_json(args.report)
    except (OSError, ValueError) as exc:
        print(json.dumps({"status": "REPORT_UNAVAILABLE", "error": str(exc)}, indent=2))
        return 1
    dataset = report.get("dataset", {})
    summary = {key: report.get(key) for key in
               ("stage", "status", "job_id", "started_utc", "finished_utc", "error")}
    summary["dataset_verified"] = dataset.get("dataset_verified", False)
    summary["splits"] = {
        name: {key: row.get(key) for key in
               ("count", "paper_eligible", "rejected_count", "known_missing_count")}
        for name, row in dataset.get("splits", {}).items()
    }
    smoke = report.get("smoke")
    if not isinstance(smoke, dict):
        path = args.report.parent / "smoke" / "smoke_status.json"
        if path.is_file():
            try:
                smoke = read_json(path)
            except (OSError, ValueError) as exc:
                smoke = {"error": f"Cannot read smoke report: {exc}"}
        else:
            smoke = {}
    summary["smoke"] = {key: smoke.get(key) for key in
                        ("status", "stage", "actual_device", "accepted_updates", "error", "scope")}
    data = smoke.get("data", {})
    selection = data.get("training_selection", smoke.get("training_selection", {}))
    if selection:
        summary["smoke"]["training_selection"] = bounded(selection)
    census = data.get("coordinate_census", smoke.get("coordinate_census"))
    if census:
        summary["smoke"]["coordinate_census"] = bounded(census)
    if smoke.get("updates"):
        summary["smoke"]["updates"] = [{key: row.get(key) for key in
            ("update", "loss", "gradient_norm", "accepted_graphs", "rejected_graphs")}
            for row in smoke["updates"]]
    failures = args.report.parent / "smoke" / "trainer" / "failures.jsonl"
    if failures.is_file():
        with failures.open() as stream:
            tail = list(deque((line for line in stream if line.strip()), maxlen=2))
        rows = []
        for line in tail:
            try:
                rows.append(bounded(json.loads(line)))
            except ValueError:
                rows.append({"unparsed_tail": line[:1000]})
        summary["last_geometry_failures"] = rows
    print(json.dumps(summary, indent=2))
    return 0 if report.get("status") == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
