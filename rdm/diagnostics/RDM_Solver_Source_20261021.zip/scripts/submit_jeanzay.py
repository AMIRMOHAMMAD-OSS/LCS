#!/usr/bin/env python3
"""Prepare inspectable Slurm submissions; submit only with explicit --submit."""
from __future__ import annotations
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def absolute(value: str) -> str:
    return str(Path(value).expanduser().resolve())


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['train', 'predict', 'official', 'evaluate', 'quantum'])
    p.add_argument('--account', required=True, help='Explicit allocated Slurm account, e.g. PROJECT@a100; never inferred from paths.')
    p.add_argument('--qos', required=True, help='Exact QoS allowed for your account; inspect local sacctmgr/sinfo.')
    p.add_argument('--env-file', help='Defaults to hpc/site.env; official inference defaults to hpc/official.env')
    p.add_argument('--data', help='Prepared local dataset directory')
    p.add_argument('--config', help='Training JSON configuration')
    p.add_argument('--output', required=True, help='Train: parent for seed_<N>; predict: NPZ file; evaluate: report directory; quantum: results directory')
    p.add_argument('--seeds', default='17,29,43', help='Independent training seeds, comma separated; each array task uses one GPU')
    p.add_argument('--checkpoint', help='Prediction checkpoint')
    p.add_argument('--official-source', help='Pinned authors\' source checkout for official inference')
    p.add_argument('--released-pt', help='Authors\' released PyG test dataset for official inference')
    p.add_argument('--official-model', choices=['rdm','edm'], default='rdm')
    p.add_argument('--nfe', type=int, default=128, help='Official baseline flow integration steps')
    p.add_argument('--batch-size', type=int, default=64, help='Official inference batch size')
    p.add_argument('--predictions', action='append', default=[], help='METHOD=path.npz; repeat to evaluate paired methods together')
    p.add_argument('--split', default='test', choices=['train','val','validation','test'])
    p.add_argument('--jobs', help='Quantum jobs.jsonl from quantum prepare')
    p.add_argument('--quantum-engine', default='pyscf', choices=['pyscf','gaussian'])
    p.add_argument('--gaussian-command', default='g09')
    p.add_argument('--tasks', type=int, default=100, help='Maximum quantum shards; capped by nonempty jobs lines')
    p.add_argument('--concurrent', type=int, default=3, help='Maximum running array tasks')
    p.add_argument('--cpus', type=int, default=None)
    p.add_argument('--quantum-memory-mb', type=int, default=12000)
    p.add_argument('--walltime', default='19:30:00')
    p.add_argument('--signal-seconds', type=int, default=600)
    p.add_argument('--dependency', help='Existing Slurm dependency expression, e.g. afterok:12345')
    p.add_argument('--max-updates', type=int, help='Optional CLI cap; use the same cap again on resume')
    p.add_argument('--preflight-report', help='Train --submit requires a fresh GPU PASS report for this exact config/data/environment')
    p.add_argument('--submit', action='store_true', help='Actually invoke sbatch. Otherwise write and print a reviewable submission.')
    return p


def main(argv=None) -> int:
    p=parser(); a=p.parse_args(argv)
    if a.env_file is None: a.env_file=str(ROOT/'hpc'/('official.env' if a.action=='official' else 'site.env'))
    cpu=a.action in {'evaluate','quantum'}
    suffix='@cpu' if cpu else '@a100'
    if not a.account.endswith(suffix): p.error(f'{a.action} requires explicit account ending {suffix}')
    if not re.fullmatch(r'[A-Za-z0-9_.@-]+',a.account): p.error('Invalid account name')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+',a.qos): p.error('Invalid QoS name')
    if a.concurrent < 1 or (a.cpus is not None and a.cpus < 1): p.error('Resource counts must be positive')
    if a.nfe < 1 or a.batch_size < 1: p.error('--nfe and --batch-size must be positive')
    if a.signal_seconds < 60: p.error('Allow at least60seconds for numerical solver/checkpoint shutdown')
    if not re.fullmatch(r'(?:\d+-)?\d+:\d{2}:\d{2}',a.walltime): p.error('Walltime must be [D-]HH:MM:SS')
    if a.split=='val': a.split='validation'
    required_paths=['env_file']+(['data'] if a.action!='quantum' else ['jobs'])
    if a.action=='train': required_paths+=['config']
    if a.action in {'predict','official'}: required_paths+=['checkpoint']
    if a.action=='official': required_paths+=['official_source','released_pt']
    for name in required_paths:
        val=getattr(a,name)
        if not val: p.error(f'--{name.replace("_","-")} is required for {a.action}')
        if not Path(val).expanduser().exists(): p.error(f'Path does not exist: {val}')
        setattr(a,name,absolute(val))
    if a.action=='evaluate':
        if not a.predictions: p.error('--predictions METHOD=path.npz is required for evaluate')
        normalized=[]; names=set()
        for value in a.predictions:
            if '=' not in value: p.error('Use --predictions METHOD=path.npz')
            name,filename=value.split('=',1)
            if not name or name=='reference' or name in names: p.error('Prediction method names must be unique and cannot be reference')
            if not Path(filename).expanduser().is_file(): p.error(f'Prediction file absent: {filename}')
            names.add(name); normalized.append(name+'='+absolute(filename))
        a.predictions=normalized
    if a.action=='train':
        try: seeds=[int(x.strip()) for x in a.seeds.split(',')]
        except ValueError: p.error('--seeds must contain integers')
        if not seeds or len(seeds)!=len(set(seeds)) or any(s<0 for s in seeds): p.error('Seeds must be distinct nonnegative integers')
        count=len(seeds)
        if a.submit and not a.preflight_report:
            p.error('Training submission blocked: --preflight-report GPU_REPORT is required. Complete CPU preflight then GPU smoke for this configuration.')
        if a.preflight_report:
            from rdm_drift.preflight import verify_report
            try:
                verify_report(a.preflight_report,'gpu',a.config,a.data,a.env_file,root=ROOT)
            except (ValueError,OSError,KeyError) as exc:
                p.error(str(exc))
            a.preflight_report=absolute(a.preflight_report)
    elif a.action=='quantum':
        if a.tasks < 1: p.error('--tasks must be positive')
        with open(a.jobs) as f: count=min(a.tasks,sum(bool(line.strip()) for line in f))
        if not count: p.error('Quantum jobs file has no jobs')
        seeds=[]
    else: count=1; seeds=[]
    cpus=a.cpus or (4 if cpu else 8)
    stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8]
    folder=ROOT/'submissions'/f'{a.action}_{stamp}'
    folder.mkdir(parents=True)
    logs=folder/'logs'; logs.mkdir()
    if a.config:
        # Protect a queued job from later edits to the working configuration.
        parsed=json.loads(Path(a.config).read_text())
        config_path=folder/'config.json'; config_path.write_text(json.dumps(parsed,indent=2)+'\n')
        a.config=str(config_path)
    payload=vars(a).copy()
    if a.action=='train' and a.preflight_report:
        # Preserve the exact PASS evidence used for submission while inputs are
        # reverified independently again on the allocated node.
        report_snapshot=folder/'gpu_preflight_report.json'
        shutil.copyfile(a.preflight_report,report_snapshot)
        payload['preflight_report']=str(report_snapshot)
    payload.update(package_root=str(ROOT),output=absolute(a.output),seed_list=seeds,task_count=count,cpus=cpus)
    path=folder/'payload.json'; path.write_text(json.dumps(payload,indent=2)+'\n')
    env_values={'RDM_SUBMISSION':str(path),'RDM_SITE_ENV':a.env_file,'RDM_PACKAGE_ROOT':str(ROOT),'RDM_JOB_KIND':'cpu' if cpu else 'gpu'}
    if any(',' in v or '\n' in v for v in env_values.values()): p.error('Slurm export paths cannot contain comma/newline')
    cmd=['sbatch','--parsable',f'--job-name=rdm_{a.action}',f'--account={a.account}',f'--qos={a.qos}',
         '--nodes=1','--ntasks=1',f'--cpus-per-task={cpus}','--hint=nomultithread',
         f'--time={a.walltime}',
         f'--output={logs}/%x_%A_%a.out',f'--error={logs}/%x_%A_%a.err',
         '--export=ALL,'+','.join(k+'='+v for k,v in env_values.items())]
    if not cpu: cmd+=['--constraint=a100','--gres=gpu:1']
    if a.action=='train': cmd += [f'--signal=USR1@{a.signal_seconds}']
    if count>1: cmd += [f'--array=0-{count-1}%{min(a.concurrent,count)}']
    if a.dependency: cmd += [f'--dependency={a.dependency}']
    cmd += [str(ROOT/'hpc/job.sbatch')]
    (folder/'command.txt').write_text(shlex.join(cmd)+'\n')
    print(json.dumps({'action':a.action,'array_tasks':count,'gpus_per_task':0 if cpu else 1,'cpus_per_task':cpus,
                      'walltime_per_task':a.walltime,'payload':str(path),'submitted':a.submit,
                      'preflight':'verified GPU PASS' if a.action=='train' and a.preflight_report else 'UNVERIFIED (dry run only)' if a.action=='train' else 'not a training submission'},indent=2))
    print(shlex.join(cmd),flush=True)
    if a.submit:
        if shutil.which('sbatch') is None: p.error('sbatch is unavailable; run this on Jean Zay')
        done=subprocess.run(cmd,text=True,capture_output=True)
        (folder/'sbatch.stdout').write_text(done.stdout)
        (folder/'sbatch.stderr').write_text(done.stderr)
        print(done.stdout,end=''); print(done.stderr,end='',file=__import__('sys').stderr)
        if done.returncode: return done.returncode
        (folder/'job_id.txt').write_text(done.stdout.strip()+'\n')
    return 0


if __name__=='__main__': raise SystemExit(main())

