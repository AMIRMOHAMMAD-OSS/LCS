#!/usr/bin/env bash
# Read-only discovery. No module loads, package installs or job submissions.
set -uo pipefail
printf '\nUser account associations and allowed QoS:\n'
if command -v sacctmgr >/dev/null 2>&1; then
  sacctmgr -nP show assoc where "user=${USER:?}" format=Cluster,Account,Partition,QOS,DefaultQOS || true
  printf '\nQoS definitions (an existing QoS is not proof your account may use it):\n'
  sacctmgr -nP show qos format=Name,MaxWall,MaxTRESPerUser || true
else
  echo 'sacctmgr unavailable; ask the site for your CPU account and its permitted QoS.'
fi
printf '\nPartitions:\n'
if command -v sinfo >/dev/null 2>&1; then
  sinfo -h -o '%P %a %l %D %G' || true
fi
printf '\nAvailable PyTorch and CPU architecture modules:\n'
if type module >/dev/null 2>&1; then
  module -t avail pytorch 2>&1 || true
  module -t avail arch 2>&1 || true
else
  echo 'The module command is not initialized in this shell.'
fi
printf '\nCPU account/QoS must be supplied explicitly to submit_preflight.py; no @cpu account is inferred.\n'
