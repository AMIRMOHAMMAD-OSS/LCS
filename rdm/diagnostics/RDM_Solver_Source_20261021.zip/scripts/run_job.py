#!/usr/bin/env python3
"""Offline Slurm step supervisor; forwards advance warning to the training process."""
from __future__ import annotations
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def atomic_json(path: Path, value: dict) -> None:
    temp=path.with_name(path.name+f'.{os.getpid()}.tmp')
    temp.write_text(json.dumps(value,indent=2,default=str)+'\n')
    os.replace(temp,path)


def command(payload: dict, index: int) -> tuple[list[str],Path]:
    p=payload; action=p['action']; out=Path(p['output'])
    cli=[sys.executable,'-u','-m','rdm_drift.cli']
    if action=='train':
        seed=p['seed_list'][index]; out=out/f'seed_{seed}'
        cmd=[sys.executable,'-u','-m','rdm_drift.train','--config',p['config'],'--data',p['data'],'--run-dir',str(out),'--resume','auto','--seed',str(seed),'--device','cuda']
        if p.get('max_updates') is not None: cmd+=['--max-updates',str(p['max_updates'])]
    elif action=='predict':
        out.parent.mkdir(parents=True,exist_ok=True)
        cmd=cli+['predict','--data',p['data'],'--split',p['split'],'--checkpoint',p['checkpoint'],'--output',str(out),'--device','cuda']
        out=out.parent
    elif action=='evaluate':
        cmd=[sys.executable,'-u','-m','rdm_drift.evaluate','--data-dir',p['data'],'--split',p['split'],'--out',str(out)]
        for value in p['predictions']: cmd+=['--predictions',value]
    elif action=='official':
        out.parent.mkdir(parents=True,exist_ok=True)
        cmd=[sys.executable,'-u','-m','rdm_drift.official','infer','--source',p['official_source'],
             '--checkpoint',p['checkpoint'],'--released-pt',p['released_pt'],'--data-dir',p['data'],
             '--split',p['split'],'--model',p['official_model'],'--device','cuda',
             '--nfe',str(p['nfe']),'--batch-size',str(p['batch_size']),'--output',str(out),'--resume']
        out=out.parent
    elif action=='quantum':
        cmd=[sys.executable,'-u','-m','rdm_drift.quantum','run','--jobs',p['jobs'],'--task-index',str(index),
             '--task-count',str(p['task_count']),'--out',str(out),'--threads',str(p['cpus']),
             '--memory-mb',str(p['quantum_memory_mb']),'--engine',p['quantum_engine']]
        if p['quantum_engine']=='gaussian': cmd+=['--gaussian-command',p['gaussian_command']]
    else: raise ValueError(action)
    return cmd,out


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--payload',required=True)
    args=parser.parse_args(); path=Path(args.payload); payload=json.loads(path.read_text())
    if payload['action']=='train':
        if not payload.get('preflight_report'):
            parser.error('Training blocked: payload has no GPU preflight PASS report. Use submit_preflight.py CPU then GPU, and submit_jeanzay.py --preflight-report.')
        from rdm_drift.preflight import verify_report
        try:
            verify_report(payload['preflight_report'],'gpu',payload['config'],payload['data'],payload['env_file'],
                          full_data=True,runtime=True,root=Path(payload['package_root']))
        except (ValueError,OSError,KeyError) as exc:
            parser.error(f'Training blocked before child launch: {exc}')
    index=int(os.environ.get('SLURM_ARRAY_TASK_ID','0'))
    if not 0<=index<payload['task_count']: raise ValueError('Array index outside payload')
    cmd,out=command(payload,index); out.mkdir(parents=True,exist_ok=True)
    metadata=dict(action=payload['action'],command=cmd,task_index=index,job_id=os.environ.get('SLURM_JOB_ID'),
                  array_job_id=os.environ.get('SLURM_ARRAY_JOB_ID'),start_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                  status='running',payload=str(path),output=str(out))
    statuspath=path.parent/f'task_{index}_status.json'; atomic_json(statuspath,metadata)
    child=None; pending=[]
    def on_signal(sig,frame):
        pending.append(sig)
        print(f'Received {signal.Signals(sig).name}; requesting cooperative child checkpoint.',flush=True)
        if child is not None and child.poll() is None:
            try: child.send_signal(sig)
            except ProcessLookupError: pass
    signal.signal(signal.SIGUSR1,on_signal); signal.signal(signal.SIGTERM,on_signal)
    start=time.monotonic()
    child=subprocess.Popen(cmd,cwd=payload['package_root'])
    for sig in pending:
        if child.poll() is None: child.send_signal(sig)
    code=child.wait()
    metadata.update(exit_code=code,elapsed_seconds=time.monotonic()-start,end_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                    signals=[signal.Signals(s).name for s in pending],status='complete' if code==0 else ('needs_resume' if code==75 else 'failed'))
    atomic_json(statuspath,metadata)
    if code==75:
        print('NEEDS_RESUME: checkpoint saved. Resubmit the same training configuration, output, and seeds.',flush=True)
    elif code: print(f'FAILED: child exit {code}; inspect logs before resubmitting.',flush=True)
    return code if code>=0 else 128-code


if __name__=='__main__': raise SystemExit(main())

