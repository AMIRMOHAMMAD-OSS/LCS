#!/usr/bin/env python3
"""Prepare CPU validation or short GPU smoke jobs; submit only with --submit."""
from __future__ import annotations
import argparse
import datetime as dt
import json
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage', choices=('cpu', 'gpu'))
    p.add_argument('--account', required=True, help='Explicit allocated account; CPU ending @cpu, GPU ending @a100')
    p.add_argument('--qos', required=True, help='Exact allowed QoS from your account association; no inferred defaults')
    p.add_argument('--config', required=True)
    p.add_argument('--data', required=True)
    p.add_argument('--env-file', default=str(ROOT / 'hpc/site.env'), help='Target training site environment whose content is bound to PASS')
    p.add_argument('--load-env-file', help='Optional loader configuration override; target runtime package versions must still match GPU training')
    p.add_argument('--load-env-kind', choices=('gpu', 'cpu'), default='gpu', help='load_env.sh branch; default reuses known training module/venv even on CPU without requesting any GPU')
    p.add_argument('--output', required=True, help='Dedicated output directory; report.json is written here')
    p.add_argument('--raw-root')
    p.add_argument('--prepare', action='store_true')
    p.add_argument('--force-rebuild', action='store_true')
    p.add_argument('--cpu-report')
    p.add_argument('--cpus', type=int, default=8)
    p.add_argument('--walltime', default='02:00:00')
    p.add_argument('--submit', action='store_true')
    return p


def execute_payload(path):
    from rdm_drift.preflight import run_stage
    payload = json.loads(Path(path).read_text())
    if payload.get('stage') not in ('cpu', 'gpu'):
        raise ValueError('Invalid preflight payload stage')
    options = {key: payload.get(key) for key in ('stage', 'config', 'data', 'env_file', 'output', 'raw_root', 'prepare', 'force_rebuild', 'cpu_report')}
    options['allow_local'] = False
    return run_stage(argparse.Namespace(**options))


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == '--run-payload':
        if len(argv) != 2:
            raise SystemExit('Usage: --run-payload /absolute/payload.json')
        return execute_payload(argv[1])
    p = parser()
    a = p.parse_args(argv)
    suffix = '@cpu' if a.stage == 'cpu' else '@a100'
    if not re.fullmatch(r'[A-Za-z0-9_.@-]+', a.account) or not a.account.endswith(suffix):
        p.error(f'{a.stage} requires an explicitly allowed account ending {suffix}; use scripts/discover_preflight_site.sh')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+', a.qos):
        p.error('Invalid QoS name')
    if a.cpus < 1 or not re.fullmatch(r'(?:\d+-)?\d+:\d{2}:\d{2}', a.walltime):
        p.error('Positive CPU count and [D-]HH:MM:SS walltime required')
    if a.stage == 'gpu' and (a.prepare or a.force_rebuild):
        p.error('Preparation/reconstruction is CPU-only')
    if a.force_rebuild and not a.prepare:
        p.error('--force-rebuild requires --prepare')
    if a.prepare and not a.raw_root:
        p.error('--prepare requires --raw-root pointing to the verified extracted release')
    if a.stage == 'gpu' and not a.cpu_report:
        p.error('GPU smoke requires --cpu-report; complete CPU preflight first')
    a.load_env_file = a.load_env_file or a.env_file
    if a.stage == 'gpu' and (Path(a.load_env_file).resolve() != Path(a.env_file).resolve() or a.load_env_kind != 'gpu'):
        p.error('GPU smoke must use the same GPU environment configuration as training')
    for key in ('config', 'env_file', 'load_env_file', 'raw_root', 'cpu_report'):
        value = getattr(a, key)
        if value:
            path = Path(value).expanduser().resolve()
            if not path.exists():
                p.error(f'Missing {key}: {path}')
            setattr(a, key, str(path))
    a.data = str(Path(a.data).expanduser().resolve())
    a.output = str(Path(a.output).expanduser().resolve())
    from rdm_drift.preflight_checks import validate_static
    try:
        validate_static(ROOT, [a.config])
        if a.stage == 'gpu':
            from rdm_drift.preflight import verify_report
            verify_report(a.cpu_report, 'cpu', a.config, a.data, a.env_file, root=ROOT)
    except (ValueError, OSError, KeyError) as exc:
        p.error(str(exc))
    stamp = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + uuid.uuid4().hex[:8]
    folder = ROOT / 'submissions' / f'preflight_{a.stage}_{stamp}'
    logs = folder / 'logs'
    logs.mkdir(parents=True)
    parsed = json.loads(Path(a.config).read_text())
    config = folder / 'config.json'
    config.write_text(json.dumps(parsed, indent=2) + '\n')
    a.config = str(config)
    payload = vars(a).copy()
    payload['package_root'] = str(ROOT)
    payloadpath = folder / 'payload.json'
    payloadpath.write_text(json.dumps(payload, indent=2) + '\n')
    env = {'RDM_PREFLIGHT_PAYLOAD': str(payloadpath), 'RDM_PACKAGE_ROOT': str(ROOT),
           'RDM_PREFLIGHT_STAGE': a.stage, 'RDM_SITE_ENV': a.load_env_file,
           'RDM_JOB_KIND': a.load_env_kind}
    if any(',' in value or '\n' in value for value in env.values()):
        p.error('Slurm export paths cannot contain commas/newlines')
    cmd = ['sbatch', '--parsable', f'--job-name=rdm_preflight_{a.stage}', f'--account={a.account}', f'--qos={a.qos}',
           '--nodes=1', '--ntasks=1', f'--cpus-per-task={a.cpus}', '--hint=nomultithread', f'--time={a.walltime}',
           f'--output={logs}/%x_%j.out', f'--error={logs}/%x_%j.err', '--export=ALL,' + ','.join(k + '=' + v for k, v in env.items())]
    if a.stage == 'gpu':
        cmd += ['--constraint=a100', '--gres=gpu:1']
    cmd += [str(ROOT / 'hpc/preflight.sbatch')]
    (folder / 'command.txt').write_text(shlex.join(cmd) + '\n')
    print(json.dumps({'stage': a.stage, 'submitted': a.submit, 'report': str(Path(a.output) / 'report.json'),
                      'gpus': int(a.stage == 'gpu'), 'payload': str(payloadpath),
                      'validation': 'CPU prerequisite verified' if a.stage == 'gpu' else 'Static checks only; runtime is not yet validated'}, indent=2))
    print(shlex.join(cmd), flush=True)
    if a.submit:
        if shutil.which('sbatch') is None:
            p.error('sbatch unavailable; run submission on Jean Zay')
        done = subprocess.run(cmd, text=True, capture_output=True)
        (folder / 'sbatch.stdout').write_text(done.stdout)
        (folder / 'sbatch.stderr').write_text(done.stderr)
        print(done.stdout, end='')
        print(done.stderr, end='', file=sys.stderr)
        if done.returncode:
            return done.returncode
        (folder / 'job_id.txt').write_text(done.stdout.strip() + '\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
