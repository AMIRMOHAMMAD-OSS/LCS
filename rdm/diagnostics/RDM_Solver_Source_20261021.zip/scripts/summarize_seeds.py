#!/usr/bin/env python3
"""Summarize independent training seeds without treating molecules as seeds."""
import argparse
import json
from pathlib import Path
import numpy as np


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--reports", nargs="+", required=True, help="One evaluation metrics.json per independently trained seed")
    p.add_argument("--method", default="drift")
    p.add_argument("--out", required=True)
    args = p.parse_args()
    if len(set(map(str, args.reports))) < 2:
        raise ValueError("Supply at least two distinct seed reports")
    reports = [json.loads(Path(path).read_text()) for path in args.reports]
    signatures = {(r.get("cohort_ids_sha256"), r.get("cohort"), r.get("primary_atom_correspondence"),
                   r.get("metadata", {}).get("dataset_split_sha256")) for r in reports}
    if len(signatures) != 1 or next(iter(signatures))[0] is None:
        raise ValueError("Seed reports must use identical verified cohort IDs, eligibility and symmetry conventions")
    methods = [r["methods"][args.method] for r in reports]
    output = {"method": args.method, "n_seeds": len(reports), "report_files": args.reports,
              "unit": "independent training seed; molecular observations are not pooled across seeds",
              "cohort_ids_sha256": reports[0]["cohort_ids_sha256"],
              "n_failed_by_seed": [m["n_failed"] for m in methods], "metrics": {}}
    if any(m["n_failed"] for m in methods):
        output["status"] = "Full-cohort seed summary withheld because at least one seed has failed predictions. Inspect reports or re-evaluate on an explicitly declared common cohort."
    else:
        output["status"] = "complete"
        keys = set.intersection(*(set(m["metrics"]) for m in methods))
        for key in sorted(keys):
            by_stat = {}
            for stat in ("mean", "median"):
                values = [m["metrics"][key][stat] for m in methods]
                if any(v is None for v in values):
                    continue
                by_stat[stat] = {"per_seed": values, "across_seed_mean": float(np.mean(values)),
                                 "across_seed_sample_std": float(np.std(values, ddof=1))}
            output["metrics"][key] = by_stat
    path = Path(args.out)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
