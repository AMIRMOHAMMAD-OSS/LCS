#!/usr/bin/env python3
"""Report measured pilot cost and eligibility for a heavy-run decision.

Never auto-submits jobs or converts CPU throughput into hypothetical GPU speed.
"""
import argparse
import json
import math
from pathlib import Path
import statistics


def quantile(values, p):
    values = sorted(values)
    index = (len(values) - 1) * p
    lo, hi = int(index), min(int(index) + 1, len(values) - 1)
    return values[lo] * (hi - index) + values[hi] * (index - lo) if hi > lo else values[lo]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--heavy-config", default="configs/heavy_intrinsic.json")
    parser.add_argument("--output")
    args = parser.parse_args()
    run = Path(args.run_dir)
    config = json.loads((run / "config.json").read_text())
    heavy = json.loads(Path(args.heavy_config).read_text())
    environment = json.loads((run / "environment.json").read_text())
    rows = [json.loads(s) for s in (run / "train.jsonl").read_text().splitlines() if s.strip()]
    if not rows:
        raise SystemExit("No completed optimizer updates; a cost projection is not available")
    # Discard only the first completed update for CUDA/module warmup.
    timed = rows[1:] if len(rows) > 1 else rows
    times = [r["update_seconds"] for r in timed]
    target = sorted(heavy["noise"]["schedule"], key=lambda r:r["fraction"])[-1]
    mismatches = []
    for path in (("objective",), ("model",), ("geometry",), ("drift",),
                 ("training","particles"), ("training","graphs_per_update")):
        left, right = config, heavy
        for part in path:
            left, right = left[part], right[part]
        if left != right:
            mismatches.append(".".join(path))
    for key in ("metric_sigma", "max_displacement_A"):
        if any(not math.isclose(r["noise"][key], target[key], abs_tol=1e-10) for r in timed):
            mismatches.append("noise." + key)
    last = rows[-1]
    acceptance = last["accepted_graphs"] / max(last["graph_attempts"], 1)
    cuda = str(environment.get("device", "")).startswith("cuda")
    enough = len(timed) >= 10
    gate = cuda and enough and not mismatches and acceptance >= heavy["training"]["minimum_graph_acceptance"]
    # Project measured per-update numerical work. Separately include measured
    # validation/checkpoint startup overhead from this run if it is available.
    updates = heavy["training"]["updates"]
    result = {"run_dir": str(run), "measured_device": environment.get("device_name"),
              "measured_device_type": environment.get("device"), "completed_updates": len(rows),
              "timed_updates_after_warmup": len(times), "graph_acceptance": acceptance,
              "matches_heavy_model_solver_batch_and_final_noise": not mismatches,
              "mismatches": mismatches, "minimum_10_timed_updates": enough,
              "numerical_and_cost_probe_passed": gate,
              "seconds_per_update": {"p10": quantile(times,.1), "median": statistics.median(times), "p90": quantile(times,.9)},
              "projected_heavy_training_hours_on_measured_device": {"median": statistics.median(times)*updates/3600,
                    "p90": quantile(times,.9)*updates/3600},
              "projected_updates": updates, "validation_and_checkpoint_overhead_excluded_from_projection": True,
              "actual_unique_training_graphs": last["unique_graphs_accepted"],
              "required_followup": "Inspect validation behavior and rejected molecule IDs, compare projected allocation cost, then explicitly submit the selected budget. Passing this gate is not proof of model quality or a guaranteed wall-time bound."}
    output = Path(args.output) if args.output else run / "cost_projection.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if gate else 2


if __name__ == "__main__":
    raise SystemExit(main())
