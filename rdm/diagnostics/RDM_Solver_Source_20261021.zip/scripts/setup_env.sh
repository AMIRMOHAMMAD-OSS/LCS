#!/usr/bin/env bash
# Environment preparation only: use a site-approved internet-enabled session.
set -euo pipefail
rdm_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
rdm_site_env="${1:-$rdm_root/hpc/site.env}"
shift || true
rdm_install_mode="${1:-online}"
rdm_wheels="${2:-$rdm_root/wheelhouse}"
export RDM_SETUP_ONLY=1
# shellcheck source=../hpc/load_env.sh
source "$rdm_root/hpc/load_env.sh" "$rdm_site_env"
python -c 'import torch; assert tuple(map(int,torch.__version__.split("+")[0].split(".")[:2])) >= (2,5), "PyTorch >=2.5 required"; print("Site torch:",torch.__version__,"CUDA:",torch.version.cuda)'
python -m venv --system-site-packages "$RDM_VENV"
# shellcheck source=/dev/null
source "$RDM_VENV/bin/activate"
case "$rdm_install_mode" in
  online)
    python -m pip install -r "$rdm_root/hpc/requirements-extra.txt"
    ;;
  download)
    mkdir -p "$rdm_wheels"
    python -m pip download --only-binary=:all: -r "$rdm_root/hpc/requirements-extra.txt" --dest "$rdm_wheels"
    echo "Wheels downloaded. Next: bash scripts/setup_env.sh '$rdm_site_env' offline '$rdm_wheels'"
    exit 0
    ;;
  offline)
    python -m pip install --no-index --find-links "$rdm_wheels" -r "$rdm_root/hpc/requirements-extra.txt"
    ;;
  *) echo 'Mode must be online, download, or offline.' >&2; exit 2 ;;
esac
python - <<'PY'
import json, pathlib, platform, os
import torch, numpy, scipy, rdkit, h5py
p = pathlib.Path(os.environ['RDM_VENV']) / 'rdm_environment.json'
p.write_text(json.dumps(dict(python=platform.python_version(),torch=torch.__version__,
    cuda=torch.version.cuda,numpy=numpy.__version__,scipy=scipy.__version__,
    rdkit=rdkit.__version__,h5py=h5py.__version__), indent=2)+'\n')
print(p.read_text())
PY
python -m pip freeze > "$RDM_VENV/rdm_pip_freeze.txt"
module -t list 2> "$RDM_VENV/rdm_modules.txt"
echo "Environment ready: $RDM_VENV"

