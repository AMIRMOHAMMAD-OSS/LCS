"""Numerical R-DM geometry on molecular shapes with fixed atom correspondence.

q_ij(x) = exp[-alpha (|x_i-x_j|/(r_i+r_j)-1)] + beta/(|x_i-x_j|/(r_i+r_j)).
The pullback metric J_q.T J_q has the six rigid-motion null directions. We
integrate horizontal geodesics using x'' = -J_q^+ Hess(q)[x',x'] and solve a
boundary-value problem for Log. A successful solve is a numerically certified
LOCAL geodesic branch; it is not a certificate of global distance minimality.

All solvers are float64, batched, device preserving, and stopped-gradient. No
feature-chord distance is substituted for a failed geodesic. Atom permutations
are not identified here: the primary task is indexed conformer refinement.
"""
from __future__ import annotations

import math
from functools import lru_cache

import torch


def _batch(x, radii=None):
    if not torch.is_tensor(x):
        x = torch.as_tensor(x, dtype=torch.float64)
    x = x.to(dtype=torch.float64)
    single = x.ndim == 2
    if single:
        x = x.unsqueeze(0)
    if x.ndim != 3 or x.shape[-1] != 3 or x.shape[-2] < 2:
        raise ValueError("Coordinates must have shape [B,N,3] or [N,3], N >= 2")
    if radii is None:
        return x, single
    radii = torch.as_tensor(radii, dtype=x.dtype, device=x.device)
    if radii.ndim == 1:
        radii = radii.unsqueeze(0)
    radii = radii.expand(x.shape[0], x.shape[1])
    if not bool(torch.isfinite(radii).all() and (radii > 0).all()):
        raise ValueError("Covalent radii must be finite and strictly positive (Angstrom)")
    return x, radii, single


def _restore(value, single):
    if single and torch.is_tensor(value) and value.ndim:
        return value[0]
    if single and isinstance(value, list):
        return value[0]
    return value


def _result(result, single):
    return {k: _restore(v, single) for k, v in result.items()}


@lru_cache(maxsize=64)
def _pair_indices(n, device):
    return torch.triu_indices(n, n, 1, device=device)


def _pairs(x, radii, alpha=1.7, beta=0.01):
    i, j = _pair_indices(x.shape[1], str(x.device))
    delta = x[:, i] - x[:, j]
    distance = torch.linalg.vector_norm(delta, dim=-1)
    safe_d = distance.clamp_min(1e-12)
    scale = radii[:, i] + radii[:, j]
    r = safe_d / scale
    e = torch.exp(-alpha * (r - 1))
    q = e + beta / r
    first = (-alpha * e - beta / r.square()) / scale
    second = (alpha * alpha * e + 2 * beta / r.pow(3)) / scale.square()
    return i, j, delta / safe_d[..., None], distance, r, q, first, second


def rdm_features(x, radii, alpha=1.7, beta=0.01):
    x, radii, single = _batch(x, radii)
    return _restore(_pairs(x, radii, alpha, beta)[5], single)


def rdm_jacobian(x, radii, alpha=1.7, beta=0.01):
    x, radii, single = _batch(x, radii)
    return _restore(_jacobian_batched(x, radii, alpha, beta), single)


def _jacobian_batched(x, radii, alpha=1.7, beta=0.01):
    i, j, unit, _, _, _, first, _ = _pairs(x, radii, alpha, beta)
    jac = x.new_zeros(x.shape[0], i.numel(), x.shape[1], 3)
    row = torch.arange(i.numel(), device=x.device)
    derivative = first[..., None] * unit
    jac[:, row, i] = derivative
    jac[:, row, j] = -derivative
    return jac.flatten(-2)


def rdm_hessian_vv(x, v, radii, alpha=1.7, beta=0.01):
    x, radii, single = _batch(x, radii)
    v, _ = _batch(v)
    return _restore(_hessian_batched(x, v, radii, alpha, beta), single)


def _hessian_batched(x, v, radii, alpha=1.7, beta=0.01):
    i, j, unit, distance, _, _, first, second = _pairs(x, radii, alpha, beta)
    dv = v[:, i] - v[:, j]
    radial = (unit * dv).sum(-1)
    out = second * radial.square() + first / distance.clamp_min(1e-12) * (
        dv.square().sum(-1) - radial.square())
    return out


def metric_covector(x, v, radii, alpha=1.7, beta=0.01):
    x, radii, single = _batch(x, radii)
    v, _ = _batch(v)
    j = rdm_jacobian(x, radii, alpha, beta)
    jv = torch.bmm(j, v.flatten(1).unsqueeze(-1))
    out = torch.bmm(j.transpose(-1, -2), jv).squeeze(-1).reshape_as(x)
    return _restore(out, single)


def metric_norm(x, v, radii, alpha=1.7, beta=0.01):
    x, radii, single = _batch(x, radii)
    v, _ = _batch(v)
    return _restore(_metric_norm_batched(x, v, radii, alpha, beta), single)


def _metric_norm_batched(x, v, radii, alpha=1.7, beta=0.01):
    jv = torch.bmm(_jacobian_batched(x, radii, alpha, beta), v.flatten(1).unsqueeze(-1))
    return torch.linalg.vector_norm(jv.squeeze(-1), dim=-1)


def _svd(x, radii, alpha=1.7, beta=0.01, rank_rtol=1e-10, min_ratio=0.10):
    finite = torch.isfinite(x).flatten(1).all(-1)
    safe = torch.where(finite[:, None, None], x, torch.zeros_like(x))
    j = _jacobian_batched(safe, radii, alpha, beta)
    u, s, vh = torch.linalg.svd(j, full_matrices=False)
    wanted = 3 * x.shape[1] - 6
    threshold = s[:, :1] * rank_rtol
    rank = (s > threshold.clamp_min(1e-14)).sum(-1)
    min_pair_ratio = _pairs(safe, radii, alpha, beta)[4].min(-1).values
    valid = finite & (rank == wanted) & (min_pair_ratio > min_ratio)
    return j, u[:, :, :wanted], s[:, :wanted], vh[:, :wanted], valid, rank


def horizontal_basis(x, radii, alpha=1.7, beta=0.01, rank_rtol=1e-10, min_ratio=0.10):
    """Return both metric-orthonormal and Euclidean-orthonormal horizontal bases."""
    x, radii, single = _batch(x, radii)
    _, _, s, vh, valid, rank = _svd(x, radii, alpha, beta, rank_rtol, min_ratio)
    euclidean = vh.transpose(-1, -2)
    basis = euclidean / s.clamp_min(1e-14)[:, None, :]
    # Diagnostic only: never truncate extra directions or alter the metric.
    condition = (torch.where(s[:, -1] > 0, s[:, 0] / s[:, -1], torch.inf)
                 if s.shape[-1] else x.new_full((x.shape[0],), torch.inf))
    return _result(dict(basis=basis, euclidean_basis=euclidean,
                        singular_values=s, condition_number=condition,
                        valid=valid, rank=rank), single)


def horizontal_projection(x, v, radii, alpha=1.7, beta=0.01):
    x, radii, single = _batch(x, radii)
    v, _ = _batch(v)
    b = horizontal_basis(x, radii, alpha, beta)["euclidean_basis"]
    out = (b @ (b.transpose(-1, -2) @ v.flatten(1).unsqueeze(-1))).reshape_as(x)
    return _restore(out, single)


def proper_align(source, target):
    """Align source to target by translation and a proper rotation, never reflection."""
    source, single = _batch(source)
    target, _ = _batch(target)
    target = target.expand_as(source)
    sm = source.mean(-2, keepdim=True)
    tm = target.mean(-2, keepdim=True)
    a, b = source - sm, target - tm
    u, _, vh = torch.linalg.svd(a.transpose(-1, -2) @ b)
    sign = torch.ones(source.shape[0], 3, dtype=source.dtype, device=source.device)
    sign[:, -1] = torch.where(torch.linalg.det(u @ vh) < 0, -1., 1.)
    rotation = (u * sign[:, None, :]) @ vh
    return _restore(a @ rotation + tm, single)


def quotient_rmsd(x, y):
    x, single = _batch(x)
    y, _ = _batch(y)
    value = (proper_align(x, y) - y).square().sum(-1).mean(-1).sqrt()
    return _restore(value, single)


def _acceleration(x, v, radii, alpha, beta, rank_rtol, min_ratio):
    _, u, s, vh, valid, rank = _svd(x, radii, alpha, beta, rank_rtol, min_ratio)
    h = _hessian_batched(x, v, radii, alpha, beta)
    h = torch.nan_to_num(h)
    coefficients = (u.transpose(-1, -2) @ h.unsqueeze(-1)).squeeze(-1) / s.clamp_min(1e-14)
    a = -(vh.transpose(-1, -2) @ coefficients.unsqueeze(-1)).reshape_as(x)
    valid = valid & torch.isfinite(a).flatten(1).all(-1) & torch.isfinite(v).flatten(1).all(-1)
    return torch.where(valid[:, None, None], a, torch.zeros_like(a)), valid, rank


@torch.no_grad()
def _integrate(x, v, radii, n_steps=8, alpha=1.7, beta=0.01,
               rank_rtol=1e-10, min_ratio=0.10, trajectory=False):
    """RK4 for the induced metric. Invalid rows are masked, not silently repaired."""
    if n_steps < 1:
        raise ValueError("n_steps must be positive")
    initial = x
    initial_speed = _metric_norm_batched(x, v, radii, alpha, beta)
    ok = torch.isfinite(x).flatten(1).all(-1) & torch.isfinite(v).flatten(1).all(-1)
    speed_error = x.new_zeros(x.shape[0])
    points = [x.clone()] if trajectory else None
    step = 1. / n_steps
    for _ in range(n_steps):
        a1, v1, rank = _acceleration(x, v, radii, alpha, beta, rank_rtol, min_ratio)
        k2v = v + .5 * step * a1
        a2, v2, _ = _acceleration(x + .5 * step * v, k2v, radii, alpha, beta, rank_rtol, min_ratio)
        k3v = v + .5 * step * a2
        a3, v3, _ = _acceleration(x + .5 * step * k2v, k3v, radii, alpha, beta, rank_rtol, min_ratio)
        k4v = v + step * a3
        a4, v4, _ = _acceleration(x + step * k3v, k4v, radii, alpha, beta, rank_rtol, min_ratio)
        new_x = x + step / 6 * (v + 2 * k2v + 2 * k3v + k4v)
        new_v = v + step / 6 * (a1 + 2 * a2 + 2 * a3 + a4)
        stage_ok = v1 & v2 & v3 & v4 & torch.isfinite(new_x).flatten(1).all(-1)
        ok &= stage_ok
        x = torch.where(ok[:, None, None], new_x, initial)
        v = torch.where(ok[:, None, None], new_v, torch.zeros_like(v))
        speed = _metric_norm_batched(x, v, radii, alpha, beta)
        error = (speed - initial_speed).abs() / initial_speed.clamp_min(1e-12)
        speed_error = torch.maximum(speed_error, error)
        if trajectory:
            points.append(x.clone())
    result = dict(point=x, velocity=v, valid=ok, speed_error=speed_error,
                  rank=rank, initial_speed=initial_speed)
    if trajectory:
        result["trajectory"] = torch.stack(points, 1)
    return result


@torch.no_grad()
def exp_map(x, v, radii, n_steps=8, atol=1e-3, rtol=5e-3,
            alpha=1.7, beta=0.01, rank_rtol=1e-10, min_ratio=0.10,
            check=True, trajectory=False, horizontal_tolerance=1e-7):
    """Numerical Exp with step-doubling, metric-speed and horizontality checks.

    ``atol`` bounds quotient RMSD between n and 2n step endpoints (Angstrom),
    ``rtol`` bounds relative metric speed drift. Returned endpoint uses 2n steps
    if check=True. Inputs must be horizontal; no large vertical part is discarded.
    """
    x, radii, single = _batch(x, radii)
    v, _ = _batch(v)
    x, v = x.detach(), v.detach().expand_as(x)
    basis = horizontal_basis(x, radii, alpha, beta, rank_rtol, min_ratio)
    e = basis["euclidean_basis"]
    projected = (e @ (e.transpose(-1, -2) @ v.flatten(1).unsqueeze(-1))).reshape_as(v)
    horizontal_error = (projected-v).flatten(1).norm(dim=-1) / v.flatten(1).norm(dim=-1).clamp_min(1e-12)
    options = dict(alpha=alpha, beta=beta, rank_rtol=rank_rtol, min_ratio=min_ratio)
    coarse = _integrate(x, projected, radii, n_steps, **options)
    out = _integrate(x, projected, radii, 2*n_steps, trajectory=trajectory, **options) if check else coarse
    grid_error = quotient_rmsd(coarse["point"], out["point"]) if check else x.new_zeros(x.shape[0])
    # Failed integrator rows internally reset to the initial point for batching.
    # Agreement between two such placeholders is not an endpoint certificate.
    integrated = out["valid"] & coarse["valid"] & basis["valid"]
    grid_error = torch.where(integrated, grid_error, torch.nan)
    valid = out["valid"] & coarse["valid"] & basis["valid"]
    valid &= (horizontal_error <= horizontal_tolerance)
    if check:
        valid &= (grid_error <= atol) & (out["speed_error"] <= rtol)
    reasons = []
    for k in range(x.shape[0]):
        if not bool(basis["valid"][k]):
            reasons.append("rank_or_collision")
        elif float(horizontal_error[k]) > horizontal_tolerance:
            reasons.append("nonhorizontal_velocity")
        elif not bool(out["valid"][k] and coarse["valid"][k]):
            reasons.append("integration_failed")
        elif check and float(grid_error[k]) > atol:
            reasons.append("step_doubling_error")
        elif check and float(out["speed_error"][k]) > rtol:
            reasons.append("metric_speed_error")
        else:
            reasons.append("ok")
    out.update(coarse_integration_valid=coarse["valid"],
               fine_integration_valid=out["valid"],
               base_singular_values=basis["singular_values"],
               base_condition_number=basis["condition_number"],
               base_rank=basis["rank"],
               valid=valid, grid_error=grid_error, horizontal_error=horizontal_error, reason=reasons)
    out["point"] = torch.where(valid[:, None, None], out["point"], torch.nan)
    out["velocity"] = torch.where(valid[:, None, None], out["velocity"], torch.nan)
    if "trajectory" in out:
        out["trajectory"] = torch.where(valid[:, None, None, None],out["trajectory"],torch.nan)
    return _result(out, single)


def _endpoint_chunks(x, tangent, radii, n_steps, max_batch_size, options):
    values, oks = [], []
    for start in range(0, x.shape[0], max_batch_size):
        result = _integrate(x[start:start+max_batch_size], tangent[start:start+max_batch_size],
                            radii[start:start+max_batch_size], n_steps, **options)
        values.append(result["point"])
        oks.append(result["valid"])
    return torch.cat(values), torch.cat(oks)


@torch.no_grad()
def log_map(x, y, radii, n_steps=8, max_iter=8, tolerance=1e-3,
            fd_eps=2e-4, damping=1e-3, max_batch_size=64,
            alpha=1.7, beta=0.01, rank_rtol=1e-10, min_ratio=0.10,
            exp_atol=None, speed_tolerance=5e-3, initial_velocity=None,
            max_step_rmsd=0.25):
    """Solve Exp_x(v)=y modulo proper rigid motions by damped Gauss-Newton.

    Unknowns are horizontal velocity coefficients in a Euclidean orthonormal
    basis. Endpoint Jacobians use batched finite differences (on GPU if x is on
    GPU), and every trial evaluates the real geodesic ODE. There is no straight-
    chord/feature distance fallback. Results only certify a local geodesic branch.
    ``max_batch_size`` bounds simultaneous finite-difference trajectories.
    """
    x, radii, single = _batch(x, radii)
    y, _ = _batch(y)
    y = y.to(device=x.device).expand_as(x).detach()
    x = x.detach()
    if not (max_iter >= 0 and fd_eps > 0 and damping > 0 and tolerance > 0 and max_batch_size >= 1):
        raise ValueError("Invalid shooting configuration")
    b, n, _ = x.shape
    d = 3*n - 6
    basis_info = horizontal_basis(x, radii, alpha, beta, rank_rtol, min_ratio)
    basis = basis_info["euclidean_basis"]
    y_finite = torch.isfinite(y).flatten(1).all(-1)
    y_safe = torch.where(y_finite[:, None, None], y, x)
    aligned = proper_align(y_safe, x)
    start = aligned - x if initial_velocity is None else _batch(initial_velocity)[0].expand_as(x)
    coeff = (basis.transpose(-1, -2) @ start.flatten(1).unsqueeze(-1)).squeeze(-1)
    live = basis_info["valid"] & y_finite
    lam = x.new_full((b,), damping)
    iterations = torch.zeros(b, dtype=torch.long, device=x.device)
    options = dict(alpha=alpha, beta=beta, rank_rtol=rank_rtol, min_ratio=min_ratio)

    def solve_endpoint(c, ids):
        tangent = (basis[ids] @ c.unsqueeze(-1)).reshape(-1,n,3)
        points, good = _endpoint_chunks(x[ids], tangent, radii[ids], n_steps,
                                        max_batch_size, options)
        residual = (proper_align(points, y_safe[ids]) - y_safe[ids]).flatten(1)
        return residual, good

    all_ids = torch.arange(b, device=x.device)
    residual, integrate_ok = solve_endpoint(coeff, all_ids)
    error = residual.square().sum(-1).div(n).sqrt()
    for iteration in range(max_iter):
        ids = torch.where(live & ((error > tolerance*.25) | ~integrate_ok))[0]
        if ids.numel() == 0:
            break
        iterations[ids] = iteration+1
        c = coeff[ids]
        # Forward differences use an actual BVP endpoint map, in Angstrom units.
        perturb = torch.eye(d, dtype=x.dtype, device=x.device)*fd_eps
        test_coeff = (c[:,None,:] + perturb[None,:,:]).reshape(-1,d)
        test_ids = ids.repeat_interleave(d)
        shifted, shifted_ok = solve_endpoint(test_coeff, test_ids)
        jac = ((shifted.reshape(ids.numel(),d,3*n)-residual[ids,None,:])/fd_eps).transpose(-1,-2)
        usable = shifted_ok.reshape(ids.numel(),d).all(-1) & integrate_ok[ids]
        # A failed large initial chord is contracted and retried, never accepted.
        if bool((~usable).any()):
            bad_ids = ids[~usable]
            coeff[bad_ids] *= .5
            residual[bad_ids], integrate_ok[bad_ids] = solve_endpoint(coeff[bad_ids],bad_ids)
            error[bad_ids] = residual[bad_ids].square().sum(-1).div(n).sqrt()
        good_ids = ids[usable]
        if good_ids.numel() == 0:
            continue
        j = jac[usable]
        jt = j.transpose(-1,-2)
        normal = jt@j
        diagonal = normal.diagonal(dim1=-2,dim2=-1).clamp_min(1e-8)
        regularized = normal + torch.diag_embed(lam[good_ids,None]*diagonal)
        gradient = (jt@residual[good_ids,:,None]).squeeze(-1)
        step = torch.linalg.solve(regularized, -gradient.unsqueeze(-1)).squeeze(-1)
        rms = step.norm(dim=-1)/math.sqrt(n)
        step *= (max_step_rmsd/rms.clamp_min(1e-12)).clamp(max=1)[:,None]
        scales = x.new_tensor([1.,.5,.25,.125])
        candidates = coeff[good_ids,None,:] + scales[None,:,None]*step[:,None,:]
        trial_residual, trial_ok = solve_endpoint(candidates.reshape(-1,d),good_ids.repeat_interleave(4))
        trial_error = trial_residual.square().sum(-1).div(n).sqrt().reshape(-1,4)
        trial_error = torch.where(trial_ok.reshape(-1,4),trial_error,torch.inf)
        best_error, best_index = trial_error.min(-1)
        improved = best_error < error[good_ids]
        if bool(improved.any()):
            accept = good_ids[improved]
            row = torch.arange(good_ids.numel(), device=x.device)[improved]
            col = best_index[improved]
            coeff[accept] = candidates[row,col]
            residual[accept] = trial_residual.reshape(-1,4,3*n)[row,col]
            error[accept] = best_error[improved]
            integrate_ok[accept] = True
        lam[good_ids] = torch.where(improved,lam[good_ids]*.3,lam[good_ids]*10).clamp(1e-9,1e8)

    velocity = (basis@coeff.unsqueeze(-1)).reshape_as(x)
    certificate = exp_map(x,velocity,radii,n_steps=n_steps,
                          atol=tolerance*.5 if exp_atol is None else exp_atol,
                          rtol=speed_tolerance,alpha=alpha,beta=beta,
                          rank_rtol=rank_rtol,min_ratio=min_ratio,check=True)
    safe_point = torch.where(certificate["valid"][:,None,None],certificate["point"],x)
    endpoint_rmsd = quotient_rmsd(safe_point,y_safe)
    endpoint_rmsd = torch.where(certificate["valid"],endpoint_rmsd,torch.inf)
    valid = live & certificate["valid"] & (endpoint_rmsd <= tolerance)
    distance = metric_norm(x,velocity,radii,alpha,beta)
    reasons = []
    for k in range(b):
        if not bool(live[k]):
            reasons.append("invalid_base_or_target")
        elif not bool(certificate["valid"][k]):
            reasons.append(certificate["reason"][k])
        elif float(endpoint_rmsd[k]) > tolerance:
            reasons.append("shooting_not_converged")
        else:
            reasons.append("ok")
    return _result(dict(log=torch.where(valid[:,None,None],velocity,torch.nan),
                        distance=torch.where(valid,distance,torch.nan),valid=valid,
                        endpoint_rmsd=endpoint_rmsd,iterations=iterations,
                        speed_error=certificate["speed_error"],grid_error=certificate["grid_error"],
                        rank=basis_info["rank"],reason=reasons,
                        base_singular_values=certificate["base_singular_values"],
                        base_condition_number=certificate["base_condition_number"],
                        base_rank=certificate["base_rank"],
                        coarse_integration_valid=certificate["coarse_integration_valid"],
                        fine_integration_valid=certificate["fine_integration_valid"],
                        branch="local_numerical_no_global_minimum_certificate"),single)

