"""Intrinsic R-DM metric drifting research implementation."""
__version__='0.1.0'
