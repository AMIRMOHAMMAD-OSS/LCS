"""Paired, failure-aware QM9M structure-refinement evaluation.

Kabsch uses proper rotations. The default reproduces the released R-DM SMARTS
permutation enumeration; fixed-order metrics are always retained separately.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
from typing import Mapping

import numpy as np


METRICS = ("rmsd_all_A", "d_mae_A", "q_chord_l2", "rmsd_heavy_A",
           "fixed_rmsd_all_A", "fixed_d_mae_A", "fixed_q_chord_l2")


def json_write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _array(value, dtype=None):
    if hasattr(value, "detach"):
        value = value.detach().cpu().numpy()
    return np.asarray(value, dtype=dtype)


def reference_position(record):
    x = _array(record["positions"], np.float64)
    if x.ndim == 3:
        if x.shape[0] != 1:
            raise ValueError("Paired QM9 evaluation requires one reference per id; conformer ensembles need a different protocol.")
        x = x[0]
    z = _array(record["Z"], np.int64)
    if x.shape != (len(z), 3) or not np.isfinite(x).all():
        raise ValueError(f"Malformed reference geometry for {record['id']}")
    return x


def load_records(data_dir, split="test"):
    path = Path(data_dir)
    if path.suffix == ".npz":
        # The same packed schema is accepted without importing a Torch dataset.
        with np.load(path, allow_pickle=False) as data:
            required = {"id", "Z", "n_atoms", "positions"}
            if not required.issubset(data.files):
                raise ValueError(f"Dataset missing {required - set(data.files)}")
            records = []
            for i, rid in enumerate(data["id"]):
                n = int(data["n_atoms"][i])
                r = {"id": str(rid), "Z": data["Z"][i, :n], "positions": data["positions"][i, :n]}
                for k in ("radii", "initial_positions", "bonds"):
                    if k in data:
                        r[k] = data[k][i, :n, :n] if k == "bonds" else data[k][i, :n]
                for k in ("smarts", "smiles", "exclusion_reason"):
                    if k in data:
                        r[k] = str(data[k][i])
                if "paper_eligible" in data:
                    r["paper_eligible"] = bool(data["paper_eligible"][i])
                records.append(r)
    else:
        from .data import load_split
        records = list(load_split(path, split))
    ids = [str(r["id"]) for r in records]
    if len(set(ids)) != len(ids):
        raise ValueError("Evaluation ids must be unique; duplicate conformers require explicit distinct ids.")
    return records


def save_predictions(records, positions, output, valid=None, status=None, metadata=None):
    """Write portable non-pickle predictions in stable record order."""
    records = list(records)
    if len(records) != len(positions):
        raise ValueError("Prediction count differs from record count")
    width = max((len(r["Z"]) for r in records), default=0)
    xyz = np.full((len(records), width, 3), np.nan, dtype=np.float64)
    zs = np.zeros((len(records), width), np.int64)
    sizes = np.array([len(r["Z"]) for r in records], np.int64)
    ids = np.asarray([str(r["id"]) for r in records], dtype=str)
    valid = np.ones(len(records), bool) if valid is None else np.asarray(valid, bool).copy()
    status = ["ok"] * len(records) if status is None else list(map(str, status))
    if len(valid) != len(records) or len(status) != len(records):
        raise ValueError("valid/status count differs from record count")
    for i, (r, pred) in enumerate(zip(records, positions)):
        n = sizes[i]
        zs[i, :n] = _array(r["Z"], np.int64)
        if pred is None:
            valid[i] = False
            status[i] = "missing_prediction"
            continue
        x = _array(pred, np.float64)
        if x.shape != (n, 3):
            raise ValueError(f"Wrong prediction shape for {ids[i]}: {x.shape}")
        xyz[i, :n] = x
        if not np.isfinite(x).all():
            valid[i] = False
            status[i] = "nonfinite_prediction"
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, id=ids, Z=zs, n_atoms=sizes, positions=xyz,
                        valid=valid, status=np.asarray(status, str))
    json_write(path.with_suffix(".metadata.json"), metadata or {})


def load_predictions(path, records, allow_extra=False):
    """Join by id and verify every predicted atom's atomic number and order."""
    records = list(records)
    expected = {str(r["id"]): r for r in records}
    with np.load(path, allow_pickle=False) as data:
        required = {"id", "Z", "n_atoms", "positions", "valid"}
        if not required.issubset(data.files):
            raise ValueError(f"Predictions missing {required - set(data.files)}. Anonymous arrays cannot establish atom correspondence.")
        ids = list(map(str, data["id"]))
        if len(set(ids)) != len(ids):
            raise ValueError("Duplicate prediction ids")
        extra = set(ids) - set(expected)
        if extra and not allow_extra:
            raise ValueError(f"Predictions contain {len(extra)} ids outside selected split")
        out = {}
        for i, rid in enumerate(ids):
            if rid not in expected:
                continue
            z = _array(expected[rid]["Z"], np.int64)
            n = int(data["n_atoms"][i])
            if n != len(z) or not np.array_equal(data["Z"][i, :n], z):
                raise ValueError(f"Atom count or ordered atomic numbers differ for {rid}")
            x = np.asarray(data["positions"][i, :n], np.float64)
            if x.shape != (n, 3):
                raise ValueError(f"Prediction geometry shape differs for {rid}")
            ok = bool(data["valid"][i]) and bool(np.isfinite(x).all())
            reason = str(data["status"][i]) if "status" in data else "ok" if ok else "prediction_failed"
            if not np.isfinite(x).all():
                reason = "nonfinite_prediction"
            out[rid] = {"positions": x, "valid": ok, "status": reason}
    for rid in expected:
        out.setdefault(rid, {"positions": None, "valid": False, "status": "missing_prediction"})
    return out


def kabsch_rmsd(pred, reference):
    pred = np.asarray(pred, np.float64)
    reference = np.asarray(reference, np.float64)
    a = pred - pred.mean(axis=0)
    b = reference - reference.mean(axis=0)
    u, _, vh = np.linalg.svd(a.T @ b)
    correction = np.eye(3)
    correction[-1, -1] = np.linalg.det(u @ vh)
    aligned = a @ (u @ correction @ vh)
    return float(np.sqrt(np.mean(np.sum((aligned - b) ** 2, axis=-1))))


def symmetry_permutations(record, mode="paper", cap=1000):
    """Paper reproduces the published SMARTS matching convention, including cap.

    The separate strict mode requests one extra candidate and rejects truncation.
    Chirality is checked on a molecule reconstructed from fixed-order reference
    coordinates. Never silently use symmetry equivalence across different graphs.
    """
    z = _array(record["Z"], np.int64)
    if mode == "fixed":
        return [tuple(range(len(z)))], {"mode": "fixed", "cap_hit": False}
    from rdkit import Chem
    if mode == "paper":
        if not record.get("smarts"):
            raise ValueError("Paper-compatible symmetry requires released atom-mapped smarts; use --symmetry fixed explicitly for datasets without it")
        all_matches = []
        cap_hit = False
        for part in str(record["smarts"]).split(">>"):
            mol = Chem.MolFromSmarts(part)
            if mol is None or mol.GetNumAtoms() != len(z):
                raise ValueError("Invalid released SMARTS")
            maps = np.array([a.GetAtomMapNum() for a in mol.GetAtoms()]) - 1
            if set(maps.tolist()) != set(range(len(z))):
                raise ValueError("SMARTS atom maps do not define a bijection to XYZ indices")
            matches = mol.GetSubstructMatches(mol, uniquify=False, useChirality=False, maxMatches=1000)
            cap_hit |= len(matches) == 1000
            inv = np.argsort(maps)
            all_matches.append({tuple(maps[np.array(m)[inv]].tolist()) for m in matches})
        if len(all_matches) not in (1, 2):
            raise ValueError("Invalid SMARTS reaction layout")
        matches = sorted(set.intersection(*all_matches))
    else:
        from rdkit.Chem import rdDetermineBonds
        xyz = reference_position(record)
        pt = Chem.GetPeriodicTable()
        block = f"{len(z)}\nreference\n" + "\n".join(f"{pt.GetElementSymbol(int(a))} {p[0]:.14g} {p[1]:.14g} {p[2]:.14g}" for a, p in zip(z, xyz))
        mol = Chem.MolFromXYZBlock(block)
        rdDetermineBonds.DetermineBonds(mol, charge=int(record.get("charge", 0)), allowChargedFragments=True, embedChiral=True)
        matches = list(mol.GetSubstructMatches(mol, uniquify=False, useChirality=True, maxMatches=cap + 1))
        cap_hit = len(matches) > cap
        if cap_hit:
            raise ValueError(f"Strict automorphism enumeration exceeds {cap}; evaluation refused truncated group")
        matches = sorted(set(matches))
    if not matches or any(not np.array_equal(z[list(p)], z) for p in matches):
        raise ValueError("Invalid or empty atomic-number-preserving symmetry group")
    return matches, {"mode": mode, "cap_hit": cap_hit, "n_permutations": len(matches),
                     "chirality_preserved": mode == "strict", "paper_max_matches": 1000 if mode == "paper" else None}


def structure_metrics(pred, ref, z, radii=None):
    pred, ref, z = _array(pred, np.float64), _array(ref, np.float64), _array(z, np.int64)
    if pred.shape != ref.shape or pred.shape != (len(z), 3):
        raise ValueError("Structure shape mismatch")
    i, j = np.triu_indices(len(z), 1)
    dp = np.linalg.norm(pred[i] - pred[j], axis=-1)
    dr = np.linalg.norm(ref[i] - ref[j], axis=-1)
    if (dp <= 1e-8).any() or (dr <= 1e-8).any():
        raise ValueError("Coincident atoms: undefined q metric")
    if radii is None:
        from rdkit import Chem
        pt = Chem.GetPeriodicTable()
        radii = np.array([pt.GetRcovalent(int(a)) for a in z])
    radii = _array(radii, np.float64)
    if radii.shape != (len(z),) or (radii <= 0).any():
        raise ValueError("Invalid covalent radii")
    scale = radii[i] + radii[j]
    rp, rr = dp / scale, dr / scale
    qp = np.exp(-1.7 * (rp - 1)) + .01 / rp
    qr = np.exp(-1.7 * (rr - 1)) + .01 / rr
    heavy = z != 1
    return {"rmsd_all_A": kabsch_rmsd(pred, ref),
            "d_mae_A": float(np.mean(np.abs(dp - dr))) if len(dp) else 0.,
            "q_chord_l2": float(np.linalg.norm(qp - qr)),
            "rmsd_heavy_A": kabsch_rmsd(pred[heavy], ref[heavy]) if heavy.any() else None}


def summarize(values, seed=2026, n_bootstrap=2000):
    values = np.asarray([v for v in values if v is not None and np.isfinite(v)], np.float64)
    if not len(values):
        return {"n": 0, "mean": None, "median": None, "mean_ci95": None, "median_ci95": None}
    means, medians = [], []
    rng = np.random.default_rng(seed)
    # Avoid allocating 2000 x 10000 per metric; each draw is a molecule bootstrap.
    for _ in range(n_bootstrap):
        draw = values[rng.integers(0, len(values), len(values))]
        means.append(np.mean(draw))
        medians.append(np.median(draw))
    return {"n": len(values), "mean": float(np.mean(values)), "median": float(np.median(values)),
            "mean_ci95": np.quantile(means, [.025, .975]).tolist() if means else None,
            "median_ci95": np.quantile(medians, [.025, .975]).tolist() if medians else None}


def evaluate(records, predictions: Mapping, out, metadata=None, n_bootstrap=2000, seed=2026, symmetry="paper", symmetry_cap=4096, cohort="all"):
    """Evaluate all methods on the same references without discarding failure ids."""
    records = list(records)
    if cohort not in ("all", "paper"):
        raise ValueError("cohort must be all or paper")
    selected_ids = {str(r["id"]) for r in records if cohort == "all" or bool(r.get("paper_eligible", True))}
    rows, method_rows = [], {}
    permutations = {}
    for r in records:
        try:
            permutations[str(r["id"])] = symmetry_permutations(r, symmetry, symmetry_cap)
        except (ValueError, RuntimeError) as exc:
            permutations[str(r["id"])] = (None, {"error": str(exc), "mode": symmetry})
    for method, preds in predictions.items():
        method_rows[method] = {}
        for record in records:
            rid = str(record["id"])
            p = preds.get(rid, {"valid": False, "status": "missing_prediction"})
            row = {"id": rid, "method": method, "n_atoms": len(record["Z"]),
                   "n_heavy": int(np.sum(_array(record["Z"]) != 1)),
                   "valid": bool(p["valid"]), "status": p.get("status", "ok"),
                   "symmetry_mode": symmetry, "symmetry_cap_hit": permutations[rid][1].get("cap_hit", False),
                   "paper_eligible": bool(record.get("paper_eligible", True)),
                   "exclusion_reason": str(record.get("exclusion_reason", ""))}
            if row["valid"]:
                try:
                    ref = reference_position(record)
                    fixed = structure_metrics(p["positions"], ref, record["Z"], record.get("radii"))
                    row.update({f"fixed_{k}": fixed[k] for k in ("rmsd_all_A", "d_mae_A", "q_chord_l2")})
                    candidates, info = permutations[rid]
                    if candidates is None:
                        raise ValueError(info["error"])
                    pred = _array(p["positions"], np.float64)
                    best = min(candidates, key=lambda perm: kabsch_rmsd(pred[list(perm)], ref))
                    row.update(structure_metrics(pred[list(best)], ref, record["Z"], record.get("radii")))
                except (ValueError, np.linalg.LinAlgError, FloatingPointError) as exc:
                    row.update(valid=False, status=f"metric_failure:{type(exc).__name__}:{exc}")
            for k in METRICS:
                row.setdefault(k, None)
            rows.append(row)
            method_rows[method][rid] = row
    report = {"n_requested": len(selected_ids), "n_raw_split": len(records), "cohort": cohort,
              "n_cohort_excluded": len(records) - len(selected_ids),
              "cohort_ids_sha256": hashlib.sha256("\n".join(sorted(selected_ids)).encode()).hexdigest(),
              "bootstrap_unit": "molecule", "bootstrap_seed": seed,
              "n_bootstrap": n_bootstrap, "primary_atom_correspondence": symmetry,
              "alignment": "proper SO(3) Kabsch; D-MAE/q-chord use the permutation minimizing all-atom RMSD",
              "symmetry_diagnostics": {rid: info for rid, (_, info) in permutations.items()},
              "q_chord_l2_is_geodesic_distance": False, "metadata": metadata or {}, "methods": {}, "paired_comparisons": {}}
    for method, mapping in method_rows.items():
        all_rows = list(mapping.values())
        current = [r for r in all_rows if r["id"] in selected_ids]
        good = [r for r in current if r["valid"]]
        reasons = {}
        for r in current:
            if not r["valid"]:
                reasons[r["status"]] = reasons.get(r["status"], 0) + 1
        report["methods"][method] = {"n_success": len(good), "n_failed": len(current) - len(good),
                "failure_fraction": 1 - len(good) / max(1, len(current)), "failure_reasons": reasons,
                "summary_scope": "successful predictions only; never interpret separately from failure fraction",
                "metrics": {k: summarize([r[k] for r in good], seed, n_bootstrap) for k in METRICS}}
        all_good = [r for r in all_rows if r["valid"]]
        report["methods"][method]["all_released_test_records"] = {
            "n_requested": len(all_rows), "n_success": len(all_good), "n_failed": len(all_rows) - len(all_good),
            "metrics": {k: summarize([r[k] for r in all_good], seed, 0) for k in METRICS}}
        eligible = [r for r in all_rows if r["paper_eligible"]]
        eligible_good = [r for r in eligible if r["valid"]]
        report["methods"][method]["paper_eligible_subset"] = {
            "n_requested": len(eligible), "n_success": len(eligible_good), "n_failed": len(eligible) - len(eligible_good),
            "note": "Eligibility uses dataset flags; an absent released exclusion list is not evidence of exact Table1 membership.",
            "metrics": {k: summarize([r[k] for r in eligible_good], seed, 0) for k in METRICS}}
        report["methods"][method]["by_heavy_atom_count"] = {
            str(n): {"n_requested": sum(r["n_heavy"] == n for r in current),
                     "n_success": sum(r["n_heavy"] == n for r in good),
                     "rmsd_all_A": summarize([r["rmsd_all_A"] for r in good if r["n_heavy"] == n], seed, 0)}
            for n in sorted({r["n_heavy"] for r in current})}
    names = list(method_rows)
    for a_index, a in enumerate(names):
        for b in names[a_index + 1:]:
            common = [rid for rid in method_rows[a] if rid in selected_ids and method_rows[a][rid]["valid"] and method_rows[b][rid]["valid"]]
            report["paired_comparisons"][f"{a} minus {b}"] = {
                "n_common_success": len(common), "n_excluded": len(selected_ids) - len(common),
                "negative_favors": a, "scope": "intersection of successful predictions, not the full benchmark when failures occur",
                "metric_differences": {k: summarize([method_rows[a][rid][k] - method_rows[b][rid][k]
                    for rid in common if method_rows[a][rid][k] is not None and method_rows[b][rid][k] is not None], seed, n_bootstrap) for k in METRICS}}
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    json_write(out / "metrics.json", report)
    with (out / "per_molecule.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "method", "n_atoms", "n_heavy", "valid", "status", "symmetry_mode", "symmetry_cap_hit", "paper_eligible", "exclusion_reason", *METRICS])
        writer.writeheader()
        writer.writerows(rows)
    return report


def prediction_arguments(values):
    out = {}
    for value in values:
        if "=" not in value:
            raise ValueError("Use --predictions METHOD=path.npz")
        name, path = value.split("=", 1)
        if not name or name in out or name == "reference":
            raise ValueError(f"Invalid or duplicate method name: {name}")
        out[name] = path
    return out


def seed_group_statistics(report, groups):
    """Separate training-seed variation from molecule-bootstrap uncertainty."""
    result = {}
    for group in groups:
        name, members = group.split("=", 1)
        members = members.split(",")
        if len(members) < 2 or len(set(members)) != len(members):
            raise ValueError("Seed groups require at least two distinct method names")
        methods = [report["methods"][m] for m in members]
        if any(m["n_failed"] for m in methods):
            result[name] = {"members": members, "status": "full_cohort_seed_summary_withheld_due_to_failures",
                            "n_failed_by_seed": [m["n_failed"] for m in methods]}
            continue
        metrics = {}
        for k in METRICS:
            values = [m["metrics"][k]["mean"] for m in methods]
            metrics[k] = {"seed_means": values, "mean_across_seed_means": float(np.mean(values)),
                          "std_across_seed_means": float(np.std(values, ddof=1))}
        result[name] = {"members": members, "n_seeds": len(members), "scope": "same complete test cohort", "metrics": metrics}
    report["training_seed_groups"] = result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", required=True, help="Processed dataset directory or packed split NPZ")
    parser.add_argument("--split", default="test", choices=("train", "validation", "test"))
    parser.add_argument("--predictions", action="append", default=[], help="METHOD=path.npz; repeat for fair paired baselines")
    parser.add_argument("--out", required=True)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--no-mmff", action="store_true")
    parser.add_argument("--symmetry", choices=("paper", "strict", "fixed"), default="paper")
    parser.add_argument("--symmetry-cap", type=int, default=4096)
    parser.add_argument("--seed-group", action="append", default=[], help="GROUP=method_seed1,method_seed2,method_seed3")
    parser.add_argument("--cohort", choices=("all", "paper"), default="all", help="Select aggregate cohort; full per-molecule CSV always retained")
    args = parser.parse_args()
    records = load_records(args.data_dir, args.split)
    files = prediction_arguments(args.predictions)
    predictions = {name: load_predictions(path, records) for name, path in files.items()}
    if not args.no_mmff:
        if "MMFF" in predictions:
            raise ValueError("MMFF name is reserved for dataset initialization; use --no-mmff to replace it explicitly")
        predictions = {"MMFF": {str(r["id"]): {"positions": r.get("initial_positions"),
            "valid": r.get("initial_positions") is not None and np.isfinite(r["initial_positions"]).all(),
            "status": "ok" if r.get("initial_positions") is not None else "missing_initial_geometry"} for r in records}, **predictions}
    metadata = {"data_dir": str(Path(args.data_dir).resolve()), "split": args.split,
                "prediction_files": {name: {"path": str(Path(path).resolve()), "sha256": sha256(path)} for name, path in files.items()},
                "published_results_are_external_reference_only": True}
    data_path = Path(args.data_dir)
    split_file = data_path if data_path.suffix == ".npz" else data_path / f"{args.split}.npz"
    if split_file.exists():
        metadata["dataset_split_sha256"] = sha256(split_file)
    for filename in ("manifest.json", "split.json"):
        split_meta = (data_path.parent if data_path.suffix == ".npz" else data_path) / filename
        if split_meta.exists():
            metadata[filename] = json.loads(split_meta.read_text())
    report = evaluate(records, predictions, args.out, metadata, args.bootstrap, args.seed, args.symmetry, args.symmetry_cap, args.cohort)
    if args.seed_group:
        seed_group_statistics(report, args.seed_group)
        json_write(Path(args.out) / "metrics.json", report)
    print(json.dumps({m: {"success": r["n_success"], "failed": r["n_failed"], "RMSD_mean_A": r["metrics"]["rmsd_all_A"]["mean"]}
                      for m, r in report["methods"].items()}, indent=2))


if __name__ == "__main__":
    main()
