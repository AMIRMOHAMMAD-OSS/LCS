"""Unified entry point; subcommands delegate to independently usable modules."""
import argparse
import sys
from pathlib import Path

def main(argv=None):
    argv=list(sys.argv[1:] if argv is None else argv)
    commands=('train','predict','data','evaluate','quantum','official')
    if not argv or argv[0] in ('-h','--help'):
        print('python -m rdm_drift.cli {'+','.join(commands)+'} [arguments]')
        return 0
    command=argv.pop(0)
    if command=='predict':
        p=argparse.ArgumentParser(description='One-pass or explicitly repeated MMFF refinement; references are never model inputs.')
        p.add_argument('--data',required=True);p.add_argument('--checkpoint',required=True)
        p.add_argument('--output',required=True);p.add_argument('--split',default='test')
        p.add_argument('--passes',type=int,default=1);p.add_argument('--device',choices=['cpu','cuda'],default='cuda')
        a=p.parse_args(argv)
        from .train import save_predictions
        checkpoint=Path(a.checkpoint).resolve()
        save_predictions(None,a.data,checkpoint.parent,a.output,split={'val':'validation'}.get(a.split,a.split),passes=a.passes,checkpoint=checkpoint.name,device=a.device)
        return 0
    import importlib
    module={'train':'train','data':'prepare_data','evaluate':'evaluate','quantum':'quantum','official':'official'}.get(command)
    if module is None:raise SystemExit(f'Unknown command {command}; choose {commands}')
    return importlib.import_module('.'+module,__package__).main(argv)
if __name__=='__main__':raise SystemExit(main())
