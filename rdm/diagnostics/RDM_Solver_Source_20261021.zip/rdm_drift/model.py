"""Dense E(3)-equivariant coordinate refiner for small fixed molecular graphs.

Only invariant scalar features enter MLPs; coordinate updates are weighted sums
of relative coordinates. Atom ordering is not used as a feature. No PyG needed.
"""
from __future__ import annotations

import math
import torch
from torch import nn


class EquivariantBlock(nn.Module):
    def __init__(self, hidden: int, radial: int = 32):
        super().__init__()
        self.register_buffer("centers", torch.linspace(0.0, 6.0, radial))
        self.width = 6.0 / max(radial - 1, 1)
        self.message = nn.Sequential(nn.Linear(2 * hidden + radial + 2, hidden),
                                     nn.SiLU(), nn.Linear(hidden, hidden), nn.SiLU())
        self.update = nn.Sequential(nn.Linear(2 * hidden, hidden), nn.SiLU(),
                                    nn.Linear(hidden, hidden))
        self.coord = nn.Sequential(nn.Linear(hidden, hidden // 2), nn.SiLU(),
                                   nn.Linear(hidden // 2, 1, bias=False))
        nn.init.normal_(self.coord[-1].weight, mean=0, std=1e-3)
        self.norm = nn.LayerNorm(hidden)

    def forward(self, h, x, bonds):
        b, n, _ = x.shape
        delta = x[:, :, None, :] - x[:, None, :, :]
        d = (delta.square().sum(-1) + 1e-12).sqrt()
        radial = torch.exp(-((d[..., None] - self.centers) / self.width).square())
        hi = h[:, :, None, :].expand(b, n, n, -1)
        hj = h[:, None, :, :].expand(b, n, n, -1)
        edge = bonds[None, :, :, None].expand(b, -1, -1, -1)
        message = self.message(torch.cat([hi, hj, radial, edge, d[..., None] / 6], -1))
        mask = (~torch.eye(n, device=x.device, dtype=torch.bool))[None, :, :, None]
        message = message * mask
        h = self.norm(h + self.update(torch.cat([h, message.sum(2) / max(n - 1, 1)], -1)))
        weight = self.coord(message).tanh() * mask
        dx = (weight * delta / (1 + d[..., None])).sum(2) / math.sqrt(max(n - 1, 1))
        return h, x + dx


class EquivariantRefiner(nn.Module):
    def __init__(self, hidden=128, layers=6, radial=32, max_displacement=0.5):
        super().__init__()
        self.embedding = nn.Embedding(119, hidden)
        self.noise_embedding = nn.Sequential(nn.Linear(3, hidden), nn.SiLU(), nn.Linear(hidden, hidden))
        self.blocks = nn.ModuleList([EquivariantBlock(hidden, radial) for _ in range(layers)])
        self.max_displacement = float(max_displacement)

    def forward(self, positions, atomic_numbers, noise_scale, bonds=None):
        """positions[B,N,3], Z[N], scalar or per-particle metric noise scale."""
        x0 = positions
        if x0.ndim != 3:
            raise ValueError("positions must have shape [particles, atoms, 3]")
        b, n, _ = x0.shape
        if atomic_numbers.shape != (n,):
            raise ValueError("atomic_numbers must have shape [atoms]")
        if bonds is None:
            bonds = x0.new_zeros((n, n))
        bonds = torch.as_tensor(bonds, device=x0.device, dtype=x0.dtype)
        if bonds.shape != (n, n):
            raise ValueError("bonds must be a dense symmetric [atoms, atoms] matrix")
        sigma = torch.as_tensor(noise_scale, device=x0.device, dtype=x0.dtype).reshape(-1)
        if sigma.numel() == 1:
            sigma = sigma.expand(b)
        if sigma.numel() != b:
            raise ValueError("noise_scale must be scalar or one value per particle")
        log_sigma = sigma.clamp_min(1e-8).log()
        conditioning = torch.stack([sigma, log_sigma / 10, torch.ones_like(sigma)], -1)
        h = self.embedding(atomic_numbers.long())[None].expand(b, -1, -1)
        h = h + self.noise_embedding(conditioning)[:, None, :]
        x = x0
        for block in self.blocks:
            h, x = block(h, x, bonds)
        delta = x - x0
        delta = delta - delta.mean(1, keepdim=True)
        rms = delta.square().sum(-1).mean(-1).clamp_min(1e-16).sqrt()
        # One invariant scalar per structure preserves equivariance and bounds
        # the RMS coordinate correction, without clipping Cartesian components.
        scale = self.max_displacement * torch.tanh(rms / self.max_displacement) / rms
        return x0 + delta * scale[:, None, None]


def build_model(config):
    return EquivariantRefiner(**config.get("model", {}))
