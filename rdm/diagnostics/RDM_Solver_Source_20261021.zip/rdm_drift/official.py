"""Run published R-DM/E-DM QM9 weights through pinned official inference code.

This adapter does not train or approximate the baseline network. It verifies every
learned parameter, joins released samples by molecular id, and checks atom order.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import tarfile
import time
import urllib.request

import numpy as np

COMMIT = "527c37d4f39ecf8538b7f4755f45e1c7f5afeeee"
SOURCE_URL = f"https://codeload.github.com/seonghann/neural_opt/tar.gz/{COMMIT}"
SOURCE_SHA256 = "8f156f15023b0231d69344b051caa6cb9cbba72b7ba6e647e68b97c0a438750a"
CHECKPOINTS = {
    "rdm": ("rdsm.qm9.finetuned.ckpt", "9c4e9cfbc17a4b13f380678fc260f027e7c4946697293b7db65e8bf29057afd2"),
    "edm": ("edsm.qm9.ckpt", "c0f6c7cfd45d9ddefba52e798c27e933a023f433ebf8a41bc8a2d9ae65269cc8"),
}
ALIASES = {
    "NeuralNet.atom_embedding.": "NeuralNet.layers.0.",
    "NeuralNet.edge_encoder.": "NeuralNet.layers.1.",
    "NeuralNet.encoder.": "NeuralNet.layers.2.",
    "NeuralNet.score_mlp.": "NeuralNet.layers.3.",
    "NeuralNet.atom_feat_embedding.": "NeuralNet.layers.4.",
}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def fetch_source(destination):
    """Download and verify the exact official source archive, preserving its MIT license."""
    dest = Path(destination).resolve()
    dest.mkdir(parents=True, exist_ok=True)
    archive = dest / f"neural_opt-{COMMIT}.tar.gz"
    if not archive.exists():
        temporary = archive.with_suffix(".part")
        with urllib.request.urlopen(SOURCE_URL, timeout=120) as response, temporary.open("wb") as f:
            for block in iter(lambda: response.read(1024 * 1024), b""):
                f.write(block)
        os.replace(temporary, archive)
    if sha256(archive) != SOURCE_SHA256:
        raise ValueError("Official source checksum mismatch; refusing to execute it")
    source = dest / f"neural_opt-{COMMIT}"
    manifest = {}
    with tarfile.open(archive, "r:gz") as tar:
        for member in tar.getmembers():
            target = (dest / member.name).resolve()
            if not target.is_relative_to(dest) or member.issym() or member.islnk():
                raise ValueError(f"Unsafe source archive entry: {member.name}")
            if member.isfile():
                manifest[str(target.relative_to(source))] = hashlib.sha256(tar.extractfile(member).read()).hexdigest()
        if not source.exists():
            tar.extractall(dest, filter="data")
    for name, expected in manifest.items():
        if not (source / name).is_file() or sha256(source / name) != expected:
            raise ValueError(f"Existing official checkout differs from pinned archive: {name}")
    # Re-extracting is intentionally not used to overwrite a modified checkout.
    marker = dest / f"neural_opt-{COMMIT}.verified.json"
    if marker.exists() and json.loads(marker.read_text())["files"] != manifest:
        raise ValueError("Pinned official source has changed since verification")
    marker.write_text(json.dumps({"commit": COMMIT, "archive_sha256": SOURCE_SHA256, "files": manifest}, indent=2) + "\n")
    print(source)
    return source


def verify_source(source):
    source = Path(source).resolve()
    marker = source.parent / f"neural_opt-{COMMIT}.verified.json"
    if not marker.exists():
        raise ValueError("Run `python -m rdm_drift.official fetch --destination VENDOR_DIR` first")
    manifest = json.loads(marker.read_text())
    if manifest["commit"] != COMMIT or manifest["archive_sha256"] != SOURCE_SHA256:
        raise ValueError("Official source provenance differs")
    for name, expected in manifest["files"].items():
        if not (source / name).is_file() or sha256(source / name) != expected:
            raise ValueError(f"Official source was modified: {name}")
    return source


def canonical_key(key):
    for old, new in ALIASES.items():
        if key.startswith(old):
            return new + key[len(old):]
    return key


def load_exact_network(model, checkpoint):
    """Load all learned weights; missing, extra, or conflicting aliases are errors."""
    import torch
    content = torch.load(checkpoint, map_location="cpu", weights_only=False)
    state = content["state_dict"]
    learned = {}
    for key, value in state.items():
        if not key.startswith("NeuralNet."):
            continue
        canon = canonical_key(key)
        if canon in learned and not torch.equal(learned[canon], value):
            raise ValueError(f"Conflicting checkpoint aliases: {key}")
        learned[canon] = value
    expected = {canonical_key(k) for k in model.state_dict() if k.startswith("NeuralNet.")}
    if set(learned) != expected:
        raise ValueError(f"Checkpoint network mismatch. Missing={expected - set(learned)}, extra={set(learned) - expected}")
    model_state = model.state_dict()
    for key in model_state:
        if key.startswith("NeuralNet."):
            model_state[key] = learned[canonical_key(key)]
    model.load_state_dict(model_state, strict=True)
    return {"canonical_network_tensors": len(learned), "epoch": content.get("epoch"), "global_step": content.get("global_step")}


def _load_released_dataset(path):
    import torch
    from torch_geometric.data import InMemoryDataset
    pair = torch.load(path, map_location="cpu", weights_only=False)
    if not isinstance(pair, tuple) or len(pair) != 2 or pair[0] is None:
        raise ValueError("Expected released PyG (data, slices) tuple")
    ds = InMemoryDataset(root=None)
    ds.data, ds.slices = pair
    return ds


def _match_records(records, dataset):
    lookup = {}
    encoded_to_z = np.array([1, 6, 7, 8, 9, 16, 17])
    for i in range(len(dataset)):
        item = dataset[i]
        rid = str(int(item.idx))
        if rid in lookup:
            raise ValueError(f"Duplicate released id {rid}")
        lookup[rid] = i
    result = []
    for record in records:
        rid = str(record["id"])
        if rid not in lookup:
            raise ValueError(f"Prepared id {rid} missing from official test split")
        item = dataset[lookup[rid]]
        codes = item.x.cpu().numpy().reshape(-1)
        if codes.min() < 0 or codes.max() >= len(encoded_to_z):
            raise ValueError(f"Invalid official atom encoding at {rid}")
        if not np.array_equal(encoded_to_z[codes], np.asarray(record["Z"])):
            raise ValueError(f"Ordered atomic identities differ at {rid}")
        if str(item.smarts) != record["smarts"]:
            raise ValueError(f"Atom-mapped SMARTS differ at {rid}")
        for key, idx in (("positions", 0), ("initial_positions", -1)):
            ours = np.asarray(record[key], np.float64)
            theirs = item.pos[:, idx].cpu().numpy().astype(np.float64)
            if ours.shape != theirs.shape or not np.allclose(ours - ours.mean(0), theirs - theirs.mean(0), atol=2e-5, rtol=0):
                raise ValueError(f"Released {key} differs for {rid}")
        result.append(item)
    return result


def infer(args):
    import torch
    from .evaluate import load_records, save_predictions
    source = verify_source(args.source)
    sys.path.insert(0, str(source))
    from omegaconf import OmegaConf
    from torch_geometric.data import Batch
    from src.diffusion.model import DiffusionModel
    from src.diffusion.sampling import sample_batch_simple

    checkpoint = Path(args.checkpoint).resolve()
    if sha256(checkpoint) != CHECKPOINTS[args.model][1]:
        raise ValueError(f"Expected published {CHECKPOINTS[args.model][0]}; checkpoint checksum differs")
    args.split = {"val": "validation", "valid": "validation"}.get(args.split, args.split)
    data_path = Path(args.data_dir) / f"{args.split}.npz"
    records = load_records(args.data_dir, args.split)
    if args.limit is not None:
        records = records[:args.limit]
    dataset = _load_released_dataset(args.released_pt)
    selected = _match_records(records, dataset)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    torch.manual_seed(args.seed)
    torch.set_default_dtype(torch.float32)
    config = OmegaConf.load(source / "configs" / f"sampling.qm9.{('rdsm' if args.model == 'rdm' else 'edsm')}.yaml")
    config.general.use_wandb = False
    config.debug.save_dynamic = "adapter_in_memory"
    config.debug.save_dynamic_final_only = True
    config.sampling.sde_steps = args.nfe
    config.sampling.num_cycles = 1
    config.sampling.stochastic = False
    config.sampling.score_type = "cfm"
    model = DiffusionModel(config)
    weight_report = load_exact_network(model, checkpoint)
    model.to(device).eval()
    meta = {
        "kind": "published_checkpoint_through_pinned_official_code", "model": args.model,
        "official_commit": COMMIT, "source_archive_sha256": SOURCE_SHA256,
        "checkpoint_sha256": sha256(checkpoint), "prepared_split_sha256": sha256(data_path),
        "released_pt_sha256": sha256(args.released_pt), "split": args.split,
        "nfe": args.nfe, "sampler": "official_cfm_contracted_tangent_updates",
        "seed": args.seed, "batch_size": args.batch_size, "limit": args.limit,
        "torch": torch.__version__, "device": str(device), "weights": weight_report,
    }
    parts = Path(str(args.output) + ".parts")
    parts.mkdir(parents=True, exist_ok=True)
    provenance = parts / "run.json"
    if provenance.exists():
        if not args.resume:
            raise FileExistsError(f"{parts} exists; pass --resume for the same run")
        if json.loads(provenance.read_text()) != meta:
            raise ValueError("Official inference resume configuration differs")
    else:
        provenance.write_text(json.dumps(meta, indent=2) + "\n")
    predictions, valid, status = [], [], []
    start = time.time()
    for begin in range(0, len(records), args.batch_size):
        end = min(begin + args.batch_size, len(records))
        part = parts / f"{begin:08d}-{end:08d}.npz"
        batch_records = records[begin:end]
        if part.exists():
            from .evaluate import load_predictions
            saved = load_predictions(part, batch_records)
            for record in batch_records:
                item = saved[str(record["id"])]
                predictions.append(item["positions"])
                valid.append(item["valid"])
                status.append(item["status"])
            continue
        try:
            batch = Batch.from_data_list(selected[begin:end]).to(device)
            with torch.no_grad():
                output = sample_batch_simple(model, batch, config, stochastic=False, num_cycles=1)
            by_id = {str(int(item.idx)): item for item in output}
            if len(by_id) != len(batch_records):
                raise RuntimeError("Official sampler returned duplicate or missing ids")
            xyz = [by_id[str(r["id"])].traj[:, 0].detach().cpu().numpy() for r in batch_records]
            ok = [bool(np.isfinite(x).all()) for x in xyz]
            reasons = ["ok" if value else "nonfinite_prediction" for value in ok]
        except (RuntimeError, ValueError) as exc:
            # Retain the entire attempted denominator. Failed batches are not retried
            # with altered settings and cannot silently disappear from evaluation.
            xyz = [np.full((len(r["Z"]), 3), np.nan) for r in batch_records]
            ok = [False] * len(xyz)
            reasons = [f"official_sampler_failed:{type(exc).__name__}:{str(exc)[:200]}"] * len(xyz)
            if device.type == "cuda":
                torch.cuda.empty_cache()
        save_predictions(batch_records, xyz, part, valid=ok, status=reasons, metadata=meta)
        predictions.extend(xyz); valid.extend(ok); status.extend(reasons)
        print(json.dumps({"complete": end, "total": len(records), "accepted": sum(valid), "elapsed_s": time.time() - start}), flush=True)
    meta["elapsed_s_this_invocation"] = time.time() - start
    meta["valid"] = int(sum(valid)); meta["total"] = len(records)
    save_predictions(records, predictions, args.output, valid=valid, status=status, metadata=meta)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    fetch = commands.add_parser("fetch")
    fetch.add_argument("--destination", required=True)
    run = commands.add_parser("infer")
    run.add_argument("--source", required=True)
    run.add_argument("--checkpoint", required=True)
    run.add_argument("--released-pt", required=True)
    run.add_argument("--data-dir", required=True)
    run.add_argument("--split", default="test", choices=["train", "valid", "validation", "test"])
    run.add_argument("--model", choices=["rdm", "edm"], default="rdm")
    run.add_argument("--output", required=True)
    run.add_argument("--device", default="cuda")
    run.add_argument("--nfe", type=int, default=128)
    run.add_argument("--batch-size", type=int, default=64)
    run.add_argument("--seed", type=int, default=42)
    run.add_argument("--limit", type=int)
    run.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.command == "fetch":
        fetch_source(args.destination)
    else:
        if args.nfe < 1 or args.batch_size < 1 or (args.limit is not None and args.limit < 1):
            parser.error("nfe, batch-size, and limit must be positive")
        infer(args)


if __name__ == "__main__":
    main()
