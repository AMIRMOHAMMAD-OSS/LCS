"""Prepare, run and collect reproducible CPU single-point DFT jobs.

Gaussian exports match the paper's published QM9 level/options. PySCF is a
separately labelled same-functional/basis re-evaluation, not Gaussian equivalence.
Every selected id is retained, including missing predictions and failed SCF jobs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

import numpy as np

from .evaluate import (json_write, load_predictions, load_records,
                       prediction_arguments, reference_position, sha256, summarize)


HARTREE_TO_KCAL_MOL = 627.5094740631
PYSCF_SETTINGS = {"xc": "B3LYPG", "basis": "6-31g(2df,p)", "conv_tol": 1e-10,
                   "conv_tol_grad": 1e-7, "max_cycle": 200, "atom_grid": [99, 590],
                   "prune": None, "direct_scf_tol": 1e-13, "density_fitting": False,
                   "device": "cpu", "unit": "Angstrom"}
GAUSSIAN_ROUTE = "#p B3LYP/6-31G(2df,p) integral(grid=ultrafine) scf(maxcycle=200,verytight)"


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _symbol(z):
    # QM9 only; make an unsupported extension explicit rather than silently guessing.
    symbols = {1: "H", 6: "C", 7: "N", 8: "O", 9: "F"}
    if int(z) not in symbols:
        raise ValueError(f"Only QM9 elements are supported by this benchmark: Z={z}")
    return symbols[int(z)]


def xyz_text(job):
    lines = [str(len(job["Z"])), f"id={job['id']} method={job['method']} positions_A"]
    lines += [f"{_symbol(z)} {p[0]:.15g} {p[1]:.15g} {p[2]:.15g}" for z, p in zip(job["Z"], job["positions"])]
    return "\n".join(lines) + "\n"


def gaussian_text(job, threads=4, memory_mb=8000, optimize=False):
    route = GAUSSIAN_ROUTE + (" opt(calcfc,maxstep=5,maxcycles=1000)" if optimize else "")
    lines = [f"%nprocshared={threads}", f"%mem={memory_mb}MB", route, "",
             f"RDM benchmark job {job['job_index']} id={job['id']} method={job['method']}", "",
             f"{job['charge']} {job['spin'] + 1}"]
    lines += [f"{_symbol(z)} {p[0]:.15g} {p[1]:.15g} {p[2]:.15g}" for z, p in zip(job["Z"], job["positions"])]
    return "\n".join(lines) + "\n\n"


def prepare(data_dir, split, prediction_files, out, limit=0, seed=2026, threads=4, memory_mb=8000, gaussian=False, optimize=False, cohort="all"):
    records = load_records(data_dir, split)
    raw_count = len(records)
    # Resolve predictions against the FULL split before optional, predeclared sampling.
    predictions = {name: load_predictions(path, records) for name, path in prediction_files.items()}
    if "MMFF" in predictions:
        raise ValueError("MMFF is the reserved dataset initialization baseline")
    exclusions = []
    if cohort == "paper":
        exclusions = [{"id": str(r["id"]), "reason": str(r.get("exclusion_reason", "paper_eligible=False"))}
                      for r in records if not bool(r.get("paper_eligible", True))]
        records = [r for r in records if bool(r.get("paper_eligible", True))]
    elif cohort != "all":
        raise ValueError("Unknown cohort")
    if limit > 0 and limit < len(records):
        chosen = np.sort(np.random.default_rng(seed).choice(len(records), limit, replace=False))
        records = [records[i] for i in chosen]
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    if (out / "jobs.jsonl").exists():
        raise FileExistsError("A quantum plan already exists at this path; use a fresh output directory to preserve its provenance")
    (out / "xyz").mkdir(exist_ok=True)
    if gaussian:
        (out / "gaussian").mkdir(exist_ok=True)
    jobs = []
    for record in records:
        rid = str(record["id"])
        methods = {"reference": {"valid": True, "positions": reference_position(record)},
                   "MMFF": {"valid": record.get("initial_positions") is not None,
                            "positions": record.get("initial_positions"), "status": "missing_initial_geometry"}}
        methods.update({name: results[rid] for name, results in predictions.items()})
        for method, pred in methods.items():
            x = None if pred.get("positions") is None else np.asarray(pred["positions"], np.float64)
            valid = bool(pred["valid"]) and x is not None and bool(np.isfinite(x).all())
            job = {"job_index": len(jobs), "id": rid, "method": method,
                   "Z": np.asarray(record["Z"], int).tolist(),
                   "positions": x.tolist() if valid else None,
                   "charge": int(record.get("charge", 0)), "spin": int(record.get("spin", 0)),
                   "ready": valid, "status": "prepared" if valid else pred.get("status", "prediction_failed"),
                   "calculation": "optimization" if optimize else "single_point",
                   "paper_eligible": bool(record.get("paper_eligible", True))}
            if valid:
                if x.shape != (len(job["Z"]), 3):
                    raise ValueError(f"Invalid geometry for {rid}/{method}")
                if (sum(job["Z"]) - job["charge"] - job["spin"]) % 2:
                    raise ValueError(f"Electron count/spin parity mismatch for {rid}")
                for z in job["Z"]:
                    _symbol(z)
            job["payload_sha256"] = _hash(job)
            jobs.append(job)
            if valid:
                (out / "xyz" / f"{job['job_index']:08d}.xyz").write_text(xyz_text(job))
                if gaussian:
                    (out / "gaussian" / f"{job['job_index']:08d}.gjf").write_text(gaussian_text(job, threads, memory_mb, optimize))
    with (out / "jobs.jsonl").open("w") as f:
        for job in jobs:
            f.write(json.dumps(job, allow_nan=False) + "\n")
    manifest = {"n_molecules": len(records), "n_raw_split": raw_count, "cohort": cohort, "cohort_exclusions": exclusions,
        "n_jobs": len(jobs), "n_ready": sum(j["ready"] for j in jobs),
        "ids": [str(r["id"]) for r in records], "split": split, "selection_seed": seed, "limit": limit,
        "selection": "uniform molecule sampling before considering method success" if limit else "entire split",
        "prediction_files": {k: {"path": str(Path(p).resolve()), "sha256": sha256(p)} for k, p in prediction_files.items()},
        "jobs_sha256": sha256(out / "jobs.jsonl"), "calculation": "optimization" if optimize else "single_point",
        "pyscf_settings": PYSCF_SETTINGS, "gaussian_route": GAUSSIAN_ROUTE,
        "paper_quantum_engine": "Gaussian09 Revision D.01", "reference_energies": "recomputed with the same engine and settings as every method",
        "note": "PySCF grids/convergence are explicitly specified but not identical to Gaussian09. Do not combine absolute energies across engines."}
    json_write(out / "manifest.json", manifest)
    print(json.dumps({k: manifest[k] for k in ("n_molecules", "n_jobs", "n_ready")}, indent=2))
    return manifest


def read_jobs(path):
    jobs = [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]
    for index, job in enumerate(jobs):
        payload = {k: v for k, v in job.items() if k != "payload_sha256"}
        if job.get("job_index") != index or job.get("payload_sha256") != _hash(payload):
            raise ValueError(f"Quantum plan index or geometry hash mismatch at job {index}")
    return jobs


def pyscf_single_point(job, log_path, threads=4, memory_mb=8000):
    import pyscf
    from pyscf import dft, gto, lib
    if job["calculation"] != "single_point":
        raise ValueError("PySCF optimization is deliberately not substituted for the paper Gaussian optimization; use --engine gaussian")
    lib.num_threads(threads)
    atom = [(_symbol(z), p) for z, p in zip(job["Z"], job["positions"])]
    mol = gto.M(atom=atom, unit="Angstrom", basis=PYSCF_SETTINGS["basis"], charge=job["charge"],
                spin=job["spin"], max_memory=memory_mb, verbose=4, output=str(log_path), symmetry=False)
    mf = dft.RKS(mol) if job["spin"] == 0 else dft.UKS(mol)
    mf.xc = PYSCF_SETTINGS["xc"]
    mf.conv_tol = PYSCF_SETTINGS["conv_tol"]
    mf.conv_tol_grad = PYSCF_SETTINGS["conv_tol_grad"]
    mf.max_cycle = PYSCF_SETTINGS["max_cycle"]
    mf.direct_scf_tol = PYSCF_SETTINGS["direct_scf_tol"]
    mf.grids.atom_grid = tuple(PYSCF_SETTINGS["atom_grid"])
    mf.grids.prune = None
    cycle = [0]
    def callback(env):
        cycle[0] = int(env.get("cycle", cycle[0])) + 1
    mf.callback = callback
    energy = mf.kernel()
    # Nonconverged SCF energy is never accepted as an energy-error observation.
    result = {"converged": bool(mf.converged) and bool(np.isfinite(energy)),
              "energy_hartree": float(energy) if mf.converged and np.isfinite(energy) else None,
              "scf_cycles": cycle[0], "engine_version": pyscf.__version__, "settings": PYSCF_SETTINGS}
    if hasattr(mol.stdout, "close"):
        mol.stdout.close()
    return result


def parse_gaussian_log(text, optimization=False):
    matches = re.findall(r"SCF Done:\s+E\([^)]*\)\s*=\s*([-+0-9.DEde]+).*?after\s+(\d+)\s+cycles", text)
    normal = "Normal termination of Gaussian" in text and "Error termination" not in text
    optimization_done = "Optimization completed." in text
    converged = normal and bool(matches) and (optimization_done if optimization else True)
    energy = float(matches[-1][0].replace("D", "E").replace("d", "e")) if converged else None
    versions = re.findall(r"Gaussian (?:09|16).*?Revision[^\n]*", text)
    return {"converged": converged, "energy_hartree": energy,
            "scf_cycles": sum(int(m[1]) for m in matches), "force_calls": len(matches) if optimization else None,
            "optimization_completed": optimization_done if optimization else None,
            "engine_version": versions[0].strip() if versions else "unknown; inspect log",
            "settings": {"route": GAUSSIAN_ROUTE, "optimization": optimization},
            "normal_termination": normal}


def run(jobs_path, task_index, out, task_count=None, engine="pyscf", threads=4, memory_mb=8000, gaussian_command="g09", retry_failed=False):
    jobs = read_jobs(jobs_path)
    if task_index < 0 or (task_count is not None and not 0 <= task_index < task_count):
        raise ValueError("Invalid task index/count")
    selected = jobs[task_index:task_index + 1] if task_count is None else jobs[task_index::task_count]
    if task_count is None and task_index >= len(jobs):
        raise IndexError("Task index exceeds planned jobs")
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    for job in selected:
        result_path = out / f"{job['job_index']:08d}.json"
        log_path = out / f"{job['job_index']:08d}.log"
        settings = PYSCF_SETTINGS if engine == "pyscf" else {"route": GAUSSIAN_ROUTE, "optimization": job["calculation"] == "optimization"}
        if result_path.exists():
            old = json.loads(result_path.read_text())
            if old.get("payload_sha256") != job["payload_sha256"] or old.get("engine") != engine or old.get("requested_settings") != settings:
                raise ValueError(f"Cannot reuse incompatible quantum result {result_path}")
            if old.get("converged") or not retry_failed:
                continue
        result = {"job_index": job["job_index"], "id": job["id"], "method": job["method"],
                  "payload_sha256": job["payload_sha256"], "calculation": job["calculation"],
                  "engine": engine, "requested_settings": settings, "threads": threads, "memory_mb": memory_mb,
                  "energy_hartree": None, "converged": False}
        start = time.monotonic()
        if not job["ready"]:
            result["status"] = job["status"]
        else:
            try:
                if engine == "pyscf":
                    result.update(pyscf_single_point(job, log_path, threads, memory_mb))
                else:
                    input_path = out / f"{job['job_index']:08d}.gjf"
                    input_path.write_text(gaussian_text(job, threads, memory_mb, job["calculation"] == "optimization"))
                    with input_path.open("r") as stdin, log_path.open("w") as stdout:
                        completed = subprocess.run([gaussian_command], stdin=stdin, stdout=stdout, stderr=subprocess.STDOUT, check=False)
                    result.update(parse_gaussian_log(log_path.read_text(errors="replace"), job["calculation"] == "optimization"))
                    result["return_code"] = completed.returncode
                    if completed.returncode:
                        result.update(converged=False, energy_hartree=None)
                result["status"] = "ok" if result["converged"] else "scf_or_optimization_failed"
            except Exception as exc:
                result["status"] = f"calculation_error:{type(exc).__name__}:{exc}"
        result["elapsed_seconds"] = time.monotonic() - start
        if log_path.exists():
            result["log_sha256"] = sha256(log_path)
        tmp = result_path.with_suffix(f".tmp.{os.getpid()}")
        json_write(tmp, result)
        os.replace(tmp, result_path)
        print(f"job={job['job_index']} id={job['id']} method={job['method']} status={result['status']}", flush=True)


def collect(jobs_path, results_dir, out, bootstrap=2000, seed=2026):
    jobs = read_jobs(jobs_path)
    results = {}
    settings_seen = set()
    for job in jobs:
        p = Path(results_dir) / f"{job['job_index']:08d}.json"
        if p.exists():
            result = json.loads(p.read_text())
            if result.get("payload_sha256") != job["payload_sha256"]:
                raise ValueError(f"Result geometry/provenance mismatch: {p}")
            if result.get("converged"):
                settings_seen.add(_hash({"engine": result["engine"], "settings": result["requested_settings"], "version": result.get("engine_version")}))
        else:
            result = {"id": job["id"], "method": job["method"], "converged": False,
                      "energy_hartree": None, "status": "not_run" if job["ready"] else job["status"]}
        results[(job["id"], job["method"])] = result
    if len(settings_seen) > 1:
        raise ValueError("Energy jobs mix engines/settings/versions; separate result directories and re-evaluate both reference and predictions consistently")
    methods = sorted({j["method"] for j in jobs} - {"reference"})
    ids = list(dict.fromkeys(j["id"] for j in jobs))
    optimization = any(j["calculation"] == "optimization" for j in jobs)
    rows, by_method = [], {}
    for method in methods:
        method_rows = []
        for rid in ids:
            ref, pred = results[(rid, "reference")], results[(rid, method)]
            ok = bool(ref["converged"] and pred["converged"])
            delta = (pred["energy_hartree"] - ref["energy_hartree"]) * HARTREE_TO_KCAL_MOL if ok else None
            row = {"id": rid, "method": method, "valid_pair": ok,
                   "reference_status": ref["status"], "prediction_status": pred["status"],
                   "signed_delta_kcal_mol": delta, "abs_delta_kcal_mol": abs(delta) if delta is not None else None,
                   "chemical_accuracy": abs(delta) < 1. if delta is not None else False}
            rows.append(row)
            method_rows.append(row)
        good = [r for r in method_rows if r["valid_pair"]]
        by_method[method] = {"n_requested": len(ids), "n_success": len(good), "n_failed": len(ids) - len(good),
                "failure_fraction": 1 - len(good) / max(1, len(ids)),
                "abs_delta_kcal_mol": summarize([r["abs_delta_kcal_mol"] for r in good], seed, bootstrap),
                "chemical_accuracy_fraction_all_requested": sum(r["chemical_accuracy"] for r in method_rows) / max(1, len(ids)),
                "chemical_accuracy_fraction_converged": sum(r["chemical_accuracy"] for r in good) / len(good) if good else None}
    report = {"calculation": "optimization" if optimization else "single_point", "methods": by_method,
              "quantum_settings_unique": len(settings_seen), "bootstrap_unit": "molecule", "bootstrap_seed": seed,
              "scope": "POST-OPTIMIZATION energy differences; not Table1 pre-relaxation accuracy" if optimization else "paired single-point energy error on fixed geometries",
              "caution": "No successful-only energy statistic should be interpreted without failures; chemical-accuracy fraction across all ids counts failure as not demonstrated.",
              "jobs_sha256": sha256(jobs_path)}
    # Paired differences use identical molecules and preserve the excluded count.
    report["paired_comparisons"] = {}
    row_map = {(r["id"], r["method"]): r for r in rows}
    for i, a in enumerate(methods):
        for b in methods[i + 1:]:
            common = [rid for rid in ids if row_map[rid, a]["valid_pair"] and row_map[rid, b]["valid_pair"]]
            report["paired_comparisons"][f"{a} minus {b}"] = {"n_common_success": len(common), "n_excluded": len(ids) - len(common),
                "abs_delta_difference_kcal_mol": summarize([row_map[rid, a]["abs_delta_kcal_mol"] - row_map[rid, b]["abs_delta_kcal_mol"] for rid in common], seed, bootstrap)}
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    json_write(out / "quantum_metrics.json", report)
    json_write(out / "quantum_per_molecule.json", rows)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--data-dir", required=True)
    p.add_argument("--split", default="test")
    p.add_argument("--predictions", action="append", default=[])
    p.add_argument("--out", required=True)
    p.add_argument("--limit", type=int, default=0)
    p.add_argument("--seed", type=int, default=2026)
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--memory-mb", type=int, default=8000)
    p.add_argument("--gaussian", action="store_true")
    p.add_argument("--optimize", action="store_true", help="Separate post-optimization experiment; Gaussian engine required")
    p.add_argument("--cohort", choices=("all", "paper"), default="all")
    p = sub.add_parser("run")
    p.add_argument("--jobs", required=True)
    p.add_argument("--task-index", type=int, required=True)
    p.add_argument("--task-count", type=int)
    p.add_argument("--out", required=True)
    p.add_argument("--engine", choices=("pyscf", "gaussian"), default="pyscf")
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--memory-mb", type=int, default=8000)
    p.add_argument("--gaussian-command", default="g09")
    p.add_argument("--retry-failed", action="store_true")
    p = sub.add_parser("collect")
    p.add_argument("--jobs", required=True)
    p.add_argument("--results", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--bootstrap", type=int, default=2000)
    p.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()
    if args.command == "prepare":
        prepare(args.data_dir, args.split, prediction_arguments(args.predictions), args.out,
                args.limit, args.seed, args.threads, args.memory_mb, args.gaussian, args.optimize, args.cohort)
    elif args.command == "run":
        run(args.jobs, args.task_index, args.out, args.task_count, args.engine, args.threads,
            args.memory_mb, args.gaussian_command, args.retry_failed)
    else:
        report = collect(args.jobs, args.results, args.out, args.bootstrap, args.seed)
        print(json.dumps(report["methods"], indent=2))


if __name__ == "__main__":
    main()
