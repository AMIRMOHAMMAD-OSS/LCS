"""Bounded, real-data training preflight using the production trainer.

A smoke pass is a software/numerical startup check, not a benchmark result or a
certificate for later curriculum noise. CPU and CUDA reports are distinct. No
synthetic records are generated here and no failed geometry solve is skipped.
"""
from __future__ import annotations

import copy
import json
import math
from pathlib import Path
import platform
import time

import numpy as np
import torch

from .data import load_split, save_records
from .model import build_model
from .preflight_geometry import (coordinate_census, startup_criteria,
                                 startup_record_diagnostics)
from .train import (_config_check, _hash_file, _hash_json, _write_json,
                    predict_record, train)


class StartupSelectionError(ValueError):
    """Selection failure carries all examined candidates for the failure report."""
    def __init__(self, diagnostics):
        self.diagnostics = diagnostics
        super().__init__(
            "No training record satisfies the declared startup coordinate-resolution "
            "and Jacobian-conditioning criteria. All original records are retained; "
            "inspect training_selection in smoke_status.json. No solver checks were relaxed.")


def _choose_training_record(dataset, device_type, config=None):
    """Choose in fixed size/ID order using declared coordinate/metric screening."""
    sizes = np.asarray(dataset.arrays["n_atoms"], dtype=int)
    ids = np.asarray(dataset.arrays["id"]).astype(str)
    criteria = startup_criteria(config)
    metric_options = (config or {}).get("geometry", {}).get("exp", {})
    if device_type == "cpu":
        candidates = np.flatnonzero((sizes >= 4) & (sizes <= 8))
        ordering = sorted(candidates.tolist(), key=lambda i: (int(sizes[i]), ids[i]))
    else:
        candidates = np.flatnonzero(sizes >= 4)
        ordering = sorted(candidates.tolist(), key=lambda i: (-int(sizes[i]), ids[i]))
    info = {
        "selection": "first eligible 4-8-atom record in ascending size/ID order" if device_type == "cpu"
                     else "first eligible record in descending size, ascending ID order",
        "source_records": len(dataset), "source_max_atoms": int(sizes.max()) if len(sizes) else None,
        "candidate_count": len(ordering), "candidates_examined": 0, "criteria": criteria,
        "excluded_candidates_before_selection": [],
        "solver_or_noise_outcomes_used_for_selection": False,
        "metric_diagnostics_used_for_selection": True,
        "all_source_records_retained": True,
        "scope": "Bounded startup selection only; exclusions here do not remove any dataset or benchmark ID.",
    }
    for index in ordering:
        record = dataset[index]
        diagnostics = startup_record_diagnostics(record, criteria, metric_options)
        info["candidates_examined"] += 1
        if not diagnostics["coordinates"]["finite"]:
            # Nonfinite data is a data error, never a silently bypassed candidate.
            info["excluded_candidates_before_selection"].append(diagnostics)
            raise StartupSelectionError(info)
        if not diagnostics["eligible_for_startup"]:
            info["excluded_candidates_before_selection"].append(diagnostics)
            continue
        info.update(selected_id=str(record["id"]), selected_atoms=int(sizes[index]),
                    selection_reason="First candidate in the declared order satisfying coordinate resolution, existing basis validity, and Jacobian conditioning criteria",
                    selected_geometry=diagnostics)
        return record, info
    raise StartupSelectionError(info)


def _choose_validation_records(dataset):
    """Median and largest atom-count cases; deterministic ID tie breaking."""
    if not len(dataset):
        raise ValueError("Validation dataset is empty")
    sizes = np.asarray(dataset.arrays["n_atoms"], dtype=int)
    ids = np.asarray(dataset.arrays["id"]).astype(str)
    ordering = sorted(range(len(dataset)), key=lambda i: (int(sizes[i]), ids[i]))
    indices = list(dict.fromkeys([ordering[len(ordering) // 2], ordering[-1]]))
    return [dataset[i] for i in indices]


def _finite_state(value, label):
    if torch.is_tensor(value):
        if value.is_floating_point() and not bool(torch.isfinite(value).all()):
            raise AssertionError(f"Nonfinite tensor in {label}")
    elif isinstance(value, dict):
        for key, child in value.items():
            _finite_state(child, f"{label}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, child in enumerate(value):
            _finite_state(child, f"{label}[{index}]")
    elif isinstance(value, float) and not math.isfinite(value):
        raise AssertionError(f"Nonfinite number in {label}")


def _checkpoint_delta(previous, current):
    maximum = 0.0
    changed = 0
    for name, tensor in current["model"].items():
        _finite_state(tensor, f"model.{name}")
        if tensor.is_floating_point():
            delta = float((tensor - previous["model"][name]).abs().max())
            maximum = max(maximum, delta)
            changed += int(delta > 0)
    if not changed:
        raise AssertionError("Optimizer update did not change any model parameters")
    _finite_state(current["optimizer"], "optimizer")
    if not current["optimizer"]["state"]:
        raise AssertionError("Checkpoint has no optimizer state after an accepted update")
    return {"changed_state_tensors": changed, "maximum_absolute_change": maximum}


def _check_validation(path, expected):
    result = json.loads(Path(path).read_text())
    if result["records"] != expected or result["valid"] != expected or result["failed"] != 0:
        raise AssertionError(f"Not all validation records succeeded: {path}")
    for key in ("distance_mae_A", "initial_distance_mae_A", "rmsd_A"):
        if result.get(key) is None or not math.isfinite(float(result[key])):
            raise AssertionError(f"Nonfinite validation metric {key}: {path}")
    for row in result["rows"]:
        if row.get("valid") is not True:
            raise AssertionError(f"Failed validation row: {row}")
        for key in ("distance_mae_A", "initial_distance_mae_A", "rmsd_A"):
            if row.get(key) is None or not math.isfinite(float(row[key])):
                raise AssertionError(f"Nonfinite validation row metric {key}: {row}")
    return {k: result[k] for k in ("records", "valid", "failed", "distance_mae_A", "rmsd_A")}


def run_smoke(data_dir, config_path, output_dir, device="cpu", max_updates=2):
    """Run initial checkpoint, accepted update, and accepted resumed update.

    Keyword arguments are recommended. output_dir must be empty or new. CPU uses
    two particles and one graph per update; CUDA retains the target model,
    particle count and graph accumulation count. All solver settings, objective,
    and curriculum remain unchanged. The report explicitly describes coverage.
    Any rejection, invalid validation, nonfinite gradient, failed resume, or
    absent requested device raises and leaves a failed smoke_status.json.
    """
    requested_device = torch.device(device)
    if requested_device.type not in {"cpu", "cuda"}:
        raise ValueError("Preflight device must be cpu or cuda")
    if max_updates != 2:
        raise ValueError("Checkpoint/resume smoke requires exactly max_updates=2")
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    if any(output.iterdir()):
        raise FileExistsError(f"Use an empty/new smoke output directory: {output}")
    started = time.perf_counter()
    report = {"status": "running", "requested_device": str(requested_device),
              "actual_device": None, "passed": False, "benchmark_result": False,
              "stage": "device", "python": platform.python_version(),
              "torch": str(torch.__version__), "numpy": np.__version__,
              "torch_cuda_build": torch.version.cuda,
              "scope": "Two accepted startup updates; not a full-data or late-curriculum acceptance test."}
    _write_json(output / "smoke_status.json", report)
    try:
        if requested_device.type == "cuda":
            if not torch.cuda.is_available():
                raise RuntimeError("CUDA requested, but CUDA is unavailable; no CPU fallback is permitted")
            index = requested_device.index if requested_device.index is not None else torch.cuda.current_device()
            if index >= torch.cuda.device_count():
                raise RuntimeError(f"CUDA device index {index} is unavailable")
            requested_device = torch.device("cuda", index)
            torch.cuda.set_device(requested_device)
            torch.cuda.reset_peak_memory_stats(requested_device)
            report["cuda_device_name"] = torch.cuda.get_device_name(requested_device)
        report["actual_device"] = str(requested_device)
        target = json.loads(Path(config_path).read_text()) if not isinstance(config_path, dict) else copy.deepcopy(config_path)
        _config_check(target)
        if int(target["training"]["updates"]) < 2:
            raise ValueError("Target configuration must permit at least two updates")
        config = copy.deepcopy(target)
        training = config["training"]
        if requested_device.type == "cpu":
            training["particles"] = 2
            training["graphs_per_update"] = 1
        training.update(checkpoint_every=1, validate_every=1,
                        max_attempts_per_update=training["graphs_per_update"],
                        minimum_graph_acceptance=1.0,
                        acceptance_gate_after_attempts=training["graphs_per_update"],
                        validation_max_records=2, log_every=1)
        report.update(target_config_sha256=_hash_json(target), effective_config_sha256=_hash_json(config),
                      model_architecture_unchanged=config["model"] == target["model"],
                      geometry_unchanged=config["geometry"] == target["geometry"],
                      noise_schedule_unchanged=config["noise"] == target["noise"],
                      target_particles=target["training"]["particles"], particles=training["particles"],
                      target_graphs_per_update=target["training"]["graphs_per_update"],
                      graphs_per_update=training["graphs_per_update"],
                      reduced_batch=requested_device.type == "cpu" and (
                          training["particles"] != target["training"]["particles"] or
                          training["graphs_per_update"] != target["training"]["graphs_per_update"]))
        _write_json(output / "smoke_effective_config.json", config)
        report["stage"] = "real_data_subset"
        training_data = load_split(data_dir, "train")
        report["coordinate_census"] = coordinate_census(training_data, startup_criteria(target))
        _write_json(output / "smoke_status.json", report)
        try:
            record, selection = _choose_training_record(training_data, requested_device.type, target)
        except StartupSelectionError as error:
            report["training_selection"] = error.diagnostics
            raise
        source_training_sha256 = training_data.fingerprint
        del training_data
        validation_data = load_split(data_dir, "val")
        validation = _choose_validation_records(validation_data)
        source_validation_sha256 = validation_data.fingerprint
        del validation_data
        if str(record["id"]) in {str(r["id"]) for r in validation}:
            raise ValueError("Selected training and validation IDs overlap")
        subset = output / "real_data_subset"
        save_records([record], subset / "train.npz")
        save_records(validation, subset / "validation.npz")
        subset_metadata = {
            "purpose": "Preflight subset, never benchmark evaluation",
            "source_data_dir": str(Path(data_dir).resolve()),
            "source_train_sha256": source_training_sha256,
            "source_validation_sha256": source_validation_sha256,
            "training_selection": selection,
            "validation_ids": [str(r["id"]) for r in validation],
            "validation_atoms": [len(r["Z"]) for r in validation],
            "validation_selection": "median and largest atom count",
        }
        _write_json(subset / "manifest.json", subset_metadata)
        report["data"] = subset_metadata
        report["stage"] = "initial_checkpoint"
        run_dir = output / "trainer"
        code = train(config, subset, run_dir, resume="never", max_updates=0,
                     device=str(requested_device))
        if code != 0:
            raise AssertionError(f"Initial checkpoint trainer returned {code}")
        previous = torch.load(run_dir / "last.pt", map_location="cpu", weights_only=False)
        if previous["state"]["update"] != 0:
            raise AssertionError("Initial checkpoint update is not zero")
        _finite_state(previous["model"], "initial_model")
        report["validation_initial"] = _check_validation(run_dir / "validation_initial.json", len(validation))
        report["updates"] = []
        for cap in (1, 2):
            report["stage"] = f"resumed_update_{cap}"
            _write_json(output / "smoke_status.json", report)
            code = train(config, subset, run_dir, resume="must", max_updates=cap,
                         device=str(requested_device))
            if code != 0:
                raise AssertionError(f"Trainer returned {code} at update cap {cap}")
            current = torch.load(run_dir / "last.pt", map_location="cpu", weights_only=False)
            state = current["state"]
            expected_graphs = cap * training["graphs_per_update"]
            if (state["update"] != cap or state["accepted_graphs"] != expected_graphs or
                    state["graph_attempts"] != expected_graphs or state["rejected_graphs"] != 0):
                raise AssertionError("Expected exact accepted update count with zero skipped/rejected graphs")
            if current["identity"] != previous["identity"]:
                raise AssertionError("Checkpoint identity changed across resume")
            rows = [json.loads(line) for line in (run_dir / "train.jsonl").read_text().splitlines()]
            if [r["update"] for r in rows] != list(range(1, cap + 1)):
                raise AssertionError("Training log does not contain every committed update exactly once")
            row = rows[-1]
            if not math.isfinite(float(row["loss"])) or not math.isfinite(float(row["gradient_norm"])):
                raise AssertionError("Nonfinite loss/gradient norm")
            if row["gradient_norm"] <= 0:
                raise AssertionError("Zero gradient norm does not demonstrate training")
            update = {"update": cap, "resumed_from_update": cap - 1,
                      "loss": row["loss"], "gradient_norm": row["gradient_norm"],
                      "update_seconds": row["update_seconds"],
                      "accepted_graphs": state["accepted_graphs"],
                      "rejected_graphs": state["rejected_graphs"],
                      "parameter_change": _checkpoint_delta(previous, current),
                      "validation": _check_validation(run_dir / f"validation_{cap:07d}.json", len(validation))}
            report["updates"].append(update)
            previous = current
        report["stage"] = "checkpoint_reload"
        reloaded = build_model(previous["config"]).to(device=requested_device, dtype=torch.float32)
        reloaded.load_state_dict(previous["model"], strict=True)
        if any(p.device != requested_device and not (
                requested_device.type == "cuda" and requested_device.index is None and p.device.type == "cuda")
               for p in reloaded.parameters()):
            raise AssertionError("Reloaded model is on the wrong device")
        reloaded.eval()
        prediction = predict_record(reloaded, validation[0], requested_device,
                                    config["validation"]["inference_metric_sigma"],
                                    config["validation"].get("passes", 1))
        if not bool(torch.isfinite(prediction).all()):
            raise AssertionError("Reloaded model produced nonfinite coordinates")
        report["model_parameters"] = sum(p.numel() for p in reloaded.parameters())
        report["checkpoint_sha256"] = _hash_file(run_dir / "last.pt")
        report["checkpoint_reload_valid"] = True
        report["gradient_validation"] = "Production trainer clip_grad_norm_(error_if_nonfinite=True); positive finite norm required"
        report["geometry_rejections"] = 0
        report["accepted_updates"] = 2
        if requested_device.type == "cuda":
            torch.cuda.synchronize(requested_device)
            report["cuda_peak_allocated_bytes"] = torch.cuda.max_memory_allocated(requested_device)
            report["cuda_peak_reserved_bytes"] = torch.cuda.max_memory_reserved(requested_device)
        report.update(status="passed", passed=True, stage="complete", seconds=time.perf_counter() - started)
        _write_json(output / "smoke_status.json", report)
        return report
    except BaseException as error:
        report.update(status="failed", passed=False, seconds=time.perf_counter() - started,
                      error={"type": type(error).__name__, "message": str(error)})
        if report.get("actual_device") and requested_device.type == "cuda" and torch.cuda.is_initialized():
            report["cuda_peak_allocated_bytes"] = torch.cuda.max_memory_allocated(requested_device)
        _write_json(output / "smoke_status.json", report)
        raise
