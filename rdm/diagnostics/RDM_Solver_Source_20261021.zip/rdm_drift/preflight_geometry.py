"""Declared geometric scope for startup checks, not a change to the manifold.

SDF coordinate quantization supplies a conservative perturbation bound. If each
coordinate was rounded at resolution delta, ||E||_F <= delta*sqrt(3*N)/2;
centering cannot enlarge this bound. Weyl's inequality then motivates requiring
the smallest centered-coordinate singular value to exceed that bound before
calling a startup candidate robustly three-dimensional. This is a screening
criterion, not a guarantee that numerical geodesics or every dataset row work.

All records remain in the dataset. The separate Jacobian conditioning limit is
used only to choose a bounded startup example; Exp/Log validity checks and the
metric itself are unchanged.
"""
from __future__ import annotations

from collections import Counter
import math

import numpy as np


DEFAULT_COORDINATE_RESOLUTION_A = 1e-4
DEFAULT_MAX_JACOBIAN_CONDITION = 1e4
DEFAULT_CENSUS_CHUNK_SIZE = 4096


def startup_criteria(config=None):
    """Resolve predeclared optional target['preflight'] settings."""
    options = (config or {}).get("preflight", {})
    if not isinstance(options, dict):
        raise ValueError("preflight configuration must be an object")
    resolution = float(options.get("coordinate_resolution_A", DEFAULT_COORDINATE_RESOLUTION_A))
    condition = float(options.get("max_jacobian_condition", DEFAULT_MAX_JACOBIAN_CONDITION))
    chunk = options.get("coordinate_census_chunk_size", DEFAULT_CENSUS_CHUNK_SIZE)
    if not math.isfinite(resolution) or resolution <= 0:
        raise ValueError("preflight.coordinate_resolution_A must be finite and positive")
    if not math.isfinite(condition) or condition < 1:
        raise ValueError("preflight.max_jacobian_condition must be finite and at least one")
    if isinstance(chunk, bool) or int(chunk) != chunk or chunk < 1:
        raise ValueError("preflight.coordinate_census_chunk_size must be a positive integer")
    return {
        "coordinate_resolution_A": resolution,
        "coordinate_resolution_source": "declared SDF rounding resolution; not an inferred measurement precision",
        "coordinate_criterion": "smallest centered-coordinate singular value > 0.5 * resolution_A * sqrt(3 * n_atoms)",
        "max_jacobian_condition": condition,
        "metric_criterion": "existing horizontal-basis validity and largest/smallest retained J_q singular value <= declared limit",
        "coordinate_census_chunk_size": int(chunk),
        "scope": "Startup-example selection only; does not establish full-dataset metric regularity or noise/solver acceptance.",
    }


def coordinate_diagnostics(coordinates, resolution_A=DEFAULT_COORDINATE_RESOLUTION_A):
    coordinates = np.asarray(coordinates, dtype=np.float64)
    if coordinates.ndim != 2 or coordinates.shape[1] != 3 or not len(coordinates):
        raise ValueError("Coordinates must be a nonempty [atoms,3] array")
    if not math.isfinite(resolution_A) or resolution_A <= 0:
        raise ValueError("Coordinate resolution must be finite and positive")
    bound = 0.5 * float(resolution_A) * math.sqrt(3 * len(coordinates))
    finite = bool(np.isfinite(coordinates).all())
    if not finite:
        return {"finite": False, "n_atoms": len(coordinates),
                "rounding_perturbation_bound_A": bound,
                "singular_values_A": None, "smallest_to_largest_ratio": None,
                "robust_3d_at_declared_resolution": False}
    singular = np.linalg.svd(coordinates - coordinates.mean(0), compute_uv=False)
    # N<3 has fewer than three singular values and cannot demonstrate full 3D.
    singular = np.pad(singular, (0, max(0, 3 - len(singular))))
    ratio = float(singular[-1] / singular[0]) if singular[0] else 0.0
    return {"finite": True, "n_atoms": len(coordinates),
            "rounding_perturbation_bound_A": bound,
            "singular_values_A": singular.tolist(),
            "smallest_to_largest_ratio": ratio,
            "robust_3d_at_declared_resolution": bool(singular[-1] > bound)}


def startup_record_diagnostics(record, criteria=None, metric_options=None):
    """Assess fixed coordinates only; never call Exp, Log, or draw noise."""
    import torch
    from .geometry import horizontal_basis

    criteria = criteria or startup_criteria()
    metric_options = dict(metric_options or {})
    options = {key: metric_options[key] for key in ("alpha", "beta", "rank_rtol", "min_ratio")
               if key in metric_options}
    coordinate = coordinate_diagnostics(record["positions"], criteria["coordinate_resolution_A"])
    result = {"id": str(record["id"]), "n_atoms": coordinate["n_atoms"],
              "coordinates": coordinate, "metric": None, "eligible_for_startup": False,
              "exclusion_reasons": []}
    if not coordinate["finite"]:
        result["exclusion_reasons"].append("nonfinite_coordinates")
        return result
    if not coordinate["robust_3d_at_declared_resolution"]:
        result["exclusion_reasons"].append("not_robust_3d_at_declared_coordinate_resolution")
    if coordinate["n_atoms"] < 4:
        result["exclusion_reasons"].append("fewer_than_four_atoms")
        return result
    x = torch.as_tensor(np.asarray(record["positions"]), dtype=torch.float64, device="cpu")
    radii = torch.as_tensor(np.asarray(record["radii"]), dtype=torch.float64, device="cpu")
    basis = horizontal_basis(x, radii, **options)
    singular = basis["singular_values"].detach().cpu().numpy()
    condition = float(singular[0] / singular[-1]) if len(singular) and singular[-1] > 0 else math.inf
    condition_pass = math.isfinite(condition) and condition <= criteria["max_jacobian_condition"]
    result["metric"] = {
        "jacobian_rank": int(basis["rank"]), "expected_rank": 3 * len(x) - 6,
        "existing_basis_valid": bool(basis["valid"]),
        "jacobian_singular_values": singular.tolist(),
        "jacobian_condition": condition if math.isfinite(condition) else None,
        "jacobian_condition_is_finite": math.isfinite(condition),
        "jacobian_condition_within_startup_limit": condition_pass,
        "metric_options": options,
    }
    if not bool(basis["valid"]):
        result["exclusion_reasons"].append("existing_metric_basis_validity_failed")
    if not condition_pass:
        result["exclusion_reasons"].append("jacobian_condition_exceeds_startup_limit")
    result["eligible_for_startup"] = not result["exclusion_reasons"]
    return result


def coordinate_census(dataset, criteria=None):
    """Chunked reference-coordinate SVD census, honoring NPZ active-atom masks.

    Aggregate counts only: no records are removed or mutated, and no Jacobian,
    corruption, Exp or Log is evaluated by this function.
    """
    criteria = criteria or startup_criteria()
    arrays = dataset.arrays
    positions = np.asarray(arrays["positions"])
    sizes = np.asarray(arrays["n_atoms"], dtype=np.int64)
    if positions.ndim != 3 or positions.shape[-1] != 3 or positions.shape[0] != len(sizes):
        raise ValueError("Census expects packed positions [records,max_atoms,3] and n_atoms [records]")
    if sizes.ndim != 1 or np.any(sizes < 1) or np.any(sizes > positions.shape[1]):
        raise ValueError("Invalid active-atom counts for coordinate census")
    chunk = criteria["coordinate_census_chunk_size"]
    resolution = criteria["coordinate_resolution_A"]
    counts = Counter(records=len(sizes), finite_coordinates=0, nonfinite_coordinates=0,
                     robust_3d_at_declared_resolution=0, not_robust_3d_at_declared_resolution=0,
                     fewer_than_four_atoms=0)
    atom_counts = Counter()
    for start in range(0, len(sizes), chunk):
        n = sizes[start:start + chunk]
        x = np.asarray(positions[start:start + chunk], dtype=np.float64)
        mask = np.arange(positions.shape[1])[None, :] < n[:, None]
        finite = np.all(np.isfinite(x) | ~mask[..., None], axis=(1, 2))
        active = np.where(mask[..., None], x, 0.0)
        active = np.where(finite[:, None, None], active, 0.0)
        center = active.sum(1) / n[:, None]
        centered = np.where(mask[..., None], active - center[:, None, :], 0.0)
        singular = np.linalg.svd(centered, compute_uv=False)
        smallest = singular[:, -1] if positions.shape[1] >= 3 else np.zeros(len(n))
        bound = 0.5 * resolution * np.sqrt(3 * n)
        robust = finite & (smallest > bound)
        counts["finite_coordinates"] += int(finite.sum())
        counts["nonfinite_coordinates"] += int((~finite).sum())
        counts["robust_3d_at_declared_resolution"] += int(robust.sum())
        counts["not_robust_3d_at_declared_resolution"] += int((finite & ~robust).sum())
        counts["fewer_than_four_atoms"] += int((n < 4).sum())
        atom_counts.update(int(value) for value in n)
    return {
        "reference_coordinates_only": True,
        "coordinate_resolution_A": resolution,
        "coordinate_criterion": criteria["coordinate_criterion"],
        "counts": dict(counts),
        "atom_count_histogram": {str(key): atom_counts[key] for key in sorted(atom_counts)},
        "all_records_retained": True,
        "metric_conditioning_coverage": "not evaluated by this census",
        "noise_or_geodesic_acceptance_coverage": "not evaluated by this census",
        "scope": "Aggregate full-training coordinate screening only; robust coordinate rank does not prove metric validity or solver acceptance.",
    }
