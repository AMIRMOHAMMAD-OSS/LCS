"""Audited reconstruction of the authors' raw QM9M SDF pairs.

The strict default never discards a failed record.  The explicitly selected
``official_v0_0_2`` policy permits only unsupported categorical graph features,
matching the pinned author's encoder domain. It does not excuse invalid SDFs,
coordinates, atom identities, duplicates, missing pairs, or unknown failures.
Reconstructed caches are never labelled original authors' processed caches.
"""
import io
import json
import os
import pickle
import re
import tempfile
import uuid
from collections import Counter
from importlib.metadata import version, PackageNotFoundError
from pathlib import Path

import numpy as np
import torch
from rdkit import Chem
from torch_geometric.data import Data

from .data import ENCODED_Z, file_sha256
from .prepare_data import convert_record

REBUILD_SCHEMA = 2
REBUILD_POLICIES = ('strict', 'official_v0_0_2')
OFFICIAL_COMMIT = 'f245954fa2c8626a0d353c3d78c8f79ceb1edb0e'
OFFICIAL_POLICY = {
    'repository': 'https://github.com/seonghann/neural_opt',
    'commit': OFFICIAL_COMMIT,
    'release': 'v0.0.2',
    'encoder_path': 'utils/chem.py',
    'dataset_policy_path': 'dataset/data_module.py',
    'scope': 'Only unsupported categorical atom/bond feature values may be rejected; all other failures remain fatal.',
    'equivalence': 'Raw reconstruction under recorded local dependency versions; not proof of byte-identical original processed cache or population.',
}
FILENAMES = {'train': 'train_proc.pt', 'validation': 'valid_proc.pt', 'test': 'test_proc.pt'}


class UnsupportedGraphFeature(ValueError):
    """A value outside the pinned official categorical encoder's domain."""
    def __init__(self, feature, value, allowed_values, **location):
        self.details = {
            'stage': 'graph_features', 'category': 'unsupported_graph_feature',
            'feature': feature, 'value': str(value),
            'allowed_values': sorted(str(v) for v in allowed_values), **location,
        }
        super().__init__(f'Unsupported official graph feature {feature}={value}')


def _encode(feature, value, encoder, **location):
    if value not in encoder:
        raise UnsupportedGraphFeature(feature, value, encoder, **location)
    return encoder[value]


def _features(mol):
    """The eight atom encodings and four bond types from pinned chem.py."""
    Chem.SanitizeMol(mol)
    encoders = [
        ('GetIsAromatic', {False: 0, True: 1}),
        ('GetFormalCharge', {i: i + 2 for i in range(-2, 3)}),
        ('GetTotalNumHs', {i: i for i in range(6)}),
        ('GetTotalValence', {i: i for i in range(9)}),
        ('GetTotalDegree', {i: i for i in range(8)}),
        ('GetHybridization', {v: k for k, v in Chem.rdchem.HybridizationType.values.items()}),
        ('GetChiralTag', {v: k for k, v in Chem.rdchem.ChiralType.values.items()}),
        ('IsInRing', {False: 0, True: 1}),
    ]
    atoms = sorted(mol.GetAtoms(), key=lambda a: a.GetAtomMapNum())
    features = [[_encode(method, getattr(a, method)(), encoding,
                         atom_map=int(a.GetAtomMapNum()))
                 for method, encoding in encoders] for a in atoms]
    types = {Chem.rdchem.BondType.names[name]: i + 1
             for i, name in enumerate(['SINGLE', 'DOUBLE', 'TRIPLE', 'AROMATIC'])}
    edges = []
    for bond in mol.GetBonds():
        i, j = sorted((bond.GetBeginAtom().GetAtomMapNum() - 1,
                       bond.GetEndAtom().GetAtomMapNum() - 1))
        edges.append((i, j, _encode('GetBondType', bond.GetBondType(), types,
                                   atom_maps=[i + 1, j + 1])))
    # Preserve official undirected edge ordering (sort key uses E, not N).
    edges.sort(key=lambda e: e[0] * len(edges) + e[1])
    index = (torch.tensor([[e[0], e[1]] for e in edges], dtype=torch.long).T
             if edges else torch.empty((2, 0), dtype=torch.long))
    return (torch.tensor(features, dtype=torch.long), index,
            torch.tensor([e[2] for e in edges], dtype=torch.long))


def sdf_pair_to_data(index, reference_bytes, initial_bytes):
    molecules = []
    for block in (reference_bytes, initial_bytes):
        parsed = list(Chem.ForwardSDMolSupplier(io.BytesIO(block), removeHs=False))
        if len(parsed) != 1 or parsed[0] is None:
            raise ValueError('SDF must contain one valid molecule')
        molecules.append(parsed[0])
    ref, initial = molecules
    numbers = [a.GetAtomicNum() for a in ref.GetAtoms()]
    if not numbers or numbers != [a.GetAtomicNum() for a in initial.GetAtoms()]:
        raise ValueError('DFT/MMFF ordered atom elements differ or are empty')
    encoded = {int(z): i for i, z in enumerate(ENCODED_Z)}
    if any(z not in encoded for z in numbers):
        raise ValueError('Unsupported atomic element in SDF pair')
    positions = np.stack([m.GetConformer().GetPositions() for m in molecules], 1)
    if positions.shape != (len(numbers), 2, 3) or not np.isfinite(positions).all():
        raise ValueError('Invalid coordinate/atom array')
    strings = []
    for mol in molecules:
        for atom in mol.GetAtoms():
            atom.SetAtomMapNum(atom.GetIdx() + 1)
        strings.append(Chem.MolToSmarts(mol))
    mapped = Chem.MolFromSmarts(strings[0])
    if mapped is None:
        raise ValueError('Cannot parse DFT mapped SMARTS')
    atoms = sorted(mapped.GetAtoms(), key=lambda a: a.GetAtomMapNum())
    if [a.GetAtomMapNum() for a in atoms] != list(range(1, len(numbers) + 1)):
        raise ValueError('Invalid atom maps after SMARTS conversion')
    if [a.GetAtomicNum() for a in atoms] != numbers:
        raise ValueError('Ordered elements changed during SMARTS conversion')
    # Structural checks above precede classification, so an unsupported feature
    # cannot hide bad coordinates, a missing conformer, or invalid atom identity.
    node_feat, edges, edge_feat = _features(mapped)
    data = Data(x=torch.tensor([encoded[z] for z in numbers], dtype=torch.long),
                pos=torch.as_tensor(positions, dtype=torch.float64),
                edge_index=edges, edge_feat=edge_feat, node_feat=node_feat,
                idx=int(index), smarts=strings[0],
                geodesic_length=torch.zeros((1, 2), dtype=torch.float64))
    convert_record(data)
    return data, strings[0] != strings[1]


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        temporary.write_text(json.dumps(value, indent=2))
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def reconstruction_fingerprints(archive, split_file, policy, allow_missing_ids=(0,)):
    versions = {}
    for name in ('torch', 'torch-geometric', 'numpy', 'rdkit'):
        try:
            versions[name] = version(name)
        except PackageNotFoundError:
            versions[name] = 'unknown'
    code_root = Path(__file__).parent
    return {
        'archive_sha256': file_sha256(archive),
        'split_sha256': file_sha256(split_file), 'policy': policy,
        'allowed_missing_ids': sorted(set(map(int, allow_missing_ids))),
        'code_sha256': {name: file_sha256(code_root / name)
                        for name in ('rebuild_raw.py', 'prepare_data.py', 'data.py')},
        'versions': versions,
    }


def validate_rebuild_cache(output_dir, archive, split_file, policy='strict',
                           allow_missing_ids=(0,), fingerprints=None):
    """Reject partial, stale, differently configured or modified caches."""
    output_dir = Path(output_dir)
    audit_path = output_dir / 'rebuild_audit.json'
    if not audit_path.is_file():
        raise ValueError('Rebuilt cache lacks rebuild_audit.json; use --force-rebuild in the designated rebuilt directory')
    audit = json.loads(audit_path.read_text())
    expected = fingerprints or reconstruction_fingerprints(archive, split_file, policy, allow_missing_ids)
    if (audit.get('schema') != REBUILD_SCHEMA or audit.get('status') != 'complete'
            or audit.get('fingerprints') != expected or audit.get('policy') != policy):
        raise ValueError('Rebuilt cache is incomplete/stale or policy differs; use --force-rebuild')
    if audit.get('fatal_records') or audit.get('unexpected_missing_ids') or audit.get('unpaired_ids'):
        raise ValueError('Rebuilt cache audit contains fatal records or unexpected missing pairs')
    for split, filename in FILENAMES.items():
        entry = audit.get('processed_files', {}).get(split, {})
        path = output_dir / filename
        if not path.is_file() or entry.get('filename') != filename or file_sha256(path) != entry.get('sha256'):
            raise ValueError(f'Rebuilt cache file missing/modified: {filename}; use --force-rebuild')
    return audit


def rebuild_raw(archive, split_file, output_dir, allow_missing_ids=(0,),
                allow_rebuild_rejections=False, rebuild_policy='strict', force_rebuild=False):
    """Return (processed_directory, audit), preserving declared IDs and order.

    ID 0 is a known missing release record. IDs are never shifted. Selection of
    the named encoder policy is explicit; the former blanket skip flag fails.
    """
    if allow_rebuild_rejections:
        raise ValueError('--allow-rebuild-rejections is unsafe and no longer supported; select --rebuild-policy official_v0_0_2 for classified feature failures only')
    if rebuild_policy not in REBUILD_POLICIES:
        raise ValueError(f'Unknown rebuild policy: {rebuild_policy}')
    archive, split_file, output_dir = map(Path, (archive, split_file, output_dir))
    output_dir.mkdir(parents=True, exist_ok=True)
    audit_path = output_dir / 'rebuild_audit.json'
    fingerprints = reconstruction_fingerprints(archive, split_file, rebuild_policy, allow_missing_ids)
    existing_files = any((output_dir / filename).exists() for filename in FILENAMES.values())
    if existing_files and not audit_path.exists():
        raise ValueError('Refusing to overwrite unmarked processed files; choose a separate rebuilt output directory')
    if audit_path.exists() or existing_files:
        if not force_rebuild:
            return output_dir, validate_rebuild_cache(output_dir, archive, split_file,
                rebuild_policy, allow_missing_ids, fingerprints=fingerprints)
        if audit_path.exists():
            backup = output_dir / ('rebuild_audit.before_' + uuid.uuid4().hex + '.json')
            backup.write_bytes(audit_path.read_bytes())
    # Caller validates the trusted published input fingerprint before unpickling.
    with split_file.open('rb') as stream:
        declared = pickle.load(stream)
    keys = {'train': 'train_index', 'validation': 'valid_index', 'test': 'test_index'}
    splits = {name: [int(i) for i in declared[key]] for name, key in keys.items()}
    flat = [i for ids in splits.values() for i in ids]
    if len(flat) != len(set(flat)):
        raise ValueError('Duplicate/overlapping declared split IDs')
    if any(i < 0 for i in flat):
        raise ValueError('Negative declared molecule ID')
    membership = {i: split for split, ids in splits.items() for i in ids}
    audit = {
        'schema': REBUILD_SCHEMA, 'status': 'in_progress', 'policy': rebuild_policy,
        'provenance': 'reconstructed_from_authors_raw_SDF_not_original_processed_cache',
        'official_policy_reference': OFFICIAL_POLICY, 'fingerprints': fingerprints,
        'archive_sha256': fingerprints['archive_sha256'],
        'split_sha256': fingerprints['split_sha256'],
        'order': 'Declared data_split.pkl ID order; no random resplitting and no ID shift',
        'declared_ids_by_split': splits,
        'declared_counts': {k: len(v) for k, v in splits.items()},
        'processed_files': {},
    }
    atomic_json(audit_path, audit)
    selected = set(flat)
    records, pending, errors, mismatch, seen = {}, {}, [], [], set()
    import tarfile
    try:
        with tarfile.open(archive, 'r|*') as tar:
            for member in tar:
                match = re.fullmatch(r'(\d+)(\.mmff)?\.sdf', Path(member.name).name)
                if not member.isfile() or not match:
                    continue
                index = int(match[1])
                kind = 'mmff' if match[2] else 'dft'
                if index not in selected:
                    continue
                if (index, kind) in seen:
                    raise ValueError(f'Duplicate SDF member {index}/{kind}')
                seen.add((index, kind))
                with tar.extractfile(member) as stream:
                    payload = stream.read()
                pair = pending.setdefault(index, {})
                pair[kind] = payload
                if len(pair) == 2:
                    try:
                        records[index], differs = sdf_pair_to_data(index, pair['dft'], pair['mmff'])
                        if differs:
                            mismatch.append(index)
                    except Exception as exc:
                        row = {'id': index, 'split': membership[index],
                               'error_type': type(exc).__name__, 'error': str(exc),
                               'category': 'unexpected_record_failure', 'stage': 'sdf_pair_conversion'}
                        if isinstance(exc, UnsupportedGraphFeature):
                            row.update(exc.details)
                        row['permitted_rejection'] = (isinstance(exc, UnsupportedGraphFeature)
                                                       and rebuild_policy == 'official_v0_0_2')
                        errors.append(row)
                    del pending[index]
                    if (len(records) + len(errors)) % 10000 == 0:
                        print(f'Rebuilt {len(records)} QM9M pairs; classified failures {len(errors)}', flush=True)
    except Exception as exc:
        errors.append({'id': None, 'split': None, 'error_type': type(exc).__name__,
                       'error': str(exc), 'category': 'archive_failure',
                       'stage': 'archive_read', 'permitted_rejection': False})
    rejected = [r for r in errors if r['permitted_rejection']]
    fatal = [r for r in errors if not r['permitted_rejection']]
    rejected_ids = {r['id'] for r in rejected}
    missing = sorted(selected - set(records) - {e['id'] for e in errors})
    allowed = sorted(set(missing) & set(allow_missing_ids))
    audit.update({
        'reconstructed_count': len(records), 'missing_ids': missing,
        'allowed_missing_ids': allowed,
        'unexpected_missing_ids': sorted(set(missing) - set(allow_missing_ids)),
        'unpaired_ids': sorted(pending), 'malformed_records': errors,
        'rejected_records': rejected, 'fatal_records': fatal,
        'error_histogram': dict(Counter(r['category'] + ':' + r.get('feature', r['error_type']) + ':' + r.get('value', '') for r in errors)),
        'DFT_MMFF_smarts_mismatch_ids': sorted(mismatch),
        'retained_ids_by_split': {s: [i for i in ids if i in records] for s, ids in splits.items()},
        'rejected_ids_by_split': {s: [i for i in ids if i in rejected_ids] for s, ids in splits.items()},
        'allowed_missing_ids_by_split': {s: [i for i in ids if i in allowed] for s, ids in splits.items()},
    })
    if fatal or audit['unexpected_missing_ids'] or pending:
        audit['status'] = 'failed'
        atomic_json(audit_path, audit)
        raise ValueError(f'Raw reconstruction incomplete; inspect {audit_path}. '
                         'Strict mode rejects all feature failures; only --rebuild-policy official_v0_0_2 '
                         'permits classified unsupported graph features. Unexpected failures and missing pairs always fail.')
    if any(not audit['retained_ids_by_split'][s] for s in splits):
        audit['status'] = 'failed'
        atomic_json(audit_path, audit)
        raise ValueError('Empty reconstructed split')
    from torch_geometric.data.collate import collate
    # Stage all files; the audit completion marker is committed LAST. Interrupted
    # writes can never be mistaken for a reusable completed cache.
    try:
        with tempfile.TemporaryDirectory(prefix='.rebuild-stage-', dir=output_dir) as staging:
            for split, filename in FILENAMES.items():
                rows = [records[i] for i in audit['retained_ids_by_split'][split]]
                data, slices, _ = collate(Data, rows, increment=False, add_batch=False)
                destination = Path(staging) / filename
                torch.save((data, slices), destination)
                audit['processed_files'][split] = {'count': len(rows), 'filename': filename,
                                                   'sha256': file_sha256(destination)}
            for filename in FILENAMES.values():
                os.replace(Path(staging) / filename, output_dir / filename)
        audit['status'] = 'complete'
        atomic_json(audit_path, audit)
    except Exception:
        audit['status'] = 'failed'
        atomic_json(audit_path, audit)
        raise
    return output_dir, audit


rebuild_processed = rebuild_raw
