"""CPU dataset/provenance validation and content-bound preflight fingerprints.

This module never imports torch or RDKit and never unpickles a source file.
Static checks are explicitly not a dataset check or authorization for a GPU job.
Full dataset validation belongs in a CPU allocation, not on a login node.
"""
from __future__ import annotations

import ast
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import platform
import re
import sys

SCHEMA = 1
SPLITS = ("train", "validation", "test")
QM9_RADII = {1: .31, 6: .76, 7: .71, 8: .66, 9: .57}
SOURCE_MD5 = "55aee4295ad770ae64bd629f8b2080db"
SOURCE_SIZE = 2348212124
DEPENDENCIES = ("numpy", "torch", "torch-geometric", "rdkit", "scipy", "h5py")


def canonical_sha256(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _read_json(path):
    def no_constant(value):
        raise ValueError(f"Nonfinite JSON value {value} in {path}")
    def unique_keys(pairs):
        result = {}
        for key, value in pairs:
            _require(key not in result, f"Duplicate JSON key {key!r} in {path}")
            result[key] = value
        return result
    with Path(path).open() as stream:
        return json.load(stream, parse_constant=no_constant, object_pairs_hook=unique_keys)


def _sha(value, label):
    _require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None,
             f"{label}: missing/invalid SHA256")
    return value


def _ids(value, label):
    _require(isinstance(value, list), f"{label}: expected an ID list")
    result = []
    for item in value:
        _require(not isinstance(item, bool), f"{label}: boolean molecule ID")
        text = str(item)
        _require(re.fullmatch(r"0|[1-9][0-9]*", text) is not None, f"{label}: noncanonical molecule ID {item!r}")
        result.append(text)
    _require(len(result) == len(set(result)), f"{label}: duplicate molecule IDs")
    return result


def source_fingerprint(root):
    """Fingerprint executable source and HPC setup, excluding outputs/caches."""
    root = Path(root).resolve()
    files = {}
    for folder in ("rdm_drift", "scripts", "hpc"):
        directory = root / folder
        _require(directory.is_dir(), f"Missing source directory {directory}")
        for path in sorted(directory.rglob("*")):
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            if path.suffix not in {".py", ".sh", ".sbatch", ".txt", ".toml"}:
                continue
            _require(not path.is_symlink(), f"Source symlinks are not accepted: {path}")
            files[str(path.relative_to(root))] = file_sha256(path)
    _require(files, "No executable source to fingerprint")
    return {"files": files, "sha256": canonical_sha256(files)}


def environment_fingerprint():
    """Installed versions, without loading CUDA or importing heavy packages."""
    versions = {}
    for name in DEPENDENCIES:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    identity = {"python": platform.python_version(), "implementation": platform.python_implementation(),
                "abi": sys.implementation.cache_tag, "machine": platform.machine(),
                "versions": versions}
    return {**identity, "sha256": canonical_sha256(identity)}


def _positive(value, label, integer=False, zero=False):
    _require(isinstance(value, (int, float)) and not isinstance(value, bool)
             and math.isfinite(value) and (value >= 0 if zero else value > 0),
             f"{label}: expected a finite {'nonnegative' if zero else 'positive'} number")
    if integer:
        _require(isinstance(value, int), f"{label}: expected an integer")


def validate_config(config):
    """Check actual runner fields without importing train (or torch)."""
    _require(isinstance(config, dict), "Configuration must be a JSON object")
    _require(config.get("schema_version") == 1, "Unsupported configuration schema_version")
    _require(config.get("objective") in {"intrinsic_drift", "euclidean_drift", "supervised_denoise"}, "Unknown objective")
    for group in ("model", "training", "noise", "geometry", "drift", "validation"):
        _require(isinstance(config.get(group), dict), f"Missing configuration object: {group}")
    _positive(config.get("seed"), "seed", integer=True, zero=True)
    model, training, geometry = config["model"], config["training"], config["geometry"]
    _require(set(model) <= {"hidden", "layers", "radial", "max_displacement"}, "Unknown model constructor argument")
    for key in ("hidden", "layers", "radial"):
        _positive(model.get(key), f"model.{key}", integer=True)
    _require(model["hidden"] >= 2 and model["radial"] >= 2, "Model hidden/radial dimensions must be >= 2")
    _positive(model.get("max_displacement"), "model.max_displacement")
    for key in ("updates", "graphs_per_update", "particles", "checkpoint_every", "validate_every",
                "max_attempts_per_update", "acceptance_gate_after_attempts", "validation_max_records", "log_every"):
        _positive(training.get(key), f"training.{key}", integer=True)
    _require(training["particles"] >= 2, "training.particles must be >= 2")
    _require(training["max_attempts_per_update"] >= training["graphs_per_update"], "Attempt budget smaller than graphs per update")
    _positive(training.get("warmup_updates", 0), "training.warmup_updates", integer=True, zero=True)
    _require(training.get("warmup_updates", 0) <= training["updates"], "Warmup exceeds training updates")
    _positive(training.get("learning_rate"), "training.learning_rate")
    _positive(training.get("grad_clip"), "training.grad_clip")
    _positive(training.get("weight_decay", 0), "training.weight_decay", zero=True)
    acceptance = training.get("minimum_graph_acceptance")
    _positive(acceptance, "training.minimum_graph_acceptance")
    _require(acceptance <= 1, "Minimum acceptance must be <= 1")
    _require(geometry.get("dtype") == "float64", "Geometry must use float64")
    for group in ("log", "exp"):
        _require(isinstance(geometry.get(group), dict), f"Missing geometry.{group}")
    for key in ("n_steps", "max_n_steps", "max_iter", "max_batch_size"):
        _positive(geometry["log"].get(key), f"geometry.log.{key}", integer=True)
    _require(geometry["log"]["max_n_steps"] >= geometry["log"]["n_steps"], "max_n_steps smaller than n_steps")
    for key in ("tolerance", "fd_eps", "damping"):
        _positive(geometry["log"].get(key), f"geometry.log.{key}")
    _positive(geometry["exp"].get("n_steps"), "geometry.exp.n_steps", integer=True)
    for key in ("atol", "rtol"):
        _positive(geometry["exp"].get(key), f"geometry.exp.{key}")
    _require(geometry["exp"].get("check") is True, "Exp certificates must remain enabled")
    noise = config["noise"]
    _require(noise.get("corruption") in {"intrinsic", "euclidean"}, "Unknown noise.corruption")
    schedule = noise.get("schedule")
    _require(isinstance(schedule, list) and len(schedule) >= 1, "Empty noise schedule")
    fractions = []
    for i, item in enumerate(schedule):
        _require(isinstance(item, dict), "Noise schedule entry must be an object")
        _positive(item.get("fraction"), f"noise.schedule[{i}].fraction", zero=True)
        _require(item["fraction"] <= 1, "Noise schedule fraction exceeds 1")
        fractions.append(item["fraction"])
        for key in ("metric_sigma", "max_displacement_A"):
            _positive(item.get(key), f"noise.schedule[{i}].{key}")
    _require(fractions[0] == 0 and all(a < b for a, b in zip(fractions, fractions[1:])), "Schedule must start at 0 and fractions must increase")
    drift = config["drift"]
    temperatures = drift.get("temperature_multipliers")
    _require(isinstance(temperatures, list) and temperatures, "Empty drift temperature list")
    for value in temperatures:
        _positive(value, "drift.temperature_multipliers")
    for key in ("step_size", "max_metric_step_multiplier"):
        _positive(drift.get(key), f"drift.{key}")
    validation = config["validation"]
    _positive(validation.get("seed"), "validation.seed", integer=True, zero=True)
    _positive(validation.get("inference_metric_sigma"), "validation.inference_metric_sigma")
    _require(validation.get("passes") == 1, "This runner's one-step evaluation requires validation.passes=1")
    _require(validation.get("selection_metric") == "mmff_initial_pair_distance_mae", "Unexpected validation selection metric")
    return {"objective": config["objective"], "updates": training["updates"], "particles": training["particles"]}


def config_fingerprint(path):
    path = Path(path).resolve()
    config = _read_json(path)
    details = validate_config(config)
    return {"path": str(path), "sha256": file_sha256(path), "semantic_sha256": canonical_sha256(config), **details}


def validate_static(root, configs):
    """Cheap syntax/config checks only: no dataset reads, imports, or GPU claims."""
    root = Path(root).resolve()
    source = source_fingerprint(root)
    syntax_count = 0
    for name in source["files"]:
        if name.endswith(".py"):
            path = root / name
            ast.parse(path.read_bytes(), filename=str(path))
            syntax_count += 1
    cfg = [config_fingerprint(p if Path(p).is_absolute() else root / p) for p in configs]
    _require(cfg, "At least one training configuration is required")
    return {"schema": SCHEMA, "stage": "static", "status": "checks_passed", "gpu_ready": False,
            "dataset_verified": False, "syntax_files": syntax_count,
            "source": source, "configs": cfg, "environment": environment_fingerprint()}


def _resolve_source(path, raw_root):
    path = Path(path)
    if not path.is_absolute():
        _require(raw_root is not None, "raw_root is required to rehash relative source files")
        path = Path(raw_root) / path
    _require(path.is_file(), f"Missing provenance source: {path}")
    return path


def _verify_hash(path, expected, label):
    actual = file_sha256(path)
    _require(actual == _sha(expected, label), f"{label}: SHA256 mismatch for {path}")
    return actual


def _audit_policy(audit, manifest):
    _require(audit.get("schema") == 2 and audit.get("status") == "complete", "Raw reconstruction audit must be schema 2 and complete")
    policy = audit.get("policy")
    _require(policy in {"strict", "official_v0_0_2"}, "Unknown raw reconstruction policy")
    _require(not audit.get("allow_rebuild_rejections", False), "Blanket allow_rebuild_rejections is not a valid preflight policy")
    for key in ("fatal_records", "unexpected_missing_ids", "unpaired_ids"):
        _require(key in audit and audit[key] == [], f"Raw reconstruction has {key}, or the audit is incomplete")
    fingerprints = audit.get("fingerprints")
    _require(isinstance(fingerprints, dict), "Missing rebuild fingerprints")
    _require(fingerprints.get("policy") == policy, "Rebuild policy fingerprint mismatch")
    _require(fingerprints.get("allowed_missing_ids") == [0], "Only the release's known absent ID 0 may be allowed")
    for key in ("archive_sha256", "split_sha256"):
        _sha(fingerprints.get(key), f"rebuild fingerprints.{key}")
    _require(isinstance(fingerprints.get("versions"), dict) and fingerprints["versions"], "Missing reconstruction dependency versions")
    code = fingerprints.get("code_sha256")
    _require(isinstance(code, dict) and {"rebuild_raw.py", "prepare_data.py"} <= set(code), "Missing reconstruction code fingerprints")
    for name, digest in code.items():
        _require(Path(name).name == name, "Invalid rebuild source filename")
        current = Path(__file__).parent / name
        _require(current.is_file(), f"Rebuild source is absent: {name}")
        _require(file_sha256(current) == _sha(digest, f"rebuild source {name}"),
                 f"Reconstruction source changed: {name}; rebuild with current code")
    current_versions = environment_fingerprint()["versions"]
    for name in ("torch", "torch-geometric", "numpy", "rdkit"):
        _require(fingerprints["versions"].get(name) is not None
                 and fingerprints["versions"][name] == current_versions.get(name),
                 f"Reconstruction dependency changed/missing: {name}; rebuild in the selected environment")
    records = audit.get("rejected_records")
    _require(isinstance(records, list), "Missing structured rejection records")
    if policy == "strict":
        _require(not records, "Strict reconstruction policy contains rejected records")
    rejected = {}
    supported_names = {"GetIsAromatic", "GetFormalCharge", "GetTotalNumHs", "GetTotalValence", "GetTotalDegree",
                       "GetHybridization", "GetChiralTag", "IsInRing", "GetBondType"}
    for row in records:
        _require(isinstance(row, dict), "Malformed rejection audit entry")
        index = _ids([row.get("id")], "rejection id")[0]
        _require(index not in rejected, "Duplicate rejection audit ID")
        _require(row.get("split") in SPLITS, "Rejected record has no declared split")
        _require(row.get("category") == "unsupported_graph_feature" and row.get("error_type") == "UnsupportedGraphFeature"
                 and row.get("stage") == "graph_features" and row.get("feature") in supported_names and "value" in row,
                 f"Rejection {index} is not an audited unsupported official graph feature")
        allowed_values = row.get("allowed_values")
        _require(isinstance(allowed_values, list) and allowed_values and all(isinstance(v, str) for v in allowed_values),
                 f"Rejection {index} lacks the explicit official encoder categories")
        _require(isinstance(row["value"], str) and row["value"] not in allowed_values,
                 f"Rejection {index} was actually supported by its encoder")
        fixed_categories = {
            "GetIsAromatic": {"False", "True"}, "IsInRing": {"False", "True"},
            "GetFormalCharge": {str(v) for v in range(-2, 3)},
            "GetTotalNumHs": {str(v) for v in range(6)},
            "GetTotalValence": {str(v) for v in range(9)},
            "GetTotalDegree": {str(v) for v in range(8)},
            "GetBondType": {"SINGLE", "DOUBLE", "TRIPLE", "AROMATIC"},
        }
        if row["feature"] in fixed_categories:
            _require(set(allowed_values) == fixed_categories[row["feature"]],
                     f"Rejection {index} used nonofficial encoder categories")
        rejected[index] = row["split"]
    for split in SPLITS:
        listed = _ids(audit.get("rejected_ids_by_split", {}).get(split), f"audit {split} rejected")
        _require(set(listed) == {i for i, s in rejected.items() if s == split}, f"{split}: rejected IDs do not match structured records")
        meta = manifest["splits"][split]
        for audit_key, manifest_key in (("declared_ids_by_split", "declared_ids"), ("retained_ids_by_split", "retained_ids"),
                                        ("rejected_ids_by_split", "rejected_ids"), ("allowed_missing_ids_by_split", "allowed_missing_ids")):
            left = _ids(audit.get(audit_key, {}).get(split), f"audit {split} {audit_key}")
            right = _ids(meta.get(manifest_key), f"manifest {split} {manifest_key}")
            _require(left == right, f"{split}: manifest/audit {manifest_key} mismatch")
        processed = audit.get("processed_files", {}).get(split, {})
        _require(processed.get("count") == meta.get("count"), f"{split}: processed/audit count mismatch")
        _require(processed.get("sha256") == meta.get("processed_sha256"), f"{split}: processed/audit hash mismatch")
    official_split = manifest.get("official_split_file") or {}
    _require(official_split.get("sha256") == fingerprints["split_sha256"], "Official split/rebuild fingerprint mismatch")
    return policy


def validate_dataset(data_dir, raw_root=None):
    """Validate every packed row and the auditable split population on CPU.

    Hashes all three NPZs, the manifest, and (when raw_root is supplied) the
    processed and declared-source files. No pickle/PyG source is deserialized.
    """
    import numpy as np
    data_dir = Path(data_dir).resolve()
    raw_root = None if raw_root is None else Path(raw_root).resolve()
    manifest_path = data_dir / "manifest.json"
    manifest = _read_json(manifest_path)
    _require(manifest.get("schema") == 2 and manifest.get("status") == "complete", "Prepared manifest must be schema 2 and complete; rerun repaired preparation")
    _require(manifest.get("coordinates") == "Angstrom", "Expected Angstrom coordinates")
    _require(manifest.get("trust_local_pt") is False, "Locally trusted, unverifiable PyG caches cannot pass the release benchmark gate")
    _require(set(manifest.get("splits", {})) == set(SPLITS), "Manifest must contain exactly train/validation/test splits")
    source = manifest.get("source", {})
    _require(source.get("md5") == SOURCE_MD5 and source.get("size") == SOURCE_SIZE, "Unexpected source release")
    release = manifest.get("release")
    _require(isinstance(release, dict), "Missing verified release provenance")
    _require(release.get("source") == source, "Manifest/release source disagreement")
    _sha(release.get("archive_sha256"), "release.archive_sha256")
    release_files = release.get("files")
    _require(isinstance(release_files, list) and release_files, "Missing verified extraction inventory")
    for item in release_files:
        _require(isinstance(item, dict) and isinstance(item.get("path"), str), "Invalid verified extraction inventory")
        _sha(item.get("sha256"), "release extracted file")
    _require(manifest.get("source_verified") is True, "Preparation source verification did not pass")
    verified_sources = manifest.get("verified_source_files")
    _require(isinstance(verified_sources, list) and verified_sources, "Missing selected source verification records")
    inventory = {item["path"]: item["sha256"] for item in release_files}
    _require(len(inventory) == len(release_files), "Duplicate paths in extraction inventory")
    for item in verified_sources:
        _require(isinstance(item, dict) and item.get("verified") is True,
                 "Unverified selected preparation source")
        _require(inventory.get(item.get("relative_path")) == item.get("sha256"),
                 "Selected source hash does not match verified extraction inventory")
    origin = manifest.get("processed_origin")
    _require(origin in {"raw_rebuild", "authors_processed_cache"}, "Unknown processed data origin")
    if origin == "raw_rebuild":
        policy = _audit_policy(manifest.get("raw_rebuild", {}), manifest)
    else:
        policy = "authors_processed_cache"
        _require(not manifest.get("raw_rebuild"), "Authors-cache claim conflicts with rebuild audit")
    split_file = manifest.get("official_split_file")
    _require(isinstance(split_file, dict), "Missing official split source; cannot establish benchmark membership/order")
    _sha(split_file.get("sha256"), "official split file")
    _require(any(item["sha256"] == split_file["sha256"] and Path(item["path"]).name == "data_split.pkl" for item in release_files), "Official split hash is not in verified extraction inventory")
    wrong_source = manifest.get("official_exclusion_file")
    wrong_ids = None
    if wrong_source is not None:
        _require(isinstance(wrong_source, dict), "Invalid exclusion source")
        wrong_ids = set(_ids(wrong_source.get("ids"), "official exclusion IDs"))
        _sha(wrong_source.get("sha256"), "official exclusion file")
        _require(any(item["sha256"] == wrong_source["sha256"] and Path(item["path"]).name == "wrong_samples.pkl" for item in release_files), "Official exclusion hash is not in verified extraction inventory")
    raw_hashes = {}
    if raw_root is not None:
        verified = _read_json(raw_root / "verified_release.json")
        _require(verified == release, "Stored and current verified release manifests differ")
        raw_hashes["verified_release.json"] = file_sha256(raw_root / "verified_release.json")
        for label, item in (("official_split_file", split_file), ("official_exclusion_file", wrong_source)):
            if item is not None:
                path = _resolve_source(item.get("path", ""), raw_root)
                raw_hashes[label] = _verify_hash(path, item["sha256"], label)
        if origin == "raw_rebuild":
            processed_dirs = {_resolve_source(manifest["splits"][split].get("processed_file", ""), raw_root).parent for split in SPLITS}
            _require(len(processed_dirs) == 1, "Reconstructed caches are from different directories")
            audit_file = next(iter(processed_dirs)) / "rebuild_audit.json"
            _require(_read_json(audit_file) == manifest["raw_rebuild"], "Current rebuild audit differs from prepared manifest")
            raw_hashes["rebuild_audit.json"] = file_sha256(audit_file)
            digest = manifest["raw_rebuild"]["fingerprints"]["archive_sha256"]
            matches = [item for item in release_files if item["sha256"] == digest and Path(item["path"]).name == "qm9_mmff.tar.bz2"]
            _require(len(matches) == 1, "Raw rebuild archive is absent/ambiguous in verified extraction inventory")
            raw_hashes["raw_archive"] = _verify_hash(raw_root / matches[0]["path"], digest, "raw reconstruction archive")
    seen_ids, declared_all, split_reports, hashes = set(), set(), {}, {}
    for split in SPLITS:
        path = data_dir / f"{split}.npz"
        meta = manifest["splits"][split]
        hashes[path.name] = _verify_hash(path, meta.get("npz_sha256"), split)
        declared = _ids(meta.get("declared_ids"), f"{split} declared IDs")
        retained = _ids(meta.get("retained_ids"), f"{split} retained IDs")
        rejected = _ids(meta.get("rejected_ids"), f"{split} rejected IDs")
        missing = _ids(meta.get("allowed_missing_ids"), f"{split} allowed missing IDs")
        _require(not (declared_all & set(declared)), "Declared split ID overlap")
        declared_all.update(declared)
        _require(set(missing) <= {"0"}, f"{split}: unexpected missing IDs")
        _require(not set(rejected) & set(missing), f"{split}: rejection/missing overlap")
        _require(set(rejected) | set(missing) <= set(declared), f"{split}: excluded IDs outside declared split")
        if origin == "raw_rebuild":
            _require(retained == [i for i in declared if i not in set(rejected) | set(missing)], f"{split}: retained order or membership does not match declared split")
        else:
            _require(set(retained) == set(declared), f"{split}: authors cache membership differs from declared split without an audit")
        if origin == "authors_processed_cache":
            _require(not rejected and not missing, "Authors-cache population missing declared IDs without a reconstruction audit")
            _require(any(item["sha256"] == meta.get("processed_sha256") for item in release_files), f"{split}: original cache hash not in release inventory")
        _require(meta.get("declared_count") == len(declared), f"{split}: declared count mismatch")
        _require(meta.get("count") == len(retained), f"{split}: retained count mismatch")
        _require(meta.get("ids_order_sha256") == canonical_sha256(retained), f"{split}: ID order digest mismatch")
        if "declared_ids_missing_from_processed" in meta:
            absent = _ids(meta["declared_ids_missing_from_processed"], f"{split} missing IDs")
            _require(set(absent) == set(rejected) | set(missing), f"{split}: unaccounted missing declared IDs")
        if raw_root is not None:
            src = _resolve_source(meta.get("processed_file", ""), raw_root)
            raw_hashes[f"{split}_processed"] = _verify_hash(src, meta.get("processed_sha256"), f"{split} processed cache")
        with np.load(path, allow_pickle=False) as archive:
            required = {"id", "Z", "n_atoms", "positions", "initial_positions", "radii", "bonds", "smarts", "paper_eligible", "exclusion_reason"}
            _require(required <= set(archive.files), f"{split}: missing arrays {required - set(archive.files)}")
            arrays = {key: archive[key] for key in archive.files}
        _require(all(a.dtype.kind != "O" for a in arrays.values()), f"{split}: object arrays are forbidden")
        ids = arrays["id"]
        _require(ids.ndim == 1 and ids.dtype.kind in "US", f"{split}: id must be a string vector")
        ids_list = _ids(ids.tolist(), f"{split} NPZ IDs")
        _require(ids_list == retained, f"{split}: NPZ ID order differs from declared retained order")
        _require(not seen_ids & set(ids_list), "Packed split ID overlap")
        seen_ids.update(ids_list)
        count = len(ids_list)
        _require(count > 0, f"{split}: empty split")
        z = arrays["Z"]
        _require(z.ndim == 2 and z.shape[0] == count and z.dtype.kind in "iu", f"{split}: invalid Z shape/dtype")
        nmax = z.shape[1]
        _require(nmax > 0, f"{split}: no atom slots")
        expected = {"n_atoms": (count,), "positions": (count, nmax, 3), "initial_positions": (count, nmax, 3),
                    "radii": (count, nmax), "bonds": (count, nmax, nmax), "smarts": (count,),
                    "paper_eligible": (count,), "exclusion_reason": (count,)}
        for key, shape in expected.items():
            _require(arrays[key].shape == shape, f"{split}: {key} shape {arrays[key].shape}, expected {shape}")
        for key in ("positions", "initial_positions", "radii"):
            _require(arrays[key].dtype.kind == "f" and arrays[key].dtype.itemsize == 8, f"{split}: {key} must be float64")
        _require(arrays["n_atoms"].dtype.kind in "iu", f"{split}: n_atoms must be integral")
        _require(arrays["bonds"].dtype.kind in "iu", f"{split}: bonds must be integral")
        _require(arrays["paper_eligible"].dtype.kind == "b", f"{split}: paper_eligible must be bool")
        for key in ("smarts", "exclusion_reason"):
            _require(arrays[key].dtype.kind in "US", f"{split}: {key} must be strings")
        n_atoms = arrays["n_atoms"]
        _require(np.all((n_atoms >= 1) & (n_atoms <= nmax)), f"{split}: n_atoms out of bounds")
        reconstructed_bad, eligible_count = set(), 0
        for start in range(0, count, 2048):
            end = min(count, start + 2048)
            active = np.arange(nmax)[None, :] < n_atoms[start:end, None]
            zb = z[start:end]
            _require(np.isin(zb[active], list(QM9_RADII)).all(), f"{split}: invalid QM9 atomic element")
            _require(np.all(zb[~active] == 0), f"{split}: nonzero atom padding")
            for key in ("positions", "initial_positions", "radii"):
                values = arrays[key][start:end]
                _require(np.isfinite(values).all(), f"{split}: nonfinite {key}")
                _require(np.all(values[~active] == 0), f"{split}: nonzero {key} padding")
            radii = arrays["radii"][start:end]
            for number, radius in QM9_RADII.items():
                _require(np.allclose(radii[zb == number], radius, rtol=0, atol=1e-12), f"{split}: covalent radii do not match elements")
            bonds = arrays["bonds"][start:end]
            _require(np.all((bonds >= 0) & (bonds <= 4)), f"{split}: bond types outside 0..4")
            _require(np.array_equal(bonds, bonds.swapaxes(1, 2)), f"{split}: asymmetric bonds")
            _require(np.all(np.diagonal(bonds, axis1=1, axis2=2) == 0), f"{split}: bond diagonal must be zero")
            _require(np.all(bonds[~(active[:, :, None] & active[:, None, :])] == 0), f"{split}: nonzero bond padding")
            deltas = arrays["positions"][start:end] - arrays["initial_positions"][start:end]
            same = np.sqrt(np.square(deltas).sum(axis=(1, 2)) / n_atoms[start:end]) < 1e-9
            for offset in range(end - start):
                i = start + offset
                reasons = []
                if bool(same[offset]):
                    reasons.append("MMFF_equals_DFT")
                if "." in str(arrays["smarts"][i]):
                    reasons.append("disconnected_graph")
                _require(str(arrays["smarts"][i]).strip(), f"{split}: empty mapped SMARTS")
                if reasons:
                    reconstructed_bad.add(ids_list[i])
                eligible = ids_list[i] not in wrong_ids if split == "test" and wrong_ids is not None else not reasons
                actual = bool(arrays["paper_eligible"][i])
                _require(actual == eligible, f"{split}/{ids_list[i]}: incorrect paper eligibility")
                reason = str(arrays["exclusion_reason"][i])
                expected_reason = ";".join(reasons)
                if split == "test" and wrong_ids is not None and not eligible and not reasons:
                    expected_reason = "official_wrong_samples"
                _require(reason == expected_reason, f"{split}/{ids_list[i]}: incorrect exclusion reason")
                eligible_count += int(actual)
        _require(meta.get("paper_eligible") == eligible_count, f"{split}: eligible count mismatch")
        if split == "test" and wrong_ids is not None:
            disagreements = sorted(reconstructed_bad.symmetric_difference(wrong_ids & set(ids_list)), key=int)
            _require(manifest.get("exclusion_rule_disagreements") == disagreements, "Official/reconstructed exclusion disagreement audit mismatch")
        split_reports[split] = {"count": count, "paper_eligible": eligible_count, "max_atoms": int(n_atoms.max()),
                                "declared_count": len(declared), "rejected_count": len(rejected), "known_missing_count": len(missing),
                                "ids_order_sha256": canonical_sha256(ids_list), "npz_sha256": hashes[path.name]}
    hashes["manifest.json"] = file_sha256(manifest_path)
    identity = {"files": hashes, "raw_sources": raw_hashes}
    return {"schema": SCHEMA, "stage": "full_dataset", "status": "passed", "dataset_verified": True,
            "gpu_ready": False, "processed_origin": origin, "policy": policy,
            "benchmark_claim": "reconstructed declared population with explicit eligibility/exclusions" if origin == "raw_rebuild" else "verified authors processed cache",
            "raw_sources_rehashed": raw_root is not None, "splits": split_reports,
            **identity, "sha256": canonical_sha256(identity)}


def snapshot(root, data_dir, configs, full_data=True, raw_root=None):
    """Bind a gate report to source, exact config bytes, environment and data.

    full_data=False is a *static-only* snapshot and cannot satisfy a GPU gate.
    Full snapshots intentionally cost a complete dataset/provenance read.
    """
    static = validate_static(root, configs)
    dataset = validate_dataset(data_dir, raw_root=raw_root) if full_data else {
        "dataset_verified": False, "status": "not_checked", "path": str(Path(data_dir).resolve())}
    identity = {"source": static["source"], "configs": static["configs"],
                "environment": static["environment"], "dataset": dataset}
    return {"schema": SCHEMA, "stage": "full_cpu_snapshot" if full_data else "static_snapshot",
            "gpu_ready": False, "dataset_verified": full_data, **identity,
            "sha256": canonical_sha256(identity)}
