"""Portable, pickle-free, indexed QM9M data used by every method."""
from pathlib import Path
import hashlib
import json
import numpy as np

RADII = {1:.31,6:.76,7:.71,8:.66,9:.57,16:1.05,17:1.02}
ENCODED_Z = np.array([1,6,7,8,9,16,17], dtype=np.int16)

def file_sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()

class PackedDataset:
    def __init__(self,path):
        self.path=Path(path)
        with np.load(path,allow_pickle=False) as f:self.arrays={k:f[k] for k in f.files}
        a=self.arrays
        for k in ('id','Z','n_atoms','positions','initial_positions','radii'):
            if k not in a:raise ValueError(f'{path}: missing {k}')
        if len(set(a['id'].tolist()))!=len(a['id']):raise ValueError('Duplicate molecule IDs')
        self.fingerprint=file_sha256(path)
        self.metadata={}
        p=self.path.parent/'manifest.json'
        if p.exists():self.metadata=json.loads(p.read_text())
    def __len__(self):return len(self.arrays['id'])
    def __getitem__(self,index):
        if isinstance(index,slice):return [self[i] for i in range(*index.indices(len(self)))]
        a=self.arrays;n=int(a['n_atoms'][index])
        r={'id':str(a['id'][index]),'Z':a['Z'][index,:n].astype(np.int64),
           'positions':a['positions'][index,:n].astype(np.float64),
           'initial_positions':a['initial_positions'][index,:n].astype(np.float64),
           'radii':a['radii'][index,:n].astype(np.float64)}
        for k in ('smarts','smiles','paper_eligible','exclusion_reason'):
            if k in a:r[k]=a[k][index].item()
        if 'bonds' in a:r['bonds']=a['bonds'][index,:n,:n].astype(np.int64)
        return r

def load_split(data_dir,split='train'):
    split={'val':'validation','valid':'validation'}.get(split,split)
    path=Path(data_dir)
    return PackedDataset(path if path.suffix=='.npz' else path/f'{split}.npz')

def save_records(records,path):
    """Write an indexed padded NPZ; no Python objects/pickle in the result."""
    records=list(records)
    if not records:raise ValueError('Cannot save an empty split')
    count=len(records);nmax=max(len(r['Z']) for r in records)
    a={'id':np.array([str(r['id']) for r in records]),'n_atoms':np.array([len(r['Z']) for r in records],dtype=np.int16),
       'Z':np.zeros((count,nmax),np.int16),'positions':np.zeros((count,nmax,3),np.float64),
       'initial_positions':np.zeros((count,nmax,3),np.float64),'radii':np.zeros((count,nmax),np.float64),
       'bonds':np.zeros((count,nmax,nmax),np.int8),
       'smarts':np.array([r.get('smarts','') for r in records]),
       'paper_eligible':np.array([r.get('paper_eligible',True) for r in records],bool),
       'exclusion_reason':np.array([r.get('exclusion_reason','') for r in records])}
    for i,r in enumerate(records):
        n=len(r['Z'])
        for k in ('Z','positions','initial_positions','radii'):a[k][i,:n]=r[k]
        a['bonds'][i,:n,:n]=r.get('bonds',np.zeros((n,n)))
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp.npz');np.savez_compressed(temp,**a);temp.replace(path)
    return file_sha256(path)
