"""Fail-closed static, CPU and GPU preflight stages; no automatic job submission."""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
DATA_FILES = ('train.npz', 'validation.npz', 'test.npz', 'manifest.json')
REPORT_SCHEMA = 1


def _hash_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def _json_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f'.{os.getpid()}.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    os.replace(temporary, path)


def bindings(config_path, data_dir, env_file, *, full_data=False, runtime=False, root=None):
    """Login-safe by default: hash source/config/environment file, stat NPZ only."""
    from .preflight_checks import source_fingerprint
    root = Path(root or ROOT)
    config_path, data_dir, env_file = map(Path, (config_path, data_dir, env_file))
    config = json.loads(config_path.read_text())
    value = {'source': source_fingerprint(root), 'config_sha256': _json_hash(config),
             'site_env_sha256': _hash_file(env_file), 'data_dir': str(data_dir.resolve()), 'data': {}}
    for name in DATA_FILES:
        path = data_dir / name
        stat = path.stat()
        if not path.is_file() or stat.st_size == 0:
            raise ValueError(f'Missing/empty prepared dataset file: {path}; run CPU preflight preparation first.')
        item = {'size': stat.st_size, 'mtime_ns': stat.st_mtime_ns}
        if full_data:
            item['sha256'] = _hash_file(path)
            after = path.stat()
            if (after.st_size, after.st_mtime_ns) != (stat.st_size, stat.st_mtime_ns):
                raise ValueError(f'Dataset changed during fingerprinting: {path}')
        value['data'][name] = item
    if runtime:
        from .preflight_checks import environment_fingerprint
        value['runtime'] = environment_fingerprint()
    return value


def verify_report(report_path, stage, config_path, data_dir, env_file, *, full_data=False, runtime=False, root=None):
    """Require PASS plus fresh content bindings. Full data/runtime checks run in batch."""
    report_path = Path(report_path)
    try:
        report = json.loads(report_path.read_text())
    except (OSError, ValueError) as exc:
        raise ValueError(f'Cannot read {stage.upper()} preflight report {report_path}: {exc}') from exc
    if report.get('schema') != REPORT_SCHEMA or report.get('stage') != stage or report.get('status') != 'PASS':
        raise ValueError(f'{report_path} is not a PASS report for stage {stage}. Run that preflight stage successfully first.')
    expected = report.get('bindings', {})
    actual = bindings(config_path, data_dir, env_file, full_data=full_data, runtime=runtime, root=root)
    errors = []
    for key in ('source', 'config_sha256', 'site_env_sha256', 'data_dir'):
        if expected.get(key) != actual.get(key):
            errors.append(key)
    for name, observed in actual['data'].items():
        saved = expected.get('data', {}).get(name, {})
        for key, val in observed.items():
            if saved.get(key) != val:
                errors.append(f'{name}:{key}')
    if runtime and expected.get('runtime') != actual.get('runtime'):
        errors.append('runtime packages/Python')
    if errors:
        raise ValueError(f'Stale {stage.upper()} preflight report: changed {", ".join(errors)}. Repeat CPU then GPU preflight for this exact configuration/environment/data.')
    if not all(expected.get('data', {}).get(name, {}).get('sha256') for name in DATA_FILES):
        raise ValueError('Preflight report lacks full dataset hashes; rerun CPU/GPU preflight.')
    return report


def require_batch(stage, allow_local=False):
    if not os.environ.get('SLURM_JOB_ID') and not allow_local:
        raise ValueError(f'{stage.upper()} preflight performs computation and must run in a Slurm allocation. Use scripts/submit_preflight.py; --allow-local is only for an intentional laptop/test run.')


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage', choices=('static', 'cpu', 'gpu'))
    p.add_argument('--config', required=True)
    p.add_argument('--data', required=True)
    p.add_argument('--env-file', required=True)
    p.add_argument('--output', required=True, help='Dedicated stage output directory; report is output/report.json')
    p.add_argument('--raw-root', help='Previously verified extraction directory; required with --prepare')
    p.add_argument('--prepare', action='store_true', help='CPU stage only: reconstruct/pack the released data before checking it')
    p.add_argument('--force-rebuild', action='store_true', help='CPU preparation only: rebuild prior caches rather than reuse them')
    p.add_argument('--cpu-report', help='GPU stage requires a matching CPU PASS report')
    p.add_argument('--allow-local', action='store_true', help='Explicitly allow computation outside Slurm (laptop/testing only)')
    return p


def run_stage(a):
    from .preflight_checks import validate_static, validate_dataset
    output = Path(a.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    report_path = output / 'report.json'
    report = {'schema': REPORT_SCHEMA, 'stage': a.stage, 'status': 'RUNNING',
              'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
              'job_id': os.environ.get('SLURM_JOB_ID'), 'config': str(Path(a.config).resolve()),
              'data': str(Path(a.data).resolve()), 'environment_file': str(Path(a.env_file).resolve()),
              'scope': 'Preflight checks only; no full training or paper-result reproduction is certified.'}
    atomic_json(report_path, report)  # invalidate an old PASS before doing any new work
    try:
        if a.stage != 'static':
            require_batch(a.stage, a.allow_local)
        if a.prepare and a.stage != 'cpu':
            raise ValueError('--prepare is only supported for the CPU stage')
        if a.force_rebuild and not a.prepare:
            raise ValueError('--force-rebuild requires --prepare')
        if not Path(a.env_file).is_file():
            raise ValueError(f'Missing environment configuration: {a.env_file}')
        report['static'] = validate_static(ROOT, [a.config])
        if a.stage == 'static':
            # Deliberately do not open/hash large archives or NPZ arrays on login nodes.
            report['data_inventory'] = {
                name: {'exists': (Path(a.data) / name).is_file(),
                       'bytes': (Path(a.data) / name).stat().st_size if (Path(a.data) / name).is_file() else None}
                for name in DATA_FILES}
            report['scope'] = 'Source/config checks and path inventory only. No dataset or training validation; cannot authorize GPU submission.'
        else:
            if a.stage == 'cpu':
                os.environ['CUDA_VISIBLE_DEVICES'] = ''
                if a.prepare:
                    if not a.raw_root:
                        raise ValueError('--prepare requires --raw-root with the verified extracted release')
                    from .prepare_data import prepare
                    report['preparation'] = prepare(a.raw_root, a.data, rebuild_policy='official_v0_0_2', force_rebuild=a.force_rebuild)
                report['dataset'] = validate_dataset(a.data, raw_root=a.raw_root)
                if report['dataset'].get('dataset_verified') is not True or report['dataset'].get('status') != 'passed':
                    raise ValueError('Dataset validator did not return a full successful validation')
            else:
                if not a.cpu_report:
                    raise ValueError('GPU smoke requires --cpu-report from a completed CPU preflight')
                verify_report(a.cpu_report, 'cpu', a.config, a.data, a.env_file, full_data=True, runtime=True)
                report['cpu_report'] = str(Path(a.cpu_report).resolve())
                report['cpu_report_sha256'] = _hash_file(a.cpu_report)
            before = bindings(a.config, a.data, a.env_file, full_data=True, runtime=True)
            from .preflight_smoke import run_smoke
            report['smoke'] = run_smoke(a.data, a.config, output / 'smoke', device='cpu' if a.stage == 'cpu' else 'cuda')
            if report['smoke'].get('passed') is not True or report['smoke'].get('accepted_updates') != 2:
                raise ValueError('Training smoke did not certify both real accepted updates and checkpoint resume')
            after = bindings(a.config, a.data, a.env_file, full_data=True, runtime=True)
            if before != after:
                raise ValueError('Source/config/environment/data changed while preflight ran; rerun with stable inputs')
            report['bindings'] = after
        report['status'] = 'PASS'
    except Exception as exc:
        report.update(status='FAIL', error=f'{type(exc).__name__}: {exc}', traceback=traceback.format_exc())
        report['finished_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
        atomic_json(report_path, report)
        print(f'PREFLIGHT FAIL: {exc}\nReport: {report_path}', file=sys.stderr, flush=True)
        return 1
    report['finished_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
    atomic_json(report_path, report)
    print(f'PREFLIGHT {a.stage.upper()} PASS: {report_path}', flush=True)
    return 0


def main(argv=None):
    return run_stage(parser().parse_args(argv))


if __name__ == '__main__':
    raise SystemExit(main())
