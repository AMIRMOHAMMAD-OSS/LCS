"""Single-GPU, restartable fixed-graph molecular refinement experiments.

Numerical geometry is float64, the equivariant neural model is float32. The
CPU/SVD/shooting cost must be measured on the actual A100 before a heavy run.
No DFT energy, reference coordinate, or reference-derived alignment is consumed
by prediction on the official MMFF test inputs.
"""
from __future__ import annotations

import argparse
from collections import Counter
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import random
import signal
import sys
import time
import traceback

import numpy as np
import torch

from .data import load_split
from .geometry import proper_align
from .model import build_model
from .objectives import GeometryFailure, corrupt_reference, noise_parameters, objective_loss


def _jsonable(value):
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if torch.is_tensor(value):
        return _jsonable(value.detach().cpu().tolist())
    if isinstance(value, np.ndarray):
        return _jsonable(value.tolist())
    if isinstance(value, np.generic):
        return _jsonable(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Path):
        return str(value)
    return value


def _write_json(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(_jsonable(content), indent=2, sort_keys=True, allow_nan=False) + "\n")
    os.replace(temporary, path)


def _append_json(path, content):
    with Path(path).open("a") as stream:
        stream.write(json.dumps(_jsonable(content), sort_keys=True, allow_nan=False) + "\n")
        stream.flush()


def _rewind_logs(output, state):
    """Remove uncommitted tail records after resuming a crash checkpoint."""
    for name in ("train.jsonl", "validation.jsonl", "acceptance_windows.jsonl", "geometry.jsonl", "failures.jsonl"):
        path = output / name
        if not path.exists():
            continue
        retained = []
        for line in path.read_text().splitlines():
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue  # A kill during one append can leave a partial last line.
            if row.get("update", 0) <= state["update"]:
                retained.append(json.dumps(row, sort_keys=True))
        temporary = Path(str(path) + ".tmp")
        temporary.write_text("\n".join(retained) + ("\n" if retained else ""))
        os.replace(temporary, path)


def _hash_json(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _hash_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _dataset_hash(data_dir):
    """Content hash, not mtime/size identity. Computed once per process startup."""
    root = Path(data_dir)
    files = sorted(p for p in root.rglob("*") if p.is_file() and p.suffix in {".npz", ".json"})
    if not files:
        raise ValueError(f"No .npz/.json dataset files under {root}")
    digest = hashlib.sha256()
    for path in files:
        digest.update(str(path.relative_to(root)).encode())
        digest.update(_hash_file(path).encode())
    return digest.hexdigest()


def _code_hash():
    root = Path(__file__).parent
    digest = hashlib.sha256()
    for name in ("train.py", "model.py", "objectives.py", "geometry.py", "data.py"):
        digest.update(name.encode())
        digest.update((root / name).read_bytes())
    return digest.hexdigest()


def _rng_state():
    return {"python": random.getstate(), "numpy": np.random.get_state(),
            "torch": torch.get_rng_state(),
            "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None}


def _restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"].cpu())
    if state["cuda"] is not None and torch.cuda.is_available():
        torch.cuda.set_rng_state_all([s.cpu() for s in state["cuda"]])


def _seed_all(seed):
    random.seed(seed)
    np.random.seed(seed % (2 ** 32))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    # Fail on nondeterministic operations instead of merely warning. Exact
    # continuation is scoped to the same library versions and device family.
    torch.use_deterministic_algorithms(True)


def _tensor_record(record, device):
    z = torch.as_tensor(np.asarray(record["Z"]), device=device, dtype=torch.long)
    positions = np.asarray(record["positions"])
    if positions.ndim == 3:
        # Adapter records may contain multiple clean conformers, but the official
        # QM9M task has one. Sample one positive anchor per graph for training.
        positions = positions[random.randrange(len(positions))]
    reference = torch.as_tensor(positions, device=device, dtype=torch.float64)
    reference = reference - reference.mean(0, keepdim=True)
    radii = torch.as_tensor(np.asarray(record["radii"]), device=device, dtype=torch.float64)
    raw_bonds = record.get("bonds")
    if raw_bonds is None:
        bonds = torch.zeros((len(z), len(z)), device=device, dtype=torch.float32)
    else:
        array = np.asarray(raw_bonds)
        if array.shape == (len(z), len(z)):
            bonds = torch.as_tensor(array, device=device, dtype=torch.float32)
        elif array.ndim == 2 and array.shape[1] in (2, 3):
            bonds = torch.zeros((len(z), len(z)), device=device, dtype=torch.float32)
            for row in array:
                i, j = int(row[0]), int(row[1])
                bonds[i, j] = bonds[j, i] = float(row[2]) if len(row) == 3 else 1.0
        else:
            raise ValueError(f"Invalid bond array for {record['id']}: {array.shape}")
    if z.shape != radii.shape or reference.shape != (len(z), 3):
        raise ValueError(f"Invalid coordinate/radius shapes for {record['id']}")
    return z, reference, radii, bonds


def _inference_record(record, device):
    """Deliberately read no clean reference positions during inference."""
    if "initial_positions" not in record:
        raise ValueError(f"{record['id']} has no official initial_positions")
    minimal = {"id": record["id"], "Z": record["Z"], "radii": record["radii"],
               "positions": record["initial_positions"], "bonds": record.get("bonds")}
    return _tensor_record(minimal, device)


@torch.no_grad()
def predict_record(model, record, device, noise_scale, passes=1):
    z, initial, _, bonds = _inference_record(record, device)
    position = initial[None].float()
    for _ in range(int(passes)):
        position = model(position, z, float(noise_scale), bonds)
    if not bool(torch.isfinite(position).all()):
        raise FloatingPointError("non-finite model coordinates")
    return position[0].double()


def _pair_distance_mae(x, y):
    return float((torch.pdist(x) - torch.pdist(y)).abs().mean())


@torch.no_grad()
def evaluate_records(model, records, config, device):
    """Real MMFF-to-DFT validation. References enter metrics only after inference."""
    was_training = model.training
    model.eval()
    rows = []
    started = time.perf_counter()
    for record in records:
        row = {"id": str(record["id"]), "valid": False}
        try:
            predicted = predict_record(model, record, device,
                                       config["validation"]["inference_metric_sigma"],
                                       config["validation"].get("passes", 1))
            reference = torch.as_tensor(np.asarray(record["positions"]), device=device, dtype=torch.float64)
            initial = torch.as_tensor(np.asarray(record["initial_positions"]), device=device, dtype=torch.float64)
            if reference.ndim != 2:
                raise ValueError("Official MMFF validation requires one reference conformer per ID")
            aligned = proper_align(predicted, reference)
            row.update(valid=True, distance_mae_A=_pair_distance_mae(predicted, reference),
                       initial_distance_mae_A=_pair_distance_mae(initial, reference),
                       rmsd_A=float((aligned - reference).square().sum(-1).mean().sqrt()))
        except (ValueError, RuntimeError, FloatingPointError) as error:
            row["status"] = f"{type(error).__name__}: {error}"
        rows.append(row)
    model.train(was_training)
    good = [r for r in rows if r["valid"]]
    result = {"records": len(rows), "valid": len(good), "failed": len(rows) - len(good),
              "failure_fraction": 1 - len(good) / max(len(rows), 1),
              "distance_mae_A": float(np.mean([r["distance_mae_A"] for r in good])) if good else math.inf,
              "initial_distance_mae_A": float(np.mean([r["initial_distance_mae_A"] for r in good])) if good else math.inf,
              "rmsd_A": float(np.mean([r["rmsd_A"] for r in good])) if good else math.inf,
              "seconds": time.perf_counter() - started,
              "selection": "lexicographic (failure_fraction, all-atom unordered-pair distance MAE)",
              "input": "official initial_positions (MMFF); no clean coordinates used by prediction",
              "passes": config["validation"].get("passes", 1), "rows": rows}
    return result


def _checkpoint(path, model, optimizer, state, config, identity):
    package = {"format_version": 1, "model": model.state_dict(), "optimizer": optimizer.state_dict(),
               "state": state, "config": config, "identity": identity, "rng": _rng_state(),
               "torch_version": torch.__version__, "numpy_version": np.__version__,
               "python_version": platform.python_version()}
    temporary = Path(str(path) + ".tmp")
    torch.save(package, temporary)
    os.replace(temporary, path)


def _learning_rate(config, update):
    training = config["training"]
    warmup = training.get("warmup_updates", 0)
    if update < warmup:
        factor = (update + 1) / max(warmup, 1)
    else:
        progress = (update - warmup) / max(training["updates"] - warmup, 1)
        factor = 0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * min(progress, 1)))
    return training["learning_rate"] * factor


def _config_check(config):
    if config["objective"] not in {"intrinsic_drift", "euclidean_drift", "supervised_denoise"}:
        raise ValueError("Unknown objective")
    if config["geometry"].get("dtype") != "float64":
        raise ValueError("Intrinsic geometry must use float64")
    if config["training"]["particles"] < 2 or config["training"]["graphs_per_update"] < 1:
        raise ValueError("Need at least two particles and one graph per update")
    if not config["geometry"]["exp"].get("check", True):
        raise ValueError("Exp certificates cannot be disabled in the experiment runner")


def train(config_path, data_dir, output_dir, resume="auto", seed=None, max_updates=None, device=None):
    config = json.loads(Path(config_path).read_text()) if not isinstance(config_path, dict) else copy.deepcopy(config_path)
    if seed is not None:
        config["seed"] = int(seed)
    _config_check(config)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but this PyTorch environment has no CUDA device")
    # Required by deterministic CUDA matmul. Set before model allocation.
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    _seed_all(config["seed"])
    train_records = load_split(data_dir, "train")
    validation_records = load_split(data_dir, "val")
    if not len(train_records) or not len(validation_records):
        raise ValueError("Both train and validation splits must be nonempty")
    indices = np.random.default_rng(config["validation"]["seed"]).permutation(len(validation_records))
    limit = config["training"].get("validation_max_records", len(validation_records))
    validation_records = [validation_records[int(i)] for i in indices[:limit]]
    identity = {"config_sha256": _hash_json(config), "data_sha256": _dataset_hash(data_dir),
                "code_sha256": _code_hash(), "validation_ids_sha256": _hash_json([str(r["id"]) for r in validation_records])}
    model = build_model(config).to(device=device, dtype=torch.float32)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config["training"]["learning_rate"],
                                 weight_decay=config["training"].get("weight_decay", 0))
    last_path, best_path = output / "last.pt", output / "best.pt"
    state = {"update": 0, "graph_attempts": 0, "accepted_graphs": 0, "rejected_graphs": 0,
             "rejection_stages": {}, "draw_counts": np.zeros(len(train_records), dtype=np.int64),
             "accepted_counts": np.zeros(len(train_records), dtype=np.int64),
             "best_key": (math.inf, math.inf), "best_update": None, "elapsed_seconds": 0.0,
             "window_attempts": 0, "window_accepted": 0}
    if isinstance(resume, bool):
        resume = "auto" if resume else "never"
    if resume not in {"auto", "never", "must"}:
        raise ValueError("resume must be auto, never, or must")
    if last_path.exists() and resume == "never":
        raise FileExistsError(f"Refusing to overwrite existing run {output}; use --resume auto")
    if resume == "must" and not last_path.exists():
        raise FileNotFoundError(last_path)
    if last_path.exists():
        saved = torch.load(last_path, map_location=device, weights_only=False)
        if saved["identity"] != identity:
            changes = [k for k in identity if saved["identity"].get(k) != identity[k]]
            raise ValueError(f"Resume identity mismatch: {changes}. Use a new run directory.")
        model.load_state_dict(saved["model"])
        optimizer.load_state_dict(saved["optimizer"])
        state = saved["state"]
        _restore_rng(saved["rng"])
        _rewind_logs(output, state)
        if not best_path.exists():
            raise FileNotFoundError("best.pt missing; preserve both checkpoints when moving a run")
        print(json.dumps({"event": "resumed", "update": state["update"], "run": str(output)}), flush=True)
    else:
        _write_json(output / "config.json", config)
        _write_json(output / "identity.json", identity)
        _write_json(output / "environment.json", {"device": str(device), "device_name": torch.cuda.get_device_name(device) if device.type == "cuda" else platform.processor(),
                    "python": platform.python_version(), "torch": torch.__version__, "cuda": torch.version.cuda,
                    "train_records": len(train_records), "validation_records_used": len(validation_records),
                    "model_parameters": sum(p.numel() for p in model.parameters()),
                    "fixed_atom_correspondence": True, "geometry_dtype": "float64", "model_dtype": "float32"})
        initial_validation = evaluate_records(model, validation_records, config, device)
        state["best_key"] = (initial_validation["failure_fraction"], initial_validation["distance_mae_A"])
        state["best_update"] = 0
        _write_json(output / "validation_initial.json", initial_validation)
        _checkpoint(best_path, model, optimizer, state, config, identity)
        _checkpoint(last_path, model, optimizer, state, config, identity)
    stop = {"requested": False, "signal": None}
    previous_handlers = {}
    def signal_handler(number, _frame):
        stop.update(requested=True, signal=number)
        print(json.dumps({"event": "checkpoint_requested", "signal": number, "finish_current_update": True}), flush=True)
    for number in (signal.SIGTERM, signal.SIGUSR1, signal.SIGINT):
        previous_handlers[number] = signal.signal(number, signal_handler)
    total_updates = config["training"]["updates"]
    stopping_update = min(total_updates, max_updates) if max_updates is not None else total_updates
    start_wall = time.perf_counter()
    elapsed_before = state["elapsed_seconds"]
    training = config["training"]
    try:
        while state["update"] < stopping_update:
            update_start = time.perf_counter()
            model.train()
            optimizer.zero_grad(set_to_none=True)
            lr = _learning_rate(config, state["update"])
            for group in optimizer.param_groups:
                group["lr"] = lr
            noise = noise_parameters(config, state["update"])
            accepted_in_update, attempts_in_update = 0, 0
            losses, graph_ids = [], []
            while accepted_in_update < training["graphs_per_update"]:
                attempts_in_update += 1
                if attempts_in_update > training["max_attempts_per_update"]:
                    raise RuntimeError("Insufficient numerical acceptance to complete an update; inspect failures.jsonl. No geometry fallback was used.")
                index = random.randrange(len(train_records))
                record = train_records[index]
                state["draw_counts"][index] += 1
                state["graph_attempts"] += 1
                state["window_attempts"] += 1
                try:
                    z, reference, radii, bonds = _tensor_record(record, device)
                    corrupted, corruption_info = corrupt_reference(reference, radii, training["particles"],
                        noise["metric_sigma"], noise["max_displacement_A"], config["geometry"]["exp"],
                        config["noise"].get("corruption", "intrinsic"))
                    generated = model(corrupted.float(), z, noise["metric_sigma"], bonds)
                    loss, diagnostics = objective_loss(generated, reference, radii, config,
                        noise["metric_sigma"], max(corruption_info["displacement_rms_max_A"], 1e-6))
                    if not bool(torch.isfinite(loss)):
                        raise GeometryFailure("nonfinite_loss", {"loss": float(loss.detach())})
                    (loss / training["graphs_per_update"]).backward()
                    diagnostics["corruption"] = corruption_info
                    accepted_in_update += 1
                    state["accepted_graphs"] += 1
                    state["accepted_counts"][index] += 1
                    state["window_accepted"] += 1
                    graph_ids.append(str(record["id"]))
                    losses.append(float(loss.detach()))
                    _append_json(output / "geometry.jsonl", {"update": state["update"] + 1, "id": str(record["id"]),
                                 "graph_attempt": state["graph_attempts"], "accepted": True, "noise": noise, "diagnostics": diagnostics})
                except GeometryFailure as error:
                    state["rejected_graphs"] += 1
                    stages = state["rejection_stages"]
                    stages[error.stage] = stages.get(error.stage, 0) + 1
                    _append_json(output / "failures.jsonl", {"update": state["update"] + 1, "id": str(record["id"]),
                                 "graph_attempt": state["graph_attempts"], "stage": error.stage, "noise": noise, "diagnostics": error.diagnostics})
                    continue
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), training["grad_clip"], error_if_nonfinite=True)
            optimizer.step()
            state["update"] += 1
            state["elapsed_seconds"] = elapsed_before + time.perf_counter() - start_wall
            row = {"event": "train", "update": state["update"], "loss": float(np.mean(losses)), "lr": lr,
                   "gradient_norm": float(norm), "update_seconds": time.perf_counter() - update_start,
                   "elapsed_seconds": state["elapsed_seconds"], "noise": noise, "graph_ids": graph_ids,
                   "graph_attempts": state["graph_attempts"], "accepted_graphs": state["accepted_graphs"],
                   "rejected_graphs": state["rejected_graphs"],
                   "unique_graphs_drawn": int(np.count_nonzero(state["draw_counts"])),
                   "unique_graphs_accepted": int(np.count_nonzero(state["accepted_counts"])),
                   "graph_draw_equivalent_epochs": state["accepted_graphs"] / len(train_records)}
            _append_json(output / "train.jsonl", row)
            if state["update"] % training.get("log_every", 1) == 0:
                print(json.dumps(_jsonable(row)), flush=True)
            validate_now = state["update"] % training["validate_every"] == 0 or state["update"] == stopping_update
            if validate_now and not stop["requested"]:
                validation = evaluate_records(model, validation_records, config, device)
                key = (validation["failure_fraction"], validation["distance_mae_A"])
                _write_json(output / f"validation_{state['update']:07d}.json", validation)
                _append_json(output / "validation.jsonl", {"update": state["update"], **{k:v for k,v in validation.items() if k != "rows"}})
                if key < tuple(state["best_key"]):
                    state["best_key"], state["best_update"] = key, state["update"]
                    _checkpoint(best_path, model, optimizer, state, config, identity)
            # Check a recent window as well as cumulative figures: a noise
            # curriculum must not hide a late-stage rejection collapse.
            window = training["acceptance_gate_after_attempts"]
            if state["window_attempts"] >= window:
                acceptance = state["window_accepted"] / state["window_attempts"]
                _append_json(output / "acceptance_windows.jsonl", {"update": state["update"], "attempts": state["window_attempts"],
                             "accepted": state["window_accepted"], "fraction": acceptance, "noise": noise})
                if acceptance < training["minimum_graph_acceptance"]:
                    _checkpoint(last_path, model, optimizer, state, config, identity)
                    raise RuntimeError(f"Numerical acceptance gate failed ({acceptance:.1%}); do not launch the heavy run before solving the pilot failures.")
                state["window_attempts"], state["window_accepted"] = 0, 0
            if state["update"] % training["checkpoint_every"] == 0 or validate_now or stop["requested"]:
                state["elapsed_seconds"] = elapsed_before + time.perf_counter() - start_wall
                _checkpoint(last_path, model, optimizer, state, config, identity)
            if stop["requested"]:
                _write_json(output / "stop.json", {"signal": stop["signal"], "update": state["update"], "resume": "last.pt", "exit_code": 75})
                return 75
        state["elapsed_seconds"] = elapsed_before + time.perf_counter() - start_wall
        _checkpoint(last_path, model, optimizer, state, config, identity)
        summary = {"completed_requested_cap": state["update"] >= stopping_update,
                   "completed_full_schedule": state["update"] >= total_updates,
                   "updates": state["update"], "configured_updates": total_updates,
                   "best_update": state["best_update"], "best_validation_key": state["best_key"],
                   "graph_attempts": state["graph_attempts"], "accepted_graphs": state["accepted_graphs"],
                   "rejected_graphs": state["rejected_graphs"], "rejection_stages": state["rejection_stages"],
                   "unique_graphs_drawn": int(np.count_nonzero(state["draw_counts"])),
                   "unique_graphs_accepted": int(np.count_nonzero(state["accepted_counts"])),
                   "train_graphs": len(train_records), "elapsed_seconds": state["elapsed_seconds"],
                   "identity": identity, "device": str(device)}
        _write_json(output / "summary.json", summary)
        return 0
    except BaseException as error:
        # The last checkpoint is a committed optimizer boundary. Never overwrite
        # it with partially accumulated gradients/RNG after a crash.
        _write_json(output / "crash.json", {"type": type(error).__name__, "message": str(error),
                    "in_memory_update": state["update"], "resume_from": "last.pt",
                    "traceback": traceback.format_exc()})
        raise
    finally:
        for number, handler in previous_handlers.items():
            signal.signal(number, handler)


def save_predictions(config_path, data_dir, run_dir, output_path, split="test", passes=1,
                     checkpoint="best", device=None):
    """Save every requested ID, including explicit failure rows, to packed NPZ."""
    from .evaluate import save_predictions as save_prediction_npz
    if passes < 1:
        raise ValueError("passes must be positive")
    device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    path = Path(run_dir) / (checkpoint if str(checkpoint).endswith(".pt") else f"{checkpoint}.pt")
    saved = torch.load(path, map_location=device, weights_only=False)
    config = saved["config"]
    # Supplied config is informational; the checkpoint's exact config governs
    # architecture and conditioning, preventing accidental evaluation mismatch.
    model = build_model(config).to(device=device, dtype=torch.float32)
    model.load_state_dict(saved["model"])
    model.eval()
    records = load_split(data_dir, split)
    predictions, valid, statuses = [], [], []
    started = time.perf_counter()
    for index, record in enumerate(records):
        try:
            predicted = predict_record(model, record, device,
                                       config["validation"]["inference_metric_sigma"], passes)
            predictions.append(predicted.cpu().numpy())
            valid.append(True)
            statuses.append("ok")
        except (ValueError, RuntimeError, FloatingPointError) as error:
            predictions.append(None)
            valid.append(False)
            statuses.append(f"{type(error).__name__}: {error}")
        if (index + 1) % 100 == 0:
            print(json.dumps({"event": "predict", "processed": index + 1, "total": len(records), "failures": valid.count(False)}), flush=True)
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    metadata = {"checkpoint": str(path), "checkpoint_sha256": _hash_file(path),
                "checkpoint_update": saved["state"]["update"], "config": config,
                "training_identity": saved["identity"], "evaluation_data_sha256": _dataset_hash(data_dir),
                "split": split, "passes": passes, "neural_function_evaluations_per_molecule": passes,
                "seconds": time.perf_counter() - started, "device": str(device),
                "initial_input": "official initial_positions only; no reference coordinates during inference",
                "iterative_reuse_note": "passes>1 repeatedly applies a one-pass refiner; it is an evaluated heuristic, not a trained 16-step sampler"}
    return save_prediction_npz(records, predictions, output_path, valid=valid, status=statuses, metadata=metadata)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--data", required=True)
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--resume", choices=("auto", "never", "must"), default="auto")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--max-updates", type=int)
    parser.add_argument("--device", choices=("cuda", "cpu"))
    args = parser.parse_args(argv)
    return train(args.config, args.data, args.run_dir, args.resume, args.seed, args.max_updates, args.device)


if __name__ == "__main__":
    raise SystemExit(main())
