"""Actual numerical geodesic drifting, with explicit failed-solve accounting.

The intrinsic objective never substitutes feature chords for geodesic distance
or a projected Cartesian displacement for Log. Fixed graph atom correspondences
are assumed. Locally found numerical branches are not global-distance proofs.
"""
from __future__ import annotations

import math
from collections import Counter
import torch

from .geometry import (exp_map, log_map, horizontal_basis, metric_covector,
                       metric_norm, proper_align)


class GeometryFailure(RuntimeError):
    def __init__(self, stage, diagnostics):
        super().__init__(f"{stage}: numerical geometry rejected this graph batch")
        self.stage, self.diagnostics = stage, diagnostics


def _reasons(result):
    reason = result.get("reason", [])
    if isinstance(reason, str):
        reason = [reason]
    return dict(Counter(str(x) for x in reason))


def _finite_max(x):
    if not torch.is_tensor(x):
        return None
    x = x.detach().flatten()
    x = x[torch.isfinite(x)]
    return float(x.max()) if x.numel() else None


def _diagnostic_values(value):
    """Small tensors as JSON-safe values, with undefined diagnostics as null."""
    if torch.is_tensor(value):
        return _diagnostic_values(value.detach().cpu().tolist())
    if isinstance(value, list):
        return [_diagnostic_values(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def log_with_retries(x, y, radii, options):
    """Refine integration grid for failed rows; preserve all acceptance tests."""
    opts = dict(options)
    maximum = int(opts.pop("max_n_steps", opts.get("n_steps", 8)))
    initial = int(opts.get("n_steps", 8))
    attempts = Counter()
    results = log_map(x, y, radii, **opts)
    attempts[str(initial)] += int(x.shape[0])
    steps = initial
    while not bool(results["valid"].all()) and steps < maximum:
        index = (~results["valid"]).nonzero(as_tuple=False).flatten()
        steps = min(2 * steps, maximum)
        retry = log_map(x[index], y[index], radii, **dict(opts, n_steps=steps))
        attempts[str(steps)] += len(index)
        for key, value in retry.items():
            if key not in results:
                continue
            if torch.is_tensor(value) and value.ndim and value.shape[0] == len(index):
                results[key][index] = value
            elif key == "reason" and isinstance(results[key], list):
                for i, reason in zip(index.tolist(), value):
                    results[key][i] = reason
    results["grid_attempts"] = dict(attempts)
    return results


def _summary(result, requested):
    """Bound successful pair diagnostics; retain at most four failed spectra."""
    diagnostics = {"requested": int(requested), "accepted": int(result["valid"].sum()),
            "reason_counts": _reasons(result),
            "endpoint_rmsd_max_A": _finite_max(result.get("endpoint_rmsd")),
            "speed_error_max": _finite_max(result.get("speed_error")),
            "grid_error_max": _finite_max(result.get("grid_error")),
            "grid_attempts": result.get("grid_attempts", {})}
    condition = result.get("base_condition_number")
    if torch.is_tensor(condition) and condition.numel():
        diagnostics["base_condition_number_max"] = _diagnostic_values(condition.max())
        diagnostics["base_condition_number_nonfinite_count"] = int((~torch.isfinite(condition)).sum())
    rank = result.get("base_rank")
    if torch.is_tensor(rank) and rank.numel():
        diagnostics["base_rank_min"] = int(rank.min())
        diagnostics["base_rank_max"] = int(rank.max())
    for key in ("coarse_integration_valid", "fine_integration_valid"):
        if key in result:
            diagnostics[key.replace("valid", "invalid_count")] = int((~result[key]).sum())
    if "grid_error" in result:
        diagnostics["grid_error_defined_count"] = int(torch.isfinite(result["grid_error"]).sum())
    failed = (~result["valid"]).reshape(-1).nonzero(as_tuple=False).flatten()
    if failed.numel():
        details = []
        for index in failed[:4].tolist():
            row = {"row": index}
            for key in ("base_singular_values", "base_condition_number", "base_rank",
                        "coarse_integration_valid", "fine_integration_valid"):
                if key in result:
                    row[key] = _diagnostic_values(result[key][index])
            reason = result.get("reason", [])
            if isinstance(reason, list) and index < len(reason):
                row["reason"] = reason[index]
            details.append(row)
        diagnostics["failed_row_details"] = details
        diagnostics["failed_rows_omitted"] = int(failed.numel()) - len(details)
    return diagnostics


def noise_parameters(config, update):
    """Piecewise linear curriculum by successful optimizer-update fraction."""
    schedule = sorted(config["noise"]["schedule"], key=lambda x: x["fraction"])
    fraction = min(max(update / max(config["training"]["updates"] - 1, 1), 0), 1)
    left, right = schedule[0], schedule[-1]
    for a, b in zip(schedule, schedule[1:]):
        if a["fraction"] <= fraction <= b["fraction"]:
            left, right = a, b
            break
    width = right["fraction"] - left["fraction"]
    weight = min(max((fraction - left["fraction"]) / width, 0), 1) if width else 0
    return {key: float((1 - weight) * left[key] + weight * right[key])
            for key in ("metric_sigma", "max_displacement_A")}


@torch.no_grad()
def corrupt_reference(reference, radii, particles, metric_sigma, max_displacement_A,
                      exp_options, mode="intrinsic", generator=None):
    """Metric Gaussian tangent noise, clipped then numerically exponentiated.

    The clipping and validity filter change its distribution: this is explicitly
    bounded tangent-Gaussian corruption, not an untruncated wrapped normal.
    Failed Exp rows reject the whole graph batch; noise is never silently shrunk.
    """
    anchor = reference[None].expand(particles, -1, -1).clone().double()
    basis_result = horizontal_basis(anchor, radii)
    noise_diagnostics = {
        # All particles share this anchor: do not serialize its spectrum B times.
        "reference_basis_condition_number": _diagnostic_values(basis_result["condition_number"][0]),
        "reference_basis_rank": int(basis_result["rank"][0]),
        "metric_sigma": float(metric_sigma),
    }
    if not bool(basis_result["valid"].all()):
        noise_diagnostics["reference_basis_singular_values"] = _diagnostic_values(basis_result["singular_values"][0])
        raise GeometryFailure("noise_basis", dict(_summary(basis_result, particles), **noise_diagnostics))
    basis = basis_result["basis"]
    gaussian = torch.randn((particles, basis.shape[-1]), device=reference.device,
                           dtype=torch.float64, generator=generator)
    gaussian *= float(metric_sigma) / math.sqrt(basis.shape[-1])
    tangent = (basis @ gaussian[..., None]).squeeze(-1).reshape_as(anchor)
    rms = tangent.square().sum(-1).mean(-1).sqrt().clamp_min(1e-20)
    clip = (float(max_displacement_A) / rms).clamp(max=1)
    tangent *= clip[:, None, None]
    # Collect the actual bounded distribution before Exp can fail. In a poorly
    # conditioned chart the unbounded tangent can be far larger than its cap.
    noise_diagnostics.update(
        clipped_particles=int((clip < 1).sum()),
        uncapped_tangent_rms_A=_diagnostic_values(rms),
        clip_factors=_diagnostic_values(clip),
        capped_tangent_rms_A=_diagnostic_values(rms * clip),
        tangent_rms_max_A=float((rms * clip).max()),
        actual_tangent_metric_norm=_diagnostic_values(metric_norm(anchor, tangent, radii)),
    )
    if mode == "intrinsic":
        result = exp_map(anchor, tangent, radii, **exp_options)
        diagnostics = _summary(result, particles)
        diagnostics.update(noise_diagnostics)
        if not bool(result["valid"].all()):
            diagnostics["reference_basis_singular_values"] = _diagnostic_values(basis_result["singular_values"][0])
            raise GeometryFailure("noise_exp", diagnostics)
        point = result["point"]
    elif mode == "cartesian":
        # Matched tangent/cap; the only difference is the corruption retraction.
        point = anchor + tangent
        diagnostics = {"requested": particles, "accepted": particles}
        diagnostics.update(noise_diagnostics)
    else:
        raise ValueError(f"Unknown corruption mode {mode}")
    point -= point.mean(-2, keepdim=True)
    diagnostics.update(displacement_rms_max_A=float((point - anchor).square().sum(-1).mean(-1).sqrt().max()))
    return point, diagnostics


@torch.no_grad()
def intrinsic_drift_target(generated, positive, radii, config, metric_sigma):
    """Kernel attraction minus self-excluded repulsion, all in T_x M.

    Local refinement uses one clean positive anchor per molecular graph, and B
    independently corrupted/refined negative particles. This is graph-conditional
    refinement, not unconditional topology or conformer-ensemble generation.
    """
    x = generated.detach().double()
    b, n, _ = x.shape
    if b < 2:
        raise ValueError("Drifting requires at least two generated particles")
    y = positive.reshape(1, n, 3).expand(b, -1, -1)
    attraction = log_with_retries(x, y, radii, config["geometry"]["log"])
    rows, columns = (~torch.eye(b, device=x.device, dtype=torch.bool)).nonzero(as_tuple=True)
    repulsion = log_with_retries(x[rows], x[columns], radii, config["geometry"]["log"])
    diagnostics = {"positive": _summary(attraction, b),
                   "negative": _summary(repulsion, b * (b - 1))}
    if not bool(attraction["valid"].all()) or not bool(repulsion["valid"].all()):
        raise GeometryFailure("drift_log", diagnostics)
    # All negative vectors sharing a row are based at exactly the same x_i.
    negative_logs = repulsion["log"].reshape(b, b - 1, n, 3)
    negative_dist = repulsion["distance"].reshape(b, b - 1)
    field = torch.zeros_like(x)
    multipliers = config["drift"]["temperature_multipliers"]
    for multiplier in multipliers:
        temperature = max(float(multiplier) * float(metric_sigma), 1e-8)
        weights = torch.softmax(-negative_dist / temperature, dim=1)
        field += attraction["log"] - (weights[..., None, None] * negative_logs).sum(1)
    field /= len(multipliers)
    tangent = float(config["drift"]["step_size"]) * field
    norm = metric_norm(x, tangent, radii)
    max_norm = float(config["drift"]["max_metric_step_multiplier"]) * metric_sigma
    tangent *= (max_norm / norm.clamp_min(1e-20)).clamp(max=1)[:, None, None]
    target = exp_map(x, tangent, radii, **config["geometry"]["exp"])
    diagnostics["target_exp"] = _summary(target, b)
    if not bool(target["valid"].all()):
        raise GeometryFailure("target_exp", diagnostics)
    diagnostics.update(field_metric_mean=float(metric_norm(x, field, radii).mean()),
                       target_move_metric_mean=float(metric_norm(x, tangent, radii).mean()))
    return target["point"].detach(), diagnostics


class _SquaredGeodesicLoss(torch.autograd.Function):
    @staticmethod
    def forward(ctx, generated, target, radii, options, diagnostic_holder):
        # Targets are stopped. The nonlinear shooting solve is evaluated here;
        # differentiating its optimization iterations is neither needed nor used.
        with torch.no_grad():
            x = generated.detach().double()
            result = log_with_retries(x, target.detach().double(), radii, options)
            diagnostic_holder.update(_summary(result, x.shape[0]))
            if not bool(result["valid"].all()):
                raise GeometryFailure("loss_log", diagnostic_holder)
            gradient = -2 * metric_covector(x, result["log"], radii) / x.shape[0]
            ctx.save_for_backward(gradient.to(generated.dtype))
            return result["distance"].square().mean().to(generated.dtype)

    @staticmethod
    def backward(ctx, scale):
        (gradient,) = ctx.saved_tensors
        return scale * gradient, None, None, None, None


def squared_geodesic_loss(generated, target, radii, options):
    diagnostics = {}
    value = _SquaredGeodesicLoss.apply(generated, target.detach(), radii, options, diagnostics)
    return value, diagnostics


@torch.no_grad()
def euclidean_drift_target(generated, positive, config, coordinate_sigma):
    """All-atom Cartesian quotient drift control; SO(3) aligned chord distances."""
    x = generated.detach()
    b, n, _ = x.shape
    y = proper_align(positive[None].expand(b, -1, -1), x)
    positive_delta = y - x
    rows, columns = (~torch.eye(b, device=x.device, dtype=torch.bool)).nonzero(as_tuple=True)
    paired = proper_align(x[columns], x[rows])
    negative_delta = (paired - x[rows]).reshape(b, b - 1, n, 3)
    d = negative_delta.square().sum((-1, -2)).sqrt() / math.sqrt(n)
    field = torch.zeros_like(x)
    for multiplier in config["drift"]["temperature_multipliers"]:
        weights = torch.softmax(-d / max(multiplier * coordinate_sigma, 1e-8), 1)
        field += positive_delta - (weights[..., None, None] * negative_delta).sum(1)
    field /= len(config["drift"]["temperature_multipliers"])
    tangent = config["drift"]["step_size"] * field
    return (x + tangent).detach(), {"target_rms_move_A": float(tangent.square().sum(-1).mean(-1).sqrt().mean())}


def objective_loss(generated, reference, radii, config, metric_sigma, coordinate_sigma):
    method = config["objective"]
    if method == "intrinsic_drift":
        target, drift_diagnostics = intrinsic_drift_target(generated, reference, radii, config, metric_sigma)
        loss, loss_diagnostics = squared_geodesic_loss(generated, target, radii, config["geometry"]["log"])
        return loss, {"drift": drift_diagnostics, "loss": loss_diagnostics}
    if method == "euclidean_drift":
        target, diagnostics = euclidean_drift_target(generated, reference, config, coordinate_sigma)
    elif method == "supervised_denoise":
        with torch.no_grad():
            target = proper_align(reference[None].expand_as(generated), generated.detach())
        diagnostics = {}
    else:
        raise ValueError(f"Unknown objective {method}")
    return (generated - target).square().sum(-1).mean(), diagnostics
