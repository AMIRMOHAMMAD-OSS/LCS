"""Fetch the authors' release and preserve its processed splits and atom ordering."""
import argparse,hashlib,json,os,shutil,tarfile,urllib.request
from pathlib import Path
import numpy as np
from .data import RADII,ENCODED_Z,save_records,file_sha256

SOURCE={
 'record':'https://zenodo.org/records/15561806',
 'url':'https://zenodo.org/api/records/15561806/files/rdsm_zenodo.tar.gz/content',
 'filename':'rdsm_zenodo.tar.gz','size':2348212124,
 'md5':'55aee4295ad770ae64bd629f8b2080db'}

def digest(path,algorithm='md5'):
    h=hashlib.new(algorithm)
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()

def download(root):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    dest=root/SOURCE['filename'];part=dest.with_suffix(dest.suffix+'.part')
    if dest.exists():
        if dest.stat().st_size==SOURCE['size'] and digest(dest)==SOURCE['md5']:return dest
        raise ValueError(f'Existing archive checksum mismatch: {dest}; move it aside before retrying')
    # Range requests resume an interrupted transfer only when the server confirms 206.
    offset=part.stat().st_size if part.exists() else 0
    request=urllib.request.Request(SOURCE['url'],headers={'Range':f'bytes={offset}-'} if offset else {})
    with urllib.request.urlopen(request,timeout=180) as src:
        if offset and src.status!=206:offset=0
        with part.open('ab' if offset else 'wb') as out:
            total=offset;last=total
            while block:=src.read(4*1024*1024):
                out.write(block);total+=len(block)
                if total-last>=64*1024*1024:print(f'downloaded {total}/{SOURCE["size"]} bytes',flush=True);last=total
    if part.stat().st_size!=SOURCE['size'] or digest(part)!=SOURCE['md5']:
        raise ValueError(f'Archive failed published size/MD5 check: {part}')
    part.replace(dest);return dest

def extract(archive,root):
    archive=Path(archive);root=Path(root);root.mkdir(parents=True,exist_ok=True)
    if archive.stat().st_size!=SOURCE['size'] or digest(archive)!=SOURCE['md5']:
        raise ValueError('Only the verified authors release may be extracted with this command')
    selected=[];inventory=[]
    # Some release versions wrap processed directories in nested tar archives.
    # Keep the original split/weights/processed pairs, never unpack noise XYZ trees.
    def walk(tar,prefix=Path(),depth=0):
        if depth>4:raise ValueError('Unexpected archive nesting depth')
        for item in tar:
            part=Path(item.name)
            if part.is_absolute() or '..' in part.parts:raise ValueError('Unsafe archive path')
            if not item.isfile():continue
            path=prefix/part;lower=str(path).lower()
            if 'geom' in lower or 'qm7' in lower:continue
            packed=lower.endswith(('.tar','.tar.gz','.tgz','.tar.bz2'))
            if packed:
                inventory.append({'path':str(path),'bytes':item.size})
                if path.name=='qm9_mmff.tar.bz2':
                    dest=root/path;dest.parent.mkdir(parents=True,exist_ok=True)
                    with tar.extractfile(item) as src,dest.open('wb') as out:shutil.copyfileobj(src,out,8*1024*1024)
                    selected.append({'path':str(dest.relative_to(root)),'bytes':item.size,'sha256':file_sha256(dest)})
                    continue
                # Raw MMFF/DFT xyz and noise archives cannot contain PyG caches.
                if any(s in lower for s in ('mmfftodft_input.tar','qm9_mmff.tar','riemannian','xyz')):continue
                with tarfile.open(fileobj=tar.extractfile(item),mode='r|*') as nested:
                    walk(nested,path.parent/(path.name+'.contents'),depth+1)
                continue
            is_pair=('qm9' in lower and 'mmff' in lower and path.name in ('train_proc.pt','valid_proc.pt','test_proc.pt'))
            is_aux=('qm9' in lower and path.name in ('wrong_samples.pkl','data_split.pkl'))
            is_weight=path.name in ('edsm.qm9.ckpt','rdsm.qm9.pretrained.ckpt','rdsm.qm9.finetuned.ckpt')
            if not (is_pair or is_aux or is_weight):continue
            dest=root/path;dest.parent.mkdir(parents=True,exist_ok=True)
            with tar.extractfile(item) as src,dest.open('wb') as out:shutil.copyfileobj(src,out,8*1024*1024)
            selected.append({'path':str(dest.relative_to(root)),'bytes':item.size,'sha256':file_sha256(dest)})
            print('extracted',path,item.size,flush=True)
    with tarfile.open(archive,'r|gz') as tar:walk(tar)
    (root/'verified_release.json').write_text(json.dumps({'source':SOURCE,'archive_sha256':file_sha256(archive),'files':selected,'nested_archives':inventory},indent=2))
    return selected

def _plain(x):
    if hasattr(x,'detach'):return x.detach().cpu().numpy()
    return np.asarray(x)

def iter_processed(path):
    import torch
    from torch_geometric.data import Data
    from torch_geometric.data.separate import separate
    value=torch.load(path,map_location='cpu',weights_only=False)
    if not (isinstance(value,tuple) and len(value)>=2):raise ValueError(f'Expected official PyG (data,slices): {path}')
    data,slices=value[:2]
    if isinstance(data,dict):data=Data.from_dict(data)
    length=len(next(iter(slices.values())))-1
    for i in range(length):
        yield separate(data.__class__,data,i,slices,decrement=False)

def convert_record(d):
    from rdkit import Chem
    pos=_plain(d.pos)
    if pos.ndim!=3 or pos.shape[1]!=2 or pos.shape[-1]!=3:
        raise ValueError(f'Expected QM9M DFT/MMFF pair pos[N,2,3], got {pos.shape}; not a noise dataset')
    x=_plain(d.x).reshape(-1).astype(int)
    if x.min()<0 or x.max()>=len(ENCODED_Z):raise ValueError('Unexpected official atom encoding')
    z=ENCODED_Z[x];n=len(z)
    if pos.shape[0]!=n or not np.isfinite(pos).all():raise ValueError('Invalid coordinate/atom array')
    idx=str(int(_plain(d.idx).reshape(-1)[0]));smarts=d.smarts
    if isinstance(smarts,(list,tuple)):smarts=smarts[0]
    mol=Chem.MolFromSmarts(str(smarts))
    if mol is None:raise ValueError(f'Cannot parse mapped SMARTS: {idx}')
    maps=np.array([a.GetAtomMapNum() for a in mol.GetAtoms()])
    if sorted(maps.tolist())!=list(range(1,n+1)):raise ValueError(f'Invalid atom maps {idx}')
    mz=np.array([a.GetAtomicNum() for a in mol.GetAtoms()])[np.argsort(maps)]
    if not np.array_equal(z,mz):raise ValueError(f'Encoded elements disagree with mapped SMARTS {idx}')
    bonds=np.zeros((n,n),np.int8)
    edges=_plain(d.edge_index).astype(int);types=_plain(d.edge_feat).astype(int).reshape(-1)
    if edges.size:
        if edges.min()<0 or edges.max()>=n:raise ValueError('Nonlocal edge indices in processed record')
        bonds[edges[0],edges[1]]=types;bonds[edges[1],edges[0]]=types
    # Recompute the authors' published exclusion rules, retaining all rows in storage.
    reason=[]
    if np.sqrt(np.mean(np.sum((pos[:,0]-pos[:,1])**2,axis=-1)))<1e-9:reason.append('MMFF_equals_DFT')
    if '.' in str(smarts):reason.append('disconnected_graph')
    return dict(id=idx,Z=z,positions=pos[:,0].astype(np.float64),initial_positions=pos[:,1].astype(np.float64),
                radii=np.array([RADII[int(v)] for v in z]),bonds=bonds,smarts=str(smarts),
                paper_eligible=not reason,exclusion_reason=';'.join(reason))

def _verify_input(path, root, release, trust_local_pt, verified_files):
    """Verify selected bytes against the checked extraction inventory before unpickling."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    fingerprint = file_sha256(path)
    relative = str(path.resolve().relative_to(root.resolve())) if path.resolve().is_relative_to(root.resolve()) else None
    entry = next((row for row in release.get('files', []) if row.get('path') == relative), None)
    checked = bool(entry and entry.get('sha256') == fingerprint)
    if not checked and not trust_local_pt:
        raise ValueError(f'Input not verified by release extraction inventory, or bytes changed: {path}')
    verified_files.append({'path': str(path.resolve()), 'relative_path': relative,
                           'sha256': fingerprint, 'verified': checked})
    return fingerprint


def prepare(root, output, processed_dir=None, trust_local_pt=False,
            allow_rebuild_rejections=False, rebuild_policy='strict', force_rebuild=False):
    from .rebuild_raw import REBUILD_POLICIES, atomic_json, rebuild_processed, validate_rebuild_cache
    import pickle
    import tempfile
    if allow_rebuild_rejections:
        raise ValueError('--allow-rebuild-rejections is no longer supported; use explicit --rebuild-policy official_v0_0_2 for classified feature failures only')
    if rebuild_policy not in REBUILD_POLICIES:
        raise ValueError(f'Unknown rebuild policy: {rebuild_policy}')
    root, output = Path(root), Path(output)
    verified = root / 'verified_release.json'
    if not verified.exists() and not trust_local_pt:
        raise ValueError('Run download/extract first, or explicitly use --trust-local-pt for your own inspected PyG files')
    release = json.loads(verified.read_text()) if verified.exists() else {}
    verified_files = []
    wrong_paths = [p for p in root.rglob('wrong_samples.pkl') if 'qm9' in str(p).lower()]
    split_paths = [p for p in root.rglob('data_split.pkl') if 'qm9' in str(p).lower()]
    if len(wrong_paths) > 1 or len(split_paths) > 1:
        raise ValueError('Ambiguous official split/exclusion files')
    for path in wrong_paths + split_paths:
        _verify_input(path, root, release, trust_local_pt, verified_files)
    wrong_ids = None
    if wrong_paths:
        with wrong_paths[0].open('rb') as stream:
            wrong_ids = {str(int(v)) for v in pickle.load(stream)}
    declared_splits = None
    split_keys = {'train': 'train_index', 'validation': 'valid_index', 'test': 'test_index'}
    if split_paths:
        with split_paths[0].open('rb') as stream:
            declared_splits = pickle.load(stream)
        all_ids = [int(v) for key in split_keys.values() for v in declared_splits[key]]
        if len(all_ids) != len(set(all_ids)) or any(v < 0 for v in all_ids):
            raise ValueError('Duplicate, overlapping or negative IDs in declared splits')
    rebuilt_dir = root / 'rebuilt_qm9m_MMFFtoDFT' / 'processed'
    rebuild_audit = None
    if processed_dir:
        processed = Path(processed_dir)
    else:
        # A reconstructed directory is never accepted merely because test_proc.pt exists.
        candidates = [p.parent for p in root.rglob('test_proc.pt')
                      if 'qm9' in str(p).lower() and 'mmff' in str(p).lower()
                      and p.parent != rebuilt_dir and not (p.parent / 'rebuild_audit.json').exists()
                      and not any(part.startswith('.rebuild-stage-') for part in p.parts)]
        if len(candidates) > 1:
            raise ValueError(f'Ambiguous authors processed directories: {candidates}; supply --processed-dir')
        processed = candidates[0] if candidates else rebuilt_dir
    if processed == rebuilt_dir or (processed / 'rebuild_audit.json').exists():
        raw = list(root.rglob('qm9_mmff.tar.bz2'))
        if len(raw) != 1 or len(split_paths) != 1:
            raise ValueError('Raw reconstruction needs exactly one verified qm9_mmff.tar.bz2 and data_split.pkl')
        _verify_input(raw[0], root, release, trust_local_pt, verified_files)
        processed, rebuild_audit = rebuild_processed(raw[0], split_paths[0], processed,
            rebuild_policy=rebuild_policy, force_rebuild=force_rebuild)
    else:
        if force_rebuild:
            raise ValueError('--force-rebuild is only valid for an audited reconstructed cache; authors original files will not be overwritten')
        for filename in ('train_proc.pt', 'valid_proc.pt', 'test_proc.pt'):
            _verify_input(processed / filename, root, release, trust_local_pt, verified_files)
    output.mkdir(parents=True, exist_ok=True)
    manifest = {
        'schema': 2, 'status': 'in_progress', 'task': 'QM9M indexed MMFF-to-DFT refinement',
        'coordinates': 'Angstrom', 'source': SOURCE,
        'split_policy': 'Preserve declared split membership and relative row order; no resplitting or ID shift',
        'test_exclusions': 'Rows retained; test eligibility uses official wrong_samples.pkl when present, otherwise explicitly reconstructed rules.',
        'radii_A': RADII, 'splits': {}, 'trust_local_pt': bool(trust_local_pt),
        'source_verified': bool(verified_files) and all(row['verified'] for row in verified_files),
        'verified_source_files': verified_files,
        'processed_origin': 'raw_rebuild' if rebuild_audit else ('local_processed_cache' if trust_local_pt else 'authors_processed_cache'),
        'rebuild_policy': rebuild_policy,
        'official_exclusion_file': None if not wrong_paths else {'path': str(wrong_paths[0].resolve()), 'sha256': file_sha256(wrong_paths[0]), 'ids': sorted(wrong_ids, key=int)},
        'official_split_file': None if not split_paths else {'path': str(split_paths[0].resolve()), 'sha256': file_sha256(split_paths[0])},
    }
    if release:
        manifest['release'] = release
    if rebuild_audit:
        manifest['raw_rebuild'] = rebuild_audit
    # Invalidate any previous completion marker before touching portable files.
    # Existing files stay available for inspection; consumers must require complete.
    atomic_json(output / 'manifest.json', manifest)
    ids = {}
    try:
        with tempfile.TemporaryDirectory(prefix='.prepare-stage-', dir=output) as staging:
            for split, name in [('train', 'train_proc.pt'), ('validation', 'valid_proc.pt'), ('test', 'test_proc.pt')]:
                src = processed / name
                records = []
                for i, d in enumerate(iter_processed(src)):
                    records.append(convert_record(d))
                    if (i + 1) % 10000 == 0:
                        print(f'{split}: converted {i + 1}', flush=True)
                if split == 'test' and wrong_ids is not None:
                    reconstructed = {r['id'] for r in records if not r['paper_eligible']}
                    present = {r['id'] for r in records}
                    manifest['exclusion_rule_disagreements'] = sorted(reconstructed.symmetric_difference(wrong_ids & present), key=int)
                    for r in records:
                        r['paper_eligible'] = r['id'] not in wrong_ids
                        if not r['paper_eligible'] and not r['exclusion_reason']:
                            r['exclusion_reason'] = 'official_wrong_samples'
                ordered_ids = [r['id'] for r in records]
                ids[split] = set(ordered_ids)
                if len(ids[split]) != len(records):
                    raise ValueError(f'Duplicate IDs in {split}')
                declared = ([str(int(v)) for v in declared_splits[split_keys[split]]]
                            if declared_splits is not None else ordered_ids)
                unexpected = ids[split] - set(declared)
                if unexpected:
                    raise ValueError(f'Processed {split} contains IDs outside released split: {sorted(unexpected)}')
                rejected = [str(v) for v in rebuild_audit['rejected_ids_by_split'][split]] if rebuild_audit else []
                allowed_missing = [str(v) for v in rebuild_audit['allowed_missing_ids_by_split'][split]] if rebuild_audit else []
                if rebuild_audit:
                    expected = [v for v in declared if v not in set(rejected + allowed_missing)]
                    if ordered_ids != expected:
                        raise ValueError(f'Reconstructed {split} IDs/order disagree with declared IDs and audited exclusions')
                checksum = save_records(records, Path(staging) / f'{split}.npz')
                manifest['splits'][split] = {
                    'count': len(records), 'paper_eligible': sum(r['paper_eligible'] for r in records),
                    'npz_sha256': checksum, 'processed_file': str(src.relative_to(root)) if src.is_relative_to(root) else str(src),
                    'processed_sha256': file_sha256(src), 'declared_count': len(declared),
                    'declared_ids': declared, 'retained_ids': ordered_ids,
                    'rejected_ids': rejected, 'allowed_missing_ids': allowed_missing,
                    'declared_ids_missing_from_processed': [v for v in declared if v not in ids[split]],
                    'ids_order_sha256': hashlib.sha256(json.dumps(ordered_ids, separators=(',', ':')).encode()).hexdigest(),
                }
                print(f'{split}: count={len(records)}, eligible={manifest["splits"][split]["paper_eligible"]}, rejected={len(rejected)}, allowed_missing={len(allowed_missing)}', flush=True)
            for a, b in [('train', 'validation'), ('train', 'test'), ('validation', 'test')]:
                if ids[a] & ids[b]:
                    raise ValueError(f'Split ID overlap {a}/{b}')
            for split in ('train', 'validation', 'test'):
                os.replace(Path(staging) / f'{split}.npz', output / f'{split}.npz')
        manifest['status'] = 'complete'
        atomic_json(output / 'manifest.json', manifest)
    except Exception as exc:
        manifest['status'] = 'failed'
        manifest['failure'] = {'error_type': type(exc).__name__, 'error': str(exc)}
        atomic_json(output / 'manifest.json', manifest)
        raise
    return manifest


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    d = sub.add_parser('download'); d.add_argument('--root', required=True)
    e = sub.add_parser('extract'); e.add_argument('--archive', required=True); e.add_argument('--root', required=True)
    c = sub.add_parser('prepare')
    c.add_argument('--root', required=True); c.add_argument('--output', required=True)
    c.add_argument('--processed-dir'); c.add_argument('--trust-local-pt', action='store_true')
    c.add_argument('--rebuild-policy', choices=('strict', 'official_v0_0_2'), default='strict',
                   help='Explicit official_v0_0_2 permits only classified unsupported graph feature values')
    c.add_argument('--force-rebuild', action='store_true', help='Rebuild stale/failed audited caches; never overwrite original unmarked caches')
    c.add_argument('--allow-rebuild-rejections', action='store_true', help=argparse.SUPPRESS)
    a = p.parse_args(argv)
    if a.command == 'download':
        print(download(a.root))
    elif a.command == 'extract':
        print(json.dumps(extract(a.archive, a.root), indent=2))
    else:
        result = prepare(a.root, a.output, a.processed_dir, a.trust_local_pt,
                         a.allow_rebuild_rejections, a.rebuild_policy, a.force_rebuild)
        print(json.dumps({'status': result['status'], 'manifest': str(Path(a.output) / 'manifest.json'),
                          'counts': {k: v['count'] for k, v in result['splits'].items()}}, indent=2))


if __name__ == '__main__':
    main()
