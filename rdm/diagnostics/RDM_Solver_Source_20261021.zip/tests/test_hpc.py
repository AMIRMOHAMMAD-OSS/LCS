"""Check resource isolation and dry submission without contacting Slurm."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
def module(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/'scripts'/f'{name}.py')
    obj=importlib.util.module_from_spec(spec); spec.loader.exec_module(obj); return obj


class HPCSubmissionTest(unittest.TestCase):
    def test_train_dry_run_has_one_gpu_per_distinct_seed(self):
        submit=module('submit_jeanzay'); runner=module('run_job')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); config=root/'train.json'; config.write_text('{"steps":100}')
            env=root/'site.env'; env.write_text('RDM_TORCH_MODULE=example\n')
            data=root/'data'; data.mkdir()
            with patch.object(submit,'ROOT',root),patch.object(submit.subprocess,'run') as called,contextlib.redirect_stdout(io.StringIO()):
                code=submit.main(['train','--account','example@a100','--qos','explicit_qos',
                    '--env-file',str(env),'--config',str(config),'--data',str(data),
                    '--output',str(root/'runs'),'--seeds','17,29,43'])
            self.assertEqual(code,0); called.assert_not_called()
            path=next((root/'submissions').glob('*/payload.json')); payload=json.loads(path.read_text())
            self.assertEqual(payload['task_count'],3)
            script=(path.parent/'command.txt').read_text()
            self.assertIn('--gres=gpu:1',script); self.assertIn('--array=0-2%3',script)
            self.assertIn('--signal=USR1@600',script)
            self.assertNotIn('--mem',script)
            self.assertIsNone(payload['preflight_report'])
            cmd,out=runner.command(payload,1)
            self.assertEqual(out.name,'seed_29')
            self.assertEqual(cmd[cmd.index('--seed')+1],'29')
            self.assertEqual(cmd[cmd.index('--resume')+1],'auto')
            config.write_text('{"steps":999}')
            self.assertEqual(json.loads(Path(payload['config']).read_text())['steps'],100)

    def test_quantum_shards_are_cpu_only(self):
        submit=module('submit_jeanzay'); runner=module('run_job')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); jobs=root/'jobs.jsonl'; jobs.write_text('{}\n{}\n{}\n')
            env=root/'site.env'; env.write_text('RDM_CPU_TORCH_MODULE=example\n')
            with patch.object(submit,'ROOT',root),patch.object(submit.subprocess,'run') as called,contextlib.redirect_stdout(io.StringIO()):
                code=submit.main(['quantum','--account','example@cpu','--qos','cpu_qos',
                    '--env-file',str(env),'--jobs',str(jobs),'--tasks','2','--output',str(root/'results')])
            self.assertEqual(code,0); called.assert_not_called()
            path=next((root/'submissions').glob('*/payload.json')); payload=json.loads(path.read_text())
            script=(path.parent/'command.txt').read_text()
            self.assertNotIn('--gres=',script); self.assertNotIn('--signal=',script)
            self.assertNotIn('--mem',script)
            cmd,_=runner.command(payload,1)
            self.assertEqual(cmd[cmd.index('--task-count')+1],'2')
            self.assertEqual(cmd[cmd.index('--task-index')+1],'1')

    def test_wrong_account_fails_before_submission(self):
        submit=module('submit_jeanzay')
        with patch.object(submit.subprocess,'run') as called,contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                submit.main(['train','--account','example@cpu','--qos','q','--output','unused'])
        called.assert_not_called()

    def test_official_baseline_uses_separate_environment_and_one_gpu(self):
        submit=module('submit_jeanzay'); runner=module('run_job')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'hpc').mkdir()
            env=root/'hpc/official.env'; env.write_text('RDM_VENV=/separate/baseline/env\n')
            source=root/'official_source'; source.mkdir()
            data=root/'data'; data.mkdir()
            ckpt=root/'model.ckpt'; ckpt.write_bytes(b'fixture')
            released=root/'test.pt'; released.write_bytes(b'fixture')
            with patch.object(submit,'ROOT',root),patch.object(submit.subprocess,'run') as called,contextlib.redirect_stdout(io.StringIO()):
                code=submit.main(['official','--account','example@a100','--qos','q',
                    '--official-source',str(source),'--released-pt',str(released),
                    '--checkpoint',str(ckpt),'--data',str(data),'--official-model','edm',
                    '--nfe','256','--batch-size','32','--output',str(root/'official.npz')])
            self.assertEqual(code,0); called.assert_not_called()
            path=next((root/'submissions').glob('*/payload.json')); payload=json.loads(path.read_text())
            self.assertEqual(payload['env_file'],str(env)); self.assertEqual(payload['task_count'],1)
            script=(path.parent/'command.txt').read_text()
            self.assertIn('--gres=gpu:1',script); self.assertNotIn('--array=',script)
            cmd,_=runner.command(payload,0)
            self.assertIn('rdm_drift.official',cmd); self.assertIn('--resume',cmd)
            self.assertEqual(cmd[cmd.index('--model')+1],'edm')
            self.assertEqual(cmd[cmd.index('--nfe')+1],'256')
            self.assertEqual(cmd[cmd.index('--batch-size')+1],'32')


if __name__=='__main__': unittest.main()
