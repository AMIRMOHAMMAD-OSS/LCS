"""Synthetic fixtures test smoke plumbing only; they are not QM9M evidence."""
import copy
import json
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pytest
import torch

from rdm_drift.data import save_records
from rdm_drift.preflight_smoke import (_check_validation, _choose_training_record,
                                      run_smoke, StartupSelectionError)


def _methane(identifier):
    xyz = np.array([[0., 0., 0.], [.63, .63, .63], [.63, -.63, -.63],
                    [-.63, .63, -.63], [-.63, -.63, .63]])
    bonds = np.zeros((5, 5), dtype=np.int8)
    bonds[0, 1:] = bonds[1:, 0] = 1
    return {"id": identifier, "Z": np.array([6, 1, 1, 1, 1]),
            "positions": xyz, "initial_positions": xyz * 1.025,
            "radii": np.array([.76, .31, .31, .31, .31]), "bonds": bonds}


def test_real_trainer_checkpoint_resume_plumbing_on_synthetic_fixture(tmp_path):
    data = tmp_path / "synthetic_fixture"
    save_records([_methane("synthetic_train")], data / "train.npz")
    save_records([_methane("synthetic_val_a"), _methane("synthetic_val_b")],
                 data / "validation.npz")
    config = json.loads((Path(__file__).parents[1] / "configs/pilot_intrinsic.json").read_text())
    old_threads = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        report = run_smoke(data, config, tmp_path / "smoke", device="cpu")
    finally:
        torch.set_num_threads(old_threads)
    assert report["passed"] is True
    assert report["benchmark_result"] is False
    assert report["actual_device"] == "cpu"
    assert report["model_architecture_unchanged"] is True
    assert report["geometry_unchanged"] is True
    assert report["noise_schedule_unchanged"] is True
    assert report["accepted_updates"] == 2
    assert report["geometry_rejections"] == 0
    assert report["checkpoint_reload_valid"] is True
    assert report["updates"][1]["resumed_from_update"] == 1
    assert report["updates"][1]["accepted_graphs"] == 2
    assert report["updates"][1]["parameter_change"]["maximum_absolute_change"] > 0
    assert report["updates"][1]["gradient_norm"] > 0
    assert report["target_particles"] == 4 and report["particles"] == 2
    assert "cuda_peak_allocated_bytes" not in report
    with pytest.raises(FileExistsError):
        run_smoke(data, config, tmp_path / "smoke", device="cpu")


def test_requested_cuda_never_falls_back_to_cpu(tmp_path):
    with patch("torch.cuda.is_available", return_value=False):
        with pytest.raises(RuntimeError, match="no CPU fallback"):
            run_smoke(tmp_path / "missing", {}, tmp_path / "cuda_smoke", device="cuda")
    report = json.loads((tmp_path / "cuda_smoke/smoke_status.json").read_text())
    assert report["passed"] is False
    assert report["actual_device"] is None
    assert report["stage"] == "device"


def test_validation_with_failed_row_cannot_pass(tmp_path):
    path = tmp_path / "invalid_validation.json"
    path.write_text(json.dumps({"records": 2, "valid": 1, "failed": 1}))
    with pytest.raises(AssertionError, match="Not all validation"):
        _check_validation(path, 2)


def test_declared_record_selection_reports_planar_scope():
    small = _methane("spatial")
    flat = copy.deepcopy(small)
    flat["id"] = "planar"
    flat["positions"][:, 2] = 0
    class Fixture:
        arrays = {"id": np.array(["planar", "spatial"]), "n_atoms": np.array([5, 5])}
        def __len__(self): return 2
        def __getitem__(self, i): return [flat, small][i]
    chosen, info = _choose_training_record(Fixture(), "cpu")
    assert chosen["id"] == "spatial"
    assert [row["id"] for row in info["excluded_candidates_before_selection"]] == ["planar"]
    assert info["solver_or_noise_outcomes_used_for_selection"] is False
    assert info["selected_geometry"]["eligible_for_startup"] is True


def test_real_bad_candidate_is_reported_before_next_eligible_training_record(tmp_path):
    from test_preflight_geometry import _cyanogen
    from rdm_drift.data import load_split
    data = tmp_path / "candidate_regression"
    save_records([_methane("z_valid"), _cyanogen(), _methane("a_valid")], data / "train.npz")
    dataset = load_split(data, "train")
    source_bytes = (data / "train.npz").read_bytes()
    chosen, info = _choose_training_record(dataset, "cpu")
    assert chosen["id"] == "a_valid"  # ascending atom count then ID, not storage order
    assert info["excluded_candidates_before_selection"][0]["id"] == "117251"
    assert "not_robust_3d_at_declared_coordinate_resolution" in info["excluded_candidates_before_selection"][0]["exclusion_reasons"]
    assert info["selected_geometry"]["metric"]["jacobian_condition"] <= 1e4
    assert info["all_source_records_retained"] is True
    assert len(dataset) == 3 and (data / "train.npz").read_bytes() == source_bytes
    rotated = []
    q, _ = np.linalg.qr(np.array([[.2, .7, .1], [.8, .3, .6], [.4, .5, .9]]))
    for i in range(len(dataset)):
        record = dataset[i]
        perm = np.arange(len(record["Z"]))[::-1]
        record["positions"] = record["positions"][perm] @ q + [1., -2., 3.]
        record["radii"] = record["radii"][perm]
        record["Z"] = record["Z"][perm]
        rotated.append(record)
    class Transformed:
        arrays = {"id": np.array([r["id"] for r in rotated]),
                  "n_atoms": np.array([len(r["Z"]) for r in rotated])}
        def __len__(self): return len(rotated)
        def __getitem__(self, i): return rotated[i]
    chosen_again, info_again = _choose_training_record(Transformed(), "cpu")
    assert chosen_again["id"] == chosen["id"]
    assert info_again["candidates_examined"] == info["candidates_examined"] == 2


def test_only_117251_fails_before_training_and_keeps_full_diagnostic_report(tmp_path):
    from test_preflight_geometry import _cyanogen
    data = tmp_path / "actual_failure_fixture"
    save_records([_cyanogen()], data / "train.npz")
    # Deliberately omit validation: selection must fail before looking there,
    # never substituting an available validation record into training.
    config = json.loads((Path(__file__).parents[1] / "configs/pilot_intrinsic.json").read_text())
    with patch("rdm_drift.preflight_smoke.train") as trainer:
        with pytest.raises(StartupSelectionError, match="No training record satisfies"):
            run_smoke(data, config, tmp_path / "rejection", device="cpu")
        trainer.assert_not_called()
    report = json.loads((tmp_path / "rejection/smoke_status.json").read_text())
    assert report["passed"] is False and report["stage"] == "real_data_subset"
    assert report["coordinate_census"]["counts"]["records"] == 1
    excluded = report["training_selection"]["excluded_candidates_before_selection"]
    assert len(excluded) == 1 and excluded[0]["id"] == "117251"
    assert excluded[0]["metric"]["jacobian_condition"] > 1e4
    assert not (tmp_path / "rejection/trainer").exists()
