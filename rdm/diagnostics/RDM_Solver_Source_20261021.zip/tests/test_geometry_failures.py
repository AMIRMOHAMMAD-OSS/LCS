"""Regression from QM9M 117251 and an independent tetrahedron-domain oracle."""
import json

import numpy as np
import pytest
import torch

from rdm_drift.geometry import exp_map, horizontal_basis, rdm_features, rdm_jacobian
from rdm_drift.objectives import GeometryFailure, corrupt_reference, _summary


DTYPE = torch.float64


def cyanogen_117251():
    # Real DFT coordinates from the failed Jean Zay smoke subset. This is
    # N#C-C#N: rounded coordinates make a nominally linear shape full rank.
    x = torch.tensor([[.0175, -1.1613, -.0042], [.0025, -.0034, .0018],
                      [-.0161, 1.3722, .0093], [-.0326, 2.5301, .0161]], dtype=DTYPE)
    return x, torch.tensor([.71, .76, .76, .71], dtype=DTYPE)


def bounded_noise(x, r):
    basis = horizontal_basis(x, r)["basis"]
    z = torch.randn((2, 6), dtype=DTYPE,
                    generator=torch.Generator().manual_seed(20261013)) * .01 / np.sqrt(6)
    tangent = (basis[None] @ z[..., None]).squeeze(-1).reshape(2, 4, 3)
    rms = tangent.square().sum(-1).mean(-1).sqrt()
    return tangent * (.03 / rms).clamp(max=1)[:, None, None]


def feature_line_gram(x, r, tangent, time):
    """Invert q0+t*dq independently, then use the Euclidean distance criterion.

    Four noncoplanar atoms have six shape dimensions and six pair features.
    The induced metric is Euclidean in that local feature chart. A straight
    feature line is realizable only while its distance-derived Gram is PSD.
    """
    i, j = np.triu_indices(4, 1)
    positions, radii = x.numpy(), r.numpy()
    delta = positions[i] - positions[j]
    distance = np.linalg.norm(delta, axis=1)
    scale = radii[i] + radii[j]
    rho = distance / scale
    exponential = np.exp(-1.7 * (rho - 1))
    feature = exponential + .01 / rho
    derivative = (-1.7 * exponential - .01 / rho**2) / scale
    dq = derivative * np.sum(delta / distance[:, None] *
                             (tangent.numpy()[i] - tangent.numpy()[j]), axis=1)
    requested = feature + time * dq
    assert np.all(requested > 0)
    lo, hi = np.full(6, 1e-9), np.full(6, 1e6)
    for _ in range(100):
        mid = (lo + hi) / 2
        values = np.exp(-1.7 * (mid - 1)) + .01 / mid
        lo = np.where(values > requested, mid, lo)
        hi = np.where(values > requested, hi, mid)
    distances = (lo + hi) / 2 * scale
    squared = np.zeros((4, 4))
    squared[i, j] = distances**2
    squared[j, i] = distances**2
    return (squared[1:, 0, None] + squared[None, 0, 1:] - squared[1:, 1:]) / 2


def test_real_near_linear_feature_geodesics_leave_realizable_domain():
    x, r = cyanogen_117251()
    basis = horizontal_basis(x, r)
    assert basis["valid"] and basis["rank"] == 6
    assert float(basis["condition_number"]) > 5e5
    tangent = bounded_noise(x, r)
    assert np.linalg.eigvalsh(feature_line_gram(x, r, tangent[0], 0)).min() > 0
    for index, time in ((0, .1), (1, .001)):
        assert np.linalg.eigvalsh(feature_line_gram(x, r, tangent[index], time)).min() < -1e-9
    result = exp_map(x[None].expand(2, -1, -1), tangent, r, n_steps=16,
                     atol=1e-4, rtol=.005)
    assert not result["valid"].any()
    assert result["reason"] == ["integration_failed", "integration_failed"]
    assert torch.isnan(result["grid_error"]).all()
    assert torch.isnan(result["point"]).all()
    assert not result["fine_integration_valid"].any()


def test_regular_tetrahedron_keeps_valid_feature_line_certificate():
    x = torch.tensor([[0., 0., 0.], [1.4, 0., 0.], [.2, 1.3, 0.],
                      [.4, .3, 1.2]], dtype=DTYPE)
    r = torch.full((4,), .76, dtype=DTYPE)
    basis = horizontal_basis(x, r)["basis"]
    tangent = (basis @ torch.linspace(-.002, .002, 6, dtype=DTYPE)).reshape_as(x)
    assert np.linalg.eigvalsh(feature_line_gram(x, r, tangent, 1)).min() > 0
    result = exp_map(x, tangent, r, n_steps=16, atol=1e-8, rtol=1e-6)
    assert result["valid"] and torch.isfinite(result["grid_error"])
    expected = rdm_features(x, r) + rdm_jacobian(x, r) @ tangent.flatten()
    assert torch.allclose(rdm_features(result["point"], r), expected, atol=1e-10, rtol=1e-9)


def test_noise_failure_preserves_conditioning_and_actual_clipping_diagnostics():
    x, r = cyanogen_117251()
    with pytest.raises(GeometryFailure) as caught:
        corrupt_reference(x, r, 2, .01, .03,
                          dict(n_steps=16, atol=1e-4, rtol=.005),
                          generator=torch.Generator().manual_seed(20261013))
    error = caught.value
    diagnostic = error.diagnostics
    assert error.stage == "noise_exp" and diagnostic["accepted"] == 0
    assert diagnostic["grid_error_max"] is None
    assert diagnostic["grid_error_defined_count"] == 0
    assert diagnostic["reference_basis_condition_number"] > 5e5
    assert len(diagnostic["reference_basis_singular_values"]) == 6
    assert len(diagnostic["failed_row_details"]) == 2
    assert min(diagnostic["uncapped_tangent_rms_A"]) > 100
    assert max(diagnostic["clip_factors"]) < 1e-3
    assert diagnostic["clipped_particles"] == 2
    assert np.allclose(diagnostic["capped_tangent_rms_A"], .03)
    assert max(diagnostic["actual_tangent_metric_norm"]) < 2e-6
    json.dumps(diagnostic, allow_nan=False)


def test_invalid_base_does_not_report_grid_agreement():
    x, r = cyanogen_117251()
    x[:, 2] = 0
    result = exp_map(x, torch.zeros_like(x), r, n_steps=2)
    assert not result["valid"] and result["reason"] == "rank_or_collision"
    assert torch.isnan(result["grid_error"])


def test_large_pair_diagnostics_are_bounded_and_failures_remain_inspectable():
    # Heavy runs may solve hundreds of pairs; success logs must not serialize
    # every pair's full spectrum. A failure captures a bounded useful sample.
    count, dimensions = 240, 81
    result = {
        "valid": torch.ones(count, dtype=torch.bool),
        "reason": ["ok"] * count,
        "base_singular_values": torch.ones(count, dimensions),
        "base_condition_number": torch.linspace(1, 100, count),
        "base_rank": torch.full((count,), dimensions),
        "coarse_integration_valid": torch.ones(count, dtype=torch.bool),
        "fine_integration_valid": torch.ones(count, dtype=torch.bool),
        "grid_error": torch.zeros(count),
    }
    summary = _summary(result, count)
    assert "base_singular_values" not in summary
    assert "failed_row_details" not in summary
    assert summary["base_condition_number_max"] == 100
    assert summary["base_rank_min"] == dimensions
    assert summary["coarse_integration_invalid_count"] == 0
    assert len(json.dumps(summary, allow_nan=False)) < 1000
    result["valid"][::2] = False
    result["fine_integration_valid"][::2] = False
    result["grid_error"][::2] = torch.nan
    result["reason"][::2] = ["integration_failed"] * (count // 2)
    failed = _summary(result, count)
    assert len(failed["failed_row_details"]) == 4
    assert failed["failed_rows_omitted"] == 116
    assert [row["row"] for row in failed["failed_row_details"]] == [0, 2, 4, 6]
    assert len(failed["failed_row_details"][0]["base_singular_values"]) == dimensions
    assert failed["fine_integration_invalid_count"] == 120
    assert failed["grid_error_defined_count"] == 120
    json.dumps(failed, allow_nan=False)
