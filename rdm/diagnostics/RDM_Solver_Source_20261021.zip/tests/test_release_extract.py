import hashlib,io,json,tarfile
from pathlib import Path
import pytest
from rdm_drift import prepare_data

def packed(entries,mode='w'):
    stream=io.BytesIO()
    with tarfile.open(fileobj=stream,mode=mode) as tar:
        for name,body in entries:
            info=tarfile.TarInfo(name);info.size=len(body);tar.addfile(info,io.BytesIO(body))
    return stream.getvalue()

def allow_fixture(monkeypatch,data):
    monkeypatch.setitem(prepare_data.SOURCE,'size',len(data))
    monkeypatch.setitem(prepare_data.SOURCE,'md5',hashlib.md5(data).hexdigest())

def test_nested_processed_extraction_and_metadata(tmp_path,monkeypatch):
    inner=packed([('qm9m_MMFFtoDFT/processed/test_proc.pt',b'test'),('qm9m_riemannian/processed/train_proc.pt',b'noise')])
    outer=packed([('release/qm9/processed.tar',inner),('release/qm9/wrong_samples.pkl',b'ids'),('release/qm7/noise.pt',b'skip')],'w:gz')
    allow_fixture(monkeypatch,outer);source=tmp_path/'release.tar.gz';source.write_bytes(outer)
    out=tmp_path/'out';selected=prepare_data.extract(source,out)
    assert len(selected)==2
    assert len(list(out.rglob('test_proc.pt')))==1
    assert not list(out.rglob('train_proc.pt'))
    manifest=json.loads((out/'verified_release.json').read_text())
    assert len(manifest['nested_archives'])==1
    assert all(len(x['sha256'])==64 for x in manifest['files'])

def test_archive_traversal_and_checksum_rejected(tmp_path,monkeypatch):
    outer=packed([('../qm9/test_proc.pt',b'bad')],'w:gz');allow_fixture(monkeypatch,outer)
    source=tmp_path/'bad.gz';source.write_bytes(outer)
    with pytest.raises(ValueError,match='Unsafe archive path'):prepare_data.extract(source,tmp_path/'out')
    source.write_bytes(outer+b'changed')
    with pytest.raises(ValueError,match='verified authors release'):prepare_data.extract(source,tmp_path/'out2')
