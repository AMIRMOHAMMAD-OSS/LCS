"""Fail-closed preflight/report gates, without Slurm, datasets or GPU hardware."""
import argparse
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from rdm_drift import preflight

ROOT = Path(__file__).resolve().parents[1]


def script(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'scripts' / f'{name}.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class PreflightTest(unittest.TestCase):
    def fixture(self, root):
        for name in ('rdm_drift', 'scripts', 'hpc'):
            (root / name).mkdir()
        (root / 'rdm_drift/a.py').write_text('value = 1\n')
        config = root / 'config.json'
        config.write_bytes((ROOT / 'configs/pilot_intrinsic.json').read_bytes())
        env = root / 'site.env'
        env.write_text('RDM_TORCH_MODULE=fixture\n')
        data = root / 'data'
        data.mkdir()
        for name in preflight.DATA_FILES:
            (data / name).write_bytes(b'fixture')
        return config, data, env

    def report(self, root, config, data, env, stage='gpu'):
        value = {'schema': 1, 'stage': stage, 'status': 'PASS',
                 'bindings': preflight.bindings(config, data, env, full_data=True, runtime=True, root=root)}
        path = root / f'{stage}.json'
        path.write_text(json.dumps(value))
        return path

    def test_matching_report_accepts_semantically_identical_config_snapshot(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            config, data, env = self.fixture(root)
            report = self.report(root, config, data, env)
            snapshot = root / 'config_snapshot.json'
            snapshot.write_text(json.dumps(json.loads(config.read_text()), sort_keys=True))
            preflight.verify_report(report, 'gpu', snapshot, data, env, full_data=True, runtime=True, root=root)

    def test_login_gate_does_not_read_npz_contents(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            config, data, env = self.fixture(root)
            report = self.report(root, config, data, env)
            original = preflight._hash_file
            def check(path):
                self.assertNotEqual(Path(path).suffix, '.npz')
                return original(path)
            with patch.object(preflight, '_hash_file', side_effect=check):
                preflight.verify_report(report, 'gpu', config, data, env, root=root)

    def test_gate_rejects_stale_source_config_environment_and_data(self):
        for case in ('source', 'config', 'env', 'data'):
            with self.subTest(case=case), tempfile.TemporaryDirectory() as folder:
                root = Path(folder)
                config, data, env = self.fixture(root)
                report = self.report(root, config, data, env)
                if case == 'source':
                    (root / 'rdm_drift/a.py').write_text('value = 2\n')
                elif case == 'config':
                    value = json.loads(config.read_text()); value['model']['hidden'] += 1
                    config.write_text(json.dumps(value))
                elif case == 'env':
                    env.write_text('RDM_TORCH_MODULE=changed\n')
                else:
                    (data / 'train.npz').write_bytes(b'changed')
                with self.assertRaisesRegex(ValueError, 'Stale'):
                    preflight.verify_report(report, 'gpu', config, data, env, root=root)

    def test_full_gate_detects_same_size_same_mtime_data_mutation(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            config, data, env = self.fixture(root)
            report = self.report(root, config, data, env)
            path = data / 'train.npz'; stat = path.stat()
            path.write_bytes(b'changed')
            os.utime(path, ns=(stat.st_atime_ns, stat.st_mtime_ns))
            with self.assertRaisesRegex(ValueError, 'sha256'):
                preflight.verify_report(report, 'gpu', config, data, env, full_data=True, root=root)

    def test_cpu_compute_refused_outside_batch(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaisesRegex(ValueError, 'Slurm allocation'):
                preflight.require_batch('cpu')
            preflight.require_batch('cpu', allow_local=True)

    def test_failure_overwrites_previous_pass_report(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            config, data, env = self.fixture(root)
            output = root / 'output'; output.mkdir()
            (output / 'report.json').write_text('{"status":"PASS"}')
            a = argparse.Namespace(stage='cpu', config=str(config), data=str(data), env_file=str(env),
                output=str(output), raw_root=None, prepare=False, force_rebuild=False, cpu_report=None, allow_local=False)
            with patch.dict(os.environ, {}, clear=True), patch.object(preflight, 'ROOT', root), contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(preflight.run_stage(a), 1)
            self.assertEqual(json.loads((output / 'report.json').read_text())['status'], 'FAIL')

    def test_cpu_job_has_no_gpu_or_memory_flags_and_does_not_submit_by_default(self):
        submit = script('submit_preflight')
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            config, data, env = self.fixture(root)
            with patch.object(submit, 'ROOT', root), patch.object(submit.subprocess, 'run') as called, contextlib.redirect_stdout(io.StringIO()):
                code = submit.main(['cpu', '--account', 'explicit@cpu', '--qos', 'explicit_cpu_qos',
                    '--config', str(config), '--data', str(data), '--env-file', str(env), '--output', str(root / 'result')])
            self.assertEqual(code, 0); called.assert_not_called()
            command = next((root / 'submissions').glob('*/command.txt')).read_text()
            self.assertNotIn('--gres', command)
            self.assertNotIn('--constraint=a100', command)
            self.assertNotIn('--mem', command)
            self.assertNotIn('--wait', command)

    def test_gpu_submit_requires_cpu_pass_before_sbatch(self):
        submit = script('submit_preflight')
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            config, data, env = self.fixture(root)
            bad = root / 'cpu.json'; bad.write_text('{"schema":1,"stage":"cpu","status":"FAIL"}')
            with patch.object(submit, 'ROOT', root), patch.object(submit.subprocess, 'run') as called, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    submit.main(['gpu', '--account', 'explicit@a100', '--qos', 'explicit_gpu_qos',
                        '--config', str(config), '--data', str(data), '--env-file', str(env),
                        '--output', str(root / 'result'), '--cpu-report', str(bad), '--submit'])
            called.assert_not_called()

    def test_train_submit_requires_gpu_pass_before_sbatch(self):
        submit = script('submit_jeanzay')
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            config, data, env = self.fixture(root)
            with patch.object(submit, 'ROOT', root), patch.object(submit.subprocess, 'run') as called, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    submit.main(['train', '--account', 'explicit@a100', '--qos', 'explicit_gpu_qos',
                        '--config', str(config), '--data', str(data), '--env-file', str(env),
                        '--output', str(root / 'runs'), '--submit'])
            called.assert_not_called()

    def test_runner_blocks_old_payload_before_child(self):
        runner = script('run_job')
        with tempfile.TemporaryDirectory() as folder:
            payload = Path(folder) / 'payload.json'; payload.write_text('{"action":"train"}')
            with patch.object(sys, 'argv', ['run_job.py', '--payload', str(payload)]), patch.object(runner.subprocess, 'Popen') as called, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    runner.main()
            called.assert_not_called()

    def test_matching_gpu_report_allows_submit_and_is_snapshotted(self):
        submit = script('submit_jeanzay')
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            config, data, env = self.fixture(root)
            report = self.report(root, config, data, env)
            with patch.object(submit, 'ROOT', root), patch.object(submit.shutil, 'which', return_value='/usr/bin/sbatch'), patch.object(submit.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0, '12345\n', '')) as called, contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(submit.main(['train', '--account', 'explicit@a100', '--qos', 'explicit_gpu_qos',
                    '--config', str(config), '--data', str(data), '--env-file', str(env),
                    '--output', str(root / 'runs'), '--preflight-report', str(report), '--submit']), 0)
            called.assert_called_once()
            payload = json.loads(next((root / 'submissions').glob('*/payload.json')).read_text())
            self.assertNotEqual(payload['preflight_report'], str(report))
            self.assertEqual(json.loads(Path(payload['preflight_report']).read_text()), json.loads(report.read_text()))
            preflight.verify_report(payload['preflight_report'], 'gpu', payload['config'], data, env, full_data=True, runtime=True, root=root)

    def test_runner_rechecks_staleness_before_child(self):
        runner = script('run_job')
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            config, data, env = self.fixture(root)
            report = self.report(root, config, data, env)
            payload = root / 'payload.json'
            payload.write_text(json.dumps({'action': 'train', 'preflight_report': str(report),
                'config': str(config), 'data': str(data), 'env_file': str(env), 'package_root': str(root)}))
            (root / 'rdm_drift/a.py').write_text('value = 2\n')
            with patch.object(sys, 'argv', ['run_job.py', '--payload', str(payload)]), patch.object(runner.subprocess, 'Popen') as called, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    runner.main()
            called.assert_not_called()


if __name__ == '__main__':
    unittest.main()
