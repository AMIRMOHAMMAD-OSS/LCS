"""Round trips through the actual PyG processed-file format used by R-DM."""
import json
import numpy as np
import pytest
import torch
from rdkit import Chem
from torch_geometric.data import Data, InMemoryDataset

from rdm_drift.data import ENCODED_Z, PackedDataset, load_split, save_records
from rdm_drift.prepare_data import convert_record, iter_processed, prepare


def record(index,smarts='[H:2][C:1]([H:3])([H:4])[H:5]',identical=False):
    mol = Chem.MolFromSmarts(smarts)
    order = np.argsort([a.GetAtomMapNum() for a in mol.GetAtoms()])
    z = np.array([a.GetAtomicNum() for a in mol.GetAtoms()])[order]
    encoded = [int(np.where(ENCODED_Z==value)[0][0]) for value in z]
    n = len(z)
    pos = torch.arange(n*3,dtype=torch.float64).reshape(n,3)*.13
    pos[:,2] = torch.cos(torch.arange(n,dtype=torch.float64))*.25
    reference = pos + .015*torch.sin(torch.arange(n*3,dtype=torch.float64)).reshape(n,3)
    if identical:reference=pos.clone()
    pairs = []
    for bond in mol.GetBonds():
        a = mol.GetAtomWithIdx(bond.GetBeginAtomIdx()).GetAtomMapNum()-1
        b = mol.GetAtomWithIdx(bond.GetEndAtomIdx()).GetAtomMapNum()-1
        pairs.append(sorted([a,b]))
    edge_index = torch.tensor(pairs,dtype=torch.long).T if pairs else torch.empty((2,0),dtype=torch.long)
    return Data(x=torch.tensor(encoded),pos=torch.stack([reference,pos],1),
                edge_index=edge_index,edge_feat=torch.ones(len(pairs),dtype=torch.long),
                idx=int(index),smarts=smarts)


def write_processed(path,records):
    path.parent.mkdir(parents=True,exist_ok=True)
    torch.save(InMemoryDataset.collate(records),path)


def test_mapping_coordinates_bonds_and_no_unit_conversion():
    d = record(712)
    out = convert_record(d)
    assert out['id']=='712'
    assert out['Z'].tolist()==[6,1,1,1,1]
    assert np.array_equal(out['positions'],d.pos[:,0].numpy())
    assert np.array_equal(out['initial_positions'],d.pos[:,1].numpy())
    assert np.array_equal(out['bonds'][0],[0,1,1,1,1])
    assert np.allclose(out['radii'],[.76,.31,.31,.31,.31])
    assert out['paper_eligible']


def test_pyg_split_roundtrip_preserves_every_row_order_and_exclusions(tmp_path):
    source = tmp_path/'release'/'qm9m_MMFFtoDFT'/'processed'
    write_processed(source/'train_proc.pt',[record(401),record(3)])
    write_processed(source/'valid_proc.pt',[record(84),record(22)])
    write_processed(source/'test_proc.pt',[record(98),record(15,identical=True),
                     record(902,'[H:1].[H:2]')])
    output = tmp_path/'portable'
    manifest = prepare(tmp_path/'release',output,source,trust_local_pt=True)
    assert manifest['splits']['train']['count']==2
    assert manifest['splits']['validation']['count']==2
    assert manifest['splits']['test']['count']==3
    assert manifest['splits']['test']['paper_eligible']==1
    test = load_split(output,'test')
    assert [r['id'] for r in test]==['98','15','902']
    assert test[1]['exclusion_reason']=='MMFF_equals_DFT'
    assert test[2]['exclusion_reason']=='disconnected_graph'
    assert len(test[2]['Z'])==2  # Singular geometries remain in benchmark storage.
    assert len(test)==3
    assert load_split(output,'val')[0]['id']=='84'
    with np.load(output/'test.npz',allow_pickle=False) as packed:
        assert all(packed[k].dtype.kind!='O' for k in packed.files)
    stored = json.loads((output/'manifest.json').read_text())
    assert test.fingerprint==stored['splits']['test']['npz_sha256']


def test_invalid_mapping_and_wrong_position_format_fail_loudly():
    d = record(1)
    d.smarts='[H:2][C:1]([H:3])([H:4])[H:4]'
    with pytest.raises(ValueError,match='Invalid atom maps'):convert_record(d)
    d = record(2);d.x[0]=0
    with pytest.raises(ValueError,match='elements disagree'):convert_record(d)
    d = record(3);d.pos=d.pos[:,0]
    with pytest.raises(ValueError,match='DFT/MMFF pair'):convert_record(d)


def test_duplicate_and_cross_split_ids_fail_loudly(tmp_path):
    source = tmp_path/'processed'
    write_processed(source/'train_proc.pt',[record(1),record(2)])
    write_processed(source/'valid_proc.pt',[record(3),record(4)])
    write_processed(source/'test_proc.pt',[record(1),record(5)])
    with pytest.raises(ValueError,match='Split ID overlap'):
        prepare(tmp_path,tmp_path/'portable',source,trust_local_pt=True)
    records=[convert_record(record(7)),convert_record(record(7))]
    save_records(records,tmp_path/'duplicate.npz')
    with pytest.raises(ValueError,match='Duplicate'):PackedDataset(tmp_path/'duplicate.npz')


def test_malformed_row_is_not_silently_dropped(tmp_path):
    source = tmp_path/'processed'
    bad=record(2);bad.pos[0,0,0]=float('nan')
    write_processed(source/'train_proc.pt',[record(1),bad])
    write_processed(source/'valid_proc.pt',[record(3),record(4)])
    write_processed(source/'test_proc.pt',[record(5),record(6)])
    with pytest.raises(ValueError,match='coordinate'):
        prepare(tmp_path,tmp_path/'portable',source,trust_local_pt=True)
    assert json.loads((tmp_path/'portable'/'manifest.json').read_text())['status']=='failed'
    assert not (tmp_path/'portable'/'train.npz').exists()

