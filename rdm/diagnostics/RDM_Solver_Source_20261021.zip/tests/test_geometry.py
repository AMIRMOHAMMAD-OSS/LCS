"""Independent geometric checks; these do not merely restate solver code."""
import torch

from rdm_drift.geometry import (
    rdm_features, rdm_jacobian, rdm_hessian_vv, horizontal_projection,
    horizontal_basis, metric_norm, metric_covector, proper_align,
    quotient_rmsd, exp_map, log_map,
)


torch.set_num_threads(1)
DTYPE = torch.float64


def shape(n=4):
    x = torch.tensor([[0.,0.,0.],[1.4,0.,0.],[.2,1.3,0.],
                      [.4,.3,1.2],[1.2,1.1,.8]],dtype=DTYPE)[:n]
    return x-x.mean(0), torch.full((n,), .76,dtype=DTYPE)


def tangent(x,r,scale=.02):
    generator = torch.Generator().manual_seed(921)
    return horizontal_projection(x,torch.randn(x.shape,generator=generator,dtype=DTYPE)*scale,r)


def solver(x,y,r):
    return log_map(x,y,r,n_steps=12,max_iter=12,tolerance=2e-8,
                   fd_eps=1e-5,damping=1e-4,speed_tolerance=1e-6)


def test_analytic_jacobian_and_hessian_against_autograd():
    x,r = shape(5)
    x.requires_grad_(True)
    v = tangent(x,r)
    numerical_j = torch.autograd.functional.jacobian(lambda z: rdm_features(z,r),x).flatten(1)
    assert torch.allclose(rdm_jacobian(x,r),numerical_j,atol=2e-12,rtol=2e-12)
    independent_h = torch.autograd.functional.jvp(
        lambda z: torch.autograd.functional.jvp(lambda zz: rdm_features(zz,r),z,v,create_graph=True)[1],
        x,v)[1]
    assert torch.allclose(rdm_hessian_vv(x,v,r),independent_h,atol=2e-12,rtol=2e-12)


def test_tetrahedron_exact_local_metric_and_log():
    # A generic tetrahedron has six shape dimensions and six pair features.
    # Its image is locally open in R^6, so straight feature segments are exact
    # geodesics locally. This is an independent oracle, not the training loss.
    x,r = shape()
    y = x + tangent(x,r,.015)
    result = solver(x,y,r)
    assert result['valid'], result
    feature_delta = rdm_features(y,r)-rdm_features(x,r)
    assert torch.allclose(result['distance'],feature_delta.norm(),rtol=2e-5,atol=2e-8)
    j_log = rdm_jacobian(x,r) @ result['log'].flatten()
    assert torch.allclose(j_log,feature_delta,rtol=2e-5,atol=2e-8)


def test_exp_log_reversal_and_metric_basis():
    x,r = shape(5)
    v = tangent(x,r)
    b = horizontal_basis(x,r)
    jb = rdm_jacobian(x,r) @ b['basis']
    assert b['valid']
    assert torch.allclose(jb.T@jb,torch.eye(9,dtype=DTYPE),atol=2e-11,rtol=2e-11)
    endpoint = exp_map(x,v,r,n_steps=12,atol=1e-8,rtol=1e-6)
    assert endpoint['valid'], endpoint
    forward = solver(x,endpoint['point'],r)
    reverse = solver(endpoint['point'],x,r)
    assert forward['valid'] and reverse['valid']
    assert torch.allclose(forward['log'],v,atol=5e-7,rtol=2e-5)
    assert torch.allclose(forward['distance'],reverse['distance'],rtol=2e-5,atol=2e-8)
    assert torch.allclose(forward['distance'],metric_norm(x,v,r),rtol=2e-5,atol=2e-8)


def test_first_variation_against_independently_resolved_distance():
    x,r = shape(5)
    fixed_y = exp_map(x,tangent(x,r,.025),r,n_steps=16,atol=1e-8,rtol=1e-6)['point']
    center = solver(x,fixed_y,r)
    direction = torch.tensor([[.2,-.1,.1],[-.1,.1,.3],[.2,.2,-.2],
                              [-.3,-.2,.1],[.1,0.,-.3]],dtype=DTYPE)
    direction /= direction.norm()
    epsilon = 2e-5
    plus = solver(x+epsilon*direction,fixed_y,r)
    minus = solver(x-epsilon*direction,fixed_y,r)
    assert center['valid'] and plus['valid'] and minus['valid']
    finite_difference = .5*(plus['distance'].square()-minus['distance'].square())/(2*epsilon)
    first_variation = -(metric_covector(x,center['log'],r)*direction).sum()
    assert torch.allclose(first_variation,finite_difference,atol=2e-7,rtol=2e-4)


def test_proper_rigid_equivariance_and_no_reflection_alignment():
    x,r = shape(5)
    y = x + tangent(x,r,.015)
    a = torch.tensor([[.8,-.6,0.],[.6,.8,0.],[0.,0.,1.]],dtype=DTYPE)
    t = torch.tensor([3.,-4.,2.],dtype=DTYPE)
    left = solver(x,y,r)
    right = solver(x@a+t,y@a+t,r)
    assert left['valid'] and right['valid']
    assert torch.allclose(right['log'],left['log']@a,atol=2e-7,rtol=1e-5)
    assert torch.allclose(right['distance'],left['distance'],atol=2e-8,rtol=1e-6)
    mirror = x.clone(); mirror[:,0] *= -1
    assert quotient_rmsd(x,mirror) > .1
    assert torch.allclose(proper_align(x@a+t,x),x,atol=2e-12,rtol=2e-12)


def test_batch_and_failure_are_explicit():
    x,r = shape(4)
    bad = x.clone(); bad[1]=bad[0]
    base = torch.stack([x,bad])
    target = torch.stack([x+tangent(x,r,.01),bad])
    result = log_map(base,target,r,n_steps=8,max_iter=8,tolerance=1e-6)
    assert result['valid'].tolist() == [True,False]
    assert torch.isfinite(result['distance'][0]) and torch.isnan(result['distance'][1])
    assert torch.isnan(result['log'][1]).all()
    vertical = torch.ones_like(x)*.01
    rejected = exp_map(x,vertical,r)
    assert not rejected['valid']
    assert rejected['reason'] == 'nonhorizontal_velocity'


def test_singular_planar_and_diatomic_shapes_are_rejected_explicitly():
    x,r = shape(4)
    x[:,2] = 0
    planar = log_map(x,x,r)
    assert not planar['valid']
    assert planar['rank'] < 6
    assert planar['reason'] == 'invalid_base_or_target'
    diatomic = torch.tensor([[0.,0.,0.],[1.1,0.,0.]],dtype=DTYPE)
    rejected = log_map(diatomic,diatomic,torch.tensor([.31,.57],dtype=DTYPE))
    assert not rejected['valid']
    assert rejected['rank'] == 1
    assert torch.isnan(rejected['distance'])


def test_latent_metric_gaussian_basis_and_batching():
    x,r = shape(5)
    b = horizontal_basis(x,r)['basis']
    latent = torch.linspace(-.02,.02,b.shape[-1],dtype=DTYPE)
    v = (b@latent).reshape_as(x)
    assert torch.allclose(metric_norm(x,v,r),latent.norm(),atol=1e-12,rtol=1e-12)
    result = exp_map(x[None].repeat(2,1,1),torch.stack([v,-v]),r,n_steps=8)
    assert result['valid'].all()
    assert result['point'].shape == (2,5,3)

