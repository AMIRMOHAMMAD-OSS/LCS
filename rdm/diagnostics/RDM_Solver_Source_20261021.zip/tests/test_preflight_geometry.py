"""Numerical startup-scope regressions, not full-dataset acceptance claims."""
import copy

import numpy as np
import pytest

from rdm_drift.preflight_geometry import (coordinate_census, coordinate_diagnostics,
                                          startup_criteria, startup_record_diagnostics)


def _cyanogen():
    # Exact four-decimal coordinates from the failed real record 117251 bundle.
    xyz = np.array([[.0175, -1.1613, -.0042], [.0025, -.0034, .0018],
                    [-.0161, 1.3722, .0093], [-.0326, 2.5301, .0161]])
    return {"id": "117251", "Z": np.array([7, 6, 6, 7]),
            "positions": xyz,
            "initial_positions": np.array([[.0191, -1.2528, -.0049], [.0033, -.0908, .0015],
                                            [-.0177, 1.4596, .0100], [-.0335, 2.6216, .0164]]),
            "radii": np.array([.71, .76, .76, .71]),
            "bonds": np.array([[0, 3, 0, 0], [3, 0, 1, 0], [0, 1, 0, 3], [0, 0, 3, 0]])}


def _methane(identifier="methane"):
    xyz = np.array([[0., 0., 0.], [.63, .63, .63], [.63, -.63, -.63],
                    [-.63, .63, -.63], [-.63, -.63, .63]])
    return {"id": identifier, "Z": np.array([6, 1, 1, 1, 1]),
            "positions": xyz, "initial_positions": xyz * 1.025,
            "radii": np.array([.76, .31, .31, .31, .31])}


def test_actual_117251_is_not_a_robust_startup_geometry():
    record = _cyanogen()
    x = record["positions"]
    assert np.linalg.matrix_rank(x - x.mean(0), tol=1e-8) == 3  # original gap
    result = startup_record_diagnostics(record)
    assert result["eligible_for_startup"] is False
    assert result["coordinates"]["singular_values_A"][-1] == pytest.approx(1.608723790232453e-5, rel=1e-5)
    assert result["coordinates"]["rounding_perturbation_bound_A"] == pytest.approx(.00017320508075688773)
    assert result["metric"]["existing_basis_valid"] is True
    assert result["metric"]["jacobian_condition"] == pytest.approx(570064.9059, rel=1e-6)
    assert set(result["exclusion_reasons"]) == {
        "not_robust_3d_at_declared_coordinate_resolution",
        "jacobian_condition_exceeds_startup_limit"}


def test_coordinate_and_metric_screening_are_rigid_motion_and_permutation_invariant():
    for record in (_cyanogen(), _methane()):
        expected = startup_record_diagnostics(record)
        q, _ = np.linalg.qr(np.array([[.2, .7, .1], [.8, .3, .6], [.4, .5, .9]]))
        perm = np.arange(len(record["Z"]))[::-1]
        changed = copy.deepcopy(record)
        changed["positions"] = record["positions"][perm] @ q + np.array([1., -2., 3.])
        changed["radii"] = record["radii"][perm]
        changed["Z"] = record["Z"][perm]
        observed = startup_record_diagnostics(changed)
        assert observed["eligible_for_startup"] == expected["eligible_for_startup"]
        assert observed["exclusion_reasons"] == expected["exclusion_reasons"]
        np.testing.assert_allclose(observed["coordinates"]["singular_values_A"],
                                   expected["coordinates"]["singular_values_A"], rtol=1e-9, atol=1e-12)
        assert observed["metric"]["jacobian_condition"] == pytest.approx(expected["metric"]["jacobian_condition"], rel=1e-8)


def test_joint_length_resolution_and_radius_scaling_preserves_startup_scope():
    for record in (_cyanogen(), _methane()):
        expected = startup_record_diagnostics(record)
        scale = 10.0
        changed = copy.deepcopy(record)
        changed["positions"] *= scale
        changed["radii"] *= scale
        criteria = startup_criteria({"preflight": {"coordinate_resolution_A": 1e-4 * scale}})
        observed = startup_record_diagnostics(changed, criteria)
        assert observed["eligible_for_startup"] == expected["eligible_for_startup"]
        assert observed["exclusion_reasons"] == expected["exclusion_reasons"]
        assert observed["metric"]["jacobian_condition"] == pytest.approx(expected["metric"]["jacobian_condition"], rel=1e-8)
        assert observed["coordinates"]["rounding_perturbation_bound_A"] == pytest.approx(
            expected["coordinates"]["rounding_perturbation_bound_A"] * scale)


def test_metric_condition_is_an_independent_declared_startup_gate():
    record = _methane()
    normal = startup_record_diagnostics(record)
    assert normal["eligible_for_startup"] is True
    strict = startup_criteria({"preflight": {"max_jacobian_condition": 1.0}})
    result = startup_record_diagnostics(record, strict)
    assert result["coordinates"]["robust_3d_at_declared_resolution"] is True
    assert result["exclusion_reasons"] == ["jacobian_condition_exceeds_startup_limit"]


def test_chunked_census_ignores_padding_and_does_not_mutate_or_filter_records():
    values = np.full((3, 7, 3), np.nan)
    values[0, :4] = _cyanogen()["positions"]
    values[1, :5] = _methane()["positions"]
    values[2, :5] = _methane()["positions"]
    values[2, 0, 0] = np.nan
    original = values.copy()
    class Fixture:
        arrays = {"positions": values, "n_atoms": np.array([4, 5, 5])}
    criterion = startup_criteria({"preflight": {"coordinate_census_chunk_size": 1}})
    report = coordinate_census(Fixture(), criterion)
    assert report["counts"] == {"records": 3, "finite_coordinates": 2, "nonfinite_coordinates": 1,
                                "robust_3d_at_declared_resolution": 1,
                                "not_robust_3d_at_declared_resolution": 1,
                                "fewer_than_four_atoms": 0}
    assert report["atom_count_histogram"] == {"4": 1, "5": 2}
    assert report["all_records_retained"] is True
    assert report["metric_conditioning_coverage"] == "not evaluated by this census"
    assert report["noise_or_geodesic_acceptance_coverage"] == "not evaluated by this census"
    np.testing.assert_array_equal(values, original)
    assert coordinate_census(Fixture())["counts"] == report["counts"]


def test_small_or_nonfinite_shapes_cannot_satisfy_three_dimensional_screen():
    assert coordinate_diagnostics([[0., 0., 0.]])["robust_3d_at_declared_resolution"] is False
    assert coordinate_diagnostics([[0., 0., 0.], [1., 0., 0.], [0., 1., 0.]])["robust_3d_at_declared_resolution"] is False
    assert coordinate_diagnostics([[np.nan, 0., 0.]])["finite"] is False
    for config in ({"coordinate_resolution_A": 0}, {"max_jacobian_condition": float("inf")},
                   {"coordinate_census_chunk_size": 0}):
        with pytest.raises(ValueError):
            startup_criteria({"preflight": config})
