"""Regression tests for reconstruction, rejection scope and cache safety."""
import io
import json
import pickle
import tarfile
from pathlib import Path
from unittest.mock import patch

import pytest
import torch
from rdkit import Chem

from rdm_drift import rebuild_raw as module
from rdm_drift.rebuild_raw import rebuild_processed, sdf_pair_to_data, UnsupportedGraphFeature
from rdm_drift.prepare_data import iter_processed, convert_record, prepare, SOURCE
from rdm_drift.data import file_sha256


def sdf_pair(index):
    mol = Chem.AddHs(Chem.MolFromSmiles('CO'))
    conf = Chem.Conformer(mol.GetNumAtoms())
    for i in range(mol.GetNumAtoms()):
        conf.SetAtomPosition(i, (i * 0.7, (i % 3) * 0.4, (i % 2) * 0.35))
    mol.AddConformer(conf)
    reference = (Chem.MolToMolBlock(mol) + '\n$$$$\n').encode()
    for i in range(mol.GetNumAtoms()):
        pos = conf.GetAtomPosition(i)
        mol.GetConformer().SetAtomPosition(i, (pos.x + (i % 2) * .05, pos.y, pos.z + .01))
    initial = (Chem.MolToMolBlock(mol) + '\n$$$$\n').encode()
    return reference, initial


def make_archive(tmp_path, bad=False):
    archive = tmp_path / 'qm9_mmff.tar.bz2'
    with tarfile.open(archive, 'w:bz2') as tar:
        for index in [1, 10, 100, 1000, 10000, 100005]:
            for suffix, payload in zip(['.sdf', '.mmff.sdf'], sdf_pair(index)):
                if bad and index == 100005:
                    payload = b'invalid SDF'
                info = tarfile.TarInfo(f'qm9_mmff/{index}{suffix}')
                info.size = len(payload)
                tar.addfile(info, io.BytesIO(payload))
    splits = {'train_index': [10, 1, 0], 'valid_index': [1000, 100], 'test_index': [100005, 10000]}
    splitfile = tmp_path / 'data_split.pkl'
    with splitfile.open('wb') as stream:
        pickle.dump(splits, stream)
    return archive, splitfile


def test_sdf_reconstruction_schema_order_and_cache_reuse(tmp_path):
    archive, splitfile = make_archive(tmp_path)
    output, audit = rebuild_processed(archive, splitfile, tmp_path / 'processed')
    assert audit['status'] == 'complete'
    assert audit['missing_ids'] == [0]
    assert audit['malformed_records'] == []
    assert audit['reconstructed_count'] == 6
    rows = list(iter_processed(output / 'train_proc.pt'))
    assert [int(d.idx) for d in rows] == [10, 1]
    assert audit['allowed_missing_ids_by_split']['train'] == [0]
    for row in rows:
        converted = convert_record(row)
        assert row.node_feat.shape == (len(converted['Z']), 8)
        assert row.geodesic_length.shape == (1, 2)
        assert (row.edge_index[0] < row.edge_index[1]).all()
        assert row.pos.dtype == torch.float64
    with patch.object(module, 'sdf_pair_to_data', side_effect=AssertionError('cache not reused')):
        _, again = rebuild_processed(archive, splitfile, output)
    assert again == audit


def test_valence_eight_supported_by_official_encoder(monkeypatch):
    # Isolate the categorical contract: sanitization is independently tested
    # with real molecules below. Previously this exact value raised KeyError(8).
    class Atom:
        def GetAtomMapNum(self): return 1
        def GetIsAromatic(self): return False
        def GetFormalCharge(self): return 0
        def GetTotalNumHs(self): return 0
        def GetTotalValence(self): return 8
        def GetTotalDegree(self): return 4
        def GetHybridization(self): return Chem.rdchem.HybridizationType.SP3
        def GetChiralTag(self): return Chem.rdchem.ChiralType.CHI_UNSPECIFIED
        def IsInRing(self): return False
    class Molecule:
        def GetAtoms(self): return [Atom()]
        def GetBonds(self): return []
    monkeypatch.setattr(Chem, 'SanitizeMol', lambda _: None)
    features, _, _ = module._features(Molecule())
    assert features[0, 3].item() == 8


def test_unspecified_bond_has_precise_classification():
    mol = Chem.MolFromSmarts('[#6:1]~[#6:2]')
    with pytest.raises(UnsupportedGraphFeature) as caught:
        module._features(mol)
    assert caught.value.details['feature'] == 'GetBondType'
    assert caught.value.details['value'] == 'UNSPECIFIED'
    assert caught.value.details['atom_maps'] == [1, 2]
    assert 'UNSPECIFIED' not in caught.value.details['allowed_values']


def test_named_policy_rejects_only_classified_features_preserves_ids(tmp_path, monkeypatch):
    archive, splitfile = make_archive(tmp_path)
    original = module.sdf_pair_to_data
    def convert(index, *args):
        if index == 100005:
            raise UnsupportedGraphFeature('GetBondType', 'UNSPECIFIED', ['SINGLE', 'DOUBLE', 'TRIPLE', 'AROMATIC'], atom_maps=[1, 2])
        return original(index, *args)
    monkeypatch.setattr(module, 'sdf_pair_to_data', convert)
    output = tmp_path / 'processed'
    with pytest.raises(ValueError, match='Strict mode'):
        rebuild_processed(archive, splitfile, output)
    failed = json.loads((output / 'rebuild_audit.json').read_text())
    assert failed['status'] == 'failed'
    assert failed['fatal_records'][0]['id'] == 100005
    assert not (output / 'train_proc.pt').exists()
    with pytest.raises(ValueError, match='force-rebuild'):
        rebuild_processed(archive, splitfile, output, rebuild_policy='official_v0_0_2')
    _, audit = rebuild_processed(archive, splitfile, output, rebuild_policy='official_v0_0_2', force_rebuild=True)
    assert audit['fatal_records'] == []
    assert audit['rejected_ids_by_split'] == {'train': [], 'validation': [], 'test': [100005]}
    assert audit['retained_ids_by_split']['test'] == [10000]
    assert audit['rejected_records'][0]['feature'] == 'GetBondType'
    assert [int(d.idx) for d in iter_processed(output / 'test_proc.pt')] == [10000]
    assert list(output.glob('rebuild_audit.before_*.json'))


def test_unknown_keyerror_cannot_be_misclassified(tmp_path, monkeypatch):
    archive, splitfile = make_archive(tmp_path)
    original = module.sdf_pair_to_data
    def convert(index, *args):
        if index == 100005:
            raise KeyError('UNSPECIFIED')
        return original(index, *args)
    monkeypatch.setattr(module, 'sdf_pair_to_data', convert)
    output = tmp_path / 'processed'
    with pytest.raises(ValueError, match='Unexpected failures'):
        rebuild_processed(archive, splitfile, output, rebuild_policy='official_v0_0_2')
    audit = json.loads((output / 'rebuild_audit.json').read_text())
    assert audit['status'] == 'failed'
    assert audit['rejected_records'] == []
    assert audit['fatal_records'][0]['error_type'] == 'KeyError'


def test_invalid_sdf_always_fails_even_with_named_policy(tmp_path):
    archive, splitfile = make_archive(tmp_path, bad=True)
    output = tmp_path / 'processed'
    with pytest.raises(ValueError, match='Unexpected failures'):
        rebuild_processed(archive, splitfile, output, rebuild_policy='official_v0_0_2')
    audit = json.loads((output / 'rebuild_audit.json').read_text())
    assert audit['fatal_records'][0]['id'] == 100005
    assert audit['fatal_records'][0]['category'] == 'unexpected_record_failure'
    assert not (output / 'train_proc.pt').exists()
    with pytest.raises(ValueError, match='no longer supported'):
        rebuild_processed(archive, splitfile, output, allow_rebuild_rejections=True)


def test_modified_and_partial_cache_cannot_be_reused(tmp_path):
    archive, splitfile = make_archive(tmp_path)
    output, _ = rebuild_processed(archive, splitfile, tmp_path / 'processed')
    (output / 'test_proc.pt').write_bytes(b'broken')
    with pytest.raises(ValueError, match='modified'):
        rebuild_processed(archive, splitfile, output)
    rebuild_processed(archive, splitfile, output, force_rebuild=True)
    audit = json.loads((output / 'rebuild_audit.json').read_text())
    audit['status'] = 'in_progress'
    (output / 'rebuild_audit.json').write_text(json.dumps(audit))
    with pytest.raises(ValueError, match='incomplete/stale'):
        rebuild_processed(archive, splitfile, output)


def test_changed_split_fingerprint_rejects_cache(tmp_path):
    archive, splitfile = make_archive(tmp_path)
    output, _ = rebuild_processed(archive, splitfile, tmp_path / 'processed')
    with splitfile.open('rb') as stream:
        splits = pickle.load(stream)
    splits['train_index'] = [1, 10, 0]
    with splitfile.open('wb') as stream:
        pickle.dump(splits, stream)
    with pytest.raises(ValueError, match='stale'):
        rebuild_processed(archive, splitfile, output)
    _, audit = rebuild_processed(archive, splitfile, output, force_rebuild=True)
    assert audit['retained_ids_by_split']['train'] == [1, 10]


def test_unmarked_original_cache_never_overwritten(tmp_path):
    archive, splitfile = make_archive(tmp_path)
    output = tmp_path / 'processed'
    output.mkdir()
    (output / 'train_proc.pt').write_bytes(b'original')
    with pytest.raises(ValueError, match='Refusing to overwrite'):
        rebuild_processed(archive, splitfile, output, force_rebuild=True)
    assert (output / 'train_proc.pt').read_bytes() == b'original'


def test_prepare_reconstruction_inventory_and_manifest(tmp_path):
    root = tmp_path / 'release'
    raw = root / 'qm9m'
    raw.mkdir(parents=True)
    archive, splitfile = make_archive(raw)
    inventory = {'source': SOURCE, 'archive_sha256': 'a' * 64,
                 'files': [{'path': str(p.relative_to(root)), 'sha256': file_sha256(p)}
                           for p in (archive, splitfile)]}
    (root / 'verified_release.json').write_text(json.dumps(inventory))
    output = tmp_path / 'portable'
    manifest = prepare(root, output)
    assert manifest['status'] == 'complete'
    assert manifest['processed_origin'] == 'raw_rebuild'
    assert manifest['source_verified']
    assert manifest['splits']['train']['declared_ids'] == ['10', '1', '0']
    assert manifest['splits']['train']['retained_ids'] == ['10', '1']
    assert manifest['splits']['train']['allowed_missing_ids'] == ['0']
    from rdm_drift.preflight_checks import validate_dataset
    result = validate_dataset(output, root)
    assert result['status'] == 'passed'
    assert result['splits']['train']['known_missing_count'] == 1
    # Presence of a cached test file must not bypass audit validation.
    audit_path = root / 'rebuilt_qm9m_MMFFtoDFT/processed/rebuild_audit.json'
    audit = json.loads(audit_path.read_text()); audit['status'] = 'failed'
    audit_path.write_text(json.dumps(audit))
    with pytest.raises(ValueError, match='stale'):
        prepare(root, output)
    manifest = prepare(root, output, force_rebuild=True)
    assert manifest['status'] == 'complete'
    # Changed split bytes are rejected before a pickle loader can execute them.
    splitfile.write_bytes(b'not a trusted pickle')
    with pytest.raises(ValueError, match='inventory'):
        prepare(root, output, force_rebuild=True)


def test_unexpected_missing_id_never_permitted(tmp_path):
    archive, splitfile = make_archive(tmp_path)
    with splitfile.open('rb') as stream:
        splits = pickle.load(stream)
    splits['train_index'].append(999999)
    with splitfile.open('wb') as stream:
        pickle.dump(splits, stream)
    output = tmp_path / 'processed'
    with pytest.raises(ValueError, match='missing pairs always fail'):
        rebuild_processed(archive, splitfile, output, rebuild_policy='official_v0_0_2')
    audit = json.loads((output / 'rebuild_audit.json').read_text())
    assert audit['allowed_missing_ids'] == [0]
    assert audit['unexpected_missing_ids'] == [999999]
    assert audit['status'] == 'failed'
    assert not (output / 'train_proc.pt').exists()


def test_changed_code_fingerprint_never_reuses_cache(tmp_path, monkeypatch):
    archive, splitfile = make_archive(tmp_path)
    output, _ = rebuild_processed(archive, splitfile, tmp_path / 'processed')
    original = module.reconstruction_fingerprints
    def changed(*args, **kwargs):
        result = original(*args, **kwargs)
        result['code_sha256']['rebuild_raw.py'] = '0' * 64
        return result
    monkeypatch.setattr(module, 'reconstruction_fingerprints', changed)
    with pytest.raises(ValueError, match='stale'):
        rebuild_processed(archive, splitfile, output)
