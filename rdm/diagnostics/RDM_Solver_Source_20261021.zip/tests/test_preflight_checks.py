"""Preflight failures must block malformed, stale or population-shifted data."""
import copy
import json
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest

from rdm_drift.data import save_records
from rdm_drift.preflight_checks import (
    canonical_sha256, config_fingerprint, environment_fingerprint, file_sha256,
    snapshot, source_fingerprint, validate_config, validate_dataset, validate_static,
)

ROOT = Path(__file__).resolve().parents[1]


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2))


@pytest.fixture
def packed(tmp_path):
    raw, data = tmp_path / "raw", tmp_path / "data"
    raw.mkdir(); data.mkdir()
    split_file = raw / "qm9" / "data_split.pkl"
    split_file.parent.mkdir()
    split_file.write_bytes(b"test-only split identity; validator must never unpickle")
    exclusion = split_file.parent / "wrong_samples.pkl"
    exclusion.write_bytes(b"test-only exclusion identity")
    archive = raw / "qm9_mmff.tar.bz2"
    archive.write_bytes(b"test-only raw identity")
    source = {"md5": "55aee4295ad770ae64bd629f8b2080db", "size": 2348212124}
    release = {"source": source, "archive_sha256": "a" * 64,
               "files": [{"path": str(p.relative_to(raw)), "sha256": file_sha256(p)}
                         for p in (split_file, exclusion, archive)]}
    write_json(raw / "verified_release.json", release)
    manifest = {"schema": 2, "status": "complete", "coordinates": "Angstrom", "trust_local_pt": False,
                "source": source, "release": release, "processed_origin": "raw_rebuild", "splits": {},
                "source_verified": True,
                "verified_source_files": [{"path": str(raw / item["path"]), "relative_path": item["path"],
                                           "sha256": item["sha256"], "verified": True} for item in release["files"]],
                "official_split_file": {"path": str(split_file), "sha256": file_sha256(split_file)},
                "official_exclusion_file": {"path": str(exclusion), "sha256": file_sha256(exclusion), "ids": ["3"]},
                "exclusion_rule_disagreements": ["3"]}
    audit = {"schema": 2, "status": "complete", "policy": "strict", "fatal_records": [],
             "unexpected_missing_ids": [], "unpaired_ids": [], "rejected_records": [],
             "declared_ids_by_split": {}, "retained_ids_by_split": {}, "rejected_ids_by_split": {},
             "allowed_missing_ids_by_split": {}, "processed_files": {},
             "fingerprints": {"archive_sha256": file_sha256(archive), "split_sha256": file_sha256(split_file),
                              "code_sha256": {name: file_sha256(ROOT / "rdm_drift" / name) for name in ("rebuild_raw.py", "prepare_data.py", "data.py")},
                              "versions": environment_fingerprint()["versions"], "policy": "strict", "allowed_missing_ids": [0]}}
    for number, split in enumerate(("train", "validation", "test"), 1):
        index = str(number)
        pos = np.array([[0., 0., 0.], [.7, 0., 0.]])
        row = {"id": index, "Z": np.array([1, 1]), "positions": pos,
               "initial_positions": pos + np.array([[0., 0., 0.], [.01, .02, 0.]]),
               "radii": np.array([.31, .31]), "bonds": np.array([[0, 1], [1, 0]]),
               "smarts": "[H:1][H:2]", "paper_eligible": split != "test",
               "exclusion_reason": "official_wrong_samples" if split == "test" else ""}
        checksum = save_records([row], data / f"{split}.npz")
        processed = raw / f"{split}_proc.pt"
        processed.write_bytes(f"test-only cache {split}".encode())
        declared = [0, number] if split == "train" else [number]
        missing = [0] if split == "train" else []
        manifest["splits"][split] = {
            "count": 1, "declared_count": len(declared), "paper_eligible": int(split != "test"),
            "declared_ids": declared, "retained_ids": [number], "rejected_ids": [],
            "allowed_missing_ids": missing, "declared_ids_missing_from_processed": [str(i) for i in missing],
            "ids_order_sha256": canonical_sha256([index]), "npz_sha256": checksum,
            "processed_file": processed.name, "processed_sha256": file_sha256(processed)}
        for key, ids in (("declared_ids_by_split", declared), ("retained_ids_by_split", [number]),
                         ("rejected_ids_by_split", []), ("allowed_missing_ids_by_split", missing)):
            audit[key][split] = list(ids)
        audit["processed_files"][split] = {"count": 1, "filename": processed.name, "sha256": file_sha256(processed)}
    manifest["raw_rebuild"] = audit
    write_json(raw / "rebuild_audit.json", audit)
    write_json(data / "manifest.json", manifest)
    return data, raw, manifest


def mutate_array(packed, name, callback, split="train"):
    data, raw, manifest = packed
    path = data / f"{split}.npz"
    with np.load(path, allow_pickle=False) as z:
        arrays = {key: z[key] for key in z.files}
    callback(arrays)
    np.savez_compressed(path, **arrays)
    manifest["splits"][split]["npz_sha256"] = file_sha256(path)
    write_json(data / "manifest.json", manifest)


def test_validated_population_and_provenance_are_explicit(packed):
    data, raw, _ = packed
    result = validate_dataset(data, raw)
    assert result["status"] == "passed"
    assert result["dataset_verified"] and result["raw_sources_rehashed"]
    assert result["gpu_ready"] is False
    assert result["splits"]["train"]["known_missing_count"] == 1
    assert result["splits"]["test"]["paper_eligible"] == 0
    assert set(result["files"]) == {"train.npz", "validation.npz", "test.npz", "manifest.json"}
    assert result["processed_origin"] == "raw_rebuild"


def test_npz_hash_tampering_rejected_before_arrays(packed):
    data, raw, _ = packed
    with (data / "train.npz").open("ab") as stream:
        stream.write(b"changed")
    with pytest.raises(ValueError, match="SHA256 mismatch"):
        validate_dataset(data, raw)


@pytest.mark.parametrize("name,callback,match", [
    ("nonfinite", lambda a: a["positions"].__setitem__((0, 0, 0), np.nan), "nonfinite positions"),
    ("radii", lambda a: a["radii"].__setitem__((0, 0), .76), "radii do not match"),
    ("element", lambda a: a["Z"].__setitem__((0, 0), 16), "invalid QM9 atomic element"),
    ("bond_asym", lambda a: a["bonds"].__setitem__((0, 0, 1), 2), "asymmetric bonds"),
    ("bond_type", lambda a: a["bonds"].__setitem__((0, 0, 1), 5), "bond types outside"),
    ("self_edge", lambda a: a["bonds"].__setitem__((0, 0, 0), 1), "bond diagonal"),
    ("atoms", lambda a: a["n_atoms"].__setitem__(0, 3), "n_atoms out of bounds"),
    ("dtype", lambda a: a.__setitem__("positions", a["positions"].astype(np.float32)), "must be float64"),
    ("shape", lambda a: a.__setitem__("positions", a["positions"][:, :, :2]), "positions shape"),
    ("eligibility", lambda a: a["paper_eligible"].__setitem__(0, False), "incorrect paper eligibility"),
])
def test_fresh_hash_does_not_hide_bad_arrays(packed, name, callback, match):
    mutate_array(packed, name, callback)
    with pytest.raises(ValueError, match=match):
        validate_dataset(packed[0], packed[1])


def test_known_missing_id_cannot_expand_to_unknown_losses(packed):
    data, raw, manifest = packed
    meta = manifest["splits"]["train"]
    meta["declared_ids"].append(49)
    meta["declared_count"] += 1
    meta["allowed_missing_ids"].append(49)
    audit = manifest["raw_rebuild"]
    audit["declared_ids_by_split"]["train"].append(49)
    audit["allowed_missing_ids_by_split"]["train"].append(49)
    write_json(raw / "rebuild_audit.json", audit)
    write_json(data / "manifest.json", manifest)
    with pytest.raises(ValueError, match="unexpected missing IDs"):
        validate_dataset(data, raw)


def add_rejection(manifest):
    meta = manifest["splits"]["train"]
    meta["declared_ids"] = [0, 1, 15]
    meta["declared_count"] = 3
    meta["rejected_ids"] = [15]
    meta["declared_ids_missing_from_processed"] = ["0", "15"]
    audit = manifest["raw_rebuild"]
    audit["policy"] = audit["fingerprints"]["policy"] = "official_v0_0_2"
    audit["declared_ids_by_split"]["train"] = [0, 1, 15]
    audit["rejected_ids_by_split"]["train"] = [15]
    audit["rejected_records"] = [{"id": 15, "split": "train", "error_type": "UnsupportedGraphFeature",
                                   "category": "unsupported_graph_feature", "feature": "GetBondType",
                                   "stage": "graph_features", "value": "UNSPECIFIED",
                                   "allowed_values": ["SINGLE", "DOUBLE", "TRIPLE", "AROMATIC"]}]


def test_only_explicit_official_encoder_rejections_can_pass(packed):
    data, raw, manifest = packed
    add_rejection(manifest)
    write_json(raw / "rebuild_audit.json", manifest["raw_rebuild"])
    write_json(data / "manifest.json", manifest)
    result = validate_dataset(data, raw)
    assert result["policy"] == "official_v0_0_2"
    assert result["splits"]["train"]["rejected_count"] == 1
    manifest["raw_rebuild"]["rejected_records"][0]["error_type"] = "ValueError"
    write_json(data / "manifest.json", manifest)
    with pytest.raises(ValueError, match="not an audited unsupported"):
        validate_dataset(data, raw)


def test_fixed_valence_8_bug_cannot_be_whitelisted(packed):
    data, raw, manifest = packed
    add_rejection(manifest)
    record = manifest["raw_rebuild"]["rejected_records"][0]
    record.update(feature="GetTotalValence", value="8", allowed_values=[str(i) for i in range(7)])
    write_json(data / "manifest.json", manifest)
    with pytest.raises(ValueError, match="nonofficial encoder categories"):
        validate_dataset(data, raw)


def test_blanket_rejection_flag_is_never_a_pass(packed):
    data, raw, manifest = packed
    manifest["raw_rebuild"]["allow_rebuild_rejections"] = True
    write_json(data / "manifest.json", manifest)
    with pytest.raises(ValueError, match="Blanket"):
        validate_dataset(data, raw)


def test_stale_processed_source_rejected(packed):
    data, raw, _ = packed
    (raw / "train_proc.pt").write_bytes(b"replaced after preparation")
    with pytest.raises(ValueError, match="processed cache: SHA256 mismatch"):
        validate_dataset(data, raw)


def test_declared_npz_order_and_duplicate_ids_rejected(packed):
    mutate_array(packed, "id", lambda a: a["id"].__setitem__(0, "8"))
    with pytest.raises(ValueError, match="NPZ ID order differs"):
        validate_dataset(packed[0], packed[1])


def test_incomplete_or_trusted_local_manifest_cannot_pass(packed):
    data, raw, manifest = packed
    manifest["status"] = "incomplete"
    write_json(data / "manifest.json", manifest)
    with pytest.raises(ValueError, match="schema 2 and complete"):
        validate_dataset(data, raw)
    manifest["status"] = "complete"
    manifest["trust_local_pt"] = True
    write_json(data / "manifest.json", manifest)
    with pytest.raises(ValueError, match="Locally trusted"):
        validate_dataset(data, raw)


def test_static_checks_never_claim_full_data_or_gpu_readiness():
    result = validate_static(ROOT, [ROOT / "configs/pilot_intrinsic.json"])
    assert result["status"] == "checks_passed"
    assert result["dataset_verified"] is result["gpu_ready"] is False
    assert result["source"]["sha256"] == source_fingerprint(ROOT)["sha256"]
    env = environment_fingerprint()
    assert "cuda_available" not in env
    assert {"torch", "numpy", "rdkit"} <= set(env["versions"])


def test_static_snapshot_does_not_read_nonexistent_dataset(tmp_path):
    result = snapshot(ROOT, tmp_path / "absent", [ROOT / "configs/pilot_intrinsic.json"], full_data=False)
    assert result["dataset"]["status"] == "not_checked"
    assert not result["dataset_verified"] and not result["gpu_ready"]


def test_login_import_does_not_load_numpy_torch_or_rdkit():
    code = "import sys; import rdm_drift.preflight_checks; assert not {'numpy','torch','rdkit'} & set(sys.modules)"
    subprocess.run([sys.executable, "-c", code], cwd=ROOT, check=True)


def test_config_invalid_exp_or_noise_is_rejected(tmp_path):
    cfg = json.loads((ROOT / "configs/pilot_intrinsic.json").read_text())
    cfg["geometry"]["exp"]["check"] = False
    with pytest.raises(ValueError, match="certificates"):
        validate_config(cfg)
    cfg["geometry"]["exp"]["check"] = True
    cfg["noise"]["schedule"][0]["metric_sigma"] = float("nan")
    with pytest.raises(ValueError, match="finite"):
        validate_config(cfg)


def test_source_hash_ignores_outputs_but_tracks_implementation(tmp_path):
    for folder in ("rdm_drift", "scripts", "hpc"):
        (tmp_path / folder).mkdir()
    implementation = tmp_path / "rdm_drift" / "model.py"
    implementation.write_text("x = 1\n")
    first = source_fingerprint(tmp_path)
    (tmp_path / "submissions").mkdir()
    (tmp_path / "submissions" / "config.json").write_text("{}")
    (tmp_path / "hpc" / "site.env").write_text("module=site\n")
    assert source_fingerprint(tmp_path) == first
    implementation.write_text("x = 2\n")
    assert source_fingerprint(tmp_path)["sha256"] != first["sha256"]


def test_config_semantics_survive_submission_copy_formatting(tmp_path):
    config = ROOT / "configs/pilot_intrinsic.json"
    copied = tmp_path / "config.json"
    copied.write_text(json.dumps(json.loads(config.read_text()), sort_keys=True, separators=(",", ":")))
    left, right = config_fingerprint(config), config_fingerprint(copied)
    assert left["semantic_sha256"] == right["semantic_sha256"]
    assert left["sha256"] != right["sha256"]


def test_rebuild_audit_changed_after_preparation_is_stale(packed):
    data, raw, manifest = packed
    changed = copy.deepcopy(manifest["raw_rebuild"])
    changed["status"] = "failed"
    write_json(raw / "rebuild_audit.json", changed)
    with pytest.raises(ValueError, match="Current rebuild audit differs"):
        validate_dataset(data, raw)


def test_reconstruction_source_or_dependency_change_requires_rebuild(packed):
    data, raw, manifest = packed
    manifest["raw_rebuild"]["fingerprints"]["code_sha256"]["data.py"] = "0" * 64
    write_json(data / "manifest.json", manifest)
    with pytest.raises(ValueError, match="Reconstruction source changed"):
        validate_dataset(data, raw)
    manifest["raw_rebuild"]["fingerprints"]["code_sha256"]["data.py"] = file_sha256(ROOT / "rdm_drift/data.py")
    manifest["raw_rebuild"]["fingerprints"]["versions"]["rdkit"] = "stale"
    write_json(data / "manifest.json", manifest)
    with pytest.raises(ValueError, match="Reconstruction dependency changed"):
        validate_dataset(data, raw)


def test_cross_split_overlap_cannot_hide_behind_consistent_hashes(packed):
    data, raw, manifest = packed
    mutate_array(packed, "id", lambda a: a["id"].__setitem__(0, "1"), split="validation")
    meta = manifest["splits"]["validation"]
    meta["declared_ids"] = meta["retained_ids"] = ["1"]
    meta["ids_order_sha256"] = canonical_sha256(["1"])
    audit = manifest["raw_rebuild"]
    audit["declared_ids_by_split"]["validation"] = [1]
    audit["retained_ids_by_split"]["validation"] = [1]
    write_json(raw / "rebuild_audit.json", audit)
    write_json(data / "manifest.json", manifest)
    with pytest.raises(ValueError, match="Declared split ID overlap"):
        validate_dataset(data, raw)
