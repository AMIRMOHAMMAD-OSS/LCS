"""Small mathematical and inference-isolation tests; no benchmark claims."""
import copy
import numpy as np
import torch

from rdm_drift.model import EquivariantRefiner
from rdm_drift.objectives import squared_geodesic_loss
from rdm_drift.geometry import exp_map, horizontal_projection, metric_covector, log_map
from rdm_drift.train import predict_record


def test_model_rotation_translation_and_atom_permutation():
    torch.manual_seed(341)
    model = EquivariantRefiner(hidden=32, layers=2, radial=16)
    x = torch.randn(3, 6, 3)
    z = torch.tensor([6, 8, 7, 1, 1, 1])
    bonds = torch.zeros(6, 6)
    bonds[0, 1] = bonds[1, 0] = 2
    q, _ = torch.linalg.qr(torch.randn(3, 3))
    offset = torch.randn(1, 1, 3)
    perm = torch.tensor([2, 5, 1, 4, 0, 3])
    expected = model(x, z, .03, bonds)[:, perm] @ q + offset
    actual = model(x[:, perm] @ q + offset, z[perm], .03, bonds[perm][:, perm])
    torch.testing.assert_close(actual, expected, atol=2e-6, rtol=2e-6)


def test_intrinsic_loss_gradient_batch_normalization_and_scalar():
    x = torch.tensor([[0.,0.,0.],[1.2,0.,0.],[.1,1.1,0.],[.2,.1,1.3]], dtype=torch.float64)
    x -= x.mean(0)
    x = x[None].repeat(2, 1, 1)
    radii = torch.full((4,), .76, dtype=torch.float64)
    torch.manual_seed(33)
    v = horizontal_projection(x, torch.randn_like(x) * .003, radii)
    target = exp_map(x, v, radii, n_steps=8, atol=1e-8, rtol=1e-6)
    assert bool(target["valid"].all())
    options = dict(n_steps=8, max_n_steps=8, max_iter=8, tolerance=1e-7, fd_eps=1e-5, damping=1e-5)
    variable = x.clone().requires_grad_(True)
    loss, diagnostics = squared_geodesic_loss(variable, target["point"], radii, options)
    loss.backward()
    solved = log_map(x, target["point"], radii, **{k:v for k,v in options.items() if k != "max_n_steps"})
    expected = -2 * metric_covector(x, solved["log"], radii) / len(x)
    torch.testing.assert_close(variable.grad, expected, atol=1e-11, rtol=1e-8)
    torch.testing.assert_close(loss, solved["distance"].square().mean(), atol=1e-15, rtol=1e-10)
    assert diagnostics["accepted"] == 2


def test_prediction_is_independent_of_clean_reference():
    torch.manual_seed(37)
    model = EquivariantRefiner(hidden=32, layers=2, radial=16).eval()
    record = dict(id="isolation", Z=np.array([6,8,1,1,1]), radii=np.ones(5),
                  positions=np.random.default_rng(1).normal(size=(5,3)),
                  initial_positions=np.random.default_rng(2).normal(size=(5,3)))
    expected = predict_record(model, record, torch.device("cpu"), .03)
    poisoned = copy.deepcopy(record)
    poisoned["positions"] = np.full((5,3), np.nan)
    actual = predict_record(model, poisoned, torch.device("cpu"), .03)
    torch.testing.assert_close(actual, expected, atol=0, rtol=0)
