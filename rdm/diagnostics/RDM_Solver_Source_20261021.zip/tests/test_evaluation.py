"""Metric oracles, failure denominators and quantum provenance (no fake DFT)."""
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from rdm_drift.evaluate import (evaluate, kabsch_rmsd, load_predictions,
                                save_predictions, structure_metrics, symmetry_permutations)
from rdm_drift.quantum import collect, gaussian_text, parse_gaussian_log, prepare


def records():
    xyz = np.array([[0., 0., 0.], [.96, 0., 0.], [-.24, .93, 0.]])
    return [{"id": str(i), "Z": np.array([8, 1, 1]), "positions": xyz,
             "initial_positions": xyz + np.array([[0., 0., 0.], [.04, .01, 0.], [0., 0., 0.]]),
             "radii": np.array([.66, .31, .31]), "smarts": "[O:1]([H:2])[H:3]",
             "paper_eligible": i == 0, "exclusion_reason": "" if i == 0 else "test exclusion"} for i in range(2)]


class EvaluationTests(unittest.TestCase):
    def test_proper_alignment_and_reflection(self):
        x = np.array([[0., 0., 0.], [1., 0., 0.], [0., 2., 0.], [0., 0., 3.]])
        rotation = np.array([[0., -1., 0.], [1., 0., 0.], [0., 0., 1.]])
        self.assertLess(kabsch_rmsd(x @ rotation + 5, x), 1e-12)
        self.assertGreater(kabsch_rmsd(x * [-1, 1, 1], x), .1)

    def test_metric_distance_oracle(self):
        r = records()[0]
        x, y = r["initial_positions"], r["positions"]
        expected = np.mean([abs(np.linalg.norm(x[i] - x[j]) - np.linalg.norm(y[i] - y[j]))
                            for i, j in [(0, 1), (0, 2), (1, 2)]])
        got = structure_metrics(x, y, r["Z"], r["radii"])
        self.assertAlmostEqual(expected, got["d_mae_A"], places=14)

    def test_paper_symmetry_maps(self):
        r = records()[0]
        perms, info = symmetry_permutations(r, "paper")
        self.assertIn((0, 2, 1), perms)
        self.assertFalse(info["cap_hit"])
        pred = r["positions"][[0, 2, 1]]
        self.assertLess(min(kabsch_rmsd(pred[list(p)], r["positions"]) for p in perms), 1e-12)
        r["smarts"] = "[H:3][O:1][H:2]"
        self.assertEqual(perms, symmetry_permutations(r, "paper")[0])

    def test_npz_roundtrip_and_atom_identity(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "pred.npz"
            recs = records()
            save_predictions(recs, [recs[0]["positions"], None], path)
            got = load_predictions(path, recs)
            self.assertTrue(got["0"]["valid"])
            self.assertFalse(got["1"]["valid"])
            recs[0]["Z"] = np.array([6, 1, 1])
            with self.assertRaisesRegex(ValueError, "atomic numbers"):
                load_predictions(path, recs)

    def test_failure_denominator_and_cohort(self):
        recs = records()
        preds = {"model": {"0": {"positions": recs[0]["positions"], "valid": True}}}
        with tempfile.TemporaryDirectory() as td:
            report = evaluate(recs, preds, td, n_bootstrap=10, symmetry="paper")
            self.assertEqual(report["methods"]["model"]["n_failed"], 1)
            self.assertEqual(report["methods"]["model"]["failure_fraction"], .5)
            self.assertEqual(len((Path(td) / "per_molecule.csv").read_text().splitlines()), 3)
            report = evaluate(recs, preds, td, n_bootstrap=0, symmetry="paper", cohort="paper")
            self.assertEqual(report["n_raw_split"], 2)
            self.assertEqual(report["n_requested"], 1)
            self.assertEqual(report["methods"]["model"]["n_failed"], 0)
            self.assertEqual(report["methods"]["model"]["all_released_test_records"]["n_failed"], 1)

    def test_gaussian_parser_rejects_failed_scf(self):
        text = "SCF Done:  E(RB3LYP) =  -76.23456789 A.U. after 12 cycles\nNormal termination of Gaussian"
        got = parse_gaussian_log(text)
        self.assertTrue(got["converged"])
        self.assertAlmostEqual(got["energy_hartree"], -76.23456789)
        self.assertFalse(parse_gaussian_log(text.replace("Normal termination of Gaussian", "Error termination"))["converged"])
        self.assertFalse(parse_gaussian_log(text, optimization=True)["converged"])

    def test_quantum_plan_and_absent_jobs(self):
        recs = records()
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            np.savez(root / "dataset.npz", id=np.array(["0", "1"]), Z=np.array([r["Z"] for r in recs]),
                     n_atoms=np.array([3, 3]), positions=np.array([r["positions"] for r in recs]),
                     initial_positions=np.array([r["initial_positions"] for r in recs]),
                     radii=np.array([r["radii"] for r in recs]))
            save_predictions(recs, [recs[0]["positions"], None], root / "pred.npz")
            plan = prepare(root / "dataset.npz", "test", {"drift": root / "pred.npz"}, root / "qc", gaussian=True)
            self.assertEqual(plan["n_jobs"], 6)
            self.assertEqual(plan["n_ready"], 5)
            result = collect(root / "qc/jobs.jsonl", root / "absent", root / "report", bootstrap=0)
            self.assertEqual(result["methods"]["drift"]["n_requested"], 2)
            self.assertEqual(result["methods"]["drift"]["n_failed"], 2)
            self.assertEqual(result["methods"]["drift"]["chemical_accuracy_fraction_all_requested"], 0.)
            job = json.loads((root / "qc/jobs.jsonl").read_text().splitlines()[0])
            self.assertIn("scf(maxcycle=200,verytight)", gaussian_text(job))
            self.assertNotIn("opt(", gaussian_text(job))


if __name__ == "__main__":
    unittest.main()
