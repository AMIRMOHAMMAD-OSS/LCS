#!/usr/bin/env bash
# Source this script with SITE_ENV as its first argument; it never installs packages.
set -euo pipefail
rdm_env_file="${1:?Usage: source hpc/load_env.sh /absolute/path/site.env}"
[[ -f "$rdm_env_file" ]] || { echo "Missing environment file: $rdm_env_file" >&2; return 2 2>/dev/null || exit 2; }
# shellcheck source=/dev/null
source "$rdm_env_file"
if ! type module >/dev/null 2>&1; then
  for rdm_modules_init in /etc/profile.d/modules.sh /usr/share/lmod/lmod/init/bash; do
    if [[ -f "$rdm_modules_init" ]]; then
      # shellcheck source=/dev/null
      source "$rdm_modules_init"
      break
    fi
  done
fi
type module >/dev/null 2>&1 || { echo 'Environment Modules is unavailable; run on Jean Zay.' >&2; return 2 2>/dev/null || exit 2; }
if [[ "${RDM_JOB_KIND:-gpu}" == cpu ]]; then
  rdm_arch="${RDM_CPU_ARCH_MODULE-}"
  rdm_torch="${RDM_CPU_TORCH_MODULE:-}"
  RDM_VENV="${RDM_CPU_VENV:-}"
else
  rdm_arch="${RDM_ARCH_MODULE:-arch/a100}"
  rdm_torch="${RDM_TORCH_MODULE:-}"
fi
[[ -n "$rdm_torch" && "$rdm_torch" != SET_* ]] || { echo 'Set the selected GPU/CPU RDM_TORCH_MODULE to an exact module shown by module avail.' >&2; return 2 2>/dev/null || exit 2; }
[[ -n "${RDM_VENV:-}" && "$RDM_VENV" == /* ]] || { echo 'RDM_VENV must be an absolute path.' >&2; return 2 2>/dev/null || exit 2; }
module purge
[[ -z "$rdm_arch" ]] || module load "$rdm_arch"
module load "$rdm_torch"
if [[ -n "${RDM_EXTRA_MODULES:-}" ]]; then
  read -r -a rdm_extra_modules <<< "$RDM_EXTRA_MODULES"
  module load "${rdm_extra_modules[@]}"
fi
export RDM_VENV
if [[ "${RDM_SETUP_ONLY:-0}" != 1 ]]; then
  [[ -f "$RDM_VENV/bin/activate" ]] || { echo "Run setup_env.sh first: $RDM_VENV is absent." >&2; return 2 2>/dev/null || exit 2; }
  # shellcheck source=/dev/null
  source "$RDM_VENV/bin/activate"
fi
export PYTHONUNBUFFERED=1
export PYTHONNOUSERSITE=1
export WANDB_MODE=offline
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1

