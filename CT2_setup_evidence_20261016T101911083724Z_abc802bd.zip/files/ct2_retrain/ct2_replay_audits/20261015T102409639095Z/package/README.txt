CT2 replay diagnostic — 15 October 2026

Purpose

Locate the first observed difference between continuous and resumed stage-1
smoke training. The supplied results first show different scalar gradient norms
at update 21. Updates 17–20 having equal norms does not establish equality of
every gradient or parameter. History through update 16 was loaded into the
resumed checkpoint and is not an independent replay of those updates.

The observed failure is the model-state comparison in checks.py. Matching
counters and configuration do not establish equal optimizer trajectories.
This package diagnoses that failure; it does not change training tolerances,
learning rates, source files, or production checkpoint contents.

Experiment

 A: start from verified fullmask512 step_040000; run 32 stage-1 updates.
 B: fresh process; load A step_040016; run updates 17–32.
 C: fresh process; repeat A from the same verified production checkpoint.

A and C both save at update 16. All branches save at update 32. Each process
uses the original engine.optimizer_update, 8 ranks on 2 H100 nodes, length
1024, microbatch 96, accumulation 2, and the sealed execution settings.
The original per-update stop-flag reduction and post-save audit gather remain.
A/C retain the original stage-entry evaluation; B skips it, as in production.
Final evaluation is omitted because the target is the update trajectory.

The job requests at most 30 minutes and performs 80 discarded optimizer
updates total. It writes five checkpoint files, plus hard-link last.ckpt aliases,
inside the audit directory. Allow approximately 10 GB of free storage, subject
to actual checkpoint sizes. These checkpoints must not initialize production.

Read-only production inputs

 /lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2/ct2_production_20260930_v4
 /lustre/fswork/projects/rech/nef/unh87ms/ct2_retrain/ct2_production_20260930_v4/training/fullmask512/step_040000.ckpt

Training and diagnostic outputs go to the package's submission records and a fresh:

 /lustre/fswork/projects/rech/nef/unh87ms/ct2_retrain/ct2_replay_audits/<UTC timestamp>/

Preparation copies all 71 sealed source files, preserving run.json. The one
known logging-only checks.py edit is removed ONLY in the snapshot copy, and
the result must reproduce the original sealed SHA-256 exactly. Other source
changes are rejected. Production files remain untouched. Runtime verification
checks pinned dependencies, shard names/sizes/mtimes, mapping, source receipts,
and the stage-0 checkpoint hash/header before replay.

Launch after transferring this ZIP to Jean Zay

 cd /lustre/fswork/projects/rech/nef/unh87ms
 unzip -n CT2_ReplayAudit_20261015.zip
 cd CT2_ReplayAudit_20261015
 bash submit.sh

This prepares and submits one Slurm job. Repeating the command refuses a
duplicate submission. Do not use --new for an unresolved submission. For an
intentional new audit after the previous job is inactive: bash submit.sh --new

To prepare and inspect the snapshot without submitting: python3 prepare.py
To see the job status, report and output path: bash status.sh

What is recorded

All ranks: exact byte hashes, shapes and dtypes of every actual CPU batch tensor
on each executed update. From update 17: full output-logit hashes per microbatch,
selected gradients before/after original clipping, selected weights and AdamW
state after each update. Update 16 and load boundaries record state snapshots.
Rank 0 records full token/species embeddings and QKV weights in layers 0,10,21;
other ranks record the full token embedding. These are complete tensors for
the selected parameters, not samples. RNG and stream state have canonical
hashes. Raw sequences and full tensors are not written into traces.

The report compares A16 with the newly loaded B16, A with C, and A with B.
Final checkpoint comparison covers ALL model weights, optimizer state and
rank state. Floating weights/moments use the existing rtol=1e-5, atol=2e-6;
rank state and consumed-count totals must match exactly. Nonfinite values fail
health checks. DDP metadata is retained for inspection but its timing and
process-local counters do not classify numerical mismatches.

Interpretation

 A/C differ: the experiment shows variability beyond the restart comparison.
 A/C match and B differs: investigate restart-specific execution/state.
 Inputs differ first: inspect stream replay and collation at that rank/update.
 Logits differ first: inspect the forward/model/runtime path.
 Selected gradients differ first: inspect backward/reduction and earlier
 unobserved state; this is a clue, not proof of one mechanism.
 Selected post-step state differs first: inspect optimizer inputs/update and
 unobserved gradients; selected equality alone does not isolate the cause.

Hash differences are exact-bit observations, distinct from tolerance failures.
CPU hashing adds synchronization and can change whether a failure appears.
Passing this instrumented experiment does not establish that the original
preflight passes. The original sealed production gate remains necessary.
Missing traces/checkpoints or an interrupted experiment are inconclusive.

Results

 report.txt       short interpretation and first observed differences
 report.json      detailed comparisons, coverage and limits
 inspection.zip   reports, rank traces and bounded logs/metadata

The result ZIP excludes checkpoint weights, source snapshots and evaluation
sequences. Upload inspection.zip here for review. If the job fails, its exit
handler attempts to package partial results; hard termination can prevent this.
bash status.sh prints the exact path. Do not transfer the multi-GB checkpoints.

Validation performed before delivery

Python syntax, shell syntax and 11 standard-library regression checks passed:
copy isolation/seals, unexpected source mutation rejection, path rejection,
output overwrite refusal, incomplete trace handling, mismatch localization,
DDP timing exclusion and bounded result packaging. Two PyTorch CPU tests were
skipped locally because PyTorch is unavailable here; job.sh runs them in the
Jean Zay module before the replay. GPU/Slurm execution has not been tested here.

To run local regression checks: python3 -B selftest.py
Transfer commands are in TRANSFER_AND_RUN.txt.
