CT2 fixed-bucket candidate replay — 15 October 2026

Purpose

Test the specific DDP restart difference measured in replay job 1113328.
This is a candidate repair experiment, not an installed production repair.
Read FINDINGS.txt for the measured evidence and its limits.

Only the isolated replay driver's DistributedDataParallel options change:
  find_unused_parameters=True
  static_graph=False
  broadcast_buffers=False (unchanged)

The unused-parameter detection flag is deliberately used to prevent dynamic
bucket rebuilding in PyTorch 2.6. It can add graph-traversal overhead. A warning
that no unused parameters were found is expected for this model; it is not a
failed replay comparison.

Experiment and resources

  A: fresh process, verified production step 040000 ->32 stage 1 updates.
  B: fresh process, resume NEW A16 ->32.
  C: fresh process, independently repeat NEW A ->32.

All three branches use the candidate policy. Do not resume the old A16 under
the new policy or compare candidate checkpoints against old-run weights as if
the two executions were required to be bit-identical.

The job requests8 H100 GPUs on2 nodes for at most30 minutes. It performs80 discarded
optimizer updates and writes five checkpoints; allow approximately 10 GB free.
The earlier original-policy replay took about 7 minutes. Candidate duration and
performance have not been measured. No production training is submitted.

Production inputs are read-only. All 71 sealed source files are copied and
verified. The known checks.py logging edit is normalized ONLY inside the copy
and must reproduce the original sealed hash. run.json is never resealed.

Outputs go to a fresh timestamped directory under:
  /lustre/fswork/projects/rech/nef/unh87ms/ct2_retrain/ct2_replay_fixed_buckets

This is separate from the previous ct2_replay_audits run. Both are retained.

Run on Jean Zay after transferring the ZIP

  cd /lustre/fswork/projects/rech/nef/unh87ms
  unzip -n CT2_ReplayFixedBuckets_20261015.zip
  cd CT2_ReplayFixedBuckets_20261015
  bash submit.sh

Check the same submission:
  bash status.sh

Duplicate submission is refused. Do not use --new for an unresolved attempt.
Only an intentional retry after the prior attempt is inactive uses --new.
Read-only preparation without submission: python3 prepare.py

Validation and interpretation

The same all-rank batch/logit hashes and selected numerical tracing are kept.
Each rank's header and every update record the actual DDP boolean properties.
Missing, mistyped or wrong flags, any rebuilding, or inconsistent bucket-size
observations prevent a successful candidate conclusion. The expected number
of buckets is measured, not hardcoded to the previous 17-bucket layout.

Full endpoint model and optimizer comparisons keep rtol 1e-5, atol 2e-6.
Rank stream/RNG state and count totals must match exactly. Exact bit equality
is reported separately from tolerance agreement. NaNs/infinities fail health
checks. A/C is still an independent reproducibility control.

The driver continues to call the sealed engine.optimizer_update. It does not
change LR, clipping, loss scaling, masks, input order, model parameters, or AdamW.
The original-policy job passed all 13 packaged self-tests on Jean Zay,
including the 2 Torch tests unavailable in this local environment. New local
validation is recorded in VALIDATION.json. The candidate itself has not run
on a GPU at delivery; its job runs all tests before the experiment.

Results
  report.txt / report.json    Candidate-policy and numerical comparisons
  inspection.zip             Reports, rank traces and bounded logs/metadata

Upload the new inspection.zip for review, even if the job reports COMPLETED.
That scheduler status means execution finished, not that equality passed.
The result ZIP excludes checkpoint weights, evaluation sequences and source
snapshots. Keep the large candidate checkpoints on Jean Zay for diagnosis;
never use them to initialize production training.

No original preflight receipt or production approval is written by this test.
If the candidate succeeds, the next step is a reviewed production revision
with explicit provenance followed by the production preflight. If it fails,
use its traces to choose the next discriminating test; do not relax tolerances.

Transfer commands are in TRANSFER_AND_RUN.txt.
