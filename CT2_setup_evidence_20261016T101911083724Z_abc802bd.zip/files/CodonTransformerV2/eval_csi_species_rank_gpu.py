import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from tqdm import tqdm


GENETIC_CODE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

SENSE_CODONS = sorted([c for c, aa in GENETIC_CODE.items() if aa != "*"])
CODON_TO_COL = {c: i for i, c in enumerate(SENSE_CODONS)}

DNA_COL_CANDIDATES = [
    "pred_dna", "predicted_dna", "generated_dna", "optimized_dna",
    "prediction", "pred_sequence", "generated_sequence", "output_sequence",
    "dna", "dna_sequence", "nt_sequence", "sequence",
]
SPECIES_COL_CANDIDATES = ["species", "organism", "organism_name", "species_name"]
MODEL_COL_CANDIDATES = ["model", "model_name", "checkpoint"]


def pick_col(df, candidates, required=True, label="column"):
    for c in candidates:
        if c in df.columns:
            return c
    if required:
        raise SystemExit(
            f"Could not find {label}. Candidates={candidates}\n"
            f"Available columns={df.columns.tolist()}"
        )
    return None


def normalize_dna(seq):
    if seq is None or pd.isna(seq):
        return ""
    return str(seq).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def codon_count_vector(seq):
    seq = normalize_dna(seq)
    x = np.zeros(len(SENSE_CODONS), dtype=np.float32)
    n = len(seq) // 3
    valid = 0

    for i in range(n):
        codon = seq[3*i:3*i+3]
        j = CODON_TO_COL.get(codon)
        if j is None:
            continue
        x[j] += 1.0
        valid += 1

    return x, valid


def build_species_logfreq_matrix(freq_df, rare_mode, eps):
    species_list = sorted(freq_df["species"].dropna().unique().tolist())
    species_to_idx = {s: i for i, s in enumerate(species_list)}

    mat = np.full(
        (len(species_list), len(SENSE_CODONS)),
        np.log(eps),
        dtype=np.float32,
    )

    use = freq_df
    if rare_mode == "no_rare_0_001":
        use = use[~use["rare_lt_0_001"]]
    elif rare_mode == "no_rare_0_01":
        use = use[~use["rare_lt_0_01"]]

    for r in tqdm(use.itertuples(index=False), total=len(use), desc=f"building matrix {rare_mode}"):
        j = CODON_TO_COL.get(r.codon)
        if j is None:
            continue
        i = species_to_idx.get(r.species)
        if i is None:
            continue
        mat[i, j] = np.log(max(float(r.frequency), eps))

    return species_list, species_to_idx, mat


def summarize(df):
    return (
        df.groupby(["rare_mode", "model"], as_index=False)
        .agg(
            n=("row_id", "count"),
            species_in_table_rate=("species_in_table", "mean"),
            mean_codons_scored=("n_codons_scored", "mean"),
            mean_true_rank=("true_species_rank", "mean"),
            median_true_rank=("true_species_rank", "median"),
            top1_rate=("top1", "mean"),
            top5_rate=("top5", "mean"),
            top10_rate=("top10", "mean"),
            top100_rate=("top100", "mean"),
            mean_reciprocal_rank=("reciprocal_rank", "mean"),
            mean_true_score=("true_species_score", "mean"),
            mean_best_score=("best_species_score", "mean"),
            mean_score_gap_true_minus_best=("score_gap_true_minus_best", "mean"),
        )
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--out_prefix", default="csi_species_rank")
    ap.add_argument("--batch_size", type=int, default=512)
    ap.add_argument("--eps", type=float, default=1e-9)
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--device", default="cuda")
    args = ap.parse_args()

    pred = pd.read_csv(args.predictions)
    if args.limit:
        pred = pred.head(args.limit).copy()

    species_col = pick_col(pred, SPECIES_COL_CANDIDATES, label="species column")
    model_col = pick_col(pred, MODEL_COL_CANDIDATES, required=False, label="model column")
    dna_col = pick_col(pred, DNA_COL_CANDIDATES, label="DNA/generated sequence column")

    if model_col is None:
        pred["model"] = "unknown_model"
        model_col = "model"

    print("prediction rows:", len(pred))
    print("species_col:", species_col)
    print("model_col:", model_col)
    print("dna_col:", dna_col)
    print("sense codons:", len(SENSE_CODONS))

    freq_df = pd.read_parquet(args.codon_table)
    print("codon table rows:", len(freq_df))
    print("codon table species:", freq_df["species"].nunique())

    device = args.device
    if device == "cuda" and not torch.cuda.is_available():
        device = "cpu"
    print("device:", device)

    all_outputs = []

    for rare_mode in ["all", "no_rare_0_001", "no_rare_0_01"]:
        print()
        print("=" * 80)
        print("RARE MODE:", rare_mode)
        print("=" * 80)

        species_list, species_to_idx, logfreq_np = build_species_logfreq_matrix(
            freq_df, rare_mode, args.eps
        )

        logfreq = torch.tensor(logfreq_np.T, dtype=torch.float32, device=device)
        # shape: 61 x n_species

        rows = []

        for start in tqdm(range(0, len(pred), args.batch_size), desc=f"ranking {rare_mode}"):
            end = min(start + args.batch_size, len(pred))
            chunk = pred.iloc[start:end]

            X = np.zeros((len(chunk), len(SENSE_CODONS)), dtype=np.float32)
            n_valid = np.zeros(len(chunk), dtype=np.float32)
            true_indices = np.full(len(chunk), -1, dtype=np.int64)

            for bi, (_, r) in enumerate(chunk.iterrows()):
                x, valid = codon_count_vector(r[dna_col])
                X[bi] = x
                n_valid[bi] = max(valid, 1)
                true_indices[bi] = species_to_idx.get(str(r[species_col]), -1)

            Xt = torch.tensor(X, dtype=torch.float32, device=device)
            denom = torch.tensor(n_valid, dtype=torch.float32, device=device)[:, None]

            # score = mean log frequency across generated codons
            scores = (Xt @ logfreq) / denom
            # shape: batch x n_species

            best_scores, best_idx = torch.max(scores, dim=1)
            top10_scores, top10_idx = torch.topk(scores, k=10, dim=1)

            scores_cpu = scores.detach().cpu()
            best_scores_cpu = best_scores.detach().cpu().numpy()
            best_idx_cpu = best_idx.detach().cpu().numpy()
            top10_idx_cpu = top10_idx.detach().cpu().numpy()

            for bi, (orig_idx, r) in enumerate(chunk.iterrows()):
                ti = int(true_indices[bi])
                species_in_table = ti >= 0

                if species_in_table:
                    true_score = float(scores_cpu[bi, ti].item())
                    rank = int((scores_cpu[bi] > true_score).sum().item()) + 1
                else:
                    true_score = np.nan
                    rank = np.nan

                best_species = species_list[int(best_idx_cpu[bi])]
                top10_species = [species_list[int(j)] for j in top10_idx_cpu[bi]]

                rows.append({
                    "rare_mode": rare_mode,
                    "row_id": int(orig_idx),
                    "model": str(r[model_col]),
                    "species": str(r[species_col]),
                    "species_in_table": species_in_table,
                    "n_codons_scored": int(n_valid[bi]),
                    "true_species_score": true_score,
                    "best_species": best_species,
                    "best_species_score": float(best_scores_cpu[bi]),
                    "true_species_rank": rank,
                    "top1": int(rank == 1) if species_in_table else 0,
                    "top5": int(rank <= 5) if species_in_table else 0,
                    "top10": int(rank <= 10) if species_in_table else 0,
                    "top100": int(rank <= 100) if species_in_table else 0,
                    "reciprocal_rank": float(1.0 / rank) if species_in_table and rank > 0 else np.nan,
                    "score_gap_true_minus_best": true_score - float(best_scores_cpu[bi]) if species_in_table else np.nan,
                    "top10_species": ";".join(top10_species),
                })

            del Xt, scores, scores_cpu

        mode_df = pd.DataFrame(rows)
        partial = f"{args.out_prefix}_{rare_mode}_by_sequence.csv"
        mode_df.to_csv(partial, index=False)
        print("wrote:", partial)

        all_outputs.append(mode_df)

        del logfreq

    by_seq = pd.concat(all_outputs, ignore_index=True)
    out_seq = f"{args.out_prefix}_by_sequence.csv"
    by_seq.to_csv(out_seq, index=False)

    summary_model = summarize(by_seq)
    out_model = f"{args.out_prefix}_summary_by_model.csv"
    summary_model.to_csv(out_model, index=False)

    summary_bucket = (
        by_seq.merge(
            pred[["model", "species", "bucket"]].reset_index().rename(columns={"index": "row_id"}),
            on=["row_id", "model", "species"],
            how="left",
        )
        .groupby(["rare_mode", "model", "bucket"], as_index=False)
        .agg(
            n=("row_id", "count"),
            mean_true_rank=("true_species_rank", "mean"),
            median_true_rank=("true_species_rank", "median"),
            top1_rate=("top1", "mean"),
            top5_rate=("top5", "mean"),
            top10_rate=("top10", "mean"),
            top100_rate=("top100", "mean"),
            mean_reciprocal_rank=("reciprocal_rank", "mean"),
        )
    )
    out_bucket = f"{args.out_prefix}_summary_by_bucket.csv"
    summary_bucket.to_csv(out_bucket, index=False)

    print()
    print("=== SUMMARY BY MODEL ===")
    print(summary_model.to_string(index=False))

    print()
    print("WROTE")
    print(out_seq)
    print(out_model)
    print(out_bucket)


if __name__ == "__main__":
    main()
