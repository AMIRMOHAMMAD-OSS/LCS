"""Reviewed 80/10/5/5 MLM recipe; independent stateless full-mask/species draws."""
from __future__ import annotations
import torch
from common import stable_seed
from phase1_tokens import STANDARD_CODE, codon_token, validate_vocabulary

class TrainingCollator:
    def __init__(self,tokenizer,n_real,seed=123,rank=0):
        self.tokenizer,self.n_real,self.seed,self.rank=tokenizer,n_real,seed,rank
        self.vocab=tokenizer.get_vocab(); validate_vocabulary(self.vocab)
        self.mask=torch.arange(len(self.vocab)); self.eligible=torch.zeros(len(self.vocab),dtype=torch.bool)
        self.synonyms={}
        for codon,aa in STANDARD_CODE.items():
            index=self.vocab[codon_token(codon)]
            self.eligible[index]=True
            self.mask[index]=self.vocab['__unk' if aa=='*' else f'{aa.lower()}_unk']
            self.synonyms[index]=[self.vocab[codon_token(c)] for c,a in STANDARD_CODE.items() if a==aa]

    def __call__(self,records,length,full_probability,update,microbatch):
        if not records or not 0<=full_probability<=1: raise ValueError('Invalid collation request')
        rows=[[self.tokenizer.cls_token_id]+[self.vocab[t] for t in r['prepared'].text.split()][:length-2]
              +[self.tokenizer.sep_token_id] for r in records]
        width=max(map(len,rows)); original=torch.full((len(rows),width),self.tokenizer.pad_token_id,dtype=torch.long)
        attention=torch.zeros_like(original)
        for i,row in enumerate(rows): original[i,:len(row)]=torch.tensor(row); attention[i,:len(row)]=1
        eligible=self.eligible[original]&attention.bool()
        stream=f'{self.seed}:{self.rank}:{update}:{microbatch}'
        gen=torch.Generator().manual_seed(stable_seed('mlm:'+stream))
        selected=(torch.rand(original.shape,generator=gen)<.15)&eligible
        for i in range(len(rows)):
            if not selected[i].any():
                indices=eligible[i].nonzero().flatten()
                if not len(indices): raise ValueError('No supervised codons in accepted record')
                selected[i,indices[torch.randint(len(indices),(1,),generator=gen)]]=True
        replaced=(torch.rand(original.shape,generator=gen)<.8)&selected
        generic=(torch.rand(original.shape,generator=gen)<.5)&selected&~replaced
        synonymous=(torch.rand(original.shape,generator=gen)<.5)&selected&~replaced&~generic
        inputs=original.clone(); inputs[replaced]=self.mask[original[replaced]]
        inputs[generic]=self.tokenizer.mask_token_id
        for b,p in synonymous.nonzero().tolist():
            choices=self.synonyms[int(original[b,p])]
            inputs[b,p]=choices[int(torch.randint(len(choices),(1,),generator=gen))]
        # These draws never consume the MLM or species RNG stream.
        gen=torch.Generator().manual_seed(stable_seed('full:'+stream))
        full=torch.rand((len(rows),),generator=gen)<full_probability
        full_positions=full[:,None]&eligible
        inputs[full_positions]=self.mask[original[full_positions]]
        selected|=full_positions
        truth=torch.tensor([r['species_id'] for r in records],dtype=torch.long)
        gen=torch.Generator().manual_seed(stable_seed('species:'+stream))
        unknown=torch.rand(truth.shape,generator=gen)<.12
        return dict(input_ids=inputs,attention_mask=attention,labels=torch.where(selected,original,-100),
                    species_id=torch.where(unknown,self.n_real,truth),full=full,unknown=unknown)
