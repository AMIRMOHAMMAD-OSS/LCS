#!/usr/bin/env python3
"""Real-checkpoint baselines and worst-length memory/augmentation probes on eight H100s."""
from __future__ import annotations
import argparse
import gc
import json
from pathlib import Path
import torch
from torch.nn.parallel import DistributedDataParallel
from common import load_run, STAGES, atomic_json, batch_profile
from model_io import initial_checkpoint, tokenizer_at, build_model, optimizer_for
from engine import initialize, rank, barrier, seed_all, optimizer_update, gather
from evaluation import Evaluator
from augmentation import TrainingCollator
from phase1_tokens import STANDARD_CODE, prepare_sequence
from train import input_checkpoint
from execution import assert_profile

def run(stage,output):
    cfg=load_run();device=initialize();seed_all(cfg['seed']);tok=tokenizer_at();evaluator=Evaluator(cfg,tok)
    if stage==0:
        for name in ('epoch_6','epoch_9'):
            checkpoint=initial_checkpoint(cfg,name)
            model=build_model(checkpoint,tok,cfg,device,name)
            # Validate the saved optimizer even for the comparison checkpoint.
            opt,_=optimizer_for(model,checkpoint);del opt,checkpoint
            evaluator.evaluate(model,output/'baselines'/name,0,name,reference=name,long_panels=name==cfg['initialization'])
            del model;gc.collect();torch.cuda.empty_cache();barrier()
    checkpoint,historical=input_checkpoint(cfg,stage)
    model=build_model(checkpoint,tok,cfg,device,historical);optimizer,_=optimizer_for(model,checkpoint);del checkpoint
    model=DistributedDataParallel(model,device_ids=[device.index],broadcast_buffers=False)
    collator=TrainingCollator(tok,26678,cfg['seed'],rank());length=STAGES[stage]['lengths'][1]
    micro,accumulate=batch_profile(length,cfg['batch_divisor'])
    motif='ACDEFGHIKLMNPQRSTVWY'
    protein='M'+(motif*((length+len(motif))//len(motif)))[:length-4]
    codons={aa:next(c for c,a in STANDARD_CODE.items() if a==aa) for aa in set(protein)}
    prepared=prepare_sequence(''.join(codons[aa] for aa in protein)+'TAA',protein,tok.get_vocab())
    rows=[{'prepared':prepared,'species_id':(rank()*micro+i)%26678} for i in range(micro)]
    torch.cuda.reset_peak_memory_stats();probes=[]
    for j,probability in enumerate((STAGES[stage]['full'][1],1.)):
        batches=[collator(rows,length,probability,j,i) for i in range(accumulate)]
        if any(b['input_ids'].shape[1]!=length for b in batches):raise ValueError('Memory probe did not fill the requested context')
        metrics,norm=optimizer_update(model,optimizer,batches,device,STAGES[stage]['lr'][0])
        assert_profile(model.module)
        probes.append({'length':length,'probability':probability,'gradient':norm,'global_metrics':metrics})
        del batches
    memory=gather({'rank':rank(),'peak_allocated_bytes':torch.cuda.max_memory_allocated(),
                   'peak_reserved_bytes':torch.cuda.max_memory_reserved(),'gpu':torch.cuda.get_device_name(),
                   'execution_settings':assert_profile(model.module)})
    if rank()==0:
        atomic_json(output/'hardware_checks.json',{'fingerprint':cfg['fingerprint'],'stage':stage,'memory':memory,
            'probes':probes,'baseline_comparison':stage==0,'discarded_probe_updates':2})
        print('CT2_HARDWARE_CHECKS_PASSED',stage,flush=True)
    barrier()

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--stage',type=int,required=True,choices=range(len(STAGES)))
    p.add_argument('--output',type=Path,required=True);a=p.parse_args();run(a.stage,a.output)
