"""Reviewed synonymous metrics and paired species bootstrap from the supplied diagnostic."""

def synonymous_groups(vocab):
    groups = [-1] * len(vocab)
    group_ids = {}
    for token, index in vocab.items():
        if len(token) == 5 and token[1] == "_" and set(token[2:]) <= set("acgt"):
            aa = token[0]
            groups[index] = group_ids.setdefault(aa, len(group_ids))
    if sum(value >= 0 for value in groups) != 64:
        raise ValueError("Expected exactly 64 paired codon tokens")
    return groups


def row_statistics(logits, labels, groups):
    """Per-record sums over exactly supervised positions; raw and synonymous CE."""
    import torch
    import torch.nn.functional as F
    selected = labels.ne(-100)
    gold = labels[selected]
    values = logits[selected].float()
    if not gold.numel() or (groups[gold] < 0).any():
        raise ValueError("Missing or invalid codon labels")
    if not torch.isfinite(values).all():
        raise FloatingPointError("Nonfinite evaluated logits")
    allowed = groups[None, :].eq(groups[gold, None]) & groups[None, :].ge(0)
    restricted = values.masked_fill(~allowed, float("-inf"))
    row_ids = torch.arange(labels.shape[0], device=labels.device)[:, None].expand_as(labels)[selected]
    columns = (
        torch.ones_like(gold, dtype=torch.float64),
        F.cross_entropy(values, gold, reduction="none").double(),
        F.cross_entropy(restricted, gold, reduction="none").double(),
        values.argmax(-1).eq(gold).double(),
        restricted.argmax(-1).eq(gold).double(),
    )
    result = torch.zeros((labels.shape[0], 5), dtype=torch.float64, device=labels.device)
    for index, column in enumerate(columns):
        result[:, index].scatter_add_(0, row_ids, column)
    if not torch.isfinite(result).all():
        raise FloatingPointError("Nonfinite metric sums")
    return result.cpu()


def aggregate(rows):
    totals = rows.sum(0)
    count = float(totals[0])
    if count <= 0:
        raise ValueError("No supervised targets")
    return {"targets": int(count), "raw_loss": float(totals[1] / count),
            "synonymous_loss": float(totals[2] / count),
            "raw_accuracy": float(totals[3] / count),
            "synonymous_accuracy": float(totals[4] / count)}


def paired_deltas(correct, other, panel_ids, bootstrap=1000):
    """Token-weighted loss difference with a paired bootstrap over species."""
    import torch
    if not torch.equal(correct[:, 0], other[:, 0]):
        raise ValueError("Compared species conditions have different prediction targets")
    keys = sorted(set(panel_ids))
    indices = {sid: index for index, sid in enumerate(keys)}
    clustered = torch.zeros((len(keys), 3), dtype=torch.float64)
    for row, sid in enumerate(panel_ids):
        clustered[indices[sid], 0] += correct[row, 0]
        clustered[indices[sid], 1:] += other[row, 1:3] - correct[row, 1:3]
    generator = torch.Generator().manual_seed(9321)
    samples = torch.randint(len(keys), (bootstrap, len(keys)), generator=generator)
    totals = clustered[samples].sum(1)
    ratios = totals[:, 1:] / totals[:, :1]
    interval = torch.quantile(ratios, torch.tensor([.025, .975], dtype=torch.float64), dim=0)
    observed = clustered.sum(0)
    return {
        "sign": "positive means correct species has lower loss",
        "raw_delta": float(observed[1] / observed[0]),
        "synonymous_delta": float(observed[2] / observed[0]),
        "raw_95pct_species_bootstrap": interval[:, 0].tolist(),
        "synonymous_95pct_species_bootstrap": interval[:, 1].tolist(),
        "bootstrap_replicates": bootstrap,
    }


