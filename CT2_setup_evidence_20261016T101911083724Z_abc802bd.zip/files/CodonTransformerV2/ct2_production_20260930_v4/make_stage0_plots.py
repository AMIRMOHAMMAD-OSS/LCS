import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path


CSV="stage0_fullmask512_eval/full_evaluation_metrics.csv"
OUT=Path("stage0_fullmask512_eval/plots")
OUT.mkdir(exist_ok=True)

df=pd.read_csv(CSV)

# avoid pandas method collisions
modes=df["mode"].unique()


# =========================
# LOSS vs STEP
# =========================

for mode in modes:

    x=df[df["mode"]==mode]

    y=x.groupby("step")["raw_loss"].mean()

    plt.figure(figsize=(8,5))
    plt.plot(y.index,y.values)
    plt.xlabel("Step")
    plt.ylabel("Raw loss")
    plt.title(f"Raw loss - {mode}")
    plt.savefig(
        OUT/f"loss_{mode}.png",
        dpi=300,
        bbox_inches="tight"
    )
    plt.close()


# =========================
# SYNONYMOUS ACCURACY
# =========================

for mode in modes:

    x=df[df["mode"]==mode]

    y=x.groupby("step")["synonymous_accuracy"].mean()

    plt.figure(figsize=(8,5))
    plt.plot(y.index,y.values)
    plt.xlabel("Step")
    plt.ylabel("Synonymous accuracy")
    plt.title(f"Synonymous accuracy - {mode}")

    plt.savefig(
        OUT/f"synonymous_accuracy_{mode}.png",
        dpi=300,
        bbox_inches="tight"
    )
    plt.close()



# =========================
# LENGTH COMPARISON FINAL
# =========================

final=df[df["step"]==df["step"].max()]

length_table=(
    final
    .groupby(["length","mode"])
    ["synonymous_accuracy"]
    .mean()
    .reset_index()
)

for mode in modes:

    x=length_table[length_table["mode"]==mode]

    plt.figure(figsize=(6,4))
    plt.bar(
        x["length"].astype(str),
        x["synonymous_accuracy"]
    )

    plt.xlabel("Context length")
    plt.ylabel("Synonymous accuracy")
    plt.title(f"Length scaling - {mode}")

    plt.savefig(
        OUT/f"length_scaling_{mode}.png",
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()



# =========================
# SPECIES ABLATION
# =========================

final=df[df["step"]==df["step"].max()]

species=(
    final
    .groupby(["mode","condition"])
    [
        [
        "raw_accuracy",
        "synonymous_accuracy",
        "raw_loss",
        "synonymous_loss"
        ]
    ]
    .mean()
)

species.to_csv(
    OUT/"species_ablation_summary.csv"
)


for mode in modes:

    try:
        x=species.loc[mode]

    except:
        continue


    plt.figure(figsize=(8,5))

    x["synonymous_accuracy"].plot(
        kind="bar"
    )

    plt.ylabel("Synonymous accuracy")
    plt.title(f"Species ablation - {mode}")

    plt.savefig(
        OUT/f"species_ablation_{mode}.png",
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()


print("DONE")
print("plots:",OUT)
