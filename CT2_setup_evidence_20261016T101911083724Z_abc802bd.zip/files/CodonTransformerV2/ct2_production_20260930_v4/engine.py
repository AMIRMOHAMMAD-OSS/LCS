"""Distributed token-weighted updates, RNG snapshots, and atomic checkpoints."""
from __future__ import annotations
import contextlib
import os
import random
from datetime import timedelta
from pathlib import Path
import numpy as np
import torch
import torch.distributed as dist

def distributed(): return dist.is_available() and dist.is_initialized()
def rank(): return dist.get_rank() if distributed() else 0
def world(): return dist.get_world_size() if distributed() else 1
def barrier():
    if distributed(): dist.barrier()
def sum_tensor(t):
    if distributed(): dist.all_reduce(t)
    return t
def gather(value):
    values=[None]*world()
    if distributed(): dist.all_gather_object(values,value)
    else: values[0]=value
    return values

def initialize():
    from execution import configure
    configure()
    if not torch.cuda.is_available(): raise RuntimeError('Use the supplied Jean Zay GPU Slurm job')
    r=int(os.environ['SLURM_PROCID']); w=int(os.environ['SLURM_NTASKS']); local=int(os.environ['SLURM_LOCALID'])
    if w!=8: raise RuntimeError(f'Expected exactly eight ranks, got {w}')
    count=torch.cuda.device_count()
    index=0 if count==1 else local
    torch.cuda.set_device(index)
    dist.init_process_group('nccl',rank=r,world_size=w,timeout=timedelta(minutes=45))
    torch.set_num_threads(int(os.environ.get('OMP_NUM_THREADS','8')))
    device=torch.device('cuda',index)
    hosts=gather({'rank':r,'host':os.uname().nodename,'device':index,'visible':os.environ.get('CUDA_VISIBLE_DEVICES')})
    if len({(h['host'],h['device'],h['visible']) for h in hosts})!=w: raise RuntimeError('Ranks share a GPU binding')
    if rank()==0: print('CT2_RANKS',hosts,flush=True)
    return device

def seed_all(seed):
    random.seed(seed); np.random.seed(seed % (2**32)); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

def rng_state():
    return {'python':random.getstate(),'numpy':np.random.get_state(),'torch':torch.get_rng_state(),
            'cuda':torch.cuda.get_rng_state() if torch.cuda.is_available() else None}

def restore_rng(state):
    random.setstate(state['python']); np.random.set_state(state['numpy']); torch.set_rng_state(state['torch'])
    if state['cuda'] is not None: torch.cuda.set_rng_state(state['cuda'])

@contextlib.contextmanager
def isolated_rng():
    state=rng_state()
    try: yield
    finally: restore_rng(state)

def autocast(device): return torch.autocast(device.type,dtype=torch.bfloat16,enabled=device.type=='cuda')

def optimizer_update(module,optimizer,batches,device,lr,clip=.5):
    """Sum local CE, scale by world/global targets, let DDP average gradients."""
    for group in optimizer.param_groups: group['lr']=lr
    optimizer.zero_grad(set_to_none=True)
    local_count=sum(int(b['labels'].ne(-100).sum()) for b in batches)
    total=sum_tensor(torch.tensor(local_count,dtype=torch.int64,device=device))
    if total.item()<=0: raise ValueError('No targets in optimizer update')
    scale=world()/int(total)
    metric=torch.zeros(8,dtype=torch.float64,device=device)
    module.train()
    for index,cpu in enumerate(batches):
        b={k:v.to(device) for k,v in cpu.items()}
        sync=(module.no_sync() if hasattr(module,'no_sync') and index<len(batches)-1 else contextlib.nullcontext())
        with sync:
            with autocast(device): logits=module(b['input_ids'],b['attention_mask'],b['species_id'])
            losses=torch.nn.functional.cross_entropy(logits.float().reshape(-1,logits.shape[-1]),b['labels'].reshape(-1),
                                                     ignore_index=-100,reduction='none').reshape_as(b['labels'])
            loss=losses.sum()*scale
            if not torch.isfinite(loss): raise FloatingPointError('Nonfinite training loss')
            loss.backward()
        with torch.no_grad():
            for kind,rows in enumerate((~b['full'],b['full'])):
                mask=rows[:,None]&b['labels'].ne(-100)
                metric[2*kind]+=losses.detach()[mask].double().sum(); metric[2*kind+1]+=mask.sum()
            metric[4]+=b['input_ids'].shape[0]; metric[5]+=b['attention_mask'].sum()
            metric[6]+=b['full'].sum(); metric[7]+=b['unknown'].sum()
    norm=torch.nn.utils.clip_grad_norm_(module.parameters(),clip,error_if_nonfinite=True)
    optimizer.step()
    return sum_tensor(metric).cpu().tolist(),float(norm)

def atomic_torch_save(path,value):
    path=Path(path); temp=path.with_name(path.name+f'.tmp.{os.getpid()}')
    try:
        with temp.open('wb') as f: torch.save(value,f); f.flush(); os.fsync(f.fileno())
        os.replace(temp,path)
    finally: temp.unlink(missing_ok=True)

def checkpoint_save(path,model,optimizer,names,stream,cfg,stage,stage_step,total,stats,mode):
    # The caller must be at an optimizer boundary, with no prepared unconsumed batch.
    from execution import PROFILE, assert_profile
    execution=assert_profile(model)
    local={'stream':stream.state_dict(),'rng':rng_state(),'execution_settings':execution}
    states=gather(local)
    if rank()==0:
        source_step=cfg['source_step']
        checkpoint={'ct2_format':1,'fingerprint':cfg['fingerprint'],'mode':mode,'world_size':world(),
            'execution_profile':dict(PROFILE),'execution_settings':execution,
            'state_dict':model.state_dict(),'model_config':model.model.config.to_dict(),
            'species_embed_scale':model.scale,'mapping_sha256':cfg['mapping_sha256'],
            'global_step':source_step+total,'continuation_step':total,'source_step':source_step,
            'stage':stage,'stage_step':stage_step,'optimizer_states':[optimizer.state_dict()],
            'optimizer_parameter_names':names,'rank_states':states,'statistics':stats,
            'schedule':{'stage':stage,'completed':stage_step},'next_update_controls':'common.controls(stage, stage_step)',
            'hyper_parameters':{'species_embed_scale':model.scale,'unknown_species_id':26678,'n_species_total':28678}}
        atomic_torch_save(path,checkpoint)
        # last.ckpt is an atomic hard-link alias, not a second 1.5 GB copy.
        alias=Path(path).parent/'last.ckpt'; temp=alias.with_name(f'.last.{os.getpid()}')
        temp.unlink(missing_ok=True); os.link(path,temp); os.replace(temp,alias)
    barrier()
