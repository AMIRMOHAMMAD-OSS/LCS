#!/bin/bash
set -euo pipefail

CKPT=$1

OUT=${2:-stage1_eval}

mkdir -p $OUT

echo "Checkpoint:"
echo $CKPT

echo "Output:"
echo $OUT


#########################################
# 1. CHECKPOINT INFO
#########################################

python - <<PY > $OUT/checkpoint_info.txt
import torch
from model_io import read_checkpoint

cp = read_checkpoint("$CKPT")

print(cp.keys())

for k,v in cp.items():
    if isinstance(v,(int,float,str)):
        print(k,v)
PY


#########################################
# 2. TRAINING LOG EXTRACTION
#########################################

python extract_training_metrics.py \
    --logdir logs \
    --out $OUT/training_metrics.csv


#########################################
# 3. SPECIES ABLATION
#########################################

python run_species_eval.py \
    --checkpoint $CKPT \
    --output $OUT/species_ablation.json


#########################################
# 4. GENERATION BENCHMARK
#########################################

python generation.py \
    --checkpoint $CKPT \
    --output $OUT/generated_sequences.json


#########################################
# 5. CSI
#########################################

python ../eval_formal_csi_own_wrong_rare.py \
    --input $OUT/generated_sequences.json \
    --codon_table ../ct2_codon_usage_tables_qc/ct2_train_species_codon_frequencies_clean.parquet \
    --output $OUT/csi.csv


#########################################
# 6. SPECIES RANK
#########################################

python ../eval_formal_csi_species_rank_gpu.py \
    --input $OUT/generated_sequences.json \
    --codon_table ../ct2_codon_usage_tables_qc/ct2_train_species_codon_frequencies_clean.parquet \
    --output $OUT/species_rank.csv


#########################################
# 7. CAI
#########################################

python ../eval_cai_top10csi_train_reference_safe_w8.py \
    --input $OUT/generated_sequences.json \
    --codon_table ../ct2_codon_usage_tables_qc/ct2_train_species_codon_frequencies_clean.parquet \
    --output $OUT/cai.csv


#########################################
# 8. MINMAX18
#########################################

python ../eval_minmax_dtw_ct2_stages.py \
    --input $OUT/generated_sequences.json \
    --codon_table ../ct2_codon_usage_tables_qc/ct2_train_species_codon_frequencies_clean.parquet \
    --output $OUT/minmax18.csv


#########################################
# 9. FINAL SUMMARY
#########################################

python build_stage1_report.py \
    --input $OUT \
    --output $OUT/CT2_stage1_report.html


echo "DONE"
