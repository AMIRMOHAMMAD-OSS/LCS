import json
import torch

from common import load_run
from model_io import read_checkpoint, build_model, tokenizer_at
from evaluation import Evaluator


CKPT = "/lustre/fswork/projects/rech/nef/unh87ms/ct2_retrain/ct2_production_20260930_v4/training/fullmask512/last.ckpt"


import time

cfg = load_run()

tok = tokenizer_at()

device = torch.device("cuda")

print("Loading checkpoint...", flush=True)

checkpoint = read_checkpoint(CKPT)

model = build_model(
    checkpoint,
    tok,
    cfg,
    device,
    None
)

model.eval()

print("Loaded checkpoint", flush=True)
print("species scale =", model.scale, flush=True)


evaluator = Evaluator(
    cfg,
    tok
)

print("Panel rows =", len(evaluator.rows), flush=True)
print("Starting evaluation...", flush=True)

start = time.time()

result = evaluator.evaluate(
    model,
    output="species_eval",
    step=40000,
    tag="fullmask512_species_test",
    long_panels=True,
    generation=False
)

print(
    "Evaluation finished in %.2f minutes" %
    ((time.time()-start)/60),
    flush=True
)


if result is not None:
    with open("species_eval_result.json","w") as f:
        json.dump(result,f,indent=2)

    print("saved species_eval_result.json", flush=True)
