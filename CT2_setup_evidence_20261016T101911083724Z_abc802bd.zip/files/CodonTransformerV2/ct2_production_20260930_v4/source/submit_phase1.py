#!/usr/bin/env python3
"""Submit, inspect, or resume this particular isolated Phase-1 run."""
from __future__ import annotations
import argparse
from collections import deque
import fcntl
import json
import re
import subprocess
from pathlib import Path

from phase1_common import load_config


def read_jobs(run):
    path = run / "jobs.json"
    return json.loads(path.read_text()) if path.exists() else {}


def save_jobs(run, jobs):
    tmp = run / "jobs.tmp"
    tmp.write_text(json.dumps(jobs, indent=2) + "\n")
    tmp.replace(run / "jobs.json")


def sbatch(run, *args):
    result = subprocess.run(["sbatch", "--parsable", *map(str, args)], cwd=run, text=True, capture_output=True)
    if result.stderr.strip():
        print(result.stderr.strip(), flush=True)
    if result.returncode:
        raise RuntimeError(f"sbatch failed: {result.stdout} {result.stderr}")
    matches = [line.strip().split(";")[0] for line in result.stdout.splitlines()
               if re.fullmatch(r"\d+(;[A-Za-z0-9_.-]+)?", line.strip())]
    if len(matches) != 1:
        raise RuntimeError(f"Cannot identify the submitted job; inspect squeue before retrying. Output: {result.stdout!r}")
    return matches[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["start", "status", "logs", "resume"])
    args = parser.parse_args()
    run, cfg = load_config()
    jobs = read_jobs(run)
    if args.action in {"start", "resume"}:
        lock = (run / ".submission.lock").open("a")
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        jobs = read_jobs(run)
        if args.action == "start":
            if jobs.get("training"):
                raise RuntimeError("This run already has submissions. Use status/logs/resume; do not submit it twice.")
            if jobs.get("preflight"):
                check = jobs["preflight"]
                print(f"Reusing previously submitted preflight {check}; retrying only full-job submission.")
            else:
                check = sbatch(run, run / "preflight.slurm")
                jobs = {"preflight": check, "training": []}
                save_jobs(run, jobs)
            full = sbatch(run, f"--dependency=afterok:{check}", "--kill-on-invalid-dep=yes", run / "train.slurm")
            jobs["training"].append(full)
            save_jobs(run, jobs)
            print(f"Preflight job: {check}\nFull-training job: {full}\nFull training starts only after preflight succeeds.")
        else:
            if not jobs.get("training") or not (run / "preflight_passed.json").exists():
                raise RuntimeError("No previously submitted, preflight-approved full training run.")
            last = jobs["training"][-1]
            state = subprocess.run(["sacct", "-X", "-n", "-j", last, "--format=State", "--parsable2"],
                                   text=True, capture_output=True, check=True)
            states = [line.strip().split("|")[0].split()[0].rstrip("+") for line in state.stdout.splitlines() if line.strip()]
            allowed = {"TIMEOUT", "FAILED", "CANCELLED", "NODE_FAIL", "OUT_OF_MEMORY", "PREEMPTED"}
            if not states or any(value not in allowed for value in states):
                raise RuntimeError(f"Resume is allowed after an interrupted job, not while active or completed. State: {states}")
            checkpoint = Path(cfg["output_dir"]) / "full" / "last.ckpt"
            if not checkpoint.is_file():
                raise FileNotFoundError(f"No full-run checkpoint to resume: {checkpoint}")
            full = sbatch(run, run / "train.slurm", "--resume")
            jobs["training"].append(full)
            save_jobs(run, jobs)
            print(f"Resume job: {full}\nCheckpoint: {checkpoint}")
    elif args.action == "status":
        if not jobs:
            print("No jobs submitted for this run.")
            return
        ids = ",".join([jobs["preflight"], *jobs.get("training", [])])
        print("Run:", run, "\nCheckpoints:", Path(cfg["output_dir"]) / "full", flush=True)
        subprocess.run(["sacct", "-X", "-j", ids, "--format=JobID,JobName%16,State,Elapsed,ExitCode"], check=True)
        subprocess.run(["squeue", "-j", ids, "-o", "%.12i %.16j %.2t %.10M %.6D %R"], check=False)
    else:
        targets = [("preflight", jobs.get("preflight"))]
        if jobs.get("training"):
            targets.append(("train", jobs["training"][-1]))
        for prefix, job_id in targets:
            if not job_id:
                continue
            for suffix in ("out", "err"):
                path = run / "logs" / f"{prefix}_{job_id}.{suffix}"
                print("\nLog:", path, flush=True)
                if not path.exists():
                    print("Not created yet; this job may still be queued.")
                    continue
                if suffix == "err":
                    with path.open(errors="replace") as stream:
                        lines = deque(stream, maxlen=35)
                else:
                    with path.open(errors="replace") as stream:
                        lines = deque((line for line in stream if any(key in line for key in
                                      ("PHASE1_", "PREFLIGHT_", "Total steps:", "Restored", "Loading model weights", "Traceback", "Error"))), maxlen=45)
                print("".join(lines), end="", flush=True)


if __name__ == "__main__":
    main()
