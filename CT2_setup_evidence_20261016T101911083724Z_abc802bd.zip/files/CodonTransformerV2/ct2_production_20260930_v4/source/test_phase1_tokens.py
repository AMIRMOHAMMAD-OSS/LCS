"""CPU-only tests of representation, filtering and the translation contract."""
from __future__ import annotations
import itertools
import json
import tempfile
import unittest
from collections import Counter
from pathlib import Path
from phase1_tokens import (ALTERNATIVE_START_CODONS, AMINO_ACIDS, STANDARD_CODE, RecordRejected,
                          codon_token, prepare_sequence, require_supervision, validate_vocabulary)
from phase1_records import RecordFilter
from strict_generation import allowed_ids, validate_generated_dna


def fixture_vocab():
    tokens = ['[UNK]', '[CLS]', '[SEP]', '[PAD]', '[MASK]']
    tokens += [f'{aa.lower()}_unk' for aa in sorted(AMINO_ACIDS)] + ['__unk']
    tokens += [codon_token(c) for c in STANDARD_CODE]
    return {token: index for index, token in enumerate(tokens)}


class TokenPolicyTests(unittest.TestCase):
    vocab = fixture_vocab()

    def test_alphabet_contract(self):
        self.assertEqual(len(self.vocab), 90)
        validate_vocabulary(self.vocab)
        with self.assertRaises(ValueError):
            validate_vocabulary(dict(self.vocab, m_gtg=90))

    def test_all_initiation_exceptions_preserve_position(self):
        for codon in ALTERNATIVE_START_CODONS:
            sequence = prepare_sequence(codon+'GCTATGTAA', 'MAM', self.vocab)
            self.assertEqual(sequence.text, 'm_unk a_gct m_atg __taa')
            self.assertEqual(sequence.ignored_positions, (0,))
            self.assertEqual(sequence.target_positions, (1,2,3))
            self.assertEqual(sequence.events, {'alternative_start_positions': 1})

    def test_terminal_stop_conventions_are_equivalent(self):
        for protein in ('MA', 'MA*', 'MA_'):
            self.assertEqual(prepare_sequence('ATGGCTTAA', protein, self.vocab).text, 'm_atg a_gct __taa')

    def test_unknown_codon_retains_known_residue(self):
        result = prepare_sequence('ATGNNNTAA', 'ML', self.vocab)
        self.assertEqual(result.text, 'm_atg l_unk __taa')
        self.assertEqual(result.ignored_positions, (1,))

    def test_missing_stop_is_unknown_target(self):
        result = prepare_sequence('ATGGCT', 'MA', self.vocab)
        self.assertEqual(result.text, 'm_atg a_gct __unk')
        self.assertEqual(result.ignored_positions, (2,))

    def test_translation_disagreement_rejected_even_with_matching_lengths(self):
        for dna, protein in [('ATGCCTTAA','ML'), ('ATGGTGTAA','MM')]:
            with self.assertRaises(RecordRejected) as caught:
                prepare_sequence(dna, protein, self.vocab)
            self.assertEqual(caught.exception.reason, 'translation_mismatch')

    def test_unknown_amino_acids_are_not_replaced(self):
        with self.assertRaises(RecordRejected) as caught:
            prepare_sequence('ATGATGTAA','MX',self.vocab)
        self.assertEqual(caught.exception.reason,'unresolved_protein')
        with self.assertRaises(RecordRejected) as caught:
            prepare_sequence('ATGTAAGCTTAA','MXA',self.vocab)
        self.assertEqual(caught.exception.reason,'internal_stop')

    def test_no_supervision_after_truncation_is_rejected(self):
        result=prepare_sequence('NNN'*510+'ATGTAA','L'*510+'M',self.vocab)
        with self.assertRaises(RecordRejected):
            require_supervision(result,512)

    def test_uploaded_ten_records(self):
        records=json.loads((Path(__file__).parent/'regression_examples.json').read_text())
        reasons=Counter()
        expected={9:'length_mismatch',44:'internal_stop',107:'length_mismatch',117:'length_mismatch',
                  178:'length_mismatch',230:'internal_stop',313:'internal_stop',372:'internal_stop',
                  506:'internal_stop',515:'length_mismatch'}
        for item in records['examples']:
            with self.subTest(protein=item['gene']['protein_id']), self.assertRaises(RecordRejected) as caught:
                prepare_sequence(item['gene']['dna_sequence'], item['gene']['protein_sequence'], self.vocab)
            self.assertEqual(caught.exception.reason,expected[item['gene_index']])
            reasons[caught.exception.reason]+=1
        self.assertEqual(reasons,{'length_mismatch':5,'internal_stop':5})

    def test_filter_keeps_batches_free_of_rejected_records_and_audits(self):
        with tempfile.TemporaryDirectory() as temp:
            choose=RecordFilter(self.vocab, {'a':0},1,temp)
            docs=[{'species':'a','protein_id':'good','dna_sequence':'GTGGCTTAA','protein_sequence':'MA'},
                  {'species':'a','protein_id':'bad','dna_sequence':'ATGCCTTAA','protein_sequence':'ML'}]
            samples=[{'json':json.dumps(doc).encode()} for doc in docs]
            accepted=list(filter(choose,samples))
            choose.flush()
            report=json.loads(next(Path(temp).glob('filter_*.json')).read_text())
            self.assertEqual(len(accepted),1)
            self.assertEqual(accepted[0]['_phase1_prepared'].text,'m_unk a_gct __taa')
            self.assertEqual(report['counts']['excluded'],1)
            self.assertEqual(report['by_species']['a']['translation_mismatch'],1)
            del choose

    def test_all_allowed_codons_preserve_translation(self):
        reverse={i:t for t,i in self.vocab.items()}
        for aa in sorted(AMINO_ACIDS):
            for residue_id, stop_id in itertools.product(*allowed_ids(aa,self.vocab)):
                dna=reverse[residue_id][-3:].upper()+reverse[stop_id][-3:].upper()
                self.assertEqual(validate_generated_dna(dna,aa),dna)
        self.assertEqual(allowed_ids('M',self.vocab)[0],[self.vocab['m_atg']])

    def test_translation_validation_rejects_changed_or_ambiguous_protein(self):
        for dna, protein in [('ATGCCTTAA','ML'),('ATGTAATAG','MA'),('ATGNNNTAA','ML'),('ATGTAA','X'),('ATGTAA','MA')]:
            with self.subTest(dna=dna,protein=protein), self.assertRaises(ValueError):
                validate_generated_dna(dna,protein)

    def test_case_and_rna_normalization(self):
        self.assertEqual(prepare_sequence('gug gcu uaa','m a',self.vocab).text,'m_unk a_gct __taa')


if __name__ == '__main__':
    unittest.main(verbosity=2)
