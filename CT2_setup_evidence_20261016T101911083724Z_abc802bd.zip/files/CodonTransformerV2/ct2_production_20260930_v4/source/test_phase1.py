from __future__ import annotations
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import torch
import torch.nn.functional as F
from transformers import PreTrainedTokenizerFast

from phase1_support import CheckedCollator, FixedEvalCollator, FixedEvalDataset, validate_species_mapping
from codontransformer2.eval.CT2_eval import evaluate_species_ablations, masked_accuracy
from test_phase1_tokens import TokenPolicyTests
from strict_generation import decode_logits, validate_generated_dna, predict_preserving_translation


class Phase1Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tokenizer = PreTrainedTokenizerFast(
            tokenizer_file=str(Path(__file__).parent / "CodonTransformerTokenizer.json"),
            bos_token="[CLS]", eos_token="[SEP]", unk_token="[UNK]", sep_token="[SEP]",
            pad_token="[PAD]", cls_token="[CLS]", mask_token="[MASK]",
        )

    def collator(self, fixed=False, **kwargs):
        return (FixedEvalCollator if fixed else CheckedCollator)(
            self.tokenizer, species_to_id={"a": 0, "b": 1, "c": 2},
            unknown_species_id=3, max_species_id=5, max_length=512, **kwargs)

    @staticmethod
    def record(key="one", repeats=4, **overrides):
        doc = dict(species="a", protein_id=key, dna_sequence="ATG" * repeats,
                   protein_sequence="M" * repeats, eval_key=key)
        doc.update(overrides)
        return {"json": json.dumps(doc).encode()}

    def test_zero_selection_gets_supervision(self):
        batch = self.collator(mlm_probability=0.0)([self.record(repeats=1), self.record(repeats=3)])
        self.assertTrue(batch["labels"].ne(-100).any(dim=1).all())
        n, length = batch["labels"].shape
        loss = F.cross_entropy(torch.zeros(n * length, len(self.tokenizer)), batch["labels"].flatten(), ignore_index=-100)
        self.assertTrue(torch.isfinite(loss))

    def test_bad_data_is_not_silently_dropped(self):
        collator = self.collator()
        for records in ([], [self.record(protein_sequence=None)], [self.record(dna_sequence="ATGA")],
                        [self.record(species="not-in-mapping")]):
            with self.assertRaises(ValueError):
                collator(records)

    def test_alternative_start_works_in_training_and_fixed_evaluation(self):
        for fixed in (False, True):
            collator = self.collator(fixed=fixed, mlm_probability=1.0)
            record = self.record(dna_sequence="GTGGCTATGTAA", protein_sequence="MAM")
            batch = collator([record])
            targets = batch["labels"][batch["labels"].ne(-100)].tolist()
            self.assertEqual(targets, [self.tokenizer.convert_tokens_to_ids("a_gct"),
                                       self.tokenizer.convert_tokens_to_ids("m_atg"),
                                       self.tokenizer.convert_tokens_to_ids("__taa")])
            self.assertEqual(int(batch['input_ids'][0, 1]), self.tokenizer.convert_tokens_to_ids('m_unk'))
            self.assertEqual(int(batch['labels'][0, 1]), -100)
            self.assertEqual(int(batch['attention_mask'][0].sum()), 6)
            self.assertEqual(collator.ignored_target_counts['alternative_start_positions'], 1)
            with self.assertRaisesRegex(ValueError, "m_gtg at residue position 2"):
                collator([self.record(dna_sequence="ATGGTG", protein_sequence="MM")])

    def test_unknown_positions_are_never_augmented_or_supervised(self):
        for full in (0.0, 1.0):
            collator = self.collator(mlm_probability=1.0, full_mask_probability=full)
            batch = collator([self.record(dna_sequence='GTGNNNGCT', protein_sequence='MLA')])
            for position, token in ((1, 'm_unk'), (2, 'l_unk'), (4, '__unk')):
                self.assertEqual(int(batch['input_ids'][0, position]), self.tokenizer.convert_tokens_to_ids(token))
                self.assertEqual(int(batch['labels'][0, position]), -100)
            self.assertEqual(int(batch['labels'][0, 3]), self.tokenizer.convert_tokens_to_ids('a_gct'))

    def test_strict_decoding_survives_adversarial_nonsynonymous_logits(self):
        vocab = self.tokenizer.get_vocab()
        protein = 'MACDEFGHIKLMNPQRSTVWY'
        logits = torch.zeros(len(protein)+1, len(vocab))
        logits[:, vocab['[MASK]']] = 10000
        logits[:, vocab['y_tat']] = 9999
        for sample in (False, True):
            for top_p in (0.01, 1.0):
                dna = decode_logits(logits, protein, vocab, sample=sample, top_p=top_p,
                                    generator=torch.Generator().manual_seed(12))
                self.assertEqual(validate_generated_dna(dna, protein), dna)
                self.assertTrue(dna.startswith('ATG'))
        logits[0, vocab['m_atg']] = float('nan')
        with self.assertRaises(ValueError):
            decode_logits(logits, protein, vocab)

    def test_generation_helper_keeps_full_input_and_checks_context(self):
        class Model(torch.nn.Module):
            def __init__(self, size):
                super().__init__()
                self.tokens = torch.nn.Embedding(size, 4)
                self.config = SimpleNamespace(max_position_embeddings=32)
                self.size = size
            def get_input_embeddings(self):
                return self.tokens
            def forward(self, inputs_embeds, attention_mask):
                self.last_length = inputs_embeds.shape[1]
                return SimpleNamespace(logits=torch.zeros(1, self.last_length, self.size))
        model, species = Model(len(self.tokenizer)), torch.nn.Embedding(3, 4)
        dna = predict_preserving_translation(model, species, self.tokenizer, 'MALW', 1, species_embed_scale=0.0347)
        self.assertEqual(validate_generated_dna(dna, 'MALW'), dna)
        self.assertEqual(model.last_length, 7)
        self.assertTrue(model.training and species.training)
        with self.assertRaisesRegex(ValueError, 'context'):
            predict_preserving_translation(model, species, self.tokenizer, 'M'*32, 1, species_embed_scale=0.0347)

    def test_deterministic_masks_and_wrong_ids(self):
        collator = self.collator(fixed=True)
        examples = [self.record("one", 3), self.record("two", 17, species="b")]
        torch.manual_seed(7)
        before = torch.get_rng_state().clone()
        first = collator(examples)
        self.assertTrue(torch.equal(before, torch.get_rng_state()))
        torch.manual_seed(91)
        second = collator(examples)
        for key in first:
            self.assertTrue(torch.equal(first[key], second[key]), key)
        for index, example in enumerate(examples):
            alone = collator([example])
            length = alone["input_ids"].shape[1]
            for key in ("input_ids", "labels", "attention_mask"):
                self.assertTrue(torch.equal(first[key][index, :length], alone[key][0]))
        self.assertTrue((first["wrong_species_id"] < 3).all())
        self.assertTrue((first["wrong_species_id"] != first["species_id"]).all())

    def test_distributed_panel_has_no_overlap(self):
        with tempfile.TemporaryDirectory() as temp:
            panel = Path(temp) / "panel.jsonl"
            panel.write_text("".join(json.dumps({"id": i}) + "\n" for i in range(16)))
            seen = []
            for rank in range(8):
                dataset = FixedEvalDataset(str(panel), rank=rank, world_size=8)
                self.assertEqual(len(dataset), 2)
                seen.extend(json.loads(row["json"])["id"] for row in dataset)
            self.assertEqual(sorted(seen), list(range(16)))

    def test_bf16_accuracy_keeps_integer_counts(self):
        logits = torch.zeros(1, 513, 3, dtype=torch.bfloat16)
        logits[..., 0] = 1.0
        labels = torch.zeros(1, 513, dtype=torch.long)
        labels[0, -1] = 1
        self.assertAlmostEqual(float(masked_accuracy(logits, labels)), 512 / 513, places=6)

    def test_wrong_species_never_uses_reserved_slots(self):
        class Model(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.tokens = torch.nn.Embedding(10, 4)
                self.decoder = torch.nn.Linear(4, 10)
            def get_input_embeddings(self):
                return self.tokens
            def forward(self, inputs_embeds, attention_mask, labels):
                logits = self.decoder(inputs_embeds)
                loss = F.cross_entropy(logits.reshape(-1, 10), labels.reshape(-1), ignore_index=-100)
                return SimpleNamespace(loss=loss, logits=logits)
        model = Model().eval()
        species = torch.nn.Embedding(5, 4)  # only IDs 0,1,2 are real
        batch = {"input_ids": torch.tensor([[1, 2], [3, 4]]), "attention_mask": torch.ones(2, 2, dtype=torch.long),
                 "labels": torch.tensor([[1, -100], [-100, 4]]), "species_id": torch.tensor([0, 2])}
        seen = []
        hook = species.register_forward_pre_hook(lambda module, args: seen.append(args[0].clone()))
        try:
            for _ in range(20):
                seen.clear()
                evaluate_species_ablations(model, species, batch, unknown_species_id=3, topk=5, species_embed_scale=0.0347)
                wrong = seen[-1]
                self.assertTrue(((wrong >= 0) & (wrong < 3)).all())
                self.assertTrue((wrong != batch["species_id"]).all())
            batch["wrong_species_id"] = torch.tensor([1, 0])
            seen.clear()
            evaluate_species_ablations(model, species, batch, unknown_species_id=3, topk=5)
            self.assertTrue(torch.equal(seen[-1], batch["wrong_species_id"]))
        finally:
            hook.remove()

    def test_species_id_contract(self):
        validate_species_mapping({"a": 0, "b": 1, "c": 2}, 3, 3)
        with self.assertRaises(ValueError):
            validate_species_mapping({"a": 0, "b": 2}, 3, 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
