from __future__ import annotations
import argparse
import json
import math
import os
import random
import sys
from datetime import datetime, timezone
from pathlib import Path

from phase1_common import file_sha, load_config, verify_panel
from phase1_tokens import TOKEN_POLICY


def make_panel(run, cfg):
    import torch
    import lightning.pytorch as pl
    import transformers
    import webdataset
    from transformers import PreTrainedTokenizerFast
    from phase1_support import CheckedCollator
    from phase1_panel import select_panel

    print("PHASE1_ENVIRONMENT", json.dumps({
        "python": sys.executable, "torch": torch.__version__, "lightning": pl.__version__,
        "transformers": transformers.__version__, "webdataset": webdataset.__version__,
    }), flush=True)
    if (run / "eval_panel.jsonl").exists():
        _, meta = verify_panel(run, cfg)
        print("Using existing fixed evaluation panel:", meta, flush=True)
        return
    tokenizer = PreTrainedTokenizerFast(
        tokenizer_file=str(run / "CodonTransformerTokenizer.json"),
        bos_token="[CLS]", eos_token="[SEP]", unk_token="[UNK]", sep_token="[SEP]",
        pad_token="[PAD]", cls_token="[CLS]", mask_token="[MASK]",
    )
    selected, report = select_panel(cfg, tokenizer.get_vocab())
    cpu_check = json.loads((run / "token_precheck.json").read_text())
    if cpu_check.get("error_count") or cpu_check.get("fingerprint") != cfg["fingerprint"]:
        raise RuntimeError("CPU token precheck has not passed for this run")
    if cpu_check["selected_records_sha256"] != report["selected_records_sha256"]:
        raise RuntimeError("Evaluation records changed since CPU precheck")
    mapping = {str(k): int(v) for k, v in json.loads(Path(cfg["species_mapping"]).read_text()).items()}
    collator = CheckedCollator(tokenizer, species_to_id=mapping,
        unknown_species_id=cfg["unknown_species_id"],
        max_species_id=cfg["num_organisms"] + cfg["extra_organisms"],
        mlm_probability=0.15, max_length=512)
    for record in selected:
        try:
            collator([{"json": record}])
        except Exception as exc:
            raise RuntimeError(f"Collator preflight failed at {record['eval_key']}: {exc}") from exc
    panel = run / "eval_panel.jsonl"
    temp = panel.with_suffix(".tmp")
    temp.write_text("".join(json.dumps(row) + "\n" for row in selected))
    temp.replace(panel)
    meta = dict(report, fingerprint=cfg["fingerprint"], samples=len(selected),
                genes_per_species=cfg["eval_genes_per_species"], token_policy=TOKEN_POLICY,
                sha256=file_sha(panel))
    (run / "eval_panel_meta.json").write_text(json.dumps(meta, indent=2) + "\n")
    print("PHASE1_PANEL", json.dumps({k:v for k,v in meta.items() if k not in
          ("excluded_by_species", "rejection_examples")}, sort_keys=True), flush=True)


def stamp_preflight(run, cfg):
    import torch
    panel, meta = verify_panel(run, cfg)
    checkpoint = Path(cfg["output_dir"]) / "smoke" / "last.ckpt"
    ckpt = torch.load(checkpoint, map_location="cpu", weights_only=False)
    if int(ckpt["global_step"]) != 128:
        raise RuntimeError(f"Resume test did not end at global_step 128: {ckpt.get('global_step')}")
    metrics = json.loads((checkpoint.parent / "validation_latest.json").read_text())
    if metrics.get("global_step") != 128 or not all(math.isfinite(float(v)) for v in metrics.values()):
        raise RuntimeError("Smoke validation is missing or nonfinite.")
    if not ckpt.get("optimizer_states") or not ckpt.get("lr_schedulers"):
        raise RuntimeError("Checkpoint is missing optimizer/scheduler state.")
    from strict_generation import validate_generated_dna
    generation = json.loads((checkpoint.parent / 'generation_check_latest.json').read_text())
    if generation.get('global_step') != 128 or generation.get('translation_matches') is not True:
        raise RuntimeError('Strict-generation check did not pass at the end of resumed preflight')
    validate_generated_dna(generation['dna'], generation['protein'])
    stamp = {
        "fingerprint": cfg["fingerprint"], "panel_sha256": meta["sha256"],
        "global_step": 128, "distributed_ranks": 8, "resume_test": "passed",
        "time_utc": datetime.now(timezone.utc).isoformat(),
        "job_id": os.environ.get("SLURM_JOB_ID"), "metrics": metrics,
        "strict_generation": generation,
    }
    (run / "preflight_passed.json").write_text(json.dumps(stamp, indent=2) + "\n")
    print("PREFLIGHT_PASSED", json.dumps(stamp, sort_keys=True), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--stamp", action="store_true")
    args = parser.parse_args()
    run, cfg = load_config()
    if args.stamp:
        stamp_preflight(run, cfg)
    else:
        make_panel(run, cfg)
