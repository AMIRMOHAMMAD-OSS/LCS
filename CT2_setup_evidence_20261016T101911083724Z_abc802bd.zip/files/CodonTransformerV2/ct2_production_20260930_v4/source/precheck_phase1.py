"""CPU-only check of the accepted evaluation panel, with explicit exclusions."""
from __future__ import annotations
import json
from phase1_common import load_config
from phase1_panel import select_panel
from phase1_tokens import TOKEN_POLICY


def main():
    run, cfg = load_config()
    tokenizer = json.loads((run / 'CodonTransformerTokenizer.json').read_text())
    raw = tokenizer['model']['vocab']
    vocab = set(raw) if isinstance(raw, dict) else {item[0] for item in raw}
    vocab.update(item['content'] for item in tokenizer.get('added_tokens', []))
    print('PHASE1_TOKEN_CHECK_START', flush=True)
    try:
        _, report = select_panel(cfg, vocab)
    except (ValueError, RuntimeError) as exc:
        report = {'error_count': 1, 'error': str(exc)}
    else:
        report['error_count'] = 0
    report.update(fingerprint=cfg['fingerprint'], token_policy=TOKEN_POLICY)
    (run / 'token_precheck.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
    printable = {k: v for k, v in report.items() if k not in ('excluded_by_species', 'rejection_examples')}
    print('PHASE1_TOKEN_CHECK_FAILED' if report['error_count'] else 'PHASE1_TOKEN_CHECK_PASSED',
          json.dumps(printable, sort_keys=True), flush=True)
    return 1 if report['error_count'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
