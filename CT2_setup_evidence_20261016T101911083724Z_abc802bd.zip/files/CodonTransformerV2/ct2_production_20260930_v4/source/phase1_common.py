from __future__ import annotations
import hashlib
import json
from pathlib import Path


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def config_fingerprint(config):
    clean = {k: v for k, v in config.items() if k != "fingerprint"}
    return hashlib.sha256(json.dumps(clean, sort_keys=True).encode()).hexdigest()


def load_config():
    run = Path(__file__).resolve().parent
    config = json.loads((run / "run_config.json").read_text())
    if config_fingerprint(config) != config["fingerprint"]:
        raise RuntimeError("run_config.json was changed. Make a new run rather than changing a sealed run.")
    for relative, expected in config["code_hashes"].items():
        if file_sha(run / relative) != expected:
            raise RuntimeError(f"Snapshot file changed after setup: {relative}")
    if file_sha(config["species_mapping"]) != config["species_mapping_sha256"]:
        raise RuntimeError("Species mapping changed after setup.")
    stat = Path(config["init_checkpoint"]).stat()
    if stat.st_size != config["init_size"] or stat.st_mtime_ns != config["init_mtime_ns"]:
        raise RuntimeError("Initialization checkpoint changed after setup.")
    return run, config


def verify_panel(run, config):
    panel = run / "eval_panel.jsonl"
    meta = json.loads((run / "eval_panel_meta.json").read_text())
    if meta["fingerprint"] != config["fingerprint"] or file_sha(panel) != meta["sha256"]:
        raise RuntimeError("Evaluation panel does not match this run.")
    if meta["samples"] != config["eval_species"] * config["eval_genes_per_species"]:
        raise RuntimeError("Wrong evaluation-panel size.")
    return panel, meta
