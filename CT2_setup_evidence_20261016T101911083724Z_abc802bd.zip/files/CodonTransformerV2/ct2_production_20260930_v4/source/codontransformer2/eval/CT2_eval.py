from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional, Tuple
import torch
import torch.nn.functional as F

IGNORE_INDEX = -100


@torch.no_grad()
def masked_topk_accuracy(logits: torch.Tensor,labels: torch.Tensor,k: int = 1,ignore_index: int = IGNORE_INDEX,) -> torch.Tensor:
    mask = labels.ne(ignore_index)  # [B,L]
    denom = mask.sum().clamp_min(1).float()
    topk = logits.topk(k, dim=-1).indices  # [B,L,K]
    gold = labels.unsqueeze(-1)            # [B,L,1]
    correct = (topk == gold).any(dim=-1) & mask  # [B,L]
    return correct.sum().float() / denom


@torch.no_grad()
def masked_accuracy(logits: torch.Tensor,labels: torch.Tensor,ignore_index: int = IGNORE_INDEX,) -> torch.Tensor:
    return masked_topk_accuracy(logits, labels, k=1, ignore_index=ignore_index)


@torch.no_grad()
def masked_loss_from_logits(logits: torch.Tensor,labels: torch.Tensor,ignore_index: int = IGNORE_INDEX,) -> torch.Tensor:
    B, L, V = logits.shape
    return F.cross_entropy(
        logits.float().reshape(B * L, V),
        labels.view(B * L),
        ignore_index=ignore_index,
        reduction="mean",
    )


@torch.no_grad()
def masked_synonymous_accuracy(
    logits: torch.Tensor,
    labels: torch.Tensor,
    codon_id_to_aa_id: torch.Tensor,
    k: int = 1,
    ignore_index: int = IGNORE_INDEX,
) -> torch.Tensor:
    mask = labels.ne(ignore_index)

    safe_labels = labels.clone()
    safe_labels[~mask] = 0

    topk = logits.topk(k, dim=-1).indices
    pred_aa = codon_id_to_aa_id[topk]
    gold_aa = codon_id_to_aa_id[safe_labels].unsqueeze(-1)

    valid_gold = gold_aa.ne(-1).squeeze(-1)
    final_mask = mask & valid_gold

    denom = final_mask.sum().clamp_min(1).float()
    same = (pred_aa == gold_aa).any(dim=-1) & final_mask

    return same.sum().float() / denom


@dataclass
class SpeciesBuckets:
    head: torch.Tensor  # [S] bool
    mid: torch.Tensor   # [S] bool
    tail: torch.Tensor  # [S] bool


def build_species_buckets(species_counts: torch.Tensor,head_frac: float = 0.10, tail_frac: float = 0.50,) -> SpeciesBuckets:
    assert species_counts.dim() == 1
    S = species_counts.numel()
    sorted_ids = torch.argsort(species_counts, descending=True)
    head_n = max(1, int(S * head_frac))
    tail_n = max(1, int(S * tail_frac))
    head_ids = sorted_ids[:head_n]
    tail_ids = sorted_ids[-tail_n:]
    head = torch.zeros(S, dtype=torch.bool, device=species_counts.device)
    tail = torch.zeros(S, dtype=torch.bool, device=species_counts.device)
    head[head_ids] = True
    tail[tail_ids] = True
    mid = ~(head | tail)
    return SpeciesBuckets(head=head, mid=mid, tail=tail)


@torch.no_grad()
def forward_with_species_conditioning(model,species_embed: torch.nn.Embedding,batch: Dict[str, torch.Tensor],species_ids: torch.Tensor, species_embed_scale: float = 1.0, ) -> Tuple[torch.Tensor, torch.Tensor]:
    input_ids = batch["input_ids"]
    attn = batch["attention_mask"]
    labels = batch["labels"]
    token_embeds = model.get_input_embeddings()(input_ids)  # [B,L,H]
    sp = species_embed(species_ids)                         # [B,H]
    sp = sp * species_embed_scale
    token_embeds = token_embeds + sp[:, None, :]            # [B,L,H]
    out = model(inputs_embeds=token_embeds, attention_mask=attn, labels=labels)
    return out.loss, out.logits


@torch.no_grad()
def evaluate_mlm_batch(model,species_embed: torch.nn.Embedding,batch: Dict[str, torch.Tensor],*,topk: int = 5,codon_id_to_aa_id: Optional[torch.Tensor] = None,synonym_topk: int = 1,prefix: str = "test",species_embed_scale: float = 1.0,) -> Dict[str, torch.Tensor]:
    loss, logits = forward_with_species_conditioning(model, species_embed, batch, batch["species_id"], species_embed_scale)
    labels = batch["labels"]
    metrics: Dict[str, torch.Tensor] = {
        f"{prefix}_loss": loss.detach(),
        f"{prefix}_acc": masked_accuracy(logits, labels),
        f"{prefix}_top{topk}_acc": masked_topk_accuracy(logits, labels, k=topk),
    }
    if codon_id_to_aa_id is not None:
        metrics[f"{prefix}_syn_acc"] = masked_synonymous_accuracy(
            logits, labels, codon_id_to_aa_id, k=synonym_topk
        )
    return metrics


@torch.no_grad()
def evaluate_species_ablations(model,species_embed: torch.nn.Embedding,batch: Dict[str, torch.Tensor],*,unknown_species_id: int,topk: int = 5,prefix: str = "test",species_embed_scale: float = 1.0,) -> Dict[str, torch.Tensor]:
    labels = batch["labels"]
    B = batch["species_id"].shape[0]
    device = batch["species_id"].device
    # correct
    loss_c, logits_c = forward_with_species_conditioning(model, species_embed, batch, batch["species_id"], species_embed_scale)
    # unknown
    unk_ids = torch.full((B,), int(unknown_species_id), device=device, dtype=torch.long)
    loss_u, logits_u = forward_with_species_conditioning(model, species_embed, batch, unk_ids, species_embed_scale)
    # wrong: guaranteed-different species (offset in valid range, never equals true id)
    n_species = int(unknown_species_id)  # real IDs only; reserved slots are not organisms
    if n_species < 2:
        raise ValueError("Need at least two real species for ablations.")
    if "wrong_species_id" in batch:
        wrong_ids = batch["wrong_species_id"]
    else:
        # With no fixed panel, still sample only real IDs and exclude each known true ID.
        true_ids = batch["species_id"]
        known = (true_ids >= 0) & (true_ids < n_species)
        candidate = torch.randint(0, n_species - 1, (B,), device=device)
        different = candidate + (candidate >= true_ids).long()
        fallback = torch.randint(0, n_species, (B,), device=device)
        wrong_ids = torch.where(known, different, fallback)
    if ((wrong_ids < 0) | (wrong_ids >= n_species) | (wrong_ids == batch["species_id"])).any():
        raise ValueError("Invalid wrong-species assignment.")
    loss_w, logits_w = forward_with_species_conditioning(model, species_embed, batch, wrong_ids, species_embed_scale)

    metrics = {
        f"{prefix}_loss_correct": loss_c.detach(),
        f"{prefix}_loss_unknown": loss_u.detach(),
        f"{prefix}_loss_wrong": loss_w.detach(),
        f"{prefix}_acc_correct": masked_accuracy(logits_c, labels),
        f"{prefix}_acc_unknown": masked_accuracy(logits_u, labels),
        f"{prefix}_acc_wrong": masked_accuracy(logits_w, labels),
        f"{prefix}_top{topk}_acc_correct": masked_topk_accuracy(logits_c, labels, k=topk),
        f"{prefix}_top{topk}_acc_unknown": masked_topk_accuracy(logits_u, labels, k=topk),
        f"{prefix}_top{topk}_acc_wrong": masked_topk_accuracy(logits_w, labels, k=topk),
        f"{prefix}_delta_unk": (loss_u - loss_c).detach(),
        f"{prefix}_delta_wrong": (loss_w - loss_c).detach(),
    }
    return metrics


@torch.no_grad()
def evaluate_tail_buckets(model,species_embed: torch.nn.Embedding,batch: Dict[str, torch.Tensor],buckets: SpeciesBuckets,*,topk: int = 5,prefix: str = "test",species_embed_scale: float = 1.0,) -> Dict[str, torch.Tensor]:
    loss, logits = forward_with_species_conditioning(model, species_embed, batch, batch["species_id"], species_embed_scale)
    labels = batch["labels"]
    species_ids = batch["species_id"]  # [B]
    device = labels.device
    metrics: Dict[str, torch.Tensor] = {}

    def bucket_metrics(name: str, sample_mask: torch.Tensor):
        if sample_mask.sum().item() == 0:
            metrics[f"{prefix}_{name}_loss"] = torch.tensor(float("nan"), device=device)
            metrics[f"{prefix}_{name}_acc"] = torch.tensor(float("nan"), device=device)
            metrics[f"{prefix}_{name}_top{topk}_acc"] = torch.tensor(float("nan"), device=device)
            return

        logits_b = logits[sample_mask]
        labels_b = labels[sample_mask]
        metrics[f"{prefix}_{name}_loss"] = masked_loss_from_logits(logits_b, labels_b)
        metrics[f"{prefix}_{name}_acc"] = masked_accuracy(logits_b, labels_b)
        metrics[f"{prefix}_{name}_top{topk}_acc"] = masked_topk_accuracy(logits_b, labels_b, k=topk)

    bucket_metrics("head", buckets.head[species_ids])
    bucket_metrics("mid", buckets.mid[species_ids])
    bucket_metrics("tail", buckets.tail[species_ids])

    return metrics
