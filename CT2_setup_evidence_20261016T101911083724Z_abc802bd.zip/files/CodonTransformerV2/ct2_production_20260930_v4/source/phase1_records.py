"""Filter unresolved records before DataLoader batching and record exclusions."""
from __future__ import annotations
import json
import os
from collections import Counter
from pathlib import Path
from phase1_tokens import RecordRejected, prepare_sequence, require_supervision


def parse_record(raw):
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, (bytes, bytearray)):
        raw = raw.decode('utf-8')
    doc = json.loads(raw)
    if not isinstance(doc, dict):
        raise ValueError('A training JSON record must be an object')
    return doc


def record_dna(doc):
    return doc.get('dna_sequence') or doc.get('seq') or doc.get('dna') or doc.get('sequence')


class RecordFilter:
    def __init__(self, vocab, mapping, unknown_species_id, audit_dir, max_length=512):
        self.vocab, self.mapping = vocab, mapping
        self.unknown_species_id = unknown_species_id
        self.audit_dir, self.max_length = Path(audit_dir), max_length
        self.counts, self.events = Counter(), Counter()
        self.by_species, self.examples = {}, []

    def __call__(self, sample):
        doc = parse_record(sample['json'])
        species = doc.get('species')
        sid = species if isinstance(species, int) else self.mapping.get(str(species))
        if sid is None or not 0 <= sid < self.unknown_species_id:
            raise ValueError(f'Unmapped training species: {species!r}')
        self.counts['examined'] += 1
        species_counts = self.by_species.setdefault(str(species), Counter())
        try:
            prepared = prepare_sequence(record_dna(doc), doc.get('protein_sequence'), self.vocab)
            require_supervision(prepared, self.max_length)
        except RecordRejected as exc:
            self.counts['excluded'] += 1
            self.counts[exc.reason] += 1
            species_counts[exc.reason] += 1
            if len(self.examples) < 20:
                self.examples.append({'protein_id': doc.get('protein_id'), 'species': species,
                                      'shard': sample.get('__url__'), 'key': sample.get('__key__'),
                                      'reason': exc.reason, 'error': str(exc)})
            accepted = False
        else:
            self.counts['accepted'] += 1
            species_counts['accepted'] += 1
            self.events.update(prepared.events)
            sample['json'] = doc
            sample['_phase1_prepared'] = prepared
            accepted = True
        if self.counts['examined'] == 1 or self.counts['examined'] % 10000 == 0 or (not accepted and self.counts['excluded'] == 1):
            self.flush()
        return accepted

    def flush(self):
        if not self.counts:
            return
        self.audit_dir.mkdir(parents=True, exist_ok=True)
        job = os.environ.get('SLURM_JOB_ID', 'local')
        rank = os.environ.get('SLURM_PROCID', os.environ.get('RANK', '0'))
        path = self.audit_dir / f'filter_job{job}_rank{rank}_pid{os.getpid()}.json'
        result = {'counts': dict(self.counts), 'by_species': self.by_species,
                  'ignored_target_positions': dict(self.events), 'rejection_examples': self.examples,
                  'scope': 'records examined by this worker; periodic snapshot, not a full-corpus audit'}
        tmp = path.with_suffix('.tmp')
        tmp.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
        tmp.replace(path)

    def __del__(self):
        try:
            self.flush()
        except Exception:
            pass  # Normal flushes are strict; interpreter shutdown is best effort.
