from __future__ import annotations
import argparse
import json
import os
import sys
from pathlib import Path
from phase1_common import load_config, verify_panel


def command(mode, resume=False):
    run, cfg = load_config()
    panel, meta = verify_panel(run, cfg)
    full = mode == "full"
    output = Path(cfg["output_dir"]) / ("full" if full else "smoke")
    output.mkdir(parents=True, exist_ok=True)
    if full:
        stamp_path = run / "preflight_passed.json"
        if not stamp_path.exists():
            raise RuntimeError("Preflight has not passed; full training is blocked.")
        stamp = json.loads(stamp_path.read_text())
        if stamp["fingerprint"] != cfg["fingerprint"] or stamp["panel_sha256"] != meta["sha256"]:
            raise RuntimeError("Preflight stamp does not match this code/config/panel.")
    do_resume = resume or mode == "smoke-resume"
    if do_resume:
        checkpoint = output / "last.ckpt"
        if not checkpoint.is_file():
            raise FileNotFoundError(f"No resumable checkpoint: {checkpoint}")
        load_args = ["--resume_from_checkpoint", str(checkpoint)]
    else:
        if list(output.glob("*.ckpt")):
            raise RuntimeError(f"Checkpoints already exist in {output}; use the documented resume command.")
        load_args = ["--init_from_checkpoint", cfg["init_checkpoint"]]

    args = {
        "dataroot": cfg["data_root"], "shard_pattern": "shard-{000000..005873}.tar.gz", "shardshuffle": 100,
        "tokenizer_file": str(run / "CodonTransformerTokenizer.json"),
        "species_to_id_path": cfg["species_mapping"], "test_json_dir": cfg["test_json_dir"],
        "eval_panel": str(panel), "test_batch_size": 8, "limit_test_batches": 64,
        "check_test_every_n_epoch": 1, "do_species_ablations_every": 1,
        "num_organisms": cfg["num_organisms"], "extra_organisms": cfg["extra_organisms"],
        "unknown_species_id": cfg["unknown_species_id"], "species_dropout_prob": 0.15,
        "species_random_frac": 0.2, "full_mask_probability": 0.0, "mlm_probability": 0.15,
        "max_length": 2048, "train_max_length": 512, "attn_implementation": "sdpa",
        "species_embed_scale": 0.0347, "learning_rate": 1e-4, "warmup_fraction": 0.1,
        "learning_rate_decay": 0.2, "weight_decay": 0.01, "gradient_clip_val": 0.5,
        "max_epochs": 10 if full else 2, "batch_size": 192, "num_workers": 1,
        "accumulate_grad_batches": 1, "limit_train_batches": 8000 if full else 64,
        "log_every_n_steps": 50 if full else 10, "accelerator": "gpu", "devices": 4,
        "num_nodes": 2, "strategy": "ddp", "precision": "bf16-mixed",
        "checkpoint_dir": str(output), "save_interval": 1, "seed": cfg["seed"],
    }
    cmd = [sys.executable, "-u", str(run / "train_phase1_final.py")]
    for key, value in args.items():
        cmd.extend(["--" + key, str(value)])
    cmd.extend(load_args)
    if mode == "smoke-first":
        cmd.append("--stop_after_first_epoch")
    if os.environ.get("SLURM_PROCID", "0") == "0":
        print("PHASE1_LAUNCH", json.dumps({"mode": mode, "resuming": do_resume, "arguments": args}), flush=True)
    return cmd


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", required=True, choices=["smoke-first", "smoke-resume", "full"])
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.resume and args.mode != "full":
        parser.error("--resume is only for full training; smoke-resume is a separate mode.")
    cmd = command(args.mode, args.resume)
    os.execv(sys.executable, cmd)
