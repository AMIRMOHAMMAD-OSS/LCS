"""Guards and fixed evaluation for the CT2 Phase-1 run."""
from __future__ import annotations

import hashlib
import json
import math
import os
from collections import Counter
from pathlib import Path

import lightning.pytorch as pl
import torch
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import IterableDataset, get_worker_info

from codontransformer2.dataset.collators import MaskedTokenizerCollator
from phase1_tokens import PreparedSequence, codon_token, STANDARD_CODE, prepare_sequence, require_supervision, validate_vocabulary
from phase1_records import RecordFilter, parse_record, record_dna


def stable_seed(text: str) -> int:
    return int.from_bytes(hashlib.sha256(text.encode()).digest()[:8], "big") % (2**63 - 1)


def validate_species_mapping(mapping, n_real: int, unknown_id: int):
    ids = {int(v) for v in mapping.values()}
    if unknown_id != n_real or ids != set(range(n_real)):
        raise ValueError(
            "Expected real species IDs 0..num_organisms-1 and unknown_species_id=num_organisms. "
            "Check species_to_id.json; this run must not silently reinterpret species IDs."
        )


class CheckedCollator(MaskedTokenizerCollator):
    """Retain the original masking recipe, with explicit data/supervision checks."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        validate_vocabulary(self.vocab)
        from codontransformer2.dataset.constants import SYNONYMOUS_CODONS
        target_ids = {self.vocab[codon_token(c)] for c in STANDARD_CODE}
        residue_for_id = {self.vocab[codon_token(c)]: aa for c, aa in STANDARD_CODE.items()}
        for codon, aa in STANDARD_CODE.items():
            index = self.vocab[codon_token(codon)]
            masked = self.vocab['__unk' if aa == '*' else f'{aa.lower()}_unk']
            if int(self.token2mask_tensor[index]) != masked:
                raise ValueError(f'TOKEN2MASK disagrees with tokenizer at {codon}')
            if any(residue_for_id.get(int(candidate)) != aa for candidate in SYNONYMOUS_CODONS.get(index, [index])):
                raise ValueError(f'Synonymous replacement changes the amino acid at {codon}')
        self.special_ids.update(set(self.vocab.values()) - target_ids)
        # The window checks and generation helper depend on this exact framing.
        probe = self.tokenizer('m_atg __taa', add_special_tokens=True)['input_ids']
        expected = [self.tokenizer.cls_token_id, self.vocab['m_atg'], self.vocab['__taa'], self.tokenizer.sep_token_id]
        if probe != expected:
            raise ValueError('Tokenizer must produce CLS + one token per codon + SEP')
        self.ignored_target_counts = Counter()

    def _parse_json(self, raw):
        return parse_record(raw)

    def _to_species_id(self, raw_species):
        sid = super()._to_species_id(raw_species)
        if not (0 <= sid < self.unknown_species_id):
            raise ValueError(f"Unmapped input species before augmentation: {raw_species!r}")
        return sid

    def _build_token_text(self, dna, protein):
        if hasattr(self, '_pending_texts'):
            return next(self._pending_texts)
        return prepare_sequence(dna, protein, self.vocab).text

    def __call__(self, examples):
        if not examples:
            raise ValueError("Empty input batch.")
        texts = []
        for ex in examples:
            doc = self._parse_json(ex["json"])
            try:
                prepared = ex.get('_phase1_prepared')
                if not isinstance(prepared, PreparedSequence):
                    prepared = prepare_sequence(record_dna(doc), doc.get('protein_sequence'), self.vocab)
                require_supervision(prepared, self.max_length)
                texts.append(prepared.text)
                self.ignored_target_counts.update(prepared.events)
            except ValueError as exc:
                identity = doc.get("protein_id", doc.get("genome_id", "unidentified record"))
                raise ValueError(f"Invalid CT2 record {identity!r}: {exc}") from exc
        self._pending_texts = iter(texts)
        try:
            batch = super().__call__(examples)
        finally:
            del self._pending_texts
        if batch["input_ids"].shape[0] != len(examples):
            raise ValueError("Collation unexpectedly changed batch size.")

        # A short accepted sequence may otherwise receive no MLM target at all.
        for row in range(batch["labels"].shape[0]):
            if batch["labels"][row].ne(-100).any():
                continue
            ids = batch["input_ids"][row]
            eligible = batch["attention_mask"][row].bool()
            for special_id in self.special_ids:
                eligible &= ids.ne(special_id)
            positions = eligible.nonzero(as_tuple=False).flatten()
            if positions.numel() == 0:
                raise ValueError("Tokenization produced no usable codon positions.")
            pos = positions[torch.randint(positions.numel(), (1,)).item()]
            original = ids[pos].clone()
            if self.token2mask_tensor[original] == original:
                raise ValueError("Selected codon has no amino-acid masking mapping.")
            batch["labels"][row, pos] = original
            batch["input_ids"][row, pos] = self.token2mask_tensor[original]
        return batch


class FixedEvalCollator(CheckedCollator):
    """Per-record RNG seeds make masking independent of workers, ranks and batch order."""

    def __call__(self, examples):
        rows = []
        wrong_ids = []
        n_real = self.unknown_species_id
        if n_real < 2:
            raise ValueError("Species ablation requires at least two real species.")
        for ex in examples:
            doc = self._parse_json(ex["json"])
            key = str(doc["eval_key"])
            with torch.random.fork_rng(devices=[]):
                torch.default_generator.manual_seed(stable_seed("mask:" + key))
                row = super().__call__([ex])
            sid = int(row["species_id"].item())
            offset = 1 + stable_seed("wrong:" + key) % (n_real - 1)
            wrong_ids.append((sid + offset) % n_real)
            rows.append(row)
        if not rows:
            raise ValueError("Empty evaluation batch.")
        result = {}
        for key, pad in (("input_ids", self.pad_token_id), ("attention_mask", 0), ("labels", -100)):
            result[key] = pad_sequence([r[key][0] for r in rows], batch_first=True, padding_value=pad)
        result["species_id"] = torch.cat([r["species_id"] for r in rows])
        result["wrong_species_id"] = torch.tensor(wrong_ids, dtype=torch.long)
        return result


class FixedEvalDataset(IterableDataset):
    def __init__(self, panel_path: str, rank=None, world_size=None):
        super().__init__()
        self.rank = int(rank if rank is not None else os.environ.get("SLURM_PROCID", os.environ.get("RANK", 0)))
        self.world_size = int(world_size if world_size is not None else os.environ.get("SLURM_NTASKS", os.environ.get("WORLD_SIZE", 1)))
        self.rows = [line.encode("utf-8") for line in Path(panel_path).read_text().splitlines() if line.strip()]
        if not self.rows or len(self.rows) % self.world_size:
            raise ValueError("Fixed evaluation panel must be nonempty and divisible by world size.")
        if not 0 <= self.rank < self.world_size:
            raise ValueError("Invalid evaluation rank.")

    def __len__(self):
        return len(self.rows) // self.world_size

    def __iter__(self):
        info = get_worker_info()
        worker_id, n_workers = (0, 1) if info is None else (info.id, info.num_workers)
        rank_rows = self.rows[self.rank::self.world_size]
        for row in rank_rows[worker_id::n_workers]:
            yield {"json": row}


class Phase1Diagnostics(pl.Callback):
    def __init__(self, batches_per_epoch: int, stop_after_first_epoch=False):
        self.batches_per_epoch = batches_per_epoch
        self.stop_after_first_epoch = stop_after_first_epoch

    def on_train_start(self, trainer, module):
        if trainer.world_size != 8:
            raise RuntimeError(f"Expected eight distributed ranks; got {trainer.world_size}.")
        if trainer.is_global_zero:
            print("PHASE1_WORLD_SIZE", trainer.world_size, flush=True)
            self.print_norms(module)

    @staticmethod
    @torch.no_grad()
    def print_norms(module):
        token = module.model.get_input_embeddings().weight.detach().float()
        species = module.species_embed.weight[:module.hparams.unknown_species_id].detach().float()
        token_norm = token.norm(dim=-1).mean()
        species_norm = species.norm(dim=-1).mean()
        ratio = module.hparams.species_embed_scale * species_norm / token_norm.clamp_min(1e-12)
        values = {
            "token_norm_mean": float(token_norm), "real_species_norm_mean": float(species_norm),
            "species_scale": float(module.hparams.species_embed_scale), "scaled_species_to_token_ratio": float(ratio),
        }
        if not all(math.isfinite(v) for v in values.values()):
            raise FloatingPointError("Nonfinite embedding norms.")
        print("PHASE1_EMBEDDING_NORMS", json.dumps(values, sort_keys=True), flush=True)

    def on_train_epoch_start(self, trainer, module):
        self.epoch_start_step = trainer.global_step

    def on_train_epoch_end(self, trainer, module):
        steps = trainer.global_step - self.epoch_start_step
        if steps != self.batches_per_epoch:
            raise RuntimeError(
                f"Only {steps}/{self.batches_per_epoch} optimizer steps completed this epoch. "
                "A finite WebDataset rank may have exhausted its shards; do not silently shorten the schedule."
            )
        if trainer.is_global_zero:
            self.print_norms(module)
        if self.stop_after_first_epoch and trainer.current_epoch == 0:
            trainer.should_stop = True

    def on_validation_end(self, trainer, module):
        if trainer.sanity_checking:
            return
        names = ("test_loss", "test_acc", "test_top5_acc", "test_loss_correct", "test_loss_unknown",
                 "test_loss_wrong", "test_delta_unk", "test_delta_wrong")
        values = {k: float(trainer.callback_metrics[k]) for k in names if k in trainer.callback_metrics}
        if len(values) != len(names) or not all(math.isfinite(v) for v in values.values()):
            raise FloatingPointError(f"Missing/nonfinite aggregated evaluation metrics: {values}")
        values.update(epoch=int(trainer.current_epoch), global_step=int(trainer.global_step))
        if trainer.is_global_zero:
            print("PHASE1_VALIDATION", json.dumps(values, sort_keys=True), flush=True)
            target = Path(trainer.default_root_dir) / "validation_latest.json"
            target.parent.mkdir(parents=True, exist_ok=True)
            temporary = target.with_suffix(".tmp")
            temporary.write_text(json.dumps(values, indent=2) + "\n")
            temporary.replace(target)
            # Check the actual loaded CT2 model through the strict generation path.
            from transformers import PreTrainedTokenizerFast
            from strict_generation import predict_preserving_translation
            if not hasattr(self, '_generation_tokenizer'):
                self._generation_tokenizer = PreTrainedTokenizerFast(
                    tokenizer_file=str(Path(__file__).parent / 'CodonTransformerTokenizer.json'),
                    cls_token='[CLS]', sep_token='[SEP]', pad_token='[PAD]',
                    unk_token='[UNK]', mask_token='[MASK]',
                )
            protein = 'MACDEFGHIKLMNPQRSTVWY'
            dna = predict_preserving_translation(
                module.model, module.species_embed, self._generation_tokenizer, protein, 0,
                species_embed_scale=module.hparams.species_embed_scale,
            )
            check = {'global_step': int(trainer.global_step), 'protein': protein,
                     'dna': dna, 'genetic_code': 'standard', 'translation_matches': True}
            (target.parent / 'generation_check_latest.json').write_text(json.dumps(check, indent=2)+'\n')
            print('PHASE1_GENERATION_CHECK', json.dumps(check, sort_keys=True), flush=True)
