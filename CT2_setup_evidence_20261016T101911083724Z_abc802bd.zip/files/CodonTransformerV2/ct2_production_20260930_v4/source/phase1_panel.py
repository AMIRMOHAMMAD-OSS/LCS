"""Deterministic accepted-record selection shared by both preflights."""
from __future__ import annotations
import hashlib
import json
import random
from collections import Counter
from pathlib import Path
from phase1_tokens import RecordRejected, prepare_sequence, require_supervision, validate_vocabulary


def stable_seed(text):
    return int.from_bytes(hashlib.sha256(text.encode()).digest()[:8], "big") % (2**63-1)


def select_panel(cfg, vocab):
    validate_vocabulary(vocab)
    mapping = {str(k): int(v) for k, v in json.loads(Path(cfg["species_mapping"]).read_text()).items()}
    if set(mapping.values()) != set(range(cfg["num_organisms"])) or cfg["unknown_species_id"] != cfg["num_organisms"]:
        raise ValueError("Invalid real-species mapping")
    files = sorted(p for p in Path(cfg["test_json_dir"]).glob("*.json") if not p.name.startswith("._"))
    random.Random(cfg["seed"]).shuffle(files)
    selected, seen = [], set()
    rejected, events = Counter(), Counter()
    per_species, examples = {}, []
    examined = too_few = 0
    for path in files:
        org = json.loads(path.read_text())
        raw_species = org.get("species")
        sid = raw_species if isinstance(raw_species, int) else mapping.get(str(raw_species))
        if sid is None or not 0 <= sid < cfg["unknown_species_id"]:
            raise ValueError(f"Unmapped organism {raw_species!r} in {path}")
        if sid in seen:
            continue
        genes = org.get("genes", [])
        if len(genes) < cfg["eval_genes_per_species"]:
            too_few += 1
            continue
        indices = list(range(len(genes)))
        random.Random(stable_seed("genes:"+path.name)).shuffle(indices)
        accepted = []
        for index in indices:
            gene = genes[index]
            examined += 1
            try:
                prepared = prepare_sequence(gene.get("dna_sequence"), gene.get("protein_sequence"), vocab)
                require_supervision(prepared)
            except RecordRejected as exc:
                rejected[exc.reason] += 1
                counts = per_species.setdefault(str(raw_species), {})
                counts[exc.reason] = counts.get(exc.reason, 0)+1
                if len(examples) < 20:
                    examples.append({"file": str(path), "gene_index": index, "protein_id": gene.get("protein_id"), "reason": exc.reason, "error": str(exc)})
                continue
            record = {"species": raw_species, "genome_id": org.get("genome_id"),
                      "protein_id": gene.get("protein_id"), "dna_sequence": gene.get("dna_sequence"),
                      "protein_sequence": gene.get("protein_sequence"),
                      "eval_key": f"{path.name}:{index}:{gene.get('protein_id', '')}"}
            accepted.append((record, prepared))
            if len(accepted) == cfg["eval_genes_per_species"]:
                break
        if len(accepted) < cfg["eval_genes_per_species"]:
            too_few += 1
            continue
        for record, prepared in accepted:
            selected.append(record)
            events.update(prepared.events)
        seen.add(sid)
        if len(seen) == cfg["eval_species"]:
            break
    if len(seen) != cfg["eval_species"]:
        raise RuntimeError(f"Only {len(seen)}/{cfg['eval_species']} organisms have enough accepted genes")
    random.Random(cfg["seed"]+1).shuffle(selected)
    report = {"records_examined": examined, "accepted_records": len(selected), "distinct_species": len(seen),
              "excluded_records": sum(rejected.values()), "excluded_by_reason": dict(rejected),
              "excluded_by_species": per_species, "rejection_examples": examples,
              "ignored_target_positions": dict(events), "skipped_organisms_with_too_few_accepted_genes": too_few,
              "selected_records_sha256": hashlib.sha256(json.dumps(selected, sort_keys=True).encode()).hexdigest()}
    return selected, report
