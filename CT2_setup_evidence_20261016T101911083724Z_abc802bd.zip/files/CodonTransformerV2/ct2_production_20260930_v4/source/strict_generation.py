"""CT1-style synonymous decoding, always enabled, with a translation check.

Accepts an already loaded CT2 model and its separate species embedding. Uses
the standard-code alphabet and never changes or truncates the target protein.
"""
from __future__ import annotations
from phase1_tokens import AMINO_ACIDS, STANDARD_CODE, STOP_CODONS, codon_token, normalize_protein


def checked_protein(protein):
    protein = normalize_protein(protein)
    if set(protein) - AMINO_ACIDS:
        raise ValueError("Exact translation requires a fully specified protein; ambiguous residues are not replaced")
    return protein


def allowed_ids(protein, vocab):
    result = []
    for aa in checked_protein(protein) + "*":
        ids = [vocab[codon_token(c)] for c, residue in STANDARD_CODE.items() if residue == aa and codon_token(c) in vocab]
        if not ids:
            raise ValueError(f"No supported codons for {aa}")
        result.append(ids)
    return result


def validate_generated_dna(dna, protein):
    protein = checked_protein(protein)
    if not isinstance(dna, str) or len(dna) != 3*(len(protein)+1) or set(dna)-set("ACGT"):
        raise ValueError("Generated DNA has invalid characters or length")
    codons = [dna[i:i+3] for i in range(0, len(dna), 3)]
    if codons[-1] not in STOP_CODONS:
        raise ValueError("Generated DNA has no terminal stop")
    if "".join(STANDARD_CODE[c] for c in codons[:-1]) != protein:
        raise ValueError("Generated DNA does not translate exactly to the supplied protein")
    return dna


def decode_logits(logits, protein, vocab, *, sample=False, temperature=1.0, top_p=1.0, generator=None):
    import torch
    protein = checked_protein(protein)
    choices = allowed_ids(protein, vocab)
    if logits.ndim != 2 or logits.shape[0] != len(choices):
        raise ValueError("Logits need one row per amino acid plus terminal stop")
    if not temperature > 0 or not 0 < top_p <= 1:
        raise ValueError("temperature must be positive and top_p must lie in (0,1]")
    index_to_token = {index: token for token, index in vocab.items()}
    result = []
    for row, ids in zip(logits, choices):
        values = row[ids].float()
        if not torch.isfinite(values).all():
            raise ValueError("Nonfinite logits for allowed codons")
        if sample:
            probabilities = torch.softmax((values-values.max())/temperature, dim=-1)
            probabilities, order = probabilities.sort(descending=True)
            probabilities[(probabilities.cumsum(-1)-probabilities) >= top_p] = 0
            selected = int(order[torch.multinomial(probabilities, 1, generator=generator)])
        else:
            selected = int(values.argmax())
        result.append(index_to_token[ids[selected]][-3:].upper())
    return validate_generated_dna("".join(result), protein)


def predict_preserving_translation(model, species_embed, tokenizer, protein, species_id, *, species_embed_scale,
                                   sample=False, temperature=1.0, top_p=1.0, generator=None):
    import torch
    protein = checked_protein(protein)
    vocab = tokenizer.get_vocab()
    tokens = [f"{aa.lower()}_unk" for aa in protein] + ["__unk"]
    ids = [tokenizer.cls_token_id] + [vocab[token] for token in tokens] + [tokenizer.sep_token_id]
    if len(ids) > model.config.max_position_embeddings:
        raise ValueError("Protein exceeds model context; no truncation allowed")
    device = model.get_input_embeddings().weight.device
    if not 0 <= species_id < species_embed.num_embeddings:
        raise ValueError("Invalid species embedding index")
    states = model.training, species_embed.training
    model.eval()
    species_embed.eval()
    try:
        with torch.inference_mode():
            input_ids = torch.tensor([ids], dtype=torch.long, device=device)
            embeddings = model.get_input_embeddings()(input_ids)
            species = species_embed(torch.tensor([species_id], device=device)) * species_embed_scale
            logits = model(inputs_embeds=embeddings+species[:, None, :], attention_mask=torch.ones_like(input_ids)).logits[0, 1:-1]
            return decode_logits(logits, protein, vocab, sample=sample, temperature=temperature, top_p=top_p, generator=generator)
    finally:
        model.train(states[0])
        species_embed.train(states[1])
