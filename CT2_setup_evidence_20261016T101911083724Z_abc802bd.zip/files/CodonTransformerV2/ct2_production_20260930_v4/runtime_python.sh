#!/bin/bash
# Run on each allocated node so cache creation also covers remote Slurm ranks.
set -euo pipefail
: "${SLURM_JOB_ID:?Use this wrapper inside a Slurm allocation}"
# Set before importing Torch or initializing CUDA on every rank/node.
export CUBLAS_WORKSPACE_CONFIG=:4096:8
ct2_cache_root="${SLURM_TMPDIR:-/tmp}/ct2-${UID}-${SLURM_JOB_ID}"
export TMPDIR="${SLURM_TMPDIR:-/tmp}"
export XDG_CACHE_HOME="$ct2_cache_root/xdg"
export HF_HOME="$ct2_cache_root/huggingface"
export HF_HUB_CACHE="$HF_HOME/hub"
export HF_DATASETS_CACHE="$HF_HOME/datasets"
export TRANSFORMERS_CACHE="$HF_HUB_CACHE"
export TORCH_HOME="$ct2_cache_root/torch"
export TORCHINDUCTOR_CACHE_DIR="$ct2_cache_root/torchinductor"
export TRITON_CACHE_DIR="$ct2_cache_root/triton"
export TRITON_HOME="$ct2_cache_root/triton-home"
export CUDA_CACHE_PATH="$ct2_cache_root/cuda"
export PYTHONDONTWRITEBYTECODE=1
mkdir -p "$XDG_CACHE_HOME" "$HF_HOME" "$HF_HUB_CACHE" "$HF_DATASETS_CACHE" \
    "$TORCH_HOME" "$TORCHINDUCTOR_CACHE_DIR" "$TRITON_CACHE_DIR" "$TRITON_HOME" "$CUDA_CACHE_PATH"
if [[ "${SLURM_PROCID:-0}" == 0 ]]; then
    printf 'CT2_RUNTIME_CACHE: %s\n' "$ct2_cache_root"
fi
exec python "$@"
