#!/usr/bin/env python3
"""Run one production allocation; gate new stages inside the same allocation."""
from __future__ import annotations
import argparse
import json
import os
import subprocess
import time
from pathlib import Path
from common import ROOT, STAGES, load_run, stage_start, atomic_json
from production import verify_inherited_preflight, verify_pause, coverage, POLICY

def distributed(*args):
    subprocess.run(['srun','--kill-on-bad-exit=1','bash','runtime_python.sh','-u',*map(str,args)],check=True,cwd=ROOT)

def entry_checks(cfg,stage,job):
    if stage==0:
        stamp=verify_inherited_preflight(cfg)
        print('USING_INHERITED_STAGE0_VALIDATION:',stamp['job_id'],flush=True);return
    path=ROOT/f'preflight_{STAGES[stage]["name"]}_passed.json'
    if path.exists():
        stamp=json.loads(path.read_text())
        expected=Path(cfg['output'])/'preflight'/STAGES[stage]['name']/('job_'+str(stamp.get('job_id')))
        if (stamp.get('fingerprint')!=cfg['fingerprint'] or stamp.get('stage')!=stage
                or stamp.get('comparison_passed') is not True or Path(stamp.get('output',''))!=expected
                or stamp.get('execution_profile')!=cfg['execution_profile']
                or stamp.get('weight_and_moment_tolerance')!={'rtol':1e-5,'atol':2e-6}
                or stamp.get('exact_rng_and_stream_match') is not True
                or json.loads((expected/'resume_comparison.json').read_text())!=stamp):
            raise ValueError('Stage-entry evidence is inconsistent')
        print('USING_STAGE_ENTRY_VALIDATION:',stamp['job_id'],flush=True);return
    out=Path(cfg['output'])/'preflight'/STAGES[stage]['name']/('job_'+job)
    out.mkdir(parents=True,exist_ok=False)
    print('STAGE_ENTRY_CHECKS_IN_THIS_ALLOCATION:',STAGES[stage]['name'],flush=True)
    distributed('preflight.py','--stage',stage,'--output',out)
    distributed('train.py','--stage',stage,'--mode','smoke-reference','--stop-after',32,
                '--validation-max-length','--eval-interval',32,'--checkpoint-interval',16,'--output',out/'reference')
    distributed('train.py','--stage',stage,'--mode','smoke-resume','--stop-after',32,
                '--validation-max-length','--eval-interval',32,'--checkpoint-interval',16,'--output',out/'resumed',
                '--resume',out/'reference'/f'step_{stage_start(stage)+16:06d}.ckpt')
    from checks import compare
    compare(cfg,stage,out)

def run(stage):
    from checks import inputs, completed
    from model_io import read_checkpoint
    from production_submit import queue
    started=time.monotonic();cfg=load_run();job=os.environ['SLURM_JOB_ID'];inputs(cfg)
    out=Path(cfg['output'])/'training'/STAGES[stage]['name']
    # Recover final verification if a previous allocation finished training but
    # stopped between completed.json and its final CPU verification.
    if (out/'completed.json').exists():
        completed(cfg,stage);return
    entry_checks(cfg,stage,job)
    entry=0
    if (out/'last.ckpt').exists():
        entry=read_checkpoint(out/'last.ckpt')['stage_step']
    elif stage==0 and cfg.get('adopt_checkpoint'):
        from production import adopt_checkpoint
        entry=adopt_checkpoint(cfg)['stage_step']
    remaining=max(60.,POLICY['training_seconds']-(time.monotonic()-started))
    distributed('train.py','--stage',stage,'--resume','auto','--max-runtime-seconds',remaining)
    if (out/'completed.json').exists():
        completed(cfg,stage)
        atomic_json(out/'coverage.json',coverage(read_checkpoint(out/'last.ckpt')))
        print('PRODUCTION_STAGE_FINISHED:',STAGES[stage]['name'],flush=True)
        print('Review python3 submit.py report before explicitly advancing.',flush=True)
    else:
        verify_pause(cfg,stage,job,entry)
        queue(cfg,'resume',stage,parent_job=job)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--stage',type=int,choices=range(len(STAGES)),required=True)
    run(p.parse_args().stage)
