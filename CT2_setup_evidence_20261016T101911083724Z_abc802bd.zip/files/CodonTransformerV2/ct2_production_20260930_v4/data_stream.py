"""Single-process-per-rank tar stream with checkpointed cursor and shuffle buffer."""
from __future__ import annotations
import copy
import hashlib
import json
import random
import tarfile
from collections import Counter
from pathlib import Path
from common import stable_seed, resolve_species
from phase1_tokens import prepare_sequence, require_supervision, RecordRejected

def shard_order(count,seed,cycle,rank,world):
    order=list(range(count)); random.Random(stable_seed(f'shards:{seed}:{cycle}')).shuffle(order)
    return order[rank::world]

class RecordStream:
    def __init__(self,paths,vocab,mapping,n_real,rank,world,seed=123,buffer_size=1024):
        if not 0<=rank<world or len(paths)<world or buffer_size<1: raise ValueError('Invalid stream geometry')
        self.paths=[str(Path(p)) for p in paths]
        self.identity=hashlib.sha256(json.dumps(self.paths).encode()).hexdigest()
        self.vocab,self.mapping,self.n_real=vocab,mapping,n_real
        self.rank,self.world,self.seed,self.buffer_size=rank,world,seed,buffer_size
        self.cycle=self.shard_pos=self.record_pos=0
        self.buffer=[]; self.rng=random.Random(stable_seed(f'buffer:{seed}:{rank}'))
        self.counts=Counter(); self.species=Counter(); self.events=Counter(); self.shards=set()
        self.rejection_examples=[]; self.chain='0'*64; self._iterator=None; self._order_cache=None

    @staticmethod
    def _records(path):
        seen=set()
        with tarfile.open(path,mode='r|gz') as archive:
            for member in archive:
                if not member.isfile() or not member.name.endswith('.json'): continue
                if member.name in seen: raise ValueError(f'Duplicate JSON member: {path}:{member.name}')
                seen.add(member.name)
                if member.size>16*1024*1024: raise ValueError(f'Oversized JSON record: {member.name}')
                raw=archive.extractfile(member)
                if raw is None: raise ValueError('Unreadable JSON tar member')
                doc=json.loads(raw.read())
                if not isinstance(doc,dict): raise ValueError('Training record must be a JSON object')
                yield {'json':doc,'key':member.name}
        if not seen: raise ValueError(f'Shard has no JSON records: {path}')

    def _next_raw(self):
        while True:
            if self._order_cache is None or self._order_cache[0]!=self.cycle:
                self._order_cache=(self.cycle,shard_order(len(self.paths),self.seed,self.cycle,self.rank,self.world))
            order=self._order_cache[1]
            if self.shard_pos>=len(order):
                self.cycle+=1; self.shard_pos=self.record_pos=0; self._iterator=None
                continue
            shard=order[self.shard_pos]
            if self._iterator is None:
                self._iterator=self._records(self.paths[shard])
                for _ in range(self.record_pos):
                    try: next(self._iterator)
                    except StopIteration: raise RuntimeError('Saved cursor exceeds shard contents') from None
            try: record=next(self._iterator)
            except StopIteration:
                self.shard_pos+=1; self.record_pos=0; self._iterator=None
                continue
            self.record_pos+=1
            record.update(shard=shard,cycle=self.cycle)
            return record

    def _next_buffered(self):
        while len(self.buffer)<self.buffer_size: self.buffer.append(self._next_raw())
        index=self.rng.randrange(len(self.buffer))
        result=self.buffer[index]
        self.buffer[index]=self._next_raw()
        return result

    def next_accepted(self,max_length):
        for _ in range(1_000_000):
            record=self._next_buffered(); doc=record['json']
            sid=resolve_species(doc.get('species'),self.mapping,self.n_real)
            self.counts['examined']+=1
            try:
                dna=doc.get('dna_sequence') or doc.get('seq') or doc.get('dna') or doc.get('sequence')
                prepared=prepare_sequence(dna,doc.get('protein_sequence'),self.vocab)
                require_supervision(prepared,max_length)
            except RecordRejected as error:
                self.counts['excluded']+=1; self.counts[error.reason]+=1
                if len(self.rejection_examples)<20:
                    self.rejection_examples.append({'shard':record['shard'],'key':record['key'],'reason':error.reason})
                continue
            self.counts['accepted']+=1; self.species[sid]+=1; self.events.update(prepared.events)
            self.shards.add(record['shard'])
            identity=f"{record['cycle']}:{record['shard']}:{record['key']}".encode()
            self.chain=hashlib.sha256(bytes.fromhex(self.chain)+identity+b'\n').hexdigest()
            return {'prepared':prepared,'species_id':sid,'identity':identity.decode()}
        raise RuntimeError('No accepted record in one million examined records')

    def batch(self,n,length): return [self.next_accepted(length) for _ in range(n)]

    def state_dict(self):
        return copy.deepcopy(dict(version=1,identity=self.identity,rank=self.rank,world=self.world,seed=self.seed,
            buffer_size=self.buffer_size,cycle=self.cycle,shard_pos=self.shard_pos,record_pos=self.record_pos,
            buffer=self.buffer,rng=self.rng.getstate(),counts=dict(self.counts),species=dict(self.species),
            events=dict(self.events),shards=sorted(self.shards),rejection_examples=self.rejection_examples,chain=self.chain))

    def load_state_dict(self,state):
        for key in ('identity','rank','world','seed','buffer_size'):
            if state[key]!=getattr(self,key): raise ValueError(f'Incompatible stream {key}')
        if state['version']!=1: raise ValueError('Unknown stream version')
        if self._iterator is not None: self._iterator.close()
        self._iterator=None
        for key in ('cycle','shard_pos','record_pos','buffer','rejection_examples','chain'):
            setattr(self,key,copy.deepcopy(state[key]))
        self.rng.setstate(state['rng'])
        for key in ('counts','species','events'): setattr(self,key,Counter(state[key]))
        self.shards=set(state['shards'])

    def summary(self):
        return dict(rank=self.rank,counts=dict(self.counts),per_species=dict(self.species),
            ignored_positions=dict(self.events),distinct_shards=len(self.shards),shard_ids=sorted(self.shards),
            chain=self.chain,cursor=dict(cycle=self.cycle,shard_position=self.shard_pos,json_position=self.record_pos),
            buffered_records=len(self.buffer),rejection_examples=self.rejection_examples,
            scope='Consumed training draws since continuation start; not unique biological genes. Cursor includes saved buffered reads.')
