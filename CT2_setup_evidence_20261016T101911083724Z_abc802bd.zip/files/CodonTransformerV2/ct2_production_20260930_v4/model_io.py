"""Strict model identities and optimizer import for the reviewed ModernBERT CT2."""
from __future__ import annotations
import math
from pathlib import Path
import torch
from common import ROOT, sha
from phase1_tokens import validate_vocabulary, STANDARD_CODE, codon_token

class CT2(torch.nn.Module):
    def __init__(self,model,n_species,scale):
        super().__init__(); self.model=model
        self.species_embed=torch.nn.Embedding(n_species,model.config.hidden_size)
        self.scale=float(scale)
        if not math.isfinite(self.scale) or self.scale<=0: raise ValueError('Invalid species scale')

    def forward(self,input_ids,attention_mask,species_id=None,zero=False):
        vectors=self.model.get_input_embeddings()(input_ids)
        if not zero: vectors=vectors+self.species_embed(species_id)[:,None,:]*self.scale
        return self.model(inputs_embeds=vectors,attention_mask=attention_mask).logits

def tokenizer_at(root=ROOT):
    from transformers import PreTrainedTokenizerFast
    tok=PreTrainedTokenizerFast(tokenizer_file=str(Path(root)/'source/CodonTransformerTokenizer.json'),
        bos_token='[CLS]',eos_token='[SEP]',cls_token='[CLS]',sep_token='[SEP]',pad_token='[PAD]',unk_token='[UNK]',mask_token='[MASK]')
    validate_vocabulary(tok.get_vocab())
    probe=tok('m_atg __taa',add_special_tokens=True)['input_ids']
    if probe!=[tok.cls_token_id,tok.get_vocab()['m_atg'],tok.get_vocab()['__taa'],tok.sep_token_id]:
        raise ValueError('Unexpected token framing')
    return tok

def read_checkpoint(path):
    # Only run on the user's own checkpoints named in the sealed run.
    return torch.load(path,map_location='cpu',weights_only=False,mmap=True)

def build_model(checkpoint,tokenizer,cfg,device='cpu',source_name=None):
    from transformers import ModernBertConfig, ModernBertForMaskedLM
    if 'ct2_format' in checkpoint:
        if checkpoint['ct2_format']!=1 or checkpoint['fingerprint']!=cfg['fingerprint']:
            raise ValueError('Continuation checkpoint belongs to a different sealed run')
        if checkpoint['mapping_sha256']!=cfg['mapping_sha256']: raise ValueError('Checkpoint mapping mismatch')
        if cfg.get('version')==3:
            from execution import PROFILE, validate_snapshot
            if checkpoint.get('execution_profile')!=PROFILE: raise ValueError('Checkpoint execution profile mismatch')
            validate_snapshot(checkpoint.get('execution_settings',{}))
        config=ModernBertConfig(**checkpoint['model_config'])
        scale=checkpoint['species_embed_scale']
    else:
        if source_name not in ('epoch_6','epoch_9'): raise ValueError('Historical checkpoint needs verified Phase-1 provenance')
        expected=(int(source_name[-1])+1)*8000
        if checkpoint.get('global_step')!=expected or checkpoint.get('epoch')!=int(source_name[-1]):
            raise ValueError('Unexpected source checkpoint step/epoch')
        hp=checkpoint['hyper_parameters']; scale=float(hp['species_embed_scale'])
        if hp['unknown_species_id']!=26678 or hp['n_species_total']!=28678: raise ValueError('Checkpoint species space mismatch')
        config=ModernBertConfig(vocab_size=len(tokenizer),pad_token_id=tokenizer.pad_token_id,
            sep_token_id=tokenizer.sep_token_id,cls_token_id=tokenizer.cls_token_id,
            max_position_embeddings=2048,attn_implementation='sdpa')
    config._attn_implementation='sdpa'
    config.reference_compile=False
    if not math.isclose(scale,.0347,rel_tol=0,abs_tol=1e-12): raise ValueError('Unexpected checkpoint species scale')
    if config.vocab_size!=len(tokenizer) or config.max_position_embeddings!=2048: raise ValueError('Architecture contract changed')
    model=CT2(ModernBertForMaskedLM(config),28678,scale)
    state=dict(checkpoint['state_dict'])
    buffer=state.pop('codon_id_to_aa_id',None)
    if buffer is not None:
        expected=torch.full((len(tokenizer),),-1,dtype=torch.long); vocab=tokenizer.get_vocab()
        for codon,aa in STANDARD_CODE.items(): expected[vocab[codon_token(codon)]]=vocab['__unk' if aa=='*' else f'{aa.lower()}_unk']
        if not torch.equal(buffer,expected): raise ValueError('Unexpected codon-to-amino-acid checkpoint buffer')
    model.load_state_dict(state,strict=True)
    for name,tensor in model.state_dict().items():
        if tensor.is_floating_point() and not torch.isfinite(tensor).all(): raise FloatingPointError(f'Nonfinite source tensor: {name}')
    return model.to(device)

def optimizer_for(model,checkpoint=None):
    groups=[list(model.model.parameters()),list(model.species_embed.parameters())]
    optimizer=torch.optim.AdamW([{'params':groups[0],'weight_decay':.01},{'params':groups[1],'weight_decay':0.}],lr=2e-5)
    names=[[f'model.{n}' for n,_ in model.model.named_parameters()],['species_embed.weight']]
    if checkpoint is not None:
        saved=checkpoint['optimizer_states']
        if len(saved)!=1: raise ValueError('Expected one AdamW optimizer')
        saved=saved[0]
        if checkpoint.get('optimizer_parameter_names',names)!=names: raise ValueError('Optimizer parameter order mismatch')
        if len(saved['param_groups'])!=2: raise ValueError('Optimizer groups mismatch')
        for group,params in zip(saved['param_groups'],groups):
            if len(group['params'])!=len(params): raise ValueError('Optimizer group size mismatch')
            if tuple(group['betas'])!=(.9,.999) or group['eps']!=1e-8 or group.get('amsgrad',False):
                raise ValueError('Unexpected AdamW hyperparameters')
            for identifier,param in zip(group['params'],params):
                state=saved['state'][identifier]
                for key in ('exp_avg','exp_avg_sq'):
                    if state[key].shape!=param.shape or not torch.isfinite(state[key]).all(): raise ValueError('Invalid AdamW moment')
                if int(state['step'])!=int(checkpoint['global_step']): raise ValueError('AdamW counter mismatch')
        optimizer.load_state_dict(saved)
        if optimizer.param_groups[0]['weight_decay']!=.01 or optimizer.param_groups[1]['weight_decay']!=0.:
            raise ValueError('Unexpected AdamW decay groups')
    return optimizer,names

def initial_checkpoint(cfg,name=None):
    name=name or cfg['initialization']
    spec=cfg['checkpoints'][name]; path=Path(spec['path']); stat=path.stat()
    if [stat.st_size,stat.st_mtime_ns]!=spec['stat'] or sha(path)!=spec['sha256']:
        raise RuntimeError(f'Phase-1 checkpoint changed: {path}')
    return read_checkpoint(path)
