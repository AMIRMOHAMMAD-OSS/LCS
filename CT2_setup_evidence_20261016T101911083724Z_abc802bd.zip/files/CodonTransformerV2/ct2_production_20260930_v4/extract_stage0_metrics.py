import json
from pathlib import Path
import pandas as pd

ROOT = Path(
"/lustre/fswork/projects/rech/nef/unh87ms/ct2_retrain/ct2_production_20260930_v4/training/fullmask512"
)

rows=[]

for f in sorted(ROOT.glob("evaluation_*.json")):
    if "latest" in f.name:
        continue

    x=json.loads(f.read_text())

    for length,panel in x["panels"].items():

        for mode,block in panel["modes"].items():

            for condition,metrics in block["conditions"].items():

                row={
                    "file": f.name,
                    "step": x["continuation_step"],
                    "length": length,
                    "mode": mode,
                    "condition": condition,
                    "species_embed_scale": x["species_embed_scale"]
                }

                for k,v in metrics.items():
                    if isinstance(v,(int,float)):
                        row[k]=v

                rows.append(row)

df=pd.DataFrame(rows)

out="stage0_fullmask512_eval/full_evaluation_metrics.csv"
df.to_csv(out,index=False)

print("saved:",out)
print("shape:",df.shape)
print(df.head())
print(df.columns.tolist())
