"""Protein-preserving paired inputs using the existing 90-token vocabulary."""
from __future__ import annotations
import itertools
from collections import Counter
from dataclasses import dataclass

AMINO_ACIDS = frozenset('ACDEFGHIKLMNPQRSTVWY')
STANDARD_CODE = dict(zip(
    (''.join(parts) for parts in itertools.product('TCAG', repeat=3)),
    'FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG',
))
STOP_CODONS = frozenset(c for c, aa in STANDARD_CODE.items() if aa == '*')
ALTERNATIVE_START_CODONS = frozenset({'GTG', 'TTG', 'CTG', 'ATT', 'ATC', 'ATA'})
IUPAC_DNA = frozenset('ACGTRYSWKMBDHVN')
TOKEN_POLICY = 'preserve_protein_positions_standard_code_v3'


class RecordRejected(ValueError):
    def __init__(self, reason, detail):
        self.reason = reason
        super().__init__(f'{reason}: {detail}')


@dataclass(frozen=True)
class PreparedSequence:
    text: str
    target_positions: tuple[int, ...]
    ignored_positions: tuple[int, ...]
    events: dict


def codon_token(codon):
    aa = STANDARD_CODE[codon]
    return f'__{codon.lower()}' if aa == '*' else f'{aa.lower()}_{codon.lower()}'


def validate_vocabulary(vocab):
    required = {codon_token(c) for c in STANDARD_CODE}
    required |= {f'{aa.lower()}_unk' for aa in AMINO_ACIDS} | {'__unk'}
    required |= {'[UNK]', '[CLS]', '[SEP]', '[PAD]', '[MASK]'}
    if set(vocab) != required:
        raise ValueError(f'Expected CT1 exact 90-token alphabet; missing={sorted(required-set(vocab))}, extra={sorted(set(vocab)-required)}')


def normalize_sequence(value, field):
    if not isinstance(value, str) or not value.strip():
        raise RecordRejected('missing_sequence', f'{field} must be a nonempty string')
    return ''.join(value.split()).upper()


def normalize_protein(protein):
    protein = normalize_sequence(protein, 'protein_sequence')
    if protein[-1] in '*_':
        protein = protein[:-1]
    if not protein:
        raise RecordRejected('empty_protein', 'no amino acids before terminal stop')
    return protein


def prepare_sequence(dna, protein, vocab):
    dna = normalize_sequence(dna, 'dna_sequence').replace('U', 'T')
    protein = normalize_protein(protein)
    if len(dna) % 3:
        raise RecordRejected('dna_length', f'{len(dna)} bases is not divisible by three')
    if set(dna) - IUPAC_DNA:
        raise RecordRejected('invalid_dna', f'invalid characters: {sorted(set(dna)-IUPAC_DNA)}')
    codons = [dna[i:i+3] for i in range(0, len(dna), 3)]
    terminal = codons[-1] in STOP_CODONS
    body = codons[:-1] if terminal else codons
    if len(body) != len(protein):
        raise RecordRejected('length_mismatch', f'DNA has {len(body)} residue codons and protein has {len(protein)} residues; terminal stop handled separately')
    for index, codon in enumerate(body):
        if codon in STOP_CODONS:
            raise RecordRejected('internal_stop', f'{codon} at residue position {index+1}')
    invalid = sorted(set(protein) - AMINO_ACIDS)
    if invalid:
        raise RecordRejected('unresolved_protein', f'unsupported residues: {invalid}; no amino-acid substitution')
    tokens, targets, ignored = [], [], []
    events = Counter()
    for index, (aa, codon) in enumerate(zip(protein, body)):
        if set(codon) - set('ACGT'):
            token = f'{aa.lower()}_unk'
            ignored.append(index)
            events['unknown_codon_positions'] += 1
        elif index == 0 and aa == 'M' and codon in ALTERNATIVE_START_CODONS:
            token = 'm_unk'
            ignored.append(index)
            events['alternative_start_positions'] += 1
        elif STANDARD_CODE[codon] == aa:
            token = codon_token(codon)
            targets.append(index)
        else:
            raise RecordRejected('translation_mismatch', f'{aa.lower()}_{codon.lower()} at residue position {index+1}')
        if token not in vocab:
            raise ValueError(f'Required input token is missing: {token}')
        tokens.append(token)
    # CT1 merged inputs include a terminal stop, even when its codon is unknown.
    token = codon_token(codons[-1]) if terminal else '__unk'
    if token not in vocab:
        raise ValueError(f'Required terminal token is missing: {token}')
    tokens.append(token)
    if terminal:
        targets.append(len(protein))
    else:
        ignored.append(len(protein))
        events['unknown_terminal_stop_positions'] += 1
    return PreparedSequence(' '.join(tokens), tuple(targets), tuple(ignored), dict(events))


def require_supervision(prepared, max_length=512):
    limit = max_length - 2 if max_length is not None else len(prepared.text.split())
    if not any(index < limit for index in prepared.target_positions):
        raise RecordRejected('no_targets_in_window', 'no known codon target survives truncation')


def build_checked_token_text(dna, protein, vocab):
    prepared = prepare_sequence(dna, protein, vocab)
    return prepared.text, prepared.events
