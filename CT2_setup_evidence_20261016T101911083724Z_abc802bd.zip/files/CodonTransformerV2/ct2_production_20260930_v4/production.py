"""Production provenance, checkpoint adoption, and allocation receipts."""
from __future__ import annotations
import copy
import json
from pathlib import Path
from common import ROOT, STAGES, fingerprint, sha, atomic_json, stage_start
from execution import PROFILE, validate_snapshot

PARENT_FINGERPRINT='062fb5c25fa9a67f8f79faee0b9502fc72054140cc30735ebf0fb61ce104c47c'
OLD_STEPS=[8000,8000,8000,8000,12000]
POLICY={'allocation_hours':20,'training_seconds':61200,'automatic_same_stage_resume':True,
        'automatic_stage_advance':False,'stage_entry_checks':'inherit_stage0; check_later_stages_in_training_allocation'}
CORE=('engine.py','model_io.py','execution.py','data_stream.py','augmentation.py','phase1_tokens.py',
      'strict_generation.py','generation.py','evaluation.py','diagnostic_metrics.py',
      'runtime_python.sh','preflight.py','checks.py')

def validate_pass(stamp,parent,hardware,comparison):
    if stamp!=comparison:raise ValueError('Preflight stamp and comparison disagree')
    expected={'fingerprint':parent['fingerprint'],'stage':0,'updates':32,'resume_boundary':16,
              'comparison_passed':True,'exact_rng_and_stream_match':True,
              'weight_and_moment_tolerance':{'rtol':1e-5,'atol':2e-6},'execution_profile':PROFILE}
    for key,value in expected.items():
        if stamp.get(key)!=value:raise ValueError('Invalid inherited preflight '+key)
    if hardware.get('fingerprint')!=parent['fingerprint'] or hardware.get('stage')!=0:
        raise ValueError('Hardware proof belongs to another run')
    if sorted(row['rank'] for row in hardware['memory'])!=list(range(8)):
        raise ValueError('Inherited hardware proof must contain eight ranks')
    for row in hardware['memory']:
        validate_snapshot(row['execution_settings'])
        if 'H100' not in row['gpu']:raise ValueError('Inherited proof is not from H100s')

def verify_inherited_preflight(cfg,root=ROOT):
    root=Path(root);proof=root/'inherited_validation'
    parent=json.loads((root/'parent_v3_run.json').read_text())
    if parent['fingerprint']!=fingerprint(parent) or parent['fingerprint']!=PARENT_FINGERPRINT:
        raise ValueError('Unexpected sealed v3 parent')
    if cfg.get('production_revision')!=4 or cfg.get('production_policy')!=POLICY or cfg['stages']!=STAGES:
        raise ValueError('Unexpected production schedule/policy')
    if parent['stages']!=[dict(s,steps=n) for s,n in zip(STAGES,OLD_STEPS)]:
        raise ValueError('Unexpected parent curriculum')
    for key in ('source_fingerprint','source_step','initialization','seed','world_size','batch_divisor',
                'shuffle_buffer','data_root','shards','mapping_sha256','checkpoints','execution_profile'):
        if cfg[key]!=parent[key]:raise ValueError('Production changed validated setting: '+key)
    manifest=json.loads((root/'validated_v3_program_hashes.json').read_text())
    for rel in CORE:
        if sha(root/rel)!=manifest[rel] or parent['hashes'][rel]!=manifest[rel]:
            raise ValueError('Validated numerical/data code changed: '+rel)
    read=lambda name:json.loads((proof/name).read_text())
    stamp=read('preflight_pass.json')
    validate_pass(stamp,parent,read('hardware_checks.json'),read('resume_comparison.json'))
    receipt=read('accounting.json')
    if receipt!={'job_id':stamp['job_id'],'state':'COMPLETED','exit_code':'0:0'}:
        raise ValueError('Missing successful parent Slurm accounting')
    if cfg['inherited_preflight']['job_id']!=stamp['job_id']:
        raise ValueError('Inherited job identity mismatch')
    return stamp

def adopt_checkpoint(cfg,root=ROOT):
    """Import only a verified actual stage-0 checkpoint; preserve all training state."""
    from model_io import read_checkpoint
    from checks import check_checkpoint
    info=cfg['adopt_checkpoint'];path=Path(info['path'])
    if sha(path)!=info['sha256']:raise ValueError('Imported training checkpoint changed')
    cp=read_checkpoint(path);parent=json.loads((Path(root)/'parent_v3_run.json').read_text())
    k=cp.get('stage_step',0)
    if cp.get('stage')!=0 or not 0<k<=OLD_STEPS[0]:raise ValueError('Only actual v3 stage-0 progress can be imported')
    check_checkpoint(cp,parent,0,k,'full')
    if cp.get('mapping_sha256')!=cfg['mapping_sha256']:raise ValueError('Imported mapping mismatch')
    result=dict(cp);result['fingerprint']=cfg['fingerprint']
    result['statistics']=copy.deepcopy(cp['statistics'])
    result['statistics']['production_origin']={'fingerprint':parent['fingerprint'],
        'checkpoint_sha256':info['sha256'],'imported_updates':k}
    rates=[float(g['lr']) for g in cp['optimizer_states'][0]['param_groups']]
    if len(rates)!=2 or rates[0]!=rates[1]:raise ValueError('Imported optimizer learning rates differ')
    if k>=STAGES[0]['warmup']:
        if not STAGES[0]['lr'][1]<=rates[0]<=STAGES[0]['lr'][0]:raise ValueError('Unexpected imported learning rate')
        result['statistics']['production_lr_anchor']={'completed':k,'lr':rates[0]}
    return result

def coverage(cp):
    rows=[]
    for local in cp['rank_states']:
        s=local['stream'];cycles=[s['cycle']]+[r['cycle'] for r in s['buffer']]
        rows.append({'rank':s['rank'],'completed_raw_cycles':min(cycles),
                     'accepted':s['counts']['accepted'],'examined':s['counts']['examined']})
    return {'completed_raw_cycles_all_ranks':min(r['completed_raw_cycles'] for r in rows),'ranks':rows,
        'meaning':'All JSON records of these prior shard cycles were examined, including exclusions. '
                  'This is not biological deduplication or full-length residue coverage.'}

def verify_pause(cfg,stage,job,entry_step,root=ROOT):
    from model_io import read_checkpoint
    from checks import check_checkpoint
    out=Path(cfg['output'])/'training'/STAGES[stage]['name']
    progress=json.loads((out/'progress.json').read_text())
    if (progress.get('job_id')!=job or progress.get('fingerprint')!=cfg['fingerprint']
            or progress.get('stopped_by_signal') is not True
            or not entry_step<progress['stage_step']<STAGES[stage]['steps']):
        raise ValueError('No fresh intentional pause from this allocation')
    cp=read_checkpoint(out/'last.ckpt');check_checkpoint(cp,cfg,stage,progress['stage_step'],'full')
    if progress['continuation_step']!=cp['continuation_step']:raise ValueError('Pause counters disagree')
    receipt={'fingerprint':cfg['fingerprint'],'job_id':job,'stage':stage,'stage_step':cp['stage_step'],
             'continuation_step':cp['continuation_step'],'checkpoint_sha256':sha(out/'last.ckpt')}
    atomic_json(out/'coverage.json',coverage(cp))
    atomic_json(out/('pause_'+job+'.json'),receipt)
    return receipt
