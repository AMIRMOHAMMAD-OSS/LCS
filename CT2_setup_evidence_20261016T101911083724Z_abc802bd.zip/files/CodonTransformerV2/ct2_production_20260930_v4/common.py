"""Immutable run settings and small filesystem helpers; standard library only."""
from __future__ import annotations
import hashlib
import json
import math
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULT_SOURCE = '/lustre/fswork/projects/rech/nef/unh87ms/CodonTransformerV2/phase1_runs/phase1_final_20260921_190347'
SOURCE_FINGERPRINT = '26c847835c9bcd94c1c2345c383610dc15d641d64dfdac9796a58ec8ba02935b'
VERSIONS = {'torch': '2.6.0', 'transformers': '4.51.3', 'lightning': '2.5.0.post0',
            'webdataset': '0.2.100', 'tokenizers': '0.21.0'}
STAGES = [
    dict(name='fullmask512', steps=40000, lengths=[512,512], full=[0.,.05], lr=[2e-5,1.5e-5], ramp=4000, warmup=1000),
    dict(name='length1024', steps=60000, lengths=[512,1024], full=[.05,.05], lr=[1.5e-5,1e-5], ramp=4000, warmup=0),
    dict(name='length2048', steps=80000, lengths=[1024,2048], full=[.05,.05], lr=[1e-5,7.5e-6], ramp=4000, warmup=0),
    dict(name='fullmask10', steps=80000, lengths=[2048,2048], full=[.05,.10], lr=[7.5e-6,5e-6], ramp=4000, warmup=0),
    dict(name='fullmask15', steps=140000, lengths=[2048,2048], full=[.10,.15], lr=[5e-6,2e-6], ramp=4000, warmup=0),
]
BASELINES = {
    'epoch_6': {'mlm': [1.219919,.941626], 'protein_only': [1.149235,1.148486]},
    'epoch_9': {'mlm': [1.208893,.933219], 'protein_only': [1.215072,1.215010]},
}

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def fingerprint(value):
    return hashlib.sha256(json.dumps({k:v for k,v in value.items() if k!='fingerprint'},sort_keys=True).encode()).hexdigest()

def stable_seed(text):
    return int.from_bytes(hashlib.sha256(text.encode()).digest()[:8],'big') % (2**63-1)

def atomic_json(path, value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+f'.tmp.{os.getpid()}')
    try:
        with temp.open('w') as f:
            json.dump(value,f,indent=2,sort_keys=True,allow_nan=False); f.write('\n'); f.flush(); os.fsync(f.fileno())
        os.replace(temp,path)
    finally:
        temp.unlink(missing_ok=True)

def load_run(root=ROOT, verify=True):
    root=Path(root)
    cfg=json.loads((root/'run.json').read_text())
    if cfg['fingerprint']!=fingerprint(cfg): raise RuntimeError('Run configuration seal failed.')
    if cfg.get('version')==3:
        from execution import PROFILE
        if cfg.get('execution_profile')!=PROFILE: raise RuntimeError('Unexpected execution policy in run configuration')
    if cfg.get('production_revision')==4:
        from production import POLICY
        if cfg.get('stages')!=STAGES or cfg.get('production_policy')!=POLICY:
            raise RuntimeError('Production schedule/policy differs from sealed configuration')
    if verify:
        for rel,expected in cfg['hashes'].items():
            if sha(root/rel)!=expected: raise RuntimeError(f'Installed file changed: {rel}')
        if sha(cfg['mapping'])!=cfg['mapping_sha256']: raise RuntimeError('Species mapping changed.')
    return cfg

def stage_index(name):
    return next(i for i,s in enumerate(STAGES) if s['name']==name)

def stage_start(stage): return sum(s['steps'] for s in STAGES[:stage])

def controls(stage, completed, seed=123, lr_anchor=None):
    """Settings for the next update; counters count *completed optimizer updates*."""
    s=STAGES[stage]
    if not 0<=completed<s['steps']: raise ValueError('Update outside stage')
    fraction=min(1.,completed/s['ramp'])
    full=s['full'][0]+fraction*(s['full'][1]-s['full'][0])
    u=stable_seed(f'length:{seed}:{stage}:{completed}')/(2**63-1)
    length=s['lengths'][1] if u<fraction else s['lengths'][0]
    if s['warmup'] and completed<s['warmup']:
        lr=s['lr'][0]*(completed+1)/s['warmup']
    else:
        n=max(1,s['steps']-s['warmup']-1)
        progress=(completed-s['warmup'])/n
        lr=s['lr'][1]+(s['lr'][0]-s['lr'][1])*.5*(1+math.cos(math.pi*progress))
    if stage==0 and lr_anchor is not None and completed>=lr_anchor['completed']:
        start=int(lr_anchor['completed']); initial=float(lr_anchor['lr'])
        if not s['warmup']<=start<s['steps'] or not s['lr'][1]<=initial<=s['lr'][0]:
            raise ValueError('Invalid imported learning-rate anchor')
        progress=(completed-start)/max(1,s['steps']-start-1)
        lr=s['lr'][1]+(initial-s['lr'][1])*.5*(1+math.cos(math.pi*progress))
    return length,full,lr

def batch_profile(length, divisor=1):
    base={512:(192,1),1024:(96,2),2048:(48,4)}[length]
    if divisor not in (1,2,4,8) or base[0]%divisor: raise ValueError('Invalid batch divisor')
    return base[0]//divisor,base[1]*divisor

def inventory(data):
    rows=[]
    for i in range(5874):
        p=Path(data)/f'shard-{i:06d}.tar.gz'; stat=p.stat()
        if not p.is_file() or stat.st_size<=0: raise ValueError(f'Missing/empty shard: {p}')
        rows.append([p.name,stat.st_size,stat.st_mtime_ns])
    return rows

def source_path(root=ROOT):
    import sys
    path=str(Path(root)/'source')
    if path not in sys.path: sys.path.insert(0,path)

def validate_mapping(mapping,n_real):
    if len(mapping)!=n_real or any(type(v) is not int for v in mapping.values()) or set(mapping.values())!=set(range(n_real)):
        raise ValueError('Species mapping must uniquely cover all real IDs')

def resolve_species(raw,mapping,n_real):
    if type(raw) is int: sid=raw
    elif isinstance(raw,str) and raw in mapping: sid=mapping[raw]
    else: raise ValueError(f'Unmapped species: {raw!r}; use an exact mapping name or JSON integer ID')
    if not 0<=sid<n_real: raise ValueError(f'Invalid real-species ID: {sid}')
    return sid
