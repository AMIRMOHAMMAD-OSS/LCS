"""Fixed-panel six-condition evaluation, long-gene strata, and strict generation."""
from __future__ import annotations
import json
from pathlib import Path
import torch
from common import ROOT, source_path, resolve_species, atomic_json, BASELINES
from engine import rank, world, sum_tensor, barrier, isolated_rng, autocast
from diagnostic_metrics import row_statistics, synonymous_groups, aggregate, paired_deltas
from generation import generate_batch, comparison_stats, compare_hosts

CONDITIONS=('correct','wrong','wrong_1','wrong_2','unknown','zero')

def stratum(record):
    n=len(record['protein_sequence'].rstrip('*_'))
    return 'short' if n<=509 else 'medium' if n<=1021 else 'long'

class Evaluator:
    def __init__(self,cfg,tokenizer,root=ROOT):
        self.cfg,self.tokenizer,self.root=cfg,tokenizer,Path(root)
        self.mapping=json.loads(Path(cfg['mapping']).read_text())
        self.rows=[json.loads(l) for l in (self.root/'source/eval_panel.jsonl').read_text().splitlines() if l.strip()]
        self.long_rows=[self.rows[i] for i in cfg['long_panel_indices']]
        self.generation_rows=[self.rows[i] for i in cfg['generation_indices']]
        self.host_rows=[self.rows[i] for i in cfg['host_probe_indices']]
        self.groups=synonymous_groups(tokenizer.get_vocab())
        self.batch_cache={}

    def batches(self,length,mode):
        from common import stable_seed
        source_path(self.root)
        from phase1_support import FixedEvalCollator
        key=(length,mode)
        if key in self.batch_cache:return self.batch_cache[key]
        rows=self.rows if length==512 else self.long_rows
        collator=FixedEvalCollator(self.tokenizer,species_to_id=self.mapping,unknown_species_id=26678,max_species_id=28678,
            species_dropout_prob=0.,species_random_frac=0.,mlm_probability=.15,full_mask_probability=float(mode=='protein_only'),max_length=length)
        indices=list(range(rank(),len(rows),world()));batches=[]
        for offset in range(0,len(indices),8):
            selected=indices[offset:offset+8]
            batch=collator([{'json':rows[i]} for i in selected])
            for draw in (1,2):
                offsets=[1+stable_seed(f'wrong{draw}:'+str(rows[i]['eval_key']))%26677 for i in selected]
                batch[f'wrong_species_id_{draw}']=(batch['species_id']+torch.tensor(offsets))%26678
            batches.append((selected,batch))
        self.batch_cache[key]=batches
        return batches

    @torch.inference_mode()
    def evaluate(self,model,output,step,tag,reference=None,long_panels=True,generation=True):
        with isolated_rng():
            model.eval();device=next(model.parameters()).device
            groups=torch.tensor(self.groups,device=device)
            result={'fingerprint':self.cfg['fingerprint'],'continuation_step':step,'tag':tag,
                    'species_embed_scale':model.scale,'panels':{},'notes':[
                        'Fixed development panels; exploratory paired bootstrap over species, not phylogeny or mask/assignment uncertainty.',
                        'Correct absolute performance and retention matter alongside wrong-minus-correct deltas.',
                        'CSI/rank and MinMax-18 are not computed: the original species codon tables and scorer are not in this bundle.']}
            for length in ((512,1024,2048) if long_panels else (512,)):
                rows=self.rows if length==512 else self.long_rows
                ids=[resolve_species(r['species'],self.mapping,26678) for r in rows]
                modes={}
                for mode in ('mlm','protein_only'):
                    values=torch.zeros((len(CONDITIONS),len(rows),5),dtype=torch.float64,device=device)
                    seen=torch.zeros(len(rows),dtype=torch.int32,device=device)
                    for selected,cpu in self.batches(length,mode):
                        b={k:v.to(device) for k,v in cpu.items()};seen[selected]+=1
                        for j,condition in enumerate(CONDITIONS):
                            key={'correct':'species_id','wrong':'wrong_species_id','wrong_1':'wrong_species_id_1','wrong_2':'wrong_species_id_2'}.get(condition)
                            sid=b[key] if key else torch.full_like(b['species_id'],26678)
                            with autocast(device): logits=model(b['input_ids'],b['attention_mask'],sid,zero=condition=='zero')
                            values[j,selected]=row_statistics(logits,b['labels'],groups).to(device)
                    sum_tensor(values);sum_tensor(seen)
                    if not seen.eq(1).all():raise RuntimeError('Duplicate or missing evaluation rows')
                    if rank()==0:
                        conditions={name:values[j].cpu() for j,name in enumerate(CONDITIONS)}
                        conditions['wrong_mean']=torch.stack([conditions[x] for x in ('wrong','wrong_1','wrong_2')]).mean(0)
                        item={'conditions':{k:aggregate(v) for k,v in conditions.items()},
                              'deltas':{k:paired_deltas(conditions['correct'],v,ids) for k,v in conditions.items() if k!='correct'},'length_strata':{}}
                        for label in ('short','medium','long'):
                            select=[i for i,r in enumerate(rows) if stratum(r)==label]
                            if select:
                                item['length_strata'][label]={'records':len(select),'correct':aggregate(conditions['correct'][select]),
                                    'wrong_mean_delta':paired_deltas(conditions['correct'][select],conditions['wrong_mean'][select],[ids[i] for i in select])}
                        if reference and length==512:
                            expected=BASELINES[reference][mode]
                            for metric,target in zip(('raw_loss','synonymous_loss'),expected):
                                actual=item['conditions']['correct'][metric]
                                if abs(actual-target)>.002: raise RuntimeError(f'Baseline mismatch: {reference} {mode} {metric} {actual} vs {target}')
                        modes[mode]=item
                        print('CT2_EVAL',json.dumps({'step':step,'tag':tag,'length':length,'mode':mode,
                            'correct_syn':item['conditions']['correct']['synonymous_loss'],
                            'wrong_mean_delta':item['deltas']['wrong_mean']['synonymous_delta'],
                            'ci':item['deltas']['wrong_mean']['synonymous_95pct_species_bootstrap']}),flush=True)
                if rank()==0:result['panels'][str(length)]={'records':len(rows),'modes':modes}
            if rank()==0:
                if generation:
                    predictions=[]
                    for i in range(0,len(self.generation_rows),4): predictions.extend(generate_batch(model,self.tokenizer,self.generation_rows[i:i+4],self.mapping))
                    result['generation']={'native_host':[{'prediction':p,'metrics':comparison_stats(p)} for p in predictions],
                        'host_sensitivity':compare_hosts(model,self.tokenizer,self.host_rows,self.mapping,self.cfg['comparison_hosts']),
                        'excluded_over_context':self.cfg['generation_exclusions']}
                Path(output).mkdir(parents=True,exist_ok=True)
                atomic_json(Path(output)/f'evaluation_{step:06d}.json',result)
                atomic_json(Path(output)/'evaluation_latest.json',result)
            barrier();model.train()
            return result if rank()==0 else None
