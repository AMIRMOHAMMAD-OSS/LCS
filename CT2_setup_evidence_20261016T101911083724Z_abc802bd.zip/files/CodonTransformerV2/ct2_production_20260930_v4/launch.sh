#!/bin/bash
set -euo pipefail
ct2_bundle_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f "$ct2_bundle_dir/run.json" ]]; then
    python3 "$ct2_bundle_dir/production_setup.py" "$@"
elif [[ $# -gt 0 ]]; then
    echo 'Already configured. Use python3 submit.py train or resume from this directory.' >&2
    exit 1
fi
python3 "$ct2_bundle_dir/submit.py" train --stage fullmask512
