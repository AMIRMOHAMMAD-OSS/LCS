"""Submit production stages and continue an intentionally paused allocation once."""
from __future__ import annotations
import fcntl
import json
import os
import re
import subprocess
from pathlib import Path
from common import ROOT, STAGES, atomic_json, sha, stage_start
from production import verify_inherited_preflight
from submit import live_jobs

def queue(cfg,action,stage,parent_job=None,root=ROOT):
    root=Path(root);path=root/'jobs.json'
    with (root/'.submission.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        registry=json.loads(path.read_text()) if path.exists() else {'fingerprint':cfg['fingerprint'],'submissions':[]}
        if registry['fingerprint']!=cfg['fingerprint'] or registry.get('pending_submission'):
            raise RuntimeError('Submission identity is invalid or sbatch result is unresolved; inspect status')
        verify_inherited_preflight(cfg,root)
        old=json.loads((Path(cfg['parent_run']['directory'])/'jobs.json').read_text())
        if old.get('pending_submission') or live_jobs(old):raise RuntimeError('Parent v3 has active/unresolved submissions')
        active=live_jobs(registry)
        out=Path(cfg['output'])/'training'/STAGES[stage]['name']
        if parent_job:
            if os.environ.get('SLURM_JOB_ID')!=parent_job:raise RuntimeError('Continuation must come from the active allocation')
            latest=registry['submissions'][-1] if registry['submissions'] else {}
            if latest.get('job')!=parent_job or latest.get('stage')!=stage or set(active)!={parent_job}:
                raise RuntimeError('Allocation is not the sole latest training submission')
            receipt=json.loads((out/('pause_'+parent_job+'.json')).read_text())
            if (receipt.get('fingerprint')!=cfg['fingerprint'] or receipt.get('job_id')!=parent_job
                    or receipt.get('stage')!=stage or not 0<receipt['stage_step']<STAGES[stage]['steps']
                    or receipt['checkpoint_sha256']!=sha(out/'last.ckpt')):
                raise RuntimeError('Checkpoint continuation receipt is invalid')
        elif active:raise RuntimeError('A production allocation is already queued/running: '+','.join(active))
        if (out/'verified_complete.json').exists() or ((out/'completed.json').exists() and action!='resume'):
            raise RuntimeError('Stage is complete; use report and advance (resume can finish interrupted verification)')
        if action=='resume' and not (out/'last.ckpt').exists():raise RuntimeError('No production checkpoint to resume')
        if action!='resume' and (out/'last.ckpt').exists():raise RuntimeError('Existing progress; use resume')
        if stage:
            previous=Path(cfg['output'])/'training'/STAGES[stage-1]['name']
            done=json.loads((previous/'verified_complete.json').read_text())
            if (done.get('fingerprint')!=cfg['fingerprint'] or done.get('stage')!=stage-1
                    or done.get('continuation_step')!=stage_start(stage)
                    or done['checkpoint_sha256']!=sha(previous/'last.ckpt')):
                raise RuntimeError('Previous production stage is not verified complete')
        script=root/f'train_{STAGES[stage]["name"]}.slurm'
        entry={'kind':'train','stage':stage,'action':action,'script':str(script),'afterok':parent_job}
        command=['sbatch','--parsable']
        if parent_job:command.append('--dependency=afterok:'+parent_job)
        registry['pending_submission']=entry;atomic_json(path,registry)
        result=subprocess.run([*command,str(script)],text=True,capture_output=True,cwd=root)
        match=re.fullmatch(r'(\d+)(?:;[^\s;]+)?',result.stdout.strip())
        if result.returncode or not match:
            if result.returncode and not result.stdout.strip() and 'Batch job submission failed:' in result.stderr:
                registry.pop('pending_submission');registry.setdefault('rejected_submissions',[]).append({**entry,'error':result.stderr})
                atomic_json(path,registry)
                raise RuntimeError('Slurm rejected submission; saved training is intact: '+result.stderr)
            raise RuntimeError('Ambiguous sbatch result; inspect Slurm before retrying: '+repr((result.stdout,result.stderr)))
        job=match.group(1);registry.pop('pending_submission');registry['submissions'].append({**entry,'job':job})
        atomic_json(path,registry)
    print('PRODUCTION_JOB:',job,flush=True)
    print('STAGE:',STAGES[stage]['name'],'TARGET_UPDATES:',STAGES[stage]['steps'],flush=True)
    print('Same stage continues across allocations. Next curriculum stage requires explicit advance.',flush=True)
    return job

def main(cfg,action,stage):
    import submit
    if action=='baselines':
        parent=json.loads((ROOT/'parent_v3_run.json').read_text())
        # The existing reporter reads the parent's registry and original evidence.
        submit.ROOT=Path(cfg['parent_run']['directory']);submit.baselines(parent)
    elif action=='status':
        submit.status(cfg)
        print('INHERITED_STAGE0_VALIDATION:',cfg['inherited_preflight']['job_id'])
        for s in STAGES:
            path=Path(cfg['output'])/'training'/s['name']/'coverage.json'
            if path.exists():print('COVERAGE:',s['name'],path.read_text())
    elif action=='report':submit.report(cfg)
    elif action=='errors':submit.errors()
    elif action in ('train','resume','advance'):
        if action=='advance' and stage==0:raise ValueError('advance requires a later --stage')
        queue(cfg,action,stage)
    else:raise ValueError('Use train, resume, or advance. Production does not queue separate preflight jobs.')
