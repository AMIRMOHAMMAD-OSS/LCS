#!/usr/bin/env python3
"""Extend the validated v3 run without editing its files or relaunching stage-0 checks."""
from __future__ import annotations
import argparse
import fcntl
import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from common import ROOT, STAGES, SOURCE_FINGERPRINT, load_run, inventory, sha, fingerprint, atomic_json
from setup import header, WORK_ROOT
from submit import live_jobs
from production import PARENT_FINGERPRINT, OLD_STEPS, POLICY, validate_pass, verify_inherited_preflight

def prepare(parent,root=ROOT):
    parent=Path(parent).resolve();root=Path(root).resolve()
    if root==parent or not re.fullmatch(r'[A-Za-z0-9_./-]+',str(root)):raise ValueError('Use a separate plain-path directory')
    if (root/'run.json').exists() or (root/'source').exists():raise FileExistsError('Production directory is already configured/partly configured')
    with (parent/'.submission.lock').open('a') as lock,(parent/'.run.lock').open('a') as run_lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(run_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        prior=load_run(parent)
        if prior['fingerprint']!=PARENT_FINGERPRINT or prior['source_fingerprint']!=SOURCE_FINGERPRINT:
            raise ValueError('Expected the reviewed sealed v3 run')
        old_stages=[dict(s,steps=n) for s,n in zip(STAGES,OLD_STEPS)]
        if prior['stages']!=old_stages or prior['world_size']!=8:raise ValueError('Parent curriculum/geometry changed')
        registry=json.loads((parent/'jobs.json').read_text())
        if registry['fingerprint']!=prior['fingerprint'] or registry.get('pending_submission'):
            raise ValueError('Resolve the parent submission registry first')
        active=live_jobs(registry)
        if active:raise RuntimeError('Parent jobs are still active: '+','.join(active)+'. Keep that work; upgrade after it stops.')
        stamp=json.loads((parent/'preflight_fullmask512_passed.json').read_text())
        submitted=[j for j in registry['submissions'] if j['stage']==0 and j['kind']=='preflight']
        if not submitted or stamp['job_id']!=submitted[-1]['job']:raise ValueError('Parent pass is not its latest submitted preflight')
        evidence=Path(prior['output'])/'preflight/fullmask512'/('job_'+stamp['job_id'])
        if Path(stamp['output'])!=evidence:raise ValueError('Unexpected preflight output directory')
        comparison=json.loads((evidence/'resume_comparison.json').read_text())
        hardware=json.loads((evidence/'hardware_checks.json').read_text())
        validate_pass(stamp,prior,hardware,comparison)
        result=subprocess.run(['sacct','-X','-n','-P','-j',stamp['job_id'],
            '--format=JobIDRaw,State,ExitCode'],check=True,text=True,capture_output=True)
        rows=[r.split('|') for r in result.stdout.splitlines() if r.split('|')[0]==stamp['job_id']]
        if rows!=[[stamp['job_id'],'COMPLETED','0:0']]:raise ValueError('Parent preflight must have Slurm COMPLETED / 0:0')
        if inventory(prior['data_root'])!=prior['shards']:raise ValueError('Shard inventory changed')
        output=Path(prior['output']).parent/root.name
        if not output.resolve().is_relative_to(WORK_ROOT) or output.exists():raise ValueError('Use a fresh output directory on WORK')
        for stage in STAGES[1:]:
            if (Path(prior['output'])/'training'/stage['name']/'last.ckpt').exists():
                raise ValueError('Parent has later-stage training; this migration preserves stage-0 progress only')
        manifest=json.loads((root/'validated_v3_program_hashes.json').read_text())
        for rel,digest in manifest.items():
            if prior['hashes'].get(rel)!=digest or sha(parent/rel)!=digest:raise ValueError('Parent program differs: '+rel)
        # Check everything before creating new runtime state. Parent files stay untouched.
        for rel,digest in prior['hashes'].items():
            path=Path(rel)
            if path.is_absolute() or '..' in path.parts:raise ValueError('Unsafe sealed path')
            if path.parts[0]=='source':
                target=root/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(parent/path,target)
        shutil.copy2(parent/'run.json',root/'parent_v3_run.json')
        proof=root/'inherited_validation';proof.mkdir()
        for name,value in [('preflight_pass.json',stamp),('resume_comparison.json',comparison),
                           ('hardware_checks.json',hardware),('accounting.json',{'job_id':stamp['job_id'],'state':'COMPLETED','exit_code':'0:0'})]:
            atomic_json(proof/name,value)
        run={k:v for k,v in prior.items() if k not in ('hashes','fingerprint','parent_run')}
        run.update(production_revision=4,stages=STAGES,production_policy=POLICY,
            launch_policy='production; automatic_same_stage_continuation; explicit_next_stage',
            output=str(output),mapping=str(root/'source/species_to_id.json'),
            parent_run={'directory':str(parent),'fingerprint':prior['fingerprint']},
            inherited_preflight={'job_id':stamp['job_id'],'parent_fingerprint':prior['fingerprint'],
                'scope':'Stage-0 execution/data/resume proof only; extended horizon tested locally; later lengths checked in their production allocations.'})
        checkpoint=Path(prior['output'])/'training/fullmask512/last.ckpt'
        output.mkdir(parents=True)
        if checkpoint.exists():
            target=output/'imported_v3_stage0.ckpt'
            os.link(checkpoint,target)
            run['adopt_checkpoint']={'path':str(target),'sha256':sha(target),'source':str(checkpoint)}
            print('PRESERVING_V3_TRAINING_CHECKPOINT:',checkpoint,flush=True)
        (root/'logs').mkdir(exist_ok=True)
        for i,s in enumerate(STAGES):
            path=root/f'train_{s["name"]}.slurm'
            path.write_text(header(root,'ct2prod_'+s['name'],'20')+f'\nbash runtime_python.sh -u production_job.py --stage {i}\n')
            subprocess.run(['bash','-n',str(path)],check=True)
        paths=[p for p in root.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.jsonl','.slurm','.sh') and '__pycache__' not in p.parts]
        run['hashes']={str(p.relative_to(root)):sha(p) for p in sorted(paths)}
        run['fingerprint']=fingerprint(run)
        verify_inherited_preflight(run,root)
        atomic_json(root/'run.json',run)
    print('PRODUCTION_READY:',root);print('OUTPUT:',output)
    print('UPDATES:',json.dumps({s['name']:s['steps'] for s in STAGES}))
    print('INHERITED_STAGE0_VALIDATION:',stamp['job_id'],'(no new pass claimed)')
    print('Setup submitted no job. launch.sh now submits the first production stage.')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--from-v3',type=Path,required=True)
    a=p.parse_args();prepare(a.from_v3)
