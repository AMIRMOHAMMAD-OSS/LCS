"""The complete execution profile that passed H100 replay job 297046.

This is a numerical execution policy, not a change to the training schedule.
Keep it separate from ModernBertConfig: its serializer omits reference_compile.
"""
from __future__ import annotations
import contextlib
import os

PROFILE = {
    'name': 'controlled_v1',
    'attention_implementation': 'sdpa',
    'reference_compile': False,
    'deterministic_algorithms': True,
    'deterministic_warn_only': False,
    'float32_matmul_precision': 'highest',
    'bf16_reduced_precision_reduction': False,
    'cudnn_benchmark': False,
    'cudnn_sdp': False,
    'flash_sdp': True,
    'efficient_sdp': True,
    'math_sdp': True,
    'cublas_workspace_config': ':4096:8',
    'forward_autocast': 'bfloat16',
}


def configure(require_workspace=True):
    import torch
    if require_workspace and os.environ.get('CUBLAS_WORKSPACE_CONFIG') != PROFILE['cublas_workspace_config']:
        raise RuntimeError('Use runtime_python.sh: CUBLAS_WORKSPACE_CONFIG must be set before CUDA initialization')
    torch.use_deterministic_algorithms(True, warn_only=False)
    torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cuda.enable_cudnn_sdp(False)
    torch.backends.cuda.enable_flash_sdp(True)
    torch.backends.cuda.enable_mem_efficient_sdp(True)
    torch.backends.cuda.enable_math_sdp(True)


def snapshot(model=None):
    import torch
    result = {
        'name': PROFILE['name'],
        'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
        'deterministic_warn_only': torch.is_deterministic_algorithms_warn_only_enabled(),
        'float32_matmul_precision': torch.get_float32_matmul_precision(),
        'bf16_reduced_precision_reduction': torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction,
        'cudnn_benchmark': torch.backends.cudnn.benchmark,
        'cudnn_sdp': torch.backends.cuda.cudnn_sdp_enabled(),
        'flash_sdp': torch.backends.cuda.flash_sdp_enabled(),
        'efficient_sdp': torch.backends.cuda.mem_efficient_sdp_enabled(),
        'math_sdp': torch.backends.cuda.math_sdp_enabled(),
        'cublas_workspace_config': os.environ.get('CUBLAS_WORKSPACE_CONFIG'),
        'forward_autocast': 'bfloat16',
    }
    if model is not None:
        result.update(reference_compile=model.model.config.reference_compile,
                      attention_implementation=model.model.config._attn_implementation)
    return result


def validate_snapshot(value, with_model=True):
    required = set(PROFILE) if with_model else set(PROFILE) - {'reference_compile', 'attention_implementation'}
    mismatch = {k: {'expected': PROFILE[k], 'actual': value.get(k)}
                for k in required if k not in value or value[k] != PROFILE[k]}
    if mismatch:
        raise RuntimeError('Execution profile changed: ' + repr(mismatch))


def assert_profile(model=None):
    value = snapshot(model)
    validate_snapshot(value, with_model=model is not None)
    return value


@contextlib.contextmanager
def scoped_generation(device):
    """Apply the same GPU arithmetic without leaking global flags to callers."""
    import torch
    old = snapshot()
    try:
        configure(require_workspace=str(device).startswith('cuda'))
        yield
    finally:
        torch.use_deterministic_algorithms(old['deterministic_algorithms'], warn_only=old['deterministic_warn_only'])
        torch.set_float32_matmul_precision(old['float32_matmul_precision'])
        torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = old['bf16_reduced_precision_reduction']
        torch.backends.cudnn.benchmark = old['cudnn_benchmark']
        torch.backends.cuda.enable_cudnn_sdp(old['cudnn_sdp'])
        torch.backends.cuda.enable_flash_sdp(old['flash_sdp'])
        torch.backends.cuda.enable_mem_efficient_sdp(old['efficient_sdp'])
        torch.backends.cuda.enable_math_sdp(old['math_sdp'])
