"""
eval_formal_csi_own_wrong_rare.py

Formal CSI own / wrong-mean with rare-mode sensitivity.

Differences from eval_formal_csi_own_wrong.py:

  1. Vectorized on GPU (one matmul per batch, mirroring
     eval_formal_csi_species_rank_gpu.py).

  2. Wrong-species mean now uses ALL other species in the prediction set
     (158 wrong out of 159 common) rather than 5 sampled wrong species.
     The deterministic-MD5 wrong-species sampling from the original script
     is dropped because we now exhaust the wrong-species universe.

  3. Loops over 3 rare modes ("all", "no_rare_0_001", "no_rare_0_01"),
     applying the exact same parquet-row filter that
     eval_minmax_ct2_stages.py uses (`use = use[~use[rare_col]]`),
     so the rare-mode definition is identical across CSI, CAI, MinMax,
     and rank.

  4. Per-(sequence, species) score: mean log-weight over codons whose
     (species, aa, codon) is present in the filtered lookup, then
     exponentiated to give CSI. Codons whose lookup entry is missing
     (structurally absent or rare-filtered) are skipped, matching the
     per-codon `if w is None: continue` logic of the original CSI
     calculation.

Usage:
  python eval_formal_csi_own_wrong_rare.py \\
    --predictions ct1_vs_ct2_all_trunc2046_common_valid_predictions.csv \\
    --codon_table ct2_codon_usage_tables_qc/ct2_train_species_codon_frequencies_clean.parquet \\
    --out_prefix formal_csi_own_wrong_rare_ct1_vs_ct2_all_trunc2046_common_valid \\
    --batch_size 512 --device cuda
"""

import argparse
import math

import numpy as np
import pandas as pd
import torch
from tqdm import tqdm


GENETIC_CODE = {
    "TTT": "F", "TTC": "F", "TTA": "L", "TTG": "L",
    "TCT": "S", "TCC": "S", "TCA": "S", "TCG": "S",
    "TAT": "Y", "TAC": "Y", "TAA": "*", "TAG": "*",
    "TGT": "C", "TGC": "C", "TGA": "*", "TGG": "W",
    "CTT": "L", "CTC": "L", "CTA": "L", "CTG": "L",
    "CCT": "P", "CCC": "P", "CCA": "P", "CCG": "P",
    "CAT": "H", "CAC": "H", "CAA": "Q", "CAG": "Q",
    "CGT": "R", "CGC": "R", "CGA": "R", "CGG": "R",
    "ATT": "I", "ATC": "I", "ATA": "I", "ATG": "M",
    "ACT": "T", "ACC": "T", "ACA": "T", "ACG": "T",
    "AAT": "N", "AAC": "N", "AAA": "K", "AAG": "K",
    "AGT": "S", "AGC": "S", "AGA": "R", "AGG": "R",
    "GTT": "V", "GTC": "V", "GTA": "V", "GTG": "V",
    "GCT": "A", "GCC": "A", "GCA": "A", "GCG": "A",
    "GAT": "D", "GAC": "D", "GAA": "E", "GAG": "E",
    "GGT": "G", "GGC": "G", "GGA": "G", "GGG": "G",
}

SENSE_CODONS = [c for c, aa in GENETIC_CODE.items() if aa != "*"]
CODON_TO_IDX = {c: i for i, c in enumerate(SENSE_CODONS)}
N_CODONS = len(SENSE_CODONS)


def clean_dna(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def count_codons(seq):
    seq = clean_dna(seq)
    v = np.zeros(N_CODONS, dtype=np.float32)
    n = 0
    for i in range(0, len(seq) - 2, 3):
        codon = seq[i:i + 3]
        j = CODON_TO_IDX.get(codon)
        if j is not None:
            v[j] += 1.0
            n += 1
    return v, n


def build_matrices(freq_df, species_list, rare_col):
    """
    Build per-rare-mode lookup matrices.

    Returns
    -------
    logw : np.ndarray, shape [N_CODONS, n_species]
        log of formal-CSI weight (= log(freq / max_synonymous_freq_in_species)).
        Entries that don't exist (after filtering) are 0; their `mask` is 0.
    mask : np.ndarray, shape [N_CODONS, n_species]
        1 where the (species, aa, codon) entry survives the rare filter, else 0.
    """
    use = freq_df.copy()
    if rare_col is not None:
        use = use[~use[rare_col]].copy()

    max_freq = (
        use.groupby(["species", "aa"], as_index=False)["frequency"]
        .max()
        .rename(columns={"frequency": "max_frequency"})
    )
    use = use.merge(max_freq, on=["species", "aa"], how="left")
    use["weight"] = use["frequency"] / use["max_frequency"]

    species_to_col = {s: i for i, s in enumerate(species_list)}

    logw = np.zeros((N_CODONS, len(species_list)), dtype=np.float32)
    mask = np.zeros((N_CODONS, len(species_list)), dtype=np.float32)

    for r in tqdm(use.itertuples(index=False), total=len(use),
                  desc=f"matrices [{rare_col or 'all'}]"):
        codon = str(r.codon)
        species = str(r.species)
        if pd.isna(r.weight):
            continue
        w = float(r.weight)
        if codon in CODON_TO_IDX and species in species_to_col and w > 0:
            ci = CODON_TO_IDX[codon]
            si = species_to_col[species]
            logw[ci, si] = float(math.log(w))
            mask[ci, si] = 1.0

    return logw, mask


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--out_prefix", required=True)
    ap.add_argument("--batch_size", type=int, default=512)
    ap.add_argument("--device", default="cuda")
    args = ap.parse_args()

    device = torch.device(args.device if args.device == "cuda" and torch.cuda.is_available() else "cpu")
    print("device:", device, flush=True)

    pred = pd.read_csv(args.predictions, low_memory=False)
    pred = pred[pred["pred_dna"].fillna("").astype(str).str.len() > 0].copy()
    pred = pred.reset_index(drop=True)
    print("prediction rows:", len(pred), flush=True)
    print("models:", pred["model"].nunique(), flush=True)

    freq = pd.read_parquet(args.codon_table)
    freq["species"] = freq["species"].astype(str)

    pred_species = sorted(pred["species"].astype(str).unique().tolist())
    freq_use = freq[freq["species"].isin(set(pred_species))].copy()
    print(f"species in predictions (used for own AND wrong baseline): {len(pred_species)}", flush=True)
    print(f"codon-table rows after species filter: {len(freq_use)}", flush=True)
    print(f"  wrong-species count per row will be {len(pred_species) - 1} (everyone except true)", flush=True)

    species_to_col = {s: i for i, s in enumerate(pred_species)}

    # Codon-count matrix [n_rows, N_CODONS]
    X = np.zeros((len(pred), N_CODONS), dtype=np.float32)
    n_valid = np.zeros(len(pred), dtype=np.int32)
    for i, seq in enumerate(tqdm(pred["pred_dna"], desc="counting codons")):
        v, n = count_codons(seq)
        X[i] = v
        n_valid[i] = n

    true_cols = pred["species"].astype(str).map(species_to_col).fillna(-1).astype(int).to_numpy()

    has_eval_id = "eval_id" in pred.columns
    has_bucket = "bucket" in pred.columns
    has_protein_len = "protein_len" in pred.columns

    all_rows = []
    rare_modes = [
        ("all", None),
        ("no_rare_0_001", "rare_lt_0_001"),
        ("no_rare_0_01", "rare_lt_0_01"),
    ]

    for rare_mode, rare_col in rare_modes:
        print("\n" + "=" * 80, flush=True)
        print("RARE MODE:", rare_mode, flush=True)
        print("=" * 80, flush=True)

        logw, mask = build_matrices(freq_use, pred_species, rare_col)
        print(f"  mask coverage: {mask.sum():.0f} / {mask.size} cells ({100 * mask.mean():.2f}%)", flush=True)
        logw_t = torch.tensor(logw, dtype=torch.float32, device=device)
        mask_t = torch.tensor(mask, dtype=torch.float32, device=device)

        for start in tqdm(range(0, len(pred), args.batch_size),
                          desc=f"CSI own/wrong [{rare_mode}]"):
            end = min(start + args.batch_size, len(pred))
            xb = torch.tensor(X[start:end], dtype=torch.float32, device=device)

            sum_logw = xb @ logw_t                                # [B, S]
            n_used = xb @ mask_t                                  # [B, S]
            safe_n = torch.where(n_used > 0, n_used, torch.ones_like(n_used))
            mean_logw = sum_logw / safe_n
            nan_tensor = torch.full_like(mean_logw, float("nan"))
            mean_logw = torch.where(n_used > 0, mean_logw, nan_tensor)

            mean_logw_np = mean_logw.cpu().numpy()
            n_used_np = n_used.cpu().numpy()

            for i in range(end - start):
                row_idx = start + i
                tcol = int(true_cols[row_idx])

                if tcol >= 0:
                    own_log = float(mean_logw_np[i, tcol])
                    own_n = int(n_used_np[i, tcol])
                else:
                    own_log = float("nan")
                    own_n = 0

                wrong_logs = mean_logw_np[i].copy()
                if tcol >= 0:
                    wrong_logs[tcol] = np.nan
                finite_mask = np.isfinite(wrong_logs)
                if finite_mask.any():
                    wrong_mean_log = float(wrong_logs[finite_mask].mean())
                    n_wrong = int(finite_mask.sum())
                else:
                    wrong_mean_log = float("nan")
                    n_wrong = 0

                own_csi = float(math.exp(own_log)) if not math.isnan(own_log) else float("nan")
                wrong_csi = float(math.exp(wrong_mean_log)) if not math.isnan(wrong_mean_log) else float("nan")

                if not math.isnan(own_log) and not math.isnan(wrong_mean_log):
                    delta_log = own_log - wrong_mean_log
                    ratio = own_csi / wrong_csi if wrong_csi > 0 else float("nan")
                else:
                    delta_log = float("nan")
                    ratio = float("nan")

                row = {
                    "rare_mode": rare_mode,
                    "row_id": row_idx,
                    "model": pred.loc[row_idx, "model"],
                    "species": pred.loc[row_idx, "species"],
                    "formal_csi_own": own_csi,
                    "formal_csi_wrong_mean": wrong_csi,
                    "delta_log_formal_csi_own_minus_wrong": delta_log,
                    "ratio_formal_csi_own_over_wrong": ratio,
                    "codons_total": int(n_valid[row_idx]),
                    "n_codons_used_own": own_n,
                    "n_wrong_species_used": n_wrong,
                }
                if has_eval_id:
                    row["eval_id"] = pred.loc[row_idx, "eval_id"]
                if has_bucket:
                    row["bucket"] = pred.loc[row_idx, "bucket"]
                if has_protein_len:
                    row["protein_len"] = pred.loc[row_idx, "protein_len"]
                all_rows.append(row)

    out = pd.DataFrame(all_rows)
    out_seq = f"{args.out_prefix}_by_sequence.csv"
    out.to_csv(out_seq, index=False)

    summary = (
        out.groupby(["rare_mode", "model"], as_index=False)
        .agg(
            n=("row_id", "count"),
            formal_csi_own=("formal_csi_own", "mean"),
            formal_csi_wrong_mean=("formal_csi_wrong_mean", "mean"),
            ratio_formal_csi_own_over_wrong=("ratio_formal_csi_own_over_wrong", "mean"),
            delta_log_formal_csi_own_minus_wrong=("delta_log_formal_csi_own_minus_wrong", "mean"),
            mean_n_wrong_species_used=("n_wrong_species_used", "mean"),
        )
    )
    out_model = f"{args.out_prefix}_summary_by_model.csv"
    summary.to_csv(out_model, index=False)

    print("\n=== FORMAL CSI OWN/WRONG (rare modes) SUMMARY ===", flush=True)
    print(summary.to_string(index=False), flush=True)
    print("\nwrote:", out_seq, flush=True)
    print("wrote:", out_model, flush=True)


if __name__ == "__main__":
    main()
