import argparse
import multiprocessing as mp
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm


GENETIC_CODE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

DNA_COL_PRED = "pred_dna"
DNA_COL_NATIVE = "native_dna"
SPECIES_COL = "species"
MODEL_COL = "model"

G_FREQ = None
G_STATS = None
G_RARE_MODE = None
G_WINDOW = None


def normalize_dna(seq):
    if seq is None or pd.isna(seq):
        return ""
    return str(seq).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def codons_from_dna(seq):
    seq = normalize_dna(seq)
    n = len(seq) // 3
    out = []
    for i in range(n):
        codon = seq[3*i:3*i+3]
        if len(codon) != 3:
            continue
        if any(c not in "ACGT" for c in codon):
            continue
        aa = GENETIC_CODE.get(codon)
        if aa is None or aa == "*":
            continue
        out.append((aa, codon))
    return out


def build_minmax_tables(freq_df, rare_mode):
    use = freq_df.copy()

    if rare_mode == "no_rare_0_001":
        use = use[~use["rare_lt_0_001"]].copy()
    elif rare_mode == "no_rare_0_01":
        use = use[~use["rare_lt_0_01"]].copy()

    freq_lookup = {}
    for r in tqdm(use.itertuples(index=False), total=len(use), desc=f"freq lookup {rare_mode}"):
        freq_lookup[(r.species, r.aa, r.codon)] = float(r.frequency)

    stats = (
        use.groupby(["species", "aa"])["frequency"]
        .agg(["min", "max", "mean", "count"])
        .reset_index()
    )

    stat_lookup = {}
    for r in stats.itertuples(index=False):
        stat_lookup[(r.species, r.aa)] = {
            "min": float(r.min),
            "max": float(r.max),
            "mean": float(r.mean),
            "count": int(r.count),
        }

    return freq_lookup, stat_lookup


def minmax_codon_score(species, aa, codon, freq_lookup, stat_lookup):
    f = freq_lookup.get((species, aa, codon))
    st = stat_lookup.get((species, aa))

    if f is None or st is None:
        return None

    mn = st["min"]
    mx = st["max"]
    avg = st["mean"]

    # Single-codon amino acids or degenerate cases are neutral.
    if st["count"] <= 1 or mx == mn:
        return 0.0

    if f >= avg:
        denom = mx - avg
        if denom <= 0:
            return 0.0
        return 100.0 * (f - avg) / denom

    denom = avg - mn
    if denom <= 0:
        return 0.0
    return -100.0 * (avg - f) / denom


def minmax_raw_scores(seq, species, freq_lookup, stat_lookup):
    codons = codons_from_dna(seq)
    scores = []
    missing = 0

    for aa, codon in codons:
        s = minmax_codon_score(species, aa, codon, freq_lookup, stat_lookup)
        if s is None:
            missing += 1
            continue
        scores.append(float(s))

    return np.array(scores, dtype=np.float32), len(codons), missing


def rolling_mean(x, window):
    if len(x) == 0:
        return np.array([], dtype=np.float32)

    if len(x) < window:
        return np.array([float(np.mean(x))], dtype=np.float32)

    kernel = np.ones(window, dtype=np.float32) / float(window)
    return np.convolve(x, kernel, mode="valid").astype(np.float32)


def safe_corr(a, b):
    n = min(len(a), len(b))
    if n < 2:
        return np.nan

    a = a[:n]
    b = b[:n]

    if np.std(a) == 0 or np.std(b) == 0:
        return np.nan

    return float(np.corrcoef(a, b)[0, 1])


def compare_minmax(native_dna, pred_dna, species, freq_lookup, stat_lookup, window):
    native_raw, native_codons, native_missing = minmax_raw_scores(native_dna, species, freq_lookup, stat_lookup)
    pred_raw, pred_codons, pred_missing = minmax_raw_scores(pred_dna, species, freq_lookup, stat_lookup)

    native_profile = rolling_mean(native_raw, window)
    pred_profile = rolling_mean(pred_raw, window)

    n = min(len(native_profile), len(pred_profile))

    if n == 0:
        profile_mae = np.nan
        profile_rmse = np.nan
        profile_corr = np.nan
    else:
        diff = pred_profile[:n] - native_profile[:n]
        profile_mae = float(np.mean(np.abs(diff)))
        profile_rmse = float(np.sqrt(np.mean(diff ** 2)))
        profile_corr = safe_corr(native_profile, pred_profile)

    native_mean = float(np.mean(native_raw)) if len(native_raw) else np.nan
    pred_mean = float(np.mean(pred_raw)) if len(pred_raw) else np.nan

    return {
        "native_codons": native_codons,
        "pred_codons": pred_codons,
        "native_scored_codons": int(len(native_raw)),
        "pred_scored_codons": int(len(pred_raw)),
        "native_missing_codons": native_missing,
        "pred_missing_codons": pred_missing,
        "native_missing_frac": native_missing / max(native_codons, 1),
        "pred_missing_frac": pred_missing / max(pred_codons, 1),
        "native_minmax_mean": native_mean,
        "pred_minmax_mean": pred_mean,
        "abs_mean_minmax_diff": abs(pred_mean - native_mean) if not np.isnan(pred_mean) and not np.isnan(native_mean) else np.nan,
        "profile_points_compared": n,
        "profile_mae": profile_mae,
        "profile_rmse": profile_rmse,
        "profile_corr": profile_corr,
    }


def init_worker(freq_lookup, stat_lookup, rare_mode, window):
    global G_FREQ, G_STATS, G_RARE_MODE, G_WINDOW
    G_FREQ = freq_lookup
    G_STATS = stat_lookup
    G_RARE_MODE = rare_mode
    G_WINDOW = window


def score_row(item):
    idx, rec = item

    species = str(rec[SPECIES_COL])
    model = str(rec[MODEL_COL])
    native_dna = rec[DNA_COL_NATIVE]
    pred_dna = rec[DNA_COL_PRED]

    out = compare_minmax(native_dna, pred_dna, species, G_FREQ, G_STATS, G_WINDOW)

    return {
        "rare_mode": G_RARE_MODE,
        "row_id": idx,
        "model": model,
        "species": species,
        "bucket": rec.get("bucket", ""),
        "protein_len": rec.get("protein_len", np.nan),
        **out,
    }


def summarize(df):
    return (
        df.groupby(["rare_mode", "model"], as_index=False)
        .agg(
            n=("row_id", "count"),
            mean_native_codons=("native_codons", "mean"),
            mean_pred_codons=("pred_codons", "mean"),
            mean_native_missing_frac=("native_missing_frac", "mean"),
            mean_pred_missing_frac=("pred_missing_frac", "mean"),
            native_minmax_mean=("native_minmax_mean", "mean"),
            pred_minmax_mean=("pred_minmax_mean", "mean"),
            abs_mean_minmax_diff=("abs_mean_minmax_diff", "mean"),
            profile_mae=("profile_mae", "mean"),
            profile_rmse=("profile_rmse", "mean"),
            profile_corr=("profile_corr", "mean"),
        )
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--out_prefix", default="minmax_ct2_stages")
    ap.add_argument("--window", type=int, default=17)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--chunksize", type=int, default=200)
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    pred = pd.read_csv(args.predictions)
    if args.limit:
        pred = pred.head(args.limit).copy()

    required = [MODEL_COL, SPECIES_COL, DNA_COL_NATIVE, DNA_COL_PRED]
    missing = [c for c in required if c not in pred.columns]
    if missing:
        raise SystemExit(f"Missing required prediction columns: {missing}. Available: {pred.columns.tolist()}")

    print("prediction rows:", len(pred), flush=True)
    print("models:", pred[MODEL_COL].nunique(), flush=True)
    print("species:", pred[SPECIES_COL].nunique(), flush=True)
    print("window:", args.window, flush=True)
    print("workers:", args.workers, flush=True)

    freq_df = pd.read_parquet(args.codon_table)
    print("codon table rows:", len(freq_df), flush=True)
    print("codon table species:", freq_df["species"].nunique(), flush=True)

    records = list(pred.to_dict(orient="index").items())
    all_results = []

    for rare_mode in ["all", "no_rare_0_001", "no_rare_0_01"]:
        print("\n" + "=" * 80, flush=True)
        print("RARE MODE:", rare_mode, flush=True)
        print("=" * 80, flush=True)

        freq_lookup, stat_lookup = build_minmax_tables(freq_df, rare_mode)

        with mp.Pool(
            processes=args.workers,
            initializer=init_worker,
            initargs=(freq_lookup, stat_lookup, rare_mode, args.window),
        ) as pool:
            rows = list(
                tqdm(
                    pool.imap(score_row, records, chunksize=args.chunksize),
                    total=len(records),
                    desc=f"MinMax {rare_mode}",
                )
            )

        mode_df = pd.DataFrame(rows)
        partial = f"{args.out_prefix}_{rare_mode}_by_sequence.csv"
        mode_df.to_csv(partial, index=False)
        print("wrote partial:", partial, flush=True)

        all_results.append(mode_df)

        del freq_lookup, stat_lookup

    by_seq = pd.concat(all_results, ignore_index=True)
    out_seq = f"{args.out_prefix}_by_sequence.csv"
    by_seq.to_csv(out_seq, index=False)

    summary_model = summarize(by_seq)
    out_model = f"{args.out_prefix}_summary_by_model.csv"
    summary_model.to_csv(out_model, index=False)

    summary_bucket = (
        by_seq.groupby(["rare_mode", "model", "bucket"], as_index=False)
        .agg(
            n=("row_id", "count"),
            abs_mean_minmax_diff=("abs_mean_minmax_diff", "mean"),
            profile_mae=("profile_mae", "mean"),
            profile_rmse=("profile_rmse", "mean"),
            profile_corr=("profile_corr", "mean"),
            mean_pred_missing_frac=("pred_missing_frac", "mean"),
        )
    )
    out_bucket = f"{args.out_prefix}_summary_by_bucket.csv"
    summary_bucket.to_csv(out_bucket, index=False)

    print("\n=== SUMMARY BY MODEL ===", flush=True)
    print(summary_model.to_string(index=False), flush=True)

    print("\nWROTE", flush=True)
    print(out_seq, flush=True)
    print(out_model, flush=True)
    print(out_bucket, flush=True)


if __name__ == "__main__":
    main()
