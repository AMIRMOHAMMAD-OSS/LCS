#!/usr/bin/env python3
"""
build_ct1_vs_ct2_report_rare.py

Build a self-contained HTML report for the CT1-vs-CT2 all_trunc2046
common-valid benchmark, covering all 12 models (incl. stage6_final) and
all four metric families with three rare modes each.

Inputs: the six summary CSVs sitting alongside this script.
Output: a single HTML file (default: ct1_vs_ct2_all_trunc2046_FULL_RARE_report.html).
"""

import argparse
import html as html_mod
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

# ---------------------------------------------------------------- constants

MODEL_ORDER = [
    "native", "baseline_hfc", "baseline_bfc", "baseline_uniform", "CT1",
    "stage1_main_e10", "stage2_e3", "stage3_e14", "stage4_e7",
    "stage5_e3", "stage5_continue_e4", "stage6_final",
]
MODEL_DISPLAY = {
    "native": "Native", "baseline_hfc": "HFC", "baseline_bfc": "BFC",
    "baseline_uniform": "Uniform", "CT1": "CT1",
    "stage1_main_e10": "CT2 S1", "stage2_e3": "CT2 S2", "stage3_e14": "CT2 S3",
    "stage4_e7": "CT2 S4", "stage5_e3": "CT2 S5",
    "stage5_continue_e4": "CT2 S5 cont", "stage6_final": "CT2 S6",
}
MODEL_KIND = {
    "native": "ref",
    "baseline_hfc": "baseline", "baseline_bfc": "baseline", "baseline_uniform": "baseline",
    "CT1": "ct1",
    "stage1_main_e10": "ct2", "stage2_e3": "ct2", "stage3_e14": "ct2",
    "stage4_e7": "ct2", "stage5_e3": "ct2",
    "stage5_continue_e4": "ct2", "stage6_final": "ct2",
}
RARE_MODES = ["all", "no_rare_0_001", "no_rare_0_01"]
RARE_LABEL = {
    "all": "all codons (no filter)",
    "no_rare_0_001": "no rare &lt; 0.001",
    "no_rare_0_01": "no rare &lt; 0.01",
}
BUCKETS_ORDER = ["<=512", "513-1024", "1025-2048"]
BUCKET_LABEL = {
    "<=512": "short (≤512 aa)",
    "513-1024": "medium (513–1024 aa)",
    "1025-2048": "long (1025–2048 aa)",
}
CT2_STAGES = [m for m in MODEL_ORDER if m.startswith("stage")]
LEARNED_MODELS = ["CT1"] + CT2_STAGES

# ---------------------------------------------------------------- helpers

def fmt(x, n=4):
    if x is None or (isinstance(x, float) and (math.isnan(x) or math.isinf(x))):
        return "—"
    if isinstance(x, (int, np.integer)):
        return f"{int(x):,d}"
    return f"{float(x):.{n}f}"

def fmt_int(x):
    if x is None or pd.isna(x):
        return "—"
    return f"{int(round(float(x))):,d}"

def fmt_pct(x, n=3):
    if x is None or pd.isna(x):
        return "—"
    return f"{100 * float(x):.{n}f}%"

def order_models(df):
    df = df.copy()
    df["model"] = df["model"].astype(str)
    df = df.set_index("model")
    present = [m for m in MODEL_ORDER if m in df.index]
    df = df.loc[present].reset_index()
    df.index = range(len(df))
    return df

def best_set(df, col, lower_is_better, subset_models=None):
    sub = df if subset_models is None else df[df["model"].isin(subset_models)]
    if len(sub) == 0 or sub[col].isna().all():
        return set()
    extreme = sub[col].min() if lower_is_better else sub[col].max()
    return set(sub.index[sub[col] == extreme])

def model_label(m):
    return html_mod.escape(MODEL_DISPLAY.get(m, m))

def row_class(model):
    return f"row-{MODEL_KIND.get(model, 'ct2')}"


# ---------------------------------------------------------------- table builders

def table_generation(gen_df):
    df = order_models(gen_df)
    best_recovery = best_set(df, "codon_recovery", False, LEARNED_MODELS)
    best_nt       = best_set(df, "nt_identity",    False, LEARNED_MODELS)
    best_gc3      = best_set(df, "abs_gc3_error",  True,  LEARNED_MODELS)
    out = ['<table>',
           '<thead><tr><th>Model</th><th>n</th><th>codon_recovery</th>'
           '<th>nt_identity</th><th>abs_gc3_error</th></tr></thead>',
           '<tbody>']
    for i, r in df.iterrows():
        cells = (
            f'<td class="num">{fmt_int(r["n"])}</td>'
            f'<td class="num{" best" if i in best_recovery else ""}">{fmt(r["codon_recovery"])}</td>'
            f'<td class="num{" best" if i in best_nt else ""}">{fmt(r["nt_identity"])}</td>'
            f'<td class="num{" best" if i in best_gc3 else ""}">{fmt(r["abs_gc3_error"])}</td>'
        )
        out.append(f'<tr class="{row_class(r["model"])}"><td>{model_label(r["model"])}</td>{cells}</tr>')
    out.append('</tbody></table>')
    out.append('<p class="caption"><strong>Bold</strong> marks the best <em>learned</em> '
               'model (CT1 + CT2 stages) per column. Native and HFC are trivially '
               'best at codon_recovery / nt_identity by construction.</p>')
    return "\n".join(out)


def _csi_ownwrong_one(df, rare_mode):
    sub = order_models(df[df["rare_mode"] == rare_mode])
    best_own   = best_set(sub, "formal_csi_own", False, LEARNED_MODELS)
    best_delta = best_set(sub, "delta_log_formal_csi_own_minus_wrong", False, LEARNED_MODELS)
    best_ratio = best_set(sub, "ratio_formal_csi_own_over_wrong", False, LEARNED_MODELS)
    out = ['<table>',
           '<thead><tr><th>Model</th><th>n</th><th>own</th><th>wrong (mean of 158)</th>'
           '<th>own / wrong</th><th>Δ log(own − wrong)</th></tr></thead>',
           '<tbody>']
    for i, r in sub.iterrows():
        cells = (
            f'<td class="num">{fmt_int(r["n"])}</td>'
            f'<td class="num{" best" if i in best_own else ""}">{fmt(r["formal_csi_own"])}</td>'
            f'<td class="num">{fmt(r["formal_csi_wrong_mean"])}</td>'
            f'<td class="num{" best" if i in best_ratio else ""}">{fmt(r["ratio_formal_csi_own_over_wrong"])}</td>'
            f'<td class="num{" best" if i in best_delta else ""}">{fmt(r["delta_log_formal_csi_own_minus_wrong"])}</td>'
        )
        out.append(f'<tr class="{row_class(r["model"])}"><td>{model_label(r["model"])}</td>{cells}</tr>')
    out.append('</tbody></table>')
    return "\n".join(out)

def table_csi_ownwrong(df):
    parts = []
    for rm in RARE_MODES:
        parts.append(f'<h3>Rare mode: {RARE_LABEL[rm]}</h3>')
        parts.append(_csi_ownwrong_one(df, rm))
    return "\n".join(parts)


def _cai_one(df, rare_mode):
    sub = order_models(df[df["rare_mode"] == rare_mode])
    best_cai   = best_set(sub, "cai_top10csi_train", False, LEARNED_MODELS)
    out = ['<table>',
           '<thead><tr><th>Model</th><th>n</th><th>CAI top10-CSI-train</th>'
           '<th>missing_weight_frac</th><th>rare_skipped_frac</th></tr></thead>',
           '<tbody>']
    for i, r in sub.iterrows():
        cells = (
            f'<td class="num">{fmt_int(r["n"])}</td>'
            f'<td class="num{" best" if i in best_cai else ""}">{fmt(r["cai_top10csi_train"])}</td>'
            f'<td class="num">{fmt(r["missing_weight_frac"], 6)}</td>'
            f'<td class="num">{fmt(r["rare_skipped_frac"], 6)}</td>'
        )
        out.append(f'<tr class="{row_class(r["model"])}"><td>{model_label(r["model"])}</td>{cells}</tr>')
    out.append('</tbody></table>')
    return "\n".join(out)


def table_cai(df):
    parts = []
    for rm in RARE_MODES:
        parts.append(f'<h3>Rare mode: {RARE_LABEL[rm]}</h3>')
        parts.append(_cai_one(df, rm))
    return "\n".join(parts)


def _rank_one(df, rare_mode):
    sub = order_models(df[df["rare_mode"] == rare_mode])
    best_mean   = best_set(sub, "mean_true_rank", True,  LEARNED_MODELS)
    best_median = best_set(sub, "median_true_rank", True, LEARNED_MODELS)
    best_top100 = best_set(sub, "top100_rate", False, LEARNED_MODELS)
    best_mrr    = best_set(sub, "mean_reciprocal_rank", False, LEARNED_MODELS)
    out = ['<table>',
           '<thead><tr><th>Model</th><th>n</th><th>mean rank</th><th>median rank</th>'
           '<th>top-1</th><th>top-5</th><th>top-10</th><th>top-100</th>'
           '<th>MRR</th></tr></thead>',
           '<tbody>']
    for i, r in sub.iterrows():
        cells = (
            f'<td class="num">{fmt_int(r["n"])}</td>'
            f'<td class="num{" best" if i in best_mean else ""}">{fmt_int(r["mean_true_rank"])}</td>'
            f'<td class="num{" best" if i in best_median else ""}">{fmt_int(r["median_true_rank"])}</td>'
            f'<td class="num">{fmt_pct(r["top1_rate"])}</td>'
            f'<td class="num">{fmt_pct(r["top5_rate"])}</td>'
            f'<td class="num">{fmt_pct(r["top10_rate"])}</td>'
            f'<td class="num{" best" if i in best_top100 else ""}">{fmt_pct(r["top100_rate"])}</td>'
            f'<td class="num{" best" if i in best_mrr else ""}">{fmt(r["mean_reciprocal_rank"], 4)}</td>'
        )
        out.append(f'<tr class="{row_class(r["model"])}"><td>{model_label(r["model"])}</td>{cells}</tr>')
    out.append('</tbody></table>')
    return "\n".join(out)


def table_rank(df):
    parts = []
    for rm in RARE_MODES:
        parts.append(f'<h3>Rare mode: {RARE_LABEL[rm]}</h3>')
        parts.append(_rank_one(df, rm))
    return "\n".join(parts)


def _minmax_global_one(df, rare_mode):
    sub = order_models(df[df["rare_mode"] == rare_mode])
    best_mae  = best_set(sub, "profile_mae",  True,  LEARNED_MODELS)
    best_rmse = best_set(sub, "profile_rmse", True,  LEARNED_MODELS)
    best_corr = best_set(sub, "profile_corr", False, LEARNED_MODELS)
    best_diff = best_set(sub, "abs_mean_minmax_diff", True, LEARNED_MODELS)
    out = ['<table>',
           '<thead><tr><th>Model</th><th>n</th>'
           '<th>profile MAE</th><th>profile RMSE</th><th>profile corr</th>'
           '<th>|mean MinMax diff|</th></tr></thead>',
           '<tbody>']
    for i, r in sub.iterrows():
        cells = (
            f'<td class="num">{fmt_int(r["n"])}</td>'
            f'<td class="num{" best" if i in best_mae else ""}">{fmt(r["profile_mae"], 3)}</td>'
            f'<td class="num{" best" if i in best_rmse else ""}">{fmt(r["profile_rmse"], 3)}</td>'
            f'<td class="num{" best" if i in best_corr else ""}">{fmt(r["profile_corr"], 4)}</td>'
            f'<td class="num{" best" if i in best_diff else ""}">{fmt(r["abs_mean_minmax_diff"], 3)}</td>'
        )
        out.append(f'<tr class="{row_class(r["model"])}"><td>{model_label(r["model"])}</td>{cells}</tr>')
    out.append('</tbody></table>')
    return "\n".join(out)


def table_minmax_global(df):
    parts = []
    for rm in RARE_MODES:
        parts.append(f'<h3>Rare mode: {RARE_LABEL[rm]}</h3>')
        parts.append(_minmax_global_one(df, rm))
    return "\n".join(parts)


def table_minmax_buckets(bucket_df):
    parts = []
    bdf = bucket_df[bucket_df["rare_mode"] == "all"].copy()
    for bucket in BUCKETS_ORDER:
        sub = bdf[bdf["bucket"] == bucket].copy()
        if len(sub) == 0:
            continue
        sub = order_models(sub)
        best_mae  = best_set(sub, "profile_mae",  True,  LEARNED_MODELS)
        best_rmse = best_set(sub, "profile_rmse", True,  LEARNED_MODELS)
        best_corr = best_set(sub, "profile_corr", False, LEARNED_MODELS)
        parts.append(f'<h3>{BUCKET_LABEL[bucket]} &mdash; n={fmt_int(sub["n"].iloc[0])} genes</h3>')
        out = ['<table>',
               '<thead><tr><th>Model</th>'
               '<th>profile MAE</th><th>profile RMSE</th><th>profile corr</th>'
               '<th>|mean MinMax diff|</th></tr></thead>',
               '<tbody>']
        for i, r in sub.iterrows():
            cells = (
                f'<td class="num{" best" if i in best_mae  else ""}">{fmt(r["profile_mae"],  3)}</td>'
                f'<td class="num{" best" if i in best_rmse else ""}">{fmt(r["profile_rmse"], 3)}</td>'
                f'<td class="num{" best" if i in best_corr else ""}">{fmt(r["profile_corr"], 4)}</td>'
                f'<td class="num">{fmt(r["abs_mean_minmax_diff"], 3)}</td>'
            )
            out.append(f'<tr class="{row_class(r["model"])}"><td>{model_label(r["model"])}</td>{cells}</tr>')
        out.append('</tbody></table>')
        parts.append("\n".join(out))
    parts.append('<p class="caption">Per-length-bucket MinMax-18 statistics, '
                 'rare mode "all". (Rare-mode filtering shifts these by &lt; 0.1 in '
                 'MAE/RMSE and is omitted here for readability; full per-rare-mode '
                 'per-bucket numbers are in <code>minmax18_..._summary_by_bucket.csv</code>.)</p>')
    return "\n".join(parts)


def table_compact_summary(gen_df, csi_df, cai_df, rank_df, mm_df):
    g = order_models(gen_df).set_index("model")
    c = order_models(csi_df[csi_df["rare_mode"] == "all"]).set_index("model")
    a = order_models(cai_df[cai_df["rare_mode"] == "all"]).set_index("model")
    r = order_models(rank_df[rank_df["rare_mode"] == "all"]).set_index("model")
    m = order_models(mm_df[mm_df["rare_mode"] == "all"]).set_index("model")

    rows_html = []
    rows_html.append('<table>')
    rows_html.append('<thead><tr><th>Model</th>'
                     '<th>recovery</th><th>nt_id</th><th>|GC3 err|</th>'
                     '<th>CSI own</th><th>Δlog</th>'
                     '<th>CAI</th>'
                     '<th>rank med</th><th>top100</th>'
                     '<th>MM corr</th><th>MM MAE</th>'
                     '</tr></thead>')
    rows_html.append('<tbody>')

    merged = pd.DataFrame(index=[m_ for m_ in MODEL_ORDER if m_ in g.index])
    merged["recovery"] = g["codon_recovery"]
    merged["nt_id"]    = g["nt_identity"]
    merged["gc3"]      = g["abs_gc3_error"]
    merged["csi_own"]  = c["formal_csi_own"]
    merged["delta"]    = c["delta_log_formal_csi_own_minus_wrong"]
    merged["cai"]      = a["cai_top10csi_train"]
    merged["rank_med"] = r["median_true_rank"]
    merged["top100"]   = r["top100_rate"]
    merged["mm_corr"]  = m["profile_corr"]
    merged["mm_mae"]   = m["profile_mae"]

    def best_idx(col, lower):
        sub = merged.loc[[mm for mm in LEARNED_MODELS if mm in merged.index]]
        if sub[col].isna().all(): return set()
        extreme = sub[col].min() if lower else sub[col].max()
        return set(sub.index[sub[col] == extreme])

    bests = {
        "recovery": best_idx("recovery", False),
        "nt_id":    best_idx("nt_id",    False),
        "gc3":      best_idx("gc3",      True),
        "csi_own":  best_idx("csi_own",  False),
        "delta":    best_idx("delta",    False),
        "cai":      best_idx("cai",      False),
        "rank_med": best_idx("rank_med", True),
        "top100":   best_idx("top100",   False),
        "mm_corr":  best_idx("mm_corr",  False),
        "mm_mae":   best_idx("mm_mae",   True),
    }

    for model in [mm for mm in MODEL_ORDER if mm in merged.index]:
        rec = merged.loc[model]
        def cell(col, fmt_fn=fmt):
            extra = " best" if model in bests[col] else ""
            return f'<td class="num{extra}">{fmt_fn(rec[col])}</td>'
        cells = (
            cell("recovery") + cell("nt_id") + cell("gc3") +
            cell("csi_own") + cell("delta") +
            cell("cai") +
            cell("rank_med", fmt_int) + cell("top100", fmt_pct) +
            cell("mm_corr") + cell("mm_mae", lambda x: fmt(x, 3))
        )
        rows_html.append(f'<tr class="{row_class(model)}"><td>{model_label(model)}</td>{cells}</tr>')
    rows_html.append('</tbody></table>')
    rows_html.append('<p class="caption"><strong>Bold</strong> = best <em>learned</em> '
                     'model per metric (rare mode "all"). Native and trivially-optimal '
                     'baselines (HFC at CAI/CSI; HFC at rank top-1) are excluded from the '
                     'best comparison.</p>')
    return "\n".join(rows_html)


# ---------------------------------------------------------------- prose

ABOUT_HTML = """
<section id="about">
  <h2>About this report</h2>
  <p>This report covers the <strong>CT1 vs CT2 — all_trunc2046 common-valid
    benchmark</strong>: 25,465 evaluation genes from the 162 CT1-compatible
    organisms (159 distinct CT2 species), truncated to 2046 amino acids
    (the common max length of CT1 and CT2), with predictions retained only
    when all 12 models produced a valid sequence.</p>

  <p>It supersedes the earlier 162-species / 1,619-gene report by:</p>
  <ul>
    <li>using the full set of overlap genes (25,465, not just 1,619);</li>
    <li>including CT2 Stage 6 (<code>stage6_final</code>) which is absent from the older report;</li>
    <li>computing <strong>rare-mode sensitivity (all / no_rare_0_001 / no_rare_0_01)</strong>
        for every metric family &mdash; not just MinMax &mdash; using a uniform rule.</li>
  </ul>

  <p><strong>The 12 models scored:</strong> <em>native</em> (reference), three frequency baselines
    (HFC = highest synonymous freq, BFC = sample by freq, Uniform), CT1 (trained
    only on the 162-organism overlap set), and seven CT2 checkpoints
    (S1, S2, S3, S4, S5, S5 cont, S6).</p>
</section>
"""

METHODS_HTML = """
<section id="methods">
  <h2>Metrics &amp; rare-mode rule</h2>

  <h3>Generation metrics</h3>
  <p>Per-sequence agreement with the native DNA: <code>codon_recovery</code>
     (fraction of codons identical to native), <code>nt_identity</code> (fraction
     of nucleotides identical), and <code>abs_gc3_error</code> (absolute deviation
     of the predicted 3rd-position GC content from native). No rare modes &mdash; these
     are not rare-codon-sensitive by construction.</p>

  <h3>Formal CSI (own vs wrong)</h3>
  <p>For each codon <em>j</em> coding amino acid <em>i</em> in species <em>s</em>,
     the formal-CSI weight is <code>w<sub>sij</sub> = freq<sub>sij</sub> /
     max<sub>k</sub>(freq<sub>sik</sub>)</code> &mdash; the species&rsquo;s codon
     usage divided by its most-used synonymous codon for that amino acid.
     A sequence&rsquo;s CSI is the geometric mean of <em>w</em> across its codons.
     For each prediction we report the CSI against the true species
     (<strong>own</strong>) and the mean across <strong>all 158 other species in
     the prediction set</strong> (wrong-mean), the ratio, and the log-difference
     (the discriminative signal of interest).</p>

  <h3>CAI top10-CSI-train</h3>
  <p>Standard CAI, but with a leak-free reference: training shards were scanned,
     each gene scored by formal CSI against its own species table, and the
     top 10% (by formal CSI) per species used as the CAI reference set
     (114,315 genes across 159 species). The CAI weights are then standard
     <code>w<sub>sij</sub> = count<sub>sij</sub> / max<sub>k</sub>(count<sub>sik</sub>)</code>
     from this reference. A score is the geometric mean of CAI weights over
     a sequence&rsquo;s codons.</p>

  <h3>Formal CSI species rank</h3>
  <p>For each prediction, score it under formal-CSI against each of the
     <strong>26,678 species</strong> in the codon table and rank the true species
     among the scores. Reported as mean rank, median rank, top-<em>k</em>
     rates, and mean reciprocal rank.</p>

  <h3>MinMax-18 profile</h3>
  <p>Each codon is normalized within its amino acid by
     <code>min</code> (rarest) &rarr; &minus;100, <code>mean</code> &rarr; 0, and
     <code>max</code> (most common) &rarr; +100, then averaged over an
     18-codon sliding window. The native profile and predicted profile are
     compared by absolute mean MinMax diff, profile MAE, profile RMSE, and
     Pearson profile correlation. Unlike CSI/CAI, this captures the
     <em>spatial pattern</em> of rare-vs-common codon placement along the gene,
     not just an aggregate adaptation level.</p>

  <h3>Rare-mode rule (uniform across all metrics)</h3>
  <div class="methods">
    The codon-usage parquet has pre-computed boolean columns
    <code>rare_lt_0_001</code> and <code>rare_lt_0_01</code> marking each
    <code>(species, aa, codon)</code> entry as rare if its frequency in that
    species is below 0.1% or 1% respectively. In a given rare mode, those
    entries are <strong>dropped from the lookup table</strong> before any
    per-sequence score is computed, and codon positions whose entry is dropped
    are <strong>skipped</strong> from the score aggregation. This is the exact
    rule applied by the original <code>eval_minmax_ct2_stages.py</code>; in
    this report it is applied identically to CSI own/wrong, CAI, and the rank
    metric. Rationale: a missing rare codon should not be penalized to a
    sentinel value (which would conflate filtering with mismatch), so we
    skip it &mdash; matching MinMax&rsquo;s semantics.
  </div>
</section>
"""

MINMAX_WHAT_IT_CONVEYS = """
<h3>What MinMax-18 conveys</h3>
<p>Where CSI and CAI collapse a sequence to a single adaptation scalar
   &mdash; the geometric mean of per-codon weights &mdash; MinMax-18 keeps
   the <strong>spatial structure</strong>: a per-window number that says
   how rare-leaning or common-leaning the codons are at <em>that point</em>
   of the gene. Comparing the predicted profile to the native profile then
   answers a different question than CSI/CAI: not &ldquo;is the overall
   codon usage close to native?&rdquo; but &ldquo;does the model reproduce
   the native <em>rhythm</em> &mdash; the alternation of fast (common) and
   slow (rare) stretches along the ORF?&rdquo;</p>
<p>That rhythm has direct biological meaning. Patches of rarer codons in
   real proteins are associated with translational pausing, which in turn
   is implicated in co-translational folding of multi-domain proteins,
   signal peptide processing, and the rate-matching of synthesis with
   chaperone availability. A predictor that gets the average adaptation
   right but flattens the profile (uses common codons uniformly) will
   match CSI/CAI well but score badly on MinMax. Conversely, a predictor
   that places its rare codons in roughly the right places will have high
   MinMax correlation even if its overall level is slightly off &mdash;
   which is precisely the pattern we see for CT2 (next subsection).</p>
<p>The window size 18 codons (~6 amino acids) is the standard choice from
   the Clarke &amp; Clark and Welch et al. literature for capturing
   translational-rhythm scales; smaller windows are dominated by sampling
   noise, larger windows over-smooth the local structure.</p>
"""

MINMAX_MAGNITUDE_VS_SHAPE = """
<div class="callout">
  <strong>Magnitude vs shape:</strong> Two predictors with similar overall
  codon-usage levels can differ in how they distribute those codons along
  the gene. <em>Profile MAE</em> primarily reflects level agreement
  &mdash; how close the predicted profile is to native in absolute MinMax
  units. <em>Profile correlation</em> primarily reflects shape agreement
  &mdash; whether the predicted profile rises and falls where the native
  profile rises and falls. Looking at the table above, the BFC baseline
  (which samples codons from each species&rsquo;s frequency distribution
  independently per position) gives a competitive MAE because its mean
  level matches native by construction, but its correlation is poor
  because position-independent sampling cannot place rare codons in the
  right local context. CT2 stages 5/5cont/6, by contrast, lift the profile
  correlation substantially &mdash; meaning the model has learned where
  along the protein rare codons should appear, even if the absolute level
  isn&rsquo;t perfect. This is the qualitative content of MinMax that
  CSI/CAI cannot expose.</div>
"""


# ---------------------------------------------------------------- main

CSS = """
:root {
  --bg: #ffffff; --fg: #1d1d1f; --muted: #6b6f76; --border: #e2e4ea;
  --accent: #2552c8; --best: #0a7a2f; --warn: #b67400;
}
* { box-sizing: border-box; }
body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  background: var(--bg); color: var(--fg);
  max-width: 1200px; margin: 2em auto; padding: 0 1.5em;
  line-height: 1.5;
}
h1 { font-size: 1.7em; margin-bottom: 0.2em; border-bottom: 2px solid var(--accent); padding-bottom: 0.25em; }
h2 { font-size: 1.25em; color: var(--accent); margin-top: 2em;
     border-bottom: 1px solid var(--border); padding-bottom: 0.2em; }
h3 { font-size: 1.05em; color: #2b2b30; margin-top: 1.4em; margin-bottom: 0.5em; }
section { margin-bottom: 1em; }
.toc { font-size: 0.92em; margin: 0 0 1.5em 0; padding: 0.6em 0.9em;
       background: #f5f7fb; border: 1px solid var(--border); border-radius: 4px; }
.toc a { color: var(--accent); text-decoration: none; margin-right: 0.9em; white-space: nowrap; }
.toc a:hover { text-decoration: underline; }
table { border-collapse: collapse; margin: 0.6em 0 0.4em 0;
        font-variant-numeric: tabular-nums; font-size: 0.92em; }
th, td { padding: 0.34em 0.7em; border: 1px solid var(--border); text-align: right; }
th { background: #eef2fa; font-weight: 600; }
td:first-child, th:first-child { text-align: left; white-space: nowrap; }
.num { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }
.best { font-weight: 700; color: var(--best); }
.row-ref      { background: #f3f3f5; }
.row-baseline { background: #fcf6e6; }
.row-ct1      { background: #e7eefc; }
.row-ct2      { background: #ffffff; }
.callout { background: #fff4dd; border-left: 4px solid var(--warn);
           padding: 0.7em 1em; margin: 1em 0; border-radius: 0 4px 4px 0; }
.methods { background: #eef2fa; border: 1px solid #c9d3e8;
           padding: 0.7em 1em; margin: 0.8em 0; border-radius: 4px; font-size: 0.95em; }
.caption { color: var(--muted); font-size: 0.86em; margin: 0.3em 0 1em 0; }
.footer  { color: var(--muted); font-size: 0.85em; margin-top: 3em;
           border-top: 1px solid var(--border); padding-top: 0.8em; }
code { background: #f0f2f6; padding: 0 0.3em; border-radius: 3px;
       font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
       font-size: 0.92em; }
"""

TOC_HTML = """
<div class="toc">
  <a href="#about">About</a>
  <a href="#methods">Metrics &amp; rare-mode rule</a>
  <a href="#generation">Generation</a>
  <a href="#csi">CSI own/wrong</a>
  <a href="#cai">CAI top10-CSI-train</a>
  <a href="#rank">CSI rank</a>
  <a href="#minmax">MinMax-18 profile</a>
  <a href="#compact">Compact summary</a>
</div>
"""


def build_report(args):
    gen = pd.read_csv(args.generation)
    csi = pd.read_csv(args.csi_ownwrong)
    cai = pd.read_csv(args.cai)
    rank = pd.read_csv(args.rank)
    mm_global = pd.read_csv(args.minmax_global)
    mm_bucket = pd.read_csv(args.minmax_bucket)

    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    parts = []
    parts.append('<!DOCTYPE html><html lang="en"><head><meta charset="utf-8" />')
    parts.append('<title>CT1 vs CT2 — all_trunc2046 — Full rare-mode panel</title>')
    parts.append(f'<style>{CSS}</style></head><body>')

    parts.append('<h1>CT1 vs CT2 &mdash; all_trunc2046 common-valid benchmark</h1>')
    parts.append(f'<p class="caption">Full panel: 12 models &times; 4 metric families &times; 3 rare modes. Generated {now}.</p>')

    parts.append(TOC_HTML)
    parts.append(ABOUT_HTML)
    parts.append(METHODS_HTML)

    parts.append('<section id="generation"><h2>Generation metrics</h2>')
    parts.append('<p>Per-sequence agreement with the native DNA. No rare-mode '
                 'variants are computed for these (the metrics are not '
                 'rare-codon-sensitive by definition).</p>')
    parts.append(table_generation(gen))
    parts.append('</section>')

    parts.append('<section id="csi"><h2>Formal CSI &mdash; own vs wrong-mean (158)</h2>')
    parts.append('<p>Geometric mean of formal-CSI weights, evaluated against the '
                 "true species and against the mean of the 158 other species in "
                 "the benchmark. The log-difference (own − wrong) is the "
                 "discriminative signal of interest.</p>")
    parts.append(table_csi_ownwrong(csi))
    parts.append('</section>')

    parts.append('<section id="cai"><h2>CAI &mdash; top10-CSI-train reference</h2>')
    parts.append('<p>Leak-free CAI: reference set is the top 10% of training genes '
                 'per species, selected by formal CSI. The rare-mode columns are '
                 'nearly identical in CAI score because rare codons make up &lt;2% '
                 'of all codon positions; however, the per-model '
                 '<code>rare_skipped_frac</code> reveals systematic differences '
                 '&mdash; HFC and learned models (CT1, CT2 S5/S5-cont/S6) avoid '
                 'rare codons strongly, while baseline_uniform and early CT2 '
                 'stages do not.</p>')
    parts.append(table_cai(cai))
    parts.append('</section>')

    parts.append('<section id="rank"><h2>Formal CSI species rank (universe = 26,678)</h2>')
    parts.append('<p>For each prediction, rank the true species by formal-CSI '
                 'score across all 26,678 species in the codon table. HFC trivially '
                 'ranks 1.0 by construction (its codons <em>are</em> each species&rsquo;s '
                 'maximum-frequency codons).</p>')
    parts.append(table_rank(rank))
    parts.append('</section>')

    parts.append('<section id="minmax"><h2>MinMax-18 profile</h2>')
    parts.append(MINMAX_WHAT_IT_CONVEYS)
    parts.append('<h3>Global summary (3 rare modes)</h3>')
    parts.append(table_minmax_global(mm_global))
    parts.append(MINMAX_MAGNITUDE_VS_SHAPE)
    parts.append('<h3>Per-length-bucket breakdown</h3>')
    parts.append('<p>Sequences split by protein length. Short genes (≤512 aa) '
                 'dominate the benchmark by count, but long genes (1025–2048 aa) '
                 'are the most informative test of MinMax because rhythm-effects '
                 'on translation pacing only have room to express in longer ORFs.</p>')
    parts.append(table_minmax_buckets(mm_bucket))
    parts.append('</section>')

    parts.append('<section id="compact"><h2>Compact summary &mdash; one row per model</h2>')
    parts.append('<p>Key column from each metric family, all in rare mode "all". '
                 'Bold marks the best <em>learned</em> model (CT1 + CT2 stages) per column.</p>')
    parts.append(table_compact_summary(gen, csi, cai, rank, mm_global))
    parts.append('</section>')

    parts.append(f'<p class="footer">CT1-vs-CT2 all_trunc2046 common-valid benchmark report &mdash; generated {now}.<br />'
                 'Source CSVs: generation, formal_csi_own_wrong_rare, cai_top10csi_train_w8_rare, '
                 'formal_csi_rank_rare, minmax18 (global + bucket). All metrics use the '
                 'identical parquet-row rare-filter rule from <code>eval_minmax_ct2_stages.py</code>.</p>')
    parts.append('</body></html>')

    out_path = Path(args.out)
    out_path.write_text("\n".join(parts), encoding="utf-8")
    print(f"wrote: {out_path}  ({out_path.stat().st_size:,} bytes)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--generation",   default="ct1_vs_ct2_all_trunc2046_common_valid_generation_summary.csv")
    ap.add_argument("--csi_ownwrong", default="formal_csi_own_wrong_rare_ct1_vs_ct2_all_trunc2046_common_valid_summary_by_model.csv")
    ap.add_argument("--cai",          default="cai_top10csi_train_w8_rare_ct1_vs_ct2_all_trunc2046_common_valid_summary_by_model.csv")
    ap.add_argument("--rank",         default="formal_csi_rank_rare_ct1_vs_ct2_all_trunc2046_common_valid_summary_by_model.csv")
    ap.add_argument("--minmax_global",default="minmax18_ct1_vs_ct2_all_trunc2046_common_valid_summary_by_model.csv")
    ap.add_argument("--minmax_bucket",default="minmax18_ct1_vs_ct2_all_trunc2046_common_valid_summary_by_bucket.csv")
    ap.add_argument("--out",          default="ct1_vs_ct2_all_trunc2046_FULL_RARE_report.html")
    args = ap.parse_args()
    build_report(args)


if __name__ == "__main__":
    main()
