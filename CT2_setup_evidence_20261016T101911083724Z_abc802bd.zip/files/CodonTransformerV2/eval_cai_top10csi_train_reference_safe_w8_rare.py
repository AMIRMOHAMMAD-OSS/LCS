"""
eval_cai_top10csi_train_reference_safe_w8_rare.py

CAI-top10CSI-train with rare-mode sensitivity.

Differences from eval_cai_top10csi_train_reference_safe_w8.py:

  1. Adds a rare-mode loop over ("all", "no_rare_0_001", "no_rare_0_01")
     at the FINAL scoring step. Reference selection (training-shard scan,
     top-10% CSI selection, CAI weight build) is NOT redone per rare mode
     -- it's computed ONCE, exactly the same way as before.

  2. Adds --cache_dir to point at an existing training-shard CSI cache.
     If the cache already contains scored batches, the (very expensive)
     training scan is skipped entirely.

  3. Rare-mode filter at scoring time: a codon position in a prediction
     is skipped if its (species, aa, codon) is marked rare in the
     codon-table parquet for the chosen rare column. This is exactly
     the parquet-row filter eval_minmax_ct2_stages.py applies.

Usage (reusing existing cache from the previous CAI run):
  python eval_cai_top10csi_train_reference_safe_w8_rare.py \\
    --predictions ct1_vs_ct2_all_trunc2046_common_valid_predictions.csv \\
    --codon_table ct2_codon_usage_tables_qc/ct2_train_species_codon_frequencies_clean.parquet \\
    --cache_dir cai_top10csi_train_w8_ct1_vs_ct2_all_trunc2046_common_valid_cache \\
    --out_prefix cai_top10csi_train_w8_rare_ct1_vs_ct2_all_trunc2046_common_valid \\
    --workers 8 --score_chunksize 200

(If --cache_dir is unset or empty, --shard_glob is required and the slow
training scan runs from scratch, same as the original script.)
"""

import argparse
import glob
import json
import math
import multiprocessing as mp
import tarfile
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm


GENETIC_CODE = {
    "TTT": "F", "TTC": "F", "TTA": "L", "TTG": "L",
    "TCT": "S", "TCC": "S", "TCA": "S", "TCG": "S",
    "TAT": "Y", "TAC": "Y", "TAA": "*", "TAG": "*",
    "TGT": "C", "TGC": "C", "TGA": "*", "TGG": "W",
    "CTT": "L", "CTC": "L", "CTA": "L", "CTG": "L",
    "CCT": "P", "CCC": "P", "CCA": "P", "CCG": "P",
    "CAT": "H", "CAC": "H", "CAA": "Q", "CAG": "Q",
    "CGT": "R", "CGC": "R", "CGA": "R", "CGG": "R",
    "ATT": "I", "ATC": "I", "ATA": "I", "ATG": "M",
    "ACT": "T", "ACC": "T", "ACA": "T", "ACG": "T",
    "AAT": "N", "AAC": "N", "AAA": "K", "AAG": "K",
    "AGT": "S", "AGC": "S", "AGA": "R", "AGG": "R",
    "GTT": "V", "GTC": "V", "GTA": "V", "GTG": "V",
    "GCT": "A", "GCC": "A", "GCA": "A", "GCG": "A",
    "GAT": "D", "GAC": "D", "GAA": "E", "GAG": "E",
    "GGT": "G", "GGC": "G", "GGA": "G", "GGG": "G",
}

SYNONYMOUS_CODONS = defaultdict(list)
for codon, aa in GENETIC_CODE.items():
    if aa != "*":
        SYNONYMOUS_CODONS[aa].append(codon)

# Worker globals
G_TARGET_SPECIES = None
G_CSI_WEIGHTS = None
G_CAI_WEIGHTS = None
G_SKIP_SET = None
G_RARE_MODE = None


def clean_dna(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def clean_protein(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).strip().upper().rstrip("*_")


def iter_codons(seq):
    seq = clean_dna(seq)
    for i in range(0, len(seq) - 2, 3):
        codon = seq[i:i + 3]
        if len(codon) != 3 or any(c not in "ACGT" for c in codon):
            continue
        aa = GENETIC_CODE.get(codon)
        if aa is None or aa == "*":
            continue
        yield aa, codon


# ----------------------------------------------------------------------
# Training-shard scan helpers (unchanged from the original script)
# ----------------------------------------------------------------------

def read_records_from_shard(path):
    with tarfile.open(path, "r:gz") as tar:
        for member in tar:
            if not member.isfile():
                continue
            if not member.name.endswith((".json", ".jsonl")):
                continue
            f = tar.extractfile(member)
            if f is None:
                continue
            raw = f.read().decode("utf-8", errors="replace").strip()
            if not raw:
                continue
            if member.name.endswith(".jsonl"):
                for line in raw.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        yield json.loads(line)
                    except Exception:
                        continue
            else:
                try:
                    obj = json.loads(raw)
                except Exception:
                    continue
                if isinstance(obj, list):
                    for x in obj:
                        yield x
                else:
                    yield obj


def normalize_record(rec):
    if not isinstance(rec, dict):
        return None
    species = rec.get("species")
    genome_id = rec.get("genome_id", "")
    protein_id = rec.get("protein_id", "")
    dna = rec.get("dna_sequence")
    protein = rec.get("protein_sequence")
    if species is None or dna is None or protein is None:
        return None
    dna = clean_dna(dna)
    protein = clean_protein(protein)
    if not dna or not protein:
        return None
    need = 3 * len(protein)
    if len(dna) < need:
        return None
    return str(species), str(genome_id), str(protein_id), dna[:need], len(protein)


def build_formal_csi_weights(codon_table, target_species):
    freq = pd.read_parquet(codon_table)
    freq["species"] = freq["species"].astype(str)
    freq = freq[freq["species"].isin(target_species)].copy()

    print("filtered codon table rows:", len(freq), flush=True)
    print("filtered codon table species:", freq["species"].nunique(), flush=True)

    max_freq = (
        freq.groupby(["species", "aa"], as_index=False)["frequency"]
        .max()
        .rename(columns={"frequency": "max_frequency"})
    )
    use = freq.merge(max_freq, on=["species", "aa"], how="left")
    use["weight"] = use["frequency"] / use["max_frequency"]

    weights = {}
    for r in tqdm(use.itertuples(index=False), total=len(use),
                  desc="building target formal CSI weights"):
        weights[(str(r.species), str(r.aa), str(r.codon))] = float(r.weight)
    return weights


def geomean_weight(seq, species, weights):
    logs = []
    total = 0
    missing = 0
    for aa, codon in iter_codons(seq):
        total += 1
        w = weights.get((species, aa, codon))
        if w is None or w <= 0:
            missing += 1
            continue
        logs.append(math.log(w))
    if not logs:
        return np.nan, total, missing
    return float(math.exp(sum(logs) / len(logs))), total, missing


def init_train_worker(target_species, csi_weights):
    global G_TARGET_SPECIES, G_CSI_WEIGHTS
    G_TARGET_SPECIES = set(target_species)
    G_CSI_WEIGHTS = csi_weights


def process_shard_for_train_csi(spath):
    rows = []
    seen = 0
    kept = 0
    for rec in read_records_from_shard(spath):
        seen += 1
        norm = normalize_record(rec)
        if norm is None:
            continue
        species, genome_id, protein_id, dna, protein_len = norm
        if species not in G_TARGET_SPECIES:
            continue
        csi, total, missing = geomean_weight(dna, species, G_CSI_WEIGHTS)
        if pd.isna(csi):
            continue
        rows.append({
            "species": species, "genome_id": genome_id, "protein_id": protein_id,
            "dna": dna, "protein_len": protein_len,
            "formal_csi": csi, "codons_total": total,
            "missing_weight_frac": missing / max(total, 1),
        })
        kept += 1
    return rows, seen, kept, str(spath)


def score_training_batches(shards, target_species, csi_weights, cache_dir,
                           shards_per_batch, workers, chunksize):
    cache_dir.mkdir(parents=True, exist_ok=True)
    columns = ["species", "genome_id", "protein_id", "dna", "protein_len",
               "formal_csi", "codons_total", "missing_weight_frac"]
    n_batches = math.ceil(len(shards) / shards_per_batch)
    for b in range(n_batches):
        start = b * shards_per_batch
        end = min((b + 1) * shards_per_batch, len(shards))
        out = cache_dir / f"train_topcsi_batch_{b:04d}.parquet"
        if out.exists():
            print(f"batch {b + 1}/{n_batches}: exists, skipping {out}", flush=True)
            continue
        batch_shards = shards[start:end]
        rows = []
        total_seen = 0
        total_kept = 0
        print(f"\n=== batch {b + 1}/{n_batches} shards {start}:{end} workers={workers} ===", flush=True)
        with mp.Pool(processes=workers, initializer=init_train_worker,
                     initargs=(target_species, csi_weights)) as pool:
            for shard_rows, seen, kept, spath in tqdm(
                pool.imap_unordered(process_shard_for_train_csi, batch_shards, chunksize=chunksize),
                total=len(batch_shards), desc=f"batch {b + 1}/{n_batches}",
            ):
                rows.extend(shard_rows)
                total_seen += seen
                total_kept += kept
        df = pd.DataFrame(rows, columns=columns)
        df.to_parquet(out, index=False)
        print(f"wrote {out} rows={len(df)} seen={total_seen} kept={total_kept}", flush=True)


def load_scored_training(cache_dir):
    files = sorted(cache_dir.glob("train_topcsi_batch_*.parquet"))
    if not files:
        raise SystemExit(f"No cache parquet files found in {cache_dir}")
    dfs = []
    for f in files:
        df = pd.read_parquet(f)
        if len(df):
            dfs.append(df)
    if not dfs:
        raise SystemExit("All cache parquet files are empty.")
    return pd.concat(dfs, ignore_index=True)


def select_top10(scored, top_frac):
    selected = []
    for species, g in scored.groupby("species", sort=False):
        g = g.sort_values("formal_csi", ascending=False)
        n_top = max(1, int(math.ceil(top_frac * len(g))))
        selected.append(g.head(n_top))
    return pd.concat(selected, ignore_index=True)


def build_cai_weights(top_ref, pseudocount):
    counts = defaultdict(float)
    species_set = sorted(top_ref["species"].astype(str).unique())
    for species in species_set:
        for aa, codons in SYNONYMOUS_CODONS.items():
            for codon in codons:
                counts[(species, aa, codon)] += pseudocount
    for r in tqdm(top_ref.itertuples(index=False), total=len(top_ref),
                  desc="counting top10CSI reference codons"):
        species = str(r.species)
        for aa, codon in iter_codons(r.dna):
            counts[(species, aa, codon)] += 1.0
    max_by_species_aa = defaultdict(float)
    for (species, aa, codon), count in counts.items():
        if count > max_by_species_aa[(species, aa)]:
            max_by_species_aa[(species, aa)] = count
    weights = {}
    for key, count in counts.items():
        species, aa, codon = key
        mx = max_by_species_aa[(species, aa)]
        if mx > 0:
            weights[key] = count / mx
    return weights


# ----------------------------------------------------------------------
# NEW: rare-mode-aware scoring
# ----------------------------------------------------------------------

def cai_score_rare(seq, species, weights, skip_set):
    logs = []
    total = 0
    missing = 0
    rare_skipped = 0
    for aa, codon in iter_codons(seq):
        total += 1
        key = (species, aa, codon)
        if key in skip_set:
            rare_skipped += 1
            continue
        w = weights.get(key)
        if w is None or w <= 0:
            missing += 1
            continue
        logs.append(math.log(w))
    if not logs:
        return np.nan, total, missing, rare_skipped
    return float(math.exp(sum(logs) / len(logs))), total, missing, rare_skipped


def init_cai_worker_rare(cai_weights, skip_set, rare_mode):
    global G_CAI_WEIGHTS, G_SKIP_SET, G_RARE_MODE
    G_CAI_WEIGHTS = cai_weights
    G_SKIP_SET = skip_set
    G_RARE_MODE = rare_mode


def score_prediction_row_rare(rec):
    species = str(rec["species"])
    score, total, missing, rare_skipped = cai_score_rare(
        rec["pred_dna"], species, G_CAI_WEIGHTS, G_SKIP_SET
    )
    row = {
        "rare_mode": G_RARE_MODE,
        "model": rec["model"],
        "eval_id": rec.get("eval_id", ""),
        "species": species,
        "cai_top10csi_train": score,
        "codons_total": total,
        "codons_missing_weight": missing,
        "codons_rare_skipped": rare_skipped,
        "missing_weight_frac": missing / max(total, 1),
        "rare_skipped_frac": rare_skipped / max(total, 1),
    }
    if "bucket" in rec:
        row["bucket"] = rec["bucket"]
    if "protein_len" in rec:
        row["protein_len"] = rec["protein_len"]
    return row


def score_predictions_parallel_rare(pred, cai_weights, skip_set, rare_mode, workers, chunksize):
    records = pred.to_dict(orient="records")
    rows = []
    with mp.Pool(processes=workers, initializer=init_cai_worker_rare,
                 initargs=(cai_weights, skip_set, rare_mode)) as pool:
        for row in tqdm(
            pool.imap(score_prediction_row_rare, records, chunksize=chunksize),
            total=len(records), desc=f"CAI scoring [{rare_mode}]",
        ):
            rows.append(row)
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--shard_glob", default=None,
                    help="Glob for training shards. Only used if cache is empty.")
    ap.add_argument("--cache_dir", default=None,
                    help="Path to existing training-shard CSI cache (skips slow scan if non-empty).")
    ap.add_argument("--out_prefix", required=True)
    ap.add_argument("--shards_per_batch", type=int, default=250)
    ap.add_argument("--top_frac", type=float, default=0.10)
    ap.add_argument("--pseudocount", type=float, default=1.0)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--chunksize", type=int, default=4)
    ap.add_argument("--score_chunksize", type=int, default=200)
    args = ap.parse_args()

    pred = pd.read_csv(args.predictions, low_memory=False)
    pred = pred[pred["pred_dna"].fillna("").astype(str).str.len() > 0].copy()

    target_species = sorted(pred["species"].astype(str).unique().tolist())
    print("prediction rows:", len(pred), flush=True)
    print("models:", pred["model"].nunique(), flush=True)
    print("target species:", len(target_species), flush=True)
    print("workers:", args.workers, flush=True)

    cache_dir = Path(args.cache_dir) if args.cache_dir else Path(f"{args.out_prefix}_cache")
    print("cache_dir:", cache_dir, flush=True)

    csi_weights = build_formal_csi_weights(args.codon_table, set(target_species))

    cached = cache_dir.exists() and any(cache_dir.glob("train_topcsi_batch_*.parquet"))
    if not cached:
        if not args.shard_glob:
            raise SystemExit(
                "Cache is empty and --shard_glob not provided. "
                "Either provide --shard_glob to (re)scan training shards, or "
                "--cache_dir pointing at an existing cache from a previous run."
            )
        shards = sorted(glob.glob(args.shard_glob))
        print("shards:", len(shards), flush=True)
        if not shards:
            raise SystemExit("No shards matched --shard_glob.")
        score_training_batches(
            shards=shards, target_species=target_species, csi_weights=csi_weights,
            cache_dir=cache_dir, shards_per_batch=args.shards_per_batch,
            workers=args.workers, chunksize=args.chunksize,
        )
    else:
        n_files = len(list(cache_dir.glob("train_topcsi_batch_*.parquet")))
        print(f"reusing existing training-scan cache at {cache_dir} ({n_files} batch files)", flush=True)

    scored = load_scored_training(cache_dir)
    print("scored train genes:", len(scored), flush=True)
    print("scored species:", scored["species"].nunique(), flush=True)

    top_ref = select_top10(scored, args.top_frac)
    top_ref.to_parquet(f"{args.out_prefix}_top10csi_train_reference_genes.parquet", index=False)
    print("top reference genes:", len(top_ref), flush=True)
    print("top reference species:", top_ref["species"].nunique(), flush=True)

    ref_summary = (
        top_ref.groupby("species", as_index=False)
        .agg(
            top_ref_genes=("dna", "count"),
            mean_ref_csi=("formal_csi", "mean"),
            mean_ref_len=("protein_len", "mean"),
        )
    )
    ref_summary.to_csv(f"{args.out_prefix}_top10csi_train_reference_summary_by_species.csv", index=False)

    cai_weights = build_cai_weights(top_ref, args.pseudocount)
    print("CAI weights:", len(cai_weights), flush=True)

    # Build skip sets per rare mode from the parquet rare flags
    rare_flag_df = pd.read_parquet(args.codon_table)
    rare_flag_df["species"] = rare_flag_df["species"].astype(str)
    rare_flag_df = rare_flag_df[rare_flag_df["species"].isin(set(target_species))]
    print("rare-flag parquet rows (filtered to target species):", len(rare_flag_df), flush=True)

    rare_modes = [
        ("all", None),
        ("no_rare_0_001", "rare_lt_0_001"),
        ("no_rare_0_01", "rare_lt_0_01"),
    ]

    skip_sets = {}
    for rare_mode, rare_col in rare_modes:
        if rare_col is None:
            skip_sets[rare_mode] = frozenset()
        else:
            rare_rows = rare_flag_df[rare_flag_df[rare_col]]
            s = frozenset(
                (str(r.species), str(r.aa), str(r.codon))
                for r in rare_rows.itertuples(index=False)
            )
            skip_sets[rare_mode] = s
        print(f"  skip set [{rare_mode}]: {len(skip_sets[rare_mode])} (species, aa, codon) entries", flush=True)

    # Score predictions in 3 rare modes
    all_results = []
    for rare_mode, _rc in rare_modes:
        print("\n" + "=" * 80, flush=True)
        print("RARE MODE:", rare_mode, flush=True)
        print("=" * 80, flush=True)
        out_mode = score_predictions_parallel_rare(
            pred=pred, cai_weights=cai_weights,
            skip_set=skip_sets[rare_mode], rare_mode=rare_mode,
            workers=args.workers, chunksize=args.score_chunksize,
        )
        partial = f"{args.out_prefix}_{rare_mode}_by_sequence.csv"
        out_mode.to_csv(partial, index=False)
        print("wrote partial:", partial, flush=True)
        all_results.append(out_mode)

    by_seq = pd.concat(all_results, ignore_index=True)
    out_seq = f"{args.out_prefix}_by_sequence.csv"
    by_seq.to_csv(out_seq, index=False)

    summary = (
        by_seq.groupby(["rare_mode", "model"], as_index=False)
        .agg(
            n=("eval_id", "count"),
            cai_top10csi_train=("cai_top10csi_train", "mean"),
            missing_weight_frac=("missing_weight_frac", "mean"),
            rare_skipped_frac=("rare_skipped_frac", "mean"),
        )
    )
    out_model = f"{args.out_prefix}_summary_by_model.csv"
    summary.to_csv(out_model, index=False)

    print("\n=== CAI-top10CSI-train (rare modes) SUMMARY ===", flush=True)
    print(summary.to_string(index=False), flush=True)
    print("\nwrote:", out_seq, flush=True)
    print("wrote:", out_model, flush=True)


if __name__ == "__main__":
    main()
