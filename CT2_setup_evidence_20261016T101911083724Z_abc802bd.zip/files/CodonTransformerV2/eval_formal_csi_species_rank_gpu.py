import argparse
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm


GENETIC_CODE = {
    "TTT":"F","TTC":"F","TTA":"L","TTG":"L",
    "TCT":"S","TCC":"S","TCA":"S","TCG":"S",
    "TAT":"Y","TAC":"Y","TAA":"*","TAG":"*",
    "TGT":"C","TGC":"C","TGA":"*","TGG":"W",
    "CTT":"L","CTC":"L","CTA":"L","CTG":"L",
    "CCT":"P","CCC":"P","CCA":"P","CCG":"P",
    "CAT":"H","CAC":"H","CAA":"Q","CAG":"Q",
    "CGT":"R","CGC":"R","CGA":"R","CGG":"R",
    "ATT":"I","ATC":"I","ATA":"I","ATG":"M",
    "ACT":"T","ACC":"T","ACA":"T","ACG":"T",
    "AAT":"N","AAC":"N","AAA":"K","AAG":"K",
    "AGT":"S","AGC":"S","AGA":"R","AGG":"R",
    "GTT":"V","GTC":"V","GTA":"V","GTG":"V",
    "GCT":"A","GCC":"A","GCA":"A","GCG":"A",
    "GAT":"D","GAC":"D","GAA":"E","GAG":"E",
    "GGT":"G","GGC":"G","GGA":"G","GGG":"G",
}

SENSE_CODONS = [c for c, aa in GENETIC_CODE.items() if aa != "*"]
CODON_TO_IDX = {c: i for i, c in enumerate(SENSE_CODONS)}


def clean_dna(x):
    if x is None or pd.isna(x):
        return ""
    return str(x).upper().replace("U", "T").replace(" ", "").replace("\n", "").replace("\r", "")


def count_codons(seq):
    seq = clean_dna(seq)
    v = np.zeros(len(SENSE_CODONS), dtype=np.float32)
    n = 0

    for i in range(0, len(seq) - 2, 3):
        codon = seq[i:i+3]
        j = CODON_TO_IDX.get(codon)
        if j is not None:
            v[j] += 1.0
            n += 1

    return v, n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", required=True)
    ap.add_argument("--codon_table", required=True)
    ap.add_argument("--out_prefix", required=True)
    ap.add_argument("--batch_size", type=int, default=512)
    ap.add_argument("--device", default="cuda")
    args = ap.parse_args()

    device = torch.device(args.device if args.device == "cuda" and torch.cuda.is_available() else "cpu")

    pred = pd.read_csv(args.predictions, low_memory=False)
    pred = pred[pred["pred_dna"].fillna("").astype(str).str.len() > 0].copy()
    pred = pred.reset_index(drop=True)

    freq = pd.read_parquet(args.codon_table)

    species_list = sorted(freq["species"].dropna().astype(str).unique().tolist())
    species_to_col = {s: i for i, s in enumerate(species_list)}

    print("prediction rows:", len(pred))
    print("models:", pred["model"].nunique())
    print("species tables:", len(species_list))
    print("device:", device)

    # Formal CSI weight:
    # w_ij = freq_ij / max_synonymous_freq_for_amino_acid_i_in_species
    max_freq = (
        freq.groupby(["species", "aa"], as_index=False)["frequency"]
        .max()
        .rename(columns={"frequency": "max_frequency"})
    )
    use = freq.merge(max_freq, on=["species", "aa"], how="left")
    use["weight"] = use["frequency"] / use["max_frequency"]

    # Matrix: codon x species, containing log formal-CSI weight.
    # Missing impossible entries get large negative value.
    logw = np.full((len(SENSE_CODONS), len(species_list)), -50.0, dtype=np.float32)

    for r in tqdm(use.itertuples(index=False), total=len(use), desc="building log-weight matrix"):
        codon = str(r.codon)
        species = str(r.species)
        weight = float(r.weight)

        if codon in CODON_TO_IDX and species in species_to_col and weight > 0:
            logw[CODON_TO_IDX[codon], species_to_col[species]] = np.log(weight)

    logw_t = torch.tensor(logw, dtype=torch.float32, device=device)

    true_cols = pred["species"].astype(str).map(species_to_col)
    true_in_table = true_cols.notna().to_numpy()
    true_cols_np = true_cols.fillna(-1).astype(int).to_numpy()

    X = []
    n_valid = []

    for seq in tqdm(pred["pred_dna"], desc="counting codons"):
        v, n = count_codons(seq)
        X.append(v)
        n_valid.append(n)

    X = np.vstack(X).astype(np.float32)
    n_valid = np.asarray(n_valid, dtype=np.float32)

    rows = []

    for start in tqdm(range(0, len(pred), args.batch_size), desc="ranking"):
        end = min(start + args.batch_size, len(pred))

        xb = torch.tensor(X[start:end], dtype=torch.float32, device=device)
        denom = torch.tensor(np.maximum(n_valid[start:end], 1.0), dtype=torch.float32, device=device)[:, None]

        # Average log formal-CSI score against every species.
        scores = (xb @ logw_t) / denom

        for i in range(end - start):
            row_idx = start + i

            if not true_in_table[row_idx] or n_valid[row_idx] <= 0:
                true_score = np.nan
                true_rank = np.nan
            else:
                true_col = true_cols_np[row_idx]
                true_score_t = scores[i, true_col]
                true_rank = int((scores[i] > true_score_t).sum().item()) + 1
                true_score = float(true_score_t.item())

            rows.append({
                "row_id": row_idx,
                "model": pred.loc[row_idx, "model"],
                "species": pred.loc[row_idx, "species"],
                "bucket": pred.loc[row_idx, "bucket"] if "bucket" in pred.columns else "",
                "protein_len": pred.loc[row_idx, "protein_len"] if "protein_len" in pred.columns else np.nan,
                "true_species_in_table": bool(true_in_table[row_idx]),
                "formal_csi_log_true_score": true_score,
                "true_rank": true_rank,
                "n_species_ranked": len(species_list),
            })

    out = pd.DataFrame(rows)
    out.to_csv(f"{args.out_prefix}_by_sequence.csv", index=False)

    summary = (
        out.dropna(subset=["true_rank"])
        .groupby("model", as_index=False)
        .agg(
            n=("row_id", "count"),
            mean_true_rank=("true_rank", "mean"),
            median_true_rank=("true_rank", "median"),
            top1_rate=("true_rank", lambda x: (x <= 1).mean()),
            top5_rate=("true_rank", lambda x: (x <= 5).mean()),
            top10_rate=("true_rank", lambda x: (x <= 10).mean()),
            top100_rate=("true_rank", lambda x: (x <= 100).mean()),
            mean_reciprocal_rank=("true_rank", lambda x: (1 / x).mean()),
        )
    )

    summary.to_csv(f"{args.out_prefix}_summary_by_model.csv", index=False)

    print("\n=== FORMAL CSI RANK SUMMARY ===")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
